// TestAutoFontDoc.cpp : implementation of the CTestAutoFontDoc class
//

#include "stdafx.h"
#include "TestAutoFont.h"

#include "TestAutoFontDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestAutoFontDoc

IMPLEMENT_DYNCREATE(CTestAutoFontDoc, CDocument)

BEGIN_MESSAGE_MAP(CTestAutoFontDoc, CDocument)
	//{{AFX_MSG_MAP(CTestAutoFontDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestAutoFontDoc construction/destruction

CTestAutoFontDoc::CTestAutoFontDoc()
{
	// TODO: add one-time construction code here

}

CTestAutoFontDoc::~CTestAutoFontDoc()
{
}

BOOL CTestAutoFontDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTestAutoFontDoc serialization

void CTestAutoFontDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTestAutoFontDoc diagnostics

#ifdef _DEBUG
void CTestAutoFontDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTestAutoFontDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestAutoFontDoc commands
