// TestAutoFontView.h : interface of the CTestAutoFontView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TESTAUTOFONTVIEW_H__D588AB4C_5F81_11D3_860A_A955A9614206__INCLUDED_)
#define AFX_TESTAUTOFONTVIEW_H__D588AB4C_5F81_11D3_860A_A955A9614206__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "AutoFont.h"

class CTestAutoFontView : public CView
{
protected: // create from serialization only
	CTestAutoFontView();
	DECLARE_DYNCREATE(CTestAutoFontView)

	CAutoFont m_font;
	COLORREF m_color;

// Attributes
public:
	CTestAutoFontDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestAutoFontView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTestAutoFontView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTestAutoFontView)
	afx_msg void OnTextChangefont();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TestAutoFontView.cpp
inline CTestAutoFontDoc* CTestAutoFontView::GetDocument()
   { return (CTestAutoFontDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTAUTOFONTVIEW_H__D588AB4C_5F81_11D3_860A_A955A9614206__INCLUDED_)
