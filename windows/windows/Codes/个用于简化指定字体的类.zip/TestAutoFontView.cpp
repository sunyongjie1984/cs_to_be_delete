// TestAutoFontView.cpp : implementation of the CTestAutoFontView class
//

#include "stdafx.h"
#include "TestAutoFont.h"

#include "TestAutoFontDoc.h"
#include "TestAutoFontView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestAutoFontView

IMPLEMENT_DYNCREATE(CTestAutoFontView, CView)

BEGIN_MESSAGE_MAP(CTestAutoFontView, CView)
	//{{AFX_MSG_MAP(CTestAutoFontView)
	ON_COMMAND(ID_TEXT_CHANGEFONT, OnTextChangefont)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestAutoFontView construction/destruction

CTestAutoFontView::CTestAutoFontView()
{
	m_color=RGB(0,0,0);
}

CTestAutoFontView::~CTestAutoFontView()
{
}

BOOL CTestAutoFontView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTestAutoFontView drawing

void CTestAutoFontView::OnDraw(CDC* pDC)
{
	CTestAutoFontDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CRect rect;
	GetClientRect(&rect);

	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(m_color);
	CFont *oldFont=pDC->SelectObject(&m_font);
	pDC->DrawText("Test", &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	pDC->SelectObject(oldFont);
}

/////////////////////////////////////////////////////////////////////////////
// CTestAutoFontView diagnostics

#ifdef _DEBUG
void CTestAutoFontView::AssertValid() const
{
	CView::AssertValid();
}

void CTestAutoFontView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTestAutoFontDoc* CTestAutoFontView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestAutoFontDoc)));
	return (CTestAutoFontDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestAutoFontView message handlers

void CTestAutoFontView::OnTextChangefont() 
{
	LOGFONT lf;
	m_font.GetLogFont(&lf);

	CFontDialog dlg(&lf, CF_EFFECTS | CF_SCREENFONTS, NULL, NULL);
	dlg.m_cf.rgbColors=m_color;

	if (dlg.DoModal()==IDOK)
	{
		dlg.GetCurrentFont(&lf);
		m_font.SetLogFont(lf);
		m_color=dlg.GetColor();
		CClientDC dc(this);
		dc.SetTextColor(m_color);
		Invalidate();
	}
}
