/* ==============================================================================================
 * File .......... : WidgetSizer.h
 * Purpose ....... : Definition for CWidgetSizer, implementation is in WidgetSizer.cpp
 * Last Modified . : 28/01/2000
 * QA Status ..... : Unproven
 * Author ........ : Andrew JM Hall
 * ==============================================================================================
 */

#if !defined(AFX_WIDGETSIZER_H__B3F1C293_D574_11D3_8186_000000000000__INCLUDED_)
#define AFX_WIDGETSIZER_H__B3F1C293_D574_11D3_8186_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Sizing Direction Flags
#define SIZE_NOT_SIZING		0
#define SIZE_TOP_LEFT		1
#define SIZE_TOP_MIDDLE		2
#define SIZE_TOP_RIGHT		3
#define SIZE_MIDDLE_LEFT	4
#define SIZE_MIDDLE_RIGHT	5
#define SIZE_BOTTOM_LEFT	6
#define SIZE_BOTTOM_MIDDLE	7
#define SIZE_BOTTOM_RIGHT	8

// Stores the sizing handle rectangles, the code is difficult to read 
// if we calculating these values every time a mousemove message is received
struct HotSpots	
{
	RECT TL;
	RECT TM;
	RECT TR;
	RECT ML;
	RECT MR;
	RECT BL;
	RECT BM;
	RECT BR;
};

/* ==============================================================================================
 *  Start Class Definition
 * ==============================================================================================
 */
class CWidgetSizer : public CStatic
{
public:
	BOOL AmITheTarget(CWnd *pTarget);
	CWidgetSizer(CWnd *pParent, CWnd *pTarget);
	virtual ~CWidgetSizer();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWidgetSizer)
	//}}AFX_VIRTUAL

protected:	// Variables
	CWnd *m_pParent;	// Parent window - was using AfxGetMainWnd but didn't work for doc/view
	CWnd *m_pTarget;	// Target window - what we are resizing / moving
	HCURSOR m_Cursor;	// Class cursor, normally IDC_SIZEALL
	CRect m_Rect;		// Where this control is
	HotSpots m_HotSpots;// The sizing handle rectangles 
	BYTE m_SizingFlag;	// Current operation when mousemove message is received
	POINT m_Point;		// Point where left mouse button pressed, for calculating direction for moving
	char m_Name[13];	// Storage for class name

protected: // Functions
	void UpdateHotSpots();
	void DrawItem(LPDRAWITEMSTRUCT lpDIS);
	void DrawFrame(CPaintDC *pDC);

	// Generated message map functions
	//{{AFX_MSG(CWidgetSizer)
	afx_msg void OnPaint();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMove(int x, int y);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WIDGETSIZER_H__B3F1C293_D574_11D3_8186_000000000000__INCLUDED_)
