// MyButton.cpp : implementation file
//

#include "stdafx.h"
#include "CSizerTest.h"
#include "MyButton.h"
#include "Globals.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyButton

CMyButton::CMyButton(CWnd *pParent, LPCTSTR szCaption)
{
	ASSERT (pParent);
	if (pParent)
	{
		m_pParent = pParent;
		Create(szCaption, WS_VISIBLE|WS_CHILD, CRect(10,10,75, 50), pParent, 100);
	}
}

CMyButton::~CMyButton()
{
	if (IsWindow(m_hWnd))
		DestroyWindow();
}


BEGIN_MESSAGE_MAP(CMyButton, CButton)
	//{{AFX_MSG_MAP(CMyButton)
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyButton message handlers

void CMyButton::OnLButtonDown(UINT nFlags, CPoint point) 
{		
	if (g_pWidgetSizer)
	{
		if (g_pWidgetSizer->AmITheTarget(this))
			return;
		
		delete g_pWidgetSizer;
		g_pWidgetSizer = NULL;
	}

	g_pWidgetSizer = new CWidgetSizer(m_pParent, this);
}

void CMyButton::OnRButtonUp(UINT nFlags, CPoint point) 
{
	AfxMessageBox(_T("Right mouse button up!"), MB_OK|MB_ICONINFORMATION);
	
	CButton::OnRButtonUp(nFlags, point);
}
