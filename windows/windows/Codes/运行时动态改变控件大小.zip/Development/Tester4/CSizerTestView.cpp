// CSizerTestView.cpp : implementation of the CCSizerTestView class
//

#include "stdafx.h"
#include "CSizerTest.h"

#include "CSizerTestDoc.h"
#include "CSizerTestView.h"

#include "MyButton.h"
#include "Globals.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCSizerTestView

IMPLEMENT_DYNCREATE(CCSizerTestView, CView)

BEGIN_MESSAGE_MAP(CCSizerTestView, CView)
	//{{AFX_MSG_MAP(CCSizerTestView)
	ON_COMMAND(ID_INSERT_BUTTON, OnInsertButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCSizerTestView construction/destruction

CCSizerTestView::CCSizerTestView()
{
}

CCSizerTestView::~CCSizerTestView()
{
	for (int i = 0; i <= m_ButtonList.GetUpperBound(); i++)
	{
		if (m_ButtonList[i])
			delete m_ButtonList[i];
	}

	if (g_pWidgetSizer)
		delete g_pWidgetSizer;
}

BOOL CCSizerTestView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CCSizerTestView drawing

void CCSizerTestView::OnDraw(CDC* pDC)
{
	CCSizerTestDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CCSizerTestView diagnostics

#ifdef _DEBUG
void CCSizerTestView::AssertValid() const
{
	CView::AssertValid();
}

void CCSizerTestView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CCSizerTestDoc* CCSizerTestView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCSizerTestDoc)));
	return (CCSizerTestDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCSizerTestView message handlers

void CCSizerTestView::OnInsertButton() 
{
	CString csCaption;
	CMyButton *pButton = NULL;
	int nButton = m_ButtonList.GetUpperBound() + 1;
	csCaption.Format(_T("Button %d"), nButton + 1);

	pButton = new CMyButton(this, csCaption);
	
	if (!pButton)
		return;

	if (IsWindow(pButton->m_hWnd))
	{
		m_ButtonList.Add(pButton);
		pButton->ShowWindow(SW_SHOW);

		if (g_pWidgetSizer)
		{
			delete g_pWidgetSizer;
			g_pWidgetSizer = NULL;
		}

		g_pWidgetSizer = new CWidgetSizer(this, pButton);
	}
	else
		delete pButton;
}
