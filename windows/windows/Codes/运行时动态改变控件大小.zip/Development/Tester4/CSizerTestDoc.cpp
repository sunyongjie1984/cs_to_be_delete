// CSizerTestDoc.cpp : implementation of the CCSizerTestDoc class
//

#include "stdafx.h"
#include "CSizerTest.h"

#include "CSizerTestDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCSizerTestDoc

IMPLEMENT_DYNCREATE(CCSizerTestDoc, CDocument)

BEGIN_MESSAGE_MAP(CCSizerTestDoc, CDocument)
	//{{AFX_MSG_MAP(CCSizerTestDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCSizerTestDoc construction/destruction

CCSizerTestDoc::CCSizerTestDoc()
{
	// TODO: add one-time construction code here

}

CCSizerTestDoc::~CCSizerTestDoc()
{
}

BOOL CCSizerTestDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CCSizerTestDoc serialization

void CCSizerTestDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CCSizerTestDoc diagnostics

#ifdef _DEBUG
void CCSizerTestDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CCSizerTestDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCSizerTestDoc commands
