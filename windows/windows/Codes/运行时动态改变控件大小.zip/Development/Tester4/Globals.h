#include "WidgetSizer.h"

extern CWidgetSizer *g_pWidgetSizer;