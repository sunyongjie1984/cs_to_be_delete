// CSizerTestView.h : interface of the CCSizerTestView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CSIZERTESTVIEW_H__21E872B0_D726_11D3_8189_000000000000__INCLUDED_)
#define AFX_CSIZERTESTVIEW_H__21E872B0_D726_11D3_8189_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <AfxTempl.h>

class CCSizerTestView : public CView
{
protected: // create from serialization only
	CCSizerTestView();
	DECLARE_DYNCREATE(CCSizerTestView)

// Attributes
public:
	CCSizerTestDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCSizerTestView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCSizerTestView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CArray<CWnd *, CWnd *> m_ButtonList;

// Generated message map functions
protected:
	//{{AFX_MSG(CCSizerTestView)
	afx_msg void OnInsertButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in CSizerTestView.cpp
inline CCSizerTestDoc* CCSizerTestView::GetDocument()
   { return (CCSizerTestDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CSIZERTESTVIEW_H__21E872B0_D726_11D3_8189_000000000000__INCLUDED_)
