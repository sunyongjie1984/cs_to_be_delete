/* ==============================================================================================
 * File .......... : WidgetSizer.cpp
 * Purpose ....... : A control to control size and position of other controls
 * Last Modified . : 30/01/2000
 * QA Status ..... : Unproven
 * Author ........ : Andrew JM Hall
 * ==============================================================================================
 */

#include "stdafx.h"
#include "CSizerTest.h"
#include "WidgetSizer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CCSizerTestApp theApp; // Replace this with your main class for the application

/* ==============================================================================================
 *  Function ..... : CWidgetSizer::CWidgetSizer(CWnd *pParent, CWnd *pTarget)
 *  Purpose ...... : Constructor
 *  Parameters ... : USUAL
 *  Returns ...... : Nothing
 * ==============================================================================================
 */
CWidgetSizer::CWidgetSizer(CWnd *pParent, CWnd *pTarget)
{
	ASSERT (pParent);
	ASSERT (pTarget);

	m_pParent = pParent;
	m_pTarget = pTarget;

	// Get the rect of the target control
	CRect rect;
	m_pTarget->GetWindowRect(&rect);	
	m_pParent->ScreenToClient(&rect);
	
	// Inflate rect to allow for the size of the borders (6 pixels)
	rect.InflateRect(6,6,6,6);

	// Move rect to allow for 3d borders
	m_Rect = CRect(rect.left - 4, rect.top - 4, rect.right - 4, rect.bottom - 4);

	strcpy(&m_Name[0],"CWIDGETSIZER");

	Create(_T(""), WS_CHILD|WS_VISIBLE|SS_NOTIFY, rect, m_pParent, 100);
	ShowWindow(SW_SHOW);
}

/* ==============================================================================================
 *  Function ..... : CWidgetSizer::~CWidgetSizer()
 *  Purpose ...... : Destructor
 *  Parameters ... : None
 *  Returns ...... : Nothing
 * ==============================================================================================
 */
CWidgetSizer::~CWidgetSizer()
{
	DestroyWindow();
}

BEGIN_MESSAGE_MAP(CWidgetSizer, CStatic)
	//{{AFX_MSG_MAP(CWidgetSizer)
	ON_WM_PAINT()
	ON_WM_MOUSEMOVE()
	ON_WM_CREATE()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/* ==============================================================================================
 *  Function ..... : void CWidgetSizer::OnPaint() 
 *  Purpose ...... : Called when the control needs (re) painting
 *  Parameters ... : None
 *  Returns ...... : Nothing
 * ==============================================================================================
 */
void CWidgetSizer::OnPaint() 
{	
	CPaintDC dc(this);
	DrawFrame(&dc);
}

/* =============================================================================================
 *  Function ..... : void CWidgetSizer::DrawFrame(CDC *pDC)
 *  Purpose ...... : Draws the "focus rectangle" around the target control
 *  Parameters ... : *pDC - pointer to a CPaintDC class
 *  Returns ...... : Nothing
 *  Notes ........ :
 *  First of all, 6 blue rectangles are drawn; the first starting 12 pixels wider and 12 pixels
 *	taller than the target (6 each side), each rectangle decreasing in width and height until 
 *	the last touches the outer edges of the target control. Then 8 white rectangles are drawn on 
 *	top of the thick blue one we now have. These white rectangles leave 8 blobs, one at each 
 *	corner and one at the centre of each side. Finally, these white rectangles are speckled. On 
 *	the second and forth lines of the white rectangle, every fourth pixel is repainted in blue. 
 *	The speckle painting also overpaints the blobs, but as they are the same colour it doesn't 
 *	matter.
 * =============================================================================================
 */
void CWidgetSizer::DrawFrame(CPaintDC *pDC)
{
	if(!pDC)
		return;

	COLORREF crBLUE		= RGB(0,0,255);
	COLORREF crWHITE	= RGB(255,255,255);
	
	CRect rect(m_Rect);

	// Draw a blue rectangle for starters
	for (int i = 0; i < 6; i++)
	{
		pDC->Draw3dRect(rect, crBLUE, crBLUE);
		rect.DeflateRect(1,1);
	}

	// Create a white brush
	CBrush Brush;
	Brush.CreateSolidBrush(crWHITE);
	
	// Paint 8 areas of the blue rectangle white (areas inbetween the sizing handles)
	pDC->FillRect(CRect(m_Rect.left + 6, m_Rect.top, m_Rect.CenterPoint().x - 3, m_Rect.top + 6), &Brush);
	pDC->FillRect(CRect(m_Rect.CenterPoint().x + 3, m_Rect.top, m_Rect.right - 6, m_Rect.top + 6), &Brush);
	pDC->FillRect(CRect(m_Rect.left + 6, m_Rect.bottom - 6, m_Rect.CenterPoint().x - 3, m_Rect.bottom), &Brush);
	pDC->FillRect(CRect(m_Rect.CenterPoint().x + 3, m_Rect.bottom - 6, m_Rect.right - 6, m_Rect.bottom), &Brush);
	pDC->FillRect(CRect(m_Rect.left, m_Rect.top + 6, m_Rect.left + 6, m_Rect.CenterPoint().y - 3), &Brush);
	pDC->FillRect(CRect(m_Rect.left, m_Rect.CenterPoint().y + 3, m_Rect.left + 6, m_Rect.bottom - 6), &Brush);
	pDC->FillRect(CRect(m_Rect.right - 6, m_Rect.top + 6, m_Rect.right, m_Rect.CenterPoint().y - 3), &Brush);		
	pDC->FillRect(CRect(m_Rect.right - 6, m_Rect.CenterPoint().y + 3, m_Rect.right, m_Rect.bottom - 6), &Brush);

	// Delete the white brush
	Brush.DeleteObject();
	
	// Draw blue "speckles" on the horizontal parts of the rectangle
	for (i = 6; i <= m_Rect.Width() - 4; (i = i + 4))
	{
		// Top two rows
		pDC->SetPixel(m_Rect.left + i, m_Rect.top + 2, crBLUE);
		pDC->SetPixel(m_Rect.left + (i - 2), m_Rect.top + 4, crBLUE);

		// Bottom two rows
		pDC->SetPixel(m_Rect.left + i, m_Rect.bottom - 2, crBLUE);
		pDC->SetPixel(m_Rect.left + (i - 2), m_Rect.bottom - 4, crBLUE);
	}

	// Draw blue "speckles" on the vertical parts of the rectangle
	for (i = 6; i <= m_Rect.Height() - 4; (i = i + 4))
	{
		// Left two columns
		pDC->SetPixel(m_Rect.left + 2, m_Rect.top + i, crBLUE);
		pDC->SetPixel(m_Rect.left + 4, m_Rect.top + (i - 2), crBLUE);

		// Right two columns
		pDC->SetPixel(m_Rect.right - 2, m_Rect.top + i, crBLUE);
		pDC->SetPixel(m_Rect.right - 4, m_Rect.top + (i - 2), crBLUE);
	}

	// Store the co-ordinates and sizes of the sizing handles
	UpdateHotSpots();	
}

/* ==============================================================================================
 *  Function ..... : void CWidgetSizer::OnMouseMove(UINT nFlags, CPoint point) 
 *  Purpose ...... : Controls the cursor, position and size of this control
 *  Parameters ... : nFlags - Indicates whether various virtual keys are down
 *				   : point  - Specifies the x and y co-ordinates of the cursor
 *  Returns ...... : Nothing
 * ==============================================================================================
 */
void CWidgetSizer::OnMouseMove(UINT nFlags, CPoint point) 
{
	UINT mFlags = nFlags;
	
	CRect rect;
    GetWindowRect(&rect);
	
	if ((mFlags | MK_LBUTTON) == mFlags)		// Moving or sizing
	{
		ClientToScreen(&point);
		m_pParent->ScreenToClient(&point);
		
		if (m_SizingFlag == SIZE_NOT_SIZING)	// Moving
		{
			int xm = point.x - m_Point.x;
			int ym = point.y - m_Point.y;
			
			MoveWindow(xm, ym, rect.Width(), rect.Height());
		}
		else									// Sizing
		{
			m_pParent->ScreenToClient(&rect);
			switch (m_SizingFlag)
			{
			case SIZE_MIDDLE_RIGHT:	 MoveWindow(CRect(rect.left, rect.top, point.x + 4, rect.bottom));	   break;
			case SIZE_MIDDLE_LEFT:	 MoveWindow(CRect(point.x - 4, rect.top, rect.right, rect.bottom));	   break;
			case SIZE_TOP_MIDDLE:	 MoveWindow(CRect(rect.left, point.y - 4, rect.right, rect.bottom));   break;
			case SIZE_BOTTOM_MIDDLE: MoveWindow(CRect(rect.left, rect.top, rect.right, point.y + 4));	   break;
			case SIZE_TOP_LEFT:		 MoveWindow(CRect(point.x - 4, point.y - 4, rect.right, rect.bottom)); break;
			case SIZE_TOP_RIGHT:	 MoveWindow(CRect(rect.left, point.y - 4, point.x + 4, rect.bottom));  break;
			case SIZE_BOTTOM_RIGHT:	 MoveWindow(CRect(rect.left, rect.top, point.x + 4, point.y + 4));	   break;
			case SIZE_BOTTOM_LEFT:	 MoveWindow(CRect(point.x - 4, rect.top, rect.right, point.y + 4));	   break;
			}
			m_pParent->Invalidate();
		}
	}
	else										// Neither sizing or moving
	{
		// Reset the cursor in case we changed it before
		m_Cursor = theApp.LoadStandardCursor(IDC_SIZEALL);
		SetClassLong(this->m_hWnd, GCL_HCURSOR,  (LONG)m_Cursor);

		if (CRect(m_HotSpots.TL).PtInRect(point))
		{
			::SetCursor(theApp.LoadStandardCursor(IDC_SIZENWSE));   // Top Left
			m_SizingFlag = SIZE_TOP_LEFT;
		}
		else if (CRect(m_HotSpots.TM).PtInRect(point))
		{
			::SetCursor(theApp.LoadStandardCursor(IDC_SIZENS));     // Top Middle
			m_SizingFlag = SIZE_TOP_MIDDLE;
		}
		else if (CRect(m_HotSpots.TR).PtInRect(point))
		{
			::SetCursor(theApp.LoadStandardCursor(IDC_SIZENESW));   // Top Right
			m_SizingFlag = SIZE_TOP_RIGHT;
		}
		else if (CRect(m_HotSpots.ML).PtInRect(point))
		{
			::SetCursor(theApp.LoadStandardCursor(IDC_SIZEWE));     // Middle Left
			m_SizingFlag = SIZE_MIDDLE_LEFT;
		}
		else if (CRect(m_HotSpots.MR).PtInRect(point))
		{
			::SetCursor(theApp.LoadStandardCursor(IDC_SIZEWE));     // Right Middle 
			m_SizingFlag = SIZE_MIDDLE_RIGHT;
		}
		else if (CRect(m_HotSpots.BL).PtInRect(point))
		{
			::SetCursor(theApp.LoadStandardCursor(IDC_SIZENESW));   // Bottom Left
			m_SizingFlag = SIZE_BOTTOM_LEFT;
		}
		else if (CRect(m_HotSpots.BM).PtInRect(point))
		{
			::SetCursor(theApp.LoadStandardCursor(IDC_SIZENS));     // Bottom Middle
			m_SizingFlag = SIZE_BOTTOM_MIDDLE;
		}
		else if (CRect(m_HotSpots.BR).PtInRect(point))
		{
			::SetCursor(theApp.LoadStandardCursor(IDC_SIZENWSE));   // Bottom Right
			m_SizingFlag = SIZE_BOTTOM_RIGHT;
		}
		else
			m_SizingFlag = SIZE_NOT_SIZING;
	}
}


/* ==============================================================================================
 *  Function ..... : void CWidgetSizer::UpdateHotSpots()
 *  Purpose ...... : Updates the list of hotspots, corresponding to the sizing handles
 *				   : Also moves / sizes the target control
 *  Parameters ... : None
 *  Returns ...... : Nothing
 * ==============================================================================================
 */
void CWidgetSizer::UpdateHotSpots()
{
	CRect rect;
	GetWindowRect(rect);
	ScreenToClient(&rect);

	m_Rect = rect;

	m_HotSpots.TL = CRect(rect.left, rect.top, 6,6);
	m_HotSpots.TM = CRect(rect.CenterPoint().x - 3, rect.top, rect.CenterPoint().x + 3, 6);
	m_HotSpots.TR = CRect(rect.right - 6, rect.top, rect.right,6);
	m_HotSpots.ML = CRect(rect.left, rect.CenterPoint().y - 3, 6,rect.CenterPoint().y + 3);
	m_HotSpots.MR = CRect(rect.right - 6, rect.CenterPoint().y - 3, rect.right,rect.CenterPoint().y + 3);
	m_HotSpots.BL = CRect(rect.left, rect.bottom - 6, 6, rect.bottom);
	m_HotSpots.BM = CRect(rect.CenterPoint().x - 3, rect.bottom - 6, rect.CenterPoint().x + 3, rect.bottom);
	m_HotSpots.BR = CRect(rect.right - 6, rect.bottom - 6, rect.right, rect.bottom);

	ClientToScreen(&rect);
	m_pParent->ScreenToClient(&rect);
	m_pTarget->MoveWindow(rect.left + 6, rect.top + 6, rect.Width() - 12, rect.Height() - 12);
	m_pTarget->Invalidate(FALSE);
}

/* ==============================================================================================
 *  Function ..... : int CWidgetSizer::OnCreate(LPCREATESTRUCT lpCreateStruct) 
 *  Purpose ...... : Sets the default cursor and registers the class
 *  Parameters ... : None
 *  Returns ...... : Nothing
 * ==============================================================================================
 */
int CWidgetSizer::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	
	if (CStatic::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_Cursor = theApp.LoadStandardCursor(IDC_SIZEALL);
	
	WNDCLASS mwnd;
	
	mwnd.hCursor = m_Cursor;
	mwnd.lpszClassName = m_Name;
	RegisterClass(&mwnd);

	SetClassLong(this->m_hWnd, GCL_HCURSOR,  (LONG)m_Cursor);
	
	return 0;
}

/* ==============================================================================================
 *  Function ..... : void CWidgetSizer::OnLButtonDown(UINT nFlags, CPoint point) 
 *  Purpose ...... : Maintains the correct cursor when the mouse is pressed to begin move/size
 *  Parameters ... : nFlags - Indicates whether various virtual keys are down
 *				   : point  - Specifies the x and y co-ordinates of the cursor
 *  Returns ...... : Nothing
 * ==============================================================================================
 */
void CWidgetSizer::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if (CRect(m_HotSpots.TL).PtInRect(point))
		m_Cursor = theApp.LoadStandardCursor(IDC_SIZENWSE);   // Top Left
	else if (CRect(m_HotSpots.TM).PtInRect(point))
		m_Cursor = theApp.LoadStandardCursor(IDC_SIZENS);     // Top Middle
	else if (CRect(m_HotSpots.TR).PtInRect(point))
		m_Cursor = theApp.LoadStandardCursor(IDC_SIZENESW);   // Top Right
	else if (CRect(m_HotSpots.ML).PtInRect(point))
		m_Cursor = theApp.LoadStandardCursor(IDC_SIZEWE);     // Middle Left
	else if (CRect(m_HotSpots.MR).PtInRect(point))
		m_Cursor = theApp.LoadStandardCursor(IDC_SIZEWE);     // Right Middle 
	else if (CRect(m_HotSpots.BL).PtInRect(point))
		m_Cursor = theApp.LoadStandardCursor(IDC_SIZENESW);   // Bottom Left
	else if (CRect(m_HotSpots.BM).PtInRect(point))
		m_Cursor = theApp.LoadStandardCursor(IDC_SIZENS);     // Bottom Middle
	else if (CRect(m_HotSpots.BR).PtInRect(point))
		m_Cursor = theApp.LoadStandardCursor(IDC_SIZENWSE);   // Bottom Right
	else
	{
		m_Cursor = theApp.LoadStandardCursor(IDC_SIZEALL);
		m_Point = point;
	}

	SetClassLong(this->m_hWnd, GCL_HCURSOR,  (LONG)m_Cursor);
	::SetCursor(m_Cursor);
}

/* ==============================================================================================
 *  Function ..... : BOOL CWidgetSizer::AmITheTarget(CWnd *pTarget)
 *  Purpose ...... : Let another class determine if it is the target
 *  Parameters ... : *pTarget - pointer to the CWnd to test against
 *  Returns ...... : TRUE - if the CWnd pointer is the same as our target
 * ==============================================================================================
 */
BOOL CWidgetSizer::AmITheTarget(CWnd *pTarget)
{
	if (m_pTarget == pTarget)
		return (TRUE);
	else
		return (FALSE);
}

/* ==============================================================================================
 *  Function ..... : void CWidgetSizer::OnMove(int x, int y) 
 *  Purpose ...... : Calls UpdateHotSpots to ensure correct Hot Spot values
 *  Parameters ... : None
 *  Returns ...... : Nothing
 *  Author ....... : Andrew JM Hall
 * ==============================================================================================
 */
void CWidgetSizer::OnMove(int x, int y) 
{
	CStatic::OnMove(x, y);
	
	UpdateHotSpots();
}

//* ==============================================================================================
//*  EOF WidgetSizer.cpp
//* ==============================================================================================

