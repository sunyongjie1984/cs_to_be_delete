//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Sample.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SAMPLETYPE                  129
#define ID_DATE_TIME                    32786
#define ID_READ_ONLY                    32795
#define ID_EDIT_DELETE                  37000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
