//
// Dialogs.cpp : implementation of testing dialogs
//
//@tabs=4

#include "StdAfx.h"
#include "resource.h"

#include "SmartEdit.h"
#include "Sliders.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CTestButtonDlg dialog


#define	BUTTON_COUNT	4


class CTestButtonDlg : public CDialog
{
private:
	BOOL m_bEnabled;

// Construction
public:
	CTestButtonDlg(CWnd* pParent = NULL);   // standard constructor

	CBitmapButton	Buttons[BUTTON_COUNT];

// Dialog Data
	//{{AFX_DATA(CTestButtonDlg)
	enum { IDD = IDD_BUTTON_DLG };
	//}}AFX_DATA

// Overrides
	//{{AFX_VIRTUAL(CTestButtonDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTestButtonDlg)
	afx_msg void OnExit();
	afx_msg void OnHelp();
	virtual void OnCancel();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnControl();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


CTestButtonDlg::CTestButtonDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestButtonDlg::IDD, pParent)
{
	m_bEnabled = FALSE;		// it will be toggled so start off false

	//{{AFX_DATA_INIT(CTestButtonDlg)
	//}}AFX_DATA_INIT
}


void CTestButtonDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestButtonDlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTestButtonDlg, CDialog)
	//{{AFX_MSG_MAP(CTestButtonDlg)
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_BN_CLICKED(IDC_CONTROL, OnControl)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


void CTestButtonDlg::OnCancel() 
{
	// swallow the button click
}


void CTestButtonDlg::OnOK() 
{
	// swallow the button click
}


void CTestButtonDlg::OnHelp() 
{
	// swallow the button click
}


void CTestButtonDlg::OnExit() 
{
	EndDialog( IDOK );		// end the dialog
}


void CTestButtonDlg::OnControl() 
{
	// toggle the enable flag

	char *	text;
	int		state;

	if( m_bEnabled )
		{
		state = FALSE;
		text = "Enable";
		}
	else
		{
		state = TRUE;
		text = "Disable";
		}

	SetDlgItemText( IDC_CONTROL, text );

	for( int x = 0; x < BUTTON_COUNT; x += 1 )
		Buttons[x].EnableWindow( state );

	m_bEnabled = state;
}


BOOL CTestButtonDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// load bitmaps for all the bitmap buttons

	VERIFY( Buttons[0].AutoLoad( IDOK, this ) );
	VERIFY( Buttons[1].AutoLoad( IDCANCEL, this ) );
	VERIFY( Buttons[2].AutoLoad( IDHELP, this ) );
	VERIFY( Buttons[3].AutoLoad( ID_APPLY_NOW, this ) );

	OnControl();	// set the button states
	
	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CTestEditDlg dialog

class CTestEditDlg : public CDialog
{
// Construction
public:
	CTestEditDlg(CWnd* pParent = NULL);   // standard constructor

	CBitmapButton	Buttons[2];

// Dialog Data
	//{{AFX_DATA(CTestEditDlg)
	enum { IDD = IDD_EDIT_DLG };
	CSmartEdit	m_Edit1;
	CSmartEdit	m_Edit2;
	CSmartEdit	m_Edit3;
	CSmartEdit	m_Edit4;
	CSmartEdit	m_Edit5;
	//}}AFX_DATA


// Overrides
	//{{AFX_VIRTUAL(CTestEditDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CTestEditDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


CTestEditDlg::CTestEditDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestEditDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestEditDlg)
	//}}AFX_DATA_INIT
}


void CTestEditDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestEditDlg)
	DDX_Control(pDX, IDC_EDIT1, m_Edit1);
	DDX_Control(pDX, IDC_EDIT2, m_Edit2);
	DDX_Control(pDX, IDC_EDIT3, m_Edit3);
	DDX_Control(pDX, IDC_EDIT4, m_Edit4);
	DDX_Control(pDX, IDC_EDIT5, m_Edit5);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTestEditDlg, CDialog)
	//{{AFX_MSG_MAP(CTestEditDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CTestEditDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	VERIFY( Buttons[0].AutoLoad( IDOK, this ) );
	VERIFY( Buttons[1].AutoLoad( IDCANCEL, this ) );

	m_Edit1.SetParseType( SES_LETTERS ); 
	m_Edit2.SetParseType( SES_NUMBERS | SES_SIGNED ); 
	m_Edit3.SetParseType( SES_LETTERS | SES_NUMBERS | SES_UNDERSCORE ); 
	m_Edit4.SetParseType( SES_FLOATINGPT ); 
	m_Edit5.SetParseType( SES_ALL ); 
	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CTestSlidersDlg dialog

class CTestSlidersDlg : public CDialog
{
// Construction
public:
	CTestSlidersDlg(CWnd* pParent = NULL);   // standard constructor

	CBitmapButton	Buttons[BUTTON_COUNT];

// Dialog Data

	//{{AFX_DATA(CTestSlidersDlg)
	enum { IDD = IDD_SLIDE_DLG };
	CSmartEdit	m_Edit1;
	CSmartEdit	m_Edit2;
	CSmartEdit	m_Edit3;
	CLinkSlider	m_Slider1;
	CLinkSlider	m_Slider2;
	CLinkSlider	m_Slider3;
	//}}AFX_DATA


// Overrides
	//{{AFX_VIRTUAL(CTestSlidersDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
protected:

	//{{AFX_MSG(CTestSlidersDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnHelp();
	afx_msg void OnApplyNow();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


CTestSlidersDlg::CTestSlidersDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestSlidersDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestSlidersDlg)
	//}}AFX_DATA_INIT
}


void CTestSlidersDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestSlidersDlg)
	DDX_Control(pDX, IDC_EDIT1, m_Edit1);
	DDX_Control(pDX, IDC_EDIT2, m_Edit2);
	DDX_Control(pDX, IDC_EDIT3, m_Edit3);
	DDX_Control(pDX, IDC_SLIDER1, m_Slider1);
	DDX_Control(pDX, IDC_SLIDER2, m_Slider2);
	DDX_Control(pDX, IDC_SLIDER3, m_Slider3);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTestSlidersDlg, CDialog)
	//{{AFX_MSG_MAP(CTestSlidersDlg)
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_BN_CLICKED(ID_APPLY_NOW, OnApplyNow)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CTestSlidersDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// load bitmaps for all the bitmap buttons

	VERIFY( Buttons[0].AutoLoad( IDOK, this ) );
	VERIFY( Buttons[1].AutoLoad( IDCANCEL, this ) );
	VERIFY( Buttons[2].AutoLoad( IDHELP, this ) );
	VERIFY( Buttons[3].AutoLoad( ID_APPLY_NOW, this ) );

	// setup first slider-edit box - integer

	m_Edit1.SetSlideLink( this, IDC_SLIDER1 );
	m_Edit1.SetParams( -100, 100, 10 );
	m_Edit1.SetValue( 0 );

	// setup second slider-edit box - integer

	m_Edit2.SetSlideLink( this, IDC_SLIDER2 );
	m_Edit2.SetParams( 0, 100, 10 );
	m_Edit2.SetValue( 50 );

	// setup third slider-edit box - floating point

	m_Edit3.SetSlideLink( this, IDC_SLIDER3 );
	m_Edit3.SetParams( 0.0, 10.0, 10, "%6.3f" );
	m_Edit3.SetValue( 2.0 );

	return TRUE;
}


void CTestSlidersDlg::OnHelp()
{
	MessageBox( "No Help Is Available Now", "Sorry" );
}


void CTestSlidersDlg::OnApplyNow()
{
	// swallow the click
}


/////////////////////////////////////////////////////////////////////////////
// invoke the testing dialogs
// these functions are separated like this so that the app doesn't
// have to "really" know about these dialogs and these dialogs
// don't have to "really" know about the app : no includes needed.


int TestSliders( CWnd* pParent )
{
	CTestSlidersDlg dlg( pParent );
	return dlg.DoModal();
}


int TestEditBoxes( CWnd* pParent )
{
	CTestEditDlg dlg( pParent );
	return dlg.DoModal();
}


int TestButtons( CWnd* pParent )
{
	CTestButtonDlg dlg( pParent );
	return dlg.DoModal();
}
