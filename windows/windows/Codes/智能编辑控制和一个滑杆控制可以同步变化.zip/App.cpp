//
// App.cpp : Defines the class behaviors for the application.
//
//@tabs=4

#include "Stdafx.h"
#include "resource.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// testing dialog functions
// this way no header need be included

extern int TestSliders( CWnd* pParent );
extern int TestEditBoxes( CWnd* pParent );
extern int TestButtons( CWnd* pParent );


///////////////////////////////////////////////////////////
// CAppDlg - the application dialog

class CAppDlg : public CDialog
{
private:

// Construction
public:
	CAppDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CAppDlg)
	enum { IDD = IDD_APP_DLG };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CAppDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CAppDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTestButtons();
	afx_msg void OnTestEditBoxes();
	afx_msg void OnTestSliders();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


CAppDlg::CAppDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAppDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAppDlg)
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}


void CAppDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAppDlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAppDlg, CDialog)
	//{{AFX_MSG_MAP(CAppDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_TEST_BUTTON, OnTestButtons)
	ON_BN_CLICKED(IDC_TEST_EDIT, OnTestEditBoxes)
	ON_BN_CLICKED(IDC_TEST_SLIDERS, OnTestSliders)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


// CAppDlg message handlers

BOOL CAppDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	return TRUE;
}


HCURSOR CAppDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CAppDlg::OnPaint() 
{
	if( IsIconic() )	// must draw ourselves since this is a dialog
		{
		CPaintDC dc(this);		// device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
		}
	else
		{
		CDialog::OnPaint();
		}
}


///////////////////////////////////////////////////////////
// functions to invoke the testing dialogs

void CAppDlg::OnTestButtons() 
{
	TestButtons( this );	
}


void CAppDlg::OnTestEditBoxes() 
{
	TestEditBoxes( this );	
}


void CAppDlg::OnTestSliders() 
{
	TestSliders( this );	
}


///////////////////////////////////////////////////////////
// CTestApp - the application class

class CTestApp : public CWinApp
{
public:
	CTestApp();

// Overrides
	//{{AFX_VIRTUAL(CTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTestApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


BEGIN_MESSAGE_MAP(CTestApp, CWinApp)
	//{{AFX_MSG_MAP(CTestApp)
	//}}AFX_MSG
END_MESSAGE_MAP()


// CTestApp construction

CTestApp::CTestApp()
{
}


// CTestApp initialization

BOOL CTestApp::InitInstance()
{
#ifdef _AFXDLL
	Enable3dControls();			// when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// when linking to MFC statically
#endif

	CAppDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	return FALSE;
}


CTestApp theApp;	// instantiate the app object

