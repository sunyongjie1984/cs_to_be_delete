//{{HAS_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SmartEdit.RC
//
#define IDD_APP_DLG                     101
#define IDD_EDIT_DLG                    102
#define IDD_SLIDE_DLG                   103
#define IDD_BUTTON_DLG                  104
#define IDC_EDIT1                       1001
#define IDC_EDIT2                       1002
#define IDC_EDIT3                       1003
#define IDC_EDIT4                       1004
#define IDC_EDIT5                       1005
#define IDC_SLIDER1                     1011
#define IDC_SLIDER2                     1012
#define IDC_SLIDER3                     1013
#define IDC_CONTROL                     1021
#define IDC_EXIT                        1022
#define IDC_TEST_EDIT                   1022
#define IDC_TEST_BUTTON                 1023
#define IDC_TEST_SLIDERS                1024
#define IDR_MAINFRAME                   31235

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
