// HTMLDemoDoc.cpp : implementation of the CHTMLDemoDoc class
//

#include "stdafx.h"
#include "HTMLDemo.h"

#include "HTMLDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHTMLDemoDoc

IMPLEMENT_DYNCREATE(CHTMLDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CHTMLDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CHTMLDemoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHTMLDemoDoc construction/destruction

CHTMLDemoDoc::CHTMLDemoDoc()
{
	// TODO: add one-time construction code here

}

CHTMLDemoDoc::~CHTMLDemoDoc()
{
}

BOOL CHTMLDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CHTMLDemoDoc serialization

void CHTMLDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CHTMLDemoDoc diagnostics

#ifdef _DEBUG
void CHTMLDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CHTMLDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHTMLDemoDoc commands
