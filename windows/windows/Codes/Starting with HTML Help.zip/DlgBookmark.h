#if !defined(AFX_DLGBOOKMARK_H__7137A1B7_CFFD_11D2_857E_00105A2DFCCD__INCLUDED_)
#define AFX_DLGBOOKMARK_H__7137A1B7_CFFD_11D2_857E_00105A2DFCCD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgBookmark.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgBookmark dialog

class CDlgBookmark : public CDialog
{
// Construction
public:
	CDlgBookmark(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgBookmark)
	enum { IDD = IDD_BOOKMARK };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgBookmark)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgBookmark)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGBOOKMARK_H__7137A1B7_CFFD_11D2_857E_00105A2DFCCD__INCLUDED_)
