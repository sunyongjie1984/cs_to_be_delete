// HTMLDemoView.cpp : implementation of the CHTMLDemoView class
//

#include "stdafx.h"
#include "HTMLDemo.h"

#include "HTMLDemoDoc.h"
#include "HTMLDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHTMLDemoView

IMPLEMENT_DYNCREATE(CHTMLDemoView, CView)

BEGIN_MESSAGE_MAP(CHTMLDemoView, CView)
	//{{AFX_MSG_MAP(CHTMLDemoView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHTMLDemoView construction/destruction

CHTMLDemoView::CHTMLDemoView()
{
	// TODO: add construction code here

}

CHTMLDemoView::~CHTMLDemoView()
{
}

BOOL CHTMLDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CHTMLDemoView drawing

void CHTMLDemoView::OnDraw(CDC* pDC)
{
	CHTMLDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CHTMLDemoView printing

BOOL CHTMLDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CHTMLDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CHTMLDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CHTMLDemoView diagnostics

#ifdef _DEBUG
void CHTMLDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CHTMLDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CHTMLDemoDoc* CHTMLDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CHTMLDemoDoc)));
	return (CHTMLDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHTMLDemoView message handlers
