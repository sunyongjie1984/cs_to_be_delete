#include <alloc.h>
#include <stdio.h>

void printcore()
 {
    printf("Core:%lu\n",farcoreleft());

}
#pragma   startup printcore 66
#pragma   exit printcore 66

main(void)
{
 char * data;

//  FILE * f=fopen("CON","wt");
  printf(
  " Use dos command SET DEBUG=file \n"
  "  where file is CON, PRN or any valid dos filename\n"
  );

  data = malloc(50);
  data=realloc(data,20);
  data=realloc(data,100);
  free (data);
//  fclose(f);
  return 0;

}