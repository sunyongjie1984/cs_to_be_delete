VesaTest
--------

   This is a demonstration of how to utilize the 640x480x256 color SVGA mode
by means of VESA device driver calls.  Not only that, but included is several
routines which show off video cards which use more than 1 meg of ram through
virtual paging.
   Included and integrated into the demo package are routines to handle full
digitized sound support (.wav or .voc type files) with double-buffering and
full DMA/IRQ detection!  No more asking the user for information.
   Also in this package are mouse routines which intercept mouse interrupts
and full support for 2-button and 3-button mice.  2-button users can simulate
the middle button by pressing left and right buttons simultaneously, so there's
no real disadvantage in programming for 3 buttons.

The source code was written in Borland C++ v3.1.  This package is released
to the public as of July 20th, 1994 as Tagware.  If you find it useful and
you write something using any of the routines in my package, please put a tag
in your program's title screen (or someplace visible) that I helped you.
Try to send me a copy of it too.  I like to see new software (w/ my name on 
it, of course :-).

Caution: Many SVGA card manufacturers did not and continue to not provide good
device drivers for their VESA compatibility modes.  My first recommendation is
to try whatever the manufacturer gives out with the card.  If this package
fails for whatever reason, attempt to obtain the most recent version of the
Universal VESA Bios Extender (UniVBE) from any good FTP site.  I believe as
of this writing, "univbe43.zip" was still floating around and version 5.0 was
due out.  UniVBE is a very stable, fast driver for almost any card.  If you
are to rely on VESA calls, you must recognize that out of every 10 SVGA cards
out there, you can count on at least two of them being very incompatible.

This archive contains:
    WAVCOMP.EXE         An ADPCM .wav compressor.  Not compatible with anything
    WAVUNCOM.EXE        The matching decompressor for WAVCOMP.EXE
    VESATEST.EXE        Compiled demo program
    VESANOIZ.SPA        Compressed .wav file
    VESATEST.CPP        Source code to demo
    RUNME.BAT           Last minute note to users and decompresses VESANOIZ.SPA
    README.TXT          See README.TXT...

If you are missing any files, please contact the sysadmin at the site from
which you received this archive and alert them of the mistake.

To send donations, I prefer a postcard from your city, state, or country.  If
you insist on monetary donations, $5 is certainly sufficient--but don't let
me stop you from sending more.  Realize that I cannot afford to send anything
back, so please don't send disks, pictures, tapes, cats, loved ones, or other
personal affects which might be important to you, because I'll keep them.
That's not a promise, though, so no ex-wives or ex-husbands. :-)  I'll send
them back.

Ground mail (USA):  Jason Hughes      Email: hughes@ccwf.cc.utexas.edu
                    5812 Abilene Trail
                    Austin, TX 78749

Thanks go out to the Game Programmer's Encyclopedia, Game Developer's Magazine,
everybody at rec.games.programmer, comp.os.msdos,programmer, VLA (palettes),
and innumerable others who voluntarily tested this over the past three months.
                G      R     A     C    I    A    S    !

...one last thing, if you send me any (e)mail, please tell me how and where
you found VESATEST.  I'm especially interested in hearing about compilations
and CDROMs and so forth.  

Enjoy!

The Panther!

------------------------------------------------------------------------------
This appendage is to tell users that this is revision 2 of the demo/library.

Changes include:
  o  3-button mouse detection
  o  a global variable called "mousebuttons" which contains either 2 or 3,
       depending on what kind of mouse is detected
  o  double speed mouse movement at a program- or user- specified breakover
       point, so if you move slow it's high resolution, fast it's twice as fast
  o  simulation of a third button with 2-button mice (is simple to comment out)
  o  fixed bug where vesa initialization would return errors on black screen
       with black characters (smack! "Stuupid, soo stuupid!")
  o  clearscr() now clears all the ram in the video card, not only first meg

Special notes:
  If you are using a 3-button mouse, it may be possible that the button states
are inverted.  Please send me a note in email along with a description of your
mouse and driver and com port information.  The data I received on button 
states (0 being pressed, 1 being released) was backwards for _my_ mouse, no
matter what drivers I tested with it, so I naturally made it work properly for
_my_ mouse.  I hope I did the right thing.  <crosses fingers>

Any comments, complaints, or ideas are welcome.  But please try to do minimal
troubleshooting with your system and vesa card configuration before telling
me this stuff doesn't work.  It does.  Merely realize that SVGA is extremely
nonstandard and sometimes it cannot be helped that things do not work as 
planned.  Thank you for your consideration.

The Panther!
hughes@ccwf.cc.utexas.edu
