/*
   Module        :  Header test
   Version       :  2.0
   Revision date :  July 3rd, 1993
   Author(s)     :  R�my Gendron

   Description   :  Tests if a header file can be compiled all by itself.
*/


/* Headers --------------------------------------------------------------- */

#include "stdfcts.h"


/* Main ------------------------------------------------------------------ */

void main
(
   void
)

{
   return ;                                  /* The header has been tested */
}                                                              /* End main */


/* ----------------------------------------------------------------------- */
