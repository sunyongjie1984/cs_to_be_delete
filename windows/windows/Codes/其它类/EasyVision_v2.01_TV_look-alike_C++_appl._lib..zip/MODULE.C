/*
   Module        : MODULE.C
   Version       : 2.0
   Revision date : July 3rd, 1993
   Author(s)     : Remy Gendron

   Description   : Module file template.
*/


/* Headers --------------------------------------------------------------- */

#include <stdio.h>                                   /* System's libraries */
#pragma hdrstop

#include "module.h"                           /* This module's header file */


/* Macros ---------------------------------------------------------------- */


/* TypeDefs -------------------------------------------------------------- */


/* ----------------------------------------------------------------------- */

return_type function_name                                   /* Description */
(
   type param,                                              /* Description */
   type param,                                              /* Description */
   ...
)

{


   return ;                                     /* End of function comment */
}                                                     /* End function_name */


/* End source file ------------------------------------------------------- */
