/*
   Module        : PRJMSGS.C
   Version       : 2.0
   Revision date : July 3rd, 1993
   Author(s)     : Remy Gendron

   Description   : Global definitions of project's output messages.
                   Suggestion :
                      Begin all message variable with 'msg_'.
*/


/* ----------------------------------------------------------------------- */

char huge *msg_name =                                /* Message definition */

   "Put message here..." ;


/* End source file ------------------------------------------------------- */
