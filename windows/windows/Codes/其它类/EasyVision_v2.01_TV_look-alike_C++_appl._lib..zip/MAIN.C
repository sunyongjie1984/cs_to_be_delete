/*
   Project       : EasyVision
   Version       : 2.0
   Revision Date : July 3rd, 1993
   Author(s)     : Remy Gendron

   Description   : Main source file template. (C)
*/


/* Headers --------------------------------------------------------------- */

#include <stdio.h>                                   /* System's libraries */
#pragma hdrstop


/* Macros ---------------------------------------------------------------- */

#include "stdmacro.h"
#include "prjmacro.h"


/* TypeDefs -------------------------------------------------------------- */

#include "stdtype.h"
#include "prjtype.h"


/* ----------------------------------------------------------------------- */

int main
(
   int  argc,                          /* Number of command line arguments */
   char **argv                  /* Array of ptrs to command line arguments */
)

{


   return 0 ;                                /* Program normal termination */
}                                                              /* End main */


/* End Source File ------------------------------------------------------- */
