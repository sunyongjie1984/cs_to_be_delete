// TComboBox.cpp : implementation file
//
// Author:	Christopher Conn
// Created:	07/22/98
//

#include "stdafx.h"
#include "TComboBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTComboBox

CTComboBox::CTComboBox()
			: CComboBox()
{
	m_iBottom = -1;
	lptsArray = NULL;
	m_eType = CTComboBox::Unknown;

	// Initialize selected variables
	m_csSelectedText = _T("");
	m_csSelectedCode = _T("");
	m_iSelectedCode = -1;
	m_lSelectedCode = 0;
	m_dwSelectedCode = 0;
}	// CTComboBox::CTComboBox()

CTComboBox::~CTComboBox()
{
	CComboBox::~CComboBox();

	m_eType = CTComboBox::Unknown;
}	// CTComboBox::~CTComboBox()


BEGIN_MESSAGE_MAP(CTComboBox, CComboBox)
	//{{AFX_MSG_MAP(CTComboBox)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTComboBox message handlers

BOOL CTComboBox::AddEntry(CString &rcsText, CString &rcsCode)
{
	BOOL
		bRtrn = FALSE;

	// Allocate the initial pointer if necessary
	if (lptsArray == NULL)
		lptsArray = new LPTSTR[SHRT_MAX];

	// Make sure that something was allocated
	if (lptsArray != NULL)
	{
		LPTSTR
			lpStr;

		// Allocate some memory
		int
			iSzTchar = sizeof _TCHAR;

		lpStr = new _TCHAR[(rcsCode.GetLength() + 1) * iSzTchar];

		// Validate pointer
		if (lpStr != NULL)
		{
			// Set the type if necessary
			if (m_eType == CTComboBox::Unknown)
				m_eType = CTComboBox::String;
			_tcscpy(lpStr, (LPTSTR)(LPCTSTR)rcsCode);

			// Add the code string to our list
			lptsArray[++m_iBottom] = lpStr;

			bRtrn = AddEntry(rcsText, (DWORD)lpStr);
		}	// End of pointer validation
	}	// End of pointer to array validation

	return bRtrn;
}	// CTComboBox::AddEntry(CString &rcsText, CString &rcsCode)

BOOL CTComboBox::AddEntry(CString &rcsText, LPCTSTR lpcsCode)
{
	// Set the type if necessary
	if (m_eType == CTComboBox::Unknown)
		m_eType = CTComboBox::LPString;

	// Call the CString based function
	return AddEntry(rcsText, CString(lpcsCode));
}	// CTComboBox::AddEntry(CString &rcsText, LPCTSTR lpcsCode)

BOOL CTComboBox::AddEntry(CString &rcsText, int iCode)
{
	// Set the type if necessary
	if (m_eType == CTComboBox::Unknown)
		m_eType = CTComboBox::Int;

	// Call the standard insert
	return AddEntry(rcsText, (DWORD)iCode);
}	// CTComboBox::AddEntry(CString &rcsText, int iCode)

BOOL CTComboBox::AddEntry(CString &rcsText, long lCode)
{
	// Set the type if necessary
	if (m_eType == CTComboBox::Unknown)
		m_eType = CTComboBox::Long;

	// Call the standard insert
	return AddEntry(rcsText, (DWORD)lCode);
}	// CTComboBox::AddEntry(CString &rcsText, long lCode)

BOOL CTComboBox::AddEntry(CString &rcsText, DWORD dwCode)
{
	BOOL
		bRtrn = FALSE;
	int
		iInsertPos;

	// Set the type if necessary
	if (m_eType == CTComboBox::Unknown)
		m_eType = CTComboBox::Double;

	// Attempt to insert the string into the combobox
	iInsertPos = CComboBox::AddString((LPCTSTR)rcsText);

	// Check if position is valid
	if ((iInsertPos != CB_ERR) && (iInsertPos != CB_ERRSPACE))
	{
		// Make sure that the Data was set properly
		if (CComboBox::SetItemData(iInsertPos, dwCode) != CB_ERR)
			bRtrn = TRUE;
	}	// End of check if position is valid

	return bRtrn;
}	// CTComboBox::AddEntry(CString &rcsText, DWORD dwCode)

CString CTComboBox::GetCurrentText()
{
	return GetSelectedText();
}	// CTComboBox::GetCurrentText()

CString CTComboBox::GetSelectedText()
{
	CString
		csTmp = _T("");

	// See if the handle to the window is OK
	if (m_hWnd != NULL)
	{
		// Get the current selection
		int iCurSel = this->GetCurSel();

		// Make sure the current selection was set
		if (iCurSel != CB_ERR)
			m_csSelectedText = GetText(iCurSel);
	}	// End of check to see if handle to window is valid

	return m_csSelectedText;
}	// CTComboBox::GetSelectedText()

CString CTComboBox::GetText(int iCBSelection)
{
	ASSERT(iCBSelection != CB_ERR);

	CString
		csTmp = _T("");

	// Make sure that a selection was given
	if (iCBSelection != CB_ERR)
		this->GetLBText(iCBSelection, csTmp);

	return csTmp;
}	// CTComboBox::GetText(int iCBSelection)

BOOL CTComboBox::GetSelectedCode(CString &rcsCode)
{
	// See if the handle to the window is OK
	if (m_hWnd != NULL)
	{
		// Get the current selection
		int iCurSel = this->GetCurSel();

		// Make sure the current selection was set
		if (iCurSel != CB_ERR)
			return GetCode(iCurSel, rcsCode);
		else
			return FALSE;
	}	// End of check if screen is active
	else
		rcsCode = m_csSelectedCode;

	return TRUE;
}	// CTComboBox::GetSelectedCode(CString &rcsCode)

BOOL CTComboBox::GetSelectedCode(int *piCode)
{
	return GetCurrentCode(piCode);
}	// CTComboBox::GetSelectedCode(int *piCode)

BOOL CTComboBox::GetSelectedCode(long *plCode)
{
	return GetCurrentCode(plCode);
}	// CTComboBox::GetSelectedCode(long *plCode)

BOOL CTComboBox::GetSelectedCode(DWORD *pdwCode)
{
	return GetCurrentCode(pdwCode);
}	// CTComboBox::GetSelectedCode(DWORD *pdwCode)

BOOL CTComboBox::GetCurrentCode(CString &rcsCode)
{
	return GetSelectedCode(rcsCode);
}	// CTComboBox::GetCurrentCode(CString &rcsCode)

BOOL CTComboBox::GetCurrentCode(int *piCode)
{
	ASSERT(piCode != NULL);

	BOOL
		bRtrn = FALSE;
	int
		iVal = -1;

	// See if the handle to the window is OK
	if (m_hWnd != NULL)
	{
		// Get the current selection
		int iCurSel = this->GetCurSel();

		// Make sure the current selection was set
		if (iCurSel != CB_ERR)
			bRtrn = GetCode(iCurSel, &iVal);
	}	// End of check if screen is active
	else
		iVal = m_iSelectedCode;

	// Convert value as needed
	switch(m_eType)
	{
	case String:
	case LPString:
		*piCode = _ttoi(m_csSelectedCode);
		break;
	case Int:
	case Long:
	case Double:
		*piCode = iVal;
		break;
	}	// End of conversion

	return bRtrn;
}	// CTComboBox::GetCurrentCode(int *piCode)

BOOL CTComboBox::GetCurrentCode(long *plCode)
{
	ASSERT(plCode != NULL);

	BOOL
		bRtrn = FALSE;
	long
		lVal = 0;

	// See if the handle to the window is OK
	if (m_hWnd != NULL)
	{
		// Get the current selection
		int iCurSel = this->GetCurSel();

		// Make sure the current selection was set
		if (iCurSel != CB_ERR)
			bRtrn = GetCode(iCurSel, &lVal);
	}	// End of check if screen is active
	else
		lVal = m_lSelectedCode;

	// Convert value as needed
	switch(m_eType)
	{
	case String:
	case LPString:
		*plCode = _ttol(m_csSelectedCode);
		break;
	case Int:
	case Long:
	case Double:
		*plCode = lVal;
		break;
	}	// End of conversion

	return bRtrn;
}	// CTComboBox::GetCurrentCode(long *plCode)

BOOL CTComboBox::GetCurrentCode(DWORD *pdwCode)
{
	ASSERT(pdwCode != NULL);

	BOOL
		bRtrn = FALSE;
	DWORD
		dwVal = 0;

	// See if the handle to the window is OK
	if (m_hWnd != NULL)
	{
		// Get the current selection
		int iCurSel = this->GetCurSel();

		// Make sure the current selection was set
		if (iCurSel != CB_ERR)
			bRtrn = GetCode(iCurSel, &dwVal);
	}	// End of check if screen is active
	else
		dwVal = m_dwSelectedCode;

	// Convert value as needed
	switch(m_eType)
	{
	case String:
	case LPString:
		*pdwCode = _ttol(m_csSelectedCode);
		break;
	case Int:
	case Long:
	case Double:
		*pdwCode = dwVal;
		break;
	}	// End of conversion

	return bRtrn;
}	// CTComboBox::GetCurrentCode(DWORD *pdwCode)

BOOL CTComboBox::GetCode(int iCBSelection, CString &rcsCode)
{
	ASSERT(iCBSelection != CB_ERR);

	BOOL
		bRtrn = FALSE;
	DWORD
		dwData = 0;
	LPSTR
		lpStr = NULL;

	// Get the item data
	dwData = GetItemData(iCBSelection);

	// Check item data
	if (dwData != NULL)
		bRtrn = TRUE;

	// Make sure that all is OK so far
	if (bRtrn)
	{
		// Determine which type of code it is originally
		switch (m_eType)
		{
		case Unknown:
			rcsCode = _T("");
			break;
		case String:
		case LPString:
			lpStr = (_TCHAR *)dwData;
			rcsCode = lpStr;
			bRtrn = TRUE;
			break;
		case Int:
			rcsCode.Format(_T("%d"), dwData);
			bRtrn = TRUE;
			break;
		case Long:
		case Double:
			rcsCode.Format(_T("%ld"), dwData);
			bRtrn = TRUE;
		}	// Switch depending on the type of code
	}	// End of check if all is OK so far

	return bRtrn;
}	// CTComboBox::GetCode(int iCBSelection, CString &rcsCode)

BOOL CTComboBox::GetCode(int iCBSelection, int *piCode)
{
	ASSERT(iCBSelection != CB_ERR);

	// Call the standard Get
	return GetCode(iCBSelection, (DWORD *)piCode);
}	// CTComboBox::GetCode(int iCBSelection, int *piCode)

BOOL CTComboBox::GetCode(int iCBSelection, long *plCode)
{
	ASSERT(iCBSelection != CB_ERR);

	// Call the standard Get
	return GetCode(iCBSelection, (DWORD *)plCode);
}	// CTComboBox::GetCode(int iCBSelection, long *plCode)

BOOL CTComboBox::GetCode(int iCBSelection, DWORD *pdwCode)
{
	ASSERT(iCBSelection != CB_ERR);

	BOOL
		bRtrn = FALSE;
	DWORD
		dwVal = 0;

	// Make sure the current selection was set
	if (iCBSelection != CB_ERR)
	{
		// Try to get the data value
		dwVal = this->GetItemData(iCBSelection);

		// Convert value as needed
		switch(m_eType)
		{
		case String:
		case LPString:
			*pdwCode = _ttol(m_csSelectedCode);
			break;
		case Int:
		case Long:
		case Double:
			*pdwCode = dwVal;
			break;
		}	// End of conversion

		bRtrn = TRUE;
	}	// End of current selection validation

	return bRtrn;
}	// CTComboBox::GetCode(int iCBSelection, DWORD *pdwCode)

void CTComboBox::OnDestroy()
{
	CComboBox::OnDestroy();

	// Make sure to keep the selection in case the user
	// needs this information AFTER the dialog closes!
	GetSelectedText();
	GetSelectedCode(m_csSelectedCode);
	GetSelectedCode(&m_iSelectedCode);
	GetSelectedCode(&m_lSelectedCode);
	GetSelectedCode(&m_dwSelectedCode);

	// Check if pointer to array was allocated
	if (lptsArray != NULL)
	{
		LPTSTR
			lpStr;
		// Release memory as needed
		while (m_iBottom >= 0)
		{
			lpStr = lptsArray[m_iBottom];

			// Make sure pointer is valid
			if (lpStr != NULL)
			{
				delete [] lpStr;
				lptsArray[m_iBottom--] = NULL;
			}	// End of pointer validation
		}	// End of check if something has been added
		delete [] lptsArray;
		lptsArray = NULL;
	}	// End of check if pointer to array was allocated

	m_eType = CTComboBox::Unknown;
}	// CTComboBox::OnDestroy()

int CTComboBox::FindCode(int iStartAfter, LPCTSTR lpsCodeToFind)
{
	int
		iRtrn = CB_ERR,
		iItemCount = this->GetCount();

	ASSERT(iStartAfter <= iItemCount);

	// See if need to loop
	if (iItemCount > 0)
	{
		DWORD
			dwTmp;
		LPTSTR
			lpStr;
		int
			n;
		// Loop through all selections
		for (n = (iStartAfter == -1 ? 0 : iStartAfter); n < iItemCount; n++)
		{
			dwTmp = this->GetItemData(n);
			lpStr = (LPTSTR)dwTmp;

			// Check for match
			if (_tcsicmp(lpStr, lpsCodeToFind) == 0)
			{
				iRtrn = n;
				break;
			}	// End of check for match
		}	// End of loop through all selections

		// Set error condition up if necessary
		if (n >= iItemCount)
			iRtrn = CB_ERR;
	}	// End of check if need to perform loop

	return iRtrn;
}	// CTComboBox::FindCode(int iStartAfter, LPCTSTR lpsCodeToFind)

int CTComboBox::SelectCode(int iStartAfter, LPCTSTR lpsCodeToSearchFor)
{
	int
		iRtrn = FindCode(iStartAfter, lpsCodeToSearchFor);

	// Now select the item if we can
	if (iRtrn != CB_ERR)
		this->SetCurSel(iRtrn);

	return iRtrn;
}	// CTComboBox::SelectCode(int iStartAfter, LPCTSTR lpsCodeToSearchFor)
