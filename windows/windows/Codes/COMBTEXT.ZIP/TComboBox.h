// TComboBox.h : header file
//
// Author:	Christopher Conn
// Created:	07/22/98
//

// Make sure to include this file only once (at least until all of the other
// includes for this file are removed throughout the project)
#pragma once

/////////////////////////////////////////////////////////////////////////////
// CTComboBox window

#include <LIMITS.H>

class CTComboBox : public CComboBox
{
// Construction
public:
	CTComboBox();

	// Function used to add an entry into the combobox
	BOOL AddEntry(CString &rcsText, CString &rcsCode);
	BOOL AddEntry(CString &rcsText, LPCTSTR lpcsCode);
	BOOL AddEntry(CString &rcsText, int iCode);
	BOOL AddEntry(CString &rcsText, long lCode);
	BOOL AddEntry(CString &rcsText, DWORD dwCode);

	// Function used to find an entry based on the code
	// (similar to the CComboBox::FindString() function).
	int FindCode(int iStartAfter, LPCTSTR lpsCodeToFind);

	// Function used to pre-select an entry based on the code
	// (similar to the CComboBox::SelectString() function).
	int SelectCode(int iStartAfter, LPCTSTR lpsCodeToSearchFor);

	// Function used to retrieve the currently selected text
	// This function also performs string trimming on the returned text
	CString GetCurrentText();

	// Function used to get currently select text
	CString GetSelectedText();

	// Functions used to retrieve the selected code
	BOOL GetSelectedCode(CString &rcsCode);
	BOOL GetSelectedCode(int *piCode);
	BOOL GetSelectedCode(long *plCode);
	BOOL GetSelectedCode(DWORD *pdwCode);

	// Function used to retrieve the currently selected code
	BOOL GetCurrentCode(CString &rcsCode);
	BOOL GetCurrentCode(int *piCode);
	BOOL GetCurrentCode(long *plCode);
	BOOL GetCurrentCode(DWORD *pdwCode);

	// ******************************************************************
	// NOTE: The screen that this control is on must have a valid HWND
	//       (i.e. it must be active), in order to call these functions!

	// Function used to get the text of a specific selection
	CString GetText(int iCBSelection);

	// Function used to retrieve the selected code
	BOOL GetCode(int iCBSelection, CString &rcsCode);
	BOOL GetCode(int iCBSelection, int *piCode);
	BOOL GetCode(int iCBSelection, long *plCode);
	BOOL GetCode(int iCBSelection, DWORD *pdwCode);

	// ******************************************************************

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTComboBox)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTComboBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CTComboBox)
	afx_msg void OnDestroy();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

	// NOTE:	If this array is too large, an error will occur in CHKSTK.ASM.
	//			This array is allocated only when calling string based AddEntry(),
	//			(i.e. AddEntry(_T("Testing..."), _T("1")) <- the last entry is string based).
	LPTSTR			*lptsArray;
	int				m_iBottom;
	typedef enum {Unknown, String, LPString, Int, Long, Double} ComboBoxType;
	ComboBoxType	m_eType;
	CString			m_csSelectedText;
	CString			m_csSelectedCode;
	int				m_iSelectedCode;
	long			m_lSelectedCode;
	DWORD			m_dwSelectedCode;
};

/////////////////////////////////////////////////////////////////////////////
