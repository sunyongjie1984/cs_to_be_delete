// ttqDlg.h : header file
//

#if !defined(AFX_TTQDLG_H__4D163767_1E0C_443B_8086_E141126A6318__INCLUDED_)
#define AFX_TTQDLG_H__4D163767_1E0C_443B_8086_E141126A6318__INCLUDED_
#include "MySocket.h"
#include "Tzq.h"	// Added by ClassView
#include "newgame.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTtqDlg dialog

class CTtqDlg : public CWnd
{
// Construction
public:
	NewGame();//����Ϸ�ĶԻ���

	CTzq Tzq;//������������
	int itn,itnu,itnd;
	CTtqDlg(CWnd* pParent = NULL);	// standard constructor
	BOOL TM;
	int nqztempud;
	CPlace tempplace;//��ʱ����

	CMySocket m_sListenSocket;//��δ��
	CMySocket m_sConnectSocket;//��δ��
	CMySocket m_aConnectSocket[6];//��δ��
	CStringArray m_straEndName;//��δ��




// Dialog Data
	//{{AFX_DATA(CTtqDlg)

		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTtqDlg)
	protected:
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTtqDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TTQDLG_H__4D163767_1E0C_443B_8086_E141126A6318__INCLUDED_)
