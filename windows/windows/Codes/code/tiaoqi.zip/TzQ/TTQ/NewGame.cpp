// NewGame.cpp : implementation file
//

#include "stdafx.h"
#include "ttq.h"
#include "NewGame.h"
#include "aboutdialog.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewGame dialog


CNewGame::CNewGame(CWnd* pParent /*=NULL*/)
	: CDialog(CNewGame::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewGame)
	m_PlayName = _T("");
	m_Play1 = -1;
	m_Play2 = -1;
	m_Play3 = -1;
	m_Play4 = -1;
	m_Play5 = -1;
	m_Play6 = -1;
	m_PlayType = -1;
	m_PlayAdd = _T("");
	m_PlayBegin = 1;
	//}}AFX_DATA_INIT
}


void CNewGame::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewGame)
	DDX_Text(pDX, IDC_EDIT1, m_PlayName);
	DDV_MaxChars(pDX, m_PlayName, 20);
	DDX_Radio(pDX, IDC_RADIO1, m_Play1);
	DDX_Radio(pDX, IDC_RADIO2, m_Play2);
	DDX_Radio(pDX, IDC_RADIO9, m_Play3);
	DDX_Radio(pDX, IDC_RADIO13, m_Play4);
	DDX_Radio(pDX, IDC_RADIO17, m_Play5);
	DDX_Radio(pDX, IDC_RADIO21, m_Play6);
	DDX_Radio(pDX, IDC_RADIO26, m_PlayType);
	DDX_Text(pDX, IDC_EDIT2, m_PlayAdd);
	DDV_MaxChars(pDX, m_PlayAdd, 20);
	DDX_Text(pDX, IDC_EDIT3, m_PlayBegin);
	DDV_MinMaxUInt(pDX, m_PlayBegin, 1, 6);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewGame, CDialog)
	//{{AFX_MSG_MAP(CNewGame)
	ON_BN_CLICKED(IDC_RADIO26, OnPlayType)
	ON_BN_CLICKED(IDC_RADIO27, OnPlayTypec)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewGame message handlers

void CNewGame::OnPlayType() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_EDIT2)->EnableWindow(FALSE);

}

void CNewGame::OnPlayTypec() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_EDIT2)->EnableWindow(TRUE);

}

BOOL CNewGame::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
//	((CSliderCtrl *)GetDlgItem(IDC_SLIDER1))->SetRange(1,6);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CNewGame::OnAbout() 
{
	// TODO: Add your control notification handler code here
	CAboutDialog about;
	about.DoModal();
}
