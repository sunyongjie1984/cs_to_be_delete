// ttq.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "ttq.h"
#include "ttqDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern HBITMAP hBmp,hbmmp;

HRGN BitmapToRegion (HBITMAP hBmp, COLORREF cTransparentColor = 0, COLORREF cTolerance = 0x101010);
/////////////////////////////////////////////////////////////////////////////
// CTtqApp

BEGIN_MESSAGE_MAP(CTtqApp, CWinApp)
	//{{AFX_MSG_MAP(CTtqApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTtqApp construction

CTtqApp::CTtqApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTtqApp object

CTtqApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTtqApp initialization

BOOL CTtqApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.
	if (!AfxSocketInit())
	{
		AfxMessageBox(2);
		return FALSE;
	}
	CTtqDlg dlg;
	MSG msg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.CreateEx(0,
		AfxRegisterWndClass(0),"������",
		WS_POPUP|WS_SYSMENU,
		CRect(0,0,453,504),NULL,NULL,NULL);
	hBmp = (HBITMAP)LoadImage(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_BITMBK), IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION);
	hbmmp = (HBITMAP)LoadImage(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_BITMBK1), IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION);
	
	BITMAP bm;
	GetObject(hBmp, sizeof(bm), &bm);
	HRGN h = BitmapToRegion(hBmp);
	if (h)
		SetWindowRgn(m_pMainWnd->m_hWnd, h, TRUE);
	dlg.ShowWindow(SW_SHOW);
	dlg.UpdateWindow();
	
	while(GetMessage(&msg,(HWND)NULL,0,0)){
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	
	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
