#if !defined(AFX_NEWGAME_H__98398EA0_344E_11D5_8041_444553540000__INCLUDED_)
#define AFX_NEWGAME_H__98398EA0_344E_11D5_8041_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NewGame.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNewGame dialog

class CNewGame : public CDialog
{
// Construction
public:
	CNewGame(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNewGame)
	enum { IDD = IDD_TTQ_DIALOG };
	CString	m_PlayName;
	int		m_Play1;
	int		m_Play2;
	int		m_Play3;
	int		m_Play4;
	int		m_Play5;
	int		m_Play6;
	int		m_PlayType;
	CString	m_PlayAdd;
	UINT	m_PlayBegin;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewGame)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewGame)
	afx_msg void OnPlayType();
	afx_msg void OnPlayTypec();
	virtual BOOL OnInitDialog();
	afx_msg void OnAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEWGAME_H__98398EA0_344E_11D5_8041_444553540000__INCLUDED_)
