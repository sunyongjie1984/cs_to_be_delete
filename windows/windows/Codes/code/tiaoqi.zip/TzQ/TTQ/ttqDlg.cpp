// ttqDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ttq.h"
#include "ttqDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern HBITMAP hBmp,hbmmp;
/////////////////////////////////////////////////////////////////////////////
// CTtqDlg dialog

CTtqDlg::CTtqDlg(CWnd* pParent /*=NULL*/)

{
	//{{AFX_DATA_INIT(CTtqDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	itn=0;	itnu=0;	itnd=0;
	Tzq.m_cwnd=this;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

}



BEGIN_MESSAGE_MAP(CTtqDlg, CWnd)
	//{{AFX_MSG_MAP(CTtqDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTtqDlg message handlers

BOOL CTtqDlg::OnInitDialog()
{


	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTtqDlg::OnPaint() 
{

	CPaintDC dc(this); // device context for painting

	HCURSOR hcur;
	hcur=LoadCursor(
		
		AfxGetInstanceHandle(),  // handle to application instance
		
		MAKEINTRESOURCE(IDC_CURSOR4) // name string or cursor resource identifier
		
		);
	
	SetCursor(hcur);
	//	if (hBmp)
	
	//	{
				
	
	BITMAP bm;
	
	
				
	GetObject(hBmp, sizeof(bm), &bm);
	
	HDC memdc = CreateCompatibleDC(NULL);
	HBITMAP h = (HBITMAP)SelectObject(memdc, hbmmp);
				BitBlt( dc.m_hDC,0, 0, bm.bmWidth, bm.bmHeight, memdc, 0, 0, SRCCOPY);
				SelectObject(memdc, h);



				
				
				//	SelectObject(memdc, h);
	CBitmap bitmapbk,bitmap[6],bitmapb,bitmapc;
	CDC dcmemb,dcmem[6],dcmembk,dcmemc;
	bitmap[1].LoadBitmap(IDB_BITMAP2);
	bitmap[2].LoadBitmap(IDB_BITMAP4);
	bitmap[3].LoadBitmap(IDB_BITMAP5);
	bitmap[4].LoadBitmap(IDB_BITMAP6);
	bitmap[5].LoadBitmap(IDB_BITMAP3);
	bitmap[0].LoadBitmap(IDB_BITMAP1);
	bitmapbk.LoadBitmap(IDB_BITMAP12);
	bitmapb.LoadBitmap(IDB_BITMAP8);
	bitmapc.LoadBitmap(IDB_BITMAP10);
				
	dcmem[1].CreateCompatibleDC(&dc);
	dcmem[2].CreateCompatibleDC(&dc);
	dcmem[3].CreateCompatibleDC(&dc);

	dcmem[4].CreateCompatibleDC(&dc);
	dcmem[5].CreateCompatibleDC(&dc);
	dcmem[0].CreateCompatibleDC(&dc);
	dcmemb.CreateCompatibleDC(&dc);
	dcmemc.CreateCompatibleDC(&dc);
	dcmembk.CreateCompatibleDC(&dc);		
				
	dcmem[1].SelectObject(&bitmap[1]);
	dcmem[2].SelectObject(&bitmap[2]);
	dcmem[3].SelectObject(&bitmap[3]);
				
	dcmem[4].SelectObject(&bitmap[4]);
	dcmem[5].SelectObject(&bitmap[5]);
	dcmem[0].SelectObject(&bitmap[0]);
	dcmembk.SelectObject(&bitmapbk);
				
	dcmemb.SelectObject(&bitmapb);
	dcmemc.SelectObject(&bitmapc);

	for(int i=0;i<6;i++)
		for(int j=0;j<10;j++)
		{
			if(Tzq.nPlayType[i]!=0)
			if(Tzq.aPlace[i][j].pTzq->nColor!=0)
			{
				if(Tzq.aPlace[i][j].nTestUD==0){
					dc.BitBlt(
						Tzq.aPlace[i][j].pTzq->n_x-10,
						Tzq.aPlace[i][j].pTzq->n_y-10,
						21,21,&dcmembk,0,0,SRCAND);
					
					dc.BitBlt(
						Tzq.aPlace[i][j].pTzq->n_x-10,
						Tzq.aPlace[i][j].pTzq->n_y-10,
						21,21,&dcmem[i],0,0,SRCPAINT);
				}
				else{
					dc.BitBlt(
						Tzq.aPlace[i][j].pTzq->n_x-6,
						Tzq.aPlace[i][j].pTzq->n_y-4,
						21,21,&dcmemb,0,0,SRCAND);
					
					dc.BitBlt(	
						Tzq.aPlace[i][j].pTzq->n_x-6,
						Tzq.aPlace[i][j].pTzq->n_y-4,
						21,21,
						&dcmemc,0,0,SRCPAINT);
					
					dc.BitBlt(
						Tzq.aPlace[i][j].pTzq->n_x-13,
						Tzq.aPlace[i][j].pTzq->n_y-13,
						21,21,&dcmembk,0,0,SRCAND);
					
					dc.BitBlt(	
						Tzq.aPlace[i][j].pTzq->n_x-13,
						Tzq.aPlace[i][j].pTzq->n_y-13,
						21,21,&dcmem[i],0,0,SRCPAINT);
					
				}
			}
		}

		if(Tzq.nPlayType[Tzq.nPlaySyst]!=0)
		{
			dc.BitBlt(
				390-6,
				56-4,
				21,21,&dcmemb,0,0,SRCAND);
			
			dc.BitBlt(	
				390-6,
				56-4,
				21,21,
				&dcmemc,0,0,SRCPAINT);
			
			dc.BitBlt(
				390-13,
				56-13,
				21,21,&dcmembk,0,0,SRCAND);
			
			dc.BitBlt(	
				390-13,
				56-13,
				21,21,&dcmem[Tzq.nPlaySyst],0,0,SRCPAINT);
			
		}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTtqDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

LRESULT CTtqDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	switch (message) 
	{		case WM_NCHITTEST:
	//		hdc = BeginPaint (hWnd, &ps);
	
	RECT yj1;
	
	::GetWindowRect(this->m_hWnd,&yj1);
	//		CRect yj22;
	POINTS yj2=(POINTS)MAKEPOINTS(lParam);
	//		EndPaint (hWnd, &ps);
	if(yj2.x>yj1.left+230&&yj2.x<yj1.left+419&&yj2.y>yj1.top&&yj2.y<yj1.top+20)
		
		return HTCAPTION;
	return HTCLIENT;
	case WM_KEYDOWN:
		if (wParam != VK_ESCAPE)
			break;
	case WM_DESTROY:
		if(this->MessageBox("�����Ҫ�˳���Ϸ��?","������",MB_OKCANCEL|MB_ICONQUESTION )==IDOK)
			PostQuitMessage(0);
		break;
	default:
		return CWnd::WindowProc(message, wParam, lParam);
	}
	return CWnd::WindowProc(message, wParam, lParam);
}

void CTtqDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
//����Ϸ��Ŧ����
	CClientDC pDC(this);
	CRect yj(301,32,360,52);
	if(itnd==0)
		if(itn==0){
			if(yj.PtInRect(point))
			{
				pDC.SelectStockObject(WHITE_PEN ) ; 
				pDC.MoveTo(360,33);
				pDC.LineTo(301,33);
				pDC.LineTo(301,52);
				pDC.SelectStockObject(BLACK_PEN);
				pDC.LineTo(360,52);
				pDC.LineTo(360,32);
				
				itn=1;
			}
			
		}
		else{
			if(yj.PtInRect(point))
			{
			}
			else{
				
				InvalidateRect(CRect(295,30,370,60),0);
				itn=0;
			}
		}
		
		//	MoveWindow(point.x,point.y,453,504,TRUE);
	CWnd::OnMouseMove(nFlags, point);
}

void CTtqDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	//����Ϸ��Ŧ����
	CClientDC pDC(this);
	CRect yj(301,32,360,52);
	if(itnd==0){
		if(yj.PtInRect(point))
		{
			pDC.SelectStockObject(BLACK_PEN);
			
			pDC.MoveTo(360,33);
			pDC.LineTo(301,33);
			pDC.LineTo(301,52);
			
			pDC.SelectStockObject(WHITE_PEN ) ;
			pDC.LineTo(360,52);
			pDC.LineTo(360,32);
			
			itnd=1;
			SetCapture();
		}
		
	}
//�ж��Ƿ����˳���Ϸ
	CRect rclose(420,0,437,19);
	if(rclose.PtInRect(point))
	{
		if(this->MessageBox("�����Ҫ�˳���Ϸ��?","������",MB_OKCANCEL|MB_ICONQUESTION )==IDOK)
			PostQuitMessage(0);
	}
//�ж��Ƿ�������
	CRect rgn;
	if(Tzq.nPlayType[Tzq.nPlaySyst]==1)
	{
		if(this->nqztempud==0||tempplace.pTzq==Tzq.pPlace->pTzq)
		{
			for(int i=0;i<10;i++)
			{
				rgn=CRect(
					Tzq.aPlace[Tzq.nPlaySyst][i].pTzq->n_x-9,
					Tzq.aPlace[Tzq.nPlaySyst][i].pTzq->n_y-9,
					Tzq.aPlace[Tzq.nPlaySyst][i].pTzq->n_x+9,
					Tzq.aPlace[Tzq.nPlaySyst][i].pTzq->n_y+9);
				
				if(rgn.PtInRect(point))
				{ 
					if(Tzq.pPlace!=NULL){
						Tzq.pPlace->nTestUD=0;
						this->InvalidateRect(
							CRect(
							Tzq.pPlace->pTzq->n_x-15,
							Tzq.pPlace->pTzq->n_y-15,
							Tzq.pPlace->pTzq->n_x+17,
							Tzq.pPlace->pTzq->n_y+17),0);
					}
					Tzq.pPlace=&Tzq.aPlace[Tzq.nPlaySyst][i];
					this->tempplace.pTzq=Tzq.pPlace->pTzq;
					TM=TRUE;
					Tzq.pPlace->nTestUD=1;
					this->InvalidateRect(
						CRect(
						Tzq.pPlace->pTzq->n_x-15,
						Tzq.pPlace->pTzq->n_y-15,
						Tzq.pPlace->pTzq->n_x+17,
						Tzq.pPlace->pTzq->n_y+17),0);
					
					
				}
			}
			if(Tzq.pPlace==NULL)
				return;
			this->nqztempud=1;
		}	
		if(this->nqztempud!=0)
		{
			BOOL TempYn=FALSE;
			int tempQZ=Tzq.qzsetel(point);
			if(Tzq.aTzqFull[tempQZ].nColor==0)
				for(int it=0;it<6;it++)
				{
					TempYn=Tzq.StepPath(Tzq.pPlace,&Tzq.aTzqFull[tempQZ],it);
					if(TempYn==TRUE)
						break;
				}
			
//ˢ����
				if(TempYn==TRUE)
				{
					Tzq.pPlace->pTzq->nColor=0;
								
					this->InvalidateRect(
						CRect(
						Tzq.pPlace->pTzq->n_x-15,
						Tzq.pPlace->pTzq->n_y-15,
						Tzq.pPlace->pTzq->n_x+17,
						Tzq.pPlace->pTzq->n_y+17),0);

					Tzq.pPlace->pTzq=&Tzq.aTzqFull[tempQZ];
					Tzq.pPlace->pTzq->nColor=Tzq.nPlaySyst+1;
					this->InvalidateRect(
						CRect(
						Tzq.pPlace->pTzq->n_x-15,
						Tzq.pPlace->pTzq->n_y-15,
						Tzq.pPlace->pTzq->n_x+17,
						Tzq.pPlace->pTzq->n_y+17),0);
				}




		//	if(Tzq.pPlace->pTzq




		}
			
			
			
			
			



		
		
		
		
		
	}







	CWnd::OnLButtonDown(nFlags, point);
}

void CTtqDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
//����Ϸȷ��
	CRect yj(301,32,360,52);
	
	
	if(itnd==1){
		
		
		InvalidateRect(CRect(295,30,370,60),0);
		itnd=0;	
		if(yj.PtInRect(point))
		{
			
			NewGame();
			Invalidate(0);
		}
		ReleaseCapture();
	}
	CWnd::OnLButtonUp(nFlags, point);
}

void CTtqDlg::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
//����ȷ��	
	CRect rgn;
	BOOL bpbb;
	int sss;
	sss=0;
	bpbb=0;
	if(Tzq.pPlace==NULL)
		return;
	for(int i=0;i<Tzq.pPlace->nPlaceArray.GetSize();i++){
		
		
		rgn= CRect(
			Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]].n_x-9,
			Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]].n_y-9,
			Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]].n_x+9,
			Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]].n_y+9);
		
		if(rgn.PtInRect(point))
		{
			if((Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]].nArea==(Tzq.nPlaySyst+1))
				||(Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]].nArea==0)
				||(Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]].nArea==((Tzq.nPlaySyst+3>=6)?(Tzq.nPlaySyst-3):(Tzq.nPlaySyst+3))+1))
			{ 
				Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]].nColor=Tzq.nPlaySyst+1;;//Tzq.pPlace->pTzq->nColor;
				if(Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]].nQz!=Tzq.pPlace->pTzq->nQz)
					Tzq.pPlace->pTzq->nColor=0;
				this->InvalidateRect(
					CRect(
					Tzq.pPlace->pTzq->n_x-15,
					Tzq.pPlace->pTzq->n_y-15,
					Tzq.pPlace->pTzq->n_x+17,
					Tzq.pPlace->pTzq->n_y+17),0);
				
				Tzq.pPlace->pTzq=&Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]];
				
				TM=0;
				Tzq.pPlace->nTestUD=0;
				
				this->InvalidateRect(
					CRect(
					Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]].n_x-15,
					Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]].n_y-15,
					Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]].n_x+17,
					Tzq.aTzqFull[Tzq.pPlace->nPlaceArray[i]].n_y+17),0);	
				bpbb=TRUE ;
				sss=1;
				break;
			}
			
		}
	}
	
	if((Tzq.pPlace->pTzq->nArea==(Tzq.nPlaySyst+1))
		||(Tzq.pPlace->pTzq->nArea==0)
		||(Tzq.pPlace->pTzq->nArea==((Tzq.nPlaySyst+3>=6)?(Tzq.nPlaySyst-3):(Tzq.nPlaySyst+3))+1))
		if(Tzq.pPlace->pTzq!=this->tempplace.pTzq)
		{
			bpbb=TRUE ;
			sss=1;
			Tzq.pPlace->nTestUD=0;
			
			this->InvalidateRect(
				CRect(
				Tzq.pPlace->pTzq->n_x-15,
				Tzq.pPlace->pTzq->n_y-15,
				Tzq.pPlace->pTzq->n_x+17,
				Tzq.pPlace->pTzq->n_y+17),0);
			this->tempplace.pTzq=NULL;
			
		}
		
		
		if(sss==1)
		{
		if(bpbb)
			Tzq.pPlace=NULL;

	int ffff=1,fff1=1;
	int tend;
	tend=Tzq.nPlaySyst+3;
	if(tend>5)
		tend=Tzq.nPlaySyst-3;
	for(int abqq=0;abqq<10;abqq++)
	{
		if(Tzq.aPlace[Tzq.nPlaySyst][abqq].pTzq->nArea!=tend+1)
			ffff=0;
	}
	if(ffff==1){
		CString yj;
		yj.Format("!!!���%d",Tzq.nPlaySyst+1);
		yj+="����!!!";
		MessageBox(yj,"������");
		//		newgame();
		//		this->Invalidate(0);
		Tzq.nPlayType[Tzq.nPlaySyst]=0;
	}

		int nti=0;
		for(int t=0;t<6;t++)
		{
			nti+=Tzq.nPlayType[t];
		}
		if(nti==0)
			return;

		for(Tzq.qzc=0;Tzq.qzc<6;Tzq.qzc++)
			Tzq.ChessFull();
		this->nqztempud=0;
		sss=0;
		Tzq.nPlaySyst++;
		Tzq.nPlaySyst%=6;
		while(Tzq.nPlayType[Tzq.nPlaySyst]==0)
		{
			Tzq.nPlaySyst++;
		
			Tzq.nPlaySyst%=6;
		}
		Tzq.GameStep();

	}










	CWnd::OnRButtonDown(nFlags, point);
}

CTtqDlg::NewGame()
{
	m_straEndName.RemoveAll();
	this->nqztempud=0;
	CNewGame newgame;
	TM=0;
	Tzq.nPlaySyst=0;
	newgame.m_Play1=1;
	newgame.m_Play2=0;
	newgame.m_Play3=0;
	newgame.m_Play4=2;
	newgame.m_Play5=0;
	newgame.m_Play6=0;
	newgame.m_PlayType=0;
	newgame.m_PlayName="�����";
	newgame.m_PlayAdd="";

	int nResponse = newgame.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK


		Tzq.NewGame();
		Tzq.nPlayType[0]=newgame.m_Play1;
		Tzq.nPlayType[1]=newgame.m_Play2;
		Tzq.nPlayType[2]=newgame.m_Play3;
		Tzq.nPlayType[3]=newgame.m_Play4;
		Tzq.nPlayType[4]=newgame.m_Play5;
		Tzq.nPlayType[5]=newgame.m_Play6;
		Tzq.SetTF_nColor();
		this->Invalidate(1);
		int tzplay=6;
		for(Tzq.qzc=0;Tzq.qzc<6;Tzq.qzc++)
			Tzq.ChessFull();
		while(!Tzq.nPlayType[newgame.m_PlayBegin-1])
		{
			newgame.m_PlayBegin++;
			if(newgame.m_PlayBegin>6)
				newgame.m_PlayBegin=1;
			tzplay--;
			if(tzplay==0)break;
			
		}	
			
		Tzq.nPlaySyst=newgame.m_PlayBegin-1;

		if(Tzq.nPlaySyst>=0&&Tzq.nPlaySyst<=5)
			if(Tzq.nPlayType[Tzq.nPlaySyst]!=0)
			{
				Tzq.BeginGame=TRUE;

				Tzq.GameStep();
			}
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}


}
