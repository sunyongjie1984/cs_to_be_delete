// Tzq.cpp: implementation of the CTzq class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ttq.h"
#include "Tzq.h"
#include "stdio.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTzq::CTzq()
{
	nPlaySyst=0;
	pPlace=NULL;
	BeginGame=FALSE;
//	memset(aPlace,0,sizeof(aPlace));
	for(int i=0;i<6;i++){
		for(int j=0;j<10;j++)
		{
			aPlace[i][j].pTzq=NULL;
			aPlace[i][j].nTestUD=0;
		}
		nPlayType[i]=0;
//		nPlayYN[6]=FALSE;
	}
	memset(aTzqFull,0,sizeof(aTzqFull));
	srand( (unsigned)time( NULL ) );
	SetTF_nQz();			//��ʼ��aTzqFull���� nQz;
	SetTF_nxy();			//��ʼ��aTzqFull���� n_x,n_y;
	SetTF_pTzq();			//��ʼ��aTzqFull���� pTzq
	SetTF_nPRI();			//��ʼ��aTzqFull���� nPRI;

	SetPlace();             //��ʼ��aPlace����;

	SetTF_nArea();			//��ʼ��aTzqFull���� nArea;


	SetTF_nColor();			//��ʼ��aTzqFull���� nColor;
	for(qzc=0;qzc<6;qzc++)
		ChessFull();
	
}

CTzq::SetTF_nxy()
{
	int temp1[18]={1,2,4,7,11,24,36,47,57,66,76,87,99,112,116,119,121,122};
	int temp2[18]={0,220,204,188,172,28,44,60,76,92,76,
		60,44,28,172,188,204,220};
	int tab,tae=1;
	int tyt=30,txt;
	//	int ttt1;
	for(int tj=1;tj<18;tj++){
		tab=tae;
		tae=temp1[tj];
		txt=temp2[tj];
		//	ttt1=0;
		for(int tj1=tab;tj1<tae;tj1++)
		{
			//	ttt1++;
			this->aTzqFull[tj1].n_x=txt;
			this->aTzqFull[tj1].n_y=tyt;
			txt=txt+32;
		}
		tyt=(int)(tj*27.5)+30;
	}
	
}


CTzq::SetTF_nArea()
{
	
	for(int i=0;i<6;i++)
	{
		for(int i1=0;i1<10;i1++)
			this->aPlace[i][i1].pTzq->nArea=i+1;
	}

}

CTzq::SetTF_nColor()
{
	for(int i=0;i<6;i++)
	{
		if(nPlayType[i]!=0)
		for(int i1=0;i1<10;i1++)
			this->aPlace[i][i1].pTzq->nColor=i+1;
	}

}

CTzq::SetTF_nPRI()
{
	
	TzqDate *pTzqDate;
	TzqDate *pTzqTemp;
	int ntemp[6]={1,11,99,121,111,23};
	for(int i=0;i<3;i++){
		pTzqDate=&aTzqFull[ntemp[i]];
		for(int ni=1;ni<14;ni++)
		{
			pTzqTemp=pTzqDate;
			pTzqTemp->nPRI[i]=ni;
			pTzqTemp->nPRI[i+3]=18-ni;
			while(pTzqTemp->pTzq[i+2])
			{
				pTzqTemp=pTzqTemp->pTzq[i+2];
				pTzqTemp->nPRI[i]=ni;
				pTzqTemp->nPRI[i+3]=18-ni;
			}	
			pTzqTemp=pTzqDate;
			pTzqTemp->nPRI[i]=ni;
			pTzqTemp->nPRI[i+3]=18-ni;
			while(pTzqTemp->pTzq[(i+5)%6])
			{
				pTzqTemp=pTzqTemp->pTzq[(i+5)%6];
				pTzqTemp->nPRI[i]=ni;
				pTzqTemp->nPRI[i+3]=18-ni;
			}
			pTzqDate=pTzqDate->pTzq[i+3];
		}
		pTzqDate=&aTzqFull[ntemp[i+3]];
		
		for(ni=1;ni<14;ni++)
		{
			pTzqTemp=pTzqDate;
			pTzqTemp->nPRI[i+3]=ni;
			pTzqTemp->nPRI[i]=18-ni;
			while(pTzqTemp->pTzq[i+2])
			{
				pTzqTemp=pTzqTemp->pTzq[i+2];
				pTzqTemp->nPRI[i+3]=ni;
				pTzqTemp->nPRI[i]=18-ni;
			}
			pTzqTemp=pTzqDate;
			pTzqTemp->nPRI[i+3]=ni;
			pTzqTemp->nPRI[i]=18-ni;
			while(pTzqTemp->pTzq[(i+5)%6])
			{
				pTzqTemp=pTzqTemp->pTzq[(i+5)%6];
				pTzqTemp->nPRI[i+3]=ni;
				pTzqTemp->nPRI[i]=18-ni;
			}			
			pTzqDate=pTzqDate->pTzq[i];
		}
	}
	
	
}

CTzq::SetTF_nQz()
{
	for(int i=0;i<122;i++)
		aTzqFull[i].nQz=i;
}

CTzq::SetTF_pTzq()
{
	int temp[6][121]={                      
		0,                     
			1, 0,                   
			2,  3,  0,                  
			4,  5,  6,  0, 
			0,  0,  0,  0,  7,  8,  9, 10,  0,  0,  0,  0,  0,
			12,13,14,15,16,17,18,19,20,21,22,23,
			25,26,27,28,29,30,31,32,33,34,35,
			37,38,39,40,41,42,43,44,45,46,
			48,49,50,51,52,53,54,55,56,
			57,58,59,60,61,62,63,64,65,0,
			66,67,68,69,70,71,72,73,74,75,0,
			76,77,78,79,80,81,82,83,84,85,86,0,
			87,88,89,90,91,92,93,94,95,96,97,98,0,
			104,105,106,107,
			113,114,115,
			117,118,
			120
			
			,0,
			0,1,
			0,2,3,
			0,4,5,6,
			0,0,0,0,0,7,8,9,10,0,0,0,0,
			11,12,13,14,15,16,17,18,19,20,21,22,
			24,25,26,27,28,29,30,31,32,33,34,
			36,37,38,39,40,41,42,43,44,45,
			47,48,49,50,51,52,53,54,55,
			0,57,58,59,60,61,62,63,64,65,
			0,66,67,68,69,70,71,72,73,74,75,
			0,76,77,78,79,80,81,82,83,84,85,86,
			0,87,88,89,90,91,92,93,94,95,96,97,98,
			103,104,105,106,
			112,113,114,
			116,117,
			119
			
			,
			0,
			0,2,
			0,4,5,
			0,7,8,9,
			0,11,12,13,14,15,16,17,18,19,20,21,22,
			0,24,25,26,27,28,29,30,31,32,33,34,
			0,36,37,38,39,40,41,42,43,44,45,
			0,47,48,49,50,51,52,53,54,55,
			0,57,58,59,60,61,62,63,64,
			0,66,67,68,69,70,71,72,73,74,
			0,76,77,78,79,80,81,82,83,84,85,
			0,87,88,89,90,91,92,93,94,95,96,97,
			0,99,100,101,102,103,104,105,106,107,108,109,110,
			0,112,113,114,
			0,116,117,
			0,119,
			0
			,
			2,
			4,5,
			7,8,9,
			15,16,17,18,
			0,24,25,26,27,28,29,30,31,32,33,34,35,
			0,36,37,38,39,40,41,42,43,44,45,46,
			0,47,48,49,50,51,52,53,54,55,56,
			0,57,58,59,60,61,62,63,64,65,
			66,67,68,69,70,71,72,73,74,
			76,77,78,79,80,81,82,83,84,85,
			87,88,89,90,91,92,93,94,95,96,97,
			99,100,101,102,103,104,105,106,107,108,109,110,
			0,0,0,0,0,112,113,114,115,0,0,0,0,
			0,116,117,118,
			0,119,120,
			0,121,
			0
			,
			3,
			5,6,
			8,9,10,
			16,17,18,19,
			24,25,26,27,28,29,30,31,32,33,34,35,0,
			36,37,38,39,40,41,42,43,44,45,46,0,
			47,48,49,50,51,52,53,54,55,56,0,
			57,58,59,60,61,62,63,64,65,0,
			67,68,69,70,71,72,73,74,75,
			77,78,79,80,81,82,83,84,85,86,
			88,89,90,91,92,93,94,95,96,97,98,
			100,101,102,103,104,105,106,107,108,109,110,111,
			0,0,0,0,112,113,114,115,0,0,0,0,0,
			116,117,118,0,
			119,120,0,
			121,0,
			0
			,
			0,
			3,0,
			5,6,0,
			8,9,10,0,
			12,13,14,15,16,17,18,19,20,21,22,23,0,
			25,26,27,28,29,30,31,32,33,34,35,0,
			37,38,39,40,41,42,43,44,45,46,0,
			48,49,50,51,52,53,54,55,56,0,
			58,59,60,61,62,63,64,65,0,
			67,68,69,70,71,72,73,74,75,0,
			77,78,79,80,81,82,83,84,85,86,0,
			88,89,90,91,92,93,94,95,96,97,98,0,
			100,101,102,103,104,105,106,107,108,109,110,111,0,
			113,114,115,0,
			117,118,0,
			120,0,
			0};
			
			
			
			
			for(int tttr=1;tttr<122;tttr++){
				
				for(int zz3=0;zz3<6;zz3++)
				{	if(temp[zz3][tttr-1])
				this->aTzqFull[tttr].pTzq[zz3]=&aTzqFull[temp[zz3][tttr-1]];
				
				}
			}
			
			
			
}

CTzq::SetPlace()
{
	
	
	int aset[6][10]={
			1,2,3,4,5,6,7,8,9,10,
			
			11,12,13,14,24,25,26,36,37,47,
			
			66,76,77,87,88,89,99,100,101,102,
			
			112,113,114,115,116,117,118,119,120,121,
			
			75,85,86,96,97,98,108,109,110,111,
			
			20,21,22,23,33,34,35,45,46,56
			
		};
	
	for(int aseti=0;aseti<10;aseti++)
	{
		for(int aseti1=0;aseti1<6;aseti1++)
			aPlace[aseti1][aseti].pTzq=&aTzqFull[aset[aseti1][aseti]];
	}
	





}


CTzq::~CTzq()
{

}
HBITMAP hBmp,hbmmp;
HRGN BitmapToRegion (HBITMAP hBmp, COLORREF cTransparentColor = 0, COLORREF cTolerance = 0x101010)
{
	HRGN hRgn = NULL;
	
	if (hBmp)
	{
		// Create a memory DC inside which we will scan the bitmap content
		HDC hMemDC = CreateCompatibleDC(NULL);
		if (hMemDC)
		{
			// Get bitmap size
			BITMAP bm;
			GetObject(hBmp, sizeof(bm), &bm);
			
			// Create a 32 bits depth bitmap and select it into the memory DC 
			BITMAPINFOHEADER RGB32BITSBITMAPINFO = {	
				sizeof(BITMAPINFOHEADER),	// biSize 
					bm.bmWidth,					// biWidth; 
					bm.bmHeight,				// biHeight; 
					1,							// biPlanes; 
					32,							// biBitCount 
					BI_RGB,						// biCompression; 
					0,							// biSizeImage; 
					0,							// biXPelsPerMeter; 
					0,							// biYPelsPerMeter; 
					0,							// biClrUsed; 
					0							// biClrImportant; 
			};
			VOID * pbits32; 
			HBITMAP hbm32 = CreateDIBSection(hMemDC, (BITMAPINFO *)&RGB32BITSBITMAPINFO, DIB_RGB_COLORS, &pbits32, NULL, 0);
			if (hbm32)
			{
				HBITMAP holdBmp = (HBITMAP)SelectObject(hMemDC, hbm32);
				
				// Create a DC just to copy the bitmap into the memory DC
				HDC hDC = CreateCompatibleDC(hMemDC);
				if (hDC)
				{
					// Get how many bytes per row we have for the bitmap bits (rounded up to 32 bits)
					BITMAP bm32;
					GetObject(hbm32, sizeof(bm32), &bm32);
					while (bm32.bmWidthBytes % 4)
						bm32.bmWidthBytes++;
					
					// Copy the bitmap into the memory DC
					HBITMAP holdBmp = (HBITMAP)SelectObject(hDC, hBmp);
					BitBlt(hMemDC, 0, 0, bm.bmWidth, bm.bmHeight, hDC, 0, 0, SRCCOPY);
					
					// For better performances, we will use the ExtCreateRegion() function to create the
					// region. This function take a RGNDATA structure on entry. We will add rectangles by
					// amount of ALLOC_UNIT number in this structure.
#define ALLOC_UNIT	100
					DWORD maxRects = ALLOC_UNIT;
					HANDLE hData = GlobalAlloc(GMEM_MOVEABLE, sizeof(RGNDATAHEADER) + (sizeof(RECT) * maxRects));
					RGNDATA *pData = (RGNDATA *)GlobalLock(hData);
					pData->rdh.dwSize = sizeof(RGNDATAHEADER);
					pData->rdh.iType = RDH_RECTANGLES;
					pData->rdh.nCount = pData->rdh.nRgnSize = 0;
					SetRect(&pData->rdh.rcBound, MAXLONG, MAXLONG, 0, 0);
					
					// Keep on hand highest and lowest values for the "transparent" pixels
					BYTE lr = GetRValue(cTransparentColor);
					BYTE lg = GetGValue(cTransparentColor);
					BYTE lb = GetBValue(cTransparentColor);
					BYTE hr = min(0xff, lr + GetRValue(cTolerance));
					BYTE hg = min(0xff, lg + GetGValue(cTolerance));
					BYTE hb = min(0xff, lb + GetBValue(cTolerance));
					
					// Scan each bitmap row from bottom to top (the bitmap is inverted vertically)
					BYTE *p32 = (BYTE *)bm32.bmBits + (bm32.bmHeight - 1) * bm32.bmWidthBytes;
					for (int y = 0; y < bm.bmHeight; y++)
					{
						// Scan each bitmap pixel from left to right
						for (int x = 0; x < bm.bmWidth; x++)
						{
							// Search for a continuous range of "non transparent pixels"
							int x0 = x;
							LONG *p = (LONG *)p32 + x;
							while (x < bm.bmWidth)
							{
								BYTE b = GetRValue(*p);
								if (b >= lr && b <= hr)
								{
									b = GetGValue(*p);
									if (b >= lg && b <= hg)
									{
										b = GetBValue(*p);
										if (b >= lb && b <= hb)
											// This pixel is "transparent"
											break;
									}
								}
								p++;
								x++;
							}
							
							if (x > x0)
							{
								// Add the pixels (x0, y) to (x, y+1) as a new rectangle in the region
								if (pData->rdh.nCount >= maxRects)
								{
									GlobalUnlock(hData);
									maxRects += ALLOC_UNIT;
									hData = GlobalReAlloc(hData, sizeof(RGNDATAHEADER) + (sizeof(RECT) * maxRects), GMEM_MOVEABLE);
									pData = (RGNDATA *)GlobalLock(hData);
								}
								RECT *pr = (RECT *)&pData->Buffer;
								SetRect(&pr[pData->rdh.nCount], x0, y, x, y+1);
								if (x0 < pData->rdh.rcBound.left)
									pData->rdh.rcBound.left = x0;
								if (y < pData->rdh.rcBound.top)
									pData->rdh.rcBound.top = y;
								if (x > pData->rdh.rcBound.right)
									pData->rdh.rcBound.right = x;
								if (y+1 > pData->rdh.rcBound.bottom)
									pData->rdh.rcBound.bottom = y+1;
								pData->rdh.nCount++;
								
								// On Windows98, ExtCreateRegion() may fail if the number of rectangles is too
								// large (ie: > 4000). Therefore, we have to create the region by multiple steps.
								if (pData->rdh.nCount == 2000)
								{
									HRGN h = ExtCreateRegion(NULL, sizeof(RGNDATAHEADER) + (sizeof(RECT) * maxRects), pData);
									if (hRgn)
									{
										CombineRgn(hRgn, hRgn, h, RGN_OR);
										DeleteObject(h);
									}
									else
										hRgn = h;
									pData->rdh.nCount = 0;
									SetRect(&pData->rdh.rcBound, MAXLONG, MAXLONG, 0, 0);
								}
							}
						}
						
						// Go to next row (remember, the bitmap is inverted vertically)
						p32 -= bm32.bmWidthBytes;
					}
					
					// Create or extend the region with the remaining rectangles
					HRGN h = ExtCreateRegion(NULL, sizeof(RGNDATAHEADER) + (sizeof(RECT) * maxRects), pData);
					if (hRgn)
					{
						CombineRgn(hRgn, hRgn, h, RGN_OR);
						DeleteObject(h);
					}
					else
						hRgn = h;
					
					// Clean up
					SelectObject(hDC, holdBmp);
					DeleteDC(hDC);
				}
				
				DeleteObject(SelectObject(hMemDC, holdBmp));
			}
			
			DeleteDC(hMemDC);
		}	
	}
	
	return hRgn;
}
CTzq::Chess(TzqDate *pTF)
{
	
	for(int i1=0;i1<6;i1++)
		ChessOdd(pTF,i1);
}


void CTzq::ChessOdd(TzqDate *pTF, int i1)
{
	int it,ht,ii;
	TzqDate *pb;
	pb=pTF;
	ii=0;
	it=0;
	ht=0;
	while(pb->pTzq[i1])
	{
		pb=pb->pTzq[i1];
		if(it==0)
		{
			if(pb->nColor==0)
				ii++;
			else 
				it=1;
		}
		else
		{
			if(ii==0)
			{
				if(pb->nColor==0)
				{
					Addpa(pb);
					return ;
					
				}
				else
					return ;
			}
			else
			{
				if(pb->nColor==0)
					ii--;
				else
					return ;
			}
		}
	}
	
	
}

void CTzq::Addpa(TzqDate *pTF)
{
	
	TzqDate *pb=pTF;
	int z=aPlace[qzc][qz].nPlaceArray.GetSize();
	for(int i=0;i<z;i++)
	{
		if(pb->nQz==aPlace[qzc][qz].nPlaceArray[i])
			return ;
	}
	aPlace[qzc][qz].nPlaceArray.Add(pb->nQz);
	Chess(pb);
	
	
	
	
}

CTzq::ChessFull()
{
	int j;

	for (qz=0;qz<10;qz++)
	{
		
		
		aPlace[qzc][qz].nPlaceArray.RemoveAll();
		
		
		j=aPlace[qzc][qz].pTzq->nColor;
		aPlace[qzc][qz].pTzq->nColor=0;
		
		aPlace[qzc][qz].nPlaceArray.Add(aPlace[qzc][qz].pTzq->nQz);
		this->Chess(aPlace[qzc][qz].pTzq);
		this->BsetSide(aPlace[qzc][qz].pTzq);

		CArray<int,int> yjj;
		for(int iz=1;iz<aPlace[qzc][qz].nPlaceArray.GetSize();iz++)
			yjj.Add(aPlace[qzc][qz].nPlaceArray[iz]);
		aPlace[qzc][qz].nPlaceArray.RemoveAll();
		for( iz=0;iz<yjj.GetSize();iz++)
			aPlace[qzc][qz].nPlaceArray.Add(yjj[iz]);
		aPlace[qzc][qz].pTzq->nColor=j;
	}


}
void CTzq::BsetSide(TzqDate *dp)
{
	
	for (int i=0;i<6;i++)
	{
		if(dp->pTzq[i]!=NULL)
			if(dp->pTzq[i]->nColor==0)
				aPlace[qzc][qz].nPlaceArray.Add(dp->pTzq[i]->nQz);
	}
}

void CTzq::NewGame()
{
	pPlace=NULL;
	BeginGame=FALSE;
	pPlace=NULL;
		for(int i=0;i<6;i++){
		for(int j=0;j<10;j++)
		{
			aPlace[i][j].pTzq=NULL;
			aPlace[i][j].nTestUD=0;
		}
		nPlayType[i]=0;
//		nPlayYN[6]=FALSE;
	}
	memset(aTzqFull,0,sizeof(aTzqFull));
	srand( (unsigned)time( NULL ) );
	SetTF_nQz();			//��ʼ��aTzqFull���� nQz;
	SetTF_nxy();			//��ʼ��aTzqFull���� n_x,n_y;
	SetTF_pTzq();			//��ʼ��aTzqFull���� pTzq
	SetTF_nPRI();			//��ʼ��aTzqFull���� nPRI;

	SetPlace();             //��ʼ��aPlace����;

	SetTF_nArea();			//��ʼ��aTzqFull���� nArea;


	SetTF_nColor();			//��ʼ��aTzqFull���� nColor;
	for(qzc=0;qzc<6;qzc++)
		ChessFull();
	
}

CTzq::GameStep()
{

	m_cwnd->InvalidateRect(CRect(375,40,405,70),FALSE);
	if(nPlayType[nPlaySyst]!=0)
		switch(nPlayType[nPlaySyst])
	{
		case 1:
			
			break;
		case 2:
			this->pcstep();
			break;
		case 3:
			this->NetStep();
			break;
		default:
			break;
	}

}

CTzq::pcstep()
{	
/*	int nfff=0;
	int ntend,ntt1,ntt2,ntt3,ntt4;
	int tempqzz;
	ntend=nPlaySyst+3;
	if(ntend>5)
		ntend=nPlaySyst-3;
	for(int nabqq=0;nabqq<10;nabqq++)
	{
		if(aPlace[nPlaySyst][nabqq].pTzq->nArea==ntend+1)
			nfff++;
		else
			tempqzz=nabqq;
	}
	if(nfff==9){
		CString yj;

		yj+="����!!!";
		m_cwnd->MessageBox(yj,"������");
	
	//	if(aPlace[nPlaySyst][tempqzz].pTzq->pTzq[ntend]
		ntt1=nPlaySyst+2;
		ntt2=nPlaySyst+3;
		ntt3=nPlaySyst+4;
		ntt4=nPlaySyst+5;
		ntt1%=6;
		ntt2%=6;
		ntt3%=6;
		ntt4%=6;
		TzqDate * tzqdatetemp=aPlace[nPlaySyst][tempqzz].pTzq;
		if(tzqdatetemp->pTzq[ntt2]!=NULL)
		{
			if((tzqdatetemp->pTzq[ntt2]->nArea==ntend+1)&&
				(tzqdatetemp->pTzq[ntt2]->nColor==0))
			{	
				TzqDate *temp;
				temp=aPlace[nPlaySyst][tempqzz].pTzq;
				aPlace[nPlaySyst][tempqzz].pTzq->nColor=0;
				aPlace[nPlaySyst][tempqzz].pTzq=tzqdatetemp->pTzq[ntt2];
				aPlace[nPlaySyst][tempqzz].pTzq->nColor=nPlaySyst+1;
				this->renovate(temp,aPlace[nPlaySyst][tempqzz].pTzq);
				return 0;
			}
		}
		if(tzqdatetemp->pTzq[ntt3]!=NULL)
		{
			if((tzqdatetemp->pTzq[ntt3]->nArea==ntend+1)&&
				(tzqdatetemp->pTzq[ntt3]->nColor==0))
			{
				TzqDate *temp;
				temp=aPlace[nPlaySyst][tempqzz].pTzq;
				aPlace[nPlaySyst][tempqzz].pTzq->nColor=0;
				aPlace[nPlaySyst][tempqzz].pTzq=tzqdatetemp->pTzq[ntt3];
				aPlace[nPlaySyst][tempqzz].pTzq->nColor=nPlaySyst+1;
				this->renovate(temp,aPlace[nPlaySyst][tempqzz].pTzq);

				return 0;
			}
		}
		while(tzqdatetemp->pTzq[ntt1]!=NULL)
		{
			tzqdatetemp=tzqdatetemp->pTzq[ntt1];
		//	if(tzqdatetemp->pTzq[ntt2]
		}
		tzqdatetemp=aPlace[nPlaySyst][tempqzz].pTzq;
		while(tzqdatetemp->pTzq[ntt1]!=NULL)
		{
			tzqdatetemp=tzqdatetemp->pTzq[ntt1];
		//	if(tzqdatetemp->pTzq[ntt2]
		}
	}
	*/
	int zzr,ttt,tt2,tt3;
	zzr=-10;
	ttt=0;
	tt2=0;
	tt3=0;
	int x,asd1;
	
	int zze;
	for(zze=0;zze<10;zze++)
	{
		
		for(asd1=0;asd1<aPlace[nPlaySyst][zze].nPlaceArray.GetSize();asd1++)
		{
			x=aPlace[nPlaySyst][zze].nPlaceArray[asd1];
			if(this->aTzqFull[x].nPRI[nPlaySyst]-aPlace[nPlaySyst][zze].pTzq->nPRI[nPlaySyst] >zzr)
			{
				//	if(ab[x].b[0]-abz[1][zze].a->b[0]==zzr
				//		&&ab[x].a
				if((aTzqFull[x].nArea==nPlaySyst+1)
					||(aTzqFull[x].nArea==0)
					||(aTzqFull[x].nArea==((nPlaySyst+3>=6)?(nPlaySyst-3):(nPlaySyst+3))+1))
					
				{
					ttt=zze;
					tt3=asd1;
					tt2=aPlace[nPlaySyst][zze].nPlaceArray[asd1];
					zzr=aTzqFull[aPlace[nPlaySyst][zze].nPlaceArray[asd1]].nPRI[nPlaySyst]-aPlace[nPlaySyst][zze].pTzq->nPRI[nPlaySyst];
				}
			}
			else
				if(aTzqFull[x].nPRI[nPlaySyst]-aPlace[nPlaySyst][zze].pTzq->nPRI[nPlaySyst]==zzr)
				{
					
					char crand=(char)rand();
					//	if(crand<0)
					//		MessageBox("fdslafk");
					if(crand>0)
					{
						//	if(abz[1][zze].a->a!=1)
						{
							
							if((aTzqFull[x].nArea==nPlaySyst+1)
								||(aTzqFull[x].nArea==0)
								||(aTzqFull[x].nArea==(((nPlaySyst+3>=6)?(nPlaySyst-3):(nPlaySyst+3))+1)))
							{
								ttt=zze;
								tt3=asd1;
								tt2=aPlace[nPlaySyst][zze].nPlaceArray[asd1];
								zzr=aTzqFull[aPlace[nPlaySyst][zze].nPlaceArray[asd1]].nPRI[nPlaySyst]-aPlace[nPlaySyst][zze].pTzq->nPRI[nPlaySyst];
								
							}
						}
					}
					
				}
		}
	}
	
	
	this->aTzqFull[this->aPlace[nPlaySyst][ttt].nPlaceArray[tt3]].nColor=aPlace[nPlaySyst][ttt].pTzq->nColor;
	aPlace[nPlaySyst][ttt].pTzq->nColor=0;
	m_cwnd->InvalidateRect(
		CRect(
		aTzqFull[this->aPlace[nPlaySyst][ttt].nPlaceArray[tt3]].n_x-15,
		aTzqFull[this->aPlace[nPlaySyst][ttt].nPlaceArray[tt3]].n_y-15,
		aTzqFull[this->aPlace[nPlaySyst][ttt].nPlaceArray[tt3]].n_x+17,
		aTzqFull[this->aPlace[nPlaySyst][ttt].nPlaceArray[tt3]].n_y+17),0);
	m_cwnd->InvalidateRect(
		CRect(
		aPlace[nPlaySyst][ttt].pTzq->n_x-15,
		aPlace[nPlaySyst][ttt].pTzq->n_y-15,
		aPlace[nPlaySyst][ttt].pTzq->n_x+17,
		aPlace[nPlaySyst][ttt].pTzq->n_y+17),0);	
	aPlace[nPlaySyst][ttt].pTzq=&aTzqFull[this->aPlace[nPlaySyst][ttt].nPlaceArray[tt3]];
	
	
	
	int ffff=1,fff1=1;
	int tend;
	tend=nPlaySyst+3;
	if(tend>5)
		tend=nPlaySyst-3;
	for(int abqq=0;abqq<10;abqq++)
	{
		if(aPlace[nPlaySyst][abqq].pTzq->nArea!=tend+1)
			ffff=0;
	}
	if(ffff==1){
		CString yj;
		yj.Format("!!!���%d",this->nPlaySyst+1);
		yj+="����!!!";
		m_cwnd->MessageBox(yj,"������");
		//		newgame();
		//		this->Invalidate(0);
		this->nPlayType[nPlaySyst]=0;
	}
			int nti=0;
		for(int t=0;t<6;t++)
		{
			nti+=nPlayType[t];
		}
		if(nti==0)
			return 0;
	for(qzc=0;qzc<6;qzc++)
		this->ChessFull();
	nPlaySyst++;
	nPlaySyst%=6;
	while(nPlayType[nPlaySyst]==0)
	{
		nPlaySyst++;
		
		nPlaySyst%=6;
	}


	GameStep();
	
	
	
	return 0;
}

CTzq::NetStep()
{

}

int CTzq::qzsetel(CPoint point)
{
	CRect rgn;
	for(int i=0;i<122;i++)
	{
		rgn=CRect(
			aTzqFull[i].n_x-9,
			aTzqFull[i].n_y-9,
			aTzqFull[i].n_x+9,
			aTzqFull[i].n_y+9);
		
		if(rgn.PtInRect(point))
		{ 
			return i;
		}
	}

	return 0;
}

BOOL CTzq::StepPath(CPlace *pplace, TzqDate *ptzq,int i1)
{
	int it,ht,ii;
	TzqDate *pb;
	pb=pplace->pTzq;
	ii=0;
	it=0;
	ht=0;
	while(pb->pTzq[i1])
	{
		pb=pb->pTzq[i1];
		if(it==0)
		{
			if(pb->nColor==0)
				ii++;
			else 
				it=1;
		}
		else
		{
			if(ii==0)
			{
				if(pb->nColor==0)
				{
				//	Addpa(pb);
					if(pb->nQz==ptzq->nQz)
						return TRUE;
					else 
						return FALSE;
					
				}
				else
					return FALSE;
			}
			else
			{
				if(pb->nColor==0)
					ii--;
				else
					return FALSE;
			}
		}
	}
	return FALSE;


}

CTzq::renovate(TzqDate * t1, TzqDate * t2)
{
	
	m_cwnd->InvalidateRect(
		CRect(
		t1->n_x-15,
		t1->n_y-15,
		t1->n_x+17,
		t1->n_y+17),0);
	m_cwnd->InvalidateRect(
		CRect(
		t2->n_x-15,
		t2->n_y-15,
		t2->n_x+17,
		t2->n_y+17),0);	

	
	
	
	int ffff=1,fff1=1;
	int tend;
	tend=nPlaySyst+3;
	if(tend>5)
		tend=nPlaySyst-3;
	for(int abqq=0;abqq<10;abqq++)
	{
		if(aPlace[nPlaySyst][abqq].pTzq->nArea!=tend+1)
			ffff=0;
	}
	if(ffff==1){
		CString yj;
		yj.Format("!!!���%d",this->nPlaySyst+1);
		yj+="����!!!";
		m_cwnd->MessageBox(yj,"������");
		//		newgame();
		//		this->Invalidate(0);
		this->nPlayType[nPlaySyst]=0;
	}
	
	for(qzc=0;qzc<6;qzc++)
		this->ChessFull();
	nPlaySyst++;
	nPlaySyst%=6;
	while(nPlayType[nPlaySyst]==0)
	{
		nPlaySyst++;
		
		nPlaySyst%=6;
	}


	GameStep();
}
