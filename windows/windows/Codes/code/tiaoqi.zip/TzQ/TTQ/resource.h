//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ttq.rc
//
#define IDS_STRING2                     2
#define IDD_TTQ_DIALOG                  102
#define IDR_MAINFRAME                   128
#define IDB_BITMBK                      130
#define IDB_BITMAP1                     143
#define IDB_BITMAP2                     144
#define IDB_BITMAP3                     145
#define IDB_BITMAP4                     146
#define IDB_BITMAP5                     147
#define IDB_BITMAP6                     148
#define IDB_BITMAP7                     149
#define IDB_BITMAP8                     150
#define IDC_CURSOR1                     151
#define IDB_BITMAP9                     152
#define IDB_BITMAP10                    153
#define IDB_BITMAP11                    154
#define IDC_CURSOR2                     155
#define IDC_CURSOR3                     156
#define IDC_CURSOR4                     157
#define IDB_BITMAP12                    158
#define IDB_BITMBK1                     160
#define IDD_DIALOG1                     161
#define IDI_ICON1                       163
#define IDC_RADIO1                      1001
#define IDC_RADIO2                      1002
#define IDC_RADIO3                      1003
#define IDC_RADIO4                      1004
#define IDC_RADIO5                      1005
#define IDC_RADIO6                      1006
#define IDC_RADIO7                      1007
#define IDC_RADIO8                      1008
#define IDC_RADIO9                      1009
#define IDC_RADIO10                     1010
#define IDC_RADIO11                     1011
#define IDC_RADIO12                     1012
#define IDC_RADIO13                     1013
#define IDC_RADIO14                     1014
#define IDC_RADIO15                     1015
#define IDC_RADIO16                     1016
#define IDC_RADIO17                     1017
#define IDC_RADIO18                     1018
#define IDC_RADIO19                     1019
#define IDC_RADIO20                     1020
#define IDC_RADIO21                     1021
#define IDC_RADIO22                     1022
#define IDC_RADIO23                     1023
#define IDC_RADIO24                     1024
#define IDC_STATIC1                     1025
#define IDC_STATIC2                     1026
#define IDC_STATIC3                     1027
#define IDC_STATIC4                     1028
#define IDC_STATIC5                     1029
#define IDC_STATIC6                     1030
#define IDC_RADIO26                     1032
#define IDC_RADIO27                     1033
#define IDC_EDIT1                       1034
#define IDC_EDIT2                       1036
#define IDC_EDIT3                       1042
#define IDC_ABOUT                       1043

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        164
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
