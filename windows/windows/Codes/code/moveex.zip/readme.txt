-----------------------------------------------------------------------------

MoveEx 1.0
schedules a file rename operation to be done at the next reboot
e.g. to replace files currently in use
more or less just a wrapper around the MoveFileEx() API

-----------------------------------------------------------------------------

This is a command line utility.
Type 'moveex' to see the following help text:

-----------------------------------------------------------------------------

Usage: moveex oldfile newfile

       Moves 'oldfile' to 'newfile' at next reboot.
       Useful to replace files currently in use.
       It works on Windows NT and local drives only!
       On NTFS, SYSTEM must be granted 'Full Control' to the files in question!
       There is no feedback (e.g. in the event log) stating error or success.

       Examples:
           moveex test.txt test2.txt
              renames test.txt in the current directory, overwrites test2.txt
           moveex test.txt c:\temp\test.txt
              moves test.txt from the current directory to c:\temp
           moveex test.txt c:\temp
              doesn't work, give the full path and file name for destination
           moveex c:\test.txt d:\test.txt
              doesn't work, you can't move across different drives

(C) 1998 by Alexander Frink (Alexander.Frink@Uni-Mainz.DE).
This is free software.

-----------------------------------------------------------------------------
