// WfTestDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWfTestDlg dialog
//{{AFX_INCLUDES()
#include "winfinder.h"
//}}AFX_INCLUDES

class CWfTestDlg : public CDialog
{
// Construction
public:
	CWfTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CWfTestDlg)
	enum { IDD = IDD_WFTEST_DIALOG };
	long	m_targetWindow;
	CWinFinder	m_wndFinder;
	CString	m_strCaption;
	CString	m_strClass;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWfTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CWfTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg LRESULT OnWfCallback(WPARAM wParam, LPARAM lParam);
	afx_msg void OnRetr();
	afx_msg void OnChangeCaption();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
