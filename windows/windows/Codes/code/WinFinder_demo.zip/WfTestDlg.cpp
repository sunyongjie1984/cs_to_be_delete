// WfTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WfTest.h"
#include "WfTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWfTestDlg dialog

extern CWfTestApp theApp;

// Obsolete
int WindowSelectedCallback(HWND hWnd)
{
	//CString str;

	//str.Format("%X", hWnd);
	//::SetWindowText(theApp.wndIndicator, str);

	return 0;
}

CWfTestDlg::CWfTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWfTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWfTestDlg)
	m_targetWindow = 0;
	m_strCaption = _T("");
	m_strClass = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CWfTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWfTestDlg)
	DDX_OCInt(pDX, IDC_WINFINDER, DISPID(2), m_targetWindow);
	DDX_Control(pDX, IDC_WINFINDER, m_wndFinder);
	DDX_Text(pDX, IDC_CAPTION, m_strCaption);
	DDX_Text(pDX, IDC_CLASS, m_strClass);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CWfTestDlg, CDialog)
	//{{AFX_MSG_MAP(CWfTestDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_MESSAGE(WM_WFCALLBACK, OnWfCallback)
	ON_EN_CHANGE(IDC_CAPTION, OnChangeCaption)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWfTestDlg message handlers

UINT MoniterWindowHandle(LPVOID);

#pragma pack(1)

typedef int(*WINFINDERCALLBACK)(HWND);

typedef struct
{
	WINFINDERCALLBACK pfn;
} *LPWINFINDERCALLBACKSTRUCT;

#pragma pack()

BOOL CWfTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	LPWINFINDERCALLBACKSTRUCT s;

#pragma warning(disable:4116)
	s = (struct*)new long;
#pragma warning(default:4116)

	s->pfn = WindowSelectedCallback;
	m_wndFinder.PostMessage(WM_USER + 100, 0, (long) s); 
	
	theApp.wndIndicator = GetDlgItem(IDC_HANDLE)->m_hWnd;

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CWfTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CWfTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// Window Finder callback - called when Window Finder selectio changes
LRESULT CWfTestDlg::OnWfCallback(WPARAM wParam, LPARAM lParam)
{
	CString str;

	str.Format("%X", lParam);
	GetDlgItem(IDC_HANDLE)->SetWindowText(str);

	// Get window text
	OnRetr();

	return 0;
}

// Retreive window text and classname, place in edit field
void CWfTestDlg::OnRetr() 
{
	UpdateData();

	::GetWindowText((HWND)m_targetWindow, m_strCaption.GetBuffer(MAX_PATH),
		MAX_PATH);

	::GetClassName((HWND)m_targetWindow, m_strClass.GetBuffer(MAX_PATH),
		MAX_PATH);

	UpdateData(FALSE);
}

// When window caption field changes, change it
void CWfTestDlg::OnChangeCaption() 
{
	LPRECT lpRect;

	UpdateData();

	lpRect = new RECT;

	// Set new caption
	::SetWindowText((HWND)m_targetWindow, m_strCaption);
	
	// Invalidate whole window
	::GetWindowRect((HWND)m_targetWindow, lpRect);
	::InvalidateRect((HWND)m_targetWindow, lpRect, FALSE);
}
