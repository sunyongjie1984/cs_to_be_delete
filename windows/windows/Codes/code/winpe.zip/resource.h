//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by winpe.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_WINPETYPE                   129
#define IDD_IMPORT_DIALOG               130
#define IDC_IMPORT_COMBO                1000
#define IDC_IMPORT_LISTBOX              1001
#define ID_VIEWS_IMPORTS                32771
#define ID_VIEWS_EXPORTS                32773
#define ID_VIEWS_DUMP                   32774
#define ID_VIEWS_HEADERS                32775
#define ID_VIEWS_SECTNTBL               32776
#define ID_VIEWS_DEBUGDIR               32777
#define ID_VIEWS_RESOURCES              32778
#define ID_FONTS_PRINTER                32779
#define ID_FONTS_DISPLAY                32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
