// ClockManDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ClockMan.h"
#include "ClockManDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CTray tClockMan;
CTimeSpan timespan;
CTime Now;
char Tip[30];
#include <winreg.h>
///////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClockManDlg dialog

CClockManDlg::CClockManDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CClockManDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CClockManDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_CLOCKMAN);
}

void CClockManDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClockManDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CClockManDlg, CDialog)
	//{{AFX_MSG_MAP(CClockManDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CREATE()
	ON_MESSAGE(MYWM_NOTIFYICON, OnNotifyIcon)
	ON_BN_CLICKED(IDC_OK, OnOk)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_CANCEL, OnCancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClockManDlg message handlers

BOOL CClockManDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	HKEY hKey;
	DWORD dw = 0;
	DWORD dwType = 0;
	int Hour, Minute, Second;
	if (RegOpenKeyEx(HKEY_CURRENT_USER, "SoftWare\\ClockMan", 0, KEY_QUERY_VALUE, &hKey) != ERROR_SUCCESS)
	{
		SetDlgItemInt(IDC_HOUR, 0);
		SetDlgItemInt(IDC_MINUTE, 0);
		SetDlgItemInt(IDC_SECOND, 0);
	}
	else
	{
		RegQueryValueEx(hKey, "Hour", NULL, &dwType, (BYTE*)&Hour, &dw);
		RegQueryValueEx(hKey, "Hour", NULL, &dwType, (BYTE*)&Hour, &dw);
		RegQueryValueEx(hKey, "Minute", NULL, &dwType, (BYTE*)&Minute, &dw);
		RegQueryValueEx(hKey, "Second", NULL, &dwType, (BYTE*)&Second, &dw);
		SetDlgItemInt(IDC_HOUR, Hour);
		SetDlgItemInt(IDC_MINUTE, Minute);
		SetDlgItemInt(IDC_SECOND, Second);
		OnOk();
	}
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CClockManDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CClockManDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CClockManDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

int CClockManDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	tClockMan.Create(m_hWnd, IDR_CLOCKMAN, NIF_MESSAGE|NIF_ICON|NIF_TIP, MYWM_NOTIFYICON);
	tClockMan.Add(m_hIcon, "С����");
	
	return 0;
}

LONG CClockManDlg::OnNotifyIcon(UINT message, LONG Param) 
{
	switch(LOWORD(Param))
	{
	case WM_LBUTTONDBLCLK:
	case WM_RBUTTONDOWN:
		ShowWindow(SW_SHOWNORMAL);
		break;
	}
	return 0;
}

void CClockManDlg::OnOk() 
{
	HKEY hKey;
	TCHAR lpsz[256];

	Timer();
	::GetModuleFileName(AfxGetInstanceHandle(), lpsz, 256);
	RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SoftWare\\Microsoft\\Windows\\CurrentVersion\\Run", 0, KEY_ALL_ACCESS, &hKey);
	RegSetValueEx(hKey, "ClockMan", NULL, REG_SZ, (BYTE*)lpsz, sizeof(lpsz));
	
	int Hour = GetDlgItemInt(IDC_HOUR), Minute = GetDlgItemInt(IDC_MINUTE), Second = GetDlgItemInt(IDC_SECOND);
	if (Hour == 0)
		SetDlgItemInt(IDC_HOUR, 0);
	if (Minute == 0)
		SetDlgItemInt(IDC_MINUTE, 0);
	if (Second == 0)
		SetDlgItemInt(IDC_SECOND, 0);
	RegCreateKeyEx(HKEY_CURRENT_USER, "SoftWare\\ClockMan", 0, "SoftWare\\ClockMan", REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKey, NULL);
	RegSetValueEx(hKey, "Hour", NULL, REG_DWORD, (BYTE*)&Hour, 4);
	RegSetValueEx(hKey, "Minute", NULL, REG_DWORD, (BYTE*)&Minute, 4);
	RegSetValueEx(hKey, "Second", NULL, REG_DWORD, (BYTE*)&Second, 4);
	
	ShowWindowAsync(m_hWnd, SW_HIDE);
}

void CClockManDlg::Timer()
{
	KillTimer(1);
	CTime Now;

	Now = Now.GetCurrentTime();
	CTime time(Now.GetYear(), Now.GetMonth(), Now.GetDay(), GetDlgItemInt(IDC_HOUR), GetDlgItemInt(IDC_MINUTE), GetDlgItemInt(IDC_SECOND));
	timespan = time - Now;
	if (timespan.GetTotalSeconds() < 0)
	{
		CTimeSpan sp(1, 0, 0, 0);
		timespan += sp;
	}
			
	if (timespan.GetTotalSeconds() > 3600)
	{
		SetTimer(1, 3600000, NULL);
		sprintf(Tip, "����%dСʱ�أ����ż���", timespan.GetHours());
	}
	else
		if (timespan.GetTotalSeconds() > 60)
		{
			SetTimer(1, 60000, NULL);
			sprintf(Tip, "����%d���ӣ��쵽�ˡ�", timespan.GetMinutes());
		}
		else
		{
			sprintf(Tip, "��ʣ %d ��! ��ע��", timespan.GetSeconds());
			SetTimer(1, 1000, NULL);
		}
	tClockMan.Modify(m_hIcon, Tip);
	SetDlgItemText(IDC_TIP, Tip);
	UpdateWindow();
}

void CClockManDlg::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent = 1)
	{
		Timer();
		if (timespan.GetTotalSeconds() == 0)
		{
			CTime Now;
			Now = Now.GetCurrentTime();
			ShowWindow(SW_SHOWNORMAL);
			SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
			sprintf(Tip, "������ %d:%d:%d, ʱ�䵽��!", Now.GetHour(), Now.GetMinute(), Now.GetSecond());
			MessageBox(Tip);
		}
	}
	CDialog::OnTimer(nIDEvent);
}

void CClockManDlg::OnCancel() 
{
	tClockMan.Delete();
	PostQuitMessage(0);
}
