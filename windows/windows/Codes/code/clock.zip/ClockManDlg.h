// ClockManDlg.h : header file
//

#if !defined(AFX_CLOCKMANDLG_H__F20B7F47_2101_11D3_86F7_EB11AAEE3DEC__INCLUDED_)
#define AFX_CLOCKMANDLG_H__F20B7F47_2101_11D3_86F7_EB11AAEE3DEC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <.\\CTray\\CTray.h>
#define MYWM_NOTIFYICON WM_USER+100
/////////////////////////////////////////////////////////////////////////////
// CClockManDlg dialog

class CClockManDlg : public CDialog
{
// Construction
public:
	CClockManDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CClockManDlg)
	enum { IDD = IDD_CLOCKMAN_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClockManDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	void Timer();
	
	// Generated message map functions
	//{{AFX_MSG(CClockManDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg LONG OnNotifyIcon(UINT, LONG);
	afx_msg void OnOk();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLOCKMANDLG_H__F20B7F47_2101_11D3_86F7_EB11AAEE3DEC__INCLUDED_)
