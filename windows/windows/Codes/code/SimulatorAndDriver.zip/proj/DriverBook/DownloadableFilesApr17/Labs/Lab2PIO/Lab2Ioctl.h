// mapmemioctl.h    Include file for Generic Port I/O Example Driver
/*****************************************************************************
*           Change Log
*  Date     | Change
*-----------+-----------------------------------------------------------------

*****************************************************************************/
//
// Define the IOCTL codes we will use.  The IOCTL code contains a command
// identifier, plus other information about the device, the type of access
// with which the file must have been opened, and the type of buffering.
//


// Device type           -- in the "User Defined" range."
#define LAB2_TYPE 43000
#define LAB2_IOCTL_BASE 2833  
//0xb11
                                         
 



typedef LARGE_INTEGER PHYSICAL_ADDRESS, *PPHYSICAL_ADDRESS; // windbgkd



enum 
{ 
    LAB2_IOCTL_INITIALIZE  = LAB2_IOCTL_BASE,
    LAB2_IOCTL_HELLO_READ,
    LAB2_IOCTL_HELLO_WRITE
};

// The IOCTL function codes from 0x800 to 0xFFF are for customer use.

#define IOCTL_LAB_INITIALIZE \
    CTL_CODE(LAB2_TYPE,  LAB2_IOCTL_INITIALIZE, METHOD_BUFFERED, FILE_WRITE_DATA | FILE_READ_DATA)


#define IOCTL_LAB_GEN_INT \
    CTL_CODE(LAB2_TYPE,  LAB2_IOCTL_GEN_INT, METHOD_BUFFERED, FILE_WRITE_DATA | FILE_READ_DATA)

#define IOCTL_LAB_HELLO_READ \
    CTL_CODE(LAB2_TYPE,  LAB2_IOCTL_HELLO_READ, METHOD_BUFFERED, FILE_WRITE_DATA | FILE_READ_DATA)

#define IOCTL_LAB_HELLO_WRITE \
    CTL_CODE(LAB2_TYPE,  LAB2_IOCTL_HELLO_WRITE, METHOD_BUFFERED, FILE_WRITE_DATA | FILE_READ_DATA)
