/*****************************************************************************
*           Change Log
*  Date     | Change
*-----------+-----------------------------------------------------------------
* 20-Mar-99 | Created change log
* 20-Mar-99 | Added OnRstIn, OnRstOut, c_RstIn, c_RstOut
*****************************************************************************/
// SimulatorDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSimulatorDlg dialog

class CInterruptMgt;

class CSimulatorDlg : public CDialog
{
// Construction
public:
CSimulatorDlg (CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSimulatorDlg)
	enum { IDD = IDD_SIMULATOR_DIALOG };
	CButton	c_SingleStep;
	CButton	c_GetState;
	CButton	c_IACKOut;
	CButton	c_IACKIn;
	CSpinnerButton	c_GoHackIn;
	CSpinnerButton  c_GoHackOut;
	CButton	c_Interrupt;
	CEdit	c_Transfer;
	CButton	c_Int;
	CButton	c_OvrIn;
	CButton	c_UndOut;
	CButton	c_OverUnder;
	CButton	c_IntOut;
	CButton	c_IntIn;
	CButton	c_IEOut;
	CButton	c_IEIn;
	CButton	c_GoOut;
	CButton	c_GoIn;
	CButton	c_Errors;
	CButton	c_ErrOut;
	CButton	c_ErrIn;
	CButton	c_EopIn;
	CButton	c_DoneOut;
	CButton	c_BusyOut;
	CButton	c_DoneIn;
	CButton c_RSTIn;
	CButton c_RSTOut;
	CButton	c_OK;
	CButton	c_Generate;
	CTraceWnd c_Trace;
	CButton	c_Send;
	CButton	c_Manual;
	CButton	c_FreeRun;
	CComboBox	c_Data;
	CButton	c_Clear;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimulatorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// The following are used to trace the register CHANGES
	BYTE CommandIn;
	BYTE CommandOut;
	BYTE StatusIn;
	BYTE StatusOut;
	BOOL err;
	BOOL debug;
	BOOL manual; // TRUE if in manual mode
	BOOL singleStep; // TRUE if in singleStep mode

	HICON m_hIcon;
	void updateControls(BOOL valid = TRUE);
	void setDoneOut(BOOL done, LPCTSTR why = NULL);
	static UINT watcher(LPVOID me);
	void poll();
	BOOL  polling;
	CWinThread * pollthread;
	void shutdown();
	HWND mainWnd; // required for cross-thread SendMessage
	HANDLE freerun; // event handle used for free-run
	HANDLE stop;    // interlock to keep manual transition from happening
			// in middle of cycle
	HANDLE pause;   // holds the polling thread until the message is
			// processed
	DWORD irq;
	void doSave(BOOL mode);
	void logStatusChangeIn(BYTE o, BYTE n,LPCTSTR reason = NULL);
	void logStatusChangeOut(BYTE o, BYTE n, LPCTSTR reason = NULL);
	void logCommandChangeIn(BYTE o, BYTE n, LPCTSTR reason = NULL);
	void logCommandChangeOut(BYTE o, BYTE n, LPCTSTR reason = NULL);
	void logChange(BYTE o, BYTE n, BYTE status, UINT type, LPCTSTR reason = NULL);
	BYTE InControlsToCommand();
	BYTE OutControlsToCommand();
	BYTE InControlsToStatus();
	BYTE OutControlsToStatus();

	void pollInput();
	void pollOutput();
	void generateAndLogInterrupt(LPCTSTR annotation = NULL);
	void setTransfer(CString & s);
	void sendNext();
	void receiveNext();
	void InCommandToControls(BYTE command);
	void InStatusToControls(BYTE status);
	void OutCommandToControls(BYTE command);
	void OutStatusToControls(BYTE status);
	void optimizedSet(CButton & ctl, BYTE value, BYTE mask);
	void logErrorChange(CButton & ctl);
	void startPollingCycle();
	void endPollingCycle();
	void OpenRegisterTransaction(LPCTSTR where);
	void CloseRegisterTransaction(LPCTSTR where);

	DWORD GoDoneMinimum;
	DWORD GoDoneVariance;
	DWORD GoDoneDelay();

	DWORD ProbErr;
	DWORD ProbOvrUnd;
	DWORD ProbLost;
	DWORD ProbSpurious;
	BOOL injectErr();
	BOOL injectOvrUnd();
	BOOL prob(CButton & ctl, DWORD p);

	CString SaveFileName;

	CInterruptMgt * imgr;
	CRegDisplay   * regdisp;

	IORegisters registers;
	DWORD pollInterval;

	CString input; // Current input string
	CString output; // simulated output string if using GoHack stuff

	// Generated message map functions
	//{{AFX_MSG(CSimulatorDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnClear();
	afx_msg void OnFreerun();
	afx_msg void OnManual();
	afx_msg void OnSend();
	afx_msg void OnBusyOut();
	afx_msg void OnSelendokData();
	afx_msg void OnClose();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnGenerate();
	afx_msg void OnEditchangeData();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDoneIn();
	afx_msg void OnDoneOut();
	afx_msg void OnEopIn();
	afx_msg void OnErrIn();
	afx_msg void OnErrOut();
	afx_msg void OnGoIn();
	afx_msg void OnGoOut();
	afx_msg void OnIeIn();
	afx_msg void OnIeOut();
	afx_msg void OnIntIn();
	afx_msg void OnIntOut();
	afx_msg void OnOvrIn();
	afx_msg void OnOvrund();
	afx_msg void OnUndOut();
	afx_msg void OnInt();
	afx_msg void OnAppAbout();
	afx_msg void OnFileExit();
	afx_msg void OnFileSave();
	afx_msg void OnUpdateFileSaveAs(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileSave(CCmdUI* pCmdUI);
	afx_msg void OnFileSaveAs();
	afx_msg void OnHelpIndex();
	afx_msg void OnInterruptMgt();
	afx_msg void OnSetupIrq();
	afx_msg void OnErrors();
	afx_msg void OnInterrupt();
	afx_msg void OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
	afx_msg void OnClearInput();
	afx_msg void OnDebug();
	afx_msg void OnGoHackIn();
	afx_msg void OnGoHackOut();
	afx_msg void OnIackIn();
	afx_msg void OnIackOut();
	afx_msg LRESULT OnPulse(WPARAM, LPARAM);
	afx_msg LRESULT OnPoll(WPARAM, LPARAM);
	afx_msg LRESULT OnImgrClose(WPARAM, LPARAM);
	afx_msg LRESULT OnRegClose(WPARAM, LPARAM);
	afx_msg LRESULT OnOpenFailed(WPARAM, LPARAM);
	afx_msg LRESULT OnSetTimerOut(WPARAM, LPARAM);
	afx_msg LRESULT OnSetTimerIn(WPARAM, LPARAM);
	afx_msg LRESULT OnExecuteGoHackIn(WPARAM, LPARAM);
	afx_msg LRESULT OnExecuteGoHackOut(WPARAM, LPARAM);
	afx_msg LRESULT OnSetManualMode(WPARAM, LPARAM);
	afx_msg LRESULT OnUpdateProbabilities(WPARAM, LPARAM);
	afx_msg void OnComment();
	afx_msg void OnGetstate();
	afx_msg void OnSinglestep();
	afx_msg void OnHdwsimTrace();
	afx_msg void OnRegDisp();
	afx_msg void OnRstIn();
	afx_msg void OnRstOut();
	//}}AFX_MSG

	// Nominally obsolete, redo as void w/o WPARAM, LPARAM
	afx_msg LRESULT OnRstInSet(WPARAM, LPARAM);
	afx_msg LRESULT OnRstOutSet(WPARAM, LPARAM);
	afx_msg LRESULT OnGoOutSet(WPARAM, LPARAM);
	afx_msg LRESULT OnGoInSet(WPARAM, LPARAM);
	afx_msg LRESULT OnIACKInSet(WPARAM, LPARAM);
	afx_msg LRESULT OnIACKOutSet(WPARAM, LPARAM);
	afx_msg LRESULT OnIEOutSet(WPARAM, LPARAM);
	afx_msg LRESULT OnIEInSet(WPARAM, LPARAM);
	afx_msg LRESULT OnUpdateControls(WPARAM, LPARAM);

	DECLARE_MESSAGE_MAP()
};

