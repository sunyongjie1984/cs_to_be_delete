// RegDisplay.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRegDisplay dialog

class CRegDisplay : public CDialog
{
// Construction
public:
	CRegDisplay(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRegDisplay)
	enum { IDD = IDD_REGISTERS };
	CRegData	c_OutStatus;
	CRegData	c_OutData;
	CRegData	c_OutCommand;
	CRegData	c_InStatus;
	CRegData	c_InData;
	CRegData	c_InCommand;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRegDisplay)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRegDisplay)
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	afx_msg void OnOK();
	afx_msg void OnCancel();
	afx_msg void OnDestroy();
	afx_msg LRESULT OnUpdateRegs(WPARAM, LPARAM);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
