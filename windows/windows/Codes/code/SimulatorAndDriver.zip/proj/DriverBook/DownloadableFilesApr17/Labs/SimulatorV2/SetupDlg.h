// SetupDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSetupDlg dialog

class CSetupDlg : public CDialog
{
// Construction
public:
	CSetupDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSetupDlg)
	enum { IDD = IDD_SETUP };
	CSpinButtonCtrl	c_SpinGoDoneVariance;
	CSpinButtonCtrl	c_SpinGoDoneMin;
	CEdit	c_GoDoneVariance;
	CEdit	c_GoDoneMin;
	CSpinButtonCtrl	c_SpinPollingInterval;
	CEdit	c_PollingInterval;
	CButton	c_OK;
	CComboBox	c_IRQ;
	int m_IRQ;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetupDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void updateControls();

	// Generated message map functions
	//{{AFX_MSG(CSetupDlg)
	afx_msg void OnSelendokIrq();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
