
// Hardware Simulator driver

/*****************************************************************************
*           Change Log
*  Date     | Change
*-----------+-----------------------------------------------------------------
*  3-23-99      END -  Added missing DBG_MSG_HDR to print statement
* 18-Mar-98 | Added new codes for get/set of debug mask.
*           | Debug mask stored in device extension
*           | Debug mask controls printout
* 10-06-97  |   END - Created

*****************************************************************************/


/*****************************************************************************
*                       To Do
*-----------------------------------------------------------------------------


*****************************************************************************/
#include "ntddk.h"
#include "HdwSim.h"
#include "HdwSimIoctl.h"
#include "mapMemory.h"
#include "readReg.h"


#define DBG_MSG_HDR "HdwSim: "



NTSTATUS HdwSimOpen(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp );

NTSTATUS HdwSimClose(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp );

NTSTATUS HdwSimDeviceControl (
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp );

VOID HdwSimUnload(
    IN PDRIVER_OBJECT DriverObject );


BOOLEAN HdwSimInterruptServiceRoutine(
    IN PKINTERRUPT Interrupt,
    IN OUT PVOID Context
    );


VOID HdwSimDpcRoutine(
    IN PKDPC Dpc,
    IN PVOID DeferredContext,
    IN PVOID SystemArgument1,
    IN PVOID SystemArgument2
    );



NTSTATUS DriverEntry(
    IN PDRIVER_OBJECT DriverObject,
    IN PUNICODE_STRING RegistryPath )
{

    PDEVICE_OBJECT deviceObject = NULL;
    NTSTATUS status;
    UNICODE_STRING uniNtNameString;
    UNICODE_STRING uniDosNameString;

    NTSTATUS retReg;


    //
    //  registry values
    //
    ULONG debugMask;
    ULONG eventLog;
    ULONG shouldBreak;
    ULONG interrupt_Line;



//   unsigned int busNumber;


   PHDW_SIM_DEVICE_EXTENSION extension;

    unsigned int   vgaBaseReg;
    unsigned int   baseReg = 0;
    ULONG          baseAddressReg1;

    PHYSICAL_ADDRESS    physicalAddressBase1;
    ULONG               lengthToMap;
    unsigned int        i;

     UNICODE_STRING ephemeralRegistryPath;
     UNICODE_STRING parameterRegistryPath;
     UNICODE_STRING registryPathName;
 
#define HDW_SIM_MAX_NAMELENGTH 200

     KdPrint( ("%s Entered the HdwSim driver!\n", DBG_MSG_HDR) );

     status = initDevicePath( DriverObject,  RegistryPath , &ephemeralRegistryPath, &parameterRegistryPath, &registryPathName);

     retReg = readRegistry(DriverObject, &parameterRegistryPath, &debugMask, &eventLog, &shouldBreak, &interrupt_Line);

     KdPrint( ("%s returned from readRegistry!\n", DBG_MSG_HDR) );


     if (shouldBreak)
        DbgBreakPoint();

    //
    // Create counted string version of our device name.
    //

    RtlInitUnicodeString( &uniNtNameString, NT_DEVICE_NAME );

    //
    // Create the device object
    //

    status = IoCreateDevice(
                 DriverObject,
                 sizeof(HDW_SIM_DEVICE_EXTENSION),        //  device extension
                 &uniNtNameString,
                 FILE_DEVICE_UNKNOWN,
                 0,                     // No standard device characteristics
                 FALSE,                 // This isn't an exclusive device
                 &deviceObject
                 );

    if ( !NT_SUCCESS(status) )
    {

        KdPrint(("%s could not create device\n",   DBG_MSG_HDR));
        status = STATUS_NO_SUCH_DEVICE;
        return status;
    }
    extension = deviceObject->DeviceExtension;

    extension->DeviceObject = deviceObject;



    extension->ephemeralRegistryPath = ephemeralRegistryPath ;
    extension->parameterRegistryPath = parameterRegistryPath;
    extension->registryPathName = registryPathName;
    extension->debugMask = debugMask;
  
    extension->pSimulatedRegisterLogicalAddress = &extension->simulatedRegister[0];
//    (PUCHAR)ExAllocatePool(NonPagedPool, sizeof(HDW_SIM_REGS)); 

    //
    //  if NULL returned error
    //

    extension->pSimulatedRegisterPhysicalAddress = MmGetPhysicalAddress(extension->pSimulatedRegisterLogicalAddress);


    KeInitializeSpinLock(&extension->registerLock);

    //
    // Create dispatch points for create/open, close, unload.
    //

    DriverObject->MajorFunction[IRP_MJ_CREATE]          = HdwSimOpen;
    DriverObject->MajorFunction[IRP_MJ_CLOSE]           = HdwSimClose;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL]  = HdwSimDeviceControl;
    DriverObject->DriverUnload = HdwSimUnload;

    KdPrint( ("%s just about ready!\n", DBG_MSG_HDR) );

    //
    // Do Buffered I/O.    A nop Read and write are not supported by this driver
    //
    deviceObject->Flags |= DO_BUFFERED_IO;

    //
    // Create counted string version of our Win32 device name.
    //
    RtlInitUnicodeString( &uniDosNameString, DOS_DEVICE_NAME );

    //
    // Create a link from our device name to a name in the Win32 namespace.
    //

    status = IoCreateSymbolicLink( &uniDosNameString, &uniNtNameString );

    if (!NT_SUCCESS(status))
    {
        KdPrint( ("%s  Couldn't create the symbolic link\n", DBG_MSG_HDR) );

        IoDeleteDevice( DriverObject->DeviceObject );
        return status;
    }




    //
    // save the address in the device extension;
    //
    extension->interrupt_Line = interrupt_Line;
    extension->Level  = extension->interrupt_Line;
    extension->Vector =  extension->interrupt_Line;
                                         

    extension->interrupt_IDT = HalGetInterruptVector(Isa,
                                                     (ULONG)0,                      // BusNumber,
                                                     extension->Level,       // Level
                                                     extension->Vector,      // Vector,
                                                     &extension->irql,       // IRQL
                                                     &extension->Affinity);  // Affinity mask



    status = saveConfig( extension->ephemeralRegistryPath.Buffer,
                        	extension->interrupt_Line,
                        	extension->interrupt_IDT,
                        	(VOID *)extension->pSimulatedRegisterLogicalAddress,
                        	extension->pSimulatedRegisterPhysicalAddress
                        );

     KdPrint(("%s  TargetReadRegistry - interruptLine   = 0x%08x\n", DBG_MSG_HDR,   extension->interrupt_Line ));
     KdPrint(("%s  TargetReadRegistry - interruptIDT    = 0x%08x\n", DBG_MSG_HDR,   extension->interrupt_IDT ));
     KdPrint(("%s  TargetReadRegistry - registerAddress = 0x%08x\n", DBG_MSG_HDR,   
                             (ULONG)extension->pSimulatedRegisterLogicalAddress));
     KdPrint(("%s  TargetReadRegistry - PhysicalAddress= 0x%08x 0x%08x\n", DBG_MSG_HDR,  
                             extension->pSimulatedRegisterPhysicalAddress.HighPart,
                             extension->pSimulatedRegisterPhysicalAddress.LowPart));






    KdPrint( ("%s  All initialized\n", DBG_MSG_HDR) );


    return status;
}

NTSTATUS HdwSimOpen(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp )
{
    KdPrint( ("%s  Opened!!\n", DBG_MSG_HDR) );


    //
    // No need to do anything.
    //

    //
    // Fill these in before calling IoCompleteRequest.
    //
    // DON'T get cute and try to use the status field of
    // the irp in the return status.  That IRP IS GONE as
    // soon as you call IoCompleteRequest.
    //


    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;

    IoCompleteRequest( Irp, IO_NO_INCREMENT );

    return STATUS_SUCCESS;
}

NTSTATUS HdwSimClose(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp )
{

    KdPrint( ("%s Closed!!\n", DBG_MSG_HDR) );

    //
    // No need to do anything.
    //

    //
    // Fill these in before calling IoCompleteRequest.
    //
    // DON'T get cute and try to use the status field of
    // the irp in the return status.  That IRP IS GONE as
    // soon as you call IoCompleteRequest.
    //

    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;



    IoCompleteRequest( Irp, IO_NO_INCREMENT );

    return STATUS_SUCCESS;
}

/****************************************************************************
    Function:
              generateInterrupt
    Arguments:

    Description:

    Returns:


*****************************************************************************/
void generateInterrupt(UCHAR interrupt_IDT)
{
   switch ( interrupt_IDT )
   {
     case 0x00:   _asm { int 0x00 }
                  break;
     case 0x01:   _asm { int 0x01 }
                  break;       
     case 0x02:   _asm { int 0x02 }
                  break;
     case 0x03:   _asm { int 0x03 }
                  break;
     case 0x04:   _asm { int 0x04 }
                  break;
     case 0x05:   _asm { int 0x05 }
                  break;
     case 0x06:   _asm { int 0x06 }
                  break;
     case 0x07:   _asm { int 0x07 }
                  break;
     case 0x08:   _asm { int 0x08 }
                  break;
     case 0x09:   _asm { int 0x09 }
                  break;
     case 0x0a:   _asm { int 0x0a }
                  break;
     case 0x0b:   _asm { int 0x0b }
                  break;
     case 0x0c:   _asm { int 0x0c }
                  break;
     case 0x0d:   _asm { int 0x0d }
                  break;
     case 0x0e:   _asm { int 0x0e }
                  break;
     case 0x0f:   _asm { int 0x0f }
                  break;

     case 0x10:   _asm { int 0x10 }
                  break;
     case 0x11:   _asm { int 0x11 }
                  break;
     case 0x12:   _asm { int 0x12 }
                  break;
     case 0x13:   _asm { int 0x13 }
                  break;
     case 0x14:   _asm { int 0x14 }
                  break;
     case 0x15:   _asm { int 0x15 }
                  break;
     case 0x16:   _asm { int 0x16 }
                  break;
     case 0x17:   _asm { int 0x17 }
                  break;
     case 0x18:   _asm { int 0x18 }
                  break;
     case 0x19:   _asm { int 0x19 }
                  break;
     case 0x1a:   _asm { int 0x1a }
                  break;
     case 0x1b:   _asm { int 0x1b }
                  break;
     case 0x1c:   _asm { int 0x1c }
                  break;
     case 0x1d:   _asm { int 0x1d }
                  break;
     case 0x1e:   _asm { int 0x1e }
                  break;
     case 0x1f:   _asm { int 0x1f }

   
     case 0x20:   _asm { int 0x20 }
                  break;
     case 0x21:   _asm { int 0x21 }
                  break;
     case 0x22:   _asm { int 0x22 }
                  break;
     case 0x23:   _asm { int 0x23 }
                  break;
     case 0x24:   _asm { int 0x24 }
                  break;
     case 0x25:   _asm { int 0x25 }
                  break;
     case 0x26:   _asm { int 0x26 }
                  break;
     case 0x27:   _asm { int 0x27 }
                  break;
     case 0x28:   _asm { int 0x28 }
                  break;
     case 0x29:   _asm { int 0x29 }
                  break;
     case 0x2a:   _asm { int 0x2a }
                  break;
     case 0x2b:   _asm { int 0x2b }
                  break;
     case 0x2c:   _asm { int 0x2c }
                  break;
     case 0x2d:   _asm { int 0x2d }
                  break;
     case 0x2e:   _asm { int 0x2e }
                  break;
     case 0x2f:   _asm { int 0x2f }
                  break;

     case 0x30:   _asm { int 0x30 }
                  break;
     case 0x31:   _asm { int 0x31 }
                  break;
     case 0x32:   _asm { int 0x32 }
                  break;
     case 0x33:   _asm { int 0x33 }
                  break;
     case 0x34:   _asm { int 0x34 }
                  break;
     case 0x35:   _asm { int 0x35 }
                  break;
     case 0x36:   _asm { int 0x36 }
                  break;
     case 0x37:   _asm { int 0x37 }
                  break;
     case 0x38:   _asm { int 0x38 }
                  break;
     case 0x39:   _asm { int 0x39 }
                  break;
     case 0x3a:   _asm { int 0x3a }
                  break;
     case 0x3b:   _asm { int 0x3b }
                  break;
     case 0x3c:   _asm { int 0x3c }
                  break;
     case 0x3d:   _asm { int 0x3d }
                  break;
     case 0x3e:   _asm { int 0x3e }
                  break;
     case 0x3f:   _asm { int 0x3f }
                  break;

     case 0x40:   _asm { int 0x40 }
                  break;
     case 0x41:   _asm { int 0x41 }
                  break;
     case 0x42:   _asm { int 0x42 }
                  break;
     case 0x43:   _asm { int 0x43 }
                  break;
     case 0x44:   _asm { int 0x44 }
                  break;
     case 0x45:   _asm { int 0x45 }
                  break;
     case 0x46:   _asm { int 0x46 }
                  break;
     case 0x47:   _asm { int 0x47 }
                  break;
     case 0x48:   _asm { int 0x48 }
                  break;
     case 0x49:   _asm { int 0x49 }
                  break;
     case 0x4a:   _asm { int 0x4a }
                  break;
     case 0x4b:   _asm { int 0x4b }
                  break;
     case 0x4c:   _asm { int 0x4c }
                  break;
     case 0x4d:   _asm { int 0x4d }
                  break;
     case 0x4e:   _asm { int 0x4e }
                  break;
     case 0x4f:   _asm { int 0x4f }
                  break;

     case 0x50:   _asm { int 0x50 }
                  break;
     case 0x51:   _asm { int 0x51 }
                  break;
     case 0x52:   _asm { int 0x52 }
                  break;
     case 0x53:   _asm { int 0x53 }
                  break;
     case 0x54:   _asm { int 0x54 }
                  break;
     case 0x55:   _asm { int 0x55 }
                  break;
     case 0x56:   _asm { int 0x56 }
                  break;
     case 0x57:   _asm { int 0x57 }
                  break;
     case 0x58:   _asm { int 0x58 }
                  break;
     case 0x59:   _asm { int 0x59 }
                  break;
     case 0x5a:   _asm { int 0x5a }
                  break;
     case 0x5b:   _asm { int 0x5b }
                  break;
     case 0x5c:   _asm { int 0x5c }
                  break;
     case 0x5d:   _asm { int 0x5d }
                  break;
     case 0x5e:   _asm { int 0x5e }
                  break;
     case 0x5f:   _asm { int 0x5f }
                  break;

     case 0x60:   _asm { int 0x60 }
                  break;
     case 0x61:   _asm { int 0x61 }
                  break;
     case 0x62:   _asm { int 0x62 }
                  break;
     case 0x63:   _asm { int 0x63 }
                  break;
     case 0x64:   _asm { int 0x64 }
                  break;
     case 0x65:   _asm { int 0x65 }
                  break;
     case 0x66:   _asm { int 0x66 }
                  break;
     case 0x67:   _asm { int 0x67 }
                  break;
     case 0x68:   _asm { int 0x68 }
                  break;
     case 0x69:   _asm { int 0x69 }
                  break;
     case 0x6a:   _asm { int 0x6a }
                  break;
     case 0x6b:   _asm { int 0x6b }
                  break;
     case 0x6c:   _asm { int 0x6c }
                  break;
     case 0x6d:   _asm { int 0x6d }
                  break;
     case 0x6e:   _asm { int 0x6e }
                  break;
     case 0x6f:   _asm { int 0x6f }
                  break;

     case 0x70:   _asm { int 0x70 }
                  break;
     case 0x71:   _asm { int 0x71 }
                  break;
     case 0x72:   _asm { int 0x72 }
                  break;
     case 0x73:   _asm { int 0x73 }
                  break;
     case 0x74:   _asm { int 0x74 }
                  break;
     case 0x75:   _asm { int 0x75 }
                  break;
     case 0x76:   _asm { int 0x76 }
                  break;
     case 0x77:   _asm { int 0x77 }
                  break;
     case 0x78:   _asm { int 0x78 }
                  break;
     case 0x79:   _asm { int 0x79 }
                  break;
     case 0x7a:   _asm { int 0x7a }
                  break;
     case 0x7b:   _asm { int 0x7b }
                  break;
     case 0x7c:   _asm { int 0x7c }
                  break;
     case 0x7d:   _asm { int 0x7d }
                  break;
     case 0x7e:   _asm { int 0x7e }
                  break;
     case 0x7f:   _asm { int 0x7f }
                  break;

     case 0x80:   _asm { int 0x80 }
                  break;
     case 0x81:   _asm { int 0x81 }
                  break;
     case 0x82:   _asm { int 0x82 }
                  break;
     case 0x83:   _asm { int 0x83 }
                  break;
     case 0x84:   _asm { int 0x84 }
                  break;
     case 0x85:   _asm { int 0x85 }
                  break;
     case 0x86:   _asm { int 0x86 }
                  break;
     case 0x87:   _asm { int 0x87 }
                  break;
     case 0x88:   _asm { int 0x88 }
                  break;
     case 0x89:   _asm { int 0x89 }
                  break;
     case 0x8a:   _asm { int 0x8a }
                  break;
     case 0x8b:   _asm { int 0x8b }
                  break;
     case 0x8c:   _asm { int 0x8c }
                  break;
     case 0x8d:   _asm { int 0x8d }
                  break;
     case 0x8e:   _asm { int 0x8e }
                  break;
     case 0x8f:   _asm { int 0x8f }
                  break;

     case 0x90:   _asm { int 0x90 }
                  break;
     case 0x91:   _asm { int 0x91 }
                  break;
     case 0x92:   _asm { int 0x92 }
                  break;
     case 0x93:   _asm { int 0x93 }
                  break;
     case 0x94:   _asm { int 0x94 }
                  break;
     case 0x95:   _asm { int 0x95 }
                  break;
     case 0x96:   _asm { int 0x96 }
                  break;
     case 0x97:   _asm { int 0x97 }
                  break;
     case 0x98:   _asm { int 0x98 }
                  break;
     case 0x99:   _asm { int 0x99 }
                  break;
     case 0x9a:   _asm { int 0x9a }
                  break;
     case 0x9b:   _asm { int 0x9b }
                  break;
     case 0x9c:   _asm { int 0x9c }
                  break;
     case 0x9d:   _asm { int 0x9d }
                  break;
     case 0x9e:   _asm { int 0x9e }
                  break;
     case 0x9f:   _asm { int 0x9f }
                  break;

     case 0xa0:   _asm { int 0xa0 }
                  break;
     case 0xa1:   _asm { int 0xa1 }
                  break;
     case 0xa2:   _asm { int 0xa2 }
                  break;
     case 0xa3:   _asm { int 0xa3 }
                  break;
     case 0xa4:   _asm { int 0xa4 }
                  break;
     case 0xa5:   _asm { int 0xa5 }
                  break;
     case 0xa6:   _asm { int 0xa6 }
                  break;
     case 0xa7:   _asm { int 0xa7 }
                  break;
     case 0xa8:   _asm { int 0xa8 }
                  break;
     case 0xa9:   _asm { int 0xa9 }
                  break;
     case 0xaa:   _asm { int 0xaa }
                  break;
     case 0xab:   _asm { int 0xab }
                  break;
     case 0xac:   _asm { int 0xac }
                  break;
     case 0xad:   _asm { int 0xad }
                  break;
     case 0xae:   _asm { int 0xae }
                  break;
     case 0xaf:   _asm { int 0xaf }
                  break;

     case 0xb0:   _asm { int 0xb0 }
                  break;
     case 0xb1:   _asm { int 0xb1 }
                  break;
     case 0xb2:   _asm { int 0xb2 }
                  break;
     case 0xb3:   _asm { int 0xb3 }
                  break;
     case 0xb4:   _asm { int 0xb4 }
                  break;
     case 0xb5:   _asm { int 0xb5 }
                  break;
     case 0xb6:   _asm { int 0xb6 }
                  break;
     case 0xb7:   _asm { int 0xb7 }
                  break;
     case 0xb8:   _asm { int 0xb8 }
                  break;
     case 0xb9:   _asm { int 0xb9 }
                  break;
     case 0xba:   _asm { int 0xba }
                  break;
     case 0xbb:   _asm { int 0xbb }
                  break;
     case 0xbc:   _asm { int 0xbc }
                  break;
     case 0xbd:   _asm { int 0xbd }
                  break;
     case 0xbe:   _asm { int 0xbe }
                  break;
     case 0xbf:   _asm { int 0xbf }
                  break;

     case 0xc0:   _asm { int 0xc0 }
                  break;
     case 0xc1:   _asm { int 0xc1 }
                  break;
     case 0xc2:   _asm { int 0xc2 }
                  break;
     case 0xc3:   _asm { int 0xc3 }
                  break;
     case 0xc4:   _asm { int 0xc4 }
                  break;
     case 0xc5:   _asm { int 0xc5 }
                  break;
     case 0xc6:   _asm { int 0xc6 }
                  break;
     case 0xc7:   _asm { int 0xc7 }
                  break;
     case 0xc8:   _asm { int 0xc8 }
                  break;
     case 0xc9:   _asm { int 0xc9 }
                  break;
     case 0xca:   _asm { int 0xca }
                  break;
     case 0xcb:   _asm { int 0xcb }
                  break;
     case 0xcc:   _asm { int 0xcc }
                  break;
     case 0xcd:   _asm { int 0xcd }
                  break;
     case 0xce:   _asm { int 0xce }
                  break;
     case 0xcf:   _asm { int 0xcf }
                  break;

     case 0xd0:   _asm { int 0xd0 }
                  break;
     case 0xd1:   _asm { int 0xd1 }
                  break;
     case 0xd2:   _asm { int 0xd2 }
                  break;
     case 0xd3:   _asm { int 0xd3 }
                  break;
     case 0xd4:   _asm { int 0xd4 }
                  break;
     case 0xd5:   _asm { int 0xd5 }
                  break;
     case 0xd6:   _asm { int 0xd6 }
                  break;
     case 0xd7:   _asm { int 0xd7 }
                  break;
     case 0xd8:   _asm { int 0xd8 }
                  break;
     case 0xd9:   _asm { int 0xd9 }
                  break;
     case 0xda:   _asm { int 0xda }
                  break;
     case 0xdb:   _asm { int 0xdb }
                  break;
     case 0xdc:   _asm { int 0xdc }
                  break;
     case 0xdd:   _asm { int 0xdd }
                  break;
     case 0xde:   _asm { int 0xde }
                  break;
     case 0xdf:   _asm { int 0xdf }
                  break;

     case 0xe0:   _asm { int 0xe0 }
                  break;
     case 0xe1:   _asm { int 0xe1 }
                  break;
     case 0xe2:   _asm { int 0xe2 }
                  break;
     case 0xe3:   _asm { int 0xe3 }
                  break;
     case 0xe4:   _asm { int 0xe4 }
                  break;
     case 0xe5:   _asm { int 0xe5 }
                  break;
     case 0xe6:   _asm { int 0xe6 }
                  break;
     case 0xe7:   _asm { int 0xe7 }
                  break;
     case 0xe8:   _asm { int 0xe8 }
                  break;
     case 0xe9:   _asm { int 0xe9 }
                  break;
     case 0xea:   _asm { int 0xea }
                  break;
     case 0xeb:   _asm { int 0xeb }
                  break;
     case 0xec:   _asm { int 0xec }
                  break;
     case 0xed:   _asm { int 0xed }
                  break;
     case 0xee:   _asm { int 0xee }
                  break;
     case 0xef:   _asm { int 0xef }
                  break;

     case 0xf0:   _asm { int 0xf0 }
                  break;
     case 0xf1:   _asm { int 0xf1 }
                  break;
     case 0xf2:   _asm { int 0xf2 }
                  break;
     case 0xf3:   _asm { int 0xf3 }
                  break;
     case 0xf4:   _asm { int 0xf4 }
                  break;
     case 0xf5:   _asm { int 0xf5 }
                  break;
     case 0xf6:   _asm { int 0xf6 }
                  break;
     case 0xf7:   _asm { int 0xf7 }
                  break;
     case 0xf8:   _asm { int 0xf8 }
                  break;
     case 0xf9:   _asm { int 0xf9 }
                  break;
     case 0xfa:   _asm { int 0xfa }
                  break;
     case 0xfb:   _asm { int 0xfb }
                  break;
     case 0xfc:   _asm { int 0xfc }
                  break;
     case 0xfd:   _asm { int 0xfd }
                  break;
     case 0xfe:   _asm { int 0xfe }
                  break;
     case 0xff:   _asm { int 0xff }
                  break;

  }
}

/****************************************************************************
    Function:
              HdwSimDeviceControl
    Arguments:

    Description:

    Returns:


*****************************************************************************/
NTSTATUS  HdwSimDeviceControl(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp )
{
    NTSTATUS  ret = STATUS_SUCCESS;

    PIO_STACK_LOCATION irpStack;

    HDW_SIM_DATA_OUTPUT  *pOutBuffer;
    HDW_SIM_DATA_INPUT   *pInBuffer;

    PHDW_SIM_DEVICE_EXTENSION extension;

    NTSTATUS status;


    extension = DeviceObject->DeviceExtension;

    if(extension->debugMask & (DEBUGMASK_TRACE_IOCTLS | DEBUGMASK_TRACE_REGISTERS))
       { /* trace */
	KdPrint( ("%s  Device Control!!\n", DBG_MSG_HDR) );
       } /* trace */


    irpStack = IoGetCurrentIrpStackLocation(Irp);

    pInBuffer = (HDW_SIM_DATA_INPUT *)Irp->AssociatedIrp.SystemBuffer;  // for buffered i/o
    pOutBuffer = (HDW_SIM_DATA_OUTPUT *)Irp->AssociatedIrp.SystemBuffer;  // for buffered i/o

    switch(irpStack->Parameters.DeviceIoControl.IoControlCode)
    {

        case  IOCTL_HDW_SIM_SET_TRACE:
		KdPrint( ("%s  Device Control -- enter IOCTL_HDW_SIM_SET_TRACE\n", DBG_MSG_HDR) );
		extension->debugMask = pInBuffer->mask.value;

		Irp->IoStatus.Information = 0;
		break;

	case IOCTL_HDW_SIM_GET_TRACE:
		if(extension->debugMask & DEBUGMASK_TRACE_IOCTLS)
		   { /* trace */
		    
		    KdPrint( ("%s  Device Control -- enter IOCTL_HDW_SIM_GET_TRACE\n", DBG_MSG_HDR) );
		   } /* trace */

		pOutBuffer->mask.value = extension->debugMask;

		Irp->IoStatus.Information = 0;
		break;

        case  IOCTL_HDW_SIM_INITIALIZE:
		if(extension->debugMask & DEBUGMASK_TRACE_IOCTLS)
		   { /* trace */
		    KdPrint( ("%s  Device Control  -- enter IOCTL_HDW_SIM_INITIALIZE\n", DBG_MSG_HDR) );
		   } /* trace */

             Irp->IoStatus.Information = 0;
             break;

        case IOCTL_HDW_SIM_SET_INTR: 
		if(extension->debugMask & DEBUGMASK_TRACE_IOCTLS)
		   { /* trace */
		    KdPrint( ("%s Device Control  -- enter IOCTL_HDW_SIM_SET_INTR\n", DBG_MSG_HDR) );
		   } /* trace */
             
             extension->interrupt_Line = pInBuffer->setInterrupt.interrupt_Line ;
 
             extension->Level  = extension->interrupt_Line;
             extension->Vector = extension->interrupt_Line;

             extension->mappedSysVect = HalGetInterruptVector(Isa,
                                              0,                            // BusNumber,
                                              extension->Level,       // Level
                                              extension->Vector,      // Vector,
                                              &extension->irql,       // IRQL
                                              &extension->Affinity);  // Affinity mask

             //
             // Save mapping in registry
             //
        
             ret = saveConfig( extension->ephemeralRegistryPath.Buffer,
	                           extension->interrupt_Line,
	                           extension->interrupt_IDT,
	                           (VOID *)extension->pSimulatedRegisterLogicalAddress,
                          	   extension->pSimulatedRegisterPhysicalAddress
                             );
             Irp->IoStatus.Information = 0;

             break;

        case IOCTL_HDW_SIM_REGS: 
		if(extension->debugMask & DEBUGMASK_TRACE_IOCTLS)
		   { /* trace */
		    KdPrint( ("%s  Device Control  -- enter IOCTL_HDW_SIM_REGS\n", DBG_MSG_HDR) );
		   } /* trace */
               {
         
                HDW_SIM_REGS inBuf = pInBuffer->registers;   // COPY new register contents from Ap
                                                             // they will be overwritten before we are ready for them

             
		if(extension->debugMask & DEBUGMASK_TRACE_REGISTERS)
		   { /* trace */
		    KdPrint(("%s  Regs - inCommand  inStatus  inData outCommand outStatus outData\n", DBG_MSG_HDR));             
		    KdPrint(("%s  Regs - initial state = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x \n", DBG_MSG_HDR, 
                          extension->simulatedRegister[INDEX_inCommand  ],
                          extension->simulatedRegister[INDEX_inStatus   ],
                          extension->simulatedRegister[INDEX_inData     ],
                          extension->simulatedRegister[INDEX_outCommand ],
                          extension->simulatedRegister[INDEX_outStatus  ],
                          extension->simulatedRegister[INDEX_outData    ]));
                
                           
                    KdPrint(("%s  Regs - specified  write mask = 0x%02x  \n", DBG_MSG_HDR,   inBuf.writeBitmap ));
                    KdPrint(("%s  Regs - specified     = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x \n", DBG_MSG_HDR,                    inBuf.registers[INDEX_inCommand ], 
                                inBuf.registers[INDEX_inStatus  ], 
                                inBuf.registers[INDEX_inData    ], 
                                inBuf.registers[INDEX_outCommand],
                                inBuf.registers[INDEX_outStatus ], 
                                inBuf.registers[INDEX_outData   ])); 
		   } /* trace */
             
                //?? TO DO ?? get spin lock
                
                pOutBuffer->registers.registers[INDEX_inCommand ] =  extension->simulatedRegister[INDEX_inCommand  ] ;
                pOutBuffer->registers.registers[INDEX_inStatus  ] =  extension->simulatedRegister[INDEX_inStatus   ] ;
                pOutBuffer->registers.registers[INDEX_inData    ] =  extension->simulatedRegister[INDEX_inData     ] ;
                pOutBuffer->registers.registers[INDEX_outCommand] =  extension->simulatedRegister[INDEX_outCommand ] ;
                pOutBuffer->registers.registers[INDEX_outStatus ] =  extension->simulatedRegister[INDEX_outStatus  ] ;
                pOutBuffer->registers.registers[INDEX_outData   ] =  extension->simulatedRegister[INDEX_outData    ] ;
                                       
                pOutBuffer->registers.interrupt_Line  =  extension->interrupt_Line;                      
                pOutBuffer->registers.interrupt_IDT   =  extension->interrupt_IDT;
 
                if (writeBitmap_inCommand       & inBuf.writeBitmap)
                {
                   extension->simulatedRegister[ INDEX_inCommand] = inBuf.registers[INDEX_inCommand];
                }
                if (writeBitmap_inStatus   & inBuf.writeBitmap)
                {
                   extension->simulatedRegister[ INDEX_inStatus] = inBuf.registers[INDEX_inStatus];
                }
                if (writeBitmap_inData     & inBuf.writeBitmap)
                {
                   extension->simulatedRegister[ INDEX_inData] = inBuf.registers[INDEX_inData];
                }
                if (writeBitmap_outCommand & inBuf.writeBitmap)
                {
                   extension->simulatedRegister[ INDEX_outCommand] = inBuf.registers[INDEX_outCommand];
                }
                if (writeBitmap_outStatus  & inBuf.writeBitmap)
                {
                   extension->simulatedRegister[ INDEX_outStatus] = inBuf.registers[INDEX_outStatus];
                }
                if (writeBitmap_outData    & inBuf.writeBitmap)
                {
                   extension->simulatedRegister[ INDEX_outData] = inBuf.registers[INDEX_outData];
                }


	        if(extension->debugMask & DEBUGMASK_TRACE_REGISTERS)
		   { /* trace */
		    KdPrint(("%s  Regs - final state   = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x \n", DBG_MSG_HDR,   
                          extension->simulatedRegister[INDEX_inCommand  ],
                          extension->simulatedRegister[INDEX_inStatus   ],
                          extension->simulatedRegister[INDEX_inData     ],
                          extension->simulatedRegister[INDEX_outCommand ],
                          extension->simulatedRegister[INDEX_outStatus  ],
                          extension->simulatedRegister[INDEX_outData    ]));
		   } /* trace */
            
                Irp->IoStatus.Information = sizeof(HDW_SIM_REGS);

             } 

             break;

        case IOCTL_HDW_SIM_GEN_INTR:       
             KdPrint( ("%s  Device Control  -- enter IOCTL_HDW_SIM_GEN_INTR\n", DBG_MSG_HDR) );
             generateInterrupt((UCHAR)extension->interrupt_IDT);
           break;
        default:

             ret = STATUS_UNSUCCESSFUL;

    }
    if(extension->debugMask & DEBUGMASK_TRACE_IOCTLS)
    { /* print */
         KdPrint( ("%s  Device Control  -- return\n", DBG_MSG_HDR) );
    } /* print */
    //
    // Fill these in before calling IoCompleteRequest.
    //

    Irp->IoStatus.Status = ret;

    IoCompleteRequest( Irp, IO_NO_INCREMENT );


    return ret;
}

VOID HdwSimUnload( IN PDRIVER_OBJECT DriverObject)
{
    UNICODE_STRING uniDosNameString;  
    PHDW_SIM_DEVICE_EXTENSION extension;
    NTSTATUS status;
    
    extension = DriverObject->DeviceObject->DeviceExtension;

    //
    // All *THIS* driver needs to do is to delete the allocated memory objects,
    // the device object and the
    // symbolic link between our device name and the Win32 visible name.
    //
    // Almost every other driver ever witten would need to do a
    // significant amount of work here deallocating stuff.
    //

    KdPrint( ("%s  Unloading!!\n", DBG_MSG_HDR) );




   // ????  iterate over all deviceObjects linked to the driver object
//   ExFreePool(extension->pSimulatedRegisterLogicalAddress);


   	    //
		// Free ephemeral registry entries
		//

		if (extension->ephemeralRegistryPath.Buffer)
		{
			HANDLE hKey;

            //
            //  Free devices key
            //

            if (NT_SUCCESS(OpenDevicesKey(extension->ephemeralRegistryPath.Buffer, &hKey)))
			{
				// Delete the open key from the registry
                
				ZwDeleteKey(hKey);
                
				// Close object handles. A named object is not actually deleted until all
				// of its valid handles are closed and no referenced pointers remain.

				ZwClose(hKey);
                KdPrint( ("%s Deleted ephemeral key\n", DBG_MSG_HDR) );
            }
            else
            {
                KdPrint( ("%s can't open ephemeral key\n", DBG_MSG_HDR) );            
            }

//            ExFreePool(extension->ephemeralRegistryPath.Buffer);
        }

    //
    // We don't need the path anymore.
    //
    
    ExFreePool(extension->parameterRegistryPath.Buffer);

    ExFreePool(extension->registryPathName.Buffer);
    
    


    //
    // Create counted string version of our Win32 device name.
    //

    RtlInitUnicodeString( &uniDosNameString, DOS_DEVICE_NAME );

    //
    // Delete the link from our device name to a name in the Win32 namespace.
    //

    IoDeleteSymbolicLink( &uniDosNameString );

    //
    // Finally delete our device object
    //

    IoDeleteDevice( DriverObject->DeviceObject );
}
