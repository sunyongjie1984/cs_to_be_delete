// HdwTrace.cpp : implementation file
//

#include "stdafx.h"
#include <winioctl.h>

#include "register.h"
#include "Simulator.h"
#include "HdwTrace.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHdwTrace dialog


CHdwTrace::CHdwTrace(CWnd* pParent /*=NULL*/)
	: CDialog(CHdwTrace::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHdwTrace)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CHdwTrace::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHdwTrace)
	DDX_Control(pDX, IDC_IOCTLS, c_IoctlTrace);
	DDX_Control(pDX, IDC_REGS, c_RegTrace);
	DDX_Control(pDX, IDOK, c_OK);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CHdwTrace, CDialog)
	//{{AFX_MSG_MAP(CHdwTrace)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHdwTrace message handlers

void CHdwTrace::OnOK() 
{
 	DWORD mask = registers->getTrace();
	mask &= ~(DEBUGMASK_TRACE_REGISTERS | DEBUGMASK_TRACE_IOCTLS);
	if(c_IoctlTrace.GetCheck() == BST_CHECKED)
	   mask |= DEBUGMASK_TRACE_IOCTLS;
        if(c_RegTrace.GetCheck() == BST_CHECKED)
	   mask |= DEBUGMASK_TRACE_REGISTERS;

	registers->setTrace(mask);
	
	CDialog::OnOK();
}

BOOL CHdwTrace::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
 	if(registers == NULL)
	   { /* whoops */
	    c_IoctlTrace.EnableWindow(FALSE);
	    c_RegTrace.EnableWindow(FALSE);
	    c_OK.EnableWindow(FALSE);
	   } /* whoops */
	else
	   { /* ok */
	    DWORD mask = registers->getTrace();
	    c_IoctlTrace.SetCheck( (mask & DEBUGMASK_TRACE_IOCTLS) 
	    				? BST_CHECKED
					: BST_UNCHECKED);
	    c_RegTrace.SetCheck( (mask & DEBUGMASK_TRACE_REGISTERS)
	    				? BST_CHECKED
					: BST_UNCHECKED);
	   } /* ok */
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
