// HdwSimDriver
#define REG_DBG             (L"DebugMask")
#define REG_EVENT           (L"LogEvents")
#define REG_BREAK           (L"BreakOnEntry")
#define REG_INTLINE         (L"InterruptLine")
#define REG_DEFAULT_INTLINE (L"DefaultInterruptLine")
#define REG_INTIDT          (L"InterruptIDT")
#define REG_BUF_LOG_ADDRESS      (L"BufferLogicalAddress")
#define REG_BUF_PHYS_ADDRESS_LO  (L"BufferPhysicalAddressLow")
#define REG_BUF_PHYS_ADDRESS_HI  (L"BufferPhysicalAddressHigh")

#define REG_PATHNAME        (L"PathName")
    
#define PARMS_SUBKEY        (L"\\Parameters")
#define EPHEMERAL_SUBKEY    (L"\\Ephemeral")
#define DEVICES_SUBKEY      (L"Devices")
#define DRIVER_PARMS        (L"DriverParameters")

 NTSTATUS readRegistry(
    IN PDRIVER_OBJECT DriverObject,   // Driver object
    IN PUNICODE_STRING path,          // base path to keys
    OUT PULONG debugMask,             // 32-bit binary debug mask
    OUT PULONG eventLog,              // Boolean: do we log events?
    OUT PULONG shouldBreak,           // Boolean: break in DriverEntry?
    OUT PULONG interrupt_Line
    );
NTSTATUS OpenDevicesKey(
    IN   PWSTR RegistryPathName,
    OUT  PHANDLE DevicesKey
);

NTSTATUS WriteRegistryDWORD(
    IN   PCWSTR RegistryPath,
    IN   PCWSTR ValueName,
    IN   ULONG  Value
    );
    
NTSTATUS saveConfig(
    IN	PWSTR registryPath,
	IN	ULONG interrupt_Line,
	IN	ULONG interrupt_IDT,
	IN	VOID * registersLogicalAddress,
	IN	PHYSICAL_ADDRESS registersPhysicalAddress    
    );
    
NTSTATUS initDevicePath(
       IN PDRIVER_OBJECT DriverObject,
       IN PUNICODE_STRING  inPath,    // zero terminated UNICODE_STRING with parameters path 
       UNICODE_STRING * ephemeralRegistryPath,
       UNICODE_STRING * parameterRegistryPath,
       UNICODE_STRING * registryPathName
       );
       
NTSTATUS TargetReadRegistry(
    IN PDRIVER_OBJECT DriverObject,   // Driver object
    IN PUNICODE_STRING path,          // base path to keys
    OUT PULONG debugMask,             // 32-bit binary debug mask
    OUT PULONG eventLog,              // Boolean: do we log events?
    OUT PULONG shouldBreak,           // Boolean: break in DriverEntry?
    OUT PULONG interrupt_Line,
    OUT PUCHAR registerArray,
    OUT PHYSICAL_ADDRESS *registerPhysicalAddress    
        );
