/*****************************************************************************
*           Change Log
*  Date     | Change
*-----------+-----------------------------------------------------------------
*****************************************************************************/
                                            

typedef struct _HDW_SIM_DEVICE_EXTENSION {
    PDEVICE_OBJECT      DeviceObject;
    ULONG               InterruptCount;
    
    ULONG               Level;             // Level
    ULONG               Vector;            // Vector
    KAFFINITY           Affinity;          // Affinity

    PCM_RESOURCE_LIST  *pResources;

    PVOID               DMARegisterSystemVirtualAddr;   // system address of 

    KSPIN_LOCK          ISRSpinLock;
    PKINTERRUPT         InterruptObject;   // Pointer to the Interrupt Object
    ULONG               mappedSysVect;
                                                

     UNICODE_STRING     ephemeralRegistryPath;
     UNICODE_STRING     parameterRegistryPath;
     UNICODE_STRING     registryPathName;
     
    //
    // Virtual Registers
    //
    void *              pSimulatedRegisterLogicalAddress;    
//    void *              registers;   // defined in HdwSimIoctl.h
    PHYSICAL_ADDRESS    pSimulatedRegisterPhysicalAddress;        
    //
    //  Register spinlock
    //
    BOOLEAN             spin;
    KSPIN_LOCK          registerLock;
    ULONG               interruptLine;
    ULONG               interruptIDT;

    KIRQL               irql;


} HDW_SIM_DEVICE_EXTENSION;
typedef HDW_SIM_DEVICE_EXTENSION *PHDW_SIM_DEVICE_EXTENSION;






