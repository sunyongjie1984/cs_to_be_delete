// Hardware Simulator Registry access routine
/*****************************************************************************
*           Change Log
*  Date     | Change
*-----------+-----------------------------------------------------------------
  06-01-97     create log
*****************************************************************************/

/*****************************************************************************
*           To DO
*-----------------------------------------------------------------------------


*****************************************************************************/


#define BYTE UCHAR
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


Module Name:

    HSTestReadReg.c

Abstract:


Author:

    Edward Dekker

Environment:

    kernel mode only

Notes:

--------------------------------------------------------------------*/


#include "ntddk.h"
#include "HSTestReadReg.h"

#define DBG_MSG_HDR "Lab2 (HSTestReadReg)"



NTSTATUS hardwareSimReadRegistry(
    IN PDRIVER_OBJECT DriverObject,   // Driver object
    IN PUNICODE_STRING RegistryPath,     // base path to keys
    OUT PULONG interruptLine,
    OUT PULONG interruptIDT,
    OUT VOID  *registerAddress,
    OUT PHYSICAL_ADDRESS *registerPhysicalAddress
        )
{
   //
   // We use this to query into the registry as to get initializationa and
   // debug information for our driver
   //
   RTL_QUERY_REGISTRY_TABLE eParamTable[8]; // Parameter table -- epheral key of simulator
   ULONG zero = 0;                          // default value 0
   ULONG one = 1;                           // default value 1
   ULONG sixteenK = 16 * 1024;              // default value for 16K
   ULONG notConfigurable = 0;
   PWCHAR path;                             // the Registry path   
   NTSTATUS status = STATUS_SUCCESS;   // assume failure
   // We set these values to their defaults in case there are any failures

   UNICODE_STRING systemPath;
   ULONG pathLength;                        // length to allocate for path

   HANDLE  hKey;
   OBJECT_ATTRIBUTES  objectAttributes;

   UNICODE_STRING       ephemeralRegistryPath;

     

    
   RtlZeroMemory(&eParamTable[0], sizeof(eParamTable)); // mandatory
   
   eParamTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
   eParamTable[0].Name = REG_INTLINE ;
   eParamTable[0].EntryContext = interruptLine;
   eParamTable[0].DefaultType = REG_DWORD;
   eParamTable[0].DefaultData = &zero;
   eParamTable[0].DefaultLength = sizeof(ULONG);

   eParamTable[1].Flags = RTL_QUERY_REGISTRY_DIRECT;
   eParamTable[1].Name = REG_INTIDT ;
   eParamTable[1].EntryContext = interruptIDT;
   eParamTable[1].DefaultType = REG_DWORD;
   eParamTable[1].DefaultData = &zero;
   eParamTable[1].DefaultLength = sizeof(ULONG);
                 
   eParamTable[2].Flags = RTL_QUERY_REGISTRY_DIRECT;
   eParamTable[2].Name = REG_BUF_LOG_ADDRESS;
   eParamTable[2].EntryContext = registerAddress;
   eParamTable[2].DefaultType = REG_DWORD;
   eParamTable[2].DefaultData = &zero;
   eParamTable[2].DefaultLength = sizeof(ULONG);

   eParamTable[3].Flags = RTL_QUERY_REGISTRY_DIRECT;
   eParamTable[3].Name = REG_BUF_PHYS_ADDRESS_LO ;
   eParamTable[3].EntryContext = &registerPhysicalAddress->LowPart;
   eParamTable[3].DefaultType = REG_DWORD;
   eParamTable[3].DefaultData = &zero;
   eParamTable[3].DefaultLength = sizeof(ULONG);

   eParamTable[4].Flags = RTL_QUERY_REGISTRY_DIRECT;
   eParamTable[4].Name =  REG_BUF_PHYS_ADDRESS_HI ;
   eParamTable[4].EntryContext = &registerPhysicalAddress->HighPart;
   eParamTable[4].DefaultType = REG_DWORD;
   eParamTable[4].DefaultData = &zero;
   eParamTable[4].DefaultLength = sizeof(ULONG);


   KdPrint(("%s: Parameter table set\n", DBG_MSG_HDR));



   RtlInitUnicodeString (&ephemeralRegistryPath,
          L"\\REGISTRY\\Machine\\System\\CurrentControlSet\\Services\\HdwSim\\Ephemeral" );
//        RtlAppendUnicodeToString(ephemeralRegistryPath, EPHEMERAL_SUBKEY);

   InitializeObjectAttributes(&objectAttributes,
                         &ephemeralRegistryPath,
                         OBJ_CASE_INSENSITIVE,
                         NULL,
                         (PSECURITY_DESCRIPTOR)NULL);

   KdPrint(("%s: Before open key\n", DBG_MSG_HDR));

   if (!NT_SUCCESS( status = ZwOpenKey(&hKey, KEY_QUERY_VALUE,
                 &objectAttributes)))
   {
      KdPrint(("%s: ZwOpenKey failed status = 0x%x\n", DBG_MSG_HDR, status));
   }

   if (!NT_SUCCESS( status =
               RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE | RTL_REGISTRY_OPTIONAL,
                                       ephemeralRegistryPath.Buffer,
                                         &eParamTable[0],
                                         NULL,
                                         NULL)))
   {
      KdPrint( ("readReg (2): Failed return uncessful %s\n", status) );
      return  ( status);
   }


   KdPrint(("%s: ephemeralRegistryPath = %S\n", DBG_MSG_HDR,  ephemeralRegistryPath.Buffer));


   KdPrint(("%s  TargetReadRegistry - interruptLine   = 0x%08x\n", DBG_MSG_HDR,   *interruptLine ));
   KdPrint(("%s  TargetReadRegistry - interruptIDT    = 0x%08x\n", DBG_MSG_HDR,   *interruptIDT ));
   KdPrint(("%s  TargetReadRegistry - registerAddress = 0x%08x\n", DBG_MSG_HDR,   *(ULONG *)registerAddress));
   KdPrint(("%s  TargetReadRegistry - PhysicalAddress= 0x%08x 0x%08x\n", DBG_MSG_HDR,  
                                registerPhysicalAddress->HighPart,  registerPhysicalAddress->LowPart));

     return  ( status);
}
