/*****************************************************************************
*           Change Log
*  Date     | Change
*-----------+-----------------------------------------------------------------
* 20-Mar-99 | Created
* 20-Mar-99 | WORD => UINT for registered window messages
* 20-Mar-99 | Added RST handlers
*****************************************************************************/
// SimulatorDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Simulator.h"
#include <sys\timeb.h>
#include "TraceWnd.h"
#include "Regvars.h"
#include "NumericEdit.h"
  #include "InterruptMgt.h"
#include "SpinnerButton.h"
#include "register.h"
#include "RegData.h"
  #include "RegDisplay.h"
    #include "SimulatorDlg.h"
#include "buzzword.h"
#include "SetupDlg.h"
#include "About.h"
#include "comment.h"
#include "HdwTrace.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/****************************************************************************
*                                  UWM_PULSE
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: LRESULT
*       Logically void, 0, always
* Effect: 
*       Indicates a single polling operation has started
****************************************************************************/

UINT UWM_PULSE = ::RegisterWindowMessage(
	             _T("UWM_PULSE-{71EDE612-AC36-11d1-8369-00AA005C0507}"));



/****************************************************************************
*                                  UWM_POLL
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: LRESULT
*       Logically void, 0, always
* Effect: 
*       Starts the polling operation in the main thread
****************************************************************************/

UINT UWM_POLL = ::RegisterWindowMessage(
	              _T("UWM_POLL-{71EDE612-AC36-11d1-8369-00AA005C0507}"));



/****************************************************************************
*			       UWM_SET_TIMER_OUT
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: LRESULT
*       Logically void, 0, always
* Effect: 
*       Starts a Go->Done output timer
****************************************************************************/

UINT UWM_SET_TIMER_OUT = ::RegisterWindowMessage(
	     _T("UWM_SET_TIMER_OUT-{71EDE612-AC36-11d1-8369-00AA005C0507}"));



/****************************************************************************
*			       UWM_SET_TIMER_IN
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: LRESULT
*       Logically void, 0, always
* Effect: 
*       Starts a GO->Done input timer
****************************************************************************/

UINT UWM_SET_TIMER_IN = ::RegisterWindowMessage(
               _T("UWM_SET_TIMER_IN-{71EDE612-AC36-11d1-8369-00AA005C0507}"));



/****************************************************************************
*			       UWM_SET_MANUAL_MODE
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: LRESULT
*       Logically void, 0, always
* Effect: 
*       Deferred Manual Mode request (handles queueing deadlock problem)
****************************************************************************/

UINT UWM_SET_MANUAL_MODE = ::RegisterWindowMessage(
           _T("UWM_SET_MANUAL_MODE-{71EDE612-AC36-11d1-8369-00AA005C0507}"));



/****************************************************************************
*                            UWM_OPEN_FAILED
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: LRESULT
*       0, always (logically void)
* Effect: 
*       Handles notification that the open of the device failed
****************************************************************************/

UINT UWM_OPEN_FAILED = ::RegisterWindowMessage(
               _T("UWM_OPEN_FAILED-{15B50870-B191-11d1-836A-00AA005C0507}"));


/****************************************************************************
*                            UWM_IMGR_CLOSE
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: LRESULT
*       0, always (logically void)
* Effect: 
*       Handles notification that the interrupt/error manager has closed
****************************************************************************/

UINT UWM_IMGR_CLOSE = ::RegisterWindowMessage(
                _T("UWM_IMGR_CLOSE-{15B50870-B191-11d1-836A-00AA005C0507}"));


/****************************************************************************
*                            UWM_REG_CLOSE
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: LRESULT
*       0, always (logically void)
* Effect: 
*       Handles notification that the register display has closed
****************************************************************************/

UINT UWM_REG_CLOSE = ::RegisterWindowMessage(
                 _T("UWM_REG_CLOSE-{15B50870-B191-11d1-836A-00AA005C0507}"));


/****************************************************************************
*                            UWM_UPDATE_REGS
* Inputs:
*       WPARAM: ignored
*	LPARAM: (LPARAM)(HDW_SIM_REGS)
* Result: LRESULT
*       0, always (logically void)
* Effect: 
*       Handles notification that the register display has closed
****************************************************************************/

UINT UWM_UPDATE_REGS = ::RegisterWindowMessage(
               _T("UWM_UPDATE_REGS-{15B50870-B191-11d1-836A-00AA005C0507}"));


/****************************************************************************
*                                 UWM_GO_HACK_IN
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: void
*       LRESULT 0
* Effect: 
*       The "Go" output bit has been set; initiate the action sequence required
*	to complete the GO action
****************************************************************************/

UINT UWM_GO_HACK_IN = ::RegisterWindowMessage(
                 _T("UWM_GO_HACK_IN-{71EDE610-AC36-11d1-8369-00AA005C0507}"));


/****************************************************************************
*                                 UWM_GO_HACK_OUT
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: void
*       LRESULT 0
* Effect: 
*       The "Go" output bit has been set; initiate the action sequence required
*	to complete the GO action
****************************************************************************/

UINT UWM_GO_HACK_OUT = ::RegisterWindowMessage(
                _T("UWM_GO_HACK_OUT-{71EDE610-AC36-11d1-8369-00AA005C0507}"));


/****************************************************************************
*				 UWM_SET_PROB
* Inputs:
*       WPARAM: code which indicates what probability variable is being updated
*	LPARAM: value which is to be set
* Result: void
*       LRESULT 0
* Notes: 
*       Sent from the InterruptMgt modeless dialog to its parent
****************************************************************************/

UINT UWM_SET_PROB = ::RegisterWindowMessage(
                  _T("UWM_SET_PROB-{71EDE610-AC36-11d1-8369-00AA005C0507}"));

// The Messages below are nominally obsolete (wait for next set of tests)

/****************************************************************************
*                                 UWM_GO_OUT_SET
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: void
*       LRESULT 0
* Effect: 
*       The "Go" output bit has been set; initiate the action sequence required
*	to complete the GO action
****************************************************************************/

UINT UWM_GO_OUT_SET = ::RegisterWindowMessage(
                _T("UWM_GO_OUT_SET-{71EDE610-AC36-11d1-8369-00AA005C0507}"));


/****************************************************************************
*                                 UWM_GO_IN_SET
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: void
*       LRESULT 0
* Effect: 
*       The "Go" output bit has been set; initiate the action sequence required
*	to complete the GO action
****************************************************************************/

UINT UWM_GO_IN_SET = ::RegisterWindowMessage(
                  _T("UWM_GO_IN_SET-{71EDE610-AC36-11d1-8369-00AA005C0507}"));


/****************************************************************************
*                                 UWM_IACK_OUT_SET
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: void
*       LRESULT 0
* Effect: 
*       The "IACK" output bit has been set; initiate the action sequence
*       required to complete the IACK action
****************************************************************************/

UINT UWM_IACK_OUT_SET = ::RegisterWindowMessage(
              _T("UWM_IACK_OUT_SET-{71EDE610-AC36-11d1-8369-00AA005C0507}"));


/****************************************************************************
*                                 UWM_IACK_IN_SET
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: void
*       LRESULT 0
* Effect: 
*       The "IACK" output bit has been set; initiate the action sequence
*       required to complete the IACK action
****************************************************************************/

UINT UWM_IACK_IN_SET = ::RegisterWindowMessage(
               _T("UWM_IACK_IN_SET-{71EDE610-AC36-11d1-8369-00AA005C0507}"));

/****************************************************************************
*                                 UWM_RST_OUT_SET
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: void
*       LRESULT 0
* Effect: 
*       The "RST" output bit has been set; initiate the action sequence
*       required to complete the RST action
****************************************************************************/

UINT UWM_RST_OUT_SET = ::RegisterWindowMessage(
		_T("UWM_RST_OUT_SET-{71EDE610-AC36-11d1-8369-00AA005C0507}"));


/****************************************************************************
*                                 UWM_RST_IN_SET
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: void
*       LRESULT 0
* Effect: 
*       The "RST" output bit has been set; initiate the action sequence
*       required to complete the RST action
****************************************************************************/

UINT UWM_RST_IN_SET = ::RegisterWindowMessage(
 	       _T("UWM_RST_IN_SET-{71EDE610-AC36-11d1-8369-00AA005C0507}"));

/****************************************************************************
*                             UWM_UPDATE_CONTROLS
* Inputs:
*       WPARAM: ignored
*	LPARAM: ignored
* Result: void
*       0
* Effect: 
*       Notifies the main thread to update the control status
****************************************************************************/

UINT UWM_UPDATE_CONTROLS = ::RegisterWindowMessage(
           _T("UWM_UPDATE_CONTROLS-{71EDE611-AC36-11d1-8369-00AA005C0507}"));

UINT UWM_IE_IN_SET = ::RegisterWindowMessage(
	         _T("UWM_IE_IN_SET-{71EDE612-AC36-11d1-8369-00AA005C0507}"));

UINT UWM_IE_OUT_SET = ::RegisterWindowMessage(
	        _T("UWM_IE_OUT_SET-{71EDE612-AC36-11d1-8369-00AA005C0507}"));
/////////////////////////////////////////////////////////////////////////////
// CSimulatorDlg dialog

/****************************************************************************
*                        CSimulatorDlg::CSimulatorDlg
* Inputs:
*       CWnd * parent:
* Effect: 
*       Constructor
****************************************************************************/

CSimulatorDlg::CSimulatorDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSimulatorDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSimulatorDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	pollthread = NULL;
	polling = FALSE;
	pollInterval = 50; // 50ms unless otherwise specified
	imgr = NULL;
	regdisp = NULL;
	err = FALSE;
	debug = FALSE;
	manual = TRUE;
	singleStep = FALSE;
	GoDoneMinimum = 100;  // no particular reason, sounds like good default
	GoDoneVariance = 250; // no particular reason, sounds like good default
	ProbErr = 0;
	ProbLost = 0;
	ProbSpurious = 0;
	ProbOvrUnd = 0;
}

void CSimulatorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSimulatorDlg)
	DDX_Control(pDX, IDC_SINGLESTEP, c_SingleStep);
	DDX_Control(pDX, IDC_GETSTATE, c_GetState);
	DDX_Control(pDX, IDC_IACK_OUT, c_IACKOut);
	DDX_Control(pDX, IDC_IACK_IN, c_IACKIn);
	DDX_Control(pDX, IDC_GO_HACK_IN, c_GoHackIn);
	DDX_Control(pDX, IDC_GO_HACK_OUT, c_GoHackOut);
	DDX_Control(pDX, IDC_INTERRUPT, c_Interrupt);
	DDX_Control(pDX, IDC_TRANSFER, c_Transfer);
	DDX_Control(pDX, IDC_INT, c_Int);
	DDX_Control(pDX, IDC_OVR_IN, c_OvrIn);
	DDX_Control(pDX, IDC_UND_OUT, c_UndOut);
	DDX_Control(pDX, IDC_OVRUND, c_OverUnder);
	DDX_Control(pDX, IDC_INT_OUT, c_IntOut);
	DDX_Control(pDX, IDC_INT_IN, c_IntIn);
	DDX_Control(pDX, IDC_IE_OUT, c_IEOut);
	DDX_Control(pDX, IDC_IE_IN, c_IEIn);
	DDX_Control(pDX, IDC_GO_OUT, c_GoOut);
	DDX_Control(pDX, IDC_GO_IN, c_GoIn);
	DDX_Control(pDX, IDC_ERRORS, c_Errors);
	DDX_Control(pDX, IDC_ERR_OUT, c_ErrOut);
	DDX_Control(pDX, IDC_ERR_IN, c_ErrIn);
	DDX_Control(pDX, IDC_EOP_IN, c_EopIn);
	DDX_Control(pDX, IDC_DONE_OUT, c_DoneOut);
	DDX_Control(pDX, IDC_BUSY_OUT, c_BusyOut);
	DDX_Control(pDX, IDC_DONE_IN, c_DoneIn);
	DDX_Control(pDX, IDC_GENERATE, c_Generate);
	DDX_Control(pDX, IDC_TRACE, c_Trace);
	DDX_Control(pDX, IDC_SEND, c_Send);
	DDX_Control(pDX, IDC_MANUAL, c_Manual);
	DDX_Control(pDX, IDC_FREERUN, c_FreeRun);
	DDX_Control(pDX, IDC_DATA, c_Data);
	DDX_Control(pDX, IDC_RST_IN, c_RSTIn);
	DDX_Control(pDX, IDC_RST_OUT, c_RSTOut);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSimulatorDlg, CDialog)
	//{{AFX_MSG_MAP(CSimulatorDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_COMMAND(ID_EDIT_CLEAR, OnClear)
	ON_BN_CLICKED(IDC_FREERUN, OnFreerun)
	ON_BN_CLICKED(IDC_MANUAL, OnManual)
	ON_BN_CLICKED(IDC_SEND, OnSend)
	ON_BN_CLICKED(IDC_BUSY_OUT, OnBusyOut)
	ON_CBN_SELENDOK(IDC_DATA, OnSelendokData)
	ON_WM_CLOSE()
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_BN_CLICKED(IDC_GENERATE, OnGenerate)
	ON_CBN_EDITCHANGE(IDC_DATA, OnEditchangeData)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_DONE_IN, OnDoneIn)
	ON_BN_CLICKED(IDC_DONE_OUT, OnDoneOut)
	ON_BN_CLICKED(IDC_EOP_IN, OnEopIn)
	ON_BN_CLICKED(IDC_ERR_IN, OnErrIn)
	ON_BN_CLICKED(IDC_ERR_OUT, OnErrOut)
	ON_BN_CLICKED(IDC_GO_IN, OnGoIn)
	ON_BN_CLICKED(IDC_GO_OUT, OnGoOut)
	ON_BN_CLICKED(IDC_IE_IN, OnIeIn)
	ON_BN_CLICKED(IDC_IE_OUT, OnIeOut)
	ON_BN_CLICKED(IDC_INT_IN, OnIntIn)
	ON_BN_CLICKED(IDC_INT_OUT, OnIntOut)
	ON_BN_CLICKED(IDC_OVR_IN, OnOvrIn)
	ON_BN_CLICKED(IDC_OVRUND, OnOvrund)
	ON_BN_CLICKED(IDC_UND_OUT, OnUndOut)
	ON_BN_CLICKED(IDC_INT, OnInt)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_EXIT, OnFileExit)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_HELP_INDEX, OnHelpIndex)
	ON_COMMAND(IDM_INTERRUPT_MGT, OnInterruptMgt)
	ON_COMMAND(IDM_SETUP_IRQ, OnSetupIrq)
	ON_BN_CLICKED(IDC_ERRORS, OnErrors)
	ON_BN_CLICKED(IDC_INTERRUPT, OnInterrupt)
	ON_WM_INITMENUPOPUP()
	ON_COMMAND(IDC_CLEAR_INPUT, OnClearInput)
	ON_COMMAND(IDM_DEBUG, OnDebug)
	ON_BN_CLICKED(IDC_GO_HACK_IN, OnGoHackIn)
	ON_BN_CLICKED(IDC_GO_HACK_OUT, OnGoHackOut)
	ON_BN_CLICKED(IDC_IACK_IN, OnIackIn)
	ON_BN_CLICKED(IDC_IACK_OUT, OnIackOut)
	ON_REGISTERED_MESSAGE(UWM_PULSE, OnPulse)
	ON_REGISTERED_MESSAGE(UWM_POLL, OnPoll)
	ON_REGISTERED_MESSAGE(UWM_IMGR_CLOSE, OnImgrClose)
	ON_REGISTERED_MESSAGE(UWM_REG_CLOSE, OnRegClose)
	ON_REGISTERED_MESSAGE(UWM_OPEN_FAILED, OnOpenFailed)
	ON_REGISTERED_MESSAGE(UWM_SET_TIMER_OUT, OnSetTimerOut)
	ON_REGISTERED_MESSAGE(UWM_SET_TIMER_IN, OnSetTimerIn)
	ON_REGISTERED_MESSAGE(UWM_GO_HACK_IN, OnExecuteGoHackIn)
	ON_REGISTERED_MESSAGE(UWM_GO_HACK_OUT, OnExecuteGoHackOut)
	ON_REGISTERED_MESSAGE(UWM_SET_MANUAL_MODE, OnSetManualMode)
	ON_REGISTERED_MESSAGE(UWM_SET_PROB, OnUpdateProbabilities)
	ON_BN_CLICKED(IDC_COMMENT, OnComment)
	ON_BN_CLICKED(IDC_GETSTATE, OnGetstate)
	ON_BN_CLICKED(IDC_SINGLESTEP, OnSinglestep)
	ON_COMMAND(IDM_HDWSIM_TRACE, OnHdwsimTrace)
	ON_COMMAND(IDM_REG_DISP, OnRegDisp)
	ON_BN_CLICKED(IDC_RST_IN, OnRstIn)
	ON_BN_CLICKED(IDC_RST_OUT, OnRstOut)
	//}}AFX_MSG_MAP

	// Nominally obsolete
	ON_REGISTERED_MESSAGE(UWM_RST_IN_SET, OnRstInSet)
	ON_REGISTERED_MESSAGE(UWM_RST_OUT_SET, OnRstOutSet)
	ON_REGISTERED_MESSAGE(UWM_GO_OUT_SET, OnGoOutSet)
	ON_REGISTERED_MESSAGE(UWM_GO_IN_SET, OnGoInSet)
	ON_REGISTERED_MESSAGE(UWM_IACK_IN_SET, OnIACKInSet)
	ON_REGISTERED_MESSAGE(UWM_IACK_OUT_SET, OnIACKOutSet)
	ON_REGISTERED_MESSAGE(UWM_UPDATE_CONTROLS, OnUpdateControls)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimulatorDlg message handlers

/****************************************************************************
*                           CSimulatorDlg::sendNext
* Result: void
*       
* Effect: 
*       Initiates the transfer of the next character in the input buffer
*	Updates all the relevant displays
****************************************************************************/

void CSimulatorDlg::sendNext()
    {
     BYTE status = registers.get(REGISTER_IN_STATUS);
     BYTE newstatus = status | REGISTER_IN_STATUS_DONE;
     // Take the next character off the front of the input
     // string

     if(input.GetLength() > 0)
	{ /* valid input available */
	 BYTE ch = (BYTE)*(LPCTSTR)input;
	 input = input.Mid(1); // lop off first byte
	 c_Transfer.SetWindowText(input);

	 if(input.GetLength() == 0)
	    newstatus |= REGISTER_IN_STATUS_EOP;

	 registers.set(REGISTER_IN_DATA, ch);
	 TraceItem * item = new TraceItem(TRACE_TYPE_INPUT_DATA, ch, _T("Sent"));
	 c_Trace.AddString(item);

	 if(injectErr())
	    { /* error injection */
	     newstatus |= REGISTER_IN_STATUS_ERR; // synthetic error
	     if(injectOvrUnd())
	        { /* OVR */
		 newstatus |= REGISTER_IN_STATUS_OVR;
		} /* OVR */
	     CString s;
	     s.LoadString(IDS_ERROR_INJECTED);
	     TraceItem * e = new TraceItem(TRACE_TYPE_COMMENT, s);
	     c_Trace.AddString(e);
	    } /* error injection */
	} /* valid input available */
     else
	{ /* no input available */
	 // There is nothing to send.  We will wait until there is a new
	 // SEND request
	 return;
	} /* no input available */

     // If we are going to generate an interrupt, set the INT
     // status bit

     BYTE command = registers.get(REGISTER_IN_COMMAND);

     if(command & REGISTER_IN_COMMAND_IE)
	newstatus |=  REGISTER_IN_STATUS_INT;

     registers.set(REGISTER_IN_STATUS, newstatus);
     logStatusChangeIn(status, newstatus);
     InStatusToControls(newstatus);

     updateControls();

     if(command & REGISTER_IN_COMMAND_IE)
	 generateAndLogInterrupt(_T("IN DONE"));

    }

/****************************************************************************
*                         CSimulatorDlg::receiveNext
* Result: void
*       
* Effect: 
*       Receives a character from the Output side of the device
*		Clears the busy flag
*
****************************************************************************/

void CSimulatorDlg::receiveNext()
    {
     BYTE status = registers.get(REGISTER_OUT_STATUS);
     BYTE command = registers.get(REGISTER_OUT_COMMAND);

     BYTE newstatus = status | REGISTER_OUT_STATUS_DONE;

     newstatus &= ~REGISTER_OUT_STATUS_BUSY;
     // If IE is set, we will want to set the INT bit as well
     if( (command & REGISTER_OUT_COMMAND_IE) != 0)
	newstatus |= REGISTER_OUT_STATUS_INT;

     // TODO: Error injection

     // Read the byte
     BYTE data = registers.get(REGISTER_OUT_DATA);
     TraceItem * item = new TraceItem(TRACE_TYPE_OUTPUT_DATA, data, _T("Received"));
     c_Trace.AddString(item);

     registers.set(REGISTER_OUT_STATUS, newstatus);
     logStatusChangeOut(status, newstatus);
     OutStatusToControls(newstatus);

     // if the IE bit is set, interrupt

     if(command & REGISTER_OUT_COMMAND_IE)
	generateAndLogInterrupt(_T("OUT DONE"));
    }

/****************************************************************************
*                          CSimulatorDlg::logChange
* Inputs:
*       BYTE o: Old value
*	BYTE n: New value
*	BYTE status: Status flag
*	UINT type: Type report
*	LPCTSTR reason: commentary text, or NULL
* Result: void
*       
* Effect: 
*       Logs
****************************************************************************/

void CSimulatorDlg::logChange(BYTE o, BYTE n, BYTE status, UINT type, LPCTSTR reason)
    {
     BYTE delta = (o ^ n) & status;

     if(delta != 0)
        { /* log err change */
	 TraceItem * item = new TraceItem(type, (n & status) != 0, reason);
	 c_Trace.AddString(item);
	} /* log err change */
     
    }

/****************************************************************************
*                      CSimulatorDlg::logStatusChangeIn
* Inputs:
*       BYTE o: Old status
*	BYTE n: New status
*	LPCTSTR reason: Commentary text, defaults to NULL
* Result: void
*       
* Effect: 
*       Logs changes in the input status line
****************************************************************************/

void CSimulatorDlg::logStatusChangeIn(BYTE o, BYTE n, LPCTSTR reason)
    {

     logChange(o, n, REGISTER_IN_STATUS_ERR,  TRACE_TYPE_ERR_IN, reason);
     logChange(o, n, REGISTER_IN_STATUS_OVR,  TRACE_TYPE_OVR_IN, reason);
     logChange(o, n, REGISTER_IN_STATUS_EOP,  TRACE_TYPE_EOP_IN, reason);
     logChange(o, n, REGISTER_IN_STATUS_INT,  TRACE_TYPE_INT_IN, reason);
     logChange(o, n, REGISTER_IN_STATUS_DONE, TRACE_TYPE_DONE_IN,reason);
    }

/****************************************************************************
*                      CSimulatorDlg::logCommandChangeIn
* Inputs:
*       BYTE o: Old command register
*	BYTE n: New command register
*	LPCTSTR reason: Reason string, may be NULL
* Result: void
*       
* Effect: 
*       Logs any bits that changed
****************************************************************************/

void CSimulatorDlg::logCommandChangeIn(BYTE o, BYTE n, LPCTSTR reason)
    {
     logChange(o, n, REGISTER_IN_COMMAND_GO,  TRACE_TYPE_GO_IN, reason);
     logChange(o, n, REGISTER_IN_COMMAND_IE,  TRACE_TYPE_IE_IN, reason);
     logChange(o, n, REGISTER_IN_COMMAND_IACK,TRACE_TYPE_IACK_IN, reason);
    }

/****************************************************************************
*                      CSimulatorDlg::logStatusChangeOut
* Inputs:
*       BYTE o: Old status
*	BYTE n: New status
*	LPCTSTR reason: Commentary text, defaults to NULL
* Result: void
*       
* Effect: 
*       Logs changes in the input status line
****************************************************************************/

void CSimulatorDlg::logStatusChangeOut(BYTE o, BYTE n, LPCTSTR reason)
    {

     logChange(o, n, REGISTER_OUT_STATUS_ERR,  TRACE_TYPE_ERR_OUT, reason);
     logChange(o, n, REGISTER_OUT_STATUS_UND,  TRACE_TYPE_UND_OUT, reason);
     logChange(o, n, REGISTER_OUT_STATUS_BUSY, TRACE_TYPE_BUSY_OUT,reason);
     logChange(o, n, REGISTER_OUT_STATUS_INT,  TRACE_TYPE_INT_OUT, reason);
     logChange(o, n, REGISTER_OUT_STATUS_DONE, TRACE_TYPE_DONE_OUT,reason);
    }

/****************************************************************************
*                      CSimulatorDlg::logCommandChangeOut
* Inputs:
*       BYTE o: Old command register
*	BYTE n: New command register
*	LPCTSTR reason: Reason string, may be NULL
* Result: void
*       
* Effect: 
*       Logs any bits that changed
****************************************************************************/

void CSimulatorDlg::logCommandChangeOut(BYTE o, BYTE n, LPCTSTR reason)
    {
     logChange(o, n, REGISTER_OUT_COMMAND_GO,  TRACE_TYPE_GO_OUT, reason);
     logChange(o, n, REGISTER_OUT_COMMAND_IE,  TRACE_TYPE_IE_OUT, reason);
     logChange(o, n, REGISTER_OUT_COMMAND_IACK,TRACE_TYPE_IACK_OUT, reason);
    }

/****************************************************************************
*                   CSimulatorDlg::generateAndLogInterrupt
* Inputs:
*	LPCTSTR annotation = NULL: Notation to add, or NULL if none
* Result: void
*       
* Effect: 
*       Logs an interrupt event and generates the interrupt.
*	Sets the IE bit
* Notes:
*	Before calling this, the following conditions must be true:
*		The IE bit must already be set
*		The DONE bit must already be set
*		The INT bit must already be set
****************************************************************************/

void CSimulatorDlg::generateAndLogInterrupt(LPCTSTR annotation)
    {
     TraceItem * item = new TraceItem(TRACE_TYPE_INT, annotation);
     c_Trace.AddString(item);

     registers.generateInterrupt();
     
    }

/****************************************************************************
*                          CSimulatorDlg::OnComment
* Result: void
*       
* Effect: 
*       Adds a commment to the trace box
****************************************************************************/

void CSimulatorDlg::OnComment() 
{
 CComment dlg;
 switch(dlg.DoModal())
    { /* DoModal */
     case IDOK:
	     break;
     case IDCANCEL:
	     return;
    } /* DoModal */

 TraceItem * e = new TraceItem(TRACE_TYPE_COMMENT, dlg.m_Comment);
 c_Trace.AddString(e);	
}


void CSimulatorDlg::OnHdwsimTrace() 
{
 CHdwTrace dlg;
 dlg.registers = &registers;

 dlg.DoModal();	
}

void CSimulatorDlg::OnRegDisp() 
{
 if(regdisp == NULL)
    { /* create it */
     regdisp = new CRegDisplay;
     regdisp->Create(IDD_REGISTERS, this);
    } /* create it */
 else
    { /* focus */
     regdisp->SetFocus();
    } /* focus */
	
}

