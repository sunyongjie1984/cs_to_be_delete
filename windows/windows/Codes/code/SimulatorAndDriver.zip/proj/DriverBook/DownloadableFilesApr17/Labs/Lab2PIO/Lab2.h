/*****************************************************************************
*           Change Log
*  Date     | Change
*-----------+-----------------------------------------------------------------
*****************************************************************************/
// NT device name
#define NT_DEVICE_NAME      L"\\Device\\Lab2"

// File system device name.   
#define DOS_DEVICE_NAME     L"\\DosDevices\\Lab2"


#define HELLO_STATUS_IN_MASK_DONE   (0x01)
#define HELLO_STATUS_IN_MASK_INT    (0x02)
#define HELLO_STATUS_IN_MASK_EOP    (0x04)
#define HELLO_STATUS_IN_MASK_OVR    (0x40)
#define HELLO_STATUS_IN_MASK_ERR    (0x80)

#define HELLO_COMMAND_IN_MASK_GO    (0x01)
#define HELLO_COMMAND_IN_MASK_IE    (0x02)
#define HELLO_COMMAND_IN_MASK_IACK  (0x04)

#define HELLO_STATUS_OUT_MASK_DONE   (0x01)
#define HELLO_STATUS_OUT_MASK_INT    (0x02)
#define HELLO_STATUS_OUT_MASK_BUSY   (0x04)
#define HELLO_STATUS_OUT_MASK_UND    (0x40)
#define HELLO_STATUS_OUT_MASK_ERR    (0x80)

#define HELLO_COMMAND_OUT_MASK_GO    (0x01)
#define HELLO_COMMAND_OUT_MASK_IE    (0x02)
#define HELLO_COMMAND_OUT_MASK_IACK  (0x04)

                                           
                                           

typedef struct _LAB2_DEVICE_EXTENSION {
    PDEVICE_OBJECT      DeviceObject;
    ULONG               InterruptCount;

                                               //
    ULONG               BusNumber;         // Bus number 
    ULONG               Level;             // Level
    ULONG               Vector;            // Vector
    ULONG               Affinity;          // Affinity



    PCM_RESOURCE_LIST  *pResources;

    PUCHAR               registerAddress;            // system address of Virtual Hardware
    PHYSICAL_ADDRESS    registerPhysicalAddress;    // physical address of Virtual Hardware
    ULONG               interruptLine;
    ULONG               interruptIDT;

    ULONG               debugMask;
    ULONG               eventLog;
    ULONG               shouldBreak;



    KSPIN_LOCK          ISRSpinLock;
    PKINTERRUPT         InterruptObject;   // Pointer to the Interrupt Object


                                          //

} LAB2_DEVICE_EXTENSION;
typedef LAB2_DEVICE_EXTENSION *PLAB2_DEVICE_EXTENSION;





