#include "windows.h"
#include "winioctl.h"
#include "stdio.h"
#include "stdlib.h"
//#include "ioaccess`.h"

#include "HdwSimIoctl.h"

unsigned char InBuffer[1000];
HDW_SIM_DATA_OUTPUT OutBuffer;

                                        
int IoctlResult;
HANDLE hTest;
int ReturnedLength;
unsigned int offset;



int main(int argc, char **argv)
{
   if ((hTest = CreateFile(
                     "\\\\.\\HdwSim",
                     GENERIC_READ | GENERIC_WRITE,
                     0,
                     NULL,
                     OPEN_EXISTING,
                     FILE_ATTRIBUTE_NORMAL,
                     NULL
                     )) != ((HANDLE)-1))
    {
        printf("CreateFile worked!!!\n");
    }
    else
    {
        printf("Can't get a handle to driver\n");

	return 1 ;
    }


        // initialize the board

        IoctlResult = DeviceIoControl(
                            hTest,             // Handle to device
                            (unsigned long)IOCTL_HDW_SIM_INITIALIZE, // IO Control code for Read
                            &InBuffer,         // Buffer to driver.
                            sizeof(InBuffer),  // Length of buffer in bytes.
                            &OutBuffer,        // Buffer from driver.
                            sizeof(OutBuffer), // Length of buffer in bytes.
                            &ReturnedLength,   // Bytes placed in DataBuffer.
                            NULL               // NULL means wait till op. completes.
                            );

            if (IoctlResult)                            // Did the IOCTL succeed?
            {
	       printf("Ioctl initialize worked\n" );
	    }
            else
            {
	       printf("Ioctl initialize failed\n" );
            }
        // initialize the board

        IoctlResult = DeviceIoControl(
                            hTest,             // Handle to device
                            (unsigned long)IOCTL_HDW_SIM_GEN_INTR, // IO Control code for Read
                            &InBuffer,         // Buffer to driver.
                            sizeof(InBuffer),  // Length of buffer in bytes.
                            &OutBuffer,        // Buffer from driver.
                            sizeof(OutBuffer), // Length of buffer in bytes.
                            &ReturnedLength,   // Bytes placed in DataBuffer.
                            NULL               // NULL means wait till op. completes.
                            );

            if (IoctlResult)                            // Did the IOCTL succeed?
            {
	       printf("Ioctl initialize worked\n" );
	    }
            else
            {
	       printf("Ioctl initialize failed\n" );
            }


//            printf("DMA Buffer Address = %x  \n", (ULONG)(OutBuffer.DMARegisterVirtualAddress));
        


        CloseHandle(hTest);


    return 1;

}

