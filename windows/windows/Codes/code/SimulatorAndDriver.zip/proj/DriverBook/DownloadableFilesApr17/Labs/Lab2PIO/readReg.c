

// Registry access routine
/*****************************************************************************
*           Change Log
*  Date     | Change
*-----------+-----------------------------------------------------------------
  06-01-97     create log
*****************************************************************************/

/*****************************************************************************
*           To DO
*-----------------------------------------------------------------------------


*****************************************************************************/


#define BYTE UCHAR
/*++


Module Name:

    ReadReg.c

Abstract:


Author:

    Edward Dekker

Environment:

    kernel mode only

Notes:

    --*/


#include "ntddk.h"
#include "readReg.h"

#define DBG_MSG_HDR "Lab2 (readReg)"


NTSTATUS helloReadRegistry(
    IN PDRIVER_OBJECT DriverObject,   // Driver object
    IN PUNICODE_STRING RegistryPath,  // base path to keys
    OUT PULONG debugMask,             // 32-bit binary debug mask
    OUT PULONG eventLog,              // Boolean: do we log events?
    OUT PULONG shouldBreak            // Boolean: break in DriverEntry?
    )
{
   //
   // We use this to query into the registry as to get initializationa and
   // debug information for our driver
   //
   RTL_QUERY_REGISTRY_TABLE paramTable[4];  // Parameter table
   ULONG zero = 0;                          // default value 0
   ULONG one = 1;                           // default value 1
   ULONG sixteenK = 16 * 1024;              // default value for 16K
   ULONG notConfigurable = 0;
   PWCHAR path;                             // the Registry path
   NTSTATUS status = STATUS_UNSUCCESSFUL;   // assume failure
   UNICODE_STRING systemPath;
   ULONG pathLength;                        // length to allocate for path



   UNICODE_STRING       parameterRegistryPath;
   UNICODE_STRING       registryPathName;
     
   KdPrint(("%s: RegistryPath = %S\n", DBG_MSG_HDR,  RegistryPath->Buffer));

   status = initParameterDevicePath(
       DriverObject,
       RegistryPath,      // zero terminated UNICODE_STRING with parameters path
       &parameterRegistryPath,
       &registryPathName
       );

   RtlInitUnicodeString(&systemPath,
                  L"\\REGISTRY\\MACHINE\\HARDWARE\\DESCRIPTION\\System");

   // We want the max of the Registry path length and the system path length
   pathLength = parameterRegistryPath.Length  + sizeof(WCHAR);
   if (pathLength < systemPath.Length + sizeof(WCHAR))
   {
      pathLength = systemPath.Length + sizeof(WCHAR);
   }

   // We set these values to their defaults in case there are any failures
   *debugMask = 0;
   *shouldBreak = 0;

   //
   // Since the rEgistry path parameter is a "counted" UNICODE string, it
   // might not be zero terminated.  For a very short time allocate memory
   // to hold the Registry path zero-terminated so that we can use it to
   // delve into the Registry.
   //

   path = ExAllocatePool(PagedPool, pathLength);
   if (path != NULL)
   {
      KdPrint( ("readReg: Pool allocated\n") );

      RtlZeroMemory(&paramTable[0], sizeof(paramTable)); // mandatory

      RtlZeroMemory(path, pathLength);
      RtlMoveMemory(path, parameterRegistryPath.Buffer,  parameterRegistryPath.Length);

      paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
      paramTable[0].Name = L"BreakOnEntry";
      paramTable[0].EntryContext = shouldBreak;
      paramTable[0].DefaultType = REG_DWORD;
      paramTable[0].DefaultData = &zero;
      paramTable[0].DefaultLength = sizeof(ULONG);

      paramTable[1].Flags = RTL_QUERY_REGISTRY_DIRECT;
      paramTable[1].Name = L"DebugMask";
      paramTable[1].EntryContext = debugMask;
      paramTable[1].DefaultType = REG_DWORD;
      paramTable[1].DefaultData = &zero;
      paramTable[1].DefaultLength = sizeof(ULONG);

      paramTable[2].Flags = RTL_QUERY_REGISTRY_DIRECT;
      paramTable[2].Name = L"LogEvents";
      paramTable[2].EntryContext = eventLog;
      paramTable[2].DefaultType = REG_DWORD;
      paramTable[2].DefaultData = &zero;
      paramTable[2].DefaultLength = sizeof(ULONG);

      if (!(status = NT_SUCCESS(
                     RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE | RTL_REGISTRY_OPTIONAL,
                                               path,
                                               &paramTable[0],
                                               NULL,
                                               NULL))))
      { // Not succesful
         // If it failed, it may have partially updated the variables
         // The query function quits on the first error
         // to ensure that everything is consistent, we reset the values
         KdPrint( ("readReg: Failed return uncessful\n") );
         *shouldBreak = 0;
         *debugMask = 0;
         status = STATUS_UNSUCCESSFUL;
      } 
      else
      { 
          status = STATUS_SUCCESS;
      } 

      //
      // We don't need the path anymore.
      //
      ExFreePool(path);
   } 
   
   KdPrint(("%s: parameterRegistryPath = %S\n", DBG_MSG_HDR,  parameterRegistryPath.Buffer));
   KdPrint(("%s  TargetReadRegistry - debugMask   = 0x%08x\n",      DBG_MSG_HDR, *debugMask ));
   KdPrint(("%s  TargetReadRegistry - eventLog = 0x%08x\n",         DBG_MSG_HDR, *eventLog));
   KdPrint(("%s  TargetReadRegistry - shouldBreak    = 0x%08x\n",   DBG_MSG_HDR, *shouldBreak ));
   
   return  ( status);
}


NTSTATUS initParameterDevicePath(
       IN PDRIVER_OBJECT DriverObject,
       IN PUNICODE_STRING  inPath,    // zero terminated UNICODE_STRING with parameters path
       UNICODE_STRING * parameterRegistryPath,
       UNICODE_STRING * registryPathName
       )
{
   NTSTATUS  ret = STATUS_SUCCESS;



   ULONG pathLength;              // length to allocate for path
   PUNICODE_STRING  path;         // zero terminated UNICODE_STRING with parameters path

   KdPrint( ("HdwSim: initDevicePath\n") );

   // We want  a UNICODE String long enough for the Registry path length with the Parameters key
   //
   // Since the registry path parameter is a "counted" UNICODE string, it
   // might not be zero terminated.  For a very short time allocate memory
   // to hold the Registry path zero-terminated so that we can use it to
   // delve into the Registry.
   //


   parameterRegistryPath->MaximumLength = (USHORT)(inPath->Length + 40 + sizeof(WCHAR)) ;
   parameterRegistryPath->Buffer  = ExAllocatePool(NonPagedPool, parameterRegistryPath->MaximumLength + 4);
   RtlCopyUnicodeString(parameterRegistryPath, inPath);
   RtlAppendUnicodeToString(parameterRegistryPath, PARMS_SUBKEY);


   registryPathName->MaximumLength      = (USHORT)(inPath->Length + sizeof(WCHAR)) ;
   registryPathName->Buffer = ExAllocatePool(NonPagedPool, registryPathName->MaximumLength + 4);
   RtlCopyUnicodeString(registryPathName,      inPath);



   // ?? TO DO ?? add checking on return pointer 


   //
   //  Null terminate for some uses (but don't increase the 'length' or
   //  the UNICODE_STRING version will have a 0 on the end.
   //

   parameterRegistryPath->Buffer[parameterRegistryPath->Length / sizeof(UNICODE_NULL)] = UNICODE_NULL;
   registryPathName->Buffer[registryPathName->Length / sizeof(UNICODE_NULL)] = UNICODE_NULL;

   return ret;
}
