// SetupDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Simulator.h"
#include "SetupDlg.h"
#include "help.h"
#include "regvars.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetupDlg dialog


CSetupDlg::CSetupDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetupDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetupDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSetupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetupDlg)
	DDX_Control(pDX, IDC_SPINGODONEVAR, c_SpinGoDoneVariance);
	DDX_Control(pDX, IDC_SPINGODONEMIN, c_SpinGoDoneMin);
	DDX_Control(pDX, IDC_GODONE_VAR, c_GoDoneVariance);
	DDX_Control(pDX, IDC_GODONE_MIN, c_GoDoneMin);
	DDX_Control(pDX, IDC_SPINPOLLINTERVAL, c_SpinPollingInterval);
	DDX_Control(pDX, IDC_POLLINTERVAL, c_PollingInterval);
	DDX_Control(pDX, IDOK, c_OK);
	DDX_Control(pDX, IDC_IRQ, c_IRQ);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSetupDlg, CDialog)
	//{{AFX_MSG_MAP(CSetupDlg)
	ON_CBN_SELENDOK(IDC_IRQ, OnSelendokIrq)
	ON_BN_CLICKED(IDC_SETUP_HELP, OnHelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetupDlg message handlers

void CSetupDlg::OnSelendokIrq() 
{
 updateControls();	
}

void CSetupDlg::OnOK() 
{
	RegistryInt interval(IDS_POLLING_INTERVAL);
	interval.value = c_SpinPollingInterval.GetPos();
	interval.store();

	RegistryInt minimum(IDS_GODONEMIN);
	minimum.value = c_SpinGoDoneMin.GetPos();
	minimum.store();

	RegistryInt variance(IDS_GODONEVAR);
	variance.value = c_SpinGoDoneVariance.GetPos();
	variance.store();

 	int n = c_IRQ.GetCurSel();
	if(n != CB_ERR)
	   { /* success */
	    RegistryInt regIRQ(IDS_IRQ);
	    regIRQ.value = c_IRQ.GetItemData(n);
	    regIRQ.store();
	   } /* success */
	
	CDialog::OnOK();
}

/****************************************************************************
*                          CSetupDlg::updateControls
* Result: void
*       
* Effect: 
*       Enables/disables controls
****************************************************************************/

void CSetupDlg::updateControls()
    {
    }

/****************************************************************************
*                           CSetupDlg::OnInitDialog
* Result: BOOL
*       TRUE, always
* Effect: 
*       Initializes controls
****************************************************************************/

BOOL CSetupDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
 	for(int i = 0; i < 32; i++)
	   { /* add IRQs */
	    // TODO: drop out IRQs that are not available
	    CString s;
	    s.Format(_T("%d"), i);
	    int n = c_IRQ.AddString(s);
	    c_IRQ.SetItemData(n, (DWORD) i);
	   } /* add IRQs */
	
	RegistryInt irq(IDS_IRQ);
	irq.load(-1);

	for(i = 0; i < 32; i++)
	   { /* select IRQ */
	    if(c_IRQ.GetItemData(i) == (DWORD)irq.value)
	       { /* found it */
	        c_IRQ.SetCurSel(i);
		break;
	       } /* found it */
	   } /* select IRQ */

	RegistryInt interval(IDS_POLLING_INTERVAL);
	interval.load(50); // default to 50 ms
	c_SpinPollingInterval.SetRange(10, 10000); // 0.010 to 10.000 seconds
	c_SpinPollingInterval.SetPos(interval.value);

	// Handle the Minimum Go->Done delay setup
	RegistryInt minimum(IDS_GODONEMIN);
	minimum.load(500);
	c_SpinGoDoneMin.SetRange(0, 10000);
	c_SpinGoDoneMin.SetPos(minimum.value);

	RegistryInt variance(IDS_GODONEVAR);
	variance.load(500);
	c_SpinGoDoneVariance.SetRange(0, 10000);
	c_SpinGoDoneVariance.SetPos(variance.value);

	updateControls();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSetupDlg::OnHelp() 
{
 WinHelp(HID_SETUP_DIALOG, HELP_CONTEXT);
}
