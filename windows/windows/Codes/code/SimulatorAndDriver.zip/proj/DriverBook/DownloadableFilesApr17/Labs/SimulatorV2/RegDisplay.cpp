// RegDisplay.cpp : implementation file
//

#include "stdafx.h"
#include "Simulator.h"
#include "RegData.h"
  #include "RegDisplay.h"
#include "uwm.h"
#include "register.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRegDisplay dialog


CRegDisplay::CRegDisplay(CWnd* pParent /*=NULL*/)
	: CDialog(CRegDisplay::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRegDisplay)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CRegDisplay::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRegDisplay)
	DDX_Control(pDX, IDC_OUT_STATUS, c_OutStatus);
	DDX_Control(pDX, IDC_OUT_DATA, c_OutData);
	DDX_Control(pDX, IDC_OUT_COMMAND, c_OutCommand);
	DDX_Control(pDX, IDC_IN_STATUS, c_InStatus);
	DDX_Control(pDX, IDC_IN_DATA, c_InData);
	DDX_Control(pDX, IDC_IN_COMMAND, c_InCommand);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRegDisplay, CDialog)
	//{{AFX_MSG_MAP(CRegDisplay)
	ON_WM_CLOSE()
	ON_WM_DESTROY()
	ON_REGISTERED_MESSAGE(UWM_UPDATE_REGS, OnUpdateRegs)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRegDisplay message handlers

BOOL CRegDisplay::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/****************************************************************************
*                              CRegDisplay::OnOK
* Result: void
*       
* Effect: 
*       Ignores ENTER key
****************************************************************************/

void CRegDisplay::OnOK()
    {
     // do nothing
    }

/****************************************************************************
*                            CRegDisplay::OnCancel
* Result: void
*       
* Effect: 
*       Ignores ESC key
****************************************************************************/

void CRegDisplay::OnCancel()
    {
     // does nothing
    }

void CRegDisplay::OnClose() 
{
 DestroyWindow(); // closes modeless dialog
}

void CRegDisplay::PostNcDestroy() 
{
	CDialog::PostNcDestroy();
}

void CRegDisplay::OnDestroy() 
{
	CDialog::OnDestroy();
	
 	GetParent()->SendMessage(UWM_REG_CLOSE);
}

/****************************************************************************
*                          CRegDisplay::OnUpdateRegs
* Inputs:
*       WPARAM: ignored
*	LPARAM: (LPARAM)(LPHDW_SIM_REGS)
* Result: LRESULT
*       0, always
* Effect: 
*       Updates the register display
****************************************************************************/

LRESULT CRegDisplay::OnUpdateRegs(WPARAM, LPARAM lParam)
    {
     LPHDW_SIM_REGS regs = (LPHDW_SIM_REGS)lParam;
     c_InCommand.SetWindowText(regs->registers[REGISTER_IN_COMMAND]);
     c_InStatus.SetWindowText(regs->registers[REGISTER_IN_STATUS]);
     c_InData.SetWindowText(regs->registers[REGISTER_IN_DATA]);
     c_OutCommand.SetWindowText(regs->registers[REGISTER_OUT_COMMAND]);
     c_OutStatus.SetWindowText(regs->registers[REGISTER_OUT_STATUS]);
     c_OutData.SetWindowText(regs->registers[REGISTER_OUT_DATA]);
     return 0;
    }
