// Comment.cpp : implementation file
//

#include "stdafx.h"
#include "Simulator.h"
#include "Comment.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CComment dialog


CComment::CComment(CWnd* pParent /*=NULL*/)
	: CDialog(CComment::IDD, pParent)
{
	//{{AFX_DATA_INIT(CComment)
	m_Comment = _T("");
	//}}AFX_DATA_INIT
}


void CComment::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CComment)
	DDX_Control(pDX, IDC_COMMENT, c_Comment);
	DDX_Control(pDX, IDOK, c_OK);
	DDX_Text(pDX, IDC_COMMENT, m_Comment);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CComment, CDialog)
	//{{AFX_MSG_MAP(CComment)
	ON_EN_CHANGE(IDC_COMMENT, OnChangeComment)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComment message handlers

void CComment::OnChangeComment() 
{
 updateControls();
}

BOOL CComment::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
 	updateControls();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/****************************************************************************
*                          CComment::updateControls
* Result: void
*       
* Effect: 
*       Updates teh controls
****************************************************************************/

void CComment::updateControls()
    {
     c_OK.EnableWindow(c_Comment.GetWindowTextLength() > 0);
    }
