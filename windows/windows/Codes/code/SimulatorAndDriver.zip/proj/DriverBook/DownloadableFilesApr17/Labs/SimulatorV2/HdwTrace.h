// HdwTrace.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHdwTrace dialog

class CHdwTrace : public CDialog
{
// Construction
public:
	CHdwTrace(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CHdwTrace)
	enum { IDD = IDD_HDWTRACE };
	CButton	c_IoctlTrace;
	CButton	c_RegTrace;
	CButton c_OK;
	//}}AFX_DATA

	IORegisters * registers;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHdwTrace)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CHdwTrace)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
