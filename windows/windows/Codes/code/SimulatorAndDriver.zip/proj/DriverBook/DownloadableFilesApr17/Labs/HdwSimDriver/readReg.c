

// Registry access routine
/*****************************************************************************
*           Change Log
*  Date     | Change
*-----------+-----------------------------------------------------------------
  06-01-97     create log
*****************************************************************************/

/*****************************************************************************
*           To DO
*-----------------------------------------------------------------------------


*****************************************************************************/


#define BYTE UCHAR
/*++


Module Name:

    ReadReg.c

Abstract:


Author:

    Edward Dekker

Environment:

    kernel mode only

Notes:

    --*/


#include "ntddk.h"
#include "HdwSim.h"
#include "HdwSimIoctl.h"
#include "readReg.h"
//#include "MapMemory.h"


#define DBG_MSG_HDR "HdwSim (readReg)"

 

NTSTATUS readRegistry(
    IN PDRIVER_OBJECT DriverObject,   // Driver object
    IN PUNICODE_STRING path,  // base path to keys
    OUT PULONG debugMask,             // 32-bit binary debug mask
    OUT PULONG eventLog,              // Boolean: do we log events?
    OUT PULONG shouldBreak,           // Boolean: break in DriverEntry?
    OUT PULONG interrupt_Line
    )
{
   //
   // We use this to query into the registry as to get initializationa and
   // debug information for our driver
   //
   RTL_QUERY_REGISTRY_TABLE paramTable[7];  // Parameter table
   ULONG zero = 0;                          // default value 0
   ULONG one = 1;                           // default value 1
   ULONG sixteenK = 16 * 1024;              // default value for 16K
   ULONG notConfigurable = 0;
   ULONG model30 = 0;
   NTSTATUS status = STATUS_UNSUCCESSFUL;   // assume failure
   // We set these values to their defaults in case there are any failures
 
   KdPrint(("%s: Path = %S\n", DBG_MSG_HDR,  path->Buffer));


   // We set these values to their defaults in case there are any failures
   *debugMask = 0;
   *shouldBreak = 0;
      
   RtlZeroMemory(&paramTable[0], sizeof(paramTable)); // mandatory


   paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
   paramTable[0].Name = REG_BREAK ;
   paramTable[0].EntryContext = shouldBreak;
   paramTable[0].DefaultType = REG_DWORD;
   paramTable[0].DefaultData = &zero;
   paramTable[0].DefaultLength = sizeof(ULONG);

   paramTable[1].Flags = RTL_QUERY_REGISTRY_DIRECT;
   paramTable[1].Name = REG_DBG ;
   paramTable[1].EntryContext = debugMask;
   paramTable[1].DefaultType = REG_DWORD;
   paramTable[1].DefaultData = &zero;
   paramTable[1].DefaultLength = sizeof(ULONG);

   paramTable[2].Flags = RTL_QUERY_REGISTRY_DIRECT;
   paramTable[2].Name = REG_EVENT ;
   paramTable[2].EntryContext = eventLog;
   paramTable[2].DefaultType = REG_DWORD;
   paramTable[2].DefaultData = &zero;
   paramTable[2].DefaultLength = sizeof(ULONG);
   
   paramTable[3].Flags = RTL_QUERY_REGISTRY_DIRECT;
   paramTable[3].Name = REG_DEFAULT_INTLINE ;
   paramTable[3].EntryContext = interrupt_Line;
   paramTable[3].DefaultType = REG_DWORD;
   paramTable[3].DefaultData = &zero;
   paramTable[3].DefaultLength = sizeof(ULONG);
   


   if (!NT_SUCCESS(  status =
                RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE | RTL_REGISTRY_OPTIONAL,
                                          path->Buffer,
                                          &paramTable[0],
                                          NULL,
                                          NULL)))
   { 
     // If it failed, it may have partially updated the variables
     // The query function quits on the first error
     // to ensure that everything is consistent, we reset the values
       KdPrint( ("readReg: Failed return uncessful\n") );
       *shouldBreak = 0;
       *debugMask = 0;
       return status;
   } 

    KdPrint( ("%s: shouldBreak = 0x%x\n", DBG_MSG_HDR, *shouldBreak ) );
    KdPrint( ("%s: debugMask   = 0x%x\n", DBG_MSG_HDR, *debugMask   ) );
    KdPrint( ("%s: eventLog    = 0x%x\n", DBG_MSG_HDR, *eventLog    ) );
          
    return  ( status);
}

NTSTATUS
OpenDevicesKey(
    IN   PWSTR RegistryPathName,
    OUT  PHANDLE DevicesKey
)
/*++

Routine Description :

    Create a volatile key under this driver's services node to contain the
    device name list.

Arguments :

    RegistryPathName -  registry entry

	DevicesKey        - key to devices key in registry

Return Value :

    NT status code - STATUS_SUCCESS if no problems

--*/
{
HANDLE hKey;
OBJECT_ATTRIBUTES oa;
NTSTATUS Status;
UNICODE_STRING uStr;

    RtlInitUnicodeString(&uStr, RegistryPathName);

    //
    //  First try opening this key
    //

    InitializeObjectAttributes(&oa,
                               &uStr,
                               OBJ_CASE_INSENSITIVE,
                               NULL,
                               (PSECURITY_DESCRIPTOR)NULL);

    Status = ZwOpenKey(&hKey,
                       KEY_CREATE_SUB_KEY,
                       &oa);

    if (!NT_SUCCESS(Status)) {
        return Status;
    }

    RtlInitUnicodeString(&uStr, DEVICES_SUBKEY);

    InitializeObjectAttributes(&oa,
                               &uStr,
                               OBJ_CASE_INSENSITIVE,
                               hKey,
                               (PSECURITY_DESCRIPTOR)NULL);

    Status = ZwCreateKey(DevicesKey,
                         KEY_ALL_ACCESS,
                         &oa,
                         0,
                         NULL,
                         REG_OPTION_VOLATILE,
                         NULL);

    ZwClose(hKey);

    return Status;
}



#ifdef NEVER
NTSTATUS WriteRegistrySZ(
    IN   PCWSTR RegistryPath,
    IN   PCWSTR ValueName,
    IN   PCWSTR  Value
)
/*++

Routine Description :

    Write the given REG_SZ into the registry using the path and
    value name supplied by calling RtlWriteRegistryValue

Arguments :

    RegistryPath- path to registry key

    ValueName - name of value to write

    Value - value to store

Return Value :

    NTSTATUS code

--*/
{
NTSTATUS Status;

	// Writes caller-supplied data into the registry along the specified relative path
	// at the given value name

    Status = RtlWriteRegistryValue(
                 RTL_REGISTRY_ABSOLUTE,
                 (LPWSTR)RegistryPath,
                 (LPWSTR)ValueName,
                 REG_SZ,
                 &Value,
                 sizeof(Value));

    if (!NT_SUCCESS(Status)) {
        KdPrint(("Writing parameter %ls to registry failed status %8X",
                  ValueName, Status));
    }

    return Status;
}
#endif


NTSTATUS
WriteRegistryDWORD(
    IN   PCWSTR RegistryPath,
    IN   PCWSTR ValueName,
    IN   ULONG  Value
)
/*++

Routine Description :

    Write the given DWORD into the registry using the path and
    value name supplied by calling RtlWriteRegistryValue

Arguments :

    RegistryPath- path to registry key

    ValueName - name of value to write

    Value - value to store

Return Value :

    NTSTATUS code

--*/
{
NTSTATUS Status;

	// Writes caller-supplied data into the registry along the specified relative path
	// at the given value name

    Status = RtlWriteRegistryValue(
                 RTL_REGISTRY_ABSOLUTE,
                 (LPWSTR)RegistryPath,
                 (LPWSTR)ValueName,
                 REG_DWORD,
                 &Value,
                 sizeof(Value));

    if (!NT_SUCCESS(Status)) {
        KdPrint(("Writing parameter %ls to registry failed status %8X",
                  ValueName, Status));
    }

    return Status;
}




NTSTATUS saveConfig(
    IN	PWSTR registryPath,
	IN	ULONG interrupt_Line,
	IN	ULONG interrupt_IDT,
	IN	VOID * registersLogicalAddress,
	IN	PHYSICAL_ADDRESS registersPhysicalAddress     
    )
/*++
Routine Description :

    Saves the drivers configuration information for our device

Arguments :

    Registry Key values

Return Value :

    NT status code - STATUS_SUCCESS if no problems

*/
{
NTSTATUS Status = STATUS_SUCCESS;

    Status = WriteRegistryDWORD(registryPath, REG_INTLINE, interrupt_Line);
    if (!NT_SUCCESS(Status)) {
		return Status;
    }

    Status = WriteRegistryDWORD(registryPath, REG_INTIDT, interrupt_IDT);
    if (!NT_SUCCESS(Status)) {
		return Status;
    }

    Status = WriteRegistryDWORD(registryPath, REG_BUF_LOG_ADDRESS, (ULONG)registersLogicalAddress);
    if (!NT_SUCCESS(Status)) {
		return Status;
    }

    Status = WriteRegistryDWORD(registryPath, REG_BUF_PHYS_ADDRESS_LO, registersPhysicalAddress.LowPart);
    if (!NT_SUCCESS(Status)) {
		return Status;
    }

    Status = WriteRegistryDWORD(registryPath, REG_BUF_PHYS_ADDRESS_HI, registersPhysicalAddress.HighPart);
    if (!NT_SUCCESS(Status)) {
		return Status;
    }
    
    KdPrint( ("HdwSim: Path = %S\n",  registryPath));
      
//    Status = WriteRegistrySZ(registryPath, REG_PATHNAME, registryPath);
//    if (!NT_SUCCESS(Status)) {
//		return Status;
//    }
 return Status;
}


NTSTATUS initDevicePath(
       IN PDRIVER_OBJECT DriverObject,
       IN PUNICODE_STRING  inPath,    // zero terminated UNICODE_STRING with parameters path 
       UNICODE_STRING * ephemeralRegistryPath,
       UNICODE_STRING * parameterRegistryPath,
       UNICODE_STRING * registryPathName
       )
{
    NTSTATUS  ret = STATUS_SUCCESS;


     
    ULONG pathLength;              // length to allocate for path
    PUNICODE_STRING  path;         // zero terminated UNICODE_STRING with parameters path 

    KdPrint( ("HdwSim: initDevicePath\n") );

    // We want  a UNICODE String long enough for the Registry path length with the Parameters key
     
    ephemeralRegistryPath->MaximumLength = (USHORT)(inPath->Length + 40 + sizeof(WCHAR)) ;
    parameterRegistryPath->MaximumLength = (USHORT)(inPath->Length + 40 + sizeof(WCHAR)) ;
    registryPathName->MaximumLength      = (USHORT)(inPath->Length + sizeof(WCHAR)) ;

    ephemeralRegistryPath->Buffer = ExAllocatePool(NonPagedPool, ephemeralRegistryPath->MaximumLength + 4); 
    parameterRegistryPath->Buffer  = ExAllocatePool(NonPagedPool, parameterRegistryPath->MaximumLength + 4); 
    registryPathName->Buffer = ExAllocatePool(NonPagedPool, registryPathName->MaximumLength + 4);        



    // ?? TO DO ?? add checking on return pointer here



    //
    // Since the registry path parameter is a "counted" UNICODE string, it
    // might not be zero terminated.  For a very short time allocate memory
    // to hold the Registry path zero-terminated so that we can use it to
    // delve into the Registry.
    //

        RtlCopyUnicodeString(ephemeralRegistryPath, inPath);    
        RtlCopyUnicodeString(parameterRegistryPath, inPath);    
        RtlCopyUnicodeString(registryPathName,      inPath);    


        RtlAppendUnicodeToString(ephemeralRegistryPath, EPHEMERAL_SUBKEY);
        RtlAppendUnicodeToString(parameterRegistryPath, PARMS_SUBKEY);

 

        //
        //  Null terminate for some uses (but don't increase the 'length' or
        //  the UNICODE_STRING version will have a 0 on the end.
        //
        
        ephemeralRegistryPath->Buffer[ephemeralRegistryPath->Length / sizeof(UNICODE_NULL)] = UNICODE_NULL;
        parameterRegistryPath->Buffer[parameterRegistryPath->Length / sizeof(UNICODE_NULL)] = UNICODE_NULL;
        registryPathName->Buffer[registryPathName->Length / sizeof(UNICODE_NULL)] = UNICODE_NULL;    
        
        return ret;
}


 NTSTATUS TargetReadRegistry(
    IN PDRIVER_OBJECT DriverObject,   // Driver object
    IN PUNICODE_STRING path,          // base path to keys
    OUT PULONG debugMask,             // 32-bit binary debug mask
    OUT PULONG eventLog,              // Boolean: do we log events?
    OUT PULONG shouldBreak,           // Boolean: break in DriverEntry?
    OUT PULONG interrupt_Line,
    OUT PUCHAR registerAddress,
    OUT PHYSICAL_ADDRESS *registerPhysicalAddress    
        )
{
    //
    // We use this to query into the registry as to get initializationa and
    // debug information for our driver
    //
    RTL_QUERY_REGISTRY_TABLE paramTable[7];  // Parameter table -- parameters key
    RTL_QUERY_REGISTRY_TABLE eParamTable[7];  // Parameter table -- epheral key of simulator
    ULONG zero = 0;                          // default value 0
    ULONG one = 1;                           // default value 1
    ULONG sixteenK = 16 * 1024;              // default value for 16K
    ULONG notConfigurable = 0;
    ULONG model30 = 0;
    NTSTATUS status = STATUS_UNSUCCESSFUL;   // assume failure
     // We set these values to their defaults in case there are any failures

      // We set these values to their defaults in case there are any failures
    *debugMask = 0;
    *shouldBreak = 0;
       { 
          RtlZeroMemory(&paramTable[0], sizeof(paramTable)); // mandatory


          paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
          paramTable[0].Name = REG_BREAK ;
          paramTable[0].EntryContext = shouldBreak;
          paramTable[0].DefaultType = REG_DWORD;
          paramTable[0].DefaultData = &zero;
          paramTable[0].DefaultLength = sizeof(ULONG);

          paramTable[1].Flags = RTL_QUERY_REGISTRY_DIRECT;
          paramTable[1].Name = REG_DBG ;
          paramTable[1].EntryContext = debugMask;
          paramTable[1].DefaultType = REG_DWORD;
          paramTable[1].DefaultData = &zero;
          paramTable[1].DefaultLength = sizeof(ULONG);

          paramTable[2].Flags = RTL_QUERY_REGISTRY_DIRECT;
          paramTable[2].Name = REG_EVENT ;
          paramTable[2].EntryContext = eventLog;
          paramTable[2].DefaultType = REG_DWORD;
          paramTable[2].DefaultData = &zero;
          paramTable[2].DefaultLength = sizeof(ULONG);
   
          eParamTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;
          eParamTable[0].Name = REG_DEFAULT_INTLINE ;
          eParamTable[0].EntryContext = interrupt_Line;
          eParamTable[0].DefaultType = REG_DWORD;
          eParamTable[0].DefaultData = &zero;
          eParamTable[0].DefaultLength = sizeof(ULONG);
        
          eParamTable[1].Flags = RTL_QUERY_REGISTRY_DIRECT;
          eParamTable[1].Name = REG_BUF_LOG_ADDRESS;
          eParamTable[1].EntryContext = registerAddress;
          eParamTable[1].DefaultType = REG_DWORD;
          eParamTable[1].DefaultData = &zero;
          eParamTable[1].DefaultLength = sizeof(ULONG);

          eParamTable[2].Flags = RTL_QUERY_REGISTRY_DIRECT;
          eParamTable[2].Name = REG_BUF_PHYS_ADDRESS_LO ;
          eParamTable[2].EntryContext = &registerPhysicalAddress->LowPart;
          eParamTable[2].DefaultType = REG_DWORD;
          eParamTable[2].DefaultData = &zero;
          eParamTable[2].DefaultLength = sizeof(ULONG);

          eParamTable[3].Flags = RTL_QUERY_REGISTRY_DIRECT;
          eParamTable[3].Name =  REG_BUF_PHYS_ADDRESS_HI ;
          eParamTable[3].EntryContext = &registerPhysicalAddress->HighPart;
          eParamTable[3].DefaultType = REG_DWORD;
          eParamTable[3].DefaultData = &zero;
          eParamTable[3].DefaultLength = sizeof(ULONG);

        if (!NT_SUCCESS( status =
                     RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE | RTL_REGISTRY_OPTIONAL,
                                               path->Buffer,
                                               &paramTable[0],
                                               NULL,
                                               NULL)))
        { 
          // If it failed, it may have partially updated the variables
          // The query function quits on the first error
          // to ensure that everything is consistent, we reset the values
            KdPrint( ("readReg: Failed return uncessful\n") );
            *shouldBreak = 0;
            *debugMask = 0;
            status = STATUS_UNSUCCESSFUL;
        } 
        else
        { 
//        RtlAppendUnicodeToString(ephemeralRegistryPath, EPHEMERAL_SUBKEY);

            if (!NT_SUCCESS( status =
                     RtlQueryRegistryValues(RTL_REGISTRY_ABSOLUTE | RTL_REGISTRY_OPTIONAL,
                                           L"\\REGISTRY\\Machine\\System\\CurrentControlSet\\Services\\HdwSim\\Ephemeral ", //???? CHANGE THIS ???
//                                           L"\\REGISTRY\\Machine\\System\\ControlSet001\\Services\\HdwSim\\Ephemeral ", //???? CHANGE THIS ???
                                               &eParamTable[0],
                                               NULL,
                                               NULL)))
            { 
              // If it failed, it may have partially updated the variables
              // The query function quits on the first error
              // to ensure that everything is consistent, we reset the values
              KdPrint( ("readReg: Failed return uncessful\n") );
                // interrupt_Line
                // registerAddress
                // &registerPhysicalAddress->LowPart
                // &registerPhysicalAddress->HighPart
              status = STATUS_UNSUCCESSFUL;
            } 
        else
        { 
          status = STATUS_SUCCESS;
        } 
        }

    
   } /* got path */
 return  ( status);
  }



