// RegData.cpp : implementation file
//

#include "stdafx.h"
#include "Simulator.h"
#include "RegData.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRegData

CRegData::CRegData()
{
}

CRegData::~CRegData()
{
}


BEGIN_MESSAGE_MAP(CRegData, CEdit)
	//{{AFX_MSG_MAP(CRegData)
	ON_WM_CHAR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRegData message handlers

/****************************************************************************
*                              CRegData::OnChar
* Inputs:
*       UINT nChar: Character input
*	UINT nRepCnt: Repeat count
*	UINT nFlags: Flags
* Result: void
*       
* Effect: 
*       Ignores input data; forces read-only without r/o appearance
****************************************************************************/

void CRegData::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
 	MessageBeep(0);
	// CEdit::OnChar(nChar, nRepCnt, nFlags);

}

/****************************************************************************
*                           CRegData::SetWindowText
* Inputs:
*       BYTE value: Value to set
* Result: void
*       
* Effect: 
*       Converts the byte to hex and stores it
****************************************************************************/

void CRegData::SetWindowText(BYTE value)
    {
     CString s;
     s.Format(_T("%02x"), value);
     CString t;
     CEdit::GetWindowText(t);
     if(s != t) // avoid flicker!
	CEdit::SetWindowText(s);
    }
