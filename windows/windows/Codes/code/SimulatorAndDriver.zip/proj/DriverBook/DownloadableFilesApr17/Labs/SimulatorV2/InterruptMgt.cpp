// InterruptMgt.cpp : implementation file
//

#include "stdafx.h"
#include "Simulator.h"
#include "regvars.h"
#include "NumericEdit.h"
#include "InterruptMgt.h"
#include "help.h"
#include "uwm.h"
#include "err.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInterruptMgt dialog


CInterruptMgt::CInterruptMgt(CWnd* pParent /*=NULL*/)
	: CDialog(CInterruptMgt::IDD, pParent)
{
    initialized = FALSE;
	//{{AFX_DATA_INIT(CInterruptMgt)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CInterruptMgt::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInterruptMgt)
	DDX_Control(pDX, IDC_PERR_CAPTION, c_c_ProbErr);
	DDX_Control(pDX, IDC_SPINSPURIOUS, c_SpinSpurious);
	DDX_Control(pDX, IDC_SPINPOVR, c_SpinOvr);
	DDX_Control(pDX, IDC_SPINPERR, c_SpinErr);
	DDX_Control(pDX, IDC_PSPURIOUS, c_ProbSpurious);
	DDX_Control(pDX, IDC_POVR, c_ProbOvr);
	DDX_Control(pDX, IDC_PERR, c_ProbErr);
	DDX_Control(pDX, IDC_SPURIOUS, c_Spurious);
	DDX_Control(pDX, IDC_SPINLOSE, c_SpinLose);
	DDX_Control(pDX, IDC_PLOSE, c_ProbLose);
	DDX_Control(pDX, IDC_LOSE, c_Lose);
	DDX_Control(pDX, IDC_BOTH, c_Both);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInterruptMgt, CDialog)
	//{{AFX_MSG_MAP(CInterruptMgt)
	ON_BN_CLICKED(IDCANCEL, OnCloseDialog)
	ON_BN_CLICKED(IDC_BOTH, OnBoth)
	ON_BN_CLICKED(IDC_LOSE, OnLose)
	ON_EN_CHANGE(IDC_PLOSE, OnChangePlose)
	ON_EN_CHANGE(IDC_PSPURIOUS, OnChangePspurious)
	ON_BN_CLICKED(IDC_SPURIOUS, OnSpurious)
	ON_EN_CHANGE(IDC_PERR, OnChangePerr)
	ON_EN_CHANGE(IDC_POVR, OnChangePovr)
	ON_BN_CLICKED(IDC_HELP_COMMAND, OnHelp)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CLOSE, OnCloseDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInterruptMgt message handlers


/****************************************************************************
*                        CInterruptMgt::updateControls
* Result: void
*       
* Effect: 
*       Updates all the controls
****************************************************************************/

void CInterruptMgt::updateControls()
    {
     BOOL enable = c_Spurious.GetCheck() == BST_CHECKED || c_Both.GetCheck() == BST_CHECKED;
     BOOL caption = enable;

     c_SpinSpurious.EnableWindow(enable);
     c_ProbSpurious.EnableWindow(enable);

     enable = c_Lose.GetCheck() == BST_CHECKED || c_Both.GetCheck() == BST_CHECKED;

     caption |= enable;

     c_SpinLose.EnableWindow(enable);
     c_ProbLose.EnableWindow(enable);

     caption |= c_Both.GetCheck() == BST_CHECKED;

     c_c_ProbErr.EnableWindow(caption);
    }


/****************************************************************************
*                         CInterruptMgt::OnInitDialog
* Result: BOOL
*       
* Effect: 
*       Initializes all the controls
****************************************************************************/

BOOL CInterruptMgt::OnInitDialog() 
{
 	initialized = FALSE;

	CDialog::OnInitDialog();
	
 	c_Lose.SetCheck(BST_CHECKED);

 	c_SpinSpurious.SetRange(0, 100);
	c_SpinOvr.SetRange(0, 100);
	c_SpinErr.SetRange(0, 100);
	c_SpinLose.SetRange(0, 100);

	RegistryInt pSpurious(IDS_PROB_SPURIOUS);
	pSpurious.load(0);
	c_SpinSpurious.SetPos(pSpurious.value);

	RegistryInt pOvrUnd(IDS_PROB_OVR_UND);
	pOvrUnd.load(0);
	c_SpinOvr.SetPos(pOvrUnd.value);

	RegistryInt pErr(IDS_PROB_ERR);
	pErr.load(0);
	c_SpinErr.SetPos(pErr.value);

	RegistryInt pLost(IDS_PROB_LOST);
	pLost.load(0);
	c_SpinLose.SetPos(pLost.value);

	initialized = TRUE;

	updateControls();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CInterruptMgt::OnBoth() 
{
 updateControls();
	
}

void CInterruptMgt::OnLose() 
{
 updateControls();
}

void CInterruptMgt::OnChangePlose() 
{
 if(!initialized)
    return;

 if(c_ProbLose.GetWindowInt() > 100)
    c_ProbLose.SetWindowText(100);

 GetParent()->SendMessage(UWM_SET_PROB, PROB_LOST, c_ProbLose.GetWindowInt());

}

void CInterruptMgt::OnChangePspurious() 
{
 if(!initialized)
    return;

 if(c_ProbSpurious.GetWindowInt() > 100)
    c_ProbSpurious.SetWindowText(100);
	
 GetParent()->SendMessage(UWM_SET_PROB, PROB_SPURIOUS, c_ProbSpurious.GetWindowInt());
}

void CInterruptMgt::OnSpurious() 
{
 updateControls();	
}

void CInterruptMgt::OnChangePerr() 
{
 if(!initialized)
    return;
 if(c_ProbErr.GetWindowInt() > 100)
    c_ProbErr.SetWindowText(100);	
 GetParent()->SendMessage(UWM_SET_PROB, PROB_ERR, c_ProbErr.GetWindowInt());
}

void CInterruptMgt::OnChangePovr() 
{
 if(!initialized)
    return;
 if(c_ProbOvr.GetWindowInt() > 100)
    c_ProbOvr.SetWindowText(100);
 GetParent()->SendMessage(UWM_SET_PROB, PROB_OVRUND, c_ProbOvr.GetWindowInt());
}

/****************************************************************************
*                            CInterruptMgt::OnHelp
* Result: void
*       
* Effect: 
*       Invokes help
****************************************************************************/

void CInterruptMgt::OnHelp() 
{
 WinHelp(HID_INTERRUPT_MGT, HELP_CONTEXT);	
}

/****************************************************************************
*                          CInterruptMgt::OnDestroy
* Result: void
*       
* Effect: 
*       Notifies the parent that the window is shutting down
****************************************************************************/

void CInterruptMgt::OnDestroy() 
{
 	GetParent()->SendMessage(UWM_IMGR_CLOSE);	

	CDialog::OnDestroy();
}

void CInterruptMgt::OnCloseDialog() 
{
 DestroyWindow();	
}

void CInterruptMgt::PostNcDestroy() 
{
 	delete this;
	
	CDialog::PostNcDestroy();
}
