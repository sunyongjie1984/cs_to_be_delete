// Comment.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CComment dialog

class CComment : public CDialog
{
// Construction
public:
	CComment(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CComment)
	enum { IDD = IDD_COMMENT };
	CEdit	c_Comment;
	CButton	c_OK;
	CString	m_Comment;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CComment)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void updateControls();

	// Generated message map functions
	//{{AFX_MSG(CComment)
	afx_msg void OnChangeComment();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
