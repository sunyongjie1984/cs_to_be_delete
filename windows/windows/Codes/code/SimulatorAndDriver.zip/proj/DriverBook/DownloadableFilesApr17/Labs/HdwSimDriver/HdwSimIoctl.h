/*****************************************************************************
*           Change Log
*  Date     | Change
*-----------+-----------------------------------------------------------------
* 15-Mar-98 | Created change log
* 15-Mar-98 | Split out application-specific parts from driver-specific
*           | parts.  This file is now shared between the user-level
*           | application code and the driver code
* 18-Mar-98 | Added new codes for get/set of debug mask
* 18-Mar-98 | debugMask now stored in device extension
*****************************************************************************/
typedef struct _HDW_SIM_REGS 
   {
    UCHAR writeBitmap;		// used on write, ignored on read
    UCHAR registers[6];		// actual register image
    ULONG interrupt_IDT;	// ignored on write, filled in on read
    ULONG interrupt_Line;	// ignored on write, filled in on read
   } HDW_SIM_REGS, * LPHDW_SIM_REGS, *PHDW_SIM_REGS;

// This macro is used to set the bit in the bitmap based on the
// register index
#define WRITE_BITMAP(r) (1 << (r))


typedef struct _HDW_SIM_SET_INTR
    {
     ULONG interrupt_Line;
    } HDW_SIM_SET_INTR, * LPHDW_SIM_SET_INTR, *PHDW_SIM_SET_INTR;

typedef struct _HDW_SIM_DEBUGMASK 
    {
     ULONG value;
    } HDW_SIM_DEBUGMASK, * LPHDW_SIM_DEBUGMASK, * PHDW_SIM_DEBUGMASK;

// DebugMask bits
#define DEBUGMASK_TRACE_REGISTERS 0x00000002 //
#define DEBUGMASK_TRACE_IOCTLS    0x00000004 //

typedef union _HDW_SIM_DATA_OUTPUT
    {
     HDW_SIM_REGS registers;
     HDW_SIM_DEBUGMASK mask;
    } HDW_SIM_DATA_OUTPUT, * LPHDW_SIM_DATA_OUTPUT, *PHDW_SIM_DATA_OUTPUT;

typedef union _HDW_SIM_DATA_INPUT
    {
     HDW_SIM_REGS registers;
     HDW_SIM_SET_INTR setInterrupt;
     HDW_SIM_DEBUGMASK mask;
    } HDW_SIM_DATA_INPUT, * LPHDW_SIM_DATA_INPUT, *PHDW_SIM_DATA_INPUT;

// Define the IOCTL codes we will use.  The IOCTL code contains a 
// command identifier, plus onther information about the device,
// the type of access with which the file must have been opened, and the
// type of buffering

#define HDW_SIM_TYPE (ULONG)43000      	// 32768..65535 "User defined" range
#define HDW_SIM_IOCTL_BASE (USHORT)2833 // 2048..4095 "User defined" range

// jmn: these don't belong here
#define writeBitmap_inCommand   0x01
#define writeBitmap_inStatus    0x02
#define writeBitmap_inData      0x04
#define writeBitmap_outCommand  0x08
#define writeBitmap_outStatus   0x10
#define writeBitmap_outData     0x20

#define INDEX_inCommand         0x00
#define INDEX_inStatus          0x01
#define INDEX_inData            0x02
#define INDEX_outCommand        0x03
#define INDEX_outStatus         0x04
#define INDEX_outData           0x05

enum 
   {
    HDW_SIM_IOCTL_INITIALIZE  = HDW_SIM_IOCTL_BASE,
    HDW_SIM_IOCTL_SET_INTR,
    HDW_SIM_IOCTL_GEN_INTR,
    HDW_SIM_IOCTL_REGS,
    HDW_SIM_IOCTL_SET_TRACE,
    HDW_SIM_IOCTL_GET_TRACE
   };

/****************************************************************************
*                          IOCTL_HDW_SIM_INITIALIZE
* Inputs:
*	InBuffer: NULL
*	InBufferSize: 0
*	OutBuffer: NULL
*	OutBufferSize: 0
* Result: BOOL
*       
* Effect: 
*       Initializes the hardware simulator
****************************************************************************/

#define IOCTL_HDW_SIM_INITIALIZE \
    CTL_CODE(HDW_SIM_TYPE,  HDW_SIM_IOCTL_INITIALIZE, METHOD_BUFFERED, \
    		FILE_WRITE_DATA | FILE_READ_DATA)


/****************************************************************************
*                           IOCTL_HDW_SIM_SET_INTR
* Inputs:
*       InBuffer: LPHDW_SIM_SET_INTR
*	InBufferSize: sizeof(HDW_SIM_SET_INTR)
*	OutBuffer: NULL
*	OutBufferSize: 0
* Result: BOOL
*       
* Effect: 
*       Sets the IRQ line to be used for generating IRQs
****************************************************************************/

#define IOCTL_HDW_SIM_SET_INTR \
    CTL_CODE(HDW_SIM_TYPE,  HDW_SIM_IOCTL_SET_INTR, METHOD_BUFFERED, \
    		FILE_WRITE_DATA | FILE_READ_DATA)


/****************************************************************************
*                           IOCTL_HDW_SIM_GEN_INTR
* Inputs:
*	InBuffer: NULL
*	InBufferSize: 0
*	OutBuffer: NULL
*	OutBufferSize: 0
* Result: BOOL
*       
* Effect: 
*       Generates an IRQ request on the previously-established IRQ line
****************************************************************************/

#define IOCTL_HDW_SIM_GEN_INTR \
    CTL_CODE(HDW_SIM_TYPE,  HDW_SIM_IOCTL_GEN_INTR, METHOD_BUFFERED, \
    		FILE_WRITE_DATA | FILE_READ_DATA)

/****************************************************************************
*                             IOCTL_HDW_SIM_REGS
* Inputs:
*   	InBuffer: LPHDW_SIM_REGS: Pointer to register structure which has
*				a valid write bitmap (may be 0)
*	InBufferSize: sizeof(HDW_SIM_REGS)
*	OutBuffer: LPHDW_SIM_REGS: Pointer to a place to put new register 
				values
*	OutBufferSize: sizeof(HDW_SIM_REGS)
* Result: BOOL
*       
* Effect: 
*       Reads all current register values into the OutBuffer, then writes
*	the selected register values from the InBuffer
****************************************************************************/
      
#define IOCTL_HDW_SIM_REGS  \
    CTL_CODE(HDW_SIM_TYPE,  HDW_SIM_IOCTL_REGS, METHOD_BUFFERED, \
    		FILE_WRITE_DATA | FILE_READ_DATA)


/****************************************************************************
*                             IOCTL_HDW_SIM_GET_TRACE
* Inputs:
*       Input: unused, can be NULL
*	Output: at least sizeof(HDW_SIM_DEBUGMASK)
* Result: BOOL
*       
* Effect: 
*       Retrieves the current state of the debug mask
****************************************************************************/

#define IOCTL_HDW_SIM_GET_TRACE  \
    CTL_CODE(HDW_SIM_TYPE,  HDW_SIM_IOCTL_GET_TRACE, METHOD_BUFFERED, \
    		FILE_READ_DATA)

/****************************************************************************
*                             IOCTL_HDW_SIM_SET_TRACE
* Inputs:
*       Input: at least sizeof(HDW_SIM_DEBUGMASK)
*	Output: unused, can be NULL
* Result: BOOL
*       
* Effect: 
*       Sets a new state of the debug mask
****************************************************************************/

#define IOCTL_HDW_SIM_SET_TRACE  \
    CTL_CODE(HDW_SIM_TYPE,  HDW_SIM_IOCTL_SET_TRACE, METHOD_BUFFERED, \
    		FILE_WRITE_DATA)
