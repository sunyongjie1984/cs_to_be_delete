// SpinnerButton.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSpinnerButton window

class CSpinnerButton : public CButton
{
// Construction
public:
	CSpinnerButton();
	void pulse() { pos = (pos + 1) % 8; InvalidateRect(NULL); }
	void setMode(BOOL m) { mode = m; }
	BOOL getMode() { return mode; }
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpinnerButton)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSpinnerButton();

	// Generated message map functions
protected:
	UINT pos;
	BOOL mode;

	static CBrush green;
	static CBrush red;

	//{{AFX_MSG(CSpinnerButton)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
