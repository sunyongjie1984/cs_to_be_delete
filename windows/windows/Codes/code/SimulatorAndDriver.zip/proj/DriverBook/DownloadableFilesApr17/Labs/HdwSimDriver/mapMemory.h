NTSTATUS MapSystemLogicalMemory(
    IN PDEVICE_OBJECT DeviceObject,
    IN PVOID          LogicalAddress,
    IN ULONG          LengthToMap,
    OUT PVOID         OutBuffer,
    IN ULONG          OutputBufferLength
    );

NTSTATUS MapBoardMemory(
    IN PDEVICE_OBJECT DeviceObject,
    PHYSICAL_ADDRESS   physicalAddressBase,   
    IN ULONG          LengthToMap,
    OUT PVOID         OutBuffer,
    IN ULONG          OutputBufferLength
    );
