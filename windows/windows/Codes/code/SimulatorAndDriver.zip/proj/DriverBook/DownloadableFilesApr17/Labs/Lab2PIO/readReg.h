//ReadReg
#define REG_DBG                  (L"DebugMask")
#define REG_EVENT                (L"LogEvents")
#define REG_BREAK                (L"BreakOnEntry")
#define REG_INTLINE              (L"InterruptLine")
#define REG_DEFAULT_INTLINE      (L"DefaultInterruptLine")
#define REG_INTIDT               (L"InterruptIDT")
#define REG_BUF_LOG_ADDRESS      (L"BufferLogicalAddress")
#define REG_BUF_PHYS_ADDRESS_LO  (L"BufferPhysicalAddressLow")
#define REG_BUF_PHYS_ADDRESS_HI  (L"BufferPhysicalAddressHigh")

#define REG_PATHNAME             (L"PathName")
    
#define PARMS_SUBKEY             (L"\\Parameters")
#define PARMS_DEVICE0            (L"\\Device0")
#define EPHEMERAL_SUBKEY         (L"\\Ephemeral")
#define DEVICES_SUBKEY           (L"Devices")
#define DRIVER_PARMS             (L"DriverParameters")
                                       
NTSTATUS helloReadRegistry(
    IN PDRIVER_OBJECT DriverObject,   // Driver object
    IN PUNICODE_STRING RegistryPath,  // base path to keys
    OUT PULONG debugMask,             // 32-bit binary debug mask
    OUT PULONG eventLog,              // Boolean: do we log events?
    OUT PULONG shouldBreak            // Boolean: break in DriverEntry?
    );




NTSTATUS initParameterDevicePath(
       IN PDRIVER_OBJECT DriverObject,
       IN PUNICODE_STRING  inPath,    // zero terminated UNICODE_STRING with parameters path
       UNICODE_STRING * parameterRegistryPath,
       UNICODE_STRING * registryPathName
       );
