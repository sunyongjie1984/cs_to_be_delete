#include "windows.h"
#include "winioctl.h"
#include "stdio.h"
#include "stdlib.h"
//#include "ioaccess`.h"

#include "Lab2Ioctl.h"

unsigned char InBuffer[1000];
unsigned char OutBuffer[1000];

unsigned char testString[] = "now is the time for all good men to come to the ...";
 


int IoctlResult;
HANDLE hTest;
int ReturnedLength;
unsigned int offset;



int main(int argc, char **argv)
{
   if ((hTest = CreateFile(
                     "\\\\.\\Lab2",
                     GENERIC_READ | GENERIC_WRITE,
                     0,
                     NULL,
                     OPEN_EXISTING,
                     FILE_ATTRIBUTE_NORMAL,
                     NULL
                     )) != ((HANDLE)-1))
    {
        printf("CreateFile worked!!!\n");
    }
    else
    {
        printf("Can't get a handle to driver\n");

	return 1 ;
    }


        // initialize the board

        IoctlResult = DeviceIoControl(
                            hTest,             // Handle to device
                            (unsigned long)IOCTL_LAB_INITIALIZE, // IO Control code for Read
                            &InBuffer,         // Buffer to driver.
                            sizeof(InBuffer),  // Length of buffer in bytes.
                            &OutBuffer,        // Buffer from driver.
                            sizeof(OutBuffer), // Length of buffer in bytes.
                            &ReturnedLength,   // Bytes placed in DataBuffer.
                            NULL               // NULL means wait till op. completes.
                            );

            if (IoctlResult)                            // Did the IOCTL succeed?
            {
	          printf("Ioctl initialize worked\n" );
	        }
            else
            {
	          printf("Ioctl initialize failed\n" );
            }


        

    // try reading the board

    IoctlResult = DeviceIoControl(
                        hTest,             // Handle to device
                        (unsigned long)IOCTL_LAB_HELLO_READ, // IO Control code for Read
                        &InBuffer,         // Buffer to driver.
                        sizeof(InBuffer),  // Length of buffer in bytes.
                        &OutBuffer,        // Buffer from driver.
                        sizeof(OutBuffer), // Length of buffer in bytes.
                        &ReturnedLength,   // Bytes placed in DataBuffer.
                        NULL               // NULL means wait till op. completes.
                        );

    if (IoctlResult)                            // Did the IOCTL succeed?
    {
	    printf("Ioctl read worked ? count = %d string='%s'\n", ReturnedLength, OutBuffer );
	}
    else
    {
	    printf("Ioctl read failed\n" );
    }

    // try writting the board

    IoctlResult = DeviceIoControl(
                        hTest,             // Handle to device
                        (unsigned long)IOCTL_LAB_HELLO_WRITE, // IO Control code for Read
                        &testString,       // &InBuffer,        // Buffer to driver.
                        5,                 // sizeof(InBuffer), // Length of buffer in bytes.
                        &OutBuffer,        // Buffer from driver.
                        sizeof(OutBuffer), // Length of buffer in bytes.
                        &ReturnedLength,   // Bytes placed in DataBuffer.
                        NULL               // NULL means wait till op. completes.
                        );

    if (IoctlResult)                            // Did the IOCTL succeed?
    {
	    printf("Ioctl write worked ?   Count = %d\n", ReturnedLength );
	}
    else
    {
	    printf("Ioctl write failed\n" );
    }


  


        CloseHandle(hTest);


    return 1;

}

