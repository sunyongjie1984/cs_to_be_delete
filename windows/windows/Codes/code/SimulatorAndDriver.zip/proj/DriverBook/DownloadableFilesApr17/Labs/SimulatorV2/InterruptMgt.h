// InterruptMgt.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CInterruptMgt dialog

class CInterruptMgt : public CDialog
{
// Construction
public:
	CInterruptMgt(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CInterruptMgt)
	enum { IDD = IDD_INTERRUPTS };
	CButton	c_c_ProbErr;
	CSpinButtonCtrl	c_SpinSpurious;
	CSpinButtonCtrl	c_SpinOvr;
	CSpinButtonCtrl	c_SpinErr;
	CNumericEdit	c_ProbSpurious;
	CNumericEdit	c_ProbOvr;
	CNumericEdit	c_ProbErr;
	CButton	c_Spurious;
	CSpinButtonCtrl	c_SpinLose;
	CNumericEdit	c_ProbLose;
	CButton	c_Lose;
	CButton	c_Both;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInterruptMgt)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
protected:
	void updateControls();
	BOOL initialized;

	// Generated message map functions
	//{{AFX_MSG(CInterruptMgt)
	virtual BOOL OnInitDialog();
	afx_msg void OnBoth();
	afx_msg void OnLose();
	afx_msg void OnChangePlose();
	afx_msg void OnChangePspurious();
	afx_msg void OnSpurious();
	afx_msg void OnChangePerr();
	afx_msg void OnChangePovr();
	afx_msg void OnHelp();
	afx_msg void OnDestroy();
	afx_msg void OnCloseDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
