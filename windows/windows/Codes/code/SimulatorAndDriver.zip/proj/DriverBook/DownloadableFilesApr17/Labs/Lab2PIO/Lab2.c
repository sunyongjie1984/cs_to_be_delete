
// Hardware Simulator driver

/*****************************************************************************
*           Change Log
*  Date     | Change
*-----------+-----------------------------------------------------------------
* 10-06-97  | END - Created
* 17-Mar-98 | <jmn> Added error printout for bad DeviceIoControl operation
*****************************************************************************/


/*****************************************************************************
*                       To Do
*-----------------------------------------------------------------------------
  put and get packet routines are not implemented
  interrupts not used
  startio not used
  device timeout not implemented

*****************************************************************************/
#include "ntddk.h"

#include "Lab2.h"
#include "Lab2Ioctl.h"
#include "HSTestReadReg.h"
#include "readReg.h"




#define DBG_MSG_HDR "Lab2"



NTSTATUS Lab2Open(
    IN PDEVICE_OBJECT deviceObject,
    IN PIRP Irp );

NTSTATUS Lab2Close(
    IN PDEVICE_OBJECT deviceObject,
    IN PIRP Irp );

NTSTATUS Lab2DeviceControl (
    IN PDEVICE_OBJECT deviceObject,
    IN PIRP Irp );

VOID Lab2Unload(
    IN PDRIVER_OBJECT driverObject );

BOOLEAN LabInterruptServiceRoutine(
    IN PKINTERRUPT Interrupt,
    IN OUT PVOID Context    );

static NTSTATUS LabSetupISR(
        PDEVICE_OBJECT deviceObject,
        ULONG interruptLine );      
        
VOID LabDpcRoutine(
    IN PKDPC Dpc,
    PDEVICE_OBJECT  deviceObject,
    IN PVOID SystemArgument1,
    IN PVOID SystemArgument2 );

NTSTATUS Lab2PutPacket(  
                        PDEVICE_OBJECT deviceObject,
                        UCHAR   *pBuffer,
                        ULONG   inBufferLength,
                        ULONG   *charCount);                         // RETURN transfer SIZE
NTSTATUS Lab2GetPacket(  
                        PDEVICE_OBJECT deviceObject,
                        UCHAR   *pBuffer,
                        ULONG   outBufferLength,
                        ULONG   *charCount);                         // RETURN transfer SIZE

/****************************************************************************
    Function:
              DriverEntry
    Arguments:

    Description:

    Returns:


*****************************************************************************/
NTSTATUS DriverEntry(
    IN PDRIVER_OBJECT driverObject,
    IN PUNICODE_STRING RegistryPath )
{

    PDEVICE_OBJECT deviceObject = NULL;
    NTSTATUS status;
    UNICODE_STRING uniNtNameString;
    UNICODE_STRING uniDosNameString;

    NTSTATUS retReg;

    BOOLEAN GotResources;

    //
    //  registry values
    //
    ULONG debugMask;
    ULONG eventLog;
    ULONG shouldBreak;
    ULONG interruptLine;
    ULONG interruptIDT;



   unsigned int busNumber;


   PLAB2_DEVICE_EXTENSION extension;

   VOID             *registerAddress;
   PHYSICAL_ADDRESS  registerPhysicalAddress;

   unsigned int      vgaBaseReg;
   unsigned int      baseReg = 0;
   ULONG             baseAddressReg1;

   ULONG             lengthToMap;
   unsigned int      i;

   KdPrint( ("%s: Entered the Lab2 driver!\n",   DBG_MSG_HDR) );


   //
   // Read the registry for our parameters
   //
   retReg = helloReadRegistry(driverObject, RegistryPath, &debugMask, &eventLog,
                              &shouldBreak );

   //
   // read the registry for the "address" of the hardware simulator
   //
   retReg = hardwareSimReadRegistry(driverObject, RegistryPath, &interruptLine, &interruptIDT,
                                    &registerAddress, &registerPhysicalAddress );


   KdPrint( ("%s: returned from readRegistry!\n",   DBG_MSG_HDR) );


   if (shouldBreak)
   {
      DbgBreakPoint();
   }

    //
    // Create counted string version of our device name.
    //

    RtlInitUnicodeString( &uniNtNameString, NT_DEVICE_NAME );



    //
    // Create the device object
    //

    status = IoCreateDevice(
                 driverObject,
                 sizeof(LAB2_DEVICE_EXTENSION),        //  device extension
                 &uniNtNameString,
                 FILE_DEVICE_UNKNOWN,
                 0,                     // No standard device characteristics
                 FALSE,                 // This isn't an exclusive device
                 &deviceObject
                 );

    if ( !NT_SUCCESS(status) )
    {

        KdPrint(("%s could not create device\n",   DBG_MSG_HDR));
        status = STATUS_NO_SUCH_DEVICE;
        return status;
    }
    extension = deviceObject->DeviceExtension;   
    extension->DeviceObject = deviceObject;   

    extension->BusNumber = busNumber;

    // 
    // save information from registry in extension
    //
    
    extension->registerAddress          = registerAddress;        
    extension->registerPhysicalAddress  = registerPhysicalAddress;
    extension->interruptLine            = interruptLine;
    extension->interruptIDT             = interruptIDT;

    extension->debugMask      = debugMask;
    extension->eventLog       = eventLog;
    extension->shouldBreak    = shouldBreak;

    
    //
    // Create dispatch points for create/open, close, unload.
    //

    driverObject->MajorFunction[IRP_MJ_CREATE]          = Lab2Open;
    driverObject->MajorFunction[IRP_MJ_CLOSE]           = Lab2Close;
    driverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL]  = Lab2DeviceControl;

    driverObject->DriverUnload = Lab2Unload;

        //
        // Other possible dispatch entries
        //
        // DriverObject->MajorFunction[IRP_MJ_READ] 					= 
        // DriverObject->MajorFunction[IRP_MJ_WRITE] 					=
        // DriverObject->MajorFunction[IRP_MJ_INTERNAL_DEVICE_CONTROL]  =   // For calls from other drivers
        // DriverObject->MajorFunction[IRP_MJ_SHUTDOWN] 				=   // Note driver MUST call IoRegisterShutdownNotification()

        // DriverObject->MajorFunction[IRP_MJ_QUERY_INFORMATION] 		=
        // DriverObject->MajorFunction[IRP_MJ_SET_INFORMATION] 			=
        // DriverObject->MajorFunction[IRP_MJ_CLEANUP] 					=
        // DriverObject->MajorFunction[IRP_MJ_FLUSH_BUFFERS] 		    =
        // DriverObject->MajorFunction[IRP_MJ_SET_VOLUME_INFORMATION]   =
        // DriverObject->MajorFunction[IRP_MJ_QUERY_VOLUME_INFORMATION] =
        // DriverObject->MajorFunction[IRP_MJ_DIRECTORY_CONTROL]    	=
        // DriverObject->MajorFunction[IRP_MJ_FILE_SYSTEM_CONTROL]		=
        // DriverObject->MajorFunction[IRP_MJ_LOCK_CONTROL]  			=
        // DriverObject->MajorFunction[IRP_MJ_QUERY_EA]   				=
        // DriverObject->MajorFunction[IRP_MJ_SET_EA]   				=
        // DriverObject->MajorFunction[IRP_MJ_SCSI]  					=



    KdPrint( ("%s: just about ready!\n",   DBG_MSG_HDR) );

	//
	// check if resources (ports and interrupt) are available
	//

//
// A PRODUCT DRIVER WOULD REPORT (NON) RESOURCE USAGE HERE
//


    //
    // Do Buffered I/O.    A nop Read and write are not supported by this driver
    //
    deviceObject->Flags |= DO_BUFFERED_IO;

    //
    // Create counted string version of our Win32 device name.
    //
    RtlInitUnicodeString( &uniDosNameString, DOS_DEVICE_NAME );

    //
    // Create a link from our device name to a name in the Win32 namespace.
    //

    status = IoCreateSymbolicLink( &uniDosNameString, &uniNtNameString );

    if (!NT_SUCCESS(status))
    {
        KdPrint( ("%s: Couldn't create the symbolic link\n",   DBG_MSG_HDR) );

        IoDeleteDevice( driverObject->DeviceObject );
        return status;
    }

    //
    //  Connect an ISR for our device
    //
//     status = LabSetupISR( deviceObject, interruptLine );




    KdPrint( ("%s: All initialized\n",   DBG_MSG_HDR) );


    return status;
}

/****************************************************************************
    Function:
              Lab2Open
    Arguments:

    Description:

    Returns:


*****************************************************************************/
NTSTATUS Lab2Open(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp )
{
    KdPrint( ("%s: Opened!!\n",   DBG_MSG_HDR) );


    //
    // No need to do anything.
    //

    //
    // Fill these in before calling IoCompleteRequest.
    //
    // DON'T get cute and try to use the status field of
    // the irp in the return status.  That IRP IS GONE as
    // soon as you call IoCompleteRequest.
    //


    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;

    IoCompleteRequest( Irp, IO_NO_INCREMENT );

    return STATUS_SUCCESS;
}

/****************************************************************************
    Function:
              Lab2Close
    Arguments:

    Description:

    Returns:


*****************************************************************************/
NTSTATUS Lab2Close(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp )
{

    KdPrint( ("%s: Closed!!\n",   DBG_MSG_HDR) );

    //
    // No need to do anything.
    //

    //
    // Fill these in before calling IoCompleteRequest.
    //
    // DON'T get cute and try to use the status field of
    // the irp in the return status.  That IRP IS GONE as
    // soon as you call IoCompleteRequest.
    //

    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;



    IoCompleteRequest( Irp, IO_NO_INCREMENT );

    return STATUS_SUCCESS;
}

/****************************************************************************
    Function:
              Lab2DeviceControl
    Arguments:

    Description:

    Returns:


*****************************************************************************/
NTSTATUS  Lab2DeviceControl(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp )
{
    NTSTATUS  ret = STATUS_SUCCESS;
    PIO_STACK_LOCATION irpStack;

    UCHAR *pBuffer;
    ULONG outBufferLength;
    ULONG inBufferLength;
    ULONG charCount = 0;

    PLAB2_DEVICE_EXTENSION extension;

    NTSTATUS status;


    KdPrint( ("%s: Device Control!!\n",   DBG_MSG_HDR) );

    extension = DeviceObject->DeviceExtension;
    irpStack = IoGetCurrentIrpStackLocation(Irp);

    pBuffer  = (UCHAR *)Irp->AssociatedIrp.SystemBuffer;  // for buffered i/o
    inBufferLength = irpStack->Parameters.DeviceIoControl.InputBufferLength;
    outBufferLength = irpStack->Parameters.DeviceIoControl.OutputBufferLength;


    switch(irpStack->Parameters.DeviceIoControl.IoControlCode)
    { /* ioControlCode */
        case  IOCTL_LAB_INITIALIZE:
             KdPrint( ("%s: Device Control  -- enter Initialize\n",   DBG_MSG_HDR) );

             break;

        case IOCTL_LAB_HELLO_READ:
             KdPrint( ("%s: Device Control  -- enter IOCTL_READ\n",   DBG_MSG_HDR) );

             status = Lab2GetPacket(  
                        DeviceObject,
                        pBuffer,
                        outBufferLength,
                        &charCount);       // RETURN transfer SIZE


             break;

        case IOCTL_LAB_HELLO_WRITE:
             KdPrint( ("%s: Device Control  -- enter IOCTL_WRITE\n",   DBG_MSG_HDR) );

             status = Lab2PutPacket(  
                        DeviceObject,
                        pBuffer,
                        inBufferLength,
                        &charCount);        // RETURN transfer SIZE

             break;
        default:
	     	KdPrint( ("%s: Unknown DeviceIoControl: %08x\n", 
			  DBG_MSG_HDR, 
			  irpStack->Parameters.DeviceIoControl.IoControlCode));
                ret = STATUS_UNSUCCESSFUL;

    } /* ioControlCode */

    KdPrint( ("%s: Device Control  -- return\n",   DBG_MSG_HDR) );
    //
    // Fill these in before calling IoCompleteRequest.
    //

    Irp->IoStatus.Status = ret;
    Irp->IoStatus.Information = 0;

    IoCompleteRequest( Irp, IO_NO_INCREMENT );


    return ret;
}

/****************************************************************************
    Function:
              Lab2Unload
    Arguments:

    Description:

    Returns:


*****************************************************************************/
VOID Lab2Unload( IN PDRIVER_OBJECT driverObject)
{
    UNICODE_STRING uniDosNameString;
    PLAB2_DEVICE_EXTENSION extension;
    BOOLEAN GotResources;

    extension = driverObject->DeviceObject->DeviceExtension;

    //
    // All *THIS* driver needs to do is to delete the allocated memory objects,
    // the device object and the
    // symbolic link between our device name and the Win32 visible name.
    //
    // Almost every other driver ever witten would need to do a
    // significant amount of work here deallocating stuff.
    //

    KdPrint( ("%s: Unloading!!\n",   DBG_MSG_HDR) );

    //
    // Disconnect the interrupt
    //
 //  IoDisconnectInterrupt(extension->InterruptObject);

//
// A PRODUCT DRIVER WOULD REPORT  RESOURCE USAGE HERE
//


    //
    // Create counted string version of our Win32 device name.
    //

    RtlInitUnicodeString( &uniDosNameString, DOS_DEVICE_NAME );

    //
    // Delete the link from our device name to a name in the Win32 namespace.
    //

    IoDeleteSymbolicLink( &uniDosNameString );

    //
    // Finally delete our device object
    //

    IoDeleteDevice( driverObject->DeviceObject );
}
  
/****************************************************************************
    Function:
              LowerIRQLandDelay
    Arguments:

    Description:

				The StartIo routine is called at DISPATCH IRQL.   Polling for 
				status bit changes, in the simulated hardware status registers, 
				will not show changes in the status bits since the simpuator 
				program (IRQL PASSIVE) will not execute. This function lowwers 
				the IRQL from DISPATCH to PASSIVE and allow the simulator program 
				to execute.

				This function violates the assumptions of the NT Kernal 
				and  MUST NOT BE USED IN A PRODUCTION DRIVER. 

    Returns:


*****************************************************************************/
NTSTATUS LowerIRQLandDelay()
{
   KIRQL previousIRQL;
   KIRQL notNeeded;
   LARGE_INTEGER delay = {0, 2000};
   NTSTATUS status;

#define DELAY_IN_MS 200   

   delay = RtlConvertLongToLargeInteger( (LONG) (-1 * 10 * 1000 * DELAY_IN_MS));

   previousIRQL = KeGetCurrentIrql();
   if (previousIRQL != PASSIVE_LEVEL)
   { 
      /// THIS FUNCTION IS NOT LEGAL IN PRODUCTION CODE BUT WILL WORK WELL ENOUGH FOR THIS LAB
      KeLowerIrql(PASSIVE_LEVEL);
      status = KeDelayExecutionThread( KernelMode, FALSE, &delay);  // wait 200 ms
      KeRaiseIrql( previousIRQL,  &notNeeded);  
      ///THIS FUNCTION IS NOT LEGAL IN PRODUCTION CODE BUT WILL WORK WELL ENOUGH FOR THIS LAB         
   }
   else
   {
      status = KeDelayExecutionThread( KernelMode, FALSE, &delay);  // wait 200 ms
   }
 //  +++++++++++THIS FUNCTION IS NOT LEGAL IN PRODUCTION CODE BUT WILL WORK WELL ENOUGH FOR THIS LAB++++++++
  
   return status;
}

/****************************************************************************
    Function:
              LabSetupISR
    Arguments:

    Description:

    Returns:


*****************************************************************************/


#if 0
static NTSTATUS LabSetupISR(
        PDEVICE_OBJECT deviceObject,
        ULONG interruptLine )
        {
        PLAB2_DEVICE_EXTENSION deviceExtension;
        NTSTATUS                        ioConnectStatus;
        KIRQL                           Irql;
        ULONG                           MappedSysVect;

        deviceExtension = deviceObject->DeviceExtension;

        KdPrint(("%s  LabSetupISR - Started\n",        DBG_MSG_HDR));
        //
        // register DPC routine
        //
        IoInitializeDpcRequest(deviceObject, LabDpcRoutine);

        KdPrint(("%s  LabSetupISR - Initialize DPC Request\n", DBG_MSG_HDR));

        //-------------------------------------
        //Get a mapped vector for our interrupt
        //--------------------------------------


        deviceExtension->Vector  = interruptLine;
        deviceExtension->Level   = interruptLine;


        MappedSysVect = HalGetInterruptVector(Isa,
                                              0,                            // BusNumber,
                                              deviceExtension->Level,       // Level
                                              deviceExtension->Vector,      // Vector,
                                              &Irql,                        // IRQL
                                              &deviceExtension->Affinity);  // Affinity mask


        //
        // Initialize the spinlock
        //
        KeInitializeSpinLock( &deviceExtension->ISRSpinLock);


        DbgPrint("%s  LabSetupISR - Vector        = 0x%08x\n",   DBG_MSG_HDR, deviceExtension->Vector);
        DbgPrint("%s  LabSetupISR - Level         = 0x%08x\n\n", DBG_MSG_HDR, deviceExtension->Level);

        DbgPrint("%s  LabSetupISR - MappedSysVect = 0x%08x\n", DBG_MSG_HDR, MappedSysVect);
        DbgPrint("%s  LabSetupISR - IRQL          = 0x%08x\n", DBG_MSG_HDR, Irql);
        DbgPrint("%s  LabSetupISR - Affinity      = 0x%08x\n", DBG_MSG_HDR, deviceExtension->Affinity);



        //
        // connect the device driver to the IRQ
        //
//        ioConnectStatus = IoConnectInterrupt(
//                                             &deviceExtension->InterruptObject,
//                                             LabInterruptServiceRoutine,
//                                             deviceExtension,
//                                             &deviceExtension->ISRSpinLock,
//                                             MappedSysVect,
//                                             Irql,
//                                             Irql,
//                                             Latched,          //LevelSensitive,                              //  Interrupt is not LevelSensitive
//                                             FALSE,                                // Interrupt vector is sharable
//                                             deviceExtension->Affinity,
//                                             FALSE                                 // Save Floating Point stack on interrupt
//                                            );

//        if ( !NT_SUCCESS (ioConnectStatus) )
//                {
//                   KdPrint(("%s  LabSetupISR - IoConnectInterrupt Failed (0x%08x)\n",     DBG_MSG_HDR, ioConnectStatus));
//                }
//        else
//                {
//                   KdPrint(("%s  LabSetupISR - IoConnectInterrupt Passed\n",      DBG_MSG_HDR));
//                }
//        return ioConnectStatus;

          return STATUS_SUCCESS;
        }

#endif

/****************************************************************************
    Function:
              LabInterruptServiceRoutine
    Arguments:

    Description:

    Returns:


*****************************************************************************/
#if 0
BOOLEAN LabInterruptServiceRoutine(
    IN PKINTERRUPT Interrupt,
    IN OUT PVOID Context
    )

  {
    PLAB2_DEVICE_EXTENSION  deviceExtension = Context;
    PDEVICE_OBJECT    deviceObject = deviceExtension->DeviceObject;

//    DbgBreakPoint();

     /*
    * Look at our Interrupt Status Register...
    */
    DbgPrint("%s  InterruptServiceRoutine - Got one!\n",    DBG_MSG_HDR);


    /*
    * Make sure that we keep track of all Interrupts for future reference...
    */

    /*
    * Clear the Interrupt ASAP, or get out if it isn't us...
    */
    /*
    * restore the ISR mask Register to its original value
    */


    //
    // Note: the CurrentIrp field of the device object gets filled in
    // by IoStartPacket or IoStartNextPacket (which eventually leads
    // calling the drivers StartIo routine, which should lead to the
    // interrupt).
    //
    // If this interrupt was not the result of driver initiated I/O
    // then this field would not be accurate.
    //
    IoRequestDpc(deviceObject,
                 deviceObject->CurrentIrp,
                 NULL
                 );

    return TRUE;
}
#endif

/****************************************************************************
    Function:
              LabDPCRoutine
    Arguments:

    Description:

    Returns:


*****************************************************************************/
//
// This is the deferred procedure call that gets queued by the ISR to
// finish any interrupt relate processing
//
#if 0
VOID LabDpcRoutine(
    IN PKDPC Dpc,
    PDEVICE_OBJECT  deviceObject,
    IN PVOID SystemArgument1,
    IN PVOID SystemArgument2
    )
{

    PLAB2_DEVICE_EXTENSION        deviceExtension;
    PIRP                             Irp;

    Irp = deviceObject->CurrentIrp;

    deviceExtension = deviceObject->DeviceExtension;
    deviceExtension->InterruptCount++;

    if (Irp) {
        //
        // need to fill in this field to get the I/O manager to copy the data
        // back to user address space
        //
        Irp->IoStatus.Information = sizeof(LAB2_DATA_OUTPUT);

       // ?? size of data for pending IO completion

        Irp->IoStatus.Status = STATUS_SUCCESS;

        IoCompleteRequest(Irp, IO_NO_INCREMENT);
    }

    return;
}
#endif

/****************************************************************************
    Function:
              Macros for Simulator register access
    Arguments:

    Description:

    Returns:


*****************************************************************************/
#define IN_COMMAND      (0)
#define IN_STATUS       (1)
#define IN_DATA         (2)

#define OUT_COMMAND     (3)
#define OUT_STATUS      (4)
#define OUT_DATA        (5)


//
// Macros to test Status and command bits -- YOU MAY WANT MACROS TO SET COMMAND BITS AS WELL
//

#define IN_ERROR_STATE (READ_REGISTER_UCHAR(&extension->registerAddress[IN_STATUS]) & HELLO_STATUS_IN_MASK_ERR)
#define IN_OVERFLOW_STATE (IN_ERROR_STATE && (READ_REGISTER_UCHAR(&extension->registerAddress[IN_STATUS]) & HELLO_STATUS_IN_MASK_OVR))
#define IN_END_OF_PACKET_STATE (READ_REGISTER_UCHAR(&extension->registerAddress[IN_STATUS]) & HELLO_STATUS_IN_MASK_EOP)
#define IN_INTERRUPT_STATE (READ_REGISTER_UCHAR(&extension->registerAddress[IN_STATUS]) & HELLO_STATUS_IN_MASK_INT)
#define IN_DONE_STATE (READ_REGISTER_UCHAR(&extension->registerAddress[IN_STATUS]) & HELLO_STATUS_IN_MASK_DONE)

#define IN_GO_SET (READ_REGISTER_UCHAR(&extension->registerAddress[IN_COMMAND]) & HELLO_COMMAND_IN_MASK_GO)


#define OUT_ERROR_STATE (READ_REGISTER_UCHAR(&extension->registerAddress[OUT_STATUS]) & HELLO_STATUS_OUT_MASK_ERR)
#define OUT_UNDERFLOW_STATE (OUT_ERROR_STATE && (READ_REGISTER_UCHAR(&extension->registerAddress[OUT_STATUS]) & HELLO_STATUS_OUT_MASK_UND))
        
#define OUT_BUSY_STATE (READ_REGISTER_UCHAR(&extension->registerAddress[OUT_STATUS]) & HELLO_STATUS_OUT_MASK_BUSY)
#define OUT_INTERRUPT_STATE (READ_REGISTER_UCHAR(&extension->registerAddress[OUT_STATUS]) & HELLO_STATUS_OUT_MASK_INT)
#define OUT_DONE_STATE (READ_REGISTER_UCHAR(&extension->registerAddress[OUT_STATUS]) & HELLO_STATUS_OUT_MASK_DONE)

#define OUT_GO_SET (READ_REGISTER_UCHAR(&extension->registerAddress[OUT_COMMAND]) & HELLO_COMMAND_OUT_MASK_GO)

/****************************************************************************
    Function:
              Lab2GetPacket
    Arguments:

    Description:

    Returns:


*****************************************************************************/
NTSTATUS Lab2GetPacket(  
                        PDEVICE_OBJECT deviceObject,
                        UCHAR   *pBuffer,
                        ULONG   outBufferLength,
                        ULONG   *charCount)                         // RETURN transfer SIZE
{
    PLAB2_DEVICE_EXTENSION     extension = deviceObject->DeviceExtension;
      return STATUS_UNSUCCESSFUL ;   
}                   


/****************************************************************************
    Function:
              Lab2PutPacket
    Arguments:

    Description:

    Returns:


*****************************************************************************/
NTSTATUS Lab2PutPacket(  
                        PDEVICE_OBJECT deviceObject,
                        UCHAR   *pBuffer,
                        ULONG   inBufferLength,
                        ULONG   *charCount)                         // RETURN transfer SIZE
{
    PLAB2_DEVICE_EXTENSION     extension = deviceObject->DeviceExtension;

      *charCount =  count;
      return STATUS_UNSUCCESSFUL ;   
}                   

  







