//HSTestReadReg
#define REG_DBG                  (L"DebugMask")
#define REG_EVENT                (L"LogEvents")
#define REG_BREAK                (L"BreakOnEntry")
#define REG_INTLINE              (L"InterruptLine")
#define REG_DEFAULT_INTLINE      (L"DefaultInterruptLine")
#define REG_INTIDT               (L"InterruptIDT")
#define REG_BUF_LOG_ADDRESS      (L"BufferLogicalAddress")
#define REG_BUF_PHYS_ADDRESS_LO  (L"BufferPhysicalAddressLow")
#define REG_BUF_PHYS_ADDRESS_HI  (L"BufferPhysicalAddressHigh")

#define REG_PATHNAME             (L"PathName")
    
#define PARMS_SUBKEY             (L"\\Parameters")
#define EPHEMERAL_SUBKEY         (L"\\Ephemeral")
#define DEVICES_SUBKEY           (L"Devices")
#define DRIVER_PARMS             (L"DriverParameters")
                                       



        
NTSTATUS hardwareSimReadRegistry(
    IN PDRIVER_OBJECT DriverObject,   // Driver object
    IN PUNICODE_STRING RegistryPath,     // base path to keys
    OUT PULONG interruptLine,
    OUT PULONG interruptIDT,
    OUT VOID *registerAddress,
    OUT PHYSICAL_ADDRESS *registerPhysicalAddress
        );



  NTSTATUS initHardwareSimDevicePath(
       IN PDRIVER_OBJECT DriverObject,
       IN PUNICODE_STRING  inPath,    // zero terminated UNICODE_STRING with parameters path
       UNICODE_STRING * ephemeralRegistryPath,
       UNICODE_STRING * registryPathName
       );
