/*****************************************************************************
*           Change Log
*  Date     | Change
*-----------+-----------------------------------------------------------------
*****************************************************************************/
// NT device name
#define NT_DEVICE_NAME      L"\\Device\\HdwSim"

// File system device name.   
#define DOS_DEVICE_NAME     L"\\DosDevices\\HdwSim"
                                            

typedef struct _HDW_SIM_DEVICE_EXTENSION {
    PDEVICE_OBJECT      DeviceObject;
    ULONG               InterruptCount;
    
    ULONG               Level;             // Level
    ULONG               Vector;            // Vector
    KAFFINITY           Affinity;          // Affinity

    PCM_RESOURCE_LIST  *pResources;

    PVOID               DMARegisterSystemVirtualAddr;   // system address of 

    KSPIN_LOCK          ISRSpinLock;
    PKINTERRUPT         InterruptObject;   // Pointer to the Interrupt Object
    ULONG               mappedSysVect;
                                                

    UNICODE_STRING      ephemeralRegistryPath;
    UNICODE_STRING      parameterRegistryPath;
    UNICODE_STRING      registryPathName;

    ULONG	        debugMask; // retained debug mask
     
    //
    // Virtual Registers
    //
    UCHAR               simulatedRegister[6];    
    PUCHAR              pSimulatedRegisterLogicalAddress;    
    PHYSICAL_ADDRESS    pSimulatedRegisterPhysicalAddress;        
    //
    //  Register spinlock
    //
    BOOLEAN             spin;
    KSPIN_LOCK          registerLock;
    ULONG               interrupt_Line;
    ULONG               interrupt_IDT;

    KIRQL               irql;


} HDW_SIM_DEVICE_EXTENSION;
typedef HDW_SIM_DEVICE_EXTENSION *PHDW_SIM_DEVICE_EXTENSION;

