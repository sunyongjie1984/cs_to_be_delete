//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WaitDialog.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_WAITDITYPE                  129
#define IDB_CALC_ANIM2                  142
#define IDD_BUSY_DLG                    144
#define IDC_BUSY_PIC                    1027
#define IDC_BUSY_TEXT                   1028
#define ID_VIEW_WAIT_DLG                32771
#define ID_VIEW_ABORT_DLG               32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
