#include<stdio.h>
#include<bios.h>
#include<stdlib.h>
#include<alloc.h>
void copyright();
void main(int argc,char **argv)
{
 char work=0;
 char *buff,*dot,*xname;
 FILE *hd;
 if(argc!=3)goto error;
 work=argv[1][0]|0x20;
 if((work!='s')&&(work!='r'))
 {
  error:
     copyright();
     printf("\a\n Usage:  hddbg [options] Filename.[dbg]\n\n");
     printf("         Options include:\n");
     printf("               s: save HD Dos Boot Sector to Filename.[dbg]\n");
     printf("               r: restore HD Dos Boot Sector from Filename.[dbg]\n");
     exit(0);
 }
 strlwr(argv[2]);
 xname=strstr(argv[2],".dbg");
 dot=strchr(argv[2],'.');
 if(work=='s')
 {
  if(dot&&(!xname))
  {
   copyright();
   printf("\a\n The Dos Boot Sector must be save to a DBG file!\n");
   exit(1);
  }
  if(!dot){strcat(argv[2],".dbg");}
  if((hd=fopen(argv[2],"wb"))==NULL)
  {
   copyright();
   printf("\n\a Open file <%s> error!\n",argv[2]);
   exit(1);
  }
  buff=(unsigned char *)malloc(512);
  if((biosdisk(0x02,0x80,1,0,1,1,buff))!=0)
  {
   copyright();
   printf("\n\a Save HD Dos Boot Sector to file <%s> error!",argv[2]);
   exit(1);
  }
  fwrite(buff,512,1,hd);
  fclose(hd);
  free(buff);
  copyright();
  printf("\n Saved HD Dos Boot Sector to file <%s> ok.\n",argv[2]);
 }
 else
 {
      if(dot&&(!xname)||(!dot))
      {
       copyright();
       printf("\a\n To restore HD Dos Boot Sector must need a DBG file!\n");
       exit(1);
      }
      if((hd=fopen(argv[2],"rb"))==NULL)
      {
       copyright();
       printf("\n\a Open file <%s> error!",argv[2]);
       exit(1);
      }
      buff=(unsigned char *)malloc(512);
      fread(buff,512,1,hd);
      if((biosdisk(0x03,0x80,1,0,1,1,buff))!=0)
      {
       copyright();
       printf("\n\a Restore HD Dos Boot Sector from <%s> error!\n",argv[2]);
       exit(1);
      }
      fclose(hd);
      free(buff);
      copyright();
      printf("\n Restored HD Dos Boot Sector from file <%s> ok.\n",argv[2]);
 }
 exit(0);
}
void copyright()
{
 printf("\n Yaking (R) HD Dos Boot Sector Guard version 1.0.");
 printf("\n Copyright (C) 1997.9, Yaking Software Studio.\n");
}


