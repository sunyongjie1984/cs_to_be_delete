#include<stdio.h>
#include<bios.h>
#include<stdlib.h>
#include<alloc.h>
void copyright();
void main(int argc,char **argv)
{
 char work=0;
 char *bufm,*bufd,*dot,*xname;
 FILE *hd;
 if(argc!=3)goto error;
 work=argv[1][0]|0x20;
 if((work!='s')&&(work!='r'))
 {
  error:
     copyright();
     printf("\a\n Usage:  hdbbg [options] Filename.[bbg]\n\n");
     printf("         Options include:\n");
     printf("               s: save HD Master&Dos Boot Sector to Filename.[bbg]\n");
     printf("               r: restore HD Master&Dos Boot Sector from Filename.[bbg]\n");
     exit(0);
 }
 strlwr(argv[2]);
 xname=strstr(argv[2],".bbg");
 dot=strchr(argv[2],'.');
 if(work=='s')
 {
  if(dot&&(!xname))
  {
   copyright();
   printf("\a\n The Master&Dos Boot Sector must be save to a BBG file!\n");
   exit(1);
  }
  if(!dot){strcat(argv[2],".bbg");}
  if((hd=fopen(argv[2],"wb"))==NULL)
  {
   copyright();
   printf("\n\a Open file <%s> error!\n",argv[2]);
   exit(1);
  }
  bufm=(unsigned char *)malloc(512);
  bufd=(unsigned char *)malloc(512);
  if((biosdisk(0x02,0x80,0,0,1,1,bufm))||(biosdisk(0x02,0x80,1,0,1,1,bufd)))
  {
   copyright();
   printf("\n\a Save HD Master&Dos Boot Sector to file <%s> error!",argv[2]);
   exit(1);
  }
  fwrite(bufm,512,1,hd);
  fwrite(bufd,512,1,hd);
  fclose(hd);
  free(bufm);
  free(bufd);
  copyright();
  printf("\n Saved HD Master&Dos Boot Sector to file <%s> ok.\n",argv[2]);
 }
 else
 {
      if(dot&&(!xname)||(!dot))
      {
       copyright();
       printf("\a\n To restore HD Master&Dos Boot Sector must need a BBG file!\n");
       exit(1);
      }
      if((hd=fopen(argv[2],"rb"))==NULL)
      {
       copyright();
       printf("\n\a Open file <%s> error!",argv[2]);
       exit(1);
      }
      bufd=(unsigned char *)malloc(512);
      bufm=(unsigned char *)malloc(512);
      fread(bufm,512,1,hd);
      fread(bufd,512,1,hd);
      if((biosdisk(0x03,0x80,0,0,1,1,bufm))||(biosdisk(0x03,0x80,1,0,1,1,bufd)))
      {
       copyright();
       printf("\n\a Restore HD Master&Dos Boot Sector from <%s> error!\n",argv[2]);
       exit(1);
      }
      fclose(hd);
      free(bufm);
      free(bufd);
      copyright();
      printf("\n Restored HD Master&Dos Boot Sector from file <%s> ok.\n",argv[2]);
 }
 exit(0);
}
void copyright()
{
 printf("\n Yaking (R) HD Master&Dos Boot Sector Guard version 1.0.");
 printf("\n Copyright (C) 1997.9, Yaking Software Studio.\n");
}


