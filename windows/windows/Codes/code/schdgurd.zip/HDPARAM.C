#include<dos.h>
union REGS in,out;
int main()
{
 int i;
 in.h.ah=0x08;
 in.h.dl=0x80;
 int86(0x13,&in,&out);
 for(i=0;i<out.h.dl;++i)
 {
  in.h.dl=0x80+i;
  int86(0x13,&in,&out);
  printf("\a Parameter for Drive %c:\n",'C'+i);
  printf("\n Heads=%d\n",++out.h.dh);
  out.h.bh=(out.h.cl&0xc0)>>6;
  out.h.bl=out.h.ch;
  printf(" Cylinder=%d\n",out.x.bx);
  printf(" Sectors=%d\n",out.h.cl&0x3f);
 }
 printf("\n   (C) Copyright 1997.10 LiuYaDing,Babysoft Corp.\n");
 return 0;
}