// DlgProcedureStatus.h : header file
//

#ifndef __EVENTDIALOG__
#define __EVENTDIALOG__

#define	MSG_DESTROY	WM_USER+1

/////////////////////////////////////////////////////////////////////////////
// CDlgProcedureStatus dialog

class CEventDlg : public CDialog 
{
public:
	HANDLE m_hCancelEvent;
	struct ProcParam
	{
		HANDLE	m_hCancelEvent;
		HWND	m_hWndDlgProcedureStatus;
		HWND	m_hWndStStatus;
		HWND	m_hWndProgressCtrl;
		HWND	m_hWndStImage;

		LPVOID	m_pvProcParamData;
	};

public:
	CEventDlg(AFX_THREADPROC pfnThreadProc, LPVOID pvProcParamData, CWnd* pParent = NULL);
	~CEventDlg();

	// Dialog Data
	//{{AFX_DATA(CEventDlg)
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEventDlg)
	protected:
	afx_msg LONG Destroy(UINT, LONG);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEventDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnProcCancel();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

private:
	AFX_THREADPROC	m_pfnThreadProc;
	LPVOID			m_pvProcParamData;
	CWinThread*		m_pWinThread;
	ProcParam		m_ProcParam;
};

#endif	
