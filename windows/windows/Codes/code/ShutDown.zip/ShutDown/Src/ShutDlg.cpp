// ShutDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ShutDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShutdownDlg dialog


CShutdownParamDlg::CShutdownParamDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CShutdownParamDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShutdownParamDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CShutdownParamDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShutdownParamDlg)
	DDX_Control(pDX, IDSPIN_TIMEOUT, m_spinTimeout);
	DDX_Control(pDX, IDK_REBOOT, m_ckReboot);
	DDX_Control(pDX, IDK_FORCEAPPSCLOSE, m_ckAppClose);
	DDX_Control(pDX, IDE_TIMEOUT, m_meTimeout);
	DDX_Control(pDX, IDE_MSG, m_meMessage);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CShutdownParamDlg, CDialog)
	//{{AFX_MSG_MAP(CShutdownParamDlg)
	ON_BN_CLICKED(IDOK, OnOK)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShutdownParamDlg message handlers

void CShutdownParamDlg::OnOK() 
{
	CString str;

	m_meMessage.GetWindowText(m_strMessage);

	m_meTimeout.GetWindowText(str);
	m_nTimeout = atoi(str);

	m_fReboot = m_ckReboot.GetCheck();
	m_fForce  = m_ckAppClose.GetCheck();

	CDialog::OnOK();
}
