// DlgProcedureStatus.cpp : implementation file
//

#include "stdafx.h"
#include "Resource.h"
#include "EventDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgProcedureStatus dialog

CEventDlg::CEventDlg(AFX_THREADPROC pfnThreadProc, LPVOID pvProcParamData, CWnd* pParent)
	: CDialog(IDD_EVENT, pParent)
{
	//{{AFX_DATA_INIT(CEventDlg)
	//}}AFX_DATA_INIT

	m_pfnThreadProc = pfnThreadProc;
	m_pvProcParamData = pvProcParamData;
}

CEventDlg::~CEventDlg()
{
	CloseHandle(m_hCancelEvent);
}

void 
CEventDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEventDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CEventDlg, CDialog)
	ON_MESSAGE(MSG_DESTROY, Destroy)
	//{{AFX_MSG_MAP(CEventDlg)
	ON_BN_CLICKED(IDC_PROC_CANCEL, OnProcCancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEventDlg message handlers
BOOL 
CEventDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_hCancelEvent = CreateEvent(NULL, FALSE, FALSE, _T("CancelButtonPressed"));
	ASSERT(m_hCancelEvent != NULL);

	//	Create the parametter structure for the thread
	m_ProcParam.m_hCancelEvent			 = m_hCancelEvent;
	m_ProcParam.m_hWndDlgProcedureStatus = GetSafeHwnd();

	m_ProcParam.m_pvProcParamData	= m_pvProcParamData;

	m_ProcParam.m_hWndStStatus		= GetDlgItem(IDS_STATUS)->GetSafeHwnd();
	m_ProcParam.m_hWndProgressCtrl	= GetDlgItem(IDC_PROGRESS)->GetSafeHwnd();
	m_ProcParam.m_hWndStImage		= GetDlgItem(IDS_IMAGE)->GetSafeHwnd();

	//	Launch the thread
	m_pWinThread = AfxBeginThread(m_pfnThreadProc, &m_ProcParam);

	return TRUE;
}

void 
CEventDlg::OnProcCancel() 
{
	SetEvent(m_hCancelEvent);
}

LONG 
CEventDlg::Destroy(UINT nCode, LONG)
{
	EndDialog(nCode);
	return 0;
}
