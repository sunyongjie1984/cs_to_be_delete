//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Shutdown.rc
//
#define IDSHUTDOWN                      3
#define IDD_SHUTDOWN_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_SHUTDOWN                    178
#define IDB_SHUTDOWN_0                  179
#define IDB_SHUTDOWN_1                  180
#define IDB_WKSTA                       190
#define IDD_EVENT                       240
#define IDT_WKSTA                       1000
#define IDE_TIMEOUT                     1025
#define IDE_MSG                         1048
#define IDSPIN_TIMEOUT                  1050
#define IDK_FORCEAPPSCLOSE              1051
#define IDS_IMAGE                       1052
#define IDK_REBOOT                      1052
#define IDC_PROGRESS                    1065
#define IDC_PROC_CANCEL                 1069
#define IDS_STATUS                      1121

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
