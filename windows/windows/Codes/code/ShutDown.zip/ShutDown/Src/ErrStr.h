#ifndef __ErrStr_Defined__
#define __ErrStr_Defined__

extern CString g_strAppName;

//	error functions, constants & macros
#define _MsgFatal(hWnd, lpText) ::MessageBox(hWnd, lpText, g_strAppName, MB_OK | MB_ICONSTOP)
#define _MsgError(hWnd, lpText) ::MessageBox(hWnd, lpText, g_strAppName, MB_OK | MB_ICONEXCLAMATION)
#define _MsgYesNo(hWnd, lpText) ::MessageBox(hWnd, lpText, g_strAppName, MB_YESNO | MB_ICONQUESTION)
#define _MsgInfo(hWnd, lpText) ::MessageBox(hWnd, lpText, g_strAppName, MB_YESNO | MB_ICONINFORMATION)

#define SoundAlert()			::MessageBeep(0)

CString Win32ErrString(const DWORD err);
CString ShowLastError(BOOL bShow = TRUE);
CString ShowLastError(DWORD dwErrCode, BOOL bShow = TRUE);

#endif
