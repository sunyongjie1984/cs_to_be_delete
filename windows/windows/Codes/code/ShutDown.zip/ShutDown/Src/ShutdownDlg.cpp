// ShutdownDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ShutdownDlg.h"

#include "ShutDlg.h"
#include "EventDlg.h"
#include "ErrStr.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//	Wait for shutdown
struct CShutdownParam
{
	UINT	m_nTimeout;
	CString	m_strMachineName;
};

UINT 
WaitForShutdown(LPVOID pParam)
{
	CShutdownParam* 
		pShutdownParam = 
			static_cast<CShutdownParam*>
				(static_cast<CEventDlg::ProcParam*>(pParam)->m_pvProcParamData);

	CEventDlg* 
		m_pDlg = 
			static_cast<CEventDlg*>
				(CWnd::FromHandle(
					static_cast<CEventDlg::ProcParam*>(pParam)->m_hWndDlgProcedureStatus));

	CStatic* 
		pStStatus = 
			static_cast<CStatic*>(CWnd::FromHandle(
				static_cast<CEventDlg::ProcParam*>(pParam)->m_hWndStStatus));

	CStatic* 
		pStImage = 
			static_cast<CStatic*>(CWnd::FromHandle(
				static_cast<CEventDlg::ProcParam*>(pParam)->m_hWndStImage));

	CProgressCtrl* 
		pProgress = 
			static_cast<CProgressCtrl*>(CWnd::FromHandle(
				static_cast<CEventDlg::ProcParam*>(pParam)->m_hWndProgressCtrl));
	
	CString strText;
	strText.Format(_T("Shutting down %s in %d seconds..."), 
		pShutdownParam->m_strMachineName, 
		pShutdownParam->m_nTimeout);
	pStStatus->SetWindowText(strText);

	pProgress->SetRange(0,(short)(pShutdownParam->m_nTimeout));
	pProgress->SetPos(0);

	BOOL bFlipImage = TRUE;
	UINT i = 0;
	DWORD dw;
	
	DWORD dwTickStart = GetTickCount(), dwTickEnd;
	HBITMAP 
		hBmp0 = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_SHUTDOWN_0)), 
		hBmp1 = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_SHUTDOWN_1));

	while((dw = WaitForSingleObject(static_cast<CEventDlg::ProcParam*>(pParam)->m_hCancelEvent, 0))
			!= WAIT_OBJECT_0)
	{
		dwTickEnd = GetTickCount();
		if(dwTickEnd - dwTickStart >= 1000)
		{
			i++;
			pProgress->SetPos(i);

			strText.Format(_T("Shutting down %s in %d seconds..."), 
				pShutdownParam->m_strMachineName, 
				pShutdownParam->m_nTimeout - i);
			pStStatus->SetWindowText(strText);

			dwTickStart = dwTickEnd;

			bFlipImage = !bFlipImage;

			if(bFlipImage)
				pStImage->SetBitmap(hBmp0);
			else
				pStImage->SetBitmap(hBmp1);
		}
	}

	if(dw == WAIT_TIMEOUT)
		m_pDlg->PostMessage(MSG_DESTROY, 0);
	else
		m_pDlg->PostMessage(MSG_DESTROY, 1);
	
	return 0;

}

/////////////////////////////////////////////////////////////////////////////
// CShutdownDlg dialog

CShutdownDlg::CShutdownDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CShutdownDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShutdownDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CShutdownDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShutdownDlg)
	DDX_Control(pDX, IDT_WKSTA, m_treeWksta);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CShutdownDlg, CDialog)
	//{{AFX_MSG_MAP(CShutdownDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDSHUTDOWN, OnShutdown)
	ON_NOTIFY(TVN_SELCHANGED, IDT_WKSTA, OnSelChangedWksta)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShutdownDlg message handlers

BOOL CShutdownDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	Init();
	return TRUE;
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CShutdownDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CShutdownDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void 
CShutdownDlg::Init()
{
	InitTree();
	InitMachines();
}

void 
CShutdownDlg::InitTree()
{
	CImageList imgList;
	imgList.Create(IDB_WKSTA, 16, 0, COLORREF(RGB(255, 255, 255)));
	m_treeWksta.SetImageList(&imgList, TVSIL_NORMAL);
	imgList.Detach();
}

void 
CShutdownDlg::InitMachines()
{
	m_treeWksta.DeleteAllItems();

	LPENUMIDLIST lpe = NULL;
	LPITEMIDLIST lpi = NULL;
	LPMALLOC lpMalloc = NULL;
	ULONG ulFetched = 0L;
	HRESULT hr = 0;

	HTREEITEM hRoot = NULL;

	CString strItemName;

	LPSHELLFOLDER lpsf; 
	hr = SHGetDesktopFolder(&lpsf);
	if (FAILED (hr))
		return;

	LPITEMIDLIST lpi1;
	hr = SHGetSpecialFolderLocation(m_hWnd, CSIDL_NETWORK, &lpi1);
	if (FAILED (hr))
		return;

	LPSHELLFOLDER lpsfNetworkNeighborhood;
	hr = lpsf->BindToObject(lpi1, NULL, IID_IShellFolder, (LPVOID*)&lpsfNetworkNeighborhood);
	if (FAILED (hr))
		return;

	hr = ::SHGetMalloc (&lpMalloc);
	if (FAILED (hr))
		return;

	if (SUCCEEDED (hr))
	{
		hr = lpsfNetworkNeighborhood->EnumObjects(m_hWnd, SHCONTF_FOLDERS | SHCONTF_NONFOLDERS, &lpe);

		if (SUCCEEDED (hr))
		{
			while (S_OK == lpe->Next(1, &lpi, &ulFetched))
			{
				ULONG ulAttrs = SFGAO_HASSUBFOLDER;

				hr = lpsfNetworkNeighborhood->GetAttributesOf(1, (const struct _ITEMIDLIST **)&lpi, &ulAttrs);

				STRRET strretName;
				if (ulAttrs & SFGAO_HASSUBFOLDER)
				{
					strretName.uType = STRRET_CSTR;
					hr = lpsfNetworkNeighborhood->GetDisplayNameOf(lpi, SHGDN_NORMAL, &strretName);

					switch(strretName.uType)
					{
						case STRRET_CSTR:
							strItemName = strretName.cStr;
							break;
						case STRRET_WSTR:
							strItemName = strretName.pOleStr;
							break;
						default:
							break;
					}

					if(strItemName.CompareNoCase(_T("Entire Network")) == 0)
						hRoot = m_treeWksta.InsertItem(strItemName, 0, 0, NULL);
					else
						m_treeWksta.InsertItem(strItemName, 1, 1, hRoot);
				}

				lpMalloc->Free(lpi); 
				lpi = 0;
			}
		}
	}
	else
		return;

	if (lpe)
		lpe->Release ();

	if (lpi && lpMalloc)
		lpMalloc->Free(lpi);

	if (lpMalloc)
		lpMalloc->Release();
}

void 
CShutdownDlg::OnShutdown() 
{
	HTREEITEM 
		hSel  = m_treeWksta.GetSelectedItem(),
		hRoot = m_treeWksta.GetRootItem();

	ASSERT(hRoot);
	if(hRoot == hSel)
		return;

	CShutdownParamDlg dlgShutdown(this);
	if(dlgShutdown.DoModal() == IDCANCEL)
		return;

	BOOL bShutdown = 
		InitiateSystemShutdown
			(
				(LPSTR)(LPCTSTR)m_strWkstaName, 
				(LPSTR)(LPCTSTR)dlgShutdown.m_strMessage, 
				dlgShutdown.m_nTimeout, 
				dlgShutdown.m_fForce, 
				dlgShutdown.m_fReboot
			);
	if(!bShutdown)
		ShowLastError();
	else
	{
		CShutdownParam shdwn;
		shdwn.m_nTimeout		= dlgShutdown.m_nTimeout;
		shdwn.m_strMachineName	= m_strWkstaName;

		CEventDlg dlg(WaitForShutdown, (LPVOID)&shdwn);

		if (dlg.DoModal() != 0)
			AbortSystemShutdown((LPSTR)(LPCTSTR)m_strWkstaName);
	}
}

void CShutdownDlg::OnSelChangedWksta(NMHDR* pNMHDR, LRESULT* pResult) 
{
	HTREEITEM hSelItem	= m_treeWksta.GetSelectedItem();
	HTREEITEM hRoot		= m_treeWksta.GetRootItem();

	if((hSelItem != (HTREEITEM)NULL) && (hSelItem != hRoot))
	{
		m_strWkstaName = m_treeWksta.GetItemText(hSelItem);
		GetDlgItem(IDSHUTDOWN)->EnableWindow(TRUE);
	}
	else
		GetDlgItem(IDSHUTDOWN)->EnableWindow(FALSE);
}
