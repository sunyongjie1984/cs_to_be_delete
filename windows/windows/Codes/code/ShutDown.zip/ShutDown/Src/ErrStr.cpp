#include "StdAfx.h"
#include "ErrStr.h"

#include "Resource.h"

extern DWORD		g_dwLastError;

CString 
Win32ErrString(const DWORD err)
{
	static char buffer[256];
	char *end = buffer + 
		FormatMessage(FORMAT_MESSAGE_IGNORE_INSERTS | FORMAT_MESSAGE_FROM_SYSTEM, 0, 
		err,MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),buffer, sizeof(buffer)-1, 0);

	if(end == buffer) 
		return _T("???");
    
	for(end--; end >= buffer && (*end == '\r' || *end == '\n') ;end--) 
		;

    end[1] = 0;

    CString str = (CString)buffer;

	return str;
}

CString 
ShowLastError(BOOL bShow)
{
	g_dwLastError = GetLastError();
	if(g_dwLastError != 0)
	{
		CString strErrorMessage = Win32ErrString(g_dwLastError);
		if(bShow)
		{
			::MessageBeep(MB_ICONEXCLAMATION);
			_MsgError(NULL, (LPCTSTR)strErrorMessage);
		}

		return strErrorMessage;
	}
	return _T("No error.");
}

CString 
ShowLastError(DWORD dwErrCode, BOOL bShow)
{
	g_dwLastError = dwErrCode;
	if(g_dwLastError != 0)
	{
		CString strErrorMessage = Win32ErrString(g_dwLastError);
		if(bShow)
		{
			::MessageBeep(MB_ICONEXCLAMATION);
			_MsgError(NULL, (LPCTSTR)strErrorMessage);
		}

		return strErrorMessage;
	}
	return _T("No error.");
}


