#if !defined(AFX_SHUTDOWNDLG_H__1F4D95F6_1F8B_11D3_A3CE_0080C8ECFED4__INCLUDED_)
#define AFX_SHUTDOWNDLG_H__1F4D95F6_1F8B_11D3_A3CE_0080C8ECFED4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CShutdownParamDlg.h : header file
//

#include "Resource.h"

/////////////////////////////////////////////////////////////////////////////
// CShutdownDlg dialog

class CShutdownParamDlg : public CDialog
{
public:
	CString	m_strMessage;
	UINT	m_nTimeout;
	BOOL	m_fReboot;
	BOOL	m_fForce;

public:
	CShutdownParamDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CShutdownParamDlg)
	enum { IDD = IDD_SHUTDOWN };
	CSpinButtonCtrl	m_spinTimeout;
	CButton			m_ckReboot;
	CButton			m_ckAppClose;
	CEdit			m_meTimeout;
	CEdit			m_meMessage;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShutdownParamDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CShutdownParamDlg)
	afx_msg void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHUTDOWNDLG_H__1F4D95F6_1F8B_11D3_A3CE_0080C8ECFED4__INCLUDED_)
