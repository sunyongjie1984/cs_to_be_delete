#include "stdafx.h"
#include "app.h"
#include "NewImageDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CNewImageDlg::CNewImageDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNewImageDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewImageDlg)
	m_nHeight = 0;
	m_nWidth = 0;
	//}}AFX_DATA_INIT
	m_nHeight = 200;
	m_nWidth = 320;
}


void CNewImageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewImageDlg)
	DDX_Control(pDX, IDC_SPINWIDTH, m_ctrlSpinWidth);
	DDX_Control(pDX, IDC_SPINHEIGHT, m_ctrlSpinHeight);
	DDX_Text(pDX, IDC_HEIGHT, m_nHeight);
	DDV_MinMaxInt(pDX, m_nHeight, 10, 3000);
	DDX_Text(pDX, IDC_WIDTH, m_nWidth);
	DDV_MinMaxInt(pDX, m_nWidth, 10, 3000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewImageDlg, CDialog)
	//{{AFX_MSG_MAP(CNewImageDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CNewImageDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_ctrlSpinWidth.SetRange(10, 3000);
	m_ctrlSpinHeight.SetRange(10, 3000);
	
	return TRUE;
}
