#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "mainfrm.h"

#define WM_DOREALIZE   (WM_USER + 0)

class CApp : public CWinApp
{
public:
	CApp();

  int m_nNewWidth;
  int m_nNewHeight;
  BOOL m_bNewFromPaste;

	//{{AFX_VIRTUAL(CApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CApp)
	afx_msg void OnAppAbout();
	afx_msg void OnEditEmpty();
	afx_msg void OnUpdateEditEmpty(CCmdUI* pCmdUI);
	afx_msg void OnEditPasteImage();
	afx_msg void OnUpdateEditPasteImage(CCmdUI* pCmdUI);
	afx_msg void OnFileNew();
	afx_msg void OnWindowCloseall();
	afx_msg void OnUpdateWindowCloseall(CCmdUI* pCmdUI);
	afx_msg void OnChannelCombine();
	afx_msg void OnUpdateChannelCombine(CCmdUI* pCmdUI);
	afx_msg void OnFileOpen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

  int NumberOfOpenDocuments() const;
};


class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


///////////////// Helper Functions //////////////////
CApp* GetApp();
CMainFrame* GetMainFrame();