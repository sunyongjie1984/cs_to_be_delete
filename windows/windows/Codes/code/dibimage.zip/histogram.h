#ifndef __HISTOGRAM_H__
#define __HISTOGRAM_H__

class CHistogramPalette : public CDialogBar
{
public:
	CHistogramPalette();
	virtual ~CHistogramPalette();

  BOOL Create(CWnd* pParentWnd, LPCTSTR lpszTemplateName, UINT nStyle, UINT nID );
  BOOL Create(CWnd* pParentWnd, UINT nIDTemplate, UINT nStyle, UINT nID );

	//{{AFX_VIRTUAL(CHistogramPalette)
	//}}AFX_VIRTUAL

  int m_RedChannel[256];
  int m_GreenChannel[256];
  int m_BlueChannel[256];


protected:
	//{{AFX_MSG(CHistogramPalette)
	afx_msg void OnPaint();
	afx_msg void OnRed();
	afx_msg void OnGreen();
	afx_msg void OnBlue();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

  BOOL m_bShowRed;
  BOOL m_bShowGreen;
  BOOL m_bShowBlue;

  void SetChecks();
};

#endif //__HISTOGRAM_H__
