#include "dibimage.h"

class CCombineDlg : public CDialog
{
public:
	CCombineDlg(CWnd* pParent = NULL);   // standard constructor

  CDibImage* GetRedImage() const { return m_pRedImage; };
  CDibImage* GetGreenImage() const { return m_pGreenImage; };
  CDibImage* GetBlueImage() const { return m_pBlueImage; };


	//{{AFX_DATA(CCombineDlg)
	enum { IDD = IDD_CHANNEL_COMBINE };
	CComboBox	m_ctrlRedChannel;
	CComboBox	m_ctrlGreenChannel;
	CComboBox	m_ctrlBlueChannel;
	//}}AFX_DATA


	//{{AFX_VIRTUAL(CCombineDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:

	//{{AFX_MSG(CCombineDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

  CDibImage* m_pRedImage;
  CDibImage* m_pGreenImage;
  CDibImage* m_pBlueImage;
};

