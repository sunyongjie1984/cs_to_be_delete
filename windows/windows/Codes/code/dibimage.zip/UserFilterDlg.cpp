#include "stdafx.h"
#include "app.h"
#include "UserFilterDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CUserFilterDlg::CUserFilterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUserFilterDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUserFilterDlg)
	//}}AFX_DATA_INIT
}


void CUserFilterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUserFilterDlg)
	//}}AFX_DATA_MAP

  DDX_Text(pDX, IDC_11, m_Filter.m_nValues[0][0]);
  DDX_Text(pDX, IDC_12, m_Filter.m_nValues[1][0]);
  DDX_Text(pDX, IDC_13, m_Filter.m_nValues[2][0]);
  DDX_Text(pDX, IDC_14, m_Filter.m_nValues[3][0]);
  DDX_Text(pDX, IDC_15, m_Filter.m_nValues[4][0]);
  DDX_Text(pDX, IDC_16, m_Filter.m_nValues[5][0]);
  DDX_Text(pDX, IDC_17, m_Filter.m_nValues[6][0]);

  DDX_Text(pDX, IDC_21, m_Filter.m_nValues[0][1]);
  DDX_Text(pDX, IDC_22, m_Filter.m_nValues[1][1]);
  DDX_Text(pDX, IDC_23, m_Filter.m_nValues[2][1]);
  DDX_Text(pDX, IDC_24, m_Filter.m_nValues[3][1]);
  DDX_Text(pDX, IDC_25, m_Filter.m_nValues[4][1]);
  DDX_Text(pDX, IDC_26, m_Filter.m_nValues[5][1]);
  DDX_Text(pDX, IDC_27, m_Filter.m_nValues[6][1]);

  DDX_Text(pDX, IDC_31, m_Filter.m_nValues[0][2]);
  DDX_Text(pDX, IDC_32, m_Filter.m_nValues[1][2]);
  DDX_Text(pDX, IDC_33, m_Filter.m_nValues[2][2]);
  DDX_Text(pDX, IDC_34, m_Filter.m_nValues[3][2]);
  DDX_Text(pDX, IDC_35, m_Filter.m_nValues[4][2]);
  DDX_Text(pDX, IDC_36, m_Filter.m_nValues[5][2]);
  DDX_Text(pDX, IDC_37, m_Filter.m_nValues[6][2]);

  DDX_Text(pDX, IDC_41, m_Filter.m_nValues[0][3]);
  DDX_Text(pDX, IDC_42, m_Filter.m_nValues[1][3]);
  DDX_Text(pDX, IDC_43, m_Filter.m_nValues[2][3]);
  DDX_Text(pDX, IDC_44, m_Filter.m_nValues[3][3]);
  DDX_Text(pDX, IDC_45, m_Filter.m_nValues[4][3]);
  DDX_Text(pDX, IDC_46, m_Filter.m_nValues[5][3]);
  DDX_Text(pDX, IDC_47, m_Filter.m_nValues[6][3]);
                                               
  DDX_Text(pDX, IDC_51, m_Filter.m_nValues[0][4]);
  DDX_Text(pDX, IDC_52, m_Filter.m_nValues[1][4]);
  DDX_Text(pDX, IDC_53, m_Filter.m_nValues[2][4]);
  DDX_Text(pDX, IDC_54, m_Filter.m_nValues[3][4]);
  DDX_Text(pDX, IDC_55, m_Filter.m_nValues[4][4]);
  DDX_Text(pDX, IDC_56, m_Filter.m_nValues[5][4]);
  DDX_Text(pDX, IDC_57, m_Filter.m_nValues[6][4]);

  DDX_Text(pDX, IDC_61, m_Filter.m_nValues[0][5]);
  DDX_Text(pDX, IDC_62, m_Filter.m_nValues[1][5]);
  DDX_Text(pDX, IDC_63, m_Filter.m_nValues[2][5]);
  DDX_Text(pDX, IDC_64, m_Filter.m_nValues[3][5]);
  DDX_Text(pDX, IDC_65, m_Filter.m_nValues[4][5]);
  DDX_Text(pDX, IDC_66, m_Filter.m_nValues[5][5]);
  DDX_Text(pDX, IDC_67, m_Filter.m_nValues[6][5]);

  DDX_Text(pDX, IDC_71, m_Filter.m_nValues[0][6]);
  DDX_Text(pDX, IDC_72, m_Filter.m_nValues[1][6]);
  DDX_Text(pDX, IDC_73, m_Filter.m_nValues[2][6]);
  DDX_Text(pDX, IDC_74, m_Filter.m_nValues[3][6]);
  DDX_Text(pDX, IDC_75, m_Filter.m_nValues[4][6]);
  DDX_Text(pDX, IDC_76, m_Filter.m_nValues[5][6]);
  DDX_Text(pDX, IDC_77, m_Filter.m_nValues[6][6]);

	DDX_Text(pDX, IDC_BIAS, m_Filter.m_nBias);
	DDX_Text(pDX, IDC_DIVISION, m_Filter.m_nDivision);
}


BEGIN_MESSAGE_MAP(CUserFilterDlg, CDialog)
	//{{AFX_MSG_MAP(CUserFilterDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

