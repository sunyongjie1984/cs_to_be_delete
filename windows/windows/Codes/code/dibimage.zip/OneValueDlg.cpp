#include "stdafx.h"
#include "app.h"
#include "OneValueDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

COneValueDlg::COneValueDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COneValueDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COneValueDlg)
	m_nValue = 0;
	//}}AFX_DATA_INIT
  m_nValue = 100;
  m_nMinVal = 0;
  m_nMaxVal = 500;
}


void COneValueDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COneValueDlg)
	DDX_Control(pDX, IDS_SPIN_VALUE, m_ctrlSpinValue);
	DDX_Text(pDX, IDC_VALUE, m_nValue);
	//}}AFX_DATA_MAP
  DDV_MinMaxInt(pDX, m_nValue, m_nMinVal, m_nMaxVal);
}


BEGIN_MESSAGE_MAP(COneValueDlg, CDialog)
	//{{AFX_MSG_MAP(COneValueDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL COneValueDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText(m_sCaption);
  GetDlgItem(IDC_PROMPT_VALUE)->SetWindowText(m_sPrompt);

  m_ctrlSpinValue.SetRange(m_nMinVal, m_nMaxVal);
	
	return TRUE;
}









COneValueFloatDlg::COneValueFloatDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COneValueFloatDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COneValueFloatDlg)
	m_Value = 0;
	//}}AFX_DATA_INIT
  m_Value = 1;
  m_MinVal = 0;
  m_MaxVal = 10;
}


void COneValueFloatDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COneValueDlg)
	DDX_Text(pDX, IDC_VALUE, m_Value);
	//}}AFX_DATA_MAP
  DDV_MinMaxFloat(pDX, m_Value, m_MinVal, m_MaxVal);
}


BEGIN_MESSAGE_MAP(COneValueFloatDlg, CDialog)
	//{{AFX_MSG_MAP(COneValueFloatDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL COneValueFloatDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText(m_sCaption);
  GetDlgItem(IDC_PROMPT_VALUE)->SetWindowText(m_sPrompt);

	return TRUE;
}

