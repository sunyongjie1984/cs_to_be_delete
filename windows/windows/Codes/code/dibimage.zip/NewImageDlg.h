class CNewImageDlg : public CDialog
{
public:
	CNewImageDlg(CWnd* pParent = NULL);   // standard constructor

	//{{AFX_DATA(CNewImageDlg)
	enum { IDD = IDD_NEWIMAGE };
	CSpinButtonCtrl	m_ctrlSpinWidth;
	CSpinButtonCtrl	m_ctrlSpinHeight;
	int		m_nHeight;
	int		m_nWidth;
	//}}AFX_DATA


	//{{AFX_VIRTUAL(CNewImageDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:

	//{{AFX_MSG(CNewImageDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
