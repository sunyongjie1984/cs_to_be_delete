#ifndef __COLORPALETTE_H__
#define __COLORPALETTE_H__

class CColorPalette : public CDialogBar
{
public:
	CColorPalette();
	virtual ~CColorPalette();

	//{{AFX_VIRTUAL(CColorPalette)
	//}}AFX_VIRTUAL

  COLORREF m_ForeColor;
  COLORREF m_BackColor;

protected:
	//{{AFX_MSG(CColorPalette)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	//}}AFX_MSG
  afx_msg LRESULT OnIdleUpdate(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};

#endif //__COLORPALETTE_H__
