#include "dibimage.h"

class CUserFilterDlg : public CDialog
{
public:
	CUserFilterDlg(CWnd* pParent = NULL);   // standard constructor

  C7By7Filter GetUserDefinedFilter() const { return m_Filter; };

protected:

	//{{AFX_DATA(CUserFilterDlg)
	enum { IDD = IDD_USERFILTER };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CUserFilterDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL


	//{{AFX_MSG(CUserFilterDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

  C7By7Filter m_Filter;
};

