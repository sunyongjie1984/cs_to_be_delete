class COneValueDlg : public CDialog
{
public:
	COneValueDlg(CWnd* pParent = NULL);   // standard constructor

	//{{AFX_DATA(COneValueDlg)
	enum { IDD = IDD_ONE_VALUE };
	CSpinButtonCtrl	m_ctrlSpinValue;
	int		m_nValue;
	//}}AFX_DATA

  CString m_sCaption;
  CString m_sPrompt;
  int m_nMinVal;
  int m_nMaxVal;


protected:
	//{{AFX_VIRTUAL(COneValueDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL


	//{{AFX_MSG(COneValueDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


class COneValueFloatDlg : public CDialog
{
public:
	COneValueFloatDlg(CWnd* pParent = NULL);   // standard constructor

	//{{AFX_DATA(COneValueFloatDlg)
	enum { IDD = IDD_ONE_VALUE_DOUBLE };
	float	m_Value;
	//}}AFX_DATA

  CString m_sCaption;
  CString m_sPrompt;
  float m_MinVal;
  float m_MaxVal;


protected:
	//{{AFX_VIRTUAL(COneValueFloatDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL


	//{{AFX_MSG(COneValueFloatDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
