RT Plot Library & Demo Program

Version 1.1 /9.feb.98

This library, demo program and source are distributed 'as is'
etc. etc. etc. 

You may freely use, modify an distribute this source and binaries 
provided that you include this original readme.txt file.

--------

Requirements.

This demo requires VC++ version 5.0 or later.

clPlot is a RT plot designed to display line curves needed 
for on-line monitoring system, electronic monitoring etc.

The plot is capable of running typically 20++ plots at the
same time under Windows 95 and Windows NT.


Some of the Features
------------
- Autoscroll.
- Time X axis.
- Programmable memory limitation
- Separate Left and Right Y axis.
- Independent Legend.
- High performance.


This plot is currently under developement.

Known problems/limitations.

- Flickering. A flicker free (CreateCompatibleDC etc)
draw is not yet implemented. You will find a sample
on how to do this in the Drawcli sample on VC++.


History.
-------------
This plot was developed by the author as a 2-day test due to 
problems with performance using 3rd party plots.

2.des.97	Version 1.0, First demo  version.
9.feb.98	Version 1.1, First version for the net.


Contacting the author.
------------------------
Jan Vidar Berger
Comuniq ASA
janvb@comuniq.com
