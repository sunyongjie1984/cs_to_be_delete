// CPUWizardDlg.cpp : implementation file
//
#include "stdafx.h"
#include "CPUWizard.h"
#include "CPUWizardDlg.h"
#include "CPUInfo.h"
#include "Cpu.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BOOL AbleHlt, First;
LPSTR   lpsz;
CString CmdLine;
HKEY hKey;
char lpWork[16], lpStop[16];

/////////////////////////////////////////////////////////////////////////////
// CCPUWizardDlg dialog

CCPUWizardDlg::CCPUWizardDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCPUWizardDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCPUWizardDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	hIconWork = AfxGetApp()->LoadIcon(IDI_ICONWORK);
	hIconStop = AfxGetApp()->LoadIcon(IDI_ICONSTOP);
	AbleHlt   = TRUE;
	LoadString(AfxGetInstanceHandle(), IDS_WORK, lpWork, 16);
	LoadString(AfxGetInstanceHandle(), IDS_STOP, lpStop, 16);
}

void CCPUWizardDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCPUWizardDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCPUWizardDlg, CDialog)
	//{{AFX_MSG_MAP(CCPUWizardDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_INFO, OnInfo)
	ON_COMMAND(IDM_EXIT, OnExit)
	ON_COMMAND(IDM_ABOUT, OnAbout)
	ON_MESSAGE(MYWM_NOTIFYICON, OnNotifyIcon)
	ON_WM_SHOWWINDOW()
	ON_BN_CLICKED(IDC_EMAIL, OnEmail)
	ON_COMMAND(IDM_MARK, OnCpumark)
	ON_COMMAND(IDM_INFO, OnInfo)
	ON_BN_CLICKED(ID_CPUMARK, OnCpumark)
	ON_BN_CLICKED(IDC_HOMEPAGE, OnHomepage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCPUWizardDlg message handlers

BOOL CCPUWizardDlg::OnInitDialog()
{
	TCHAR lpTemp[256];
				
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(hIconWork, TRUE);			// Set big icon
	SetIcon(hIconStop, FALSE);          // Set small icon

	cThread = AfxBeginThread((AFX_THREADPROC)HaltCPU, NULL, THREAD_PRIORITY_IDLE);
	MenuTrackPopup.CreatePopupMenu();
	MenuTrackPopup.AppendMenu(MF_STRING,  IDM_MARK,  "&CPU����");
	MenuTrackPopup.AppendMenu(MF_STRING,  IDM_INFO,  "��ϸ����(&I)");
	MenuTrackPopup.AppendMenu(MF_STRING,  IDM_ABOUT,  "����(&A)");
	MenuTrackPopup.AppendMenu(MF_SEPARATOR);
    MenuTrackPopup.AppendMenu(MF_STRING, IDM_EXIT, "�˳�(&X)");
	
	::GetModuleFileName(AfxGetInstanceHandle(), lpTemp, 256);
	CmdLine = lpTemp;
	tray.Create(m_hWnd, IDI_ICONWORK, NIF_MESSAGE|NIF_ICON|NIF_TIP, MYWM_NOTIFYICON);
	tray.Add(hIconWork, lpWork);
	First = TRUE;
    // TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCPUWizardDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, hIconWork);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCPUWizardDlg::OnQueryDragIcon()
{
	return (HCURSOR) hIconWork;
}

void CCPUWizardDlg::OnInfo()
{
	tray.Delete();
	CCPUInfo InfoDlg;
	InfoDlg.DoModal();
	tray.Add(hIconWork, lpWork);
}

void CCPUWizardDlg::OnExit()
{
	RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SoftWare\\Microsoft\\Windows\\CurrentVersion\\Run", 0, KEY_ALL_ACCESS, &hKey);
	lpsz = CmdLine.GetBufferSetLength(CmdLine.GetLength());
	int nResult = MessageBox("�����ڹر�CPU���飬���������´�����ʱ���С�\n�Ƿ�ϣ�����?", "CPU����", MB_YESNOCANCEL);
	switch (nResult)
	{
	case IDYES:
		RegSetValueEx(hKey, "CpuWizard", NULL, REG_SZ, (BYTE*)lpsz, sizeof(lpsz));
		tray.Delete();
		PostQuitMessage(0);
		break;
	
	case IDNO:
		RegDeleteValue(hKey, "CpuWizard");	
		tray.Delete();
		PostQuitMessage(0);
		break;
	}

	CmdLine.ReleaseBuffer();
	RegCloseKey(hKey);
}

void CCPUWizardDlg::OnAbout()
{
	tray.Delete();
	::ShowWindowAsync(m_hWnd, SW_RESTORE);
}

DWORD HaltCPU(LPVOID param)
{
	__asm
	{ 
Turn:
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		hlt
		
		jmp Turn
	}
	return 0;
}


void APIENTRY CCPUWizardDlg::HandlePopupMenu(POINT point)
{
	if (point.x < (long) (640 - 50))
        point.x = (long) (640 - 50);

    if (point.y < (long) (480 - 50))
        point.y = (long) (480 - 50);
    
	MenuTrackPopup.TrackPopupMenu(TPM_LEFTBUTTON|TPM_RIGHTBUTTON,
		point.x, point.y, this);
	SetForegroundWindow();
    PostMessage(WM_USER);
}

LONG CCPUWizardDlg::OnNotifyIcon(UINT message, LONG Param) 
{
	POINT point;
	
	switch(LOWORD(Param))
	{
	case WM_LBUTTONDBLCLK:
		if(AbleHlt)
		{
			tray.Modify(hIconStop, lpStop);
			cThread->SuspendThread();
		}
		else
		{
			tray.Modify(hIconWork, lpWork);
			cThread->ResumeThread();
		}
		AbleHlt=!AbleHlt;
		SendDlgItemMessage(IDC_HLT, BM_SETCHECK, AbleHlt);
		break;

	case WM_RBUTTONDOWN:
		::GetCursorPos (&point);
		HandlePopupMenu (point);            
	    break;
	}
	return 0;
}

void CCPUWizardDlg::OnOK() 
{
	::ShowWindowAsync(m_hWnd, SW_HIDE);

	lpsz = CmdLine.GetBufferSetLength(CmdLine.GetLength());
		
	RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SoftWare\\Microsoft\\Windows\\CurrentVersion\\Run", 0, KEY_ALL_ACCESS, &hKey);
	if (SendDlgItemMessage(IDC_AUTORUN, BM_GETCHECK))
		RegSetValueEx(hKey, "CpuWizard", NULL, REG_SZ, (BYTE*)lpsz, sizeof(lpsz));
	else
		RegDeleteValue(hKey, "CpuWizard");
	CmdLine.ReleaseBuffer();
	RegCloseKey(hKey);
	AbleHlt = SendDlgItemMessage(IDC_HLT, BM_GETCHECK);
	if(AbleHlt)
	{
		tray.Add(hIconWork, lpWork);
		cThread->ResumeThread();
	}
	else
	{
		tray.Add(hIconStop, lpStop);
		cThread->SuspendThread();
	}
}

void CCPUWizardDlg::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CString str;
	
	CDialog::OnShowWindow(bShow, nStatus);

	RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SoftWare\\Microsoft\\Windows\\CurrentVersion\\Run", 0, KEY_QUERY_VALUE, &hKey);
	ASSERT(hKey != NULL);
	str.Empty();
	DWORD dw = 0;
	DWORD dwType = 0;
	LONG lRes = RegQueryValueEx(hKey, "CpuWizard", NULL, &dwType, NULL, &dw);
	if (lRes == ERROR_SUCCESS)
	{
		ASSERT(dwType == REG_SZ);
		lpsz = str.GetBufferSetLength(dw);
		lRes = RegQueryValueEx(hKey, "CpuWizard", NULL, &dwType, (BYTE*)lpsz, &dw);
		ASSERT(lRes == ERROR_SUCCESS);
		str.ReleaseBuffer();
	}
	if (str.Find(CmdLine)!=-1)
		SendDlgItemMessage(IDC_AUTORUN, BM_SETCHECK, 1);
	RegCloseKey(hKey);
	SendDlgItemMessage(IDC_HLT, BM_SETCHECK, AbleHlt);
	if (First)
	{
		::ShowWindowAsync(m_hWnd, SW_HIDE);
		First = FALSE;
	}
}

void CCPUWizardDlg::OnEmail() 
{
	ShellExecute(NULL, "open", "mailto:gongmm@163.net", NULL, NULL, SW_SHOWNORMAL);
}

void CCPUWizardDlg::OnHomepage() 
{
	ShellExecute(NULL, "open", "http://gmm.yeah.net", NULL, NULL, SW_SHOWNORMAL);
}

void CCPUWizardDlg::OnCpumark() 
{
	Cpumark();	
}
