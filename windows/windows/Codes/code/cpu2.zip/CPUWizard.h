// CPUWizard.h : main header file for the CPUWIZARD application
//

#if !defined(AFX_CPUWIZARD_H__A7810805_742C_11D2_83C3_D9E130FE4B9F__INCLUDED_)
#define AFX_CPUWIZARD_H__A7810805_742C_11D2_83C3_D9E130FE4B9F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCPUWizardApp:
// See CPUWizard.cpp for the implementation of this class
//

class CCPUWizardApp : public CWinApp
{
public:
	CCPUWizardApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCPUWizardApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCPUWizardApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CPUWIZARD_H__A7810805_742C_11D2_83C3_D9E130FE4B9F__INCLUDED_)
