#if !defined(AFX_CPUINFO_H__A5A6A241_7BF9_11D2_83C5_84A29DD4A28C__INCLUDED_)
#define AFX_CPUINFO_H__A5A6A241_7BF9_11D2_83C5_84A29DD4A28C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CPUInfo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCPUInfo dialog

class CCPUInfo : public CDialog
{
// Construction
public:
	CCPUInfo(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCPUInfo)
	enum { IDD = IDD_CPUINFO };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCPUInfo)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCPUInfo)
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnRetest();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CPUINFO_H__A5A6A241_7BF9_11D2_83C5_84A29DD4A28C__INCLUDED_)
