// CPUInfo.cpp : implementation file
//

#include "stdafx.h"
#include "CPUWizard.h"
#include "CPUInfo.h"
#include "CPU.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CPUINFO CpuInfo;

/////////////////////////////////////////////////////////////////////////////
// CCPUInfo dialog

CCPUInfo::CCPUInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CCPUInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCPUInfo)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CCPUInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCPUInfo)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCPUInfo, CDialog)
	//{{AFX_MSG_MAP(CCPUInfo)
	ON_WM_SHOWWINDOW()
	ON_BN_CLICKED(IDRETEST, OnRetest)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCPUInfo message handlers

void CCPUInfo::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	char buf[10];

	if (!CpuInfo.CpuName.IsEmpty())
		SetDlgItemText(IDC_CPU, CpuInfo.CpuName);
	
	if (CpuInfo.Vendor[0] != '\0')
		SetDlgItemText(IDC_VENDOR, CpuInfo.Vendor);
	if (CpuInfo.SerialNumber[0] != '\0')
		SetDlgItemText(IDC_SN, CpuInfo.SerialNumber);

	if (CpuInfo.ExtendedLevels)
		SetDlgItemText(IDC_EXLEVEL, "֧��");

	wsprintf(buf, "%X", CpuInfo.TLB);
	SetDlgItemText(IDC_TLB, buf);

	wsprintf(buf, "%X", CpuInfo.Cache);
	SetDlgItemText(IDC_CACHE, buf);

	wsprintf(buf, "%d MHz", CpuInfo.Frequency);
	SetDlgItemText(IDC_FREQUENCY, buf);

	wsprintf(buf, "%d", CpuInfo.PR);
	SetDlgItemText(IDC_PR, buf);

	if (CpuInfo.Ratio)
	{
		wsprintf(buf, "%d", CpuInfo.Ratio);
		SetDlgItemText(IDC_RATIO, buf);

		sprintf(buf, "%f", CpuInfo.Frequency/CpuInfo.Ratio);
		SetDlgItemText(IDC_MAINBOARD, buf);
	}

	if (CpuInfo.Cpuid)
	{
		wsprintf(buf, "%X", CpuInfo.Cpuid);
		SetDlgItemText(IDC_CPUID, buf);
	}

	wsprintf(buf, "%d", CpuInfo.Type);
	SetDlgItemText(IDC_TYPE, buf);

	wsprintf(buf, "%d", CpuInfo.Family);
	SetDlgItemText(IDC_FAMILY, buf);

	wsprintf(buf, "%d", CpuInfo.Model);
	SetDlgItemText(IDC_MODEL, buf);

	wsprintf(buf, "%d", CpuInfo.Stepping);
	SetDlgItemText(IDC_STEPPING, buf);
	
	wsprintf(buf, "%X", CpuInfo.Feature);
	SetDlgItemText(IDC_FEATURE, buf);

	SendDlgItemMessage(IDC_FPU, BM_SETCHECK, CpuInfo.Feature & FPU);
	SendDlgItemMessage(IDC_VME, BM_SETCHECK, CpuInfo.Feature & VME);
	SendDlgItemMessage(IDC_DE, BM_SETCHECK, CpuInfo.Feature & DE);
	SendDlgItemMessage(IDC_PSE, BM_SETCHECK, CpuInfo.Feature & PSE);
	SendDlgItemMessage(IDC_TSC, BM_SETCHECK, CpuInfo.Feature & TSC);
	SendDlgItemMessage(IDC_MSR, BM_SETCHECK, CpuInfo.Feature & MSR);
	SendDlgItemMessage(IDC_PAE, BM_SETCHECK, CpuInfo.Feature & PAE);
	SendDlgItemMessage(IDC_MCE, BM_SETCHECK, CpuInfo.Feature & MCE);
	SendDlgItemMessage(IDC_CX8, BM_SETCHECK, CpuInfo.Feature & CX8);
	SendDlgItemMessage(IDC_APIC, BM_SETCHECK, CpuInfo.Feature & APIC);
	SendDlgItemMessage(IDC_SEP, BM_SETCHECK, CpuInfo.Feature & SEP);
	SendDlgItemMessage(IDC_MTRR, BM_SETCHECK, CpuInfo.Feature & MTRR);
	SendDlgItemMessage(IDC_PGF, BM_SETCHECK, CpuInfo.Feature & PGF);
	SendDlgItemMessage(IDC_MCA, BM_SETCHECK, CpuInfo.Feature & MCA);
	SendDlgItemMessage(IDC_CMOV, BM_SETCHECK, CpuInfo.Feature & CMOV);
	SendDlgItemMessage(IDC_PSE36, BM_SETCHECK, CpuInfo.Feature & PSE_36);
	SendDlgItemMessage(IDC_MMX, BM_SETCHECK, CpuInfo.Feature & SN);
	SendDlgItemMessage(IDC_MMX, BM_SETCHECK, (CpuInfo.Feature & MMX)>>15);
	SendDlgItemMessage(IDC_FXSR, BM_SETCHECK, (CpuInfo.Feature & FXSR)>>15);
	SendDlgItemMessage(IDC_SSIMDEX, BM_SETCHECK, (CpuInfo.Feature & SSIMDEX)>>15);
	SendDlgItemMessage(IDC_3DNOW, BM_SETCHECK, (CpuInfo.Feature & NOW)>>28);
	
	SendDlgItemMessage(IDC_AUTOHLT, BM_SETCHECK, CpuInfo.AutoHlt);
	SendDlgItemMessage(IDC_WRITEA, BM_SETCHECK, CpuInfo.WriteAllocatation);
	SendDlgItemMessage(IDC_NOLOCK, BM_SETCHECK, CpuInfo.NoLock);
}

void CCPUInfo::OnRetest() 
{
	AfxGetApp()->BeginWaitCursor();
	CheckCpu(&CpuInfo);
	AfxGetApp()->EndWaitCursor();
	OnShowWindow(TRUE, SW_PARENTOPENING);
}
