#if !defined(AFX_FLASH_H__3E738922_F74C_11D2_83C8_E7C4E7777FB0__INCLUDED_)
#define AFX_FLASH_H__3E738922_F74C_11D2_83C8_E7C4E7777FB0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Flash.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFlash dialog

class CFlash : public CDialog
{
// Construction
public:
	CFlash(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFlash)
	enum { IDD = IDD_FLASH };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlash)
	public:
	virtual int DoModal();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFlash)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FLASH_H__3E738922_F74C_11D2_83C8_E7C4E7777FB0__INCLUDED_)
