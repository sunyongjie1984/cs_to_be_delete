// CPUWizardDlg.h : header file
//

#if !defined(AFX_CPUWIZARDDLG_H__A7810807_742C_11D2_83C3_D9E130FE4B9F__INCLUDED_)
#define AFX_CPUWIZARDDLG_H__A7810807_742C_11D2_83C3_D9E130FE4B9F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define MYWM_NOTIFYICON WM_USER+100
#define IDM_USE         11
#define IDM_ABOUT       12
#define IDM_EXIT        13
#define IDM_INFO        14
#define IDM_MARK        15

#include <CTray\\Ctray.h>

DWORD HaltCPU(LPVOID);

/////////////////////////////////////////////////////////////////////////////
// CCPUWizardDlg dialog

class CCPUWizardDlg : public CDialog
{
// Construction
public:
	CCPUWizardDlg(CWnd* pParent = NULL);	// standard constructor
	void APIENTRY HandlePopupMenu (POINT);
	HICON   hIconWork, hIconStop;
	//HANDLE  hThread;
	CWinThread* cThread;
	CTray   tray;
	
// Dialog Data
	//{{AFX_DATA(CCPUWizardDlg)
	enum { IDD = IDD_CPUWIZARD_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCPUWizardDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CMenu   MenuTrackPopup;

	// Generated message map functions
	//{{AFX_MSG(CCPUWizardDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnInfo();
	afx_msg void OnExit();
	afx_msg void OnAbout();
	virtual void OnOK();
	afx_msg LONG OnNotifyIcon(UINT, LONG);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnEmail();
	afx_msg void OnCpumark();
	afx_msg void OnHomepage();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CPUWIZARDDLG_H__A7810807_742C_11D2_83C3_D9E130FE4B9F__INCLUDED_)
