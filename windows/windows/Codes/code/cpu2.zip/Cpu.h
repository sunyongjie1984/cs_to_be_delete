#include "StdAfx.h"

#define CPUID __asm _emit 0x0F __asm _emit 0xA2
#define RDTSC __asm _emit 0x0F __asm _emit 0x31
#define RDMSR __asm _emit 0x0F __asm _emit 0x32

#define FPU                     0x1     //FPU On-Chip 0
#define VME                     0x2     //Virtual Mode Extension 1
#define DE		                0x4     //Debugging Extension 2
#define PSE                     0x8     //Page Size Extension 3
#define TSC                     0x10    //Time Stamp Counter 4
#define MSR                     0x20    //RDMSR/WRMSR Instructions 5
#define PAE                     0x40    //Physical Address Extension 6
#define MCE                     0x80    //Machine Check Exception 7
#define CX8			            0x100 //CMPXCHG8B Instruction 8
#define APIC                    0x200 //On-chip APIC Hardware 9
#define SEP		                0x800 //SYSENTER/SYSEXIT Instructions 11
#define MTRR                    0x1000 //Memory Type Range Registers 12
#define PGF                     0x2000 //Page Global Enable 13
#define MCA                     0x4000 //Machine Check Architecture 14
#define CMOV                    0x8000 //Conditional Move Instruction 15
#define PAT                     0x10000 //Page Attribute Table 16
#define PSE_36					0x20000 //36Bit Page Size Extension 17
#define SN						0x80000 //Serial Number 18
#define MMX                     0x800000 //MMX Instructions 23
#define FXSR                    0x1000000 //Fast FPU Save and Restore 24
#define SSIMDEX					0x2000000 //Streaming SIMD Extention 25
#define NOW                     0x80000000 //3DNow 31

typedef struct tagCPUINFO{
	CString CpuName;
	char Vendor[13];
	char SerialNumber[13];
	int  Frequency;
	int  PR;
	long Cpuid;
	BOOL ExtendedLevels;
	long Feature;
	int  Type;
	int  Family;
	int  Model;
	int  Stepping;
	int  Ratio;
	UINT TLB;
	UINT Cache;
	BOOL AutoHlt;
	BOOL WriteAllocatation;
	BOOL NoLock;
	BOOL Weakordered;
} CPUINFO, *LPCPUINFO;

void GetCpuidInfo(long cpuid_levels, long *eax, long *ebx, long *ecx, long *edx);
void CheckCpu(LPCPUINFO);
BOOL ChkCpuidEnable();
void Cpumark();
