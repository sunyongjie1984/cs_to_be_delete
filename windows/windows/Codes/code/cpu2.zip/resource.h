//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CPUWizard.rc
//
#define IDRESET                         2
#define ID_CPUMARK                      2
#define ID_IDINFO                       2
#define IDRETEST                        2
#define IDD_CPUWIZARD_DIALOG            102
#define IDR_MAINFRAME                   103
#define IDI_ICONWORK                    104
#define IDI_ICONSTOP                    105
#define IDD_CPUINFO                     106
#define IDD_SET                         107
#define IDD_FLASH                       139
#define IDB_FLASH                       140
#define IDC_INFO                        1000
#define IDC_SETTING                     1001
#define IDC_SLIDER                      1002
#define IDC_AUTORUN                     1003
#define IDC_EMAIL                       1004
#define IDC_CPUID                       1005
#define IDC_HOMEPAGE                    1005
#define IDC_MODEL                       1006
#define IDC_FAMILY                      1007
#define IDC_VENDOR                      1008
#define IDC_CPU                         1009
#define IDC_STEPPING                    1010
#define IDC_TYPE                        1011
#define IDC_FREQUENCY                   1012
#define IDC_FEATURE                     1013
#define IDC_TLB                         1014
#define IDC_CACHE                       1015
#define IDC_FPU                         1016
#define IDC_VME                         1017
#define IDC_DEBUGE                      1018
#define IDC_DE                          1018
#define IDC_PSE                         1019
#define IDC_TSC                         1020
#define IDC_MSR                         1021
#define IDC_PAE                         1022
#define IDC_MCE                         1023
#define IDC_CMPXCHG8B                   1024
#define IDC_CX8                         1024
#define IDC_APIC                        1025
#define IDC_SYSENTER                    1026
#define IDC_SEP                         1026
#define IDC_MTRR                        1027
#define IDC_PGF                         1028
#define IDC_MCA                         1029
#define IDC_CMOV                        1030
#define IDC_PAT                         1031
#define IDC_MMX                         1032
#define IDC_FFSR                        1033
#define IDC_FXSR                        1033
#define IDC_3DNOW                       1034
#define IDC_STATICTLB                   1035
#define IDC_STATICCACHE                 1036
#define IDC_HLT                         1037
#define IDS_WORK                        1037
#define IDC_PSE36                       1037
#define IDS_STOP                        1038
#define IDC_WRITEA                      1038
#define IDC_AUTOHLT                     1039
#define IDC_NOLOCK                      1040
#define IDC_WEAKORDERED                 1041
#define IDC_RATIO                       1078
#define IDC_MAINBOARD                   1079
#define IDC_EXLEVEL                     1081
#define IDC_PR                          1082
#define IDC_SERIAL                      1084
#define IDC_SN                          1085
#define IDC_SSIMDEX                     1086
#define IDC_PROGRESS1                   1087
#define IDC_DR                          1088

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1089
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
