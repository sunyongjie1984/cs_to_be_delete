#include "Cpu.h"

static int Cy6x86PR[6][2] = {
	{80, 90},
	{100, 120},
	{110, 133},
	{120, 150},
	{133, 166},
	{150, 200}
};
static int Cy6x86MXPR[16][2] = {
	{100, 133},
	{110, 133},
	{120, 150},
	{125, 150},
	{133, 166},
	{138, 166},
	{150, 166},
	{150, 166},
	{150, 200},
	{165, 200},
	{166, 200},
	{180, 200},
	{188, 233},
	{200, 233},
	{166, 233},
	{208, 266}
};
static int AMDPR[30][2] = {
	{ 72,75, },
	{ 78,75, },
	{ 87,90, },
	{ 93,90, },
	{ 97,100, },
	{ 103,100, },
	{ 113,120, },
	{ 119,120, },
	{ 130,133, },
	{ 136,133, },
	{ 163,166, },
	{ 169,166, },
	{ 177,180, },
	{ 183,180, },
	{ 197,200, },
	{ 203,200, },
	{ 231,233, },
	{ 236,233, },
	{ 245,250, },
	{ 263,266, },
	{ 269,266, },
	{ 287,300, },
	{ 315,300, },
	{ 316,333, },
	{ 330,333, },
	{ 350,350, },
	{ 363,366, },
	{ 377,380, },
	{ 400,400, },
	{ 450,450, }
};

void TestCPU();

BOOL Is80386()
{

	BOOL Is=FALSE;

	_asm {   
		mov 	bx, sp
		and		sp, not 3
        pushfd					// Push original EFLAGS 
        pop     eax				// Get original EFLAGS
        mov     ecx, eax		// Save original EFLAGS
        xor     eax, 40000h		// Flip AC bit in EFLAGS
        
        push    eax             // Save new EFLAGS value on
        						//   stack
        
        popfd                   // Replace current EFLAGS value
        pushfd					// Get new EFLAGS
        pop     eax             // Store new EFLAGS in EAX
        
        xor     eax, ecx        // Can't toggle AC bit, 
        						//   processor=80386
        
        mov     Is, TRUE		// Turn on 80386 processor flag
        jz      end_80386		// Jump if 80386 processor
		mov		Is, FALSE
	end_80386:
		push	ecx
		popfd
		mov		sp, bx
		//mov		ax, Is
		//and		eax, 0000ffffh
      }

	return Is;
} // Is80386()

// IsCyrix:
 //  Returns TRUE if this is a Cyrix processor.
static int IsCyrix()
{
   int result;

   _asm {
		xor ax, ax                  // clear ax
		sahf                   // clear flags, bit 1 always=1 in flags
		mov ax, 5
		mov bx, 2
		div bl                   // operation that doesn�t change flags
		lahf                   // get flags
		cmp ah, 2                   // check for change in flags
		jne not_cyrix                   // flags changed, therefore NOT CYRIX
		mov result, TRUE                   // TRUE Cyrix CPU
not_cyrix:
		mov result, FALSE                   // FALSE NON-Cyrix CPU
	}
	return result;
}
// cyrix_type:
// *  Detects which type of Cyrix CPU is in use.
/* 
static void CyrixType()
{
   char orgc2, newc2, orgc3, newc3;
   int cr2_rw = FALSE, cr3_rw = FALSE, type;

   type = 0xFF;

   orgc2 = cx_r(0xC2);                 // get current c2 value 
   newc2 = orgc2 ^ 4;                  // toggle test bit 
   cx_w(0xC2, newc2);                  // write test value to c2 
   cx_r(0xC0);                         // dummy read to change bus 
   if (cx_r(0xC2) != orgc2)            // did test bit toggle 
      cr2_rw = TRUE;                   // yes bit changed 
   cx_w(0xC2, orgc2);                  // return c2 to original value 

   orgc3 = cx_r(0xC3);                 // get current c3 value 
   newc3 = orgc3 ^ 0x80;               // toggle test bit 
   cx_w(0xC3, newc3);                  // write test value to c3 
   cx_r(0xC0);                         // dummy read to change bus 
   if (cx_r(0xC3) != orgc3)            // did test bit change 
      cr3_rw = TRUE;                   // yes it did 
   cx_w(0xC3, orgc3);                  // return c3 to original value 

   if (((cr2_rw) && (cr3_rw)) || ((!cr2_rw) && (cr3_rw))) {
      type = cx_r(0xFE);               // DEV ID register ok 
   }
   else if ((cr2_rw) && (!cr3_rw)) {
      type = 0xFE;                     // Cx486S A step 
   }
   else if ((!cr2_rw) && (!cr3_rw)) {
      type = 0xFD;                     // Pre ID Regs. Cx486SLC or DLC 
   }

   if ((type < 0x30) || (type > 0xFC)) {
      cpu_family = 4;                  // 486 class-including 5x86 
      cpu_model = 14;                  // Cyrix 
   }
   else if (type < 0x50) {
      cpu_family = 5;                  // Pentium class-6x86 and Media GX 
      cpu_model = 14;                  // Cyrix 
   }
   else {
      cpu_family = 6;                  // Pentium || class- 6x86MX 
      cpu_model = 14;                  // Cyrix 
      cpu_mmx = TRUE;
   }
}*/

void GetCpuidInfo(long cpuid_levels, long *eax, long *ebx, long *ecx, long *edx)
{ 
	long a, b, c, d;
	
	_asm {
      mov eax, cpuid_levels
      CPUID
      mov a, eax
	  mov b, ebx
	  mov c, ecx
	  mov d, edx
   }
	*eax = a;
	*ebx = b;
	*ecx = c;
	*edx = d;
}

void CheckCpu(LPCPUINFO lpCpuInfo) 
{
	long reg_eax, reg_ebx, reg_ecx, reg_edx;
	DWORD t, Level, vendor_temp[3];
	
	if (IsCyrix())
		_asm{
			pushf
			cli
			mov al, 0xC2 //open Auto hlt
			out 0x22, al
			in  al, 0x23
			or  al, 8
			mov ah, al
			mov al, 0xC2
			out 0x22, al
			mov al, ah
			out 0x23, al
		
			mov al, 0xE8 //open CPUID
			out 0x22, al
			in  al, 0x23
			or  al, 0x100
			mov ah, al
			mov al, 0xE8
			out 0x22, al
			mov al, ah
			out 0x23, al

			mov al, 0xC1 //open NO_LOCK
			out 0x22, al
			in  al, 0x23
			or	al, 8
			mov ah, al
			mov al, 0xC1
			out 0x22, al
			mov al, ah
			out 0x23, al

			mov al, 0xE9 //open Write Allocatation
			out 0x22, al
			in  al, 0x23
			or	al, 1
			mov ah, al
			mov al, 0xE8
			out 0x22, al
			mov al, ah
			out 0x23, al
			
			popf
		}
	
	if (ChkCpuidEnable())
	{
		GetCpuidInfo(0x80000000, &reg_eax, &reg_ebx, &reg_ecx, &reg_edx);
		
		if (reg_eax>>28)
		{
			lpCpuInfo->ExtendedLevels = TRUE;

			GetCpuidInfo(0x80000000, &reg_eax, &reg_ebx, &reg_ecx, &reg_edx);
			Level = reg_eax;
			GetCpuidInfo(0, &reg_eax, &reg_ebx, &reg_ecx, &reg_edx);
			vendor_temp[0] = reg_ebx;
			vendor_temp[1] = reg_edx;
			vendor_temp[2] = reg_ecx;
			memcpy(lpCpuInfo->Vendor, vendor_temp, 12);
		
			GetCpuidInfo(0x80000001, &reg_eax, &reg_ebx, &reg_ecx, &reg_edx);
			lpCpuInfo->Cpuid = reg_eax;
			lpCpuInfo->Type = (reg_eax & 0xF000) >> 12;
			lpCpuInfo->Family = (reg_eax & 0xF00) >> 8;
			lpCpuInfo->Model = (reg_eax & 0xF0) >> 4;
			lpCpuInfo->Stepping = reg_eax & 0xF;
			lpCpuInfo->Feature = reg_edx;
		}		
		else
		{
			GetCpuidInfo(0, &reg_eax, &reg_ebx, &reg_ecx, &reg_edx);
			Level = reg_eax;
			vendor_temp[0] = reg_ebx;
			vendor_temp[1] = reg_edx;
			vendor_temp[2] = reg_ecx;
			memcpy(lpCpuInfo->Vendor, vendor_temp, 12);
		
			GetCpuidInfo(1, &reg_eax, &reg_ebx, &reg_ecx, &reg_edx);
			lpCpuInfo->Cpuid = reg_eax;
			lpCpuInfo->Type = (reg_eax & 0xF000) >> 12;
			lpCpuInfo->Family = (reg_eax & 0xF00) >> 8;
			lpCpuInfo->Model = (reg_eax & 0xF0) >> 4;
			lpCpuInfo->Stepping = reg_eax & 0xF;
			lpCpuInfo->Feature = reg_edx;

			if (lpCpuInfo->Feature & SN)
			{
				GetCpuidInfo(3, &reg_eax, &reg_ebx, &reg_ecx, &reg_edx);
				wsprintf(lpCpuInfo->SerialNumber, "%d%d%d", lpCpuInfo->Cpuid, reg_edx, reg_ecx);
			}
		}

		if (lpCpuInfo->Feature & TSC)
		{
			t = GetTickCount();
			_asm{
				RDTSC
				mov reg_eax, eax
				mov reg_edx, edx
			}
			Sleep(750);
			_asm{
				RDTSC
				sub eax, reg_eax
				sub edx, reg_edx
				mov reg_eax, eax
				mov reg_edx, edx
			}
			t = GetTickCount() - t;
			lpCpuInfo->PR = lpCpuInfo->Frequency = (500 + ((reg_edx<<4)+reg_eax)/t)/1000;
		}
		/*else
			if (lpCpuInfo->Feature & MSR)
			{
				t = GetTickCount();
				_asm{
					mov ecx, 0x11
					RDMSR
					mov reg_eax, eax
					mov reg_edx, edx
				}
				Sleep(750);
				_asm{
					mov ecx, 0x11
					RDMSR
					sub eax, reg_eax
					sub edx, reg_edx
					mov reg_eax, eax
					mov reg_edx, edx
				}
				t = GetTickCount() - t;
				lpCpuInfo->PR = lpCpuInfo->Frequency = (500 + ((reg_edx<<4)+reg_eax)/t)/1000;
			}*/

		int i;
		
		if (strstr(lpCpuInfo->Vendor, "Intel") != NULL)
		{
			switch(lpCpuInfo->Family)
			{
			case 4:
				switch(lpCpuInfo->Model)
				{
				case 0:
				case 1:
					lpCpuInfo->CpuName = "80486 DX";
					break;

				case 2:
					lpCpuInfo->CpuName = "80486 SX";
					break;

				case 3:
					lpCpuInfo->CpuName = "80486 DX2";
					break;

				case 4:
					lpCpuInfo->CpuName = "80486 SL";
					break;

				case 5:
					lpCpuInfo->CpuName = "80486 SX2";
					break;

				case 7:
					lpCpuInfo->CpuName = "80486 DX2WB";
					break;

				case 8:
					lpCpuInfo->CpuName = "80486 DX4";
					break;

				default:
					lpCpuInfo->CpuName = "80486";
					break;
				}
				break;

			case 5:
				_asm{
				pushf
				cli
				mov al, 0xC2 //open Auto hlt
				out 0x22, al
				in  al, 0x23
				or  al, 8
				mov ah, al
				mov al, 0xC2
				out 0x22, al
				mov al, ah
				out 0x23, al
				popf
				}
				switch(lpCpuInfo->Model)
				{
				case 1:
					lpCpuInfo->CpuName = "Pentium 60/66";
					break;

				case 2:
					lpCpuInfo->CpuName = "Pentium 75-200";
					break;

				case 3:
					lpCpuInfo->CpuName = "Pentium OverDirver";
					break;

				case 4:
					lpCpuInfo->CpuName = "Pentium MMX";
					break;
				
				default:
					lpCpuInfo->CpuName = "Pentium";
					break;
				}
				break;

			case 6:
				if (Level >= 2)
					GetCpuidInfo(0x2, &reg_eax, &reg_ebx, &reg_ecx, &reg_edx);
				if ((reg_eax & 0xFF) == 1)
					lpCpuInfo->Cache = reg_edx && 0xFF;
				_asm{
				pushf
				cli
				mov al, 0xC2 //open Auto hlt
				out 0x22, al
				in  al, 0x23
				or  al, 8
				mov ah, al
				mov al, 0xC2
				out 0x22, al
				mov al, ah
				out 0x23, al
				popf
				}
				switch(lpCpuInfo->Model)
				{
				case 1:
					lpCpuInfo->CpuName = "Pentium Pro";
					break;

				case 3:
					lpCpuInfo->CpuName = "Pentium II";
					break;
				
				case 5:
					switch(lpCpuInfo->Cache)
					{
					case 0x40:
						lpCpuInfo->CpuName = "Celeron";
						break;
					case 0x44:
						lpCpuInfo->CpuName = "Pentium II Xeon";
						break;
					default:
						lpCpuInfo->CpuName = "Pentium II";
						break;
					}
					break;

				case 6:
					if (lpCpuInfo->Stepping >= 5)
						lpCpuInfo->CpuName = "Celeron 370";
					else
						lpCpuInfo->CpuName = "Celeron A";
					break;

				case 7:
					if (lpCpuInfo->Cache = 0x44)
						lpCpuInfo->CpuName = "Pentium III Xeon";
					else
						lpCpuInfo->CpuName = "Pentium III";
					break;

				default:
					lpCpuInfo->CpuName = "Pentium Pro";
					break;
				}
				break;
			}
		}

		if (strstr(lpCpuInfo->Vendor, "AMD") != NULL)
		{
			i = 0;
			while ((AMDPR[i][1] < lpCpuInfo->Frequency) && i < 29)
				i++;
			lpCpuInfo->PR = AMDPR[i][2];
				
			switch(lpCpuInfo->Family)
			{
			case 4:
				lpCpuInfo->CpuName = "Am486 / Am5x86";
				break;

			case 5:
				_asm{
				pushf
				cli
				mov al, 0xC2 //open Auto hlt
				out 0x22, al
				in  al, 0x23
				or  al, 8
				mov ah, al
				mov al, 0xC2
				out 0x22, al
				mov al, ah
				out 0x23, al

				mov al, 0xE9 //open Write Allocatation
				out 0x22, al
				in  al, 0x23
				or	al, 1
				mov ah, al
				mov al, 0xE8
				out 0x22, al
				mov al, ah
				out 0x23, al
			
				popf
			}
				/*_asm{
					mov ecx, 0xC0000087        // processor state observability
					RDMSR                      // read constant of PSOR MSR
					mov reg_eax, eax           // save constant of PSOR MSR in bus_state variable
				}
				lpCpuInfo->Ratio = (reg_eax && 8);*/

				switch(lpCpuInfo->Model)
				{
				case 0:
				case 1:
				case 2:
				case 3:
					lpCpuInfo->CpuName = "K5";
					break;

				case 6:
				case 7:
					lpCpuInfo->CpuName = "K6";
					break;

				case 8:
					lpCpuInfo->CpuName = "K6-2";
					break;
				
				case 9:
					lpCpuInfo->CpuName = "K6-III";
					break;
				}
				break;

			case 6:
				_asm{
					mov ecx, 0xC0000087        // processor state observability
					RDMSR                      // read constant of PSOR MSR
					mov reg_eax, eax           // save constant of PSOR MSR in bus_state variable
				}
				lpCpuInfo->Ratio = (reg_eax && 8);
				lpCpuInfo->CpuName = "K7";
				lpCpuInfo->PR = lpCpuInfo->Frequency;
				break;
			}
		}

		if (strstr(lpCpuInfo->Vendor, "Cyrix") != NULL)
		{
			char reg_al;
			_asm{
				cli
				mov al, 0xFE
				out 0x22, al
				in  al, 0x23
				sti
				mov reg_al, al
			}
			lpCpuInfo->Ratio = reg_al;

			switch(lpCpuInfo->Family)
			{
			case 4:
				GetCpuidInfo(0x80000005, &reg_eax, &reg_ebx, &reg_ecx, &reg_edx);
				if ((reg_eax & 0xFF) == 1)
				{
					lpCpuInfo->TLB = reg_eax & 0xFF00;
					lpCpuInfo->Cache = reg_edx & 0xFF;
				}
				lpCpuInfo->CpuName = "MediaGX";
				break;

			case 5:
				i = 0;
				while ((Cy6x86PR[i][1] < lpCpuInfo->Frequency) && i < 6)
					i++;
				lpCpuInfo->PR = Cy6x86PR[i][2];
				switch(lpCpuInfo->Model)
				{
				case 2:
					lpCpuInfo->CpuName = "6x86";
					break;

				case 4:
					lpCpuInfo->CpuName = "GXm";
					break;
				}
				break;

			case 6:
				i = 0;
				while ((Cy6x86MXPR[i][1] < lpCpuInfo->Frequency) && i < 16)
					i++;
				lpCpuInfo->PR = Cy6x86MXPR[i][2];
				lpCpuInfo->CpuName = "6x86MX";
				break;
			}
		}

		if (strstr(lpCpuInfo->Vendor, "Hauls") != NULL)
		{
			lpCpuInfo->PR = lpCpuInfo->Frequency;
			switch(lpCpuInfo->Model)
			{
			case 4:
				lpCpuInfo->CpuName = "WinChip C6";
				break;

			case 8:
				lpCpuInfo->CpuName = "WinChip 2";
				break;
			}
		}

		if (strstr(lpCpuInfo->Vendor, "UMC") != NULL)
		{
			lpCpuInfo->PR = lpCpuInfo->Frequency;
			switch(lpCpuInfo->Family)
			{
			case 4:
				switch(lpCpuInfo->Model)
				{
				case 1:
					lpCpuInfo->CpuName = "UMC486 U5D";
					break;

				case 2:
					lpCpuInfo->CpuName = "UMC486 U5S";
					break;
				}
				break;
			}
		}
		char NoLock, AHD, WA;
		_asm{
			pushf
			cli
			mov al, 0xC1 //ccr1 NO_LOCK
			out 0x22, al
			in  al, 0x23
			and al, 8
			mov NoLock, al

			mov al, 0xC2 //ccr2 Auto Hlt
			out 0x22, al
			in  al, 0x23
			and al, 8
			mov AHD, al

			/*mov al, 0xE8 //ccr4 CPUID
			out 0x22, al
			in  al, 0x23
			and al, 0x80
			mov Cpuid, al*/

			mov al, 0xE9 //ccr5 Write Allocatation
			out 0x22, al
			in  al, 0x23
			and al, 1
			mov WA, al
		
			popf
		}
		lpCpuInfo->AutoHlt = AHD;
		lpCpuInfo->NoLock = NoLock;
		lpCpuInfo->WriteAllocatation = WA;
	}
	if (Is80386())
		lpCpuInfo->CpuName = "80386";
}

BOOL ChkCpuidEnable()
{
	BOOL cpuid_support = TRUE;

	_asm {
        pushfd					// Get original EFLAGS
		pop		eax
		mov 	ecx, eax
        xor     eax, 200000h	// Flip ID bit in EFLAGS
        push    eax				// Save new EFLAGS value on
        						//   stack
        popfd					// Replace current EFLAGS value
        pushfd					// Get new EFLAGS
        pop     eax				// Store new EFLAGS in EAX
        xor     eax, ecx		// Can not toggle ID bit,
        jnz     support			// Processor=80486
		
		mov cpuid_support,FALSE		// Clear support flag
	support:
      }
	return cpuid_support;
}

void Cpumark()
{
	AfxBeginThread((AFX_THREADPROC)TestCPU, NULL, THREAD_PRIORITY_HIGHEST);
}	

void TestCPU()
{
	long Temp_l;
	DWORD FPUMark, IntMark, t;
	char buf[100];

	t = GetTickCount();
	_asm{
		cli
		mov ecx, 0xFFFF
		mov eax, 0xFF
		mov ebx, 0xFF
	IntAgain:
		adc eax, ebx
		sbb eax, ebx
		add eax, ebx
		sub eax, ebx
		inc eax
		dec eax
		neg eax
		neg eax
		mul ebx
		div ebx
		imul ebx
		idiv ebx
		and eax, ebx
		or eax, ebx
		not eax
		not eax
		xor eax, ebx
		xor eax, ebx
		test eax, ebx
		shl eax, 1
		shr eax, 1
		sal eax, 1
		sar eax, 1
		rol eax, 1
		ror eax, 1
		rcl eax, 1
		rcr eax, 1

		dec ecx
		jnz IntAgain
		sti
	}
	IntMark = 0xFFFF / (GetTickCount() - t);
	
	t = GetTickCount();
	_asm{
		cli
		finit
		mov ecx, 0xFFF
		mov eax, 1
		mov ebx, 2
	FPUAgain:
		fist Temp_l
		fistp Temp_l
		fst st(0)
		fstp st(0)
		fild Temp_l
		fld  st(0)
		fld1
		fldl2e
		fldl2t
		fldlg2
		fldln2
		fldpi
		fldz
		fxch
		fcom
		fcomp
		fcompp
		ficom Temp_l
		ficomp Temp_l
		fucom
		fucomp
		fucompp
		ftst
		fxam
		frndint
		fadd st(0), st(1)
		
		dec ecx
		jnz FPUAgain
		sti
	}
	FPUMark = 0xFFF / (GetTickCount() - t);
	
	wsprintf(buf, "����: %d\n����: %d\n", IntMark, FPUMark);
	AfxMessageBox(buf);
}
