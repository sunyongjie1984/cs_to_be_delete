#include <windows.h>
#include <winwlx.h>
#include <stdio.h>
#include <process.h>
#include <time.h>
#include <tchar.h>
#include "globals.h"
#include "exec.h"
#include "reg.h"

#define SINGLELINE "-------------------------------------------------------------------------------\r\n"
#define DOUBLELINE "===============================================================================\r\n"

void OutputToFile(HANDLE hFile, char *fmt,...)
{
    DWORD dwBytes;
    char buffer[MAXLEN];
    va_list args;

    va_start(args,fmt);

    if (hFile!=INVALID_HANDLE_VALUE) {
        vsprintf(buffer,fmt,args);
        WriteFile(hFile,buffer,strlen(buffer),&dwBytes,NULL);
    }
    va_end(args);
}

void OutputTimeStamp(HANDLE hFile, char *additionaltext)
{
     char dbuffer [9];
     char tbuffer [9];

     _strdate(dbuffer);
     _strtime(tbuffer);
     OutputToFile(hFile,DOUBLELINE);
     OutputToFile(hFile,"%s (current date and time is %s, %s)\r\n",additionaltext,dbuffer,tbuffer);
     OutputToFile(hFile,DOUBLELINE);
}

HANDLE OpenLogFile(LPTSTR wszLogFile)
{
    // set up log file for append mode, use stderr if not set or error
    HANDLE hLogFile;
    SECURITY_ATTRIBUTES sa;

    sa.nLength=sizeof(sa);
    sa.lpSecurityDescriptor = NULL;
    sa.bInheritHandle = TRUE;

    if ((_tcscmp(wszLogFile,TEXT(""))==0)||
        ((hLogFile=CreateFile(wszLogFile,
                              GENERIC_WRITE,
                              FILE_SHARE_READ | FILE_SHARE_WRITE,
                              &sa,
                              OPEN_ALWAYS,
                              0,
                              NULL))==INVALID_HANDLE_VALUE)) {
        wprintf(TEXT("OpenLogFile %s failed, %i.\r\n"),wszLogFile,GetLastError());
        hLogFile=GetStdHandle(STD_ERROR_HANDLE);
    } else {
        SetFilePointer(hLogFile, 0, NULL, FILE_END);
    }
    return hLogFile;
}

void ExecuteScript(char *szStartText,
                   char *szEndText,
                   LPTSTR wszScript,
                   LPTSTR wszLogFile,
                   DWORD  dwTimeout,
                   HANDLE hToken)
{
    STARTUPINFO si; 
    PROCESS_INFORMATION pi;
    DWORD dwExitCode;
    TCHAR wszApplication[MAXLEN];
    TCHAR wszCommandLine[MAXLEN];
    TCHAR wszSystemRoot[MAXLEN];
    HANDLE hLogFile;
    BOOL bSuccess;

    hLogFile=OpenLogFile(wszLogFile);

    OutputTimeStamp(hLogFile,szStartText);

    if (_tcscmp(wszScript,TEXT(""))!=0) {

        // assemble command line: (path)\cmd /c script
        if (GetEnvironmentVariable(TEXT("systemroot"),wszSystemRoot,MAXLEN)==0) {
            OutputToFile(hLogFile,"GetEnvironmentVariable for %SystemRoot% failed, using c:\\winnt instead.\r\n");
            _tcscpy(wszSystemRoot,TEXT("c:\\winnt"));
        }
        wsprintf(wszApplication,TEXT("%s\\system32\\cmd.exe"),wszSystemRoot);
        wsprintf(wszCommandLine,TEXT("%s\\system32\\cmd.exe /c \"%s\""),wszSystemRoot,wszScript);

        // set up STARTUPINFO struct
        si.cb = sizeof(STARTUPINFO); 
        si.lpReserved = NULL; 
        si.lpDesktop = NULL; 
        si.lpTitle = NULL; 
        si.cbReserved2 = 0; 
        si.lpReserved2 = NULL; 
        si.wShowWindow = SW_MINIMIZE;
        si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW; 
        si.hStdOutput = hLogFile;
        si.hStdError = hLogFile;
        si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);

        if (hToken==NULL) {
            bSuccess=CreateProcess(wszApplication,
                                   wszCommandLine, // command line
                                   NULL, // security descriptor for process
                                   NULL, // security descriptor for thread
                                   TRUE, // inherit 
                                   CREATE_NEW_PROCESS_GROUP,
                                   NULL, // environment block
                                   NULL, // current directory
                                   &si,
                                   &pi);
        } else {
            bSuccess=CreateProcessAsUser(hToken,
                                         wszApplication,
                                         wszCommandLine, // command line
                                         NULL, // security descriptor for process
                                         NULL, // security descriptor for thread
                                         TRUE, // inherit 
                                         CREATE_NEW_PROCESS_GROUP,
                                         NULL, // environment block
                                         NULL, // current directory
                                         &si,
                                         &pi);
        }
        if (bSuccess) {
            dwTimeout*=1000; // convert milliseconds to seconds
            if (dwTimeout==0) dwTimeout=INFINITE;
            if (WaitForSingleObject(pi.hProcess,dwTimeout)==WAIT_TIMEOUT) {
                GenerateConsoleCtrlEvent(CTRL_BREAK_EVENT,pi.dwProcessId);
                Sleep(1000); // wait a moment until we terminate the process
                OutputToFile(hLogFile,"\r\n");
                OutputToFile(hLogFile,SINGLELINE);
                OutputToFile(hLogFile,"Script did not finish within %i seconds, therefore it was terminated.\r\n",dwTimeout/1000);
            } else {
                GetExitCodeProcess(pi.hProcess,&dwExitCode);
                OutputToFile(hLogFile,"\r\n");
                OutputToFile(hLogFile,SINGLELINE);
                OutputToFile(hLogFile,"Script finished with exit code %i.\r\n",dwExitCode);
            }
            CloseHandle(pi.hThread);
            CloseHandle(pi.hProcess);
        } else {
            OutputToFile(hLogFile,"CreateProcess failed, GetLastError()=%i.\r\n",GetLastError());
        }
    }

    OutputTimeStamp(hLogFile,szEndText);
    OutputToFile(hLogFile,"\r\n");
    CloseHandle(hLogFile);
}


HANDLE TryToLogonUser(LPTSTR wszDomainAndAccount, LPTSTR wszPassword)
{
    TCHAR wszDomain[MAXLEN];
    TCHAR wszAccount[MAXLEN];
    TCHAR *p;
    HANDLE hToken;
    // FILE *fp;

    if (_tcscmp(wszDomainAndAccount,TEXT(""))==0) return NULL; // no user (=run as system)

    p=_tcschr(wszDomainAndAccount,TEXT('\\'));
    if (p==NULL) {
        // no domain specified
        _tcscpy(wszDomain,TEXT("."));
        _tcscpy(wszAccount,wszDomainAndAccount);
    } else {
        // split DOMAIN\ACCOUNT
        *p++=TEXT('\0');
        _tcscpy(wszDomain,wszDomainAndAccount);
        _tcscpy(wszAccount,p);
    }
    // fp=fopen("c:\\temp\\try.log","a");
    // _ftprintf(fp,TEXT("user: %s   domain: %s   password: %s.\n"),wszAccount,wszDomain,wszPassword);
    if (!LogonUser(wszAccount,
                   wszDomain,
                   wszPassword,
                   LOGON32_LOGON_INTERACTIVE,
                   LOGON32_PROVIDER_DEFAULT,
                   &hToken)) {
        // _ftprintf(fp,TEXT("error in LogonUser: %i.\n"),GetLastError());
        // fclose(fp);
        return NULL;
    }
    // _ftprintf(fp,TEXT("LogonUser successful"));
    // fclose(fp);
    return hToken;
}


void ExecuteShutdownScript(void)
{
    TCHAR wszShutdownScript[MAXLEN];
    TCHAR wszLogFile[MAXLEN];
    TCHAR wszDomainAndAccount[MAXLEN];
    TCHAR wszPassword[MAXLEN];
    DWORD dwTimeout;
    HANDLE hUserToken;

    ReadShutdownOptionsFromRegistry(wszShutdownScript,wszLogFile,wszDomainAndAccount,wszPassword,&dwTimeout);

    hUserToken=TryToLogonUser(wszDomainAndAccount,wszPassword);
    _tcsnset(wszPassword,TEXT('*'),MAXLEN); // remove password from memory
    
    ExecuteScript("Start of shutdown script...",
                  "...End of shutdown script",
                  wszShutdownScript,
                  wszLogFile,
                  dwTimeout,
                  hUserToken);

    if (hUserToken!=NULL) CloseHandle(hUserToken);
}


void ExecuteUserLogoffScript(HANDLE hToken)
{
    TCHAR wszUserLogoffScript[MAXLEN];
    TCHAR wszSystemLogoffScript[MAXLEN];
    TCHAR wszLogFile[MAXLEN];
    DWORD dwTimeout;

    ReadLogoffOptionsFromRegistry(wszUserLogoffScript,wszSystemLogoffScript,wszLogFile,&dwTimeout);

    ExecuteScript("Start of user logoff script...",
                  "...End of user logoff script",
                  wszUserLogoffScript,
                  wszLogFile,
                  dwTimeout,
                  hToken);
}

void ExecuteSystemLogoffScript(void)
{
    TCHAR wszUserLogoffScript[MAXLEN];
    TCHAR wszSystemLogoffScript[MAXLEN];
    TCHAR wszLogFile[MAXLEN];
    DWORD dwTimeout;

    ReadLogoffOptionsFromRegistry(wszUserLogoffScript,wszSystemLogoffScript,wszLogFile,&dwTimeout);

    ExecuteScript("Start of system logoff script...",
                  "...End of system logoff script",
                  wszSystemLogoffScript,
                  wszLogFile,
                  dwTimeout,
                  NULL);
}
