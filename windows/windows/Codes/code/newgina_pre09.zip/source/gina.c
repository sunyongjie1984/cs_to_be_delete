/*++

Copyright (c) 1996  Microsoft Corporation

Module Name:

    ginastub.c

Abstract:

    This sample illustrates a pass-thru "stub" gina which can be used
    in some cases to simplify gina development.

    A common use for a gina is to implement code which requires the
    credentials of the user logging onto the workstation.  The credentials
    may be required for syncronization with foreign account databases
    or custom authentication activities.

    In this example case, it is possible to implement a simple gina
    stub layer which simply passes control for the required functions
    to the previously installed gina, and captures the interesting
    parameters from that gina.  In this scenario, the existing functionality
    in the existent gina is retained.  In addition, the development time
    is reduced drastically, as existing functionality does not need to
    be duplicated.

    When dealing with credentials, take steps to maintain the security
    of the credentials.  For instance, if transporting credentials over
    a network, be sure to encrypt the credentials.

Author:

    Scott Field (sfield)    18-Jul-96

--*/

#include <windows.h>
#include <stdio.h>
#include <winwlx.h>
#include <tchar.h>
#include <time.h>

#include "gina.h"
#include "resource.h"
#include "globals.h"
#include "reg.h"
#include "exec.h"

//
// Location of the real msgina.
//

#define REALGINA_PATH   TEXT("MSGINA.DLL")  // default if error occurs with value found in registry


HINSTANCE          hDllInstance;   // My instance, for resource loading
HANDLE             hGlobalWlx;
BOOL               bSomeoneIsLoggedOn=FALSE;
BOOL               bCurrentUserIsAdmin=FALSE;
HANDLE             hMyToken;

#ifdef DEBUGLOG
FILE                        *fpginalog;
#endif

//
// winlogon function dispatch table
//

volatile PWLX_DISPATCH_VERSION_1_0   pWlxFuncs;      // Ptr to table of functions

//
// Functions pointers to the real msgina which we will call.
//

PGWLXNEGOTIATE GWlxNegotiate;
PGWLXINITIALIZE GWlxInitialize;
PGWLXDISPLAYSASNOTICE GWlxDisplaySASNotice;
PGWLXLOGGEDOUTSAS GWlxLoggedOutSAS;
PGWLXACTIVATEUSERSHELL GWlxActivateUserShell;
PGWLXLOGGEDONSAS GWlxLoggedOnSAS;
PGWLXDISPLAYLOCKEDNOTICE GWlxDisplayLockedNotice;
PGWLXWKSTALOCKEDSAS GWlxWkstaLockedSAS;
PGWLXISLOCKOK GWlxIsLockOk;
PGWLXISLOGOFFOK GWlxIsLogoffOk;
PGWLXLOGOFF GWlxLogoff;
PGWLXSHUTDOWN GWlxShutdown;

//
// NEW for version 1.1
//

PGWLXSTARTAPPLICATION GWlxStartApplication;
PGWLXSCREENSAVERNOTIFY GWlxScreenSaverNotify;

BOOL
WINAPI
DllMain(
    HINSTANCE       hInstance,
    DWORD           dwReason,
    LPVOID          lpReserved)
{
    switch (dwReason)
    {
        case DLL_PROCESS_ATTACH:
            DisableThreadLibraryCalls ( hInstance );
            hDllInstance = hInstance;
			//numbad = 0;
        case DLL_PROCESS_DETACH:
        default:
            return(TRUE);
    }
}

//
// hook into the real GINA.
//

BOOL
MyInitialize( void )
{
    HINSTANCE hDll;
    TCHAR wszOriginalGinaDLL[MAXLEN];

    //
    // Load MSGINA.DLL.
    //

    ReadGeneralOptionsFromRegistry(NULL,wszOriginalGinaDLL,NULL,NULL);

    if( !(hDll = LoadLibrary(wszOriginalGinaDLL)) ) {
        if( !(hDll = LoadLibrary( REALGINA_PATH )) ) {
            return FALSE;
        }
    }

    //
    // Get pointers to all of the WLX functions in the real MSGINA.
    //
    GWlxNegotiate = (PGWLXNEGOTIATE)GetProcAddress( hDll, "WlxNegotiate" );
    if( !GWlxNegotiate ) {
        return FALSE;
    }

    GWlxInitialize = (PGWLXINITIALIZE)GetProcAddress( hDll, "WlxInitialize" );
    if( !GWlxInitialize ) {
        return FALSE;
    }

    GWlxDisplaySASNotice =
        (PGWLXDISPLAYSASNOTICE)GetProcAddress( hDll, "WlxDisplaySASNotice" );
    if( !GWlxDisplaySASNotice ) {
        return FALSE;
    }

    GWlxLoggedOutSAS =
        (PGWLXLOGGEDOUTSAS)GetProcAddress( hDll, "WlxLoggedOutSAS" );
    if( !GWlxLoggedOutSAS ) {
        return FALSE;
    }

    GWlxActivateUserShell =
        (PGWLXACTIVATEUSERSHELL)GetProcAddress( hDll, "WlxActivateUserShell" );
    if( !GWlxActivateUserShell ) {
        return FALSE;
    }

    GWlxLoggedOnSAS =
        (PGWLXLOGGEDONSAS)GetProcAddress( hDll, "WlxLoggedOnSAS" );
    if( !GWlxLoggedOnSAS ) {
        return FALSE;
    }

    GWlxDisplayLockedNotice =
        (PGWLXDISPLAYLOCKEDNOTICE)GetProcAddress(
                                        hDll,
                                        "WlxDisplayLockedNotice" );
    if( !GWlxDisplayLockedNotice ) {
        return FALSE;
    }

    GWlxIsLockOk = (PGWLXISLOCKOK)GetProcAddress( hDll, "WlxIsLockOk" );
    if( !GWlxIsLockOk ) {
        return FALSE;
    }

    GWlxWkstaLockedSAS =
        (PGWLXWKSTALOCKEDSAS)GetProcAddress( hDll, "WlxWkstaLockedSAS" );
    if( !GWlxWkstaLockedSAS ) {
        return FALSE;
    }

    GWlxIsLogoffOk = (PGWLXISLOGOFFOK)GetProcAddress( hDll, "WlxIsLogoffOk" );
    if( !GWlxIsLogoffOk ) {
        return FALSE;
    }

    GWlxLogoff = (PGWLXLOGOFF)GetProcAddress( hDll, "WlxLogoff" );
    if( !GWlxLogoff ) {
        return FALSE;
    }

    GWlxShutdown = (PGWLXSHUTDOWN)GetProcAddress( hDll, "WlxShutdown" );
    if( !GWlxShutdown ) {
        return FALSE;
    }

    //
    // we don't check for failure here because these don't exist for
    // gina's implemented prior to Windows NT 4.0
    //

    GWlxStartApplication = (PGWLXSTARTAPPLICATION) GetProcAddress( hDll, "WlxStartApplication" );
    GWlxScreenSaverNotify = (PGWLXSCREENSAVERNOTIFY) GetProcAddress( hDll, "WlxScreenSaverNotify" );

    //
    // Everything loaded ok.  Return success.
    //
    return TRUE;
}


BOOL
WINAPI
WlxNegotiate(
    DWORD       dwWinlogonVersion,
    DWORD       *pdwDllVersion)
{
    if( !MyInitialize() )
        return FALSE;

#ifdef DEBUGLOG
    fpginalog=fopen(DEBUGLOGFILE,"a");
    fprintf(fpginalog,"\n\nWlxNegotiate.\n");
    fflush(fpginalog);
#endif
    
    return GWlxNegotiate( dwWinlogonVersion, pdwDllVersion );
}


BOOL
WINAPI
WlxInitialize(
    LPWSTR      lpWinsta,
    HANDLE      hWlx,
    PVOID       pvReserved,
    PVOID       pWinlogonFunctions,
    PVOID       *pWlxContext)
{
    pWlxFuncs = (PWLX_DISPATCH_VERSION_1_0) pWinlogonFunctions;
    hGlobalWlx = hWlx;

#ifdef DEBUGLOG
    fprintf(fpginalog,"WlxInitialize.\n");
    fflush(fpginalog);
#endif

    return GWlxInitialize(
                lpWinsta,
                hWlx,
                pvReserved,
                pWinlogonFunctions,
                pWlxContext
                );
}


VOID
WINAPI
WlxDisplaySASNotice(PVOID   pWlxContext)
{
    BOOL bNeedCtrlAltDel;

#ifdef DEBUGLOG
    fprintf(fpginalog,"WlxDisplaySASNotice.\n");
    fflush(fpginalog);
#endif

    ReadGeneralOptionsFromRegistry(&bNeedCtrlAltDel,NULL,NULL,NULL);
    if (!bNeedCtrlAltDel) {    
        pWlxFuncs->WlxSasNotify(hGlobalWlx, WLX_SAS_TYPE_CTRL_ALT_DEL);
        return;
    }

    GWlxDisplaySASNotice( pWlxContext );
}


BOOL QueryIfUserIsAdmin(HANDLE hToken)
{
/*  
    check if the owner of the supplied handle is a member of the Administrator group

    IN  ---
    OUT ---

    returns TRUE  if user is an admin
            FALSE if user is not an admin

    This code is taken from Microsoft knowledge base article Q118626.
*/

    UCHAR InfoBuffer[1024];
    PTOKEN_GROUPS ptgGroups = (PTOKEN_GROUPS)InfoBuffer;
    DWORD dwInfoBufferSize;
    PSID psidAdministrators;
    SID_IDENTIFIER_AUTHORITY siaNtAuthority = SECURITY_NT_AUTHORITY;
    UINT x;
    BOOL bSuccess;

    bSuccess = GetTokenInformation(hToken,TokenGroups,InfoBuffer,
                                   1024, &dwInfoBufferSize);

    if(!bSuccess) {
        return FALSE;
    }

    if (!AllocateAndInitializeSid(&siaNtAuthority, 2,
                                  SECURITY_BUILTIN_DOMAIN_RID,
                                  DOMAIN_ALIAS_RID_ADMINS,
                                  0, 0, 0, 0, 0, 0,
                                  &psidAdministrators)) {
        return FALSE;
    }

    /* assume that we don't find the admin SID. */
    bSuccess = FALSE;

    for (x=0;x<ptgGroups->GroupCount;x++) {
        if (EqualSid(psidAdministrators, ptgGroups->Groups[x].Sid)) {
            bSuccess = TRUE;
            break;
        }
    }
    FreeSid(psidAdministrators);

    return bSuccess;
}

int
WINAPI
WlxLoggedOutSAS(
    PVOID           pWlxContext,
    DWORD           dwSasType,
    PLUID           pAuthenticationId,
    PSID            pLogonSid,
    PDWORD          pdwOptions,
    PHANDLE         phToken,
    PWLX_MPR_NOTIFY_INFO    pMprNotifyInfo,
    PVOID           *pProfile)
{
    int iRet;
    long envSize;
    WCHAR *env;

#ifdef DEBUGLOG
    fprintf(fpginalog,"WlxLoggedOutSAS, SasType=%i.\n",dwSasType);
    fflush(fpginalog);
#endif

    iRet = GWlxLoggedOutSAS(
                pWlxContext,
                dwSasType,
                pAuthenticationId,
                pLogonSid,
                pdwOptions,
                phToken,
                pMprNotifyInfo,
                pProfile
                );

    if(iRet == WLX_SAS_ACTION_LOGON) {
        //
        // copy pMprNotifyInfo and pLogonSid for later use
        //
        // pMprNotifyInfo->pszUserName
        // pMprNotifyInfo->pszDomain
        // pMprNotifyInfo->pszPassword
        // pMprNotifyInfo->pszOldPassword
        bCurrentUserIsAdmin=QueryIfUserIsAdmin(*phToken);
#ifdef DEBUGLOG
        fwprintf(fpginalog,L" user %s has logged on to domain %s with password %s.\n",
                pMprNotifyInfo->pszUserName,pMprNotifyInfo->pszDomain,pMprNotifyInfo->pszPassword);
        if (bCurrentUserIsAdmin) {
            fprintf(fpginalog," user is a member of the Administrators group.\n"); 
        } else {
            fprintf(fpginalog," user is not a member of the Administrators group.\n"); 
        }
#endif
        bSomeoneIsLoggedOn=TRUE;
        if (!DuplicateHandle(GetCurrentProcess(),
                             *phToken,
                             GetCurrentProcess(),
                             &hMyToken,
                             0,
                             TRUE,
                             DUPLICATE_SAME_ACCESS)) {
            hMyToken=NULL;
        }

#ifdef DEBUGLOG
        fprintf(fpginalog," returned profile information:\n    type %i\n",((WLX_PROFILE_V1_0 *)(*pProfile))->dwType);
        fflush(fpginalog);
        if (((WLX_PROFILE_V1_0 *)(*pProfile))->dwType==WLX_PROFILE_TYPE_V2_0) {
            fwprintf(fpginalog,TEXT("    profile path: %s\n"),((WLX_PROFILE_V2_0 *)(*pProfile))->pszProfile);
            fflush(fpginalog);
            fwprintf(fpginalog,TEXT("    policy path: %s\n"),((WLX_PROFILE_V2_0 *)(*pProfile))->pszPolicy);
            fflush(fpginalog);
            fwprintf(fpginalog,TEXT("    server: %s\n"),((WLX_PROFILE_V2_0 *)(*pProfile))->pszServerName);
            fflush(fpginalog);
            /*
            env = LocalAlloc(LMEM_FIXED|LMEM_ZEROINIT,2*32768);
            envSize = 0;
            while(wcslen(&pEnvironment[envSize]) > 0) {
                wcscpy(&env[envSize],&pEnvironment[envSize]);
                envSize += wcslen(&pEnvironment[envSize])+1;
            }
            */
            env = ((WLX_PROFILE_V2_0 *)(*pProfile))->pszEnvironment;
            if (env==NULL) {
                fwprintf(fpginalog,TEXT("    no environment block passed.\n"));
                fflush(fpginalog);
            } else {
                envSize = 0;
                while(wcslen(&env[envSize]) > 0) {
                    fwprintf(fpginalog,TEXT("    %s\n"),&env[envSize]);
                    fflush(fpginalog);
                    envSize += wcslen(&env[envSize])+1;
                }
            }
        }
#endif

/*
        if (!DuplicateTokenEx(*phToken,
                              TOKEN_ALL_ACCESS,
                              NULL,
                              SecurityImpersonation,
                              TokenPrimary,
                              &hMyToken)) {
            hMyToken=NULL;
        }
*/
    }

    return iRet;
}


BOOL
WINAPI
WlxActivateUserShell(
    PVOID           pWlxContext,
    PWSTR           pszDesktopName,
    PWSTR           pszMprLogonScript,
    PVOID           pEnvironment)
{
#ifdef DEBUGLOG
    fprintf(fpginalog,"WlxActivateUserShell.\n");
    fflush(fpginalog);
#endif

    return GWlxActivateUserShell(
                pWlxContext,
                pszDesktopName,
                pszMprLogonScript,
                pEnvironment
                );
}

    
int
WINAPI
WlxLoggedOnSAS(
    PVOID           pWlxContext,
    DWORD           dwSasType,
    PVOID           pReserved)
{
#ifdef DEBUGLOG
    fprintf(fpginalog,"WlxLoggedOnSAS, SasType=%i.\n",dwSasType);
    fflush(fpginalog);
#endif

    return GWlxLoggedOnSAS( pWlxContext, dwSasType, pReserved );
}


VOID
WINAPI
WlxDisplayLockedNotice(
    PVOID           pWlxContext )
{
#ifdef DEBUGLOG
    fprintf(fpginalog,"WlxDisplayLockedNotice.\n");
    fflush(fpginalog);
#endif

    GWlxDisplayLockedNotice( pWlxContext );
}


BOOL
WINAPI
WlxIsLockOk(
    PVOID           pWlxContext)
{
    BOOL bAllowProtectedSS;

#ifdef DEBUGLOG
    fprintf(fpginalog,"WlxIsLockOk.\n");
    fflush(fpginalog);
#endif

    ReadGeneralOptionsFromRegistry(NULL,NULL,NULL,&bAllowProtectedSS);
    if ((!bAllowProtectedSS)&&(!bCurrentUserIsAdmin)) {    
#ifdef DEBUGLOG
        fprintf(fpginalog," workstation locking denied.\n");
        fflush(fpginalog);
#endif
        return FALSE;
    }
    return GWlxIsLockOk( pWlxContext );
}


int
WINAPI
WlxWkstaLockedSAS(
    PVOID           pWlxContext,
    DWORD           dwSasType )
{
#ifdef DEBUGLOG
    fprintf(fpginalog,"WlxWkstaLockedSAS, SasType=%i.\n",dwSasType);
    fflush(fpginalog);
#endif
    
    return GWlxWkstaLockedSAS( pWlxContext, dwSasType );
}


BOOL
WINAPI
WlxIsLogoffOk(
    PVOID pWlxContext
    )
{
    BOOL bSuccess;

#ifdef DEBUGLOG
    fprintf(fpginalog,"WlxIsLogoffOk.\n");
    fflush(fpginalog);
#endif

    bSuccess = GWlxIsLogoffOk( pWlxContext );

    if(bSuccess) {

        //
        // if it's ok to logoff, finish with the stored credentials
        // and scrub the buffers
        //
        if (bSomeoneIsLoggedOn&&(hMyToken!=NULL)) {
            ExecuteUserLogoffScript(hMyToken);
            CloseHandle(hMyToken);
        }
        if (bSomeoneIsLoggedOn) {
            ExecuteSystemLogoffScript();
        }
        bSomeoneIsLoggedOn=FALSE;
    }

    return bSuccess;
}


VOID
WINAPI
WlxLogoff(
    PVOID pWlxContext
    )
{
#ifdef DEBUGLOG
    fprintf(fpginalog,"WlxLogoff.\n");
    fflush(fpginalog);
#endif
    
    if (bSomeoneIsLoggedOn&&(hMyToken!=NULL)) {
        ExecuteUserLogoffScript(hMyToken);
        CloseHandle(hMyToken);
    }
    if (bSomeoneIsLoggedOn) {
        ExecuteSystemLogoffScript();
    }
    bSomeoneIsLoggedOn=FALSE;

    GWlxLogoff( pWlxContext );
}


VOID
WINAPI
WlxShutdown(
    PVOID pWlxContext,
    DWORD ShutdownType
    )
{
#ifdef DEBUGLOG
    fprintf(fpginalog,"WlxShutdown.\n");
    fflush(fpginalog);
#endif

    if (bSomeoneIsLoggedOn&&(hMyToken!=NULL)) {
        ExecuteUserLogoffScript(hMyToken);
        CloseHandle(hMyToken);
    }
    if (bSomeoneIsLoggedOn) {
        ExecuteSystemLogoffScript();
    }
    bSomeoneIsLoggedOn=FALSE;

    ExecuteShutdownScript();

    GWlxShutdown( pWlxContext, ShutdownType );
}


//
// NEW for version 1.1
//

BOOL
WINAPI
WlxScreenSaverNotify(
    PVOID                   pWlxContext,
    BOOL *                  pSecure
    )
{
#ifdef DEBUGLOG
    fprintf(fpginalog,"WlxScreenSaverNotify.\n");
    fflush(fpginalog);
#endif

    if(GWlxScreenSaverNotify != NULL)
        return GWlxScreenSaverNotify( pWlxContext, pSecure );

    //
    // if not exported, return something intelligent
    //

    *pSecure = TRUE;

    return TRUE;
}


BOOL
WINAPI
WlxStartApplication(
    PVOID                   pWlxContext,
    PWSTR                   pszDesktopName,
    PVOID                   pEnvironment,
    PWSTR                   pszCmdLine
    )
{
#ifdef DEBUGLOG
    fprintf(fpginalog,"WlxStartApplication.\n");
    fflush(fpginalog);
#endif

    if(GWlxStartApplication != NULL)
        return GWlxStartApplication(
            pWlxContext,
            pszDesktopName,
            pEnvironment,
            pszCmdLine
            );

    //
    // if not exported, return something intelligent
    //

}

