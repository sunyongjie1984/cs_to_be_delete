void ExecuteShutdownScript(void);

void ExecuteUserLogoffScript(HANDLE hToken);

void ExecuteSystemLogoffScript(void);

