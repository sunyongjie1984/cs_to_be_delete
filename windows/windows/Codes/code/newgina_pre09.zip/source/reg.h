void ReadShutdownOptionsFromRegistry(LPTSTR wszShutdownScript,
                                     LPTSTR wszLogFile,
                                     LPTSTR wszAccount,
                                     LPTSTR wszPassword,
                                     DWORD *dwTimeout);

void ReadLogoffOptionsFromRegistry(LPTSTR wszUserLogoffScript,
                                   LPTSTR wszSystemLogoffScript,
                                   LPTSTR wszLogFile,
                                   DWORD *dwTimeout);

void ReadGeneralOptionsFromRegistry(BOOL *bNeedCtrlAltDel,
                                    LPTSTR wszOriginalGinaDLL,
                                    LPTSTR wszGinaDLL,
                                    BOOL *bAllowProtectedSS);

BOOL WriteShutdownOptionsToRegistry(LPTSTR wszShutdownScript,
                                    LPTSTR wszLogFile,
                                    LPTSTR wszAccount,
                                    LPTSTR wszPassword,
                                    DWORD dwTimeout);

BOOL WriteLogoffOptionsToRegistry(LPTSTR wszUserLogoffScript,
                                  LPTSTR wszSystemLogoffScript,
                                  LPTSTR wszLogFile,
                                  DWORD dwTimeout);

BOOL WriteGeneralOptionsToRegistry(BOOL bNeedCtrlAltDel,
                                   LPTSTR wszOriginalGinaDLL,
                                   LPTSTR wszGinaDLL,
                                   BOOL bAllowProtectedSS);

BOOL CleanupRegistry(void);


