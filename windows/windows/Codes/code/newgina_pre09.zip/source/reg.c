#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <winreg.h>
#include "globals.h"
#include "reg.h"

#define SZ_SD_BUF   100
#define SZ_SID_BUF   75
#define SZ_ACL_BUF  250

UCHAR                ucAbsSDBuf      [SZ_SD_BUF]  = "";
UCHAR                ucAdmSIDBuf     [SZ_SID_BUF] = "";
UCHAR                ucSysSIDBuf     [SZ_SID_BUF] = "";
UCHAR                ucACLBuf        [SZ_ACL_BUF] = "";

DWORD                dwSID          = SZ_SID_BUF;
DWORD                dwDACL         = SZ_ACL_BUF;

PSECURITY_DESCRIPTOR psdAbsoluteSD      = (PSECURITY_DESCRIPTOR)&ucAbsSDBuf;
PSID                 psidAdministrators = (PSID)&ucAdmSIDBuf;
PSID                 psidSystem         = (PSID)&ucSysSIDBuf;
PACL                 pNewDACL           = (PACL)&ucACLBuf;

void ReadStringFromRegistry(LPTSTR lpResult, HKEY hKey, LPTSTR lpValue, LPTSTR lpDefault, DWORD dwMaxSize)
{
    DWORD dwType;
    LONG lRv;

    if (lpResult==NULL) return; // ignore

    lRv=RegQueryValueEx(hKey,
                        lpValue,
                        0,
                        &dwType,
                        (LPBYTE) lpResult,
                        &dwMaxSize);
    if ((lRv!=ERROR_SUCCESS)||(dwType!=REG_SZ)) {
        _tcscpy(lpResult,lpDefault);
    }
}

void ReadDWordFromRegistry(DWORD *dwResult, HKEY hKey, LPTSTR lpValue, DWORD dwDefault)
{
    DWORD dwSize;
    DWORD dwType;
    DWORD dwData;
    LONG lRv;
    TCHAR wszTmpDWord[12];

    if (dwResult==NULL) return; // ignore

    // first try: treat value as REG_DWORD
    dwSize=sizeof(DWORD);
    lRv=RegQueryValueEx(hKey,
                        lpValue,
                        0,
                        &dwType,
                        (LPBYTE) &dwData,
                        &dwSize);
    if ((lRv!=ERROR_SUCCESS)||(dwType!=REG_DWORD)) {
        // failed, now try REG_SZ instead
        ReadStringFromRegistry(wszTmpDWord,hKey,lpValue,TEXT(""),sizeof(wszTmpDWord));
        if (_tcscmp(wszTmpDWord,TEXT(""))!=0) {
            dwData=_ttoi(wszTmpDWord); // nonsense will be interpreted as 0
        } else {
            dwData=dwDefault;
        }
    }
    *dwResult=dwData;
}

void ReadBoolFromRegistry(BOOL *bResult, HKEY hKey, LPTSTR lpValue, BOOL bDefault)
{
    DWORD dwData;
    TCHAR wszTmpBool[5];

    if (bResult==NULL) return; // ignore

    // first try: treat value as REG_SZ and test for yes/no and true/false
    ReadStringFromRegistry(wszTmpBool,hKey,lpValue,TEXT(""),sizeof(wszTmpBool));
    if ((_tcsicmp(wszTmpBool,TEXT("yes"))==0)||(_tcsicmp(wszTmpBool,TEXT("true"))==0)) {
        *bResult=TRUE;
    } else if ((_tcsicmp(wszTmpBool,TEXT("no"))==0)||(_tcsicmp(wszTmpBool,TEXT("false"))==0)) {
        *bResult=FALSE;
    } else {
        // failed, now try DWORD instead (includes string representing a number)
        ReadDWordFromRegistry(&dwData,hKey,lpValue,bDefault);
        *bResult=(dwData ? TRUE : FALSE); // a BOOL should be TRUE or FALSE
    }
}

BOOL WriteStringToRegistry(HKEY hKey, LPTSTR lpValue, LPTSTR lpContent)
{
    LONG lRv;

    if (lpContent==NULL) return TRUE; // ignore
    
    lRv=RegSetValueEx(hKey,
                      lpValue,
                      0,
                      REG_SZ,
                      (LPBYTE) lpContent,
                      (_tcslen(lpContent)+1)*sizeof(TCHAR));
    return (lRv==ERROR_SUCCESS);
}

BOOL WriteStringToRegistryOrDeleteIfEmpty(HKEY hKey, LPTSTR lpValue, LPTSTR lpContent)
{
    LONG lRv;

    if (lpContent==NULL) return TRUE; // ignore
    if (_tcscmp(lpContent,TEXT(""))!=0) return WriteStringToRegistry(hKey,lpValue,lpContent);

    
    lRv=RegDeleteValue(hKey,
                       lpValue);
    return (lRv==ERROR_SUCCESS)||(lRv==ERROR_FILE_NOT_FOUND);
}

BOOL WriteDWordToRegistry(HKEY hKey, LPTSTR lpValue, DWORD dwContent)
{
    LONG lRv;

    lRv=RegSetValueEx(hKey,
                      lpValue,
                      0,
                      REG_DWORD,
                      (LPBYTE) &dwContent,
                      sizeof(DWORD));
    return (lRv==ERROR_SUCCESS);
}

BOOL WriteBoolToRegistry(HKEY hKey, LPTSTR lpValue, BOOL bContent)
{
    if (bContent) {
        return WriteStringToRegistry(hKey,lpValue,TEXT("1"));
    } else {
        return WriteStringToRegistry(hKey,lpValue,TEXT("0"));
    }
}

void ReadShutdownOptionsFromRegistry(LPTSTR wszShutdownScript,
                                     LPTSTR wszLogFile,
                                     LPTSTR wszAccount,
                                     LPTSTR wszPassword,
                                     DWORD *dwTimeout)
{
    LONG lRv;
    HKEY hKey;

    if (wszShutdownScript!=NULL) _tcscpy(wszShutdownScript,DEFAULT_SHUTDOWN_SCRIPT);
    if (wszLogFile!=NULL) _tcscpy(wszLogFile,DEFAULT_SHUTDOWN_LOGFILE);
    if (wszAccount!=NULL) _tcscpy(wszAccount,DEFAULT_SHUTDOWN_ACCOUNT);
    if (wszPassword!=NULL) _tcscpy(wszPassword,DEFAULT_SHUTDOWN_PASSWORD);
    *dwTimeout=DEFAULT_SHUTDOWN_TIMEOUT;
    
    lRv=RegOpenKeyEx(REGKEY_ROOT,
                     REGSUBKEY_SHUTDOWN_OPTIONS,
                     0,
                     KEY_QUERY_VALUE,
                     &hKey);
    if (lRv!=ERROR_SUCCESS) {
        return;
    }

    ReadStringFromRegistry(wszShutdownScript,hKey,REGVALUE_SHUTDOWN_SCRIPT,DEFAULT_SHUTDOWN_SCRIPT,MAXLEN);
    ReadStringFromRegistry(wszLogFile,hKey,REGVALUE_SHUTDOWN_LOGFILE,DEFAULT_SHUTDOWN_LOGFILE,MAXLEN);
    ReadStringFromRegistry(wszAccount,hKey,REGVALUE_SHUTDOWN_ACCOUNT,DEFAULT_SHUTDOWN_ACCOUNT,MAXLEN);
    ReadStringFromRegistry(wszPassword,hKey,REGVALUE_SHUTDOWN_PASSWORD,DEFAULT_SHUTDOWN_PASSWORD,MAXLEN);
    ReadDWordFromRegistry(dwTimeout,hKey,REGVALUE_SHUTDOWN_TIMEOUT,DEFAULT_SHUTDOWN_TIMEOUT);

    RegCloseKey(hKey);
}

void ReadLogoffOptionsFromRegistry(LPTSTR wszUserLogoffScript,
                                   LPTSTR wszSystemLogoffScript,
                                   LPTSTR wszLogFile,
                                   DWORD *dwTimeout)
{
    LONG lRv;
    HKEY hKey;

    if (wszUserLogoffScript!=NULL) _tcscpy(wszUserLogoffScript,DEFAULT_USER_LOGOFF_SCRIPT);
    if (wszSystemLogoffScript!=NULL) _tcscpy(wszSystemLogoffScript,DEFAULT_SYSTEM_LOGOFF_SCRIPT);
    if (wszLogFile!=NULL) _tcscpy(wszLogFile,DEFAULT_LOGOFF_LOGFILE);
    *dwTimeout=DEFAULT_LOGOFF_TIMEOUT;
    
    lRv=RegOpenKeyEx(REGKEY_ROOT,
                     REGSUBKEY_LOGOFF_OPTIONS,
                     0,
                     KEY_QUERY_VALUE,
                     &hKey);
    if (lRv!=ERROR_SUCCESS) {
        return;
    }

    ReadStringFromRegistry(wszUserLogoffScript,hKey,REGVALUE_USER_LOGOFF_SCRIPT,DEFAULT_USER_LOGOFF_SCRIPT,MAXLEN);
    ReadStringFromRegistry(wszSystemLogoffScript,hKey,REGVALUE_SYSTEM_LOGOFF_SCRIPT,DEFAULT_SYSTEM_LOGOFF_SCRIPT,MAXLEN);
    ReadStringFromRegistry(wszLogFile,hKey,REGVALUE_LOGOFF_LOGFILE,DEFAULT_LOGOFF_LOGFILE,MAXLEN);
    ReadDWordFromRegistry(dwTimeout,hKey,REGVALUE_LOGOFF_TIMEOUT,DEFAULT_LOGOFF_TIMEOUT);

    RegCloseKey(hKey);
}

void ReadGeneralOptionsFromRegistry(BOOL *bNeedCtrlAltDel,
                                    LPTSTR wszOriginalGinaDLL,
                                    LPTSTR wszGinaDLL,
                                    BOOL *bAllowProtectedSS)
{
    LONG lRv;
    HKEY hKey;

    if (wszOriginalGinaDLL!=NULL) _tcscpy(wszOriginalGinaDLL,DEFAULT_ORIGINAL_GINA_DLL);
    if (wszGinaDLL!=NULL) _tcscpy(wszGinaDLL,DEFAULT_GINA_DLL);
    if (bNeedCtrlAltDel!=NULL) *bNeedCtrlAltDel=DEFAULT_NEED_CTRL_ALT_DEL;
    if (bAllowProtectedSS!=NULL) *bAllowProtectedSS=DEFAULT_ALLOW_PROTECTED_SS;
    
    lRv=RegOpenKeyEx(REGKEY_ROOT,
                     REGSUBKEY_GENERAL_OPTIONS,
                     0,
                     KEY_QUERY_VALUE,
                     &hKey);
    if (lRv!=ERROR_SUCCESS) {
        return;
    }

    ReadBoolFromRegistry(bNeedCtrlAltDel,hKey,REGVALUE_NEED_CTRL_ALT_DEL,DEFAULT_NEED_CTRL_ALT_DEL);
    ReadStringFromRegistry(wszOriginalGinaDLL,hKey,REGVALUE_ORIGINAL_GINA_DLL,DEFAULT_ORIGINAL_GINA_DLL,MAXLEN);
    ReadStringFromRegistry(wszGinaDLL,hKey,REGVALUE_GINA_DLL,DEFAULT_GINA_DLL,MAXLEN);
    ReadBoolFromRegistry(bAllowProtectedSS,hKey,REGVALUE_ALLOW_PROTECTED_SS,DEFAULT_ALLOW_PROTECTED_SS);

    RegCloseKey(hKey);
}

BOOL ApplySecurityDescriptor(HKEY hKey)
{
    LONG lRv;

    SID_IDENTIFIER_AUTHORITY siaNtAuthority = SECURITY_NT_AUTHORITY;

    InitializeSid(psidAdministrators, &siaNtAuthority,2);
    InitializeSid(psidSystem, &siaNtAuthority,1);

    *(GetSidSubAuthority(psidAdministrators,0)) = SECURITY_BUILTIN_DOMAIN_RID;
    *(GetSidSubAuthority(psidAdministrators,1)) = DOMAIN_ALIAS_RID_ADMINS;
    *(GetSidSubAuthority(psidSystem,0)) = SECURITY_LOCAL_SYSTEM_RID;

    if (!InitializeAcl(pNewDACL,
                       dwDACL,
                       ACL_REVISION)) return FALSE;

    if (!AddAccessAllowedAce(pNewDACL,
                             ACL_REVISION,
                             KEY_ALL_ACCESS,
                             psidAdministrators)) return FALSE;

    if (!AddAccessAllowedAce(pNewDACL,
                             ACL_REVISION,
                             KEY_ALL_ACCESS,
                             psidSystem)) return FALSE;

    if (!InitializeSecurityDescriptor(psdAbsoluteSD,
                                      SECURITY_DESCRIPTOR_REVISION)) return FALSE;

    if (!SetSecurityDescriptorDacl(psdAbsoluteSD,
                                   TRUE,      // fDaclPresent flag
                                   pNewDACL,
                                   FALSE))    // not a default DACL
                                           return FALSE;

    if (!IsValidSecurityDescriptor(psdAbsoluteSD)) return FALSE;
    
    lRv=RegSetKeySecurity(hKey,
                         (SECURITY_INFORMATION)(DACL_SECURITY_INFORMATION),
                         psdAbsoluteSD);
    if (lRv!=ERROR_SUCCESS) return FALSE;

    return TRUE;
}

BOOL WriteShutdownOptionsToRegistry(LPTSTR wszShutdownScript,
                                    LPTSTR wszLogFile,
                                    LPTSTR wszAccount,
                                    LPTSTR wszPassword,
                                    DWORD dwTimeout)
{
    LONG lRv;
    DWORD dwDisposition;
    HKEY hKey;
    BOOL bSuccess;

    lRv=RegCreateKeyEx(REGKEY_ROOT,
                       REGSUBKEY_SHUTDOWN_OPTIONS,  
                       0,  
                       NULL,  
                       REG_OPTION_NON_VOLATILE, 
                       KEY_ALL_ACCESS, 
                       NULL, 
                       &hKey, 
                       &dwDisposition);
    if (lRv!=ERROR_SUCCESS) return FALSE;

    bSuccess=WriteStringToRegistry(hKey,REGVALUE_SHUTDOWN_SCRIPT,wszShutdownScript) &&
             WriteStringToRegistry(hKey,REGVALUE_SHUTDOWN_LOGFILE,wszLogFile) &&
             WriteStringToRegistry(hKey,REGVALUE_SHUTDOWN_ACCOUNT,wszAccount) &&
             WriteStringToRegistry(hKey,REGVALUE_SHUTDOWN_PASSWORD,wszPassword) &&
             WriteDWordToRegistry(hKey,REGVALUE_SHUTDOWN_TIMEOUT,dwTimeout);

    bSuccess = bSuccess && ApplySecurityDescriptor(hKey);
    
    RegCloseKey(hKey);

    return bSuccess;
}

BOOL WriteLogoffOptionsToRegistry(LPTSTR wszUserLogoffScript,
                                  LPTSTR wszSystemLogoffScript,
                                  LPTSTR wszLogFile,
                                  DWORD dwTimeout)
{
    LONG lRv;
    DWORD dwDisposition;
    HKEY hKey;
    BOOL bSuccess;

    lRv=RegCreateKeyEx(REGKEY_ROOT,
                       REGSUBKEY_LOGOFF_OPTIONS,  
                       0,  
                       NULL,  
                       REG_OPTION_NON_VOLATILE, 
                       KEY_ALL_ACCESS, 
                       NULL, 
                       &hKey, 
                       &dwDisposition);
    if (lRv!=ERROR_SUCCESS) return FALSE;

    bSuccess=WriteStringToRegistry(hKey,REGVALUE_USER_LOGOFF_SCRIPT,wszUserLogoffScript) &&
             WriteStringToRegistry(hKey,REGVALUE_SYSTEM_LOGOFF_SCRIPT,wszSystemLogoffScript) &&
             WriteStringToRegistry(hKey,REGVALUE_LOGOFF_LOGFILE,wszLogFile) &&
             WriteDWordToRegistry(hKey,REGVALUE_LOGOFF_TIMEOUT,dwTimeout);

    // bSuccess = bSuccess && ApplySecurityDescriptor(hKey);

    RegCloseKey(hKey);

    return bSuccess;
}

BOOL WriteGeneralOptionsToRegistry(BOOL bNeedCtrlAltDel,
                                   LPTSTR wszOriginalGinaDLL,
                                   LPTSTR wszGinaDLL,
                                   BOOL bAllowProtectedSS)
{
    LONG lRv;
    DWORD dwDisposition;
    HKEY hKey;
    BOOL bSuccess;

    lRv=RegCreateKeyEx(REGKEY_ROOT,
                       REGSUBKEY_GENERAL_OPTIONS,  
                       0,  
                       NULL,  
                       REG_OPTION_NON_VOLATILE, 
                       KEY_ALL_ACCESS, 
                       NULL, 
                       &hKey, 
                       &dwDisposition);
    if (lRv!=ERROR_SUCCESS) return FALSE;

    bSuccess=WriteBoolToRegistry(hKey,REGVALUE_NEED_CTRL_ALT_DEL,bNeedCtrlAltDel) &&
             WriteStringToRegistryOrDeleteIfEmpty(hKey,REGVALUE_ORIGINAL_GINA_DLL,wszOriginalGinaDLL) &&
             WriteStringToRegistryOrDeleteIfEmpty(hKey,REGVALUE_GINA_DLL,wszGinaDLL) &&
             WriteBoolToRegistry(hKey,REGVALUE_ALLOW_PROTECTED_SS,bAllowProtectedSS);
    
    RegCloseKey(hKey);

    return bSuccess;
}

LONG RegDeleteKeyIfExists(HKEY hKey, LPCTSTR lpSubKey)
{
    LONG lRv;

    lRv=RegDeleteKey(hKey, lpSubKey);
    if (lRv==ERROR_FILE_NOT_FOUND) {
        lRv=ERROR_SUCCESS;
    }
    return lRv;
}

LONG RegDeleteValueIfExists(HKEY hKey, LPCTSTR lpValueName)
{
    LONG lRv;

    lRv=RegDeleteValue(hKey, lpValueName);
    if (lRv==ERROR_FILE_NOT_FOUND) {
        lRv=ERROR_SUCCESS;
    }
    return lRv;
}

BOOL CleanupRegistry(void)
{
    HKEY hKey;
    BOOL bSuccess=TRUE;
    TCHAR wszGinaDLL[MAXLEN];
    LONG lRv;

    if ((lRv=RegDeleteKeyIfExists(REGKEY_ROOT,REGSUBKEY_SHUTDOWN_OPTIONS))!=ERROR_SUCCESS) {
        // ErrorMessageBox("%s, %i.",REGSUBKEY_SHUTDOWN_OPTIONS,lRv);
        bSuccess=FALSE;
    }

    if ((lRv=RegDeleteKeyIfExists(REGKEY_ROOT,REGSUBKEY_LOGOFF_OPTIONS))!=ERROR_SUCCESS) {
        // ErrorMessageBox("%s, %i.",REGSUBKEY_LOGOFF_OPTIONS,lRv);
        bSuccess=FALSE;
    }

    if ((lRv=RegOpenKeyEx(REGKEY_ROOT,
                          REGSUBKEY_GENERAL_OPTIONS,
                          0,
                          KEY_ALL_ACCESS,
                          &hKey))!=ERROR_SUCCESS) {
        // ErrorMessageBox("%s, %i.",REGSUBKEY_GENERAL_OPTIONS,lRv);
        bSuccess=FALSE;
    } else {
        if ((lRv=RegDeleteValueIfExists(hKey,REGVALUE_NEED_CTRL_ALT_DEL))!=ERROR_SUCCESS) {
            // ErrorMessageBox("%s, %i.",REGVALUE_NEED_CTRL_ALT_DEL,lRv);
            bSuccess=FALSE;
        }
        if ((lRv=RegDeleteValueIfExists(hKey,REGVALUE_ORIGINAL_GINA_DLL))!=ERROR_SUCCESS) {
            // ErrorMessageBox("%s, %i.",REGVALUE_ORIGINAL_GINA_DLL,lRv);
            bSuccess=FALSE;
        }
        if ((lRv=RegDeleteValueIfExists(hKey,REGVALUE_ALLOW_PROTECTED_SS))!=ERROR_SUCCESS) {
            // ErrorMessageBox("%s, %i.",REGVALUE_ALLOW_PROTECTED_SS,lRv);
            bSuccess=FALSE;
        }
        ReadStringFromRegistry(wszGinaDLL,hKey,REGVALUE_GINA_DLL,_T("REGISTRY_KEY_NOT_AVAILABLE"),MAXLEN);
        if (_tcscmp(wszGinaDLL,_T("REGISTRY_KEY_NOT_AVAILABLE"))==0) {
            if ((lRv=RegDeleteValueIfExists(hKey,REGVALUE_GINA_DLL))!=ERROR_SUCCESS) {
                // ErrorMessageBox("%s, %i.",REGVALUE_GINA_DLL,lRv);
                bSuccess=FALSE;
            }
        }
        RegCloseKey(hKey);
    }

    return bSuccess;
}

