#define GINAVERSION_MAJOR 0
#define GINAVERSION_MINOR 90

#define MAXLEN 1024

#define REGKEY_ROOT                     HKEY_LOCAL_MACHINE
#define REGSUBKEY_WINLOGON              TEXT("Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon")

#define REGSUBKEY_GENERAL_OPTIONS       REGSUBKEY_WINLOGON
#define REGVALUE_NEED_CTRL_ALT_DEL      TEXT("NeedCtrlAltDel")
#define REGVALUE_ORIGINAL_GINA_DLL      TEXT("OriginalGinaDLL")
#define REGVALUE_GINA_DLL               TEXT("GinaDLL")
#define REGVALUE_ALLOW_PROTECTED_SS     TEXT("AllowProtectedSS")

#define REGSUBKEY_SHUTDOWN_OPTIONS      REGSUBKEY_WINLOGON TEXT("\\Shutdown")
#define REGVALUE_SHUTDOWN_SCRIPT        TEXT("Script")
#define REGVALUE_SHUTDOWN_LOGFILE       TEXT("Logfile")
#define REGVALUE_SHUTDOWN_TIMEOUT       TEXT("Timeout")
#define REGVALUE_SHUTDOWN_ACCOUNT       TEXT("Account")
#define REGVALUE_SHUTDOWN_PASSWORD      TEXT("Password")

#define REGSUBKEY_LOGOFF_OPTIONS        REGSUBKEY_WINLOGON TEXT("\\Logoff")
#define REGVALUE_USER_LOGOFF_SCRIPT     TEXT("UserScript")
#define REGVALUE_SYSTEM_LOGOFF_SCRIPT   TEXT("SystemScript")
#define REGVALUE_LOGOFF_LOGFILE         TEXT("Logfile")
#define REGVALUE_LOGOFF_TIMEOUT         TEXT("Timeout")

#define DEFAULT_NEED_CTRL_ALT_DEL       FALSE
#define DEFAULT_ORIGINAL_GINA_DLL       TEXT("msgina.dll")
#define DEFAULT_GINA_DLL                TEXT("")
#define DEFAULT_ALLOW_PROTECTED_SS      TRUE

#define DEFAULT_SHUTDOWN_SCRIPT         TEXT("")
#define DEFAULT_SHUTDOWN_LOGFILE        TEXT("")
#define DEFAULT_SHUTDOWN_TIMEOUT        60
#define DEFAULT_SHUTDOWN_ACCOUNT        TEXT("")
#define DEFAULT_SHUTDOWN_PASSWORD       TEXT("")

#define DEFAULT_USER_LOGOFF_SCRIPT      TEXT("")
#define DEFAULT_SYSTEM_LOGOFF_SCRIPT    TEXT("")
#define DEFAULT_LOGOFF_LOGFILE          TEXT("")
#define DEFAULT_LOGOFF_TIMEOUT          60


// Add your platform here if you want to compile neither for Alpha nor Intel

#ifdef _M_IX86
  #define GINA_DLL TEXT("gina_x86.dll")
#else
  #ifdef _M_ALPHA
    #define GINA_DLL TEXT("gina_axp.dll")
  #else 
    // add your platform here
    #error Unknown platform, supported is Intel x86 and DEC Alpha
  #endif
#endif
#define GINA_SETUP_PROGRAM TEXT("ginasetup.exe")

#define PASSWORD_NOT_CHANGED TEXT("**************")

#define DEBUGLOGFILE "c:\\temp\\ginadbg.log"
