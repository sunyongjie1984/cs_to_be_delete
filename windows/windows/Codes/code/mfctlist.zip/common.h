
/******************************************************************************\
*       This is a part of the Microsoft Source Code Samples. 
*		  Copyright (C) 1994-1996 Microsoft Corporation.
*       All rights reserved. 
*       This source code is only intended as a supplement to 
*       Microsoft Development Tools and/or WinHelp documentation.
*       See these sources for detailed information regarding the 
*       Microsoft samples programs.
\******************************************************************************/

#ifndef __MCTLISTCOMMONDOTH__
#define __MCTLISTCOMMONDOTH__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


//SAMPLE: this code is from the SDK TList sample
// and was hacked up to use MFC by
// Mike Blaszczak (mikeblas@nwlink.com)

#include <afxtempl.h>

#define TITLE_SIZE          64
#define PROCESS_SIZE        MAX_PATH


// task list structure

//SAMPLE: derive this guy from CObject instead of
// using a plain struct

class CTaskListEntry : public CObject
{
public:
	CTaskListEntry() { ProcessName[0] = WindowTitle[0] = 0; }
	~CTaskListEntry() { }

	DWORD       dwProcessId;
    DWORD       dwInheritedFromProcessId;
    BOOL        flags;
    HWND        hwnd;
    CHAR        ProcessName[PROCESS_SIZE];
    CHAR        WindowTitle[TITLE_SIZE];
};

typedef CTypedPtrArray<CObArray, CTaskListEntry*> CTaskList;

//
// Function pointer types for accessing platform-specific functions
//

typedef DWORD (*LPGetTaskList)(CTaskList&);
typedef BOOL  (*LPEnableDebugPriv)(VOID);


//
// Function prototypes
//
DWORD GetTaskList95(CTaskList& refTask);

DWORD GetTaskListNT(CTaskList& refTask);

BOOL EnableDebugPriv95(VOID);

BOOL EnableDebugPrivNT(VOID);

BOOL
KillProcess(
    CTaskListEntry* pEntry,
    BOOL       fForce
    );

VOID
GetWindowTitles(
    CTaskList& refList
    );

BOOL
MatchPattern(
    PUCHAR String,
    PUCHAR Pattern
    );

#endif
