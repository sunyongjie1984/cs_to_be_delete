// MFCTList.h : main header file for the MFCTLIST application
//

#if !defined(AFX_MFCTLIST_H__59DB9B48_E2D9_11D1_91E3_00AA0037DE94__INCLUDED_)
#define AFX_MFCTLIST_H__59DB9B48_E2D9_11D1_91E3_00AA0037DE94__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

#include "common.h"

/////////////////////////////////////////////////////////////////////////////
// CMFCTListApp:
// See MFCTList.cpp for the implementation of this class
//

class CMFCTListApp : public CWinApp
{
public:
	CMFCTListApp();
	void ClearTaskList();
	CTaskList& GetTaskList();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCTListApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	CTaskList m_tasklist;

	//{{AFX_MSG(CMFCTListApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCTLIST_H__59DB9B48_E2D9_11D1_91E3_00AA0037DE94__INCLUDED_)
