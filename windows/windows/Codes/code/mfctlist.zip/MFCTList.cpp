// MFCTList.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "MFCTList.h"
#include "MFCTListDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMFCTListApp

BEGIN_MESSAGE_MAP(CMFCTListApp, CWinApp)
	//{{AFX_MSG_MAP(CMFCTListApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCTListApp construction

CMFCTListApp::CMFCTListApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CMFCTListApp object

CMFCTListApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CMFCTListApp initialization

BOOL CMFCTListApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

	CMFCTListDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	ClearTaskList();

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

void CMFCTListApp::ClearTaskList()
{
	int n;
	for (n = 0; n < m_tasklist.GetSize(); n++)
		delete m_tasklist[n];
	m_tasklist.RemoveAll();
}

CTaskList& CMFCTListApp::GetTaskList()
{
	return m_tasklist;
}
