// MFCTListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MFCTList.h"
#include "MFCTListDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCTListDlg dialog

CMFCTListDlg::CMFCTListDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMFCTListDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMFCTListDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMFCTListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMFCTListDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMFCTListDlg, CDialog)
	//{{AFX_MSG_MAP(CMFCTListDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_KILL, OnKill)
	ON_BN_CLICKED(IDC_REFRESH, OnRefresh)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_TASKLIST, OnItemchangedTasklist)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCTListDlg message handlers

BOOL CMFCTListDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	//SAMPLE
	// add columns to list control

	CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_TASKLIST);
	ASSERT(pList != NULL);

	pList->InsertColumn(0, _T("Task Name"));
	pList->InsertColumn(1, _T("Process ID"));
	pList->InsertColumn(2, _T("Window Title"));

	// load the control

	DoRefresh();

	//END_SAMPLE
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMFCTListDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMFCTListDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMFCTListDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMFCTListDlg::OnKill() 
{
	//SAMPLE
	// find the selected task and kill it
	CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_TASKLIST);
	ASSERT(pList != NULL);

	int nItem = pList->GetNextItem(-1, LVIS_SELECTED);

	// no sorting, so we know nItem is still an index into
	// our array

	CMFCTListApp* pApp = (CMFCTListApp*) AfxGetApp();
	CTaskList& refTaskList = pApp->GetTaskList();

	BOOL bResult = KillProcess(refTaskList[nItem], TRUE);
	if (bResult)
	{
		DoRefresh();
		MessageBox("Kill worked!");
	}
	else
		MessageBox("Kill failed!");

}

void CMFCTListDlg::OnRefresh() 
{
	//SAMPLE
	// call implementation function to populate control

	DoRefresh();

	//END_SAMPLE
}


void CMFCTListDlg::DoRefresh()
{
	//SAMPLE
	// Actually populate the list!
	// Most of this code is from the TList sample's TLIST.C file.
	// The code was modified to work with the list view control
	// and also uses an MFC collection class instead of a
	// fixed-size array.

	CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_TASKLIST);
	ASSERT(pList != NULL);

	// reset what's there

	pList->DeleteAllItems();

    //
    // Determine what system we're on and do the right thing
    //

    LPGetTaskList     GetTaskList;
    LPEnableDebugPriv EnableDebugPriv;

    OSVERSIONINFO verInfo;
	memset(&verInfo, 0, sizeof(verInfo));

    verInfo.dwOSVersionInfoSize = sizeof(verInfo);
    GetVersionEx(&verInfo);

    switch (verInfo.dwPlatformId)
    {
    case VER_PLATFORM_WIN32_NT:
		GetTaskList     = GetTaskListNT;
		EnableDebugPriv = EnableDebugPrivNT;
		break;

    case VER_PLATFORM_WIN32_WINDOWS:
		GetTaskList = GetTaskList95;
		EnableDebugPriv = EnableDebugPriv95;
		break;

    default:
//		m_bBroken = TRUE;
		pList->InsertItem(0, _T("Requires Win95 or WinNT"));
		return;
    }

    EnableDebugPriv();

    // get the task list for the system

	CMFCTListApp* pApp = (CMFCTListApp*) AfxGetApp();
	pApp->ClearTaskList();
	CTaskList& refTaskList = pApp->GetTaskList();

    DWORD numTasks = GetTaskList(refTaskList);

    // enumerate all windows and try to get the window
    // titles for each task

    GetWindowTitles(refTaskList);

    //
    // print the task list
    //

	int n;
	for (n = 0; n < refTaskList.GetSize(); n++)
	{
		CString str;
		str.Format("0x%8.8X", refTaskList[n]->dwProcessId);

		int nItem = pList->InsertItem(n, refTaskList[n]->ProcessName);
		pList->SetItemText(nItem, 1, str);
		pList->SetItemText(nItem, 2, refTaskList[n]->WindowTitle);
	}

	pList->SetColumnWidth(0, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(1, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(2, LVSCW_AUTOSIZE);

	CWnd* pWnd = GetDlgItem(IDC_KILL);
	pWnd->EnableWindow(FALSE);

	//END_SAMPLE
}

void CMFCTListDlg::OnItemchangedTasklist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	//SAMPLE: enable or disable the kill button

	CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_TASKLIST);
	ASSERT(pList != NULL);
	int n = pList->GetNextItem(-1, LVIS_SELECTED);

	CWnd* pWnd = GetDlgItem(IDC_KILL);
	pWnd->EnableWindow(n != -1);
	
	*pResult = 0;
}
