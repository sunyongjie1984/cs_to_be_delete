// bsortDoc.h : interface of the CBsortDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_BSORTDOC_H__62E69810_333A_11D3_A76B_0000E866782A__INCLUDED_)
#define AFX_BSORTDOC_H__62E69810_333A_11D3_A76B_0000E866782A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CBsortDoc : public CDocument
{
protected: // create from serialization only
	CBsortDoc();
	DECLARE_DYNCREATE(CBsortDoc)

// Attributes
public:
	int A[20];
	int barnum;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBsortDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL IsSame(int n,int index);
	virtual ~CBsortDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CBsortDoc)
	afx_msg void OnFileNew();
	afx_msg void OnSet();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BSORTDOC_H__62E69810_333A_11D3_A76B_0000E866782A__INCLUDED_)
