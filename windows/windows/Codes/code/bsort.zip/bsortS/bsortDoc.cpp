// bsortDoc.cpp : implementation of the CBsortDoc class
//

#include "stdafx.h"
#include "bsort.h"

#include "bsortDoc.h"
#include "blistdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBsortDoc

IMPLEMENT_DYNCREATE(CBsortDoc, CDocument)

BEGIN_MESSAGE_MAP(CBsortDoc, CDocument)
	//{{AFX_MSG_MAP(CBsortDoc)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_SET, OnSet)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBsortDoc construction/destruction

CBsortDoc::CBsortDoc()
{
	srand(CTime::GetCurrentTime().GetTime());
	barnum=1 + rand() % 20;
	if(barnum<5)
		barnum=5;
	for( int i = 0; i<barnum; i++ )
	{
		A[i] = 1 + (rand() % 20);
		while(IsSame(A[i],i))
			A[i] = 1 + (rand() % 20);
	}
}

CBsortDoc::~CBsortDoc()
{
}

BOOL CBsortDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CBsortDoc serialization

void CBsortDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
		ar<<barnum;
		for(int i=0;i<barnum;i++)
			ar<<A[i];
	}
	else
	{
		// TODO: add loading code here
		ar>>barnum;
		for(int i=0;i<barnum;i++)
			ar>>A[i];
	}
}

/////////////////////////////////////////////////////////////////////////////
// CBsortDoc diagnostics

#ifdef _DEBUG
void CBsortDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CBsortDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBsortDoc commands

void CBsortDoc::OnFileNew() 
{
	// TODO: Add your command handler code here
/*	srand(CTime::GetCurrentTime().GetTime());
	for( int i = 0; i<10; i++ )
		A[i] = 1 + (rand() % 20);
	UpdateAllViews(0);//this);*/
	srand(CTime::GetCurrentTime().GetTime());
	barnum=1 + rand() % 20;
	if(barnum<5)
		barnum=5;
	for( int i = 0; i<barnum; i++ )
	{
		A[i] = 1 + (rand() % 20);
		while(IsSame(A[i],i))
			A[i] = 1 + (rand() % 20);
	}
	UpdateAllViews(0);//this);
}

BOOL CBsortDoc::IsSame(int n,int index)
{
	for( int i = 0; i<index; i++ )
		if(A[i]==n)
			return TRUE;
	return FALSE;
}

void CBsortDoc::OnSet() 
{
	// TODO: Add your command handler code here
	CBlistDlg dlg;
	dlg.A = A;
	dlg.pDoc = this;
	dlg.DoModal();
}
