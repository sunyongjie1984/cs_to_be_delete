// bsortView.h : interface of the CBsortView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_BSORTVIEW_H__62E69812_333A_11D3_A76B_0000E866782A__INCLUDED_)
#define AFX_BSORTVIEW_H__62E69812_333A_11D3_A76B_0000E866782A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CBsortView : public CView
{
protected: // create from serialization only
	CBsortView();
	DECLARE_DYNCREATE(CBsortView)

// Attributes
public:
	CBsortDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBsortView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	void QuickSort(int *A,int l,int r);
	void DrawBar(int index,int  *A);
	void Redraw(void);
	virtual ~CBsortView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CBsortView)
	afx_msg void OnBsort();
	afx_msg void OnRedraw();
	afx_msg void OnNewbar();
	afx_msg void OnShua();
	afx_msg void OnQuickSort();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in bsortView.cpp
inline CBsortDoc* CBsortView::GetDocument()
   { return (CBsortDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BSORTVIEW_H__62E69812_333A_11D3_A76B_0000E866782A__INCLUDED_)
