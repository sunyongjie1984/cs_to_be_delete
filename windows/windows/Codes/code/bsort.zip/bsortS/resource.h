//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by bsort.rc
//
#define IDD_ABOUTBOX                    100
#define ID_NEWBAR                       101
#define IDR_MAINFRAME                   128
#define IDR_BSORTTYPE                   129
#define IDD_SET_DIALOG                  130
#define IDD_BAR_DIALOG                  131
#define IDI_ICON_ORBIT                  133
#define IDC_LIST2                       1001
#define IDC_APPLY_BUTTON                1002
#define IDC_OK_BUTTON                   1003
#define IDC_EDIT                        1005
#define IDC_NUM                         1006
#define IDC_BEFORE_EDIT                 1007
#define IDC_AFTER_EDIT                  1008
#define IDC_BUTTON1                     1011
#define IDC_BUTTON2                     1012
#define ID_BSORT                        32772
#define ID_REDRAW                       32773
#define ID_SHUA                         32775
#define ID_SET                          32776
#define ID_QUICK_SORT                   32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
