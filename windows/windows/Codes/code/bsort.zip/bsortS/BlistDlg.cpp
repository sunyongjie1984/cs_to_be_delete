// BlistDlg.cpp : implementation file
//

#include "stdafx.h"
#include "bsort.h"
#include "BlistDlg.h"
#include "bsortdoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBlistDlg dialog


CBlistDlg::CBlistDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBlistDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBlistDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CBlistDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBlistDlg)
	DDX_Control(pDX, IDC_EDIT, m_cAi);
	DDX_Control(pDX, IDC_LIST2, m_cA);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBlistDlg, CDialog)
	//{{AFX_MSG_MAP(CBlistDlg)
	ON_LBN_SELCHANGE(IDC_LIST2, OnSelchangeList2)
	ON_EN_CHANGE(IDC_EDIT, OnChangeEdit)
	ON_BN_CLICKED(IDC_OK_BUTTON, OnOkButton)
	ON_BN_CLICKED(IDC_APPLY_BUTTON, OnApplyButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBlistDlg message handlers

void CBlistDlg::OnSelchangeList2() 
{
	// TODO: Add your control notification handler code here
	CString editstr,temp;
	LastSel = m_cA.GetCurSel();
	m_cA.GetText(LastSel, editstr);
	int sel=editstr.Find('>');
	temp=editstr.Right(editstr.GetLength()-sel-1);
	m_cAi.SetWindowText(temp);//editstr);
}

void CBlistDlg::OnChangeEdit() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	CString editstr,temp,ty;
	m_cAi.GetWindowText(editstr);
	m_cA.GetText(LastSel, ty);
	m_cA.DeleteString(LastSel);
	int sel=ty.Find('>');
	temp=ty.Left(sel+1);
	temp+=editstr;
	m_cA.InsertString(LastSel, temp);//editstr);
	m_cA.SetCurSel(LastSel);
}

void CBlistDlg::OnOkButton() 
{
	// TODO: Add your control notification handler code here
	OnApplyButton();
	CDialog::OnOK();
}

void CBlistDlg::OnApplyButton() 
{
	// TODO: Add your control notification handler code here
	CString item,dd;
	char *tail;
	int sel;
	for( int i = 0; i < ((CBsortDoc *)pDoc)->barnum; i ++ ) {
		m_cA.GetText(i, item);
		sel=item.Find('>');
		dd=item.Right(item.GetLength()-sel-1);
		A[i] = strtol(dd, &tail, 10);
	}
	for( i = 0; i < ((CBsortDoc *)pDoc)->barnum; i ++ ) {
		if(IsSame(A,A[i],i))
		{
			MessageBox("�������ظ���",NULL,MB_OK|MB_ICONWARNING);
			return;
		}
	}
	pDoc->UpdateAllViews(NULL);
}

BOOL CBlistDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	SetIcon(AfxGetApp()->LoadIcon(IDR_MAINFRAME),TRUE);//FALSE);
	// TODO: Add extra initialization here
	CString szText;
	for( int i = 0; i < ((CBsortDoc *)pDoc)->barnum; i ++ )
	{
		szText.Format("%d->%d",i,A[i]);
		m_cA.AddString(szText);
	}
	LastSel = 0;
	m_cA.SetCurSel(LastSel);
	OnSelchangeList2();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CBlistDlg::IsSame(int * A, int n, int index)
{
	for( int i = 0; i<index; i++ )
		if(A[i]==n)
			return TRUE;
	return FALSE;
}
