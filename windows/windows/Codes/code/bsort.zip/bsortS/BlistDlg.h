#if !defined(AFX_BLISTDLG_H__FA8402C4_336A_11D3_A76C_0000E866782A__INCLUDED_)
#define AFX_BLISTDLG_H__FA8402C4_336A_11D3_A76C_0000E866782A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// BlistDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBlistDlg dialog

class CBlistDlg : public CDialog
{
// Construction
public:
	BOOL IsSame(int *A,int n,int index);
	CBlistDlg(CWnd* pParent = NULL);   // standard constructor
//	~CBlistDlg();
// Dialog Data
	//{{AFX_DATA(CBlistDlg)
	enum { IDD = IDD_SET_DIALOG };
	CEdit	m_cAi;
	CListBox	m_cA;
	//}}AFX_DATA
	int LastSel;
    int *A;
    CDocument *pDoc;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBlistDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBlistDlg)
	afx_msg void OnSelchangeList2();
	afx_msg void OnChangeEdit();
	afx_msg void OnOkButton();
	afx_msg void OnApplyButton();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BLISTDLG_H__FA8402C4_336A_11D3_A76C_0000E866782A__INCLUDED_)
