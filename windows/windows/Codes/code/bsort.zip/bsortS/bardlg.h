#if !defined(AFX_BARDLG_H__40628CD4_3403_11D3_A76D_0000E866782A__INCLUDED_)
#define AFX_BARDLG_H__40628CD4_3403_11D3_A76D_0000E866782A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// bardlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// bardlg dialog

class bardlg : public CDialog
{
// Construction
public:
	bardlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(bardlg)
	enum { IDD = IDD_BAR_DIALOG };
	CStatic	m_num;
	CEdit	m_after;
	CEdit	m_before;
	int a;
	int index;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(bardlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(bardlg)
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BARDLG_H__40628CD4_3403_11D3_A76D_0000E866782A__INCLUDED_)
