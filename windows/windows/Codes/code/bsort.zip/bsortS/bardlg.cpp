// bardlg.cpp : implementation file
//

#include "stdafx.h"
#include "bsort.h"
#include "bardlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// bardlg dialog


bardlg::bardlg(CWnd* pParent /*=NULL*/)
	: CDialog(bardlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(bardlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void bardlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(bardlg)
	DDX_Control(pDX, IDC_NUM, m_num);
	DDX_Control(pDX, IDC_AFTER_EDIT, m_after);
	DDX_Control(pDX, IDC_BEFORE_EDIT, m_before);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(bardlg, CDialog)
	//{{AFX_MSG_MAP(bardlg)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// bardlg message handlers

void bardlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	CString sztt;
	char *tail;
	m_after.GetWindowText(sztt);
	if(!sztt.IsEmpty())
		a=strtol(sztt, &tail, 10);
	OnOK();
}

void bardlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	OnCancel();
}

BOOL bardlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	SetIcon(AfxGetApp()->LoadIcon(IDR_MAINFRAME),TRUE);//FALSE);
	// TODO: Add extra initialization here
	CString szIndex,szData;
	szIndex.Format("������ţ�%d",index);
	m_num.SetWindowText(szIndex);
	szData.Format("%d",a);
	m_before.SetWindowText(szData);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
