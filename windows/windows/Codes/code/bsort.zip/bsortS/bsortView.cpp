// bsortView.cpp : implementation of the CBsortView class
//

#include "stdafx.h"
#include "bsort.h"

#include "bsortDoc.h"
#include "bsortView.h"
#include "bardlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBsortView

IMPLEMENT_DYNCREATE(CBsortView, CView)

BEGIN_MESSAGE_MAP(CBsortView, CView)
	//{{AFX_MSG_MAP(CBsortView)
	ON_COMMAND(ID_BSORT, OnBsort)
	ON_COMMAND(ID_REDRAW, OnRedraw)
	ON_COMMAND(ID_NEWBAR, OnNewbar)
	ON_COMMAND(ID_SHUA, OnShua)
	ON_COMMAND(ID_QUICK_SORT, OnQuickSort)
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBsortView construction/destruction

CBsortView::CBsortView()
{
	// TODO: add construction code here

}

CBsortView::~CBsortView()
{
}

BOOL CBsortView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CBsortView drawing

void CBsortView::OnDraw(CDC* pDC)
{
	CBsortDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	int *A = pDoc->A;
	CString sznum;
	CRect extent;
	GetClientRect(&extent);
	extent.DeflateRect(10,10);
	int barhei = extent.Height() / (2*pDoc->barnum);
	int barinc = extent.Height() / pDoc->barnum;
	int winc = extent.Width() / 20;
	extent.left+=20;
	CRect rect = extent;
	for( int i = 0; i<pDoc->barnum; i++ ) {
		rect.top = extent.top + i * barinc;
		rect.bottom = rect.top + barhei;
		rect.right = rect.left + A[i] * winc;
		CBrush brush;
		brush.CreateSolidBrush(RGB(rand()%255,rand()%255,rand()%255));//PALETTEINDEX(A[i]));
		CBrush *oldbrush = pDC->SelectObject(&brush);
		sznum.Format("%2d",i);
		pDC->TextOut(0,rect.top,sznum);
		pDC->Rectangle(rect);
		pDC->SelectObject(oldbrush);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CBsortView printing

BOOL CBsortView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CBsortView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CBsortView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CBsortView diagnostics

#ifdef _DEBUG
void CBsortView::AssertValid() const
{
	CView::AssertValid();
}

void CBsortView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CBsortDoc* CBsortView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CBsortDoc)));
	return (CBsortDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBsortView message handlers

void CBsortView::OnBsort() 
{
	// TODO: Add your command handler code here
	CBsortDoc* pDoc = GetDocument();
	int i, j, flag, *A = pDoc->A, B;
	for( i = 1; i < pDoc->barnum; i ++ ) {
		flag = 0;
		for( j = 0; j < pDoc->barnum-i; j ++ ) {
			if( A[j] > A[j+1] ) {
				flag = 1;
				B = A[j], A[j] = A[j+1], A[j+1] = B;
			}
		}
		if( flag = 0 ) break;
	}
	pDoc->UpdateAllViews(0);//this);
}

void CBsortView::OnRedraw() 
{
	// TODO: Add your command handler code here
	CBsortDoc* pDoc = GetDocument();
	CWaitCursor wait;
	int i, j, flag, *A = pDoc->A, B;
	for( i = 1; i < pDoc->barnum; i ++ ) {
		flag = 0;
		for( j = 0; j < pDoc->barnum-i; j ++ ) {
			if( A[j] > A[j+1] ) {
				flag = 1;
				B = A[j], A[j] = A[j+1], A[j+1] = B;
				Redraw();
				for( int k = 0; k < 5000000; k ++ ) ;
			}
		}
		if( flag = 0 ) break;
	}
	pDoc->UpdateAllViews(this);
}

void CBsortView::Redraw()
{
		CDC *pDC = GetDC();
		CRect extent;
		GetClientRect(&extent);
		CBrush brush;
		brush.CreateSolidBrush(RGB(255,255,255));
		CBrush *oldbrush = pDC->SelectObject(&brush);
		pDC->Rectangle(extent);
		pDC->SelectObject(oldbrush);
		OnDraw(pDC);
		ReleaseDC(pDC);

}

void CBsortView::OnNewbar() 
{
	// TODO: Add your command handler code here
	
}

void CBsortView::OnShua() 
{
	// TODO: Add your command handler code here
	CBsortDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CWaitCursor wait;
	int *A = pDoc->A;
	for( int i=1; i<pDoc->barnum; i++ )
		DrawBar(i, A);
}

void CBsortView::DrawBar(int index, int *A)
{
	CBsortDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CClientDC dc(this);
	int B;
	CString szText,sznum1,sznum2;
	CRect extent;
	GetClientRect(&extent);
	extent.DeflateRect(10,10);
	int barhei = extent.Height() / (2*pDoc->barnum);
	int barinc = extent.Height() / pDoc->barnum;
	int winc = extent.Width() / 20;
	extent.left+=20;
	CRect rect = extent;
	int flag = 0;
	for( int j = 0; j < pDoc->barnum-index; j ++ ) {
		if( A[j] > A[j+1] ) {
			flag = 1;
			rect.top = extent.top + j * barinc;
			rect.bottom = rect.top + barhei;
			rect.right = rect.left + A[j] * winc;
			dc.FillSolidRect(&rect,RGB(255,255,255));

			rect.right = rect.left + A[j+1] * winc;
			CBrush brush2;
			brush2.CreateSolidBrush(RGB(rand()%255,rand()%255,rand()%255));//PALETTEINDEX(A[i]));
			CBrush *oldbrush = dc.SelectObject(&brush2);
			sznum1.Format("%2d",j+1);
			dc.TextOut(0,rect.top,sznum1);
			dc.Rectangle(rect);
			dc.SelectObject(oldbrush);
			rect.top = extent.top + (j+1) * barinc;
			rect.bottom = rect.top + barhei;
			rect.right = rect.left + A[j+1] * winc;
			dc.FillSolidRect(&rect,RGB(255,255,255));

			rect.right = rect.left + A[j] * winc;
			CBrush brush4;
			brush4.CreateSolidBrush(RGB(rand()%255,rand()%255,rand()%255));//PALETTEINDEX(A[i]));
			oldbrush = dc.SelectObject(&brush4);
			sznum2.Format("%2d",j);
			dc.TextOut(0,rect.top,sznum2);
			dc.Rectangle(rect);
			dc.SelectObject(oldbrush);
			B = A[j], A[j] = A[j+1], A[j+1] = B;
			szText.Format("����%d<->%d      ",j,j+1);
			dc.TextOut(extent.right-100,10,szText);
			for( int k = 0; k < 5000000; k ++ ) ;
		}
	if( flag = 0 ) return;
	}
}

void CBsortView::QuickSort(int * A, int l, int r)
{
	int i,j;
	int swap;
	i = l;
	j = r;
	swap = A[l];//A[r]
	while(i < j)
	{
		while(i < j && swap < A[j]) j--;
		if(i < j)
		{
			A[i] = A[j];
			i++;
		}
		while(i < j && A[i] < swap) i++;
		if(i < j)
		{
			A[j] = A[i];
			j--;
		}
	}
	A[i] = swap;
	if(l < i - 1) QuickSort(A,l,i - 1);
	if(j + 1 < r) QuickSort(A,j + 1,r);
}



void CBsortView::OnQuickSort() 
{
	// TODO: Add your command handler code here
	CBsortDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	QuickSort(pDoc->A,0,pDoc->barnum-1);
	CDC *pDC = GetDC();
	CRect extent;
	GetClientRect(&extent);
	CBrush brush;
	brush.CreateSolidBrush(RGB(255,255,255));
	CBrush *oldbrush = pDC->SelectObject(&brush);
	pDC->Rectangle(extent);
	pDC->SelectObject(oldbrush);
	OnDraw(pDC);
	ReleaseDC(pDC);	
}

void CBsortView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CBsortDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	int *A;
	BOOL flag=FALSE;
	CRect extent;
	GetClientRect(&extent);
	extent.DeflateRect(10,10);
	A=pDoc->A;
	int barhei = extent.Height() / (2*pDoc->barnum);
	int barinc = extent.Height() / pDoc->barnum;
	int winc = extent.Width() / 20;
	extent.left+=20;
	CRect rect = extent;
	for( int j = 0; j < pDoc->barnum; j ++ ) {
			rect.top = extent.top + j * barinc;
			rect.bottom = rect.top + barhei;
			rect.right = rect.left + A[j] * winc;
			if(rect.PtInRect(point)) 
			{
				flag=TRUE;
				break;
			}
	}
	if(flag)
	{
		bardlg dlg;
		dlg.a=A[j];
		dlg.index=j;
		if(dlg.DoModal()==IDOK)
		{
			CClientDC dc(this);
			A[j]=dlg.a;
			dc.FillSolidRect(&rect,RGB(255,255,255));
			rect.right = rect.left + dlg.a * winc;
			CBrush brush;
			brush.CreateSolidBrush(RGB(rand()%255,rand()%255,rand()%255));//PALETTEINDEX(A[i]));
			CBrush *oldbrush = dc.SelectObject(&brush);
			dc.Rectangle(rect);
			dc.SelectObject(oldbrush);
		}
	}
//	CView::OnLButtonDown(nFlags, point);
}
