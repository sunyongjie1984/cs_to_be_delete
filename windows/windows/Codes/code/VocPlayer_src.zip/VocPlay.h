#ifndef _VOCPLAYER_H
#define _VOCPLAYER_H

#include <mmsystem.h>

typedef struct
{
   UCHAR       ucBitsPerSample;
   UCHAR       ucChannels;
   USHORT      usFileFormat;
   USHORT      usTimeConstant;
   long        lSamplesPerSeconds;
   long        lTotalLength;
} FILEINFO;

class CVocPlayer
{
   public:
      CVocPlayer();
      virtual ~CVocPlayer();

      void        Play( const CString &rcFileName, CWnd *pCallbackWnd );
      inline void Reset() const        { waveOutReset( hWaveOut ); }
      void        Clear();

   protected:
      char        *pData;
      bool        boPlaying;

      HWAVEOUT    hWaveOut;
      WAVEHDR     sWaveHdr;

   protected:
      void        Decode( const CString &rcFileName, FILEINFO *psFileInfo );
};

#endif               // #ifndef _VOCPLAYER_H