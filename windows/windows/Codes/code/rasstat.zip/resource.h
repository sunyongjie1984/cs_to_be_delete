//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RasStat.rc
//
#define IDC_MYICON                      2
#define IDD_RASSTAT_DIALOG              102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_RASSTAT                     107
#define IDI_SMALL                       108
#define IDC_RASSTAT                     109
#define IDR_MAINFRAME                   128
#define IDI_CON                         129
#define IDI_NO_CONN                     129
#define IDI_NO_CON                      130
#define IDI_CONN                        130
#define IDS_RC_OPENPORT                 200
#define IDS_RC_PORTOPENED               201
#define IDS_RC_CONNDEV                  202
#define IDS_RC_DEVCONN                  203
#define IDS_RC_ALLDEVCONN               204
#define IDS_RC_AUTH                     205
#define IDS_RC_AUTHNOT                  206
#define IDS_RC_AUTHRETRY                207
#define IDS_RC_CALLBACK                 208
#define IDS_RC_AUTHCHANGEPASS           209
#define IDS_RC_AUTHPROJECT              210
#define IDS_RC_AUTHLINKSPEED            211
#define IDS_RC_AUTHACK                  212
#define IDS_RC_REAUTHACK                213
#define IDS_RC_AUTH_COMPLETE            214
#define IDS_RC_PREPARECALLBACK          215
#define IDS_RC_WAITMODEM                216
#define IDS_RC_WAITCALLBACK             217
#define IDS_RC_PROJECT                  218
#define IDS_RC_STARTAUTH                219
#define IDS_RC_CALLDONE                 220
#define IDS_RC_LOGON                    221
#define IDS_RC_SUBENTRYCONN             222
#define IDS_RC_SUBENTRYDISCONN          223
#define IDD_RASSTAT                     2300
#define IDS_RC_INTERACT                 4096
#define IDS_RC_RETRYAUTH                4097
#define IDS_RC_CALLBACK_SET             4098
#define IDS_RC_PASSWORDEXP              4099
#define IDS_RC_INVOKEEAP                4100
#define IDC_HIDE                        5001
#define IDC_PHONE_LIST                  5002
#define IDC_LIST_STAT                   5004
#define IDS_RC_CONNECTED                8392
#define IDS_RC_DISCONN                  8393
#define IDC_FIRST_ENTRY                 20000
#define ID_HANGUP                       32772
#define ID_ABOUT                        32773
#define ID_RAS_MON_DLG                  32775
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2301
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         5005
#define _APS_NEXT_SYMED_VALUE           2300
#endif
#endif
