#include <windows.h>
#include <tchar.h>
#include <shellapi.h>
#include <ras.h>
#include <raserror.h>
#include <assert.h>
#include "resource.h"
#define WM_SYSTRAY_NOTIFY  WM_USER+0
#define WM_CONNECT_CHANGE  WM_USER+1

// Global Variables:
HINSTANCE g_hInst = NULL;
HANDLE g_thread = NULL;
NOTIFYICONDATA g_nid = { 0 };
HICON     g_hIcons[2];
HMENU     g_hMenu,g_hSubMenu,g_hDialMenu;
RASENTRYNAME *g_pRasEntry = NULL;
DWORD g_dwPhoneBkCnt = 0;
HWND  g_hWnd = 0;
HANDLE g_hEvt[2];
#define MAX_USERNAME_CNT    16
char g_pUserName[MAX_USERNAME_CNT+1];
char g_pPassword[MAX_USERNAME_CNT+1];
// Function declarations
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
void TaskBarIconAdd(HICON hIcon,LPCTSTR pTT);
void UpdateRasStats();
void Dial(RASENTRYNAME *pEntry);
void Hangup();
void DisplayError(DWORD);
void ParseCmdLine(LPSTR);

int APIENTRY WinMain(HINSTANCE hInst,HINSTANCE hPrevInst,
                     LPSTR lpCmdLine,int nCmdShow) {
    MSG msg; DWORD dw;
    
    if ((g_hWnd = CreateDialog(hInst, (LPCTSTR)IDD_RASSTAT,
                                NULL, (DLGPROC)WndProc))) {
        ShowWindow(g_hWnd, SW_HIDE);

        // get username and password from command line
        memset(g_pUserName,'\0',MAX_USERNAME_CNT+1);
        memset(g_pPassword,'\0',MAX_USERNAME_CNT+1);
        ParseCmdLine(lpCmdLine);

        // Init NotifyIconData for task bar icon.
        g_nid.cbSize = sizeof(NOTIFYICONDATA);
        g_nid.hWnd = g_hWnd;
        g_nid.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE;
        g_nid.uID = IDC_RASSTAT;
	    g_nid.uCallbackMessage = WM_SYSTRAY_NOTIFY;
        g_hIcons[0] = 
            LoadIcon(hInst,MAKEINTRESOURCE(IDI_NO_CONN));
        g_hIcons[1] = 
            LoadIcon(hInst,MAKEINTRESOURCE(IDI_CONN));
        g_hMenu = LoadMenu(hInst,MAKEINTRESOURCE(IDC_RASSTAT));
        g_hSubMenu = GetSubMenu(g_hMenu,0);
        g_hDialMenu = GetSubMenu(g_hSubMenu,0);
        
        // Add Initial Icon to task bar.
        TaskBarIconAdd(g_hIcons[0],_T("undefined"));
        UpdateRasStats();
        
        InitInstance(hInst,nCmdShow);
        while (GetMessage(&msg, NULL, 0, 0))  {
    		if (!IsDialogMessage(g_hWnd, &msg)) {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
        }
        
        // Signal the thread to terminate.
        SetEvent(g_hEvt[1]);    
        dw = WaitForSingleObject(g_thread,1000);
        assert(WAIT_OBJECT_0 == dw);

        // remove the icon from the system tray.
        Shell_NotifyIcon(NIM_DELETE,&g_nid);
        
        // free the phone entries
        free(g_pRasEntry);          
        
        // free the icons.
        DestroyIcon(g_hIcons[0]);   
        DestroyIcon(g_hIcons[1]);

        // free the event handles.
        CloseHandle(g_hEvt[0]);     
        CloseHandle(g_hEvt[1]);
        
        // close the thread
        CloseHandle(g_thread);      
        return msg.wParam;
    }
    return FALSE;
}
//---------------------------------------------------------------
// MonStateThrd
//
// thread call back function to monitor 
// the state of the ras connection.
//---------------------------------------------------------------
DWORD WINAPI MonStateThrd(  LPVOID lpParameter) {
    DWORD dw;

    // create two events.  One to monitor the ras connection
    // and another to signal the thread to terminate.
    g_hEvt[0] = CreateEvent(NULL,TRUE,FALSE,"MyRasNotEvt");
    g_hEvt[1] = CreateEvent(NULL,TRUE,FALSE,"MyRasTermEvt");

    // setup ras connection to set the event when the 
    // connection terminates.
    dw = RasConnectionNotification(NULL,g_hEvt[0]
                    ,RASCN_Disconnection | RASCN_Connection);
    if (dw != 0) 
        DisplayError(dw);
    else {
        // loop until the terminate event is signaled
        for (;;) {
            // wait for one of the events to signal.
            dw = WaitForMultipleObjects(2,g_hEvt,FALSE,-1);
            dw -= WAIT_OBJECT_0;
            assert(dw >= 0 && dw <= 1); 
            if (0 == dw) {
                // the ras event has been signaled.  The
                // connection state has changed. Send a 
                // message back to the main wnd.
                PostMessage(g_hWnd,WM_CONNECT_CHANGE,0,0);
                ResetEvent(g_hEvt[0]);
            } 
            else {
                // terminate event has been signaled, bail 
                break;  
            }
        }
    }
    return 0;
}
//---------------------------------------------------------------
// InitInstance
//
// generic initialize rtn.
//---------------------------------------------------------------
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)  {
    RASENTRYNAME r;
    DWORD dwSize, i;
    
    // get a count of the number of phone book
    // entries and malloc an array to hold
    // each entry.
    dwSize = r.dwSize = sizeof(RASENTRYNAME);
    RasEnumEntries(NULL,NULL,&r,&dwSize,&g_dwPhoneBkCnt);
    g_thread = CreateThread(NULL,0,MonStateThrd,g_hWnd,0,NULL);
    g_hInst = hInstance;
    g_pRasEntry = (RASENTRYNAME *)malloc(sizeof(RASENTRYNAME) 
                                    * g_dwPhoneBkCnt);
    g_pRasEntry->dwSize = sizeof(RASENTRYNAME);
    dwSize = r.dwSize = sizeof(RASENTRYNAME);

    dwSize = sizeof(RASENTRYNAME) * g_dwPhoneBkCnt;
    RasEnumEntries(NULL,NULL,g_pRasEntry,&dwSize
                ,&g_dwPhoneBkCnt);
    // add each phone entry into the submenu.
    for(i = 0;i < g_dwPhoneBkCnt;i++) 
        AppendMenu(g_hDialMenu,MF_STRING,IDC_FIRST_ENTRY+i,
            (g_pRasEntry + i)->szEntryName);
    
    DeleteMenu(g_hDialMenu,0,MF_BYPOSITION);
    return TRUE;
}
//---------------------------------------------------------------
// ParseCmdLine
//
// parse the username and password from the command line.
//---------------------------------------------------------------
void ParseCmdLine(LPSTR lpCmdLine)
{
    LPSTR pNext = strtok(lpCmdLine,"-/");
    while (pNext) {
        if ('u' == *pNext || 'U' == *pNext) {
            pNext++;
            strncpy(g_pUserName,pNext,MAX_USERNAME_CNT);
        }
        else if ('p' == *pNext || 'P' == *pNext) {
            pNext++;
            strncpy(g_pPassword,pNext,MAX_USERNAME_CNT);
        }
        pNext = strtok(NULL,"-");
    }
}
//---------------------------------------------------------------
// WndProc
//
// window procedure for rasstat
//---------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg
                         , WPARAM wParam, LPARAM lParam) {
	UINT wmId;
    POINT pt;
	switch (msg) {
        case WM_CLOSE: 
            PostQuitMessage(1);
            break;
        case WM_SYSTRAY_NOTIFY:
            // if right click on the taskbar icon
            // then open popup menu.
            if (IDC_RASSTAT == wParam && 
                WM_RBUTTONDOWN == lParam) {
		            GetCursorPos(&pt);
		            SetForegroundWindow(g_nid.hWnd);	
		            TrackPopupMenu(g_hSubMenu,0,pt.x,
			            pt.y,0,g_nid.hWnd, NULL);
                }
            break;
        case WM_COMMAND:
			wmId    = LOWORD(wParam); 
            if (wmId >= IDC_FIRST_ENTRY && wmId <= 
                    (IDC_FIRST_ENTRY + g_dwPhoneBkCnt))
                // dial a phone book entry.
                Dial(g_pRasEntry+(wmId - IDC_FIRST_ENTRY));
            else { 
                switch (wmId)  {
                    case ID_HANGUP:
                        Hangup();
                        break;
			        case IDM_EXIT:
			           DestroyWindow(hWnd);
			           break;
                    case IDC_HIDE:
                        ShowWindow(g_hWnd,SW_HIDE);
                        break;
			        default:
			           return DefWindowProc(hWnd,msg,wParam,
                                                     lParam);
			        }
            }
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
        case WM_CONNECT_CHANGE:
            // message from monitor thread, the connection state
            // has changed, update the taskbar icon.
            UpdateRasStats();   
            break;
   }
   return FALSE;
}
//---------------------------------------------------------------
// TaskBarIconAdd
//
// add the icon to the task bar.
//---------------------------------------------------------------
void TaskBarIconAdd(HICON hIcon,LPCTSTR pTT)  {
	g_nid.hIcon = hIcon;            // add in the new icon
	strncpy(g_nid.szTip,pTT,63);    // add in the new tooltip.
	Shell_NotifyIcon(NIM_ADD,&g_nid);
}
//---------------------------------------------------------------
// TaskBarIconModify
//
// change the taskbar icon.
//---------------------------------------------------------------
void TaskBarIconModify(HICON hIcon,LPCTSTR pTT) {
	g_nid.hIcon = hIcon;                // change the taskbar icon
	strncpy(g_nid.szTip,pTT,63);        // update the tooltip.
	Shell_NotifyIcon(NIM_MODIFY,&g_nid);
}
//---------------------------------------------------------------
// UpdateRasStats
//
// determine if a connection is active and
// set the task bar icon accordingly.
//---------------------------------------------------------------
void UpdateRasStats() {
DWORD dw = 0,nBufferSize = sizeof(RASCONN) * 4,w = 0;
    RASCONN pRasConn[4];
    memset(pRasConn,'\0',sizeof(RASCONN)*4);
    pRasConn->dwSize = sizeof(RASCONN);
    w = RasEnumConnections(pRasConn, &nBufferSize, &dw);
    if (w != 0) 
        DisplayError(w);
    else if (dw > 0) {
        // new active connection.  set the connection name to
        // the tooltip and update the icon to the green light
        TaskBarIconModify(g_hIcons[1],pRasConn->szEntryName);
    } else {
        // no active connections.  Set the icon to the
        // red light and set the tooltip to no connection.
        TaskBarIconModify(g_hIcons[0],_T("No Connection"));
    }
}
//---------------------------------------------------------------
// Hangup
//
// terminate the connection.
//---------------------------------------------------------------
void Hangup() {
    
    // note, we're hard coded to a max of 4 connections if you
    // have more then 4 active connections, update the array.
    RASCONN pRasConn[4];
    DWORD dw = 0,nBufferSize = sizeof(RASCONN) * 4,dwRet;
    pRasConn->dwSize = sizeof(RASCONN);
    // check if there is an active connection first.
    dwRet = RasEnumConnections(pRasConn, &nBufferSize, &dw);
    if (dwRet != 0) 
        DisplayError(dwRet);
    else
        // hangup each active connection.
        while(dw > 0) {
            dwRet = RasHangUp(pRasConn[--dw].hrasconn);
            if (dwRet != 0) 
                DisplayError(dwRet);
            // sleep 3 seconds to give the modem time
            // to respond.
            Sleep(3000);
        }   
}
//---------------------------------------------------------------
// RasDialFunc
//
// call back function for the rasdial.  As the 
// connection state changes during dialing, this
// function is called.
//---------------------------------------------------------------
void CALLBACK RasDialFunc(HRASCONN hrasconn, UINT unMsg, 
              RASCONNSTATE rcs, DWORD dwEr, DWORD dwExErr) {
    char buf[50]; HWND hWndStat;

    // all the various ras states are loaded as string
    // resources.  Get the description of the code
    // and update the dialog list box.
    LoadString(g_hInst,(((UINT)rcs) + 200),buf,49);
    hWndStat = GetDlgItem(g_hWnd,IDC_LIST_STAT);
    SendMessage(hWndStat,LB_ADDSTRING,0,(LPARAM)buf);
}
//---------------------------------------------------------------
// Dial
//
// dial a phone book entry.
//---------------------------------------------------------------
void Dial(RASENTRYNAME *pEntry) {
    DWORD dw;
    RASDIALPARAMS dialParams; HRASCONN rc;
    memset((void *)&dialParams,'\0',sizeof(RASDIALPARAMS));
    ShowWindow(g_hWnd,SW_SHOW);
    
    // Init rasdialprams structure.
    dialParams.dwSize = sizeof(RASDIALPARAMS);
	strcpy(dialParams.szEntryName, pEntry->szEntryName);

    // username and password where passed in on the cmd line
    strcpy(dialParams.szUserName, g_pUserName);
	strcpy(dialParams.szPassword, g_pPassword);
	dw = RasDial(NULL, NULL, &dialParams, 1,  
		(RASDIALFUNC1)RasDialFunc, &rc); 
    if (dw != 0) 
        DisplayError(dw);
}
//---------------------------------------------------------------
// DisplayError
//
// Generic error rtn
//---------------------------------------------------------------
void DisplayError(DWORD dw) {
    TCHAR szBuf[256];
    RasGetErrorString( (UINT)dw, (LPSTR)szBuf, 256 );
    MessageBox(NULL,(LPSTR)szBuf,"RasStat",MB_OK);
}   
