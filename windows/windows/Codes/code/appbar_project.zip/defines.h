#define STR_ERROR_NOT_HIDDEN    "ERROR: We're not hidden currently\r\n"
#define STR_ERROR_SET_AUTOHIDE  "ERROR: Error trying to set autohidebar.\r\n"
#define STR_ERROR_AUTOHIDE      "ERROR: Error trying to set autohidebar.\r\n"
#define STR_ZERO_DIMENSION      "Specify the size of the client area please!\r\n"