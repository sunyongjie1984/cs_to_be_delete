//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TaskBar.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TASKBAR_DIALOG              102
#define IDS_ZERO_DIMENSION              103
#define IDD_APPBAR                      103
#define IDS_ERROR_AUTOHIDE              104
#define IDS_ERROR_NOT_HIDDEN            105
#define IDS_ERROR_SET_AUTOHIDE          106
#define IDR_MAINFRAME                   128
#define IDR_EPIC_BUTTON_MENU            129
#define IDC_REGISTER                    1000
#define IDC_START                       1002
#define IDC_UNREGISTER                  1002
#define IDC_AUTOHIDE                    1003
#define IDC_ONTOP                       1004
#define ID_MENUITEM32771                32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
