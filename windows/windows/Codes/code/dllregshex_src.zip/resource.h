//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dllregshex.rc
//
#define IDB_SVCA                        101
#define IDD_NTSRVPAGE                   102
#define IDB_STARTA                      103
#define IDB_PAUSEA                      104
#define IDB_STOPA                       105
#define IDB_INSTALLA                    106
#define IDB_INSTALL                     106
#define IDB_UNINSTALLA                  107
#define IDB_UNINSTALL                   107
#define IDB_INSTALLI                    111
#define IDB_UNINSTALLI                  112
#define IDB_STARTI                      113
#define IDB_STOPI                       114
#define IDB_PAUSEI                      116
#define IDB_SVCI                        117
#define IDM_SVC                         118
#define IDD_INSTALL                     119
#define IDI_MYCOMPUTERICON              122
#define IDB_ABOUTA                      123
#define IDB_ABOUT                       123
#define IDB_ABOUTI                      124
#define IDE_DISPLAYNAME                 1025
#define IDE_SERVICENAME                 1026
#define IDLB_TYPE                       1044
#define IDE_EXECUTABLE                  1045
#define IDK_DESKTOPINTERACT             1046
#define IDRB_STARTUP_BOOT               1047
#define IDRB_STARTUP_SYSTEM             1048
#define IDRB_STARTUP_DISABLED           1049
#define IDRB_STARTUP_MANUAL             1050
#define IDRB_STARTUP_AUTOMATIC          1052
#define IDRB_ERR_IGNORE                 1053
#define IDRB_ERR_SHOWERROR              1054
#define IDRB_ERR_SEVERE                 1055
#define IDRB_ERR_CRITICAL               1057
#define IDCMD_INSTALL                   40001
#define IDCMD_UNINSTALL                 40002
#define IDCMD_START                     40003
#define IDCMD_PAUSECONTINUE             40004
#define IDCMD_STOP                      40005
#define IDS_Q_INSTALL                   40006
#define IDS_ABOUT                       40007
#define IDCMD_ABOUT                     40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        126
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
