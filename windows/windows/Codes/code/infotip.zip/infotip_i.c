/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sat Mar 06 20:24:36 1999
 */
/* Compiler settings for C:\articles\infotip\infotip.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IInfoTipImpl = {0x45E1B82D,0xD3F3,0x11D2,{0xAB,0xF7,0x8C,0xF7,0x58,0xE2,0xB4,0x5E}};


const IID LIBID_INFOTIPLib = {0x45E1B821,0xD3F3,0x11D2,{0xAB,0xF7,0x8C,0xF7,0x58,0xE2,0xB4,0x5E}};


const CLSID CLSID_InfoTipImpl = {0x45E1B82E,0xD3F3,0x11D2,{0xAB,0xF7,0x8C,0xF7,0x58,0xE2,0xB4,0x5E}};


#ifdef __cplusplus
}
#endif

