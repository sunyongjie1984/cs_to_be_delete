// InfoTipImpl.cpp : Implementation of CInfoTipImpl
#include "stdafx.h"
#include "Infotip.h"
#include "InfoTipImpl.h"

/////////////////////////////////////////////////////////////////////////////
// CInfoTipImpl

//We are not displaying any more than nMaxChar characters

const DWORD nMaxChar = 256;


STDMETHODIMP CInfoTipImpl::Load(LPCOLESTR pszFileName, DWORD dwMode)
{
	//Shell gives us a file name we need to extract
	//Info from it.

	//Store the current file name so that it can be returned in GetCurFile
	delete []m_szCurFile;
	m_szCurFile = new OLECHAR[(ocslen(pszFileName)+1)*sizeof(OLECHAR)];
	ocscpy(m_szCurFile, pszFileName);

	
	//Read and extract info from the file
	USES_CONVERSION;

	HANDLE hFile = CreateFile(OLE2CT(pszFileName),	//FileName
								GENERIC_READ, 		//Access
								FILE_SHARE_READ,	//Sharing
								NULL,				//Security
								OPEN_EXISTING,
								FILE_ATTRIBUTE_NORMAL,
								NULL);

	if (hFile == INVALID_HANDLE_VALUE)
	{
			ocscpy(m_szCurFile, L" ");
		return E_FAIL;
	}


	DWORD dwRead;

	TCHAR lpBuf[nMaxChar+1];
	
	if (!ReadFile(hFile, reinterpret_cast<LPVOID>(lpBuf), nMaxChar, &dwRead, NULL))
	{
		return E_FAIL;
	}

	lpBuf[nMaxChar] = 0;

	//Finally Close the File
	CloseHandle(hFile);

	GenerateInfoTip(lpBuf);

	return S_OK;
}

void CInfoTipImpl::GenerateInfoTip(LPCTSTR szBuf)
{	
	
	//String to hold output
	LPTSTR szOut = new TCHAR[nMaxChar+1];
	//For iterating
	LPTSTR szOutI = szOut;

	//check if the file begins with C++ style comments //
	if (szBuf[0] == '/' && szBuf[1] == '/')
	{
		//display the first line
		LPCTSTR szI = szBuf + 2;

		while (*szI > 31)
		{
			*szOutI++ = *szI++;
		}

		*szOutI++ = 0;
	}
	else 
	{
		if (szBuf[0]== '/' && szBuf[1] == '*')
		{
			//display the first line
			LPCTSTR szI = szBuf + 2;

			while (*szI && !((*(szI + 1) == '*') && (*(szI + 2) == '/')) )
			{
				*szOutI++ = *szI++;
			}

			*szOutI++ = 0;
		}
		else
			*szOutI++ = '\0';
	}
	
	
	//First free the existing buffer
	
	delete[]m_szInfoTip;
	
	m_szInfoTip = new OLECHAR[(szOutI - szOut)*sizeof(OLECHAR)];

	USES_CONVERSION;
	ocscpy(m_szInfoTip, T2OLE(szOut));
	//Free the output buffer
	delete []szOut;
}
