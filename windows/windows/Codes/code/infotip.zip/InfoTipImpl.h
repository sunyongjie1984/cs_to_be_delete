// InfoTipImpl.h : Declaration of the CInfoTipImpl

#ifndef __INFOTIPIMPL_H_
#define __INFOTIPIMPL_H_

#include "resource.h"       // main symbols
#include <shlobj.h>         //For IQueryInfo
/////////////////////////////////////////////////////////////////////////////
// CInfoTipImpl
class ATL_NO_VTABLE CInfoTipImpl : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CInfoTipImpl, &CLSID_InfoTipImpl>,
	public IQueryInfo,
	public IPersistFile
{
public:
	CInfoTipImpl()
	{
		m_szInfoTip = NULL;
		m_szCurFile = NULL;
	}

	~CInfoTipImpl()
	{
		delete []m_szInfoTip;
		delete []m_szCurFile;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_INFOTIPIMPL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CInfoTipImpl)
	COM_INTERFACE_ENTRY(IPersistFile)
	COM_INTERFACE_ENTRY_IID(IID_IQueryInfo, IQueryInfo)
END_COM_MAP()

public:

	//IPersist Methods
	//Copied from default ATL implementation from IPersistImpl
	STDMETHOD(GetClassID)(CLSID *pClassID)
	{
		ATLTRACE2(atlTraceCOM, 0, _T("IPersistImpl::GetClassID\n"));
		if (pClassID == NULL)
			return E_FAIL;
		*pClassID = GetObjectCLSID();
		return S_OK;
	}


	//IPersistFile Methods
	STDMETHOD(IsDirty)()
	{
		return S_FALSE;
	}

	STDMETHOD(Load)(LPCOLESTR pszFileName, DWORD dwMode);
	
	STDMETHOD(Save)(LPCOLESTR pszFileName, BOOL fMember)
	{
		return E_NOTIMPL;		
	}

	STDMETHOD(SaveCompleted)(LPCOLESTR)
	{
		return E_NOTIMPL;
	}
	
	STDMETHOD(GetCurFile)(LPOLESTR *ppszFileName)
	{
		//Find the string length of the current file
		size_t cbSize = (ocslen(m_szCurFile)+ 1);

		//Now allocate buffer for returning the filename
		CComPtr<IMalloc> spMalloc;

		SHGetMalloc(&spMalloc);
		
		*ppszFileName = (LPOLESTR) spMalloc->Alloc(cbSize*sizeof(OLECHAR));
		
		if (!*ppszFileName)
		{
			return E_OUTOFMEMORY;
		}

		ocscpy(*ppszFileName, m_szCurFile);

		return S_OK;  
	}

	//IQueryInfo Methods
	STDMETHOD(GetInfoTip)( DWORD dwFlags, WCHAR **ppwszTip)
	{
		CComPtr<IMalloc> spMalloc;
		
		SHGetMalloc(&spMalloc);

		*ppwszTip = (LPOLESTR) spMalloc->Alloc(	(ocslen(m_szInfoTip) + 1)*sizeof(OLECHAR));

		if (!*ppwszTip)
		{
			return E_OUTOFMEMORY;
		}
		
		ocscpy(*ppwszTip, m_szInfoTip);
		return S_OK;
	}

	STDMETHOD(GetInfoFlags)( DWORD *pdwFlags) 
	{
		
		return S_OK;
	}


private:
	OLECHAR* m_szCurFile;
	OLECHAR* m_szInfoTip;
protected:
	void GenerateInfoTip(LPCTSTR lpBuf);
};

#endif //__INFOTIPIMPL_H_
