//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by freepy.rc
//
#define FREEPYIMEICON                   101
#define INDICOPENICON                   102
#define STATUSBITMAP                    103
#define FREEPYMENU                      105
#define DIALOGABOUT                     106
#define DIALOGSET                       107
#define DIALOGCONFIG                    108
#define IDC_CHECKSORT                   1003
#define IDC_CHECKFUZZYC                 1004
#define IDC_CHECKFUZZYH                 1005
#define IDC_CHECKFUZZYN                 1007
#define CONFIGFUZZYC                    1008
#define CONFIGFUZZYN                    1009
#define CONFIGFUZZYH                    1010
#define CONFIGSORT                      1011
#define CONFIGFULLSHAPE                 1012
#define CONFIGPUNCT                     1013
#define CONFIGFUZZYB                    1014
#define IDC_CHECKFUZZYB                 1015
#define CONFIGFOLLOW                    1016
#define CONFIGGBK                       1017
#define IDC_CHECKFOLLOW                 1018
#define IDC_CHECKGBK                    1019
#define IDC_CHECKSHAPE                  1020
#define CONFIGSHAPE                     1021
#define IDM_SET                         40001
#define IDM_HELP                        40003
#define IDM_ABOUT                       40005
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
