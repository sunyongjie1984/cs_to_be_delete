// VersionDemoDlg.h : header file
//

#if !defined(AFX_VERSIONDEMODLG_H__2636C409_E075_11D2_8500_00801E035520__INCLUDED_)
#define AFX_VERSIONDEMODLG_H__2636C409_E075_11D2_8500_00801E035520__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CVersionDemoDlg dialog

class CVersionDemoDlg : public CDialog
{
// Construction
public:
	CVersionDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CVersionDemoDlg)
	enum { IDD = IDD_VERSIONDEMO_DIALOG };
	CString	m_strCompany;
	CString	m_strComment;
	CString	m_strCopy;
	CString	m_strFileDescr;
	CString	m_strFileVer;
	CString	m_strIntName;
	CString	m_strPrivBuild;
	CString	m_strProductName;
	CString	m_strProductVer;
	CString	m_strSpecialBuild;
	CString	m_strTrademarks;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVersionDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CVersionDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VERSIONDEMODLG_H__2636C409_E075_11D2_8500_00801E035520__INCLUDED_)
