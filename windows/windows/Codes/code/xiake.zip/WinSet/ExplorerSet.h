#if !defined(AFX_EXPLORERSET_H__C62226F3_5FD7_11D2_8573_ECD904C10000__INCLUDED_)
#define AFX_EXPLORERSET_H__C62226F3_5FD7_11D2_8573_ECD904C10000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ExplorerSet.h : �ҵĵ�������
//
#include <afxtempl.h>
/////////////////////////////////////////////////////////////////////////////
// CExplorerSet dialog
typedef struct AutoRun
{
	int Drive;
	int IconIndex;
	CString Icon;
	CString ExeFile;
}AutorunInfo;

class CExplorerSet : public CPropertyPage
{
	DECLARE_DYNCREATE(CExplorerSet)

// Construction
public:
	CExplorerSet();
	~CExplorerSet();

// Dialog Data
	//{{AFX_DATA(CExplorerSet)
	enum { IDD = IDD_EXPLORERSET };
	CCheckListBox	m_cDriveList;
	CComboBox	m_cDrive;
	CStatic	m_cDriveIcon;
	BOOL	m_bSmallBmp;
	CString	m_sBackBmp;
	CString	m_sIconSize;
	BOOL	m_bHideFilemenu;
	BOOL	m_bNoSaveset;
	int		iIconColor;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CExplorerSet)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	bool Modify;
	BOOL m_bOldSmallbmp;
	CString BmpDefaulticon;
	CArray<AutorunInfo,AutorunInfo> DriveAuto;
	int CurDrive;
	// Generated message map functions
	//{{AFX_MSG(CExplorerSet)
	virtual BOOL OnInitDialog();
	afx_msg void OnBrowseback();
	afx_msg void OnAutorunbrowse();
	afx_msg void OnBrowseicon();
	afx_msg void OnAutoruncancel();
	afx_msg void OnSelchangeDrive();
	afx_msg void OnLChange();
	afx_msg void OnChange();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXPLORERSET_H__C62226F3_5FD7_11D2_8573_ECD904C10000__INCLUDED_)
