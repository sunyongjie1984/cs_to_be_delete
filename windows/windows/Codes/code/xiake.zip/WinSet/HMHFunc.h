/*
HMHFunc.h
���ߣ�������
���Ա�ĺ�����
*/
#ifndef _HMH_MY_FUNCTION
#define _HMH_MY_FUNCTION

int HMHGetLinkInfo(LPCTSTR FileName,CString &FilePath,CString &CommandLine,CString &WorkDir,CString &IconPath,int &IconIndex);
int HMHGetLinkInfo(LPCTSTR FileName,CString &FilePath);
int HMHCreateLink(LPCTSTR FileName, LPCTSTR FilePath,LPCTSTR CommandLine,LPCTSTR WorkDir,LPCTSTR IconPath="",int IconIndex=0);
int HMHCreateInternetLink(LPCTSTR FileName, LPCTSTR InternetPath, LPCTSTR IconFile, int IconIndex=0);

void HMHGetIconFile(const CString &IconFile, CString &IconFileName, int &IconIndex);
BOOL HMHFileExist(LPCTSTR FileName);

enum HMHWindowsVer
{
	HMHWINDOWS31,
	HMHWINDOWS95,
	HMHWINDOWS98,
	HMHWINDOWSNT,
	HMHWINDOWSNOTKNOW
};

HMHWindowsVer HMHGetWindowVer(void);
BOOL HMHRestartWindowNT(BOOL Reboot=TRUE,LPSTR PromptText=NULL,int DelayTime=0);
CString HMHGetFileAtDir(LPCTSTR FileName);
CString HMHNumToString(LONG Number);
CString HMHGetSpecifyFolderPath(int nFolder);

#endif