#if !defined(AFX_HMHOPENFILE_H__CFBC56C1_6EE1_11D3_BEE7_A7C45BAEA520__INCLUDED_)
#define AFX_HMHOPENFILE_H__CFBC56C1_6EE1_11D3_BEE7_A7C45BAEA520__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HMHOpenFile.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHMHOpenFile dialog
#ifndef HMH_OPENFILE_DIALOG
#define HMH_OPENFILE_DIALOG

class CHMHOpenFile : public CFileDialog
{
	DECLARE_DYNAMIC(CHMHOpenFile)

public:
	void SetInitialFile(LPCTSTR FileName);
	void SetDlgTitle(LPCTSTR String);
	void SetDlgTitle(UINT StrID);
	void SetCancelBtnStr(UINT StrID);
	void SetOkBtnStr(UINT StrID);
	void SetInitialDir(LPCTSTR FileName);
	void SetCancelBtnStr(CString Str);
	void SetOkBtnStr(CString Str);
	CHMHOpenFile(
		LPCTSTR lpszFilter = NULL,
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_OVERWRITEPROMPT,		
		BOOL bOpenFileDialog=TRUE, // TRUE for FileOpen, FALSE for FileSaveAs
		CWnd* pParentWnd = NULL);
	CHMHOpenFile(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_OVERWRITEPROMPT,
		LPCTSTR lpszFilter = NULL,
		CWnd* pParentWnd = NULL);
protected:
	void InitialData();
	CString DlgTitle;
	CString m_sCancelBtnStr;
	CString m_sOkBtnStr;
	//{{AFX_MSG(CHMHOpenFile)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HMHOPENFILE_H__CFBC56C1_6EE1_11D3_BEE7_A7C45BAEA520__INCLUDED_)
