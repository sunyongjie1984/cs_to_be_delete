#include "stdafx.h"
#include "HMHFunc.h"

/*
���ߣ�������
���Ա�ĺ�����
*/


/*
��ȡ��ݷ�ʽ�ļ���Ϣ
FileName����ݷ�ʽ�ļ���
FilePath: ȡ����ָ����ļ�
CommandLine: ����ָ���������
WorkDir: ����Ŀ¼
IconFile: ��ͼ���ļ�
IconIndex: ��ͼ���ļ�������

����1�ɹ������򷵻�0
*/

int HMHGetLinkInfo(LPCTSTR FileName,CString &FilePath,CString &CommandLine,CString &WorkDir,CString &IconPath,int &IconIndex)
{
	HRESULT hres;
	IShellLink *psl;
	
	hres = CoCreateInstance (CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER,
		IID_IShellLink, (void **)&psl);
	if (SUCCEEDED (hres))
	{
		IPersistFile *ppf;
		
		hres = psl->QueryInterface (IID_IPersistFile, (void **)&ppf);
		if (SUCCEEDED (hres))
		{ 
			char LinkFile[MAX_PATH];
			WORD wsz[MAX_PATH];
			
			strcpy(LinkFile,FileName);
			MultiByteToWideChar (CP_ACP, 0, LinkFile, -1, wsz, MAX_PATH);
			hres=ppf->Load(wsz,STGM_READ);
			if (hres==S_OK)
			{
				hres = psl->GetPath (FilePath.GetBuffer(MAX_PATH),MAX_PATH,NULL,0);
				FilePath.ReleaseBuffer();
				if ( !SUCCEEDED (hres))
					return 0;
				hres=psl->GetArguments(CommandLine.GetBuffer(MAX_PATH),MAX_PATH);
				CommandLine.ReleaseBuffer();
				if ( !SUCCEEDED (hres))
					CommandLine.Empty();
				hres=psl->GetWorkingDirectory(WorkDir.GetBuffer(MAX_PATH),MAX_PATH);
				WorkDir.ReleaseBuffer();
				if ( !SUCCEEDED (hres))
					WorkDir.Empty();
				hres=psl->GetIconLocation(IconPath.GetBuffer(MAX_PATH),MAX_PATH,&IconIndex);
				IconPath.ReleaseBuffer();
				if ( !SUCCEEDED (hres))
				{
					IconPath.Empty();
					IconIndex=0;
				}								
			}
			ppf->Release ();
			psl->Release ();
		}
	}
	return 1;
}

/*
��ȡ��ݷ�ʽ�ļ� FileName ָ����ļ�·��FilePath
����1�ɹ�������ʧ��
*/
int HMHGetLinkInfo(LPCTSTR FileName,CString &FilePath)
{
	CString Str;
	int Index;
	return HMHGetLinkInfo(FileName,FilePath,Str,Str,Str,Index);
}


/*
�������ͼ��
FileName:�������Ŀ�ݷ�ʽ�ļ�������չ��Ϊlnk)
FilePath:�����Ŀ�ݷ�ʽָ���·��
CommandLine:��ݷ�ʽ��������
WorkDir:����Ŀ¼
IconFile:ͼ���ļ�
IconIndex:ͼ���ļ��е�����
*/
int HMHCreateLink(LPCTSTR FileName, LPCTSTR FilePath,LPCTSTR CommandLine,LPCTSTR WorkDir,LPCTSTR IconPath,int IconIndex)
{
	HRESULT hres;
	IShellLink* psl;
	hres = CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER,	IID_IShellLink, (LPVOID*) &psl);	
	if (SUCCEEDED(hres))	
	{	
		IPersistFile* ppf;
		
		psl->SetPath(FilePath);
		psl->SetArguments(CommandLine);
		psl->SetWorkingDirectory(WorkDir);
		psl->SetIconLocation(IconPath,IconIndex);
		psl->SetShowCmd(SW_SHOW);
		hres = psl->QueryInterface( IID_IPersistFile, (LPVOID *) &ppf);
		if (SUCCEEDED(hres))		
		{			
			WORD wsz[MAX_PATH];
			MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, FileName, -1, wsz,MAX_PATH);
			hres = ppf->Save(wsz, TRUE);
			if (hres != S_OK )
				return 0;
			ppf->Release();		
		}
		psl->Release();	
	}	
	else 
		return 0;
	return 1;
}

//����Internet��ݷ�ʽ
int HMHCreateInternetLink(LPCTSTR FileName, LPCTSTR InternetPath, LPCTSTR IconFile, int IconIndex)
{
	CFile LinkFile;
	CString String;

	if (LinkFile.Open(FileName,CFile::modeCreate|CFile::modeWrite)==0)
		return 0;
	String="[InternetShortcut]\r\n";
	LinkFile.Write((void*)(LPCTSTR)String,String.GetLength());
	String.Format("Url=%s\r\n",InternetPath);
	LinkFile.Write((void*)(LPCTSTR)String,String.GetLength());
	if (IconFile!="")
	{
		String.Format("IconFile=%s,%d",IconFile,IconIndex);
		LinkFile.Write((void*)(LPCTSTR)String,String.GetLength());
	}
	LinkFile.Close();
	return 1;
}


//�ж��ļ��Ƿ���� 
BOOL HMHFileExist(LPCTSTR FileName)
{
	CFileFind ff;
    

	if (ff.FindFile(FileName)==0)
		return FALSE;
	else
		return TRUE;
}

/*
����Windows�汾��
���ش��ţ�
HMHWINDOWS31:Win32s on Windows 3.1. 
HMHWINDOWS95:Win32 on Windows 95
HMHWINDOWS98:Win32 on Windows 98
HMHWINDOWSNT:Win32 on Windows NT
//4:Win32 on Windows CE

δ֪����ϵͳ������-1
*/
HMHWindowsVer HMHGetWindowVer(void)
{
	
	OSVERSIONINFO OsVer;
	HMHWindowsVer nRes;
	
	OsVer.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if (GetVersionEx(&OsVer))
	{
		switch(OsVer.dwPlatformId)
		{  
		case VER_PLATFORM_WIN32s: //Win32s on Windows 3.1.
			nRes=HMHWINDOWS31;	//Win32s
			break;				  			
		case VER_PLATFORM_WIN32_WINDOWS: //WIN32 on 95 or 98
			//determine if Win95 or Win98 
			if (OsVer.dwMinorVersion == 0)   
			{
				nRes=HMHWINDOWS95;//Windows95				
			}
			else
			{    
				nRes=HMHWINDOWS98;//Windows98
			}
			break;
		case VER_PLATFORM_WIN32_NT: //Win32 on Windows NT.
			nRes=HMHWINDOWSNT;//Windows NT
			break;
/*		case VER_PLATFORM_WIN32_CE:  //Win32 on Windows CE
			nRes=4;
			break;	*/
		default:
			nRes=HMHWINDOWSNOTKNOW;
		} 
	}
	return nRes;
}


//��ͼ���ļ��ַ��� "xxxxx,n" �ֽ���ļ�����ͼ������
void HMHGetIconFile(const CString &IconFile, CString &IconFileName, int &IconIndex)
{
	CString Str;
	int Index;

	IconIndex=0;
	IconFileName=IconFile;

	if ( (Index=IconFile.ReverseFind(','))!=-1 )
	{
		Str=IconFile.Right(IconFile.GetLength()-Index-1);
		IconFileName=IconFile.Left(Index);
		IconIndex=atoi(Str);
	}	
}

//�����ļ�FileName���ڵ�Ŀ¼,������'\\'
CString HMHGetFileAtDir(LPCTSTR FileName)
{
	CString DirName=FileName;

    int i=DirName.ReverseFind('\\');
	if (i!=-1)
		DirName=DirName.Left(i);
	else
		DirName.Empty();

	return DirName;
}

//����ֵת��Ϊ�ַ���
CString HMHNumToString(LONG Number)
{
	char szTemp[255];

	_ltoa(Number,szTemp,10);
	return (CString)szTemp;
}

/*
����������ر�Windows NTϵͳ
PromptText:�Ի�����ʾ��Ϣ
DelayTime:�Ի�����ʾʱ��
*/
BOOL HMHRestartWindowNT(BOOL Reboot,LPSTR PromptText,int DelayTime)
{
	if (HMHGetWindowVer()==HMHWINDOWSNT)
	{
		HANDLE hToken;              // handle to process token 
		TOKEN_PRIVILEGES tkp;       // pointer to token structure  
		BOOL fResult;               // system shutdown flag  
		// Get the current process token handle so we can get shutdown // privilege.  
		if (!OpenProcessToken(GetCurrentProcess(), 
			TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) 
			return 0;
		// Get the LUID for shutdown privilege.  
		LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME,&tkp.Privileges[0].Luid);  
		tkp.PrivilegeCount = 1;  // one privilege to set    
		tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;  
		// Get shutdown privilege for this process.  
		AdjustTokenPrivileges(hToken, FALSE, &tkp, 0,(PTOKEN_PRIVILEGES) NULL, 0); 
		// Cannot test the return value of AdjustTokenPrivileges.  
		if (GetLastError() != ERROR_SUCCESS) 
			return 0;
		// Display the shutdown dialog box and start the time-out countdown.  
		fResult = InitiateSystemShutdown( 
			NULL,                                  // shut down local computer 
			PromptText,
			DelayTime,                             // time-out period 
			FALSE,                                 // ask user to close apps 
			Reboot);                                 // reboot after shutdown  
		if (!fResult) 
		{
			return 0;
		} 
		return 1;
	}
	return 0;
	
}

//����ϵͳ�����ļ��� nFolder ��·��
CString HMHGetSpecifyFolderPath(const int nFolder)
{
	int nSysFolder[]={CSIDL_DESKTOP,CSIDL_STARTMENU,CSIDL_FAVORITES,CSIDL_PERSONAL,CSIDL_RECENT,
		CSIDL_SENDTO,CSIDL_STARTUP,CSIDL_PROGRAMS,CSIDL_TEMPLATES,CSIDL_FONTS,CSIDL_APPDATA,CSIDL_INTERNET_CACHE,CSIDL_NETWORK};
	char *RegKeyName[]={"Desktop","Start Menu","Favorites","Personal","Recent",
		"SendTo","Startup","Programs","Templates","Fonts","AppData","Cache","NetHood"};
	
	CString FolderPath="";
	ITEMIDLIST Dir1;
	char Ddir[MAX_PATH];
	LPITEMIDLIST Dir=&Dir1;
	BOOL NoError=FALSE;

	for (int i=0;i<sizeof(nSysFolder)/sizeof(int);i++)
	{
		if ( *(nSysFolder+i)==nFolder)
			break;
	}
	if (i<sizeof(nSysFolder)/sizeof(int))
	{
		HKEY m_hKey;
		DWORD dwSize=255,dwType=REG_SZ;
		char String[256],StrKey[256];
		
		strcpy(StrKey,"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders");
		if (HMHGetWindowVer()==HMHWINDOWSNT)
			strcpy(StrKey,"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders");
		if (ERROR_SUCCESS==::RegOpenKeyEx(HKEY_CURRENT_USER,StrKey,NULL,KEY_ALL_ACCESS,&m_hKey))
		{
			if (ERROR_SUCCESS==::RegQueryValueEx(m_hKey,RegKeyName[i],0,&dwType,(BYTE *)String,&dwSize))
			{
				FolderPath=String;
				NoError=TRUE;
			}				
		}
	}	
	if (NoError==FALSE)
	{
		if (::SHGetSpecialFolderLocation(NULL,nFolder,&Dir)==NOERROR)
		{
			::SHGetPathFromIDList(Dir,Ddir);
			FolderPath=Ddir;
		}
	}
	if ( ! (FolderPath.GetLength()>=3 && FolderPath.GetAt(2)=='\\'))
	{
		::ExpandEnvironmentStrings(FolderPath.GetBuffer(MAX_PATH),Ddir,MAX_PATH);
		FolderPath.ReleaseBuffer();
		FolderPath=Ddir;
	}
	return FolderPath;
}