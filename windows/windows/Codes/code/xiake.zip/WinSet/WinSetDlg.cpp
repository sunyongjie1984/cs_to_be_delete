// WindowSet.cpp : �������ļ�
//����ϵͳ�޸��� 1.0b
//�������������ҡ�http://xksoft.yeah.net
//���ߣ������� xksoft@yeah.net
//

#include "stdafx.h"
#include "resource.h"
#include "WinSet.h"
#include "WinSetDlg.h"
#include "AboutDlg.h"
#include "RegEdit.h"


#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWinSetDlg

IMPLEMENT_DYNAMIC(CWinSetDlg, CPropertySheetWithLogoDlg)

CWinSetDlg::CWinSetDlg(CWnd* pWndParent)
	 : CPropertySheetWithLogoDlg(IDS_APPCAPTION, pWndParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	MouseInMinibox=FALSE;
	
	//�޸��Ʊ�����ʹ��һ����ʾ�����Ʊ�
	//EnableStackedTabs(FALSE);

	SetLogoText("��������������");
	SetTipText("��������ϵͳ�޸�������������");
	SetColor(RGB(128, 128, 0),RGB(255, 255, 0));

	m_psh.dwFlags &= ~(PSH_HASHELP);

	AddPage(&m_General);
	AddPage(&m_ExplorerSet); 	
	AddPage(&m_StartmenuPage);
	AddPage(&m_StartrunProg);
	AddPage(&m_AdddelSoft);
	AddPage(&m_OtherItem);

	//������
	RegEdit Reg;
	DWORD UsePass;
	char Pass[256];
	Reg.RootKey=HKEY_CURRENT_USER;
	if (Reg.OpenKey("SoftWare\\XKSoft\\WinSet"))
	{
		if (Reg.ReadDword("UsePass",UsePass))
		{
			if (UsePass)
			{
				if (Reg.ReadBinary("Public",Pass))
				{
					for (int i=0;i<strlen(Pass);i++)
						*(Pass+i)=~*(Pass+i);
					CInputPass InputPassDlg;
					int Num=0;
					CString Title;
					Title.LoadString(IDS_APPCAPTION);
					while (InputPassDlg.DoModal()==IDOK)
					{
						if (InputPassDlg.m_sPassword!=Pass)
						{
							
							InputPassDlg.m_sPassword="";
							if (Num==2)
							{
								MessageBox("�Բ�������������󣬲���ʹ�ñ�����!",Title);
								PostMessage(WM_QUIT);
								break;
							}
						}
						else
						{
							Num=-1;
							break;
						}
						MessageBox("�����������������!",Title);
						Num++;
					}
					if (Num!=-1)
						PostMessage(WM_QUIT);
				}
			}
		}
	}
}

CWinSetDlg::~CWinSetDlg()
{
}


BEGIN_MESSAGE_MAP(CWinSetDlg, CPropertySheetWithLogoDlg)
	//{{AFX_MSG_MAP(CWinSetDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_COMMAND(WM_WINSETFIRSTUSE,OnWinsetFiruse)
	ON_WM_NCLBUTTONDOWN()
	ON_WM_DESTROY()
	ON_WM_SETCURSOR()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};


/////////////////////////////////////////////////////////////////////////////
// CWinSetDlg message handlers



BOOL CWinSetDlg::OnInitDialog() 
{
	BOOL bResult = CPropertySheetWithLogoDlg::OnInitDialog();
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	CString str;
	
	ModifyStyle(0,WS_MINIMIZEBOX);

	pSysMenu->AppendMenu(MF_SEPARATOR);
	str.LoadString(IDS_HOMEPAGE);
	pSysMenu->AppendMenu(MF_STRING,IDM_HOMEPAGE,str);
	str.LoadString(IDS_ABOUTBOX);
	pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, str);
	
	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

	RECT rcWindow,rcStatus;	
	GetWindowRect(&rcWindow);
	rcWindow.bottom += 20;
	MoveWindow(&rcWindow, FALSE);		
	
	rcStatus=rcWindow;
	rcStatus.top=rcWindow.bottom-20;	
		
	//����״̬��
	if (!m_wndStatusBar.Create(WS_CHILD|WS_VISIBLE|CCS_BOTTOM,rcStatus,this,IDC_MYSTATUS))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      
	}
    ShowStatus=TRUE;
	m_wndStatusBar.SetTipText(0,"����״̬��");

	//���ñ�ǩͼ��
	m_imageTab.Create(16,16,ILC_COLORDDB|ILC_MASK,0,0);
	m_imageTab.Add(AfxGetApp()->LoadIcon(IDI_GENERAL));
	m_imageTab.Add(AfxGetApp()->LoadIcon(IDI_MYCOMPUTER));
	m_imageTab.Add(AfxGetApp()->LoadIcon(IDI_STARTMENU));
	m_imageTab.Add(AfxGetApp()->LoadIcon(IDI_START));
	m_imageTab.Add(AfxGetApp()->LoadIcon(IDI_ADDDEL));
	m_imageTab.Add(AfxGetApp()->LoadIcon(IDI_OTHERITEM));
	CTabCtrl *pTab = GetTabControl();
	//pTab->ModifyStyle(0,TCS_HOTTRACK|TCS_FLATBUTTONS,1);
	pTab->SetImageList( &m_imageTab );
	TC_ITEM tcItem;	
	tcItem.mask = TCIF_IMAGE;
	for( int i = 0; i <6; i++ )
	{
		tcItem.iImage = i;
		pTab->SetItem( i, &tcItem );
	}
	
	/*  �Զ����а�ť
	CWnd* pWnd = GetDlgItem(ID_APPLY_NOW);		
	if (pWnd && ::IsWindow(pWnd->m_hWnd))	
	{
		// Get the last control in the tab order - (tab order is the same as creation order)
		pWnd = pWnd->GetWindow(GW_HWNDLAST);		// Get the tab control
		CTabCtrl* pTabCtrl = GetTabControl();
		// Get the child identifier of the tab control
		int nTabControlID = ::GetWindowLong(pTabCtrl->m_hWnd, GWL_ID);
		// Child control identifier		
		int nControlID = 0;
		// The window rect of the tab control.
		CRect rcTAB(0, 0, 0, 0);
		pTabCtrl->GetWindowRect(rcTAB);		
		ScreenToClient(rcTAB);
		CRect rcTemp(0, 0, 0, 0);		
		GetClientRect(rcTemp);		
		int nLeft = rcTemp.right;
		int nSpacing = rcTemp.right - rcTAB.right;
		// do this bit while we have a control to do something with		
		while(pWnd)		
		{
			// Get the ID of the current child control
			nControlID = ::GetWindowLong(pWnd->m_hWnd, GWL_ID);			
			// Do not make changes to the tab control!!
			if (nControlID != nTabControlID)			
			{				// do some stuff
				pWnd->GetWindowRect(rcTemp);				
				ScreenToClient(rcTemp);
				// Is the child control visible? - Don't use IsWindowVisible as the parent
				// also has to be visible for that to return TRUE;
				BOOL bChildIsVisible = ((pWnd->GetStyle() & WS_VISIBLE) == WS_VISIBLE);
				// Make sure we are below the TAB control
				if ((rcTemp.top > rcTAB.bottom) && bChildIsVisible)				
				{
				// Move each control					
				nLeft -= nSpacing + rcTemp.Width();					
				pWnd->MoveWindow(nLeft, rcTemp.top, rcTemp.Width(), rcTemp.Height());				
				}
				}							// Go back in the TAB order again
				pWnd = pWnd->GetWindow(GW_HWNDPREV);		
				}	
				}
	*/
	RegEdit Reg;
	Reg.RootKey=HKEY_CURRENT_USER;
	if (Reg.OpenKey("SoftWare\\XKSoft\\WinSet"))
	{
		DWORD wordbuf,JmpPage=1,Page=0;
		if (Reg.ReadDword("AutoJmppage",wordbuf))
			JmpPage=wordbuf;
		if (JmpPage)
		{
			if (Reg.ReadDword("SrcPage",wordbuf))
				Page=wordbuf;
			if (Page>GetPageCount())
				Page=GetPageCount();
			SetActivePage(Page);
		}
	}
	else
	{
		PostMessage(WM_COMMAND,WM_WINSETFIRSTUSE);
	}	
	
	return bResult;
}

void CWinSetDlg::OnSysCommand(UINT nID, LPARAM lParam) 
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else  if (nID ==IDM_HOMEPAGE)
	{
		::ShellExecute(m_hWnd,"Open","http://xksoft.yeah.net",NULL,NULL,SW_SHOWMAXIMIZED);
	}
	else
	{
		CPropertySheetWithLogoDlg::OnSysCommand(nID, lParam);
	}	
}


HCURSOR CWinSetDlg::OnQueryDragIcon() 
{
	return m_hIcon;
}

void CWinSetDlg::GoRun()
{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
}
/////////////////////////////////////////////////////////////////////////////
// CInputPass dialog


CInputPass::CInputPass(CWnd* pParent /*=NULL*/)
	: CDialog(CInputPass::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInputPass)
	m_sPassword = _T("");
	//}}AFX_DATA_INIT
}


void CInputPass::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInputPass)
	DDX_Text(pDX, IDC_PASSWORD, m_sPassword);
	DDV_MaxChars(pDX, m_sPassword, 255);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInputPass, CDialog)
	//{{AFX_MSG_MAP(CInputPass)
	ON_EN_CHANGE(IDC_PASSWORD, OnChangePassword)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInputPass message handlers

BOOL CWinSetDlg::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo) 
{

//	if (nID==ID_HELP)
//		return FALSE;
	return CPropertySheetWithLogoDlg::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void CWinSetDlg::WinHelp(DWORD dwData, UINT nCmd) 
{
	//��F1�������ڶԻ���
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();

	//CPropertySheetWithLogoDlg::WinHelp(dwData, nCmd);
}

void CWinSetDlg::OnClose() 
{

	
	CPropertySheetWithLogoDlg::OnClose();
}

void CWinSetDlg::OnWinsetFiruse()
{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();

}


void CInputPass::OnChangePassword() 
{
	UpdateData();
	GetDlgItem(IDOK)->EnableWindow(m_sPassword.GetLength()>0 ? TRUE:FALSE);
}

BOOL CInputPass::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	GetDlgItem(IDOK)->EnableWindow(FALSE);
	return TRUE;
}


void CWinSetDlg::OnNcLButtonDown(UINT nHitTest, CPoint point) 
{
	if (nHitTest==HTMINBUTTON)
	{
		ShowWindow(SW_MINIMIZE);
	}
	
	CPropertySheetWithLogoDlg::OnNcLButtonDown(nHitTest, point);
}


void CWinSetDlg::OnDestroy() 
{
	CPropertySheetWithLogoDlg::OnDestroy();
	DWORD i=GetActiveIndex();

	RegEdit Reg;
	Reg.SetDwordValue(HKEY_CURRENT_USER,"SoftWare\\XKSoft\\WinSet","SrcPage",i);
	
	CPropertySheetWithLogoDlg::PostNcDestroy();
	
	
}

//����״̬����ʾ�ı�
void CWinSetDlg::SetStatusText(LPCTSTR lpszText)
{
	m_wndStatusBar.SetText(lpszText,0,0);
}

//��ʾ/����״̬��
void CWinSetDlg::ShowStatusBar()
{
	RECT rc;
	GetWindowRect(&rc);
	if (ShowStatus)
	{
		rc.bottom-=20;
	}
	else
	{
		rc.bottom+=20;
	}
	ShowStatus=!ShowStatus;
	MoveWindow(&rc);
}


BOOL CWinSetDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	int IDs[]={IDC_MYSTATUS,IDOK,IDCANCEL,ID_APPLY_NOW};
	int StrIDs[]={IDS_MYSTATUS,IDS_OK,IDS_CANCEL,IDS_APPLYNOW};
	
	CRect rc;
	CString Str;

	for (int i=0;i<sizeof(IDs)/sizeof(int);i++)
	{
		if (*GetDlgItem(IDs[i])==*pWnd)
		{
			Str.LoadString(StrIDs[i]);
			SetStatusText(Str);
			break;
		}
	}
	return CPropertySheetWithLogoDlg::OnSetCursor(pWnd, nHitTest, message);
}

void CWinSetDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	int IDs[]={ID_APPLY_NOW};
	int StrIDs[]={IDS_APPLYNOW};
	
	CRect rc;
	CString Str;
	bool Prompt=FALSE;
	for (int i=0;i<sizeof(IDs)/sizeof(int);i++)
	{
		GetDlgItem(IDs[i])->GetWindowRect(&rc);
		ScreenToClient(&rc);
		if (rc.PtInRect(point))
		{
			Str.LoadString(StrIDs[i]);
			((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
			Prompt=TRUE;
			break;
		}
	}
	if (!Prompt)
	{
		Str.LoadString(IDS_READY);
		SetStatusText(Str);
	}

	CPropertySheetWithLogoDlg::OnMouseMove(nFlags, point);
}

void CWinSetDlg::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	ShowStatusBar();
	CPropertySheetWithLogoDlg::OnLButtonDblClk(nFlags, point);
}

