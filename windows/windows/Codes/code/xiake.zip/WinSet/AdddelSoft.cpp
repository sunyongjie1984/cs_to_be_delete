// AdddelSoft.cpp :  ����/ɾ������ҳ
//����ϵͳ�޸��� 1.0b
//�������������ҡ�http://xksoft.yeah.net
//���ߣ������� xksoft@yeah.net


#include "stdafx.h"
#include "WinSet.h"
#include "AdddelSoft.h"
#include "RegEdit.h"
#include "UninstallCom.h"
#include "WinSetDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAdddelSoft property page

IMPLEMENT_DYNCREATE(CAdddelSoft, CPropertyPage)

CAdddelSoft::CAdddelSoft() : CPropertyPage(CAdddelSoft::IDD)
{
	m_psp.dwFlags &= ~(PSP_HASHELP);
	Modify=FALSE;
	//m_psp.dwFlags |=PSP_USEHICON ;
	//m_psp.hIcon=AfxGetApp()->LoadIcon(IDI_ADDDEL);

	//{{AFX_DATA_INIT(CAdddelSoft)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CAdddelSoft::~CAdddelSoft()
{
}

void CAdddelSoft::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAdddelSoft)
	DDX_Control(pDX, IDC_TRASHICO, m_cTrashIco);
	DDX_Control(pDX, IDC_UNINSTALLLIST, m_cUninstall);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAdddelSoft, CPropertyPage)
	//{{AFX_MSG_MAP(CAdddelSoft)
	ON_LBN_DBLCLK(IDC_UNINSTALLLIST, OnDblclkUninstalllist)
	ON_BN_CLICKED(IDC_ADDITEM, OnAdditem)
	ON_BN_CLICKED(IDC_DELITEM, OnDelitem)
	ON_BN_CLICKED(IDC_EXECUTE, OnExecute)
	ON_WM_CTLCOLOR()
	ON_WM_LBUTTONDBLCLK()
	ON_BN_CLICKED(IDC_EDITITEM, OnDblclkUninstalllist)
	ON_WM_MOUSEMOVE()
	ON_WM_SETCURSOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdddelSoft message handlers

BOOL CAdddelSoft::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	RegEdit Reg;
	char String[256];
	int i;

	Num=0;
	Reg.RootKey=HKEY_LOCAL_MACHINE;
	if (Reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall"))
	{
		RegEdit UnReg;
		UnReg.RootKey=HKEY_LOCAL_MACHINE;
		i=Reg.FirstEnumKey(String);
		while (i)
		{
			CString StrKey="Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\";
			StrKey+=String;
			
			if (UnReg.OpenKey(StrKey))
			{
				CString SoftName;
				if (UnReg.ReadString("DisplayName",SoftName))
				{
					UnMsg Msg;
					
					Msg.StrKey=String;
					
					Msg.DisplayName=SoftName;
					Msg.Command="";
					int Index=m_cUninstall.AddString(Msg.DisplayName);
					m_cUninstall.SetItemData(Index,(DWORD)Num++);
					if (UnReg.ReadString("UninstallString",SoftName))
						Msg.Command=SoftName;
					Msg.Exist=1;
					UnmsgArray.Add(Msg);			  
				}			
								
			} 
			i=Reg.NextEnumKey(String);
		}
		UnReg.CloseKey();
	}	 	
	m_cUninstall.SetCurSel(0);
	if (m_cUninstall.GetCount()<1)
		m_cTrashIco.SetIcon(::LoadIcon( AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_TRASHEMPTY)));
	else
		m_cTrashIco.SetIcon(::LoadIcon( AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_TRASHFULL)));
	((CWinSetApp*)AfxGetApp())->SetListboxWidth(m_cUninstall);
	return TRUE;  
}

//˫���򰴱༭ť�༭��
void CAdddelSoft::OnDblclkUninstalllist() 
{
	CUninstallCom UnDlg;

	int i=m_cUninstall.GetCurSel();
	if (i==LB_ERR)
		return;
	int Index=m_cUninstall.GetItemData(i);
	UnDlg.m_sCommand=UnmsgArray[Index].Command;
	UnDlg.m_sDispName=UnmsgArray[Index].DisplayName;
	int nRes=UnDlg.DoModal();
	if (nRes==IDOK)
	{	
		if (UnDlg.m_sCommand!=UnmsgArray[Index].Command || UnDlg.m_sDispName!=UnmsgArray[Index].DisplayName)
		{
			OnChange();
			UnmsgArray[Index].Command=UnDlg.m_sCommand;
			UnmsgArray[Index].DisplayName=UnDlg.m_sDispName;
			m_cUninstall.DeleteString(i);
			i=m_cUninstall.AddString(UnmsgArray[Index].DisplayName);
			m_cUninstall.SetItemData(i,(DWORD)Index);
			
			((CWinSetApp*)AfxGetApp())->SetListboxWidth(m_cUninstall);
		}
	}	
}

//����ж����
void CAdddelSoft::OnAdditem() 
{
	CUninstallCom UnDlg;
	int nRes=UnDlg.DoModal();
	static AddNum=0;
	if (nRes==IDOK)
	{
		UnMsg Msg;
		Msg.StrKey.Empty();
		Msg.Command=UnDlg.m_sCommand;
		Msg.DisplayName=UnDlg.m_sDispName;
		Msg.Exist=1;
		int Index=m_cUninstall.AddString(Msg.DisplayName);
		m_cUninstall.SetItemData(Index,(DWORD)Num++);
		m_cUninstall.SetCurSel(Index);
		UnmsgArray.Add(Msg);
		OnChange();
		((CWinSetApp*)AfxGetApp())->SetListboxWidth(m_cUninstall);
	}		
}

//ɾ��ж����
void CAdddelSoft::OnDelitem() 
{
	CString Title,String;
	int i=m_cUninstall.GetCurSel();
	if (i==LB_ERR)
		return;
	m_cUninstall.GetText(i,Title);
	String.Format("�Ƿ�ɾ���� %s ��ж�������� ?",Title);
	Title.LoadString(IDS_APPCAPTION);
	if (MessageBox(String,Title,MB_YESNO|MB_ICONQUESTION)==IDYES)
	{
		RemoveItem(i);
	}
}

void CAdddelSoft::OnOK() 
{
	if (Modify)
	{
		RegEdit Reg;
		int Index;
		CString BaseKey="Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\";
		Reg.RootKey=HKEY_LOCAL_MACHINE;
		CWinSetApp *pApp=(CWinSetApp*)AfxGetApp();
		for (int i=0;i<m_cUninstall.GetCount();i++)
		{
			CString StrKey;
			
			Index=m_cUninstall.GetItemData(i);
			StrKey=BaseKey+UnmsgArray[Index].StrKey;
			//������������һ����
			if (UnmsgArray[Index].StrKey.IsEmpty())
			{
				int num=0;
				StrKey=BaseKey+pApp->NumToString(num);
				while (Reg.OpenKey(StrKey))
				{
					num++;
					StrKey=BaseKey+pApp->NumToString(num);
				}
				UnmsgArray[Index].StrKey=pApp->NumToString(num);
				Reg.OpenKey(BaseKey);
				Reg.CreateKey(pApp->NumToString(num));
				Reg.WriteString("DisplayName",UnmsgArray[Index].DisplayName);
				Reg.WriteString("UninstallString",UnmsgArray[Index].Command);
			}
			else if (Reg.OpenKey(StrKey))
			{
				Reg.WriteString("DisplayName",UnmsgArray[Index].DisplayName);
				Reg.WriteString("UninstallString",UnmsgArray[Index].Command);
			}
			UnmsgArray[Index].Exist=0;
		}
		Reg.OpenKey(BaseKey);
		for (i=0;i<UnmsgArray.GetSize();i++)
		{
			if ( UnmsgArray[i].Exist )
			{
				if ( !UnmsgArray[i].StrKey.IsEmpty() ) 
					Reg.DeleteKey(UnmsgArray[i].StrKey);
			}
			else
				UnmsgArray[i].Exist=1;
		}
	}
	CPropertyPage::OnOK();
}


void CAdddelSoft::OnChange()
{
	SetModified(TRUE);	
	Modify=TRUE;
}

//ִ�з���װ����
void CAdddelSoft::OnExecute() 
{
	int i=m_cUninstall.GetCurSel();
	if (i==LB_ERR)
		return;
	int Index=m_cUninstall.GetItemData(i);
	

	STARTUPINFO StartInfo;
	memset((void*)&StartInfo,0,sizeof(StartInfo));
	StartInfo.cb=sizeof(StartInfo);
	PROCESS_INFORMATION ProInfo;
	if (!::CreateProcess(NULL,UnmsgArray[Index].Command.GetBuffer(UnmsgArray[Index].Command.GetLength()),NULL,NULL,FALSE,CREATE_DEFAULT_ERROR_MODE|NORMAL_PRIORITY_CLASS,NULL,NULL,&StartInfo,&ProInfo))
	{
		CString String,Prompt;

		m_cUninstall.GetText(i,String);
		Prompt.Format("ִ�С� %s ��ж�س���ʱ���������Ƿ񽫸���ɾ��?",String);
		String.LoadString(IDS_APPCAPTION);
		if (MessageBox(Prompt,String,MB_YESNO|MB_ICONQUESTION)==IDYES)
		{
			RemoveItem(i);
		}
	}
	UnmsgArray[Index].Command.ReleaseBuffer();
}

//���б�����ɾ��һ��
void CAdddelSoft::RemoveItem(int Index)
{
		m_cUninstall.DeleteString(Index);
		if (m_cUninstall.SetCurSel(Index)==LB_ERR)
			m_cUninstall.SetCurSel(0);
		OnChange();
		((CWinSetApp*)AfxGetApp())->SetListboxWidth(m_cUninstall);
		if (m_cUninstall.GetCount()<1)
			m_cTrashIco.SetIcon(::LoadIcon( AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_TRASHEMPTY)));
		else
			m_cTrashIco.SetIcon(::LoadIcon( AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_TRASHFULL)));

}

//������ɫ
HBRUSH CAdddelSoft::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CPropertyPage::OnCtlColor(pDC, pWnd, nCtlColor);
	
/*1	int	FrmIDs[]={IDC_ADDDELPROMPT};
	for (int i=0;i<sizeof(FrmIDs)/sizeof(int);i++)
	{
	 if (*GetDlgItem(FrmIDs[i])==*(pWnd))
	 {
		pDC->SetTextColor(GetSysColor(COLOR_HIGHLIGHT));
		break;
	 }
	}
	*/
	return hbr;
}

void CAdddelSoft::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	//��ʾ����״̬��
	((CWinSetDlg*)AfxGetMainWnd())->ShowStatusBar();
	
	CPropertyPage::OnLButtonDblClk(nFlags, point);
}

void CAdddelSoft::OnMouseMove(UINT nFlags, CPoint point) 
{

	CString Str;
	Str.LoadString(IDS_READY);
	((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
	
	CPropertyPage::OnMouseMove(nFlags, point);
}

BOOL CAdddelSoft::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	int IDs[]={    IDC_UNINSTALLLIST,IDC_EXECUTE,  IDC_ADDITEM,  IDC_DELITEM  ,IDC_EDITITEM};
	UINT StrIDs[]={IDS_UNINSTALLLIST,IDS_EXECUTEUN,IDS_ADDUNITEM,IDS_DELUNITEM,IDS_EDITUNITEM};
	
	CRect rc;
	CString Str;
	bool Prompt=FALSE;
	for (int i=0;i<sizeof(IDs)/sizeof(int);i++)
	{
		if (*GetDlgItem(IDs[i])==*pWnd)
		{
			Str.LoadString(StrIDs[i]);
			((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
			Prompt=TRUE;
			break;
		}
	}
	
	return CPropertyPage::OnSetCursor(pWnd, nHitTest, message);
}
