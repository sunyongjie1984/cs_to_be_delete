#if !defined(AFX_ABOUTDLG_H__04C5D302_5FF7_11D2_8573_ECD904C10000__INCLUDED_)
#define AFX_ABOUTDLG_H__04C5D302_5FF7_11D2_8573_ECD904C10000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// AboutDlg.h : header file
//
#include "HyperLink.h"
#include "BigIcon.h"
#include "CheckFrm.h"

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog

class CAboutDlg : public CDialog
{
// Construction
public:
	HICON m_hIcon;
	CAboutDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTDIALOG };
	CBigIcon	AppIcon;
	CHyperLink m_cHomePage;
	CHyperLink m_cEmailMe;
	CString	m_sPasswordType;
	BOOL	m_bUsePassword;
	BOOL	m_bAutoJmppage;
	BOOL	m_bExitPromptReboot;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CCheckFrame IsUsePass;
	// Generated message map functions
	//{{AFX_MSG(CAboutDlg)
	afx_msg void OnHomepage();
	afx_msg void OnMailme();
	virtual BOOL OnInitDialog();
	afx_msg void OnUsepassword();
	virtual void OnOK();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ABOUTDLG_H__04C5D302_5FF7_11D2_8573_ECD904C10000__INCLUDED_)
