#if !defined(AFX_STARTRUNPROG_H__135897E3_7B7C_11D2_8575_18F402C10000__INCLUDED_)
#define AFX_STARTRUNPROG_H__135897E3_7B7C_11D2_8575_18F402C10000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// StartrunProg.h : header file
//
#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CStartrunProg dialog
typedef struct StartProg
{
	CString Valname;
	CString Value;
	int Type;
	int Exist;
	BOOL Enable;
}AutoRunProg;

class CStartrunProg : public CPropertyPage
{
	DECLARE_DYNCREATE(CStartrunProg)

// Construction
public:
	void RemoveStartprog(AutoRunProg &Item);
	CStartrunProg();
	~CStartrunProg();
// Dialog Data
	//{{AFX_DATA(CStartrunProg)
	enum { IDD = IDD_START };
	CCheckListBox	m_cStartProg;
	CString	m_sStartDlgTitle;
	CString	m_sStartDlgType;
	CString	m_sStartprogCom;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CStartrunProg)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	int SelectStartprog;
	void WriteStartprog(AutoRunProg &Item,BOOL Enable);
	int Loop;
	bool Modify;
	CArray<AutoRunProg,AutoRunProg> AutoRunprogs;
	// Generated message map functions
	//{{AFX_MSG(CStartrunProg)
	afx_msg void OnAppend();
	afx_msg void OnDelete();
	virtual BOOL OnInitDialog();
	afx_msg void OnChange();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnSelchangeStartrun();
	afx_msg void OnChangeStartprog();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STARTRUNPROG_H__135897E3_7B7C_11D2_8575_18F402C10000__INCLUDED_)
