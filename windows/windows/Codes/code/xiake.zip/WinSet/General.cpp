// General.cpp : implementation file
//һ��ϵͳѡ������

#include "stdafx.h"
#include "winset.h"
#include "General.h"
#include "RegEdit.h"
#include "FolderDialog.h"
#include "WinSetDlg.h"

#include <shlobj.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGeneral property page

IMPLEMENT_DYNCREATE(CGeneral, CPropertyPage)

CGeneral::CGeneral() : CPropertyPage(CGeneral::IDD)
{
	m_psp.dwFlags &= ~(PSP_HASHELP);
	//m_psp.dwFlags |=PSP_USEHICON ;
	//m_psp.hIcon=AfxGetApp()->LoadIcon(IDI_GENERAL);
	Change=Modify=FALSE;
	Folder.SetSize(12);
}

CGeneral::~CGeneral()
{
}

void CGeneral::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGeneral)
	DDX_Control(pDX, IDC_SETUP, m_cSetting);
	DDX_Control(pDX, IDC_FOLDERLOCAL, m_cFoldLocal);
	DDX_Control(pDX, IDC_SPECIALFOLD, m_cSpecFold);
	DDX_Text(pDX, IDC_USERNAME, m_sUserName);
	DDX_Text(pDX, IDC_ORGNAME, m_sOrgName);
	DDX_Text(pDX, IDC_SYSVER, m_sSysVer);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGeneral, CPropertyPage)
	//{{AFX_MSG_MAP(CGeneral)
	ON_CBN_SELCHANGE(IDC_SPECIALFOLD, OnSelchangeSpecialfold)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHANGELOCAL, OnChangelocal)
	ON_CONTROL( CLBN_CHKCHANGE, IDC_SETUP, OnChange )
	ON_EN_CHANGE(IDC_ORGNAME, OnLChange)
	ON_BN_CLICKED(IDC_OPENSYSFOLDER, OnOpenSysfolder)
	ON_BN_CLICKED(IDC_RESTORESYSPATH, OnRestoreSysfolder)
	ON_WM_CTLCOLOR()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDBLCLK()
	ON_EN_CHANGE(IDC_SYSVER, OnLChange)
	ON_EN_CHANGE(IDC_USERNAME, OnLChange)
	ON_WM_SETCURSOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGeneral message handlers
BOOL CGeneral::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	RegEdit Reg;
	CString String,Str;	
	DWORD wordbuf;
	
	Reg.RootKey=HKEY_LOCAL_MACHINE;
	if (Reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion"))
	{
		
		Reg.ReadString("RegisteredOrganization",m_sOrgName);
		Reg.ReadString("RegisteredOwner",m_sUserName);
		Reg.ReadString("Version",m_sSysVer);
	}
	
	ITEMIDLIST Dir1;
	char Ddir[256];
	LPITEMIDLIST Dir=&Dir1;
	int i=0,Index;
	
	//�����ļ���
	if (Reg.GetStringValue(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows\\CurrentVersion","ProgramFilesDir",String))
	{
		Folder[i]=String;
		String.LoadString(IDS_PROGRAMFOLDER+i);
		Index=m_cSpecFold.AddString(String);
		m_cSpecFold.SetItemData(Index,i);
	}
	//�����ļ���
	i++;
	if (Reg.GetStringValue(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows\\CurrentVersion","CommonFilesDir",String))
	{
		Folder[i]=String;
		String.LoadString(IDS_PROGRAMFOLDER+i);
		Index=m_cSpecFold.AddString(String);
		m_cSpecFold.SetItemData(Index,i);
	}
	Reg.RootKey=HKEY_CURRENT_USER;
	Reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders");
	//�����ļ���
	i++;
	if (!Reg.ReadString("Desktop",String))
	{	 
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_DESKTOP,&Dir);
		::SHGetPathFromIDList(Dir,Ddir);
		String=Ddir;
	}
	Folder[i]=String;
	String.LoadString(IDS_PROGRAMFOLDER+i);
	Index=m_cSpecFold.AddString(String);
	m_cSpecFold.SetItemData(Index,i);
	//��ʼ�˵��ļ���
	i++;
	if (!Reg.ReadString("Start Menu",String))
	{
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_STARTMENU,&Dir);
		::SHGetPathFromIDList(Dir,Ddir);
		String=Ddir;
	}
	
	Folder[i]=String;
	String.LoadString(IDS_PROGRAMFOLDER+i);
	Index=m_cSpecFold.AddString(String);
	m_cSpecFold.SetItemData(Index,i);
	
	//�ղؼ�
	i++;
	if (Reg.ReadString("Favorites",String))
	{
		Folder[i]=String;
		String.LoadString(IDS_PROGRAMFOLDER+i);
		Index=m_cSpecFold.AddString(String);
		m_cSpecFold.SetItemData(Index,i);
	}
	//�ҵ��ĵ�
	i++;
	if (!Reg.ReadString("Personal",String))
	{
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_PERSONAL,&Dir);
		::SHGetPathFromIDList(Dir,Ddir);
		String=Ddir;
    }
	Folder[i]=String;
	String.LoadString(IDS_PROGRAMFOLDER+i);
	Index=m_cSpecFold.AddString(String);
	m_cSpecFold.SetItemData(Index,i);
	//����ĵ�
	i++;
	if (!Reg.ReadString("Recent",String))
	{
		
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_RECENT,&Dir);
		::SHGetPathFromIDList(Dir,Ddir);
		String=Ddir;
	}
	Folder[i]=String;
	String.LoadString(IDS_PROGRAMFOLDER+i);
	Index=m_cSpecFold.AddString(String);
	m_cSpecFold.SetItemData(Index,i);
	//���͵�
	i++;
	if (!Reg.ReadString("SendTo",String))
	{
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_SENDTO,&Dir);
		::SHGetPathFromIDList(Dir,Ddir);
		String=Ddir;
	}
	Folder[i]=String;
	String.LoadString(IDS_PROGRAMFOLDER+i);
	Index=m_cSpecFold.AddString(String);
	m_cSpecFold.SetItemData(Index,i);
	//����
	i++;
	if (!Reg.ReadString("Startup",String))
	{
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_STARTUP,&Dir);
		::SHGetPathFromIDList(Dir,Ddir);
		String=Ddir;
	}
	Folder[i]=String;
	String.LoadString(IDS_PROGRAMFOLDER+i);
	Index=m_cSpecFold.AddString(String);
	m_cSpecFold.SetItemData(Index,i);
	//������
	i++;
	if (!Reg.ReadString("Programs",String))
	{
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_PROGRAMS,&Dir);
		::SHGetPathFromIDList(Dir,Ddir);
		String=Ddir;
	}
	Folder[i]=String;
	String.LoadString(IDS_PROGRAMFOLDER+i);
	Index=m_cSpecFold.AddString(String);
	m_cSpecFold.SetItemData(Index,i);
	//�ļ�ģ��
	i++;
	if (!Reg.ReadString("Templates",String))
	{
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_TEMPLATES,&Dir);
		::SHGetPathFromIDList(Dir,Ddir);
		String=Ddir;
	}
	Folder[i]=String;
	String.LoadString(IDS_PROGRAMFOLDER+i);
	Index=m_cSpecFold.AddString(String);
	m_cSpecFold.SetItemData(Index,i);

	//��װ·��
	i++;
	if (Reg.GetStringValue(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Setup","SourcePath",String))
	{
		Folder[i]=String;
		String.LoadString(IDS_PROGRAMFOLDER+i);
		Index=m_cSpecFold.AddString(String);
		m_cSpecFold.SetItemData(Index,i);
	}
	m_cSpecFold.SetCurSel(0);
	m_cFoldLocal.SetWindowText(Folder[0]);
	CurSel=0;
	/* �����б��� */
	BOOL  YesNo;
	i=0;
	//�˵����뷽ʽ 
	String.LoadString(IDS_MENUALIGNING);
	m_cSetting.AddString(String);
	::SystemParametersInfo(SPI_GETMENUDROPALIGNMENT,0,&YesNo,0);
	m_cSetting.SetCheck(i++,YesNo);
	//��������
	String.LoadString(IDS_WARNBEEP);
	m_cSetting.AddString(String);
	::SystemParametersInfo(SPI_GETBEEP,0,&YesNo,0);
	m_cSetting.SetCheck(i++,YesNo);
	//���ڶ���
	{
		ANIMATIONINFO WinAni;
		
		String.LoadString(IDS_WINDOWANI);
		m_cSetting.AddString(String);
		WinAni.cbSize=sizeof(WinAni);
		::SystemParametersInfo(SPI_GETANIMATION,0,&WinAni,0);
		m_cSetting.SetCheck(i++,(BOOL)WinAni.iMinAnimate);
	}
	//���ٹػ�
	{
		String.LoadString(IDS_FASTSHUTDOWN);
		m_cSetting.AddString(String);
		int FastBoot=0;

		if (Reg.GetStringValue(HKEY_LOCAL_MACHINE,"System\\CurrentControlSet\\control\\Shutdown","FastReboot",String))
		{
			FastBoot=atoi(String);
		}
		m_cSetting.SetCheck(i++,FastBoot);
	}
	//���ݹ����Զ�ִ��
	{
		char FlagChar;
		char StrValue[4];
		
		String.LoadString(IDS_AUTORUNDATACDROM);
		m_cSetting.AddString(String);
		Reg.GetBinaryValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer","NoDriveTypeAutoRun",StrValue);
		FlagChar=(StrValue[0]>>5)&1;
		m_cSetting.SetCheck(i++,!FlagChar);
	}
	//CD���Զ�ִ��
	{
		if (Reg.GetStringValue(HKEY_CLASSES_ROOT,"AudioCD\\Shell","",Str))
		{
			String.LoadString(IDS_AUTOPLAYCD);
			m_cSetting.AddString(String);
			m_cSetting.SetCheck(i++,(Str!=""));
		}
	}
	//ɾ����ݷ�ʽͼ���ϵļ�ͷ
	{
		DWORD RegType;
		String.LoadString(IDS_DELLNKARROW);
		m_cSetting.AddString(String);
		wordbuf=1;
		Reg.RootKey=HKEY_CLASSES_ROOT;
		if (Reg.OpenKey("piffile"))
		{
		 if (Reg.QueryValue("IsShortcut",RegType))
			 wordbuf=0;
		}
		if (Reg.OpenKey("lnkfile"))
		{
		 if (Reg.QueryValue("IsShortcut",RegType))
			 wordbuf=0;
		}
		m_cSetting.SetCheck(i++,(BOOL)wordbuf);
	}
	//�˳�ʱ�Զ�����ĵ��˵�
	{
		String.LoadString(IDS_EXITCLEANDOC);
		m_cSetting.AddString(String);
		if (!Reg.GetBinaryValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer","ClearRecentDocsOnExit",wordbuf))
			wordbuf=0;
		m_cSetting.SetCheck(i++,(BOOL)wordbuf);
	}
	//����������ʾWindows�汾��
	{
		String.LoadString(IDS_SHOWVERATDSK);
		m_cSetting.AddString(String);
		if (!Reg.GetStringValue(HKEY_CURRENT_USER,"Control Panel\\desktop","PaintDesktopVersion",Str))
			Str="0";
		m_cSetting.SetCheck(i++,(Str=="1"));		
	}
	//��Ļ�����Զ�����
	{
		String.LoadString(IDS_OFTENUPDATE);
		m_cSetting.AddString(String);
		if (!Reg.GetBinaryValue(HKEY_LOCAL_MACHINE,"System\\CurrentControlSet\\Control\\Update","UpdateMode",wordbuf))
			wordbuf=1;
		m_cSetting.SetCheck(i++,(BOOL)!wordbuf);
	}
	//�޸�������ʱ���ʽΪHHMM
	{
		String.LoadString(IDS_UPTIMEFORMAT);
		m_cSetting.AddString(String);
		if (!Reg.GetStringValue(HKEY_CURRENT_USER,"Control Panel\\International","sTimeFormat",Str))
			Str="HH:mm";
		m_cSetting.SetCheck(i++,(Str.CompareNoCase("HHmm")==0));
	}
	//ȡ�������������Թ���
	{
		String.LoadString(IDS_DISTASKATTRIB);
		m_cSetting.AddString(String);
		if (!Reg.GetDwordValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer","NoSetTaskbar",wordbuf))
			wordbuf=0;
		m_cSetting.SetCheck(i++,(BOOL)wordbuf);
	}

	UpdateData(FALSE);
	return TRUE; 
}

//ȷ���޸�
void CGeneral::OnOK() 
{
	if ( Modify )
	{
		RegEdit Reg;
		
		m_cFoldLocal.GetWindowText(Folder[CurSel]);
		Reg.RootKey=HKEY_LOCAL_MACHINE;
		if (Reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion"))
		{
			CString String;
			
			GetDlgItem(IDC_USERNAME)->GetWindowText(String);
			Reg.WriteString("RegisteredOwner",String);	
			GetDlgItem(IDC_ORGNAME)->GetWindowText(String);
			Reg.WriteString("RegisteredOrganization",String);			
			GetDlgItem(IDC_SYSVER)->GetWindowText(String);
			Reg.WriteString("Version",String);	
			
			if (!Folder[0].IsEmpty())
				Reg.WriteString("ProgramFilesDir",Folder[0]);
			if (!Folder[1].IsEmpty())
				Reg.WriteString("CommonFilesDir",Folder[1]);	
		}	
		Reg.RootKey=HKEY_CURRENT_USER;
		if (Reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders"))
		{
			char *StrKey[9]={"Desktop","Start Menu","Favorites","Personal","Recent","SendTo","Startup","Programs","Templates"};
			for (int i=0;i<9;i++)
			{
				if (!Folder[2+i].IsEmpty())
					Reg.WriteString(StrKey[i],Folder[2+i]);
			}
		}	 	
		Reg.SetStringValue(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Setup","SourcePath",Folder[11]);
		/* д�����б����и��� */
		int i=0;
		//�˵����뷽ʽ
		::SystemParametersInfo(SPI_SETMENUDROPALIGNMENT,m_cSetting.GetCheck(i++),NULL,SPIF_UPDATEINIFILE|SPIF_SENDCHANGE);
		//���淢��
		::SystemParametersInfo(SPI_SETBEEP,m_cSetting.GetCheck(i++),NULL,SPIF_UPDATEINIFILE|SPIF_SENDCHANGE);
		//���ڶ���
		{
			ANIMATIONINFO WinAni;
			WinAni.cbSize=sizeof(WinAni);
			WinAni.iMinAnimate=m_cSetting.GetCheck(i++);
			::SystemParametersInfo(SPI_SETANIMATION,0,&WinAni,SPIF_UPDATEINIFILE|SPIF_SENDCHANGE);
		}
		//���ٹػ�
		{
			int FastBoot=m_cSetting.GetCheck(i++);
			CString String;
			String.Format("%d",FastBoot);
			Reg.SetStringValue(HKEY_LOCAL_MACHINE,"System\\CurrentControlSet\\control\\Shutdown","FastReboot",String);
		}			
		//���ݹ����Զ�ִ��
		{
			char Flag[4],FlagChar;
			
			Reg.GetBinaryValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer","NoDriveTypeAutoRun",Flag);
			Flag[0]&=0xdf;
			FlagChar=(!m_cSetting.GetCheck(i++))<<5;
			Flag[0]|=FlagChar;
			Reg.SetBinaryValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer","NoDriveTypeAutoRun",Flag);
		}
		//CD���Զ�����
		{
			int Flag=m_cSetting.GetCheck(i++);
			CString Str;
			Str=Flag ? "Play":"";
			Reg.SetStringValue(HKEY_CLASSES_ROOT,"AudioCD\\Shell","",Str);
		}
		//ɾ����ݷ�ʽͼ���ϵļ�ͷ
		{
			BOOL Flag=m_cSetting.GetCheck(i++);
			
			Reg.RootKey=HKEY_CLASSES_ROOT;
			if (Reg.OpenKey("piffile"))
			{
				if (Flag)
					Reg.DeleteValue("IsShortcut");
				else
					Reg.WriteString("IsShortcut","");
			}
			if (Reg.OpenKey("lnkfile"))
			{
				if (Flag)
					Reg.DeleteValue("IsShortcut");
				else
					Reg.WriteString("IsShortcut","");
			}
		}	 		
		//�˳�ʱ�Զ�����ĵ��˵�
		{	
			Reg.SetBinaryValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer","ClearRecentDocsOnExit",(DWORD)m_cSetting.GetCheck(i++));
		}		
		//����������ʾWindows�汾��
		{
			CString Str;
			int Flag=m_cSetting.GetCheck(i++);
			Str=Flag ? "1":"0";
			Reg.SetStringValue(HKEY_CURRENT_USER,"Control Panel\\desktop","PaintDesktopVersion",Str);
		}
		//��Ļ�����Զ�����
		{
			Reg.SetBinaryValue(HKEY_LOCAL_MACHINE,"System\\CurrentControlSet\\Control\\Update","UpdateMode",(DWORD)!m_cSetting.GetCheck(i++));
		}			
		//�޸�������ʱ���ʽΪHHMM
		{
			Reg.SetStringValue(HKEY_CURRENT_USER,"Control Panel\\International","sTimeFormat",m_cSetting.GetCheck(i++) ? "HHmm":"HH:mm");
		}
		//ȡ�������������Թ���
		{
			Reg.SetDwordValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer","NoSetTaskbar",(DWORD)m_cSetting.GetCheck(i++));
		}	
	}
	Change=TRUE;
	CPropertyPage::OnOK();
}

//ѡ����Ͽ�����һϵͳ�ļ���
void CGeneral::OnSelchangeSpecialfold() 
{
    m_cFoldLocal.GetWindowText(Folder[CurSel]);
	int Index=m_cSpecFold.GetCurSel();
	if (Index==CB_ERR)
  	  return;
	CurSel=m_cSpecFold.GetItemData(Index);
	m_cFoldLocal.SetWindowText(Folder[CurSel]);
}

//�ı�ϵͳĿ¼
void CGeneral::OnChangelocal()
{
	CString Title;
	CString Dir;
	
	m_cSpecFold.GetLBText(m_cSpecFold.GetCurSel(),Title);
	Title="��ѡ��"+Title+"Ŀ¼:";
	m_cFoldLocal.GetWindowText(Dir);
	CFolderDialog FolderDialog(Dir,Title);
	if (FolderDialog.DoModal()==IDOK)
	{
		m_cFoldLocal.SetWindowText(FolderDialog.GetPathName());
		OnChange();
	}
}


void CGeneral::OnDestroy() 
{
	if (Change)
	{
		if ( ((CWinSetApp*)AfxGetApp())->GetModifyflag())
		{
			CString String;
			String.LoadString(IDS_APPCAPTION);
			RegEdit Reg;
			DWORD Prompt=TRUE,wordbuf;
			if (Reg.GetDwordValue(HKEY_CURRENT_USER,"SoftWare\\XKSoft\\WinSet","PromptReboot",wordbuf))
				Prompt=wordbuf;
			
			if (Prompt)
			{
				if (MessageBox("�����޸��� Windows ����,��Щ����ѡ����Ҫ����\n���� Windows �������Ч,�Ƿ��������������� ?",String,MB_YESNO|MB_ICONQUESTION)==IDYES)
				{
					ExitWindowsEx(EWX_SHUTDOWN|EWX_REBOOT,0);
				}
			}
		}
	}

	CPropertyPage::OnDestroy();
		
}

void CGeneral::OnLChange() 
{
	SetModified(TRUE);
	Modify=TRUE;	
}

void CGeneral::OnChange() 
{
	((CWinSetApp *)AfxGetApp())->SetModifyflag();
	SetModified(TRUE);
	Modify=TRUE;
}

//��ϵͳ�ļ���
void CGeneral::OnOpenSysfolder() 
{
	CString Folder;

	m_cFoldLocal.GetWindowText(Folder);
	::ShellExecute(NULL,"explore",Folder,NULL,NULL,SW_SHOW);	
}

//�ָ�ԭĬ��ϵͳ�ļ���
void CGeneral::OnRestoreSysfolder() 
{
	CString Folder,SrcFolder;
	char SysDir[MAX_PATH];
	GetWindowsDirectory(SysDir,512);
	m_cFoldLocal.GetWindowText(SrcFolder);
	
	Folder=SysDir;
	Folder+="\\";
	switch (CurSel)
	{
	case 0:
		Folder="C:\\Program Files";
		break;
	case 1:
		Folder="C:\\Program Files\\Common Files";
		break;
	case 2:
		Folder+="Desktop";
		break;
	case 3:
		Folder+="Start Menu";
		break;
	case 4:
		Folder+="Favorites";
		break;
	case 5:
		Folder="C:\\My Documents";
		break;
	case 6:
		Folder+="Recent";
		break;
	case 7:
		Folder+="SendTo";
		break;
	case 8:
		Folder+="Start Menu\\Programs\\����";
		break;
	case 9:
		Folder+="Start Menu\\Programs";
			break;
	case 10:
		Folder+="ShellNew";
		break;
	default:
		{
			
			Folder=SrcFolder;
		}
	}
    if (Folder!=SrcFolder)
	{
		m_cFoldLocal.SetWindowText(Folder);
		OnChange();
	}
}

//������ɫ
HBRUSH CGeneral::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CPropertyPage::OnCtlColor(pDC, pWnd, nCtlColor);
	
	int	FrmIDs[]={IDC_SETFRM,IDC_SYSFOLDERFRM,IDC_USERINFOFRM};
	for (int i=0;i<sizeof(FrmIDs)/sizeof(int);i++)
	{
	 if (*GetDlgItem(FrmIDs[i])==*(pWnd))
	 {
		pDC->SetTextColor(GetSysColor(COLOR_HIGHLIGHT));
		break;
	 }
	}
	return hbr;
}

void CGeneral::OnMouseMove(UINT nFlags, CPoint point) 
{
	int IDs[]={	  IDC_SYSVERST,IDC_USERNAMEST,IDC_COMPANYNAMEST,IDC_SPECIALFOLDST,IDC_FOLDERLOCALST};
	int StrIDs[]={IDS_SYSVERST,IDS_USERNAMEST,IDS_COMPANYNAMEST,IDS_SPECIALFOLD,IDS_FOLDERLOCAL};
	
	CRect rc;
	CString Str;
	bool Prompt=FALSE;
	for (int i=0;i<sizeof(IDs)/sizeof(int);i++)
	{
		GetDlgItem(IDs[i])->GetWindowRect(&rc);
		ScreenToClient(&rc);
		if (rc.PtInRect(point))
		{
			Str.LoadString(StrIDs[i]);
			((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
			Prompt=TRUE;
			break;
		}
	}
	if (!Prompt)
	{
		Str.LoadString(IDS_READY);
		((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
	}
	
	CPropertyPage::OnMouseMove(nFlags, point);
}

void CGeneral::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	//��ʾ����״̬��
	((CWinSetDlg*)AfxGetMainWnd())->ShowStatusBar();
	CPropertyPage::OnLButtonDblClk(nFlags, point);
}

BOOL CGeneral::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	int IDs[]={    IDC_SYSVER,  IDC_USERNAME,  IDC_ORGNAME,      IDC_CHANGELOCAL,    IDC_FOLDERLOCAL,IDC_SETUP,		 IDC_RESTORESYSPATH,IDC_OPENSYSFOLDER,IDC_SPECIALFOLD};
	UINT StrIDs[]={IDS_SYSVERST,IDS_USERNAMEST,IDS_COMPANYNAMEST,IDS_CHANGESYSFOLDER,IDS_FOLDERLOCAL,IDS_SETUPOPTION,IDS_RESTORESYSPATH,IDS_OPENSYSFOLDER,IDS_SPECIALFOLD};
	
	CRect rc;
	CString Str;
	bool Prompt=FALSE;
	for (int i=0;i<sizeof(IDs)/sizeof(int);i++)
	{
		if (*GetDlgItem(IDs[i])==*pWnd)
		{
			Str.LoadString(StrIDs[i]);
			((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
			Prompt=TRUE;
			break;
		}
	}
	
	return CPropertyPage::OnSetCursor(pWnd, nHitTest, message);
}
