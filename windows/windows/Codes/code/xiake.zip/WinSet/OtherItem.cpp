// OtherItem.cpp : implementation file
//

#include "stdafx.h"
#include "winset.h"
#include "OtherItem.h"
#include "RegEdit.h"
#include "FolderDialog.h"
#include "WinSetDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COtherItem property page

IMPLEMENT_DYNCREATE(COtherItem, CPropertyPage)

COtherItem::COtherItem() : CPropertyPage(COtherItem::IDD)
{
	m_psp.dwFlags &= ~(PSP_HASHELP);
	//m_psp.dwFlags |=PSP_USEHICON ;
	//m_psp.hIcon=AfxGetApp()->LoadIcon(IDI_OTHERITEM);

	Modify=FALSE;
	
	//{{AFX_DATA_INIT(COtherItem)
	m_bDisableBackPage = FALSE;
	m_bDisableDevicePage = FALSE;
	m_bDisableDisplay = FALSE;
	m_bDisableFilesysBtn = FALSE;
	m_bDisableGuisePage = FALSE;
	m_bDisableHardsetPage = FALSE;
	m_bDisableScrPage = FALSE;
	m_bDisableVirmemBtn = FALSE;
	m_bDisableUsedos = FALSE;
	m_bDisableUseregedit = FALSE;
	m_sCloseAppWaitTime = _T("10000");
	m_sIETitle = _T("Microsoft Internet Explorer");
	m_sOutlookMailPath = _T("");
	m_bDisableSetPage = FALSE;
	//}}AFX_DATA_INIT
}

COtherItem::~COtherItem()
{
}

void COtherItem::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COtherItem)
	DDX_Check(pDX, IDC_DISABLEBACKPAGE, m_bDisableBackPage);
	DDX_Check(pDX, IDC_DISABLEDEVICEPAGE, m_bDisableDevicePage);
	DDX_Check(pDX, IDC_DISABLEDISPLAY, m_bDisableDisplay);
	DDX_Check(pDX, IDC_DISABLEFILESYSBTN, m_bDisableFilesysBtn);
	DDX_Check(pDX, IDC_DISABLEGUISEPAGE, m_bDisableGuisePage);
	DDX_Check(pDX, IDC_DISABLEHARDSETPAGE, m_bDisableHardsetPage);
	DDX_Check(pDX, IDC_DISABLESCRPAGE, m_bDisableScrPage);
	DDX_Check(pDX, IDC_DISABLEVIRMEMBTN, m_bDisableVirmemBtn);
	DDX_Check(pDX, IDC_DISABLEUSEDOS, m_bDisableUsedos);
	DDX_Check(pDX, IDC_DISABLEUSEREGEDIT, m_bDisableUseregedit);
	DDX_Text(pDX, IDC_CLOSENORESAPP, m_sCloseAppWaitTime);
	DDV_MaxChars(pDX, m_sCloseAppWaitTime, 7);
	DDX_Text(pDX, IDC_IEWINTITILE, m_sIETitle);
	DDV_MaxChars(pDX, m_sIETitle, 255);
	DDX_Text(pDX, IDC_OUTLOOKMAILPATH, m_sOutlookMailPath);
	DDV_MaxChars(pDX, m_sOutlookMailPath, 256);
	DDX_Check(pDX, IDC_DISABLESETPAGE, m_bDisableSetPage);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COtherItem, CPropertyPage)
//{{AFX_MSG_MAP(COtherItem)
	ON_EN_CHANGE(IDC_CLOSENORESAPP, OnChange)
ON_BN_CLICKED(IDC_DISABLEUSEREGEDIT, OnLChange)
	ON_BN_CLICKED(IDC_BROWSEPATH, OnBrowsepath)
	ON_WM_CTLCOLOR()
	ON_WM_LBUTTONDBLCLK()
ON_BN_CLICKED(IDC_DISABLEUSEDOS, OnLChange)
ON_BN_CLICKED(IDC_DISABLEBACKPAGE, OnLChange)
ON_BN_CLICKED(IDC_DISABLEDEVICEPAGE, OnLChange)
ON_BN_CLICKED(IDC_DISABLEDISPLAY, OnLChange)
ON_BN_CLICKED(IDC_DISABLEFILESYSBTN, OnLChange)
ON_BN_CLICKED(IDC_DISABLEGUISEPAGE, OnLChange)
ON_BN_CLICKED(IDC_DISABLEHARDSETPAGE, OnLChange)
ON_BN_CLICKED(IDC_DISABLESCRPAGE, OnLChange)
ON_BN_CLICKED(IDC_DISABLEVIRMEMBTN, OnLChange)
	ON_EN_CHANGE(IDC_IEWINTITILE, OnLChange)
	ON_EN_CHANGE(IDC_OUTLOOKMAILPATH, OnLChange)
	ON_BN_CLICKED(IDC_DISABLESETPAGE, OnLChange)
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COtherItem message handlers

void COtherItem::OnChange() 
{
	((CWinSetApp *)AfxGetApp())->SetModifyflag();
	SetModified(TRUE);	
	Modify=TRUE;	
}

void COtherItem::OnLChange() 
{
	SetModified(TRUE);	
	Modify=TRUE;
	
}

BOOL COtherItem::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	RegEdit Reg;
	DWORD wordbuf;
	CString String;
	
	Reg.RootKey=HKEY_CURRENT_USER;
	if (Reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"))
	{
		if (Reg.ReadDword("NoDevMgrPage",wordbuf))
			m_bDisableDevicePage=wordbuf;
		if (Reg.ReadDword("NoConfigPage",wordbuf))
			m_bDisableHardsetPage=wordbuf;
		if (Reg.ReadDword("NoFileSysPage",wordbuf))
			m_bDisableFilesysBtn=wordbuf;
		if (Reg.ReadDword("NoVirtMemPage",wordbuf))
			m_bDisableVirmemBtn=wordbuf;
		
		if (Reg.ReadDword("NoDispCPL",wordbuf))
			m_bDisableDisplay=wordbuf;
		if (Reg.ReadDword("NoDispScrsavPage",wordbuf))
			m_bDisableScrPage=wordbuf;
		if (Reg.ReadDword("NoDispAppearancePage",wordbuf))
			m_bDisableGuisePage=wordbuf;
		if (Reg.ReadDword("NoDispBackgroundPage",wordbuf))
			m_bDisableBackPage=wordbuf;
		if (Reg.ReadDword("NoDispSettingsPage",wordbuf))
			m_bDisableSetPage=wordbuf;
		
		//��ֹʹ��RegEdit
		if (Reg.ReadDword("DisableRegistryTools",wordbuf))
			m_bDisableUseregedit=wordbuf;
	}
	//��ֹʹ��MS-DOS
	if (Reg.GetDwordValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\WinOldApp","Disabled",wordbuf))
		m_bDisableUsedos=wordbuf;
	//�رա��޷�ӦӦ�ó��򡱵ĵȴ�ʱ��
	if (Reg.GetStringValue(HKEY_CURRENT_USER,"Control Panel\\desktop","WaitToKillAppTimeOut",String))
		m_sCloseAppWaitTime=String;
	//IE���ڱ���
	if (Reg.GetStringValue(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Internet Explorer\\Main","Window Title",String))
		m_sIETitle=String;
	//Outlook Express �ʼ������Ŵ��·��
	if (Reg.GetStringValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Outlook Express","Store Root",String))
		m_sOutlookMailPath=String;
	UpdateData(FALSE);
	
	return TRUE; 
}

void COtherItem::OnOK() 
{
	RegEdit Reg;
	
	if (Modify)
	{
		Reg.RootKey=HKEY_CURRENT_USER;
		if (Reg.CreateKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"))
		{
			Reg.WriteDword("NoDevMgrPage",m_bDisableDevicePage);
			Reg.WriteDword("NoConfigPage",m_bDisableHardsetPage);
			Reg.WriteDword("NoFileSysPage",m_bDisableFilesysBtn);
			Reg.WriteDword("NoVirtMemPage",m_bDisableVirmemBtn);
			
			Reg.WriteDword("NoDispCPL",	m_bDisableDisplay);
			Reg.WriteDword("NoDispScrsavPage",m_bDisableScrPage);
			Reg.WriteDword("NoDispAppearancePage",m_bDisableGuisePage);				
			Reg.WriteDword("NoDispBackgroundPage",m_bDisableBackPage);
			Reg.WriteDword("NoDispSettingsPage",m_bDisableSetPage);

			
			//��ֹʹ��RegEdit
			Reg.WriteDword("DisableRegistryTools",m_bDisableUseregedit);
			
		}
		Reg.SetDwordValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\WinOldApp","Disabled",m_bDisableUsedos);
		Reg.SetStringValue(HKEY_CURRENT_USER,"Control Panel\\desktop","WaitToKillAppTimeOut",m_sCloseAppWaitTime);
		{
			//IE���ڱ���
			Reg.RootKey=HKEY_LOCAL_MACHINE;
			if (Reg.OpenKey("Software\\Microsoft\\Internet Explorer\\Main"))
			{
				Reg.WriteString("Window Title",m_sIETitle);
			}
		}
		{
			//Outlook Express �ʼ������Ŵ��·��
			Reg.RootKey=HKEY_CURRENT_USER;
			if (Reg.OpenKey("Software\\Microsoft\\Outlook Express"))
			{
				Reg.WriteString("Store Root",m_sOutlookMailPath);
			}
		}
	}  	
	CPropertyPage::OnOK();
}

//���ѡ��Outlook Express �ʼ������Ŵ���ļ���
void COtherItem::OnBrowsepath() 
{
	CString Title;
	CString Dir;
	
	UpdateData();
	Title="��ѡ�� Outlook Express �ʼ������Ŵ���ļ���:";
	CFolderDialog FolderDialog(m_sOutlookMailPath,Title);
	if (FolderDialog.DoModal()==IDOK)
	{
		GetDlgItem(IDC_OUTLOOKMAILPATH)->SetWindowText(FolderDialog.GetPathName());
	}
}

HBRUSH COtherItem::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CPropertyPage::OnCtlColor(pDC, pWnd, nCtlColor);

	int	FrmIDs[]={IDC_DISSYSFUNFRM,IDC_DISLISTFUNFRM,IDC_DISABLEITEMFRM};

	for (int i=0;i<sizeof(FrmIDs)/sizeof(int);i++)
	{
	 if (*GetDlgItem(FrmIDs[i])==*(pWnd))
	 {
		pDC->SetTextColor(GetSysColor(COLOR_HIGHLIGHT));
		break;
	 }
	}

	return hbr;
}

void COtherItem::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	//��ʾ����״̬��
	((CWinSetDlg*)AfxGetMainWnd())->ShowStatusBar();
	
	CPropertyPage::OnLButtonDblClk(nFlags, point);
}

void COtherItem::OnMouseMove(UINT nFlags, CPoint point) 
{
	CString Str;
	Str.LoadString(IDS_READY);
	((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
	
	CPropertyPage::OnMouseMove(nFlags, point);
}
