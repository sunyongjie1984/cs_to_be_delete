#if !defined(AFX_STARTMENU_H__C62226F2_5FD7_11D2_8573_ECD904C10000__INCLUDED_)
#define AFX_STARTMENU_H__C62226F2_5FD7_11D2_8573_ECD904C10000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// StartMenu.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CStartMenu dialog

class CStartMenu : public CPropertyPage
{
	DECLARE_DYNCREATE(CStartMenu)

// Construction
public:
	CStartMenu();
	~CStartMenu();
	int MenuSpeed;

// Dialog Data
	//{{AFX_DATA(CStartMenu)
	enum { IDD = IDD_STARTMENU };
	CCheckListBox	m_cAddmenuList;
	CSliderCtrl	m_cMenuSpeed;
	BOOL	m_bRunMenu;
	BOOL	m_bDocMenu;
	BOOL	m_bFavoritesMenu;
	BOOL	m_bCloseSystem;
	BOOL	m_bFindMenu;
	BOOL	m_bLogoffMenu;
	BOOL	m_bExitToDos;
	BOOL	m_bDisableDocrun;
	BOOL	m_bNoConPrn;
	BOOL	m_bCleanDochist;
	BOOL	m_bCleanRunhist;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CStartMenu)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	bool Modify;
	// Generated message map functions
	//{{AFX_MSG(CStartMenu)
	virtual BOOL OnInitDialog();
	afx_msg void OnChange();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnLChange();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STARTMENU_H__C62226F2_5FD7_11D2_8573_ECD904C10000__INCLUDED_)
