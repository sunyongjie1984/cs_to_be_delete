// StartrunProg.cpp : ����ʱ�Զ����еĳ���
//����ϵͳ�޸��� 1.0b
//�������������ҡ�http://xksoft.yeah.net
//���ߣ������� xksoft@yeah.net


#include "stdafx.h"
#include "winset.h"
#include "StartrunProg.h"
#include "RegEdit.h"
#include "WinSetDlg.h"
#include <direct.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStartrunProg property page

IMPLEMENT_DYNCREATE(CStartrunProg, CPropertyPage)

CStartrunProg::CStartrunProg() : CPropertyPage(CStartrunProg::IDD)
{
	m_psp.dwFlags &= ~(PSP_HASHELP);
	Modify=FALSE;
	//m_psp.dwFlags |=PSP_USEHICON ;
	//m_psp.hIcon=AfxGetApp()->LoadIcon(IDI_START);
	
	//{{AFX_DATA_INIT(CStartrunProg)
	m_sStartDlgTitle = _T("");
	m_sStartDlgType = _T("");
	m_sStartprogCom = _T("");
	//}}AFX_DATA_INIT
	Loop=0;
}

CStartrunProg::~CStartrunProg()
{
}

void CStartrunProg::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStartrunProg)
	DDX_Control(pDX, IDC_STARTRUN, m_cStartProg);
	DDX_Text(pDX, IDC_STARTDLGTITLE, m_sStartDlgTitle);
	DDV_MaxChars(pDX, m_sStartDlgTitle, 128);
	DDX_Text(pDX, IDC_STARTDLGTYPE, m_sStartDlgType);
	DDV_MaxChars(pDX, m_sStartDlgType, 255);
	DDX_Text(pDX, IDC_STARTPROGCOM, m_sStartprogCom);
	DDV_MaxChars(pDX, m_sStartprogCom, 255);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStartrunProg, CPropertyPage)
//{{AFX_MSG_MAP(CStartrunProg)
	ON_BN_CLICKED(IDC_APPEND, OnAppend)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_CONTROL( CLBN_CHKCHANGE, IDC_STARTRUN, OnChange )
	ON_WM_CTLCOLOR()
	ON_WM_LBUTTONDBLCLK()
	ON_LBN_SELCHANGE(IDC_STARTRUN, OnSelchangeStartrun)
	ON_BN_CLICKED(IDC_CHANGESTARTPROG, OnChangeStartprog)
	ON_EN_CHANGE(IDC_STARTDLGTITLE, OnChange)
	ON_EN_CHANGE(IDC_STARTDLGTYPE, OnChange)
	ON_EN_CHANGE(IDC_STARTPROGCOM, OnChange)
	ON_WM_SETCURSOR()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStartrunProg message handlers

//����һ�������г���
void CStartrunProg::OnAppend() 
{
	
	CString Filter="��ִ���ļ�(*.exe) |*.exe|�����ļ�(*.*)|*.*||";
	AutoRunProg NewItem;
	
	CFileDialog dlgOpenFile(TRUE,0,0,OFN_HIDEREADONLY|OFN_FILEMUSTEXIST,(LPCTSTR)Filter);
	
	if (dlgOpenFile.DoModal()!=IDOK)
		return;
	NewItem.Valname=dlgOpenFile.GetFileTitle();
	NewItem.Value=dlgOpenFile.GetPathName();
	NewItem.Exist=1;
	NewItem.Enable=TRUE;
	NewItem.Type=0;
    AutoRunprogs.Add(NewItem);
	int Index=m_cStartProg.AddString(NewItem.Valname);
	m_cStartProg.SetCheck(Index,TRUE);
	m_cStartProg.SetItemData(Index,Loop++);
	((CWinSetApp*)AfxGetApp())->SetListboxWidth(m_cStartProg);
	OnChange();
	
}

//ɾ��һ�������г���
void CStartrunProg::OnDelete() 
{
	int Index=m_cStartProg.GetCurSel();
	if (Index==LB_ERR)
		return;
	CString ProgItem;
	m_cStartProg.GetText(Index,ProgItem);
	if (MessageBox("�Ƿ�ɾ��������ʱ�Զ����еĳ����� ?",ProgItem,MB_YESNO|MB_ICONQUESTION)==IDNO)
		return;

	m_cStartProg.DeleteString(Index); 
	if (Index<0 || Index>=m_cStartProg.GetCount())
		Index=m_cStartProg.GetCount()-1;
	m_cStartProg.SetCurSel(Index);
	OnSelchangeStartrun();
	((CWinSetApp*)AfxGetApp())->SetListboxWidth(m_cStartProg);
	OnChange();
}

BOOL CStartrunProg::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	RegEdit Reg;
	char String[256],Str[256];
	int i,j,Index;
	AutoRunProg Item;
	
    //������Run,RunServices��
	Reg.RootKey=HKEY_LOCAL_MACHINE;
    char *StrKey[]={"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run","SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunServices"};
	for (j=0;j<2;j++)
	{
		if (Reg.OpenKey(StrKey[j]))
		{
			i=Reg.FirstEnumValue(String,Str);
			while (i)
			{
				Item.Valname=String;
				Item.Value=Str;
				Item.Type=j;
				Item.Exist=1;
				Item.Enable=TRUE;
				AutoRunprogs.Add(Item);
				Index=m_cStartProg.AddString(String);
				m_cStartProg.SetCheck(Index,TRUE);
				m_cStartProg.SetItemData(Index,Loop++);
				i=Reg.NextEnumValue(String,Str);
			}
		}	 
	}
	//��ֹ��Run,RunServices��
	Reg.RootKey=HKEY_LOCAL_MACHINE;
    char *StrKey1[]={"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run-","SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunServices-"};
	for (j=0;j<2;j++)
	{
		if (Reg.OpenKey(StrKey1[j]))
		{
			i=Reg.FirstEnumValue(String,Str);
			while (i)
			{
				Item.Valname=String;
				Item.Value=Str;
				Item.Type=j;
				Item.Exist=1;
				Item.Enable=FALSE;
				AutoRunprogs.Add(Item);
				Index=m_cStartProg.AddString(String);
				m_cStartProg.SetCheck(Index,FALSE);
				m_cStartProg.SetItemData(Index,Loop++);
				i=Reg.NextEnumValue(String,Str);
			}
		}	 
	}
	//HKEY_CURRENT_USER��RUN
    Reg.RootKey=HKEY_CURRENT_USER;
	char *StrKeya[2];
	StrKeya[0]=StrKey[0];
	StrKeya[1]=StrKey1[0];
	for (j=0;j<2;j++)
	{
		if (Reg.OpenKey(StrKeya[j]))
		{
			i=Reg.FirstEnumValue(String,Str);
			while (i)
			{
				Item.Valname=String;
				Item.Value=Str;
				Item.Type=2;
				Item.Exist=1;
				Item.Enable=!j;
				AutoRunprogs.Add(Item);
				Index=m_cStartProg.AddString(String);
				m_cStartProg.SetCheck(Index,Item.Enable);
				m_cStartProg.SetItemData(Index,Loop++);
				i=Reg.NextEnumValue(String,Str);
			}
		}	 
	}
    //��ʼ�˵�������
	ITEMIDLIST Dir1;
	LPITEMIDLIST Dir=&Dir1;    
	char StrKey2[2][MAX_PATH];
	::SHGetSpecialFolderLocation(m_hWnd,CSIDL_STARTUP,&Dir);
	::SHGetPathFromIDList(Dir,Str);
	strcpy(StrKey2[0],Str);
	::SHGetSpecialFolderLocation(m_hWnd,CSIDL_PROGRAMS,&Dir);
	::SHGetPathFromIDList(Dir,Str);
	strcpy(StrKey2[1],Str);
	
	strcat(StrKey2[0],"\\*.*");
	strcat(StrKey2[1],"\\�ѽ��õġ���������Ŀ\\*.*");
	CFileFind ff;
	for (j=0;j<2;j++)
	{
		i=ff.FindFile(StrKey2[j]);
		while (i)
		{
			i=ff.FindNextFile();
			Item.Valname=ff.GetFileTitle();
			if (Item.Valname=="" || Item.Valname==".")
				continue;
			Item.Value=ff.GetFilePath();
			Item.Type=3;
			Item.Exist=1;
			Item.Enable=!j;
			AutoRunprogs.Add(Item);
			Index=m_cStartProg.AddString(Item.Valname);
			m_cStartProg.SetCheck(Index,j==0 ? TRUE:FALSE);
			m_cStartProg.SetItemData(Index,Loop++);			
		}	
		
	}
	
	//����ʱ��ʾ�Ի���
	if (Reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Winlogon"))
	{
		Reg.ReadString("LegalNoticeCaption",m_sStartDlgTitle);
		Reg.ReadString("LegalNoticeText",m_sStartDlgType);
	}
	m_cStartProg.SetCurSel(m_cStartProg.GetCount()-1);
	((CWinSetApp*)AfxGetApp())->SetListboxWidth(m_cStartProg);
	UpdateData(FALSE);
	OnSelchangeStartrun();
	return TRUE;                
}


void CStartrunProg::OnOK() 
{
	if (Modify)
	{
		RegEdit Reg;
		int Index;
		bool Enable;
		for (int i=0;i<m_cStartProg.GetCount();i++)
		{
			
			Index=m_cStartProg.GetItemData(i);
            Enable=(bool)m_cStartProg.GetCheck(i);
			WriteStartprog(AutoRunprogs[Index],Enable);
			AutoRunprogs[Index].Exist=0;
		}
		//ɾ����
		for (i=0;i<AutoRunprogs.GetSize();i++)
		{
			if ( AutoRunprogs[i].Exist )
			{
				RemoveStartprog(AutoRunprogs[i]);
			}
			else
				AutoRunprogs[i].Exist=1;
		}
		char Str[MAX_PATH];
		ITEMIDLIST Dir1;
		LPITEMIDLIST Dir=&Dir1;    
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_PROGRAMS,&Dir);
		::SHGetPathFromIDList(Dir,Str);
		strcat(Str,"\\�ѽ��õġ���������Ŀ\\");
		_rmdir(Str);
	}
	
	CPropertyPage::OnOK();
}

void CStartrunProg::OnChange() 
{
	((CWinSetApp *)AfxGetApp())->SetModifyflag();
	SetModified(TRUE);		
	Modify=TRUE;
}

HBRUSH CStartrunProg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CPropertyPage::OnCtlColor(pDC, pWnd, nCtlColor);
	
	int	FrmIDs[]={IDC_STARTDLGFRM};
	
	for (int i=0;i<sizeof(FrmIDs)/sizeof(int);i++)
	{
		if (*GetDlgItem(FrmIDs[i])==*(pWnd))
		{
			pDC->SetTextColor(GetSysColor(COLOR_HIGHLIGHT));
			break;
		}
	}
	
	return hbr;
}

void CStartrunProg::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	//��ʾ����״̬��
	((CWinSetDlg*)AfxGetMainWnd())->ShowStatusBar();
	
	CPropertyPage::OnLButtonDblClk(nFlags, point);
}

//�ı�ѡ���������г���ʱ��ʾ��Ϣ
void CStartrunProg::OnSelchangeStartrun() 
{
	UpdateData();
	int Index=m_cStartProg.GetCurSel();
	if (Index==LB_ERR)
		return;
	SelectStartprog=Index=m_cStartProg.GetItemData(Index);
	m_sStartprogCom=AutoRunprogs[Index].Value;
	UpdateData(FALSE);  	
	bool Enable=AutoRunprogs[Index].Type!=3;
	GetDlgItem(IDC_STARTPROGCOM)->EnableWindow(Enable);
	GetDlgItem(IDC_CHANGESTARTPROG)->EnableWindow(Enable);
}

//д�Զ����г�������
void CStartrunProg::WriteStartprog(AutoRunProg &Item, BOOL Enable)
{
	char *StrKey[]={"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run","SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunServices"};
	char *StrKey1[]={"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run-","SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunServices-"};
	if (Item.Type==3)
	{
		//��ʼ�˵�������
		char Str[MAX_PATH];
		ITEMIDLIST Dir1;
		LPITEMIDLIST Dir=&Dir1;    
		char StrKey2[2][MAX_PATH];
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_STARTUP,&Dir);
		::SHGetPathFromIDList(Dir,Str);
		strcpy(StrKey2[0],Str);
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_PROGRAMS,&Dir);
		::SHGetPathFromIDList(Dir,Str);
		strcpy(StrKey2[1],Str);
		strcat(StrKey2[0],"\\");
		strcat(StrKey2[1],"\\�ѽ��õġ���������Ŀ\\");
		_mkdir(StrKey2[1]);
		if (Enable!=Item.Enable)
		{
			CString String=Item.Value;
			int Index=String.ReverseFind('\\');
			String=String.Mid(Index+1);
			strcat(StrKey2[0],String);
			strcat(StrKey2[1],String);
			if (Item.Enable)
				MoveFile(StrKey2[0],StrKey2[1]);
			else
				MoveFile(StrKey2[1],StrKey2[0]);
			Item.Enable=Enable;
		}
	}
	else
	{
		int i=Item.Type;
		RegEdit Reg;
		HKEY Root;
		if (Item.Type==2)
		{
			Root=HKEY_CURRENT_USER;
			i=0;
		}
		else
			Root=HKEY_LOCAL_MACHINE;
		char *EnbKey=StrKey[i];
		char *DisKey=StrKey1[i];
		Reg.SetStringValue(Root,Enable ? EnbKey : DisKey,Item.Valname,Item.Value);
		if (Enable!=Item.Enable)
		  Reg.DeleteValue(Root, Enable ? DisKey : EnbKey,Item.Valname);
		Item.Enable=Enable;

	}	
}

//ɾ���Զ����г�����
void CStartrunProg::RemoveStartprog(AutoRunProg &Item)
{
	char *StrKey[]={"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run","SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunServices"};
	char *StrKey1[]={"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run-","SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunServices-"};
	if (Item.Type==3)
	{
		//��ʼ�˵�������
		char Str[MAX_PATH];
		ITEMIDLIST Dir1;
		LPITEMIDLIST Dir=&Dir1;    
		char StrKey2[2][MAX_PATH];
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_STARTUP,&Dir);
		::SHGetPathFromIDList(Dir,Str);
		strcpy(StrKey2[0],Str);
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_PROGRAMS,&Dir);
		::SHGetPathFromIDList(Dir,Str);
		strcpy(StrKey2[1],Str);
		strcat(StrKey2[0],"\\");
		strcat(StrKey2[1],"\\�ѽ��õġ���������Ŀ\\");
		_mkdir(StrKey2[1]);
		CString String=Item.Value;
		int Index=String.ReverseFind('\\');
		String=String.Mid(Index+1);
		strcat(StrKey2[0],String);
		strcat(StrKey2[1],String);
		
		
		if (Item.Enable)
		{			
			remove(StrKey2[0]);
		}
		else
			remove(StrKey2[1]);
	}
	else
	{
		RegEdit Reg;
		HKEY Root;
		int i=Item.Type;
		if (Item.Type==2)
		{
			Root=HKEY_CURRENT_USER;
			i=0;
		}
		else
			Root=HKEY_LOCAL_MACHINE;

		if (Item.Enable)
			Reg.DeleteValue(Root, StrKey[i],Item.Valname);
		else
			Reg.DeleteValue(Root, StrKey1[i],Item.Valname);
	}
}

//����ı��������г���
void CStartrunProg::OnChangeStartprog() 
{
	CString Filter="��ִ���ļ�(*.exe) |*.exe||",Str;
	
	
	CFileDialog dlgOpenFile(TRUE,0,0,OFN_HIDEREADONLY|OFN_FILEMUSTEXIST,(LPCTSTR)Filter);
    GetDlgItem(IDC_STARTPROGCOM)->GetWindowText(Str);
 	int Index=Str.ReverseFind('\\');
	if (Index!=-1)
	{
		Str=Str.Left(Index);
		dlgOpenFile.m_ofn.lpstrInitialDir=Str;
	}	
	if (dlgOpenFile.DoModal()!=IDOK)
		return;	
	Index=m_cStartProg.GetCurSel();
	if (Index==LB_ERR)
		return;
	Index=m_cStartProg.GetItemData(Index);
	AutoRunprogs[Index].Value=dlgOpenFile.GetPathName();	
	OnSelchangeStartrun();
}

BOOL CStartrunProg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	int IDs[]={    IDC_STARTRUN,IDC_APPEND,			IDC_DELETE,			IDC_CHANGESTARTPROG};
	UINT StrIDs[]={IDS_STARTRUN,IDS_APPENDSTARTPROG,IDS_DELETESTARTPROG,IDS_CHANGESTARTPROG};
	
	CRect rc;
	CString Str;
	bool Prompt=FALSE;
	for (int i=0;i<sizeof(IDs)/sizeof(int);i++)
	{
		if (*GetDlgItem(IDs[i])==*pWnd)
		{
			Str.LoadString(StrIDs[i]);
			((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
			Prompt=TRUE;
			break;
		}
	}

	
	return CPropertyPage::OnSetCursor(pWnd, nHitTest, message);
}

void CStartrunProg::OnMouseMove(UINT nFlags, CPoint point) 
{
	int IDs[]={	  IDC_STARTPROGCOMMAND};
	int StrIDs[]={IDS_STARTPROGCOMMAND};
	
	CRect rc;
	CString Str;
	bool Prompt=FALSE;
	for (int i=0;i<sizeof(IDs)/sizeof(int);i++)
	{
		GetDlgItem(IDs[i])->GetWindowRect(&rc);
		ScreenToClient(&rc);
		if (rc.PtInRect(point))
		{
			Str.LoadString(StrIDs[i]);
			((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
			Prompt=TRUE;
			break;
		}
	}
	if (!Prompt)
	{
		Str.LoadString(IDS_READY);
		((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
	}
	
	CPropertyPage::OnMouseMove(nFlags, point);
}
