//ע�����д��
//���ߣ�������

#ifndef HMHSTRDEFVALUE
#define HMHSTRDEFVALUE "hmhdef"
#define HMHDWORDDEFVALUE -33

class RegEdit
{
private:
	DWORD EnumLoop;		 
	HKEY m_hKey;
public:
	int QueryValue(LPCTSTR ValueKey,DWORD &ValueType);
	RegEdit();
	~RegEdit();
	HKEY RootKey;
	void SetKey(HKEY Key);
	int OpenKey();
	int OpenKey(LPCTSTR StrKey);
	int OpenKey(HKEY Key,LPCTSTR StrKey);
	int CloseKey();
	
	int CreateKey(LPCTSTR StrKey);
	int CreateKey(HKEY wKey,LPCTSTR StrKey);
	int DeleteKey(LPCTSTR StrKey);
	int DeleteKey(HKEY RootKey,LPCTSTR StrKey,LPCTSTR DelKey);

    int ReadString(LPCTSTR StrChildKey,CString &Value);
	int ReadDword(LPCTSTR StrChildKey,DWORD &Value);
	int ReadBinary(LPCTSTR StrChildKey,char *Value);
	int ReadBinary(LPCTSTR StrChildKey,DWORD &Value);

	int WriteString(LPCTSTR StrChildKey,LPCTSTR Value,CString DefValue=HMHSTRDEFVALUE);
	int WriteDword(LPCTSTR StrChildKey,DWORD Value,DWORD DefValue=HMHDWORDDEFVALUE);
	int WriteBinary(LPCTSTR StrChildKey,DWORD Value,DWORD DefValue=HMHDWORDDEFVALUE);
	int WriteBinary(LPCTSTR StrChildKey,const char *Value);

	int GetStringValue(HKEY RootKey,LPCTSTR StrKey,LPCTSTR StrChildKey,CString &Value);
	int GetDwordValue(HKEY RootKey,LPCTSTR StrKey,LPCTSTR StrChildKey,DWORD &Value);
	int GetBinaryValue(HKEY RootKey,LPCTSTR StrKey,LPCTSTR StrChildKey,DWORD &Value);
	int GetBinaryValue(HKEY RootKey,LPCTSTR StrKey,LPCTSTR StrChildKey,char *Value);

	int SetStringValue(HKEY RootKey,LPCTSTR StrKey,LPCTSTR StrChildKey,LPCTSTR Value,CString DefValue=HMHSTRDEFVALUE);
	int SetDwordValue(HKEY RootKey,LPCTSTR StrKey,LPCTSTR StrChildKey,DWORD Value,DWORD DefValue=HMHDWORDDEFVALUE);
	int SetBinaryValue(HKEY RootKey,LPCTSTR StrKey,LPCTSTR StrChildKey,DWORD Value,DWORD DefValue=HMHDWORDDEFVALUE);
	int SetBinaryValue(HKEY RootKey,LPCTSTR StrKey,LPCTSTR StrChildKey,const char *Value);

	int FirstEnumKey(char* Value);
	int NextEnumKey(char* Value);
	int FirstEnumValue(char *Value,void *data=NULL);
	int NextEnumValue(char *Value,void *Data=NULL);

	int DeleteValue(const char *Value);
	int DeleteValue(HKEY Root,LPCTSTR StrKey,LPCTSTR StrChildKey);

	BOOL WriteProfileString(LPCTSTR FileName,LPCTSTR SectionName,LPCTSTR KeyName,LPCTSTR Value,LPCTSTR DefValue=HMHSTRDEFVALUE);

};
#endif