#include "stdafx.h"
#include "RegEdit.h"
#include "HMHFunc.h"


RegEdit::RegEdit()
{
	m_hKey=NULL;
	RootKey=NULL;
}

RegEdit::~RegEdit()
{
	if (m_hKey!=NULL)
		::RegCloseKey(m_hKey);
}

void RegEdit::SetKey(HKEY Key)
{
	m_hKey=Key;
}

//��һע���
int RegEdit::OpenKey(LPCTSTR StrKey)
{
	if (RootKey==NULL)
		return 0;
	if (ERROR_SUCCESS==::RegOpenKeyEx(RootKey,StrKey,NULL,KEY_ALL_ACCESS,&m_hKey))
		return 1;
	return 0;
}

int RegEdit::OpenKey(HKEY Key,LPCTSTR StrKey)
{
	RootKey=Key;
	if (ERROR_SUCCESS==::RegOpenKeyEx(RootKey,StrKey,NULL,KEY_ALL_ACCESS,&m_hKey))
		return 1;
	return 0;
}

int RegEdit::OpenKey()
{
	if (RootKey==NULL)
		return 0;
	m_hKey=RootKey;
	return 1;
}

//�ر�ע���
int RegEdit::CloseKey()
{
	RootKey=NULL;
	if (ERROR_SUCCESS==::RegCloseKey(m_hKey))
		return 1;
	return 0;
}

//����һע���,����1�ɹ�������2�˼��Ѵ��ڲ���
int RegEdit::CreateKey(LPCTSTR StrKey)
{
	HKEY hKey;
    DWORD dwDisposition;
	
	if (m_hKey==NULL && RootKey!=NULL)
		m_hKey=RootKey;
	if (ERROR_SUCCESS!=::RegCreateKeyEx(m_hKey, (LPCTSTR)StrKey,0,NULL,
		REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,
		NULL,&hKey,&dwDisposition))
		return 0;
	else
	{
		m_hKey=hKey;
		if (dwDisposition==REG_CREATED_NEW_KEY)
			return 1;
		else if (dwDisposition==REG_OPENED_EXISTING_KEY)
			return 2;
	}				 
	return 1;
}

//����һע���,����1�ɹ�������2�˼��Ѵ��ڲ���
int RegEdit::CreateKey(HKEY wKey,LPCTSTR StrKey)
{	
	m_hKey=wKey;
	return CreateKey(StrKey);
}


//ɾ��һ��ֵ
int RegEdit::DeleteKey(LPCTSTR StrKey)
{
	if (HMHGetWindowVer()!=HMHWINDOWSNT)
	{
		if (ERROR_SUCCESS==::RegDeleteKey(m_hKey,StrKey))
			return 1;
	}
	//��Windows NT�����ֹ�ɾ�������Ӽ�
	else
	{
		HKEY SrcKey=m_hKey;
		char KeyName[256];
		int nRes=0;
				
		if (OpenKey(SrcKey,StrKey))
		{
			nRes=FirstEnumKey(KeyName);
			while (nRes)
			{
				DeleteKey(KeyName);
				nRes=NextEnumKey(KeyName);
			}
		}
		if (::RegDeleteKey(SrcKey,StrKey)==ERROR_SUCCESS)
			return 1;
		else
			return 0;		
	}
	return 0;
}

//ɾ��һ��ֵ
int RegEdit::DeleteKey(HKEY RootKey,LPCTSTR StrKey,LPCTSTR DelKey)
{
	if (OpenKey(RootKey,StrKey))
	{
		if (DeleteKey(DelKey))
			return 1;
		else
			return 0;
	}
	else
		return 0;
}

//ɾ��һ��ֵ
int RegEdit::DeleteValue(const char *Value)
{
	
	if (ERROR_SUCCESS==RegDeleteValue(m_hKey,Value))
		return 1;
	return 0;
}

//ɾ��һ��ֵ
int RegEdit::DeleteValue(HKEY Root,LPCTSTR StrKey,LPCTSTR StrChildKey)
{
	m_hKey=RootKey=Root;
	if (OpenKey(StrKey))
	{
		if (ERROR_SUCCESS==RegDeleteValue(m_hKey,StrChildKey))
			return 1;
		else
			return 0;
	}
	return 0;
}

//��һע����ַ���ֵ
int RegEdit::ReadString(LPCTSTR StrChildKey,CString &Value)
{
	DWORD dwSize=255,dwType=REG_SZ;
	char String[256];
	
	if (ERROR_SUCCESS!=::RegQueryValueEx(m_hKey,StrChildKey,0,&dwType,(BYTE *)String,&dwSize))
		return 0;
	Value=String;
	return 1;
}

//��һע���DWORDֵ
int RegEdit::ReadDword(LPCTSTR StrChildKey,DWORD &Value)
{
	DWORD dwSize=255,dwType=REG_DWORD;
	
	if (ERROR_SUCCESS!=::RegQueryValueEx(m_hKey,StrChildKey,0,&dwType,(BYTE *)(&Value),&dwSize))
		return 0;
	return 1;
}

//��һע���BINARYֵ
int RegEdit::ReadBinary(LPCTSTR StrChildKey,DWORD &Value)
{
	DWORD dwSize=255,dwType=REG_BINARY;
	
	if (ERROR_SUCCESS!=::RegQueryValueEx(m_hKey,StrChildKey,0,&dwType,(BYTE *)(&Value),&dwSize))
		return 0;
	return 1;					 
}

//��һע���BINARYֵ
int RegEdit::ReadBinary(LPCTSTR StrChildKey,char *Value)
{
	DWORD dwSize=255,dwType=REG_BINARY;
    
//	if (ERROR_SUCCESS!=::RegQueryValueEx(m_hKey,StrChildKey,0,&dwType,NULL,&dwSize))
//		return 0;	
	if (ERROR_SUCCESS!=::RegQueryValueEx(m_hKey,StrChildKey,0,&dwType,(BYTE *)Value,&dwSize))
		return 0;
	*(Value+dwSize)=0;
	return 1;					 
}


//дһע����ַ���ֵ
int RegEdit::WriteString(LPCTSTR StrChildKey,LPCTSTR Value,CString DefValue)
{
	if (DefValue!=HMHSTRDEFVALUE)
	{
		if (Value==DefValue)
			return DeleteValue(StrChildKey);
	}
	if (ERROR_SUCCESS==::RegSetValueEx( m_hKey,(LPCTSTR)StrChildKey,0,REG_SZ,(BYTE *)(LPCSTR)Value,strlen(Value)+1) )
		return 1;
	return 0;
}

//дһע���DWORDֵ
int RegEdit::WriteDword(LPCTSTR StrChildKey,DWORD Value,DWORD DefValue)
{
	if (DefValue!=HMHDWORDDEFVALUE)
	{
		if (Value==DefValue)
			return DeleteValue(StrChildKey);
	}
	if (ERROR_SUCCESS==::RegSetValueEx( m_hKey,(LPCTSTR)StrChildKey,0,REG_DWORD,(BYTE *)&Value,sizeof(Value)) )
		return 1;
	return 0;
}

//дһע���������ֵ
int RegEdit::WriteBinary(LPCTSTR StrChildKey,DWORD Value,DWORD DefValue)
{
	if (DefValue!=HMHDWORDDEFVALUE)
	{
		if (Value==DefValue)
			return DeleteValue(StrChildKey);
	}
	if (ERROR_SUCCESS==::RegSetValueEx( m_hKey,(LPCTSTR)StrChildKey,0,REG_BINARY,(BYTE *)&Value,sizeof(Value)) )
		return 1;
	return 0;
}

//дһע���������ֵ
int RegEdit::WriteBinary(LPCTSTR StrChildKey,const char *Value)
{
	if (ERROR_SUCCESS==::RegSetValueEx( m_hKey,(LPCTSTR)StrChildKey,0,REG_BINARY,(BYTE *)Value,strlen(Value)) )
		return 1;
	return 0;
}

int RegEdit::GetStringValue(HKEY Root,LPCTSTR StrKey,LPCTSTR StrChildKey,CString &Value)
{
	RootKey=Root;
	if (OpenKey(StrKey))
	{
		if (ReadString(StrChildKey,Value))
			return 1;
		return 0;
	}
	return 0;
}

int RegEdit::GetDwordValue(HKEY Root,LPCTSTR StrKey,LPCTSTR StrChildKey,DWORD &Value)
{
	RootKey=Root;
	if (OpenKey(StrKey))
	{
		if (ReadDword(StrChildKey,Value))
			return 1;
		return 0;
	}
	return 0;
}

int RegEdit::GetBinaryValue(HKEY Root,LPCTSTR StrKey,LPCTSTR StrChildKey,DWORD &Value)
{				
	RootKey=Root;
	if (OpenKey(StrKey))
	{
		if (ReadBinary(StrChildKey,Value))
			return 1;
		return 0;
	}
	return 0;
}

int RegEdit::GetBinaryValue(HKEY Root,LPCTSTR StrKey,LPCTSTR StrChildKey,char *Value)
{				
	RootKey=Root;
	if (OpenKey(StrKey))
	{
		if (ReadBinary(StrChildKey,Value))
			return 1;
		return 0;
	}
	return 0;
}

int RegEdit::SetStringValue(HKEY Root,LPCTSTR StrKey,LPCTSTR StrChildKey,LPCTSTR Value,CString DefValue)
{
	m_hKey=RootKey=Root;
	if (CreateKey(StrKey))
	{
		if (WriteString(StrChildKey,Value,DefValue))
			return 1;
		return 0;
	}
	return 0;
}

int RegEdit::SetDwordValue(HKEY Root,LPCTSTR StrKey,LPCTSTR StrChildKey,DWORD Value,DWORD DefValue)
{
	m_hKey=RootKey=Root;
	if (CreateKey(StrKey))
	{
		if (WriteDword(StrChildKey,Value,DefValue))
			return 1;
		return 0;
	}
	return 0;
}

int RegEdit::SetBinaryValue(HKEY Root,LPCTSTR StrKey,LPCTSTR StrChildKey,DWORD Value,DWORD DefValue)
{
	m_hKey=RootKey=Root;
	if (CreateKey(StrKey))
	{
		if (WriteBinary(StrChildKey,Value,DefValue))
			return 1;
		return 0;
	}
	return 0;
}

int RegEdit::SetBinaryValue(HKEY Root,LPCTSTR StrKey,LPCTSTR StrChildKey,const char *Value)
{
	m_hKey=RootKey=Root;
	if (CreateKey(StrKey))
	{
		if (WriteBinary(StrChildKey,Value))
			return 1;
		return 0;
	}
	return 0;
}

//ѭ����ȡ����
int RegEdit::FirstEnumKey(char *Value)
{
	DWORD dwSize=255;
	EnumLoop=0;
	
	if (ERROR_SUCCESS==::RegEnumKeyEx(m_hKey,EnumLoop,Value,&dwSize,NULL,NULL,NULL,NULL))
		return 1;
	return 0;
}

//��һ������  
int RegEdit::NextEnumKey(char *Value)
{
	DWORD dwSize=255;
	EnumLoop++;
	if (ERROR_SUCCESS==::RegEnumKeyEx(m_hKey,EnumLoop,Value,&dwSize,NULL,NULL,NULL,NULL))
		return 1;
	return 0;
}

//ѭ����ȡֵ��
int RegEdit::FirstEnumValue(char *Value,void *data)
{
	DWORD dwSize=255,dwType,dwDsize=255;;
	EnumLoop=0;
	
	if (ERROR_SUCCESS==::RegEnumValue(m_hKey,EnumLoop,Value,&dwSize,NULL,&dwType,(LPBYTE)data,&dwDsize))
		return 1;
	return 0;
}

//��һ��ֵ��
int RegEdit::NextEnumValue(char *Value,void *Data)
{
	DWORD dwSize=255,dwType,dwDsize=255;
	EnumLoop++;
	if (ERROR_SUCCESS==::RegEnumValue(m_hKey,EnumLoop,Value,&dwSize,NULL,&dwType,(LPBYTE)Data,&dwDsize))
		return 1;
	return 0;
}


//��ѯ��ֵ��Ϣ
int RegEdit::QueryValue(LPCTSTR ValueKey,DWORD &ValueType)
{
	if (ERROR_SUCCESS==::RegQueryValueEx(m_hKey,ValueKey,0,&ValueType,NULL,NULL))
		return 1;
	return 0;
}

//дINI�ļ��ַ���
BOOL RegEdit::WriteProfileString(LPCTSTR FileName,LPCTSTR SectionName,LPCTSTR KeyName,LPCTSTR Value,LPCTSTR DefValue)
{
	if (strcmp(DefValue,HMHSTRDEFVALUE))
	{
		if (strcmp(Value,DefValue)==0)
			return ::WritePrivateProfileString(SectionName,KeyName,NULL,FileName);
	}
	return ::WritePrivateProfileString(SectionName,KeyName,Value,FileName);
}
