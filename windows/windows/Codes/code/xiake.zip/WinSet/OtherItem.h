#if !defined(AFX_OTHERITEM_H__C47D3E83_D0EB_11D2_BEE7_D93B85BCBC27__INCLUDED_)
#define AFX_OTHERITEM_H__C47D3E83_D0EB_11D2_BEE7_D93B85BCBC27__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// OtherItem.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COtherItem dialog

class COtherItem : public CPropertyPage
{
	DECLARE_DYNCREATE(COtherItem)

// Construction
public:
	COtherItem();
	~COtherItem();

// Dialog Data
	//{{AFX_DATA(COtherItem)
	enum { IDD = IDD_OTHER };
	BOOL	m_bDisableBackPage;
	BOOL	m_bDisableDevicePage;
	BOOL	m_bDisableDisplay;
	BOOL	m_bDisableFilesysBtn;
	BOOL	m_bDisableGuisePage;
	BOOL	m_bDisableHardsetPage;
	BOOL	m_bDisableScrPage;
	BOOL	m_bDisableVirmemBtn;
	BOOL	m_bDisableUsedos;
	BOOL	m_bDisableUseregedit;
	CString	m_sCloseAppWaitTime;
	CString	m_sIETitle;
	CString	m_sOutlookMailPath;
	BOOL	m_bDisableSetPage;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(COtherItem)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	bool Modify;
	// Generated message map functions
	//{{AFX_MSG(COtherItem)
	virtual BOOL OnInitDialog();
	afx_msg void OnChange();
	afx_msg void OnLChange();
	afx_msg void OnBrowsepath();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OTHERITEM_H__C47D3E83_D0EB_11D2_BEE7_D93B85BCBC27__INCLUDED_)
