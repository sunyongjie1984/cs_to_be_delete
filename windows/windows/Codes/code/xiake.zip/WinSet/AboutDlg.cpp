// AboutDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WinSet.h"
#include "AboutDlg.h"
#include "RegEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog


CAboutDlg::CAboutDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAboutDlg::IDD, pParent)
{
	AppIcon.SetIcon(IDR_MAINFRAME);
	//{{AFX_DATA_INIT(CAboutDlg)
	m_sPasswordType = _T("");
	m_bUsePassword = FALSE;
	m_bAutoJmppage = TRUE;
	m_bExitPromptReboot = TRUE;
	//}}AFX_DATA_INIT
	m_hIcon=AfxGetApp()->LoadIcon(IDI_README);
}


void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_APPICON, AppIcon);
	DDX_Control(pDX, IDC_HOMEPAGE, m_cHomePage);
	DDX_Control(pDX, IDC_EMAILME, m_cEmailMe);
	DDX_Text(pDX, IDC_PASSINTPUT, m_sPasswordType);
	DDV_MaxChars(pDX, m_sPasswordType, 255);
	DDX_Check(pDX, IDC_USEPASSWORD, m_bUsePassword);
	DDX_Check(pDX, IDC_AUTOJMPPAGE, m_bAutoJmppage);
	DDX_Check(pDX, IDC_EXITPROMPTREBOOT, m_bExitPromptReboot);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_BN_CLICKED(IDHOMEPAGE, OnHomepage)
	ON_BN_CLICKED(IDMAILME, OnMailme)
	ON_BN_CLICKED(IDC_USEPASSWORD, OnUsepassword)
	ON_WM_CTLCOLOR()
	ON_WM_SYSCOMMAND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg message handlers

void CAboutDlg::OnHomepage() 
{
	::ShellExecute(m_hWnd,"Open","http://xksoft.yeah.net",NULL,NULL,SW_SHOWMAXIMIZED);
	
}

void CAboutDlg::OnMailme() 
{
	::ShellExecute(m_hWnd,"Open","Mailto:hmhu@126.com",NULL,NULL,SW_SHOW);		
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetIcon(m_hIcon,FALSE);
	SetIcon(m_hIcon,TRUE);
	m_cEmailMe.SetURL("mailto:hmhu@126.com","�����������������");
	m_cHomePage.SetTip("�����ߵ���ҳ�������°汾����");
	IsUsePass.Set(this,IDC_ISUSEPASS);

	RegEdit Reg;
	DWORD wordbuf;
	char Pass[256];
	Reg.RootKey=HKEY_CURRENT_USER;
	if (Reg.OpenKey("SoftWare\\XKSoft\\WinSet"))
	{
		if (Reg.ReadDword("UsePass",wordbuf))
			m_bUsePassword=wordbuf;
		if (Reg.ReadBinary("Public",Pass))
		{
			for (int i=0;i<strlen(Pass);i++)
				*(Pass+i)=~*(Pass+i);
			
			m_sPasswordType=Pass;
		}
		if (Reg.ReadDword("AutoJmppage",wordbuf))
			m_bAutoJmppage=wordbuf;
		if (Reg.ReadDword("PromptReboot",wordbuf))
			m_bExitPromptReboot=wordbuf;
	}
	IsUsePass.Enable(m_bUsePassword);
	UpdateData(FALSE);
	return TRUE;  
}

//�Ƿ�ʹ������ı�
void CAboutDlg::OnUsepassword() 
{
	UpdateData();
	IsUsePass.Enable(m_bUsePassword);
}

void CAboutDlg::OnOK() 
{	
	UpdateData();
	RegEdit Reg;
	char Pass[256];
	Reg.RootKey=HKEY_CURRENT_USER;
	if (Reg.CreateKey("SoftWare\\XKSoft\\WinSet"))
	{
		if (m_bUsePassword)
		{
			Reg.WriteDword("UsePass",m_bUsePassword);
			strcpy(Pass,m_sPasswordType);
			//�����ʽ��������
			for (int i=0;i<strlen(Pass);i++)
				*(Pass+i)=~*(Pass+i);
			Reg.WriteBinary("Public",Pass);
		}
		else
		{
			Reg.DeleteValue("UsePass");
			Reg.DeleteValue("Public");
		}
		Reg.WriteDword("AutoJmppage",m_bAutoJmppage);
		Reg.WriteDword("PromptReboot",m_bExitPromptReboot);
	}
	CDialog::OnOK();
}

HBRUSH CAboutDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	//���ó��������ɫ
	if (*pWnd==*GetDlgItem(IDC_PROGTITLE) || *pWnd==*GetDlgItem(IDC_XKSOFT) )
	{
		pDC->SetTextColor(RGB(255,0,0));
	}	
	if (*pWnd==*GetDlgItem(IDC_BY))
		pDC->SetTextColor(RGB(0, 128, 0));		 
	if (*pWnd==*GetDlgItem(IDC_USEPASSWORD))
		pDC->SetTextColor(GetSysColor(COLOR_HIGHLIGHT));
	return hbr;
}



void CAboutDlg::OnSysCommand(UINT nID, LPARAM lParam) 
{
	if (nID==SC_CLOSE)
	{
		OnOK();
		return;
	}	
	CDialog::OnSysCommand(nID, lParam);
}

void CAboutDlg::OnCancel() 
{	
	CDialog::OnCancel();
}
