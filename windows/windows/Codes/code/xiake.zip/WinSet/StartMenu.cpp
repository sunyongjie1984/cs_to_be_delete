// StartMenu.cpp : ��ʼ�˵�����
//����ϵͳ�޸��� 1.0b
//�������������ҡ�http://xksoft.yeah.net
//���ߣ������� xksoft@yeah.net


#include "stdafx.h"
#include "WinSet.h"
#include "StartMenu.h"
#include "RegEdit.h"
#include "WinSetDlg.h"

#include <shlobj.h>
#include <io.h>
#include <direct.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStartMenu property page

IMPLEMENT_DYNCREATE(CStartMenu, CPropertyPage)

CStartMenu::CStartMenu() : CPropertyPage(CStartMenu::IDD)
{
	m_psp.dwFlags &= ~(PSP_HASHELP);
	Modify=FALSE;
	//m_psp.dwFlags |=PSP_USEHICON ;
	//m_psp.hIcon=AfxGetApp()->LoadIcon(IDI_STARTMENU);

	//{{AFX_DATA_INIT(CStartMenu)
	m_bRunMenu = FALSE;
	m_bDocMenu = FALSE;
	m_bFavoritesMenu = FALSE;
	m_bCloseSystem = FALSE;
	m_bFindMenu = FALSE;
	m_bLogoffMenu = FALSE;
	m_bExitToDos = FALSE;
	m_bDisableDocrun = FALSE;
	m_bNoConPrn = FALSE;
	m_bCleanDochist = FALSE;
	m_bCleanRunhist = FALSE;
	//}}AFX_DATA_INIT
}

CStartMenu::~CStartMenu()
{
}

void CStartMenu::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStartMenu)
	DDX_Control(pDX, IDC_ADDMENULIST, m_cAddmenuList);
	DDX_Control(pDX, IDC_MENUSPEED, m_cMenuSpeed);
	DDX_Check(pDX, IDC_RUNMENU, m_bRunMenu);
	DDX_Check(pDX, IDC_DOCMENU, m_bDocMenu);
	DDX_Check(pDX, IDC_FAVORITESMENU, m_bFavoritesMenu);
	DDX_Check(pDX, IDC_CLOSESYSTEM, m_bCloseSystem);
	DDX_Check(pDX, IDC_FINDMENU, m_bFindMenu);
	DDX_Check(pDX, IDC_LOGOFF, m_bLogoffMenu);
	DDX_Check(pDX, IDC_EXITANDTODOS, m_bExitToDos);
	DDX_Check(pDX, IDC_DISABLEDOCMENU, m_bDisableDocrun);
	DDX_Check(pDX, IDC_NOCONPRN, m_bNoConPrn);
	DDX_Check(pDX, IDC_CLEANDOCHIST, m_bCleanDochist);
	DDX_Check(pDX, IDC_CLEANRUNHIST, m_bCleanRunhist);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStartMenu, CPropertyPage)
//{{AFX_MSG_MAP(CStartMenu)
ON_BN_CLICKED(IDC_CLOSESYSTEM, OnChange)
ON_WM_HSCROLL()
ON_CONTROL( CLBN_CHKCHANGE, IDC_ADDMENULIST, OnLChange )
	ON_WM_CTLCOLOR()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_SETCURSOR()
ON_BN_CLICKED(IDC_CLEANDOCHIST, OnLChange)
ON_BN_CLICKED(IDC_DOCMENU, OnChange)
ON_BN_CLICKED(IDC_FAVORITESMENU, OnChange)
ON_BN_CLICKED(IDC_RUNMENU, OnChange)
ON_BN_CLICKED(IDC_LOGOFF, OnChange)
ON_BN_CLICKED(IDC_FINDMENU, OnChange)
ON_BN_CLICKED(IDC_EXITANDTODOS, OnChange)
ON_BN_CLICKED(IDC_DISABLEDOCMENU, OnChange)
ON_BN_CLICKED(IDC_CLEANRUNHIST, OnChange)
	ON_BN_CLICKED(IDC_NOCONPRN, OnChange)
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStartMenu message handlers

BOOL CStartMenu::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	DWORD wordbuf;
	CString buf;
	RegEdit Reg;
	
	m_cMenuSpeed.SetRange(0,5000);
	m_cMenuSpeed.SetPageSize(500);
	m_cMenuSpeed.SetTicFreq(500);
	m_cMenuSpeed.SetLineSize(250);
	
	Reg.RootKey=HKEY_CURRENT_USER;
	if (Reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"))
	{
		if (Reg.ReadDword("NoRun",wordbuf))
			m_bRunMenu=wordbuf;
		if (Reg.ReadDword("NoRecentDocsmenu",wordbuf))
			m_bDocMenu=wordbuf;
		if (Reg.ReadDword("NoFavoritesMenu",wordbuf))
			m_bFavoritesMenu=wordbuf;
		if (Reg.ReadDword("NoClose",wordbuf))
			m_bCloseSystem=wordbuf;
		if (Reg.ReadBinary("NoFind",wordbuf))
			m_bFindMenu=wordbuf;
		if (Reg.ReadBinary("NoLogOff",wordbuf))
			m_bLogoffMenu=wordbuf;
	}
	//���ء����á��˵��п������ʹ�ӡ��
	if (Reg.GetDwordValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer","NoSetFolders",wordbuf))
		m_bNoConPrn=wordbuf;
	//<�ر�ϵͳ>���˳�WINDOWS����MS-DOS��
	if (Reg.GetDwordValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\WinOldApp","NoRealMode",wordbuf))
		m_bExitToDos=wordbuf;
	//��ֹ�ĵ��˵����ؼ�¼
	if (Reg.GetBinaryValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer","NoRecentDocsHistory",wordbuf))
		m_bDisableDocrun=wordbuf;
	
	//��ʼ�˵������ٶ�  
	MenuSpeed=400;
	if (Reg.GetStringValue(HKEY_CURRENT_USER,"control panel\\desktop","MenuShowDelay",buf))
	{
		MenuSpeed=atoi(buf);
		if (MenuSpeed<0)
			MenuSpeed=400;
		else if (MenuSpeed>5000)
			MenuSpeed=5000;
	}
	m_cMenuSpeed.SetPos(MenuSpeed);
	m_cAddmenuList.AddString("�������");
	m_cAddmenuList.AddString("��ӡ��");
	m_cAddmenuList.AddString("����վ");
	m_cAddmenuList.AddString("��ҳ��ʷ��¼��");
	m_cAddmenuList.AddString("�����ھ�");
	m_cAddmenuList.AddString("�ҵĹ��İ�");

	ITEMIDLIST Dir1;
	char Ddir[512];
	LPITEMIDLIST Dir=&Dir1;
	
	::SHGetSpecialFolderLocation(m_hWnd,CSIDL_STARTMENU,&Dir);
	::SHGetPathFromIDList(Dir,Ddir);
	CString MenuDir=Ddir;
	CString DestDir;
	
	int i=0;
	DestDir=MenuDir+"\\"+"�������.{21EC2020-3AEA-1069-A2DD-08002B30309D}";
	m_cAddmenuList.SetCheck(i++,!_chdir(DestDir));
	DestDir=MenuDir+"\\"+"��ӡ��.{2227A280-3AEA-1069-A2DE-08002B30309D}";
	m_cAddmenuList.SetCheck(i++,!_chdir(DestDir));
	DestDir=MenuDir+"\\"+"����վ.{645FF040-5081-101B-9F08-00AA002F954E}";
	m_cAddmenuList.SetCheck(i++,!_chdir(DestDir));
	DestDir=MenuDir+"\\"+"��ҳ��ʷ��¼�ļ���.{FF393560-C2A7-11CF-BFF4-444553540000}";
	m_cAddmenuList.SetCheck(i++,!_chdir(DestDir));
	DestDir=MenuDir+"\\"+"�����ھ�.{208D2C60-3AEA-1069-A2D7-08002B30309D}";
	m_cAddmenuList.SetCheck(i++,!_chdir(DestDir));
	DestDir=MenuDir+"\\"+"�ҵĹ��İ�.{85BBD920-42A0-1069-A2E4-08002B30309D}";
	m_cAddmenuList.SetCheck(i++,!_chdir(DestDir));
	
	UpdateData(FALSE);
	return TRUE; 
}

void CStartMenu::OnOK() 
{
	RegEdit Reg;
	
	if (Modify)
	{
		ITEMIDLIST Dir1;
		char Ddir[512];
		LPITEMIDLIST Dir=&Dir1;
		
		Reg.RootKey=HKEY_CURRENT_USER;
		if (Reg.CreateKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"))
		{
			Reg.WriteDword("NoRun",(DWORD)(m_bRunMenu));
			Reg.WriteDword("NoRecentDocsmenu",(DWORD)(m_bDocMenu));
			Reg.WriteDword("NoFavoritesMenu",(DWORD)(m_bFavoritesMenu));
			Reg.WriteDword("NoClose",(DWORD)(m_bCloseSystem));
			Reg.WriteBinary("NoFind",(DWORD)(m_bFindMenu));
			Reg.WriteBinary("NoLogOff",(DWORD)(m_bLogoffMenu));
		}
		Reg.SetDwordValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer","NoSetFolders",m_bNoConPrn);	
		Reg.SetDwordValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\WinOldApp","NoRealMode",(DWORD)m_bExitToDos);
		Reg.SetBinaryValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer","NoRecentDocsHistory",(DWORD)m_bDisableDocrun);
		CWinSetApp* pApp=(CWinSetApp*)AfxGetApp();
		Reg.SetStringValue(HKEY_CURRENT_USER,"control panel\\desktop","MenuShowDelay",pApp->NumToString(m_cMenuSpeed.GetPos()));
		if (m_bCleanDochist)
		{
			//����ĵ��˵�
			::SHGetSpecialFolderLocation(m_hWnd,CSIDL_RECENT,&Dir);
			::SHGetPathFromIDList(Dir,Ddir);
			CString DocDir=Ddir;
			DocDir+="\\";
			CString Fn;
			strcat(Ddir,"\\*.*");		
			
			long hfile;
			struct _finddata_t ffblk;
			if ( (hfile=_findfirst(Ddir, &ffblk)) !=-1)
			{
				do
				{
					Fn=DocDir+ffblk.name;
					_unlink(Fn);
				}while(_findnext(hfile,&ffblk)==0);
			}
			
			
		}
		if (m_bCleanRunhist)
		{
			//������в˵�
			Reg.SetKey(HKEY_CURRENT_USER);
			if (Reg.DeleteKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\runMRU"))
			{
				Reg.CreateKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\runMRU");
				Reg.WriteString("","");
			}
		}
		::SHGetSpecialFolderLocation(m_hWnd,CSIDL_STARTMENU,&Dir);
		::SHGetPathFromIDList(Dir,Ddir);
		CString MenuDir=Ddir;
		CString DestDir;
		char *DirName[]={"�������.{21EC2020-3AEA-1069-A2DD-08002B30309D}",
			"��ӡ��.{2227A280-3AEA-1069-A2DE-08002B30309D}",
			"����վ.{645FF040-5081-101B-9F08-00AA002F954E}",
			"��ҳ��ʷ��¼�ļ���.{FF393560-C2A7-11CF-BFF4-444553540000}",
			"�����ھ�.{208D2C60-3AEA-1069-A2D7-08002B30309D}",
			"�ҵĹ��İ�.{85BBD920-42A0-1069-A2E4-08002B30309D}"
		};
		for (int i=0;i<6;i++)
		{
			DestDir=MenuDir+"\\"+DirName[i];
			if (m_cAddmenuList.GetCheck(i))
				_mkdir(DestDir);
			else
				_rmdir(DestDir);			
		}
		m_bCleanDochist = FALSE;
		m_bCleanRunhist = FALSE;
		UpdateData(FALSE);		
	}
	CPropertyPage::OnOK();
}




void CStartMenu::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	OnChange();
	CPropertyPage::OnHScroll(nSBCode, nPos, pScrollBar);
}

//�ı�ѡ��ʹӦ��ť��Ч���˳���ʾ�������������������
void CStartMenu::OnChange() 
{
	((CWinSetApp *)AfxGetApp())->SetModifyflag();
	SetModified(TRUE);	
	Modify=TRUE;
}

//�ı�ѡ��ʹӦ��ť��Ч��
void CStartMenu::OnLChange() 
{
	SetModified(TRUE);	
	Modify=TRUE;	
}

//������ɫ
HBRUSH CStartMenu::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CPropertyPage::OnCtlColor(pDC, pWnd, nCtlColor);
	
	int	FrmIDs[]={IDC_HIDEMENUITEMFRM,IDC_ADDMENUFRM};
	for (int i=0;i<sizeof(FrmIDs)/sizeof(int);i++)
	{
	 if (*GetDlgItem(FrmIDs[i])==*(pWnd))
	 {
		pDC->SetTextColor(GetSysColor(COLOR_HIGHLIGHT));
		break;
	 }
	}
	return hbr;
}

void CStartMenu::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	//��ʾ����״̬��
	((CWinSetDlg*)AfxGetMainWnd())->ShowStatusBar();
	
	CPropertyPage::OnLButtonDblClk(nFlags, point);
}

BOOL CStartMenu::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	int IDs[]={    IDC_MENUSPEED,	IDC_ADDMENULIST};
	UINT StrIDs[]={IDS_MENUSPEEDST, IDS_ADDMENULIST};
	
	CRect rc;
	CString Str;
	bool Prompt=FALSE;
	for (int i=0;i<sizeof(IDs)/sizeof(int);i++)
	{
		if (*GetDlgItem(IDs[i])==*pWnd)
		{
			Str.LoadString(StrIDs[i]);
			((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
			Prompt=TRUE;
			break;
		}
	}

	return CPropertyPage::OnSetCursor(pWnd, nHitTest, message);
}

void CStartMenu::OnMouseMove(UINT nFlags, CPoint point) 
{
	int IDs[]={	  IDC_HIDEMENUITEMFRM,IDC_MENUSPEEDST};
	int StrIDs[]={IDS_HIDEMENUITEMFRM,IDS_MENUSPEEDST};
	
	CRect rc;
	CString Str;
	bool Prompt=FALSE;
	for (int i=0;i<sizeof(IDs)/sizeof(int);i++)
	{
		GetDlgItem(IDs[i])->GetWindowRect(&rc);
		ScreenToClient(&rc);
		if (rc.PtInRect(point))
		{
			Str.LoadString(StrIDs[i]);
			((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
			Prompt=TRUE;
			break;
		}
	}
	if (!Prompt)
	{
		Str.LoadString(IDS_READY);
		((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
	}
	
	CPropertyPage::OnMouseMove(nFlags, point);
}
