// ExplorerSet.cpp :  �ҵĵ���ϵͳ�����޸�
//����ϵͳ�޸��� 1.0b
//�������������ҡ�http://xksoft.yeah.net
//���ߣ������� xksoft@yeah.net

#include "stdafx.h"
#include "WinSet.h"
#include "ExplorerSet.h"
#include "RegEdit.h"
#include "OpenBmpDlg.h"
#include "OpenicoDlg.h"
#include "WinSetDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CExplorerSet property page

IMPLEMENT_DYNCREATE(CExplorerSet, CPropertyPage)

CExplorerSet::CExplorerSet() : CPropertyPage(CExplorerSet::IDD)
{
	m_psp.dwFlags &= ~(PSP_HASHELP);
	//m_psp.dwFlags |=PSP_USEHICON ;
	//m_psp.hIcon=AfxGetApp()->LoadIcon(IDI_MYCOMPUTER);

	Modify=FALSE;
	//{{AFX_DATA_INIT(CExplorerSet)
	m_bSmallBmp = m_bOldSmallbmp = FALSE;
	m_sBackBmp = _T("");
	m_sIconSize = _T("32");
	m_bHideFilemenu = FALSE;
	m_bNoSaveset = FALSE;
	iIconColor = 0;
	//}}AFX_DATA_INIT
}

CExplorerSet::~CExplorerSet()
{
}

void CExplorerSet::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExplorerSet)
	DDX_Control(pDX, IDC_DRIVELIST, m_cDriveList);
	DDX_Control(pDX, IDC_DRIVE, m_cDrive);
	DDX_Control(pDX, IDC_DRIVEICON, m_cDriveIcon);
	DDX_Check(pDX, IDC_SMALLBMP, m_bSmallBmp);
	DDX_Text(pDX, IDC_BACKBMP, m_sBackBmp);
	DDX_Text(pDX, IDC_ICONSIZE, m_sIconSize);
	DDX_Check(pDX, IDC_HIDEFILEMENU, m_bHideFilemenu);
	DDX_Check(pDX, IDC_NOSAVESET, m_bNoSaveset);
	DDX_CBIndex(pDX, IDC_ICONCOLOR, iIconColor);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CExplorerSet, CPropertyPage)
//{{AFX_MSG_MAP(CExplorerSet)
	ON_BN_CLICKED(IDC_BROWSEBACK, OnBrowseback)
	ON_BN_CLICKED(IDC_AUTORUNBROWSE, OnAutorunbrowse)
	ON_BN_CLICKED(IDC_BROWSEICON, OnBrowseicon)
	ON_BN_CLICKED(IDC_AUTORUNCANCEL, OnAutoruncancel)
	ON_CBN_SELCHANGE(IDC_DRIVE, OnSelchangeDrive)
	ON_BN_CLICKED(IDC_SAVESET, OnLChange)
	ON_CONTROL( CLBN_CHKCHANGE, IDC_DRIVELIST, OnChange )
	ON_WM_CTLCOLOR()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_SETCURSOR()
	ON_WM_MOUSEMOVE()
	ON_EN_CHANGE(IDC_ICONCOLOR, OnChange)
	ON_EN_CHANGE(IDC_ICONSIZE, OnChange)
	ON_BN_CLICKED(IDC_FILEMENU, OnChange)
	ON_BN_CLICKED(IDC_SMALLBMP, OnChange)
	ON_EN_CHANGE(IDC_BACKBMP, OnLChange)
	ON_CBN_SELCHANGE(IDC_ICONCOLOR, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExplorerSet message handlers

BOOL CExplorerSet::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CString String;
	RegEdit Reg;
	DWORD wordbuf;
	int i;
	
	//��Դ����������ͼ��
    Reg.GetStringValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Internet Explorer\\Toolbar","BackBitmap",m_sBackBmp);
	//ͼ���С����ɫ
	Reg.RootKey=HKEY_CURRENT_USER;
	if (Reg.OpenKey("Control Panel\\desktop\\WindowMetrics"))
	{
		if (Reg.ReadString("Shell Icon Size",String))
			m_sIconSize=String;
		if (Reg.ReadString("Shell Icon BPP",String))
		{
			char *sIconColors[]={"4","8","16","24","32"};
			String.TrimLeft();
			String.TrimRight();
			for (int i=0;i<5;i++)
			{
				if (String==sIconColors[i])
					iIconColor=i;
			}
		}
	}
	
	if (Reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"))
	{
		//���ļ��˵�
		if (Reg.ReadBinary("NoFileMenu",wordbuf))
			m_bHideFilemenu=wordbuf;
		//����������
		if (Reg.ReadBinary("NoSaveSettings",wordbuf))
			m_bNoSaveset=wordbuf;
	}
	//��λͼСͼƬ��ʽ 
	if (Reg.GetStringValue(HKEY_CLASSES_ROOT,".bmp","",String))
	{
		String+="\\Defaulticon";
		if (Reg.GetStringValue(HKEY_CLASSES_ROOT,String,"",String))
		{
			String.TrimLeft();
			String.TrimRight(); 
			m_bSmallBmp=m_bOldSmallbmp=(String=="%1");
			BmpDefaulticon=String;
		}						  
	}
	//������ͼ�꣬�Զ�ִ���ļ�
	char Drive[]="A:\\";
	char DriveStr[]="A:";
	AutorunInfo AutorunFile;
	
	for (i=2;i<26;i++)
	{
		*Drive=*DriveStr='A'+i;
		if (::GetDriveType(Drive)==DRIVE_FIXED)
		{
			FILE *fp;
			char Str[1024],InfFile[256];
			CString String;
			
			m_cDrive.AddString(DriveStr);
			AutorunFile.Drive=i;
			AutorunFile.IconIndex=0;
			AutorunFile.Icon.Empty();
			AutorunFile.ExeFile.Empty();
			strcpy(InfFile,Drive);
			strcat(InfFile,"AutoRun.inf");
			fp=fopen(InfFile,"rb+");
			if (fp==NULL)
				fp=fopen(InfFile,"wb+");
			while(!feof(fp))
			{
				fgets(Str,1024,fp);
				String=Str;
				String.MakeUpper();
				int Index=String.Find("ICON");
				if (Index!=-1)
				{
					String=String.Right(String.GetLength()-Index-4);
					int len=String.GetLength();
					for (int l=0;l<len;l++)
					{
						if (String[l]=='=')
						{
							String=String.Right(String.GetLength()-l-1);
							break;
						}
					}
					if (l<len)
					{
						String.TrimLeft();
						String.TrimRight();
						Index=String.Find(',');
						if (Index==-1)
							AutorunFile.Icon=String;
						else
						{
							AutorunFile.Icon=String.Left(Index);
							String=String.Right(String.GetLength()-Index-1);
							String.TrimLeft();
							AutorunFile.IconIndex=atoi(String);
						}
						if (AutorunFile.Icon.Find('\\')==-1)
							AutorunFile.Icon=Drive+AutorunFile.Icon;
					}
				}
				else
				{
					Index=String.Find("OPEN");
					if (Index!=-1)
					{
						String=String.Right(String.GetLength()-Index-4);
						int len=String.GetLength();
						for (int l=0;l<len;l++)
						{
							if (String[l]=='=')
							{
								String=String.Right(String.GetLength()-l-1);
								break;
							}
						}
						if (l<len)
						{
							String.TrimLeft();
							String.TrimRight();
							AutorunFile.ExeFile=String;
							if (AutorunFile.ExeFile.Find('\\')==-1)
							  AutorunFile.ExeFile=Drive+AutorunFile.ExeFile;

						}
					}								
				}
			}
			fclose(fp);
			DriveAuto.Add(AutorunFile);
		}
	}
	m_cDrive.SetCurSel(0);
	CurDrive=0;
	if (DriveAuto[0].Icon.IsEmpty())
	{
		SHFILEINFO fi;
		*Drive=DriveAuto[0].Drive+'A';
		SHGetFileInfo(Drive,0,&fi,sizeof(fi),SHGFI_ICON|SHGFI_LARGEICON);
		m_cDriveIcon.SetIcon(fi.hIcon);
	}
	else
	{
		m_cDriveIcon.SetIcon(::ExtractIcon(AfxGetInstanceHandle(),DriveAuto[0].Icon,DriveAuto[0].IconIndex));
	}
	GetDlgItem(IDC_AUTORUNFILE)->SetWindowText(DriveAuto[0].ExeFile);

	//��ʾ����������
	DWORD NoDrives;
	Reg.RootKey=HKEY_CURRENT_USER;
	if (Reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"))
	{
	  if (Reg.ReadBinary("NoDrives",NoDrives)==0)
		  NoDrives=0;
	}
	for (i=0;i<26;i++)
	{	
		char Str[]={"X:"};
		Str[0]='A'+i;
		
		DWORD State=NoDrives>>i;
		State&=1;
		m_cDriveList.AddString(Str);
		m_cDriveList.SetCheck(i,State);
	}		
	UpdateData(FALSE);
	return TRUE;
}

void CExplorerSet::OnOK() 
{
	if (Modify)
	{
		CString String;
		RegEdit Reg;
		int i;
		
		//���ñ���λ��
		GetDlgItem(IDC_BACKBMP)->GetWindowText(String);
		Reg.SetStringValue(HKEY_CURRENT_USER,"Software\\Microsoft\\Internet Explorer\\Toolbar","BackBitmap",String);
		//����ͼ���С����ɫ
		Reg.RootKey=HKEY_CURRENT_USER;
		if (Reg.OpenKey("Control Panel\\desktop\\WindowMetrics"))
		{
			GetDlgItem(IDC_ICONSIZE)->GetWindowText(String);
			Reg.WriteString("Shell Icon Size",String);
			char *sIconColors[]={"4","8","16","24","32"};
			String.TrimLeft();
			String.TrimRight();
			Reg.WriteString("Shell Icon BPP",sIconColors[iIconColor]);		
		}
		if (Reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"))
		{
			//�Ƿ���ʾ�ļ��˵�
			Reg.WriteBinary("NoFileMenu",(DWORD)m_bHideFilemenu);
			//�Ƿ񱣴���Դ����������
			Reg.WriteBinary("NoSaveSettings",(DWORD)m_bNoSaveset);
		}
		//�Ƿ���ʾλͼΪСͼƬ��ʽ
		if (m_bSmallBmp!=m_bOldSmallbmp)
		{
			CString StrKey;
			
			StrKey="%1";
			
			Reg.RootKey=HKEY_CURRENT_USER;
			if (Reg.OpenKey("Software"))
				if (Reg.CreateKey("XKSoft\\WinSet"))
				{
					if (!m_bOldSmallbmp)
						Reg.WriteString("BmpDefaulticon",BmpDefaulticon);
				}
				if (Reg.GetStringValue(HKEY_CLASSES_ROOT,".bmp","",String))
				{
					String+="\\Defaulticon";
					if (!m_bSmallBmp)
						Reg.GetStringValue(HKEY_CURRENT_USER,"SoftWare\\XKSoft\\WinSet","BmpDefaulticon",StrKey);
					Reg.SetStringValue(HKEY_CLASSES_ROOT,String,"",StrKey);
				}
				
		}
		//����������ͼ�꣬�Զ�ִ���ļ�
		GetDlgItem(IDC_AUTORUNFILE)->GetWindowText(String);
		DriveAuto[CurDrive].ExeFile=String;
		for (i=0;i<DriveAuto.GetSize();i++)
		{
			char fn[]="A:\\AutoRun.inf";
			*fn=DriveAuto[i].Drive+'A';
			FILE *fp;
			if ((fp=fopen(fn,"wb"))==NULL)
				continue;
			fprintf(fp,"[AutoRun]\r\n");
			fprintf(fp,"Icon=%s,%d\r\n",DriveAuto[i].Icon,DriveAuto[i].IconIndex);
			if (!DriveAuto[i].ExeFile.IsEmpty())
				fprintf(fp,"Open=%s",DriveAuto[i].ExeFile);
			fclose(fp);
		}
		DWORD NoDrives=0,State;
		for (i=0;i<26;i++)
		{
			//����б���ͼ����״̬
			State=m_cDriveList.GetCheck(i);
			State=State<<i;
			NoDrives|=State;
		}
		Reg.RootKey=HKEY_CURRENT_USER;
		if (Reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"))
		{
			Reg.WriteBinary("NoDrives",NoDrives);
		}				
	}
	CPropertyPage::OnOK();
}

//ѡ�����������λͼ�ļ�
void CExplorerSet::OnBrowseback() 
{
	CString FileName;
	
	COpenBmpDialog dlgOpenFile;
	
	GetDlgItem(IDC_BACKBMP)->GetWindowText(FileName);
	if (!FileName.IsEmpty())
	{
		int i=FileName.ReverseFind('\\');
		if (i>0)
		{
			CString Dir=FileName.Left(i);
			dlgOpenFile.m_ofn.lpstrInitialDir=Dir; 
		}
	}
	int iRet=dlgOpenFile.DoModal();
	if (iRet!=IDOK)
		return;
	FileName=dlgOpenFile.GetPathName();
	GetDlgItem(IDC_BACKBMP)->SetWindowText(FileName);
}

void CExplorerSet::OnChange() 
{
	((CWinSetApp *)AfxGetApp())->SetModifyflag();
	SetModified(TRUE);
	Modify=TRUE;
}

void CExplorerSet::OnLChange() 
{
	SetModified(TRUE);
	Modify=TRUE;	
}

//ѡ���������Զ�ִ���ļ�
void CExplorerSet::OnAutorunbrowse() 
{
	CString Filter="��ִ���ļ�(*.exe) |*.exe||";
	CString FileName;
	
	CFileDialog dlgOpenFile(TRUE,0,0,OFN_HIDEREADONLY|OFN_FILEMUSTEXIST,(LPCTSTR)Filter);
	
	dlgOpenFile.m_ofn.lpstrTitle=_T("ѡ���Զ����г���...");
	int iRet=dlgOpenFile.DoModal();
	if (iRet!=IDOK)
		return;
	FileName=dlgOpenFile.GetPathName();
	GetDlgItem(IDC_AUTORUNFILE)->SetWindowText(FileName);
	OnChange();	
}

//ѡ������ͼ��
void CExplorerSet::OnBrowseicon() 
{
	CString FileName=DriveAuto[CurDrive].Icon;
	
	COpenIcoDlg dlgOpenFile;
	
	dlgOpenFile.m_ofn.lpstrTitle=_T("ѡ��������ͼ��...");
	if (!FileName.IsEmpty())
	{
		int Index=FileName.ReverseFind('\\');
		if (Index!=-1)
		{
			FileName=FileName.Left(Index);
			dlgOpenFile.m_ofn.lpstrInitialDir=FileName;
		}
	}
	int iRet=dlgOpenFile.DoModal();
	if (iRet!=IDOK)
		return;
	FileName=dlgOpenFile.GetPathName();
	int IconIndex=dlgOpenFile.IconIndex;
	DriveAuto[CurDrive].Icon=FileName;
	DriveAuto[CurDrive].IconIndex=IconIndex;
	m_cDriveIcon.SetIcon(::ExtractIcon(AfxGetInstanceHandle(),FileName,IconIndex));
	OnChange();
}

//ȡ���Զ����г���
void CExplorerSet::OnAutoruncancel() 
{
	GetDlgItem(IDC_AUTORUNFILE)->SetWindowText("");
}

//�ı�������
void CExplorerSet::OnSelchangeDrive() 
{
	CString String;
	
	GetDlgItem(IDC_AUTORUNFILE)->GetWindowText(String);
	DriveAuto[CurDrive].ExeFile=String;
	CurDrive=m_cDrive.GetCurSel();
	GetDlgItem(IDC_AUTORUNFILE)->SetWindowText(DriveAuto[CurDrive].ExeFile);
	if (DriveAuto[CurDrive].Icon.IsEmpty())
	{
		SHFILEINFO fi;
		char *Drive="A:\\";
		*Drive=DriveAuto[CurDrive].Drive+'A';
		SHGetFileInfo(Drive,0,&fi,sizeof(fi),SHGFI_ICON|SHGFI_LARGEICON);
		m_cDriveIcon.SetIcon(fi.hIcon);
	}
	else
	{
		m_cDriveIcon.SetIcon(::ExtractIcon(AfxGetInstanceHandle(),DriveAuto[CurDrive].Icon,DriveAuto[CurDrive].IconIndex));
	}
	
}

//������ɫ
HBRUSH CExplorerSet::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CPropertyPage::OnCtlColor(pDC, pWnd, nCtlColor);
	int	FrmIDs[]={IDC_DISKAUTORUNFRM,IDC_SETFRM,IDC_ICONFRM};
	for (int i=0;i<sizeof(FrmIDs)/sizeof(int);i++)
	{
	 if (*GetDlgItem(FrmIDs[i])==*(pWnd))
	 {
		pDC->SetTextColor(GetSysColor(COLOR_HIGHLIGHT));
		break;
	 }
	}
	
	return hbr;
}

void CExplorerSet::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	//��ʾ����״̬��
	((CWinSetDlg*)AfxGetMainWnd())->ShowStatusBar();
	
	CPropertyPage::OnLButtonDblClk(nFlags, point);
}

BOOL CExplorerSet::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	int IDs[]={    IDC_DRIVELIST,IDC_BROWSEBACK,	 IDC_BACKBMP,	IDC_DRIVE,		IDC_BROWSEICON,IDC_HIDEFILEMENU,IDC_SMALLBMP,	 IDC_NOSAVESET,IDC_AUTORUNBROWSE,
				   IDC_AUTORUNCANCEL,IDC_AUTORUNFILE};
	UINT StrIDs[]={IDS_HIDEDRIVEST,IDS_BROWSEBACKBMP,IDS_BACKBMPED,	IDS_SELECTDRIVE,IDS_BROWSEICON,IDS_HIDEFILEMENU,IDS_SMALLBMPSHOW,IDS_NOSAVESET,IDS_AUTORUNBROWSE,
				   IDS_AUTORUNCANCEL,IDS_DRIVEAUTORUNFILE};
	
	CRect rc;
	CString Str;
	bool Prompt=FALSE;
	for (int i=0;i<sizeof(IDs)/sizeof(int);i++)
	{
		if (*GetDlgItem(IDs[i])==*pWnd)
		{
			Str.LoadString(StrIDs[i]);
			((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
			Prompt=TRUE;
			break;
		}
	}
	
	return CPropertyPage::OnSetCursor(pWnd, nHitTest, message);
}

void CExplorerSet::OnMouseMove(UINT nFlags, CPoint point) 
{
	int IDs[]={	  IDC_HIDEDRIVEST,IDC_DRIVEICON};
	int StrIDs[]={IDS_HIDEDRIVEST,IDS_DRIVEICON};
	
	CRect rc;
	CString Str;
	bool Prompt=FALSE;
	for (int i=0;i<sizeof(IDs)/sizeof(int);i++)
	{
		GetDlgItem(IDs[i])->GetWindowRect(&rc);
		ScreenToClient(&rc);
		if (rc.PtInRect(point))
		{
			Str.LoadString(StrIDs[i]);
			((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
			Prompt=TRUE;
			break;
		}
	}
	if (!Prompt)
	{
		Str.LoadString(IDS_READY);
		((CWinSetDlg*)AfxGetMainWnd())->SetStatusText(Str);
	}
		
	CPropertyPage::OnMouseMove(nFlags, point);
}
