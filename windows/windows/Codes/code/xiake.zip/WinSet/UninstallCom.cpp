// UninstallCom.cpp : implementation file
//

#include "stdafx.h"
#include "WinSet.h"
#include "UninstallCom.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUninstallCom dialog


CUninstallCom::CUninstallCom(CWnd* pParent /*=NULL*/)
	: CDialog(CUninstallCom::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUninstallCom)
	m_sCommand = _T("");
	m_sDispName = _T("");
	//}}AFX_DATA_INIT
}


void CUninstallCom::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUninstallCom)
	DDX_Text(pDX, IDC_COMMAND, m_sCommand);
	DDX_Text(pDX, IDC_DISPNAME, m_sDispName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUninstallCom, CDialog)
	//{{AFX_MSG_MAP(CUninstallCom)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUninstallCom message handlers
