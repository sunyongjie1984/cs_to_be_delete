// HMHOpenFile.cpp : 
//���ļ��Ի���

#include "stdafx.h"
#include "HMHOpenFile.h"
#include "HMHFunc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHMHOpenFile

IMPLEMENT_DYNAMIC(CHMHOpenFile, CFileDialog)

CHMHOpenFile::CHMHOpenFile( LPCTSTR lpszFilter,LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
						   DWORD dwFlags,  BOOL bOpenFileDialog,CWnd* pParentWnd) :
CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
	InitialData();
}

CHMHOpenFile::CHMHOpenFile(BOOL bOpenFileDialog,LPCTSTR lpszDefExt,LPCTSTR lpszFileName,
						   DWORD dwFlags,LPCTSTR lpszFilter,CWnd* pParentWnd):
CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
	InitialData();
}
		

BEGIN_MESSAGE_MAP(CHMHOpenFile, CFileDialog)
	//{{AFX_MSG_MAP(CHMHOpenFile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CHMHOpenFile::OnInitDialog() 
{
	CFileDialog::OnInitDialog();

	if (!m_sOkBtnStr.IsEmpty())
		GetParent()->GetDlgItem(IDOK)->SetWindowText(m_sOkBtnStr);
	if (!m_sCancelBtnStr.IsEmpty())
		GetParent()->GetDlgItem(IDCANCEL)->SetWindowText(m_sCancelBtnStr);
		
	return TRUE;
}

void CHMHOpenFile::SetOkBtnStr(CString Str)
{
	m_sOkBtnStr=Str;
}


void CHMHOpenFile::SetOkBtnStr(UINT StrID)
{
	m_sOkBtnStr.LoadString(StrID);
}

void CHMHOpenFile::SetCancelBtnStr(CString Str)
{
	m_sCancelBtnStr=Str;
}

void CHMHOpenFile::SetCancelBtnStr(UINT StrID)
{
	m_sCancelBtnStr.LoadString(StrID);
}

//���ó�ʼĿ¼Ϊ�ļ�FileName���ڵ�Ŀ¼
void CHMHOpenFile::SetInitialDir(LPCTSTR FileName)
{
	static CString DirName;
	
	DirName=FileName;
	int Index=DirName.ReverseFind('\\');
	if (Index!=-1)
	{
		DirName=DirName.Left(Index);
	}
	m_ofn.lpstrInitialDir=DirName;
}

//���öԻ������
void CHMHOpenFile::SetDlgTitle(UINT StrID)
{
	DlgTitle.LoadString(StrID);
	m_ofn.lpstrTitle=(LPCTSTR)DlgTitle;
}

void CHMHOpenFile::SetDlgTitle(LPCTSTR String)
{
	DlgTitle=String;
	m_ofn.lpstrTitle=(LPCTSTR)DlgTitle;
}

void CHMHOpenFile::InitialData()
{
	m_sOkBtnStr.Empty();
	m_sCancelBtnStr.Empty();
	DlgTitle.Empty();
}

void CHMHOpenFile::SetInitialFile(LPCTSTR FileName)
{
	if ( HMHFileExist(FileName) )
		strcpy(m_ofn.lpstrFile,FileName);
}
