// OpenIcoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "OpenIcoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDD_CHOOSE_ICON (5500)
#define IDC_ICONLIST (5501)
#define IDC_CURRENTICON (5502)

/////////////////////////////////////////////////////////////////////////////
// COpenIcoDlg

IMPLEMENT_DYNAMIC(COpenIcoDlg, CHMHOpenFile)

COpenIcoDlg::COpenIcoDlg(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
						 DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
CHMHOpenFile(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
    m_ofn.lpstrFilter = "ͼ���ļ� (.ico,.icl,.exe,.dll)\0*.ico;*.icl;*.exe;*.dll\0"\
		"ͼ���ļ� (.ico)\0*.ico\0ͼ����ļ� (.icl)\0*.icl\0��ִ���ļ�\0*.exe\0��̬���ӿ�\0*.dll\0"\
		"�����ļ� (*.*)\0*.*\0\0";                            
	
    m_ofn.Flags |= (OFN_HIDEREADONLY | OFN_EXPLORER  |OFN_ENABLETEMPLATE);
    m_ofn.lpstrTitle=_T("ѡ��ͼ��");
    m_ofn.hInstance = AfxGetInstanceHandle();
    m_ofn.lpTemplateName = MAKEINTRESOURCE(IDD_CHOOSE_ICON);
	IconIndex=0;
}

void COpenIcoDlg::DoDataExchange(CDataExchange* pDX)
{
	CHMHOpenFile::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COpenIcoDlg)
	DDX_Control(pDX, IDC_ICONLIST, IconListBox);
	DDX_Control(pDX, IDC_CURRENTICON, StCurrentIcon);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(COpenIcoDlg, CHMHOpenFile)
//{{AFX_MSG_MAP(COpenIcoDlg)
ON_WM_CTLCOLOR()
ON_WM_DRAWITEM()
ON_WM_MEASUREITEM()
ON_LBN_SELCHANGE(IDC_ICONLIST, OnIconlistSelchange)
ON_LBN_DBLCLK(IDC_ICONLIST, OnIconlistDblclk)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//������ɫ
HBRUSH COpenIcoDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{	
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	int	FrmIDs[]={IDC_CURRENTICON};
	
	for (int i=0;i<sizeof(FrmIDs)/sizeof(int);i++)
	{
		if (*GetDlgItem(FrmIDs[i])==*(pWnd))
		{
			pDC->SetTextColor(GetSysColor(COLOR_HIGHLIGHT));
			break;
		}
	}		
	return hbr;
}

BOOL COpenIcoDlg::OnInitDialog() 
{
	CHMHOpenFile::OnInitDialog();
	
	return TRUE;  
}

//ѡ���ļ��ı�
void COpenIcoDlg::OnFileNameChange()
{
	//�ͷ��ϴ�ͼ���б�ͼ����
	int nCount = IconListBox.GetCount();
	bool OpenErr=false;
	for (int i=0; i<nCount; i++)
	{
		HICON hIcon = (HICON) IconListBox.GetItemData(i);
		DestroyIcon(hIcon);
	}
	StCurrentIcon.SetWindowText("");
	IconListBox.ResetContent();
	CString m_sIconFileName;
	
	m_sIconFileName=GetPathName();
	int nNum = (int) ::ExtractIcon(AfxGetInstanceHandle(), m_sIconFileName, (UINT) -1);
	for (i=0; i<nNum; i++)
	{
		HICON hIcon = ::ExtractIcon(AfxGetInstanceHandle(), m_sIconFileName, i);
		IconListBox.InsertString(i,"");
		IconListBox.SetItemData(i,(DWORD)hIcon);
	}
	if (nNum>0)
	{
		IconIndex=IconIndex<nNum ? IconIndex:0;
		IconIndex=IconIndex<0 ? 0:IconIndex;
		IconListBox.SetCurSel(IconIndex);
		CString Str;
		Str.Format("%d",IconIndex);
		StCurrentIcon.SetWindowText(Str);
		IconIndex=0;	
	}
}

//��ʼ��
void COpenIcoDlg::OnInitDone()
{
	IconListBox.SetColumnWidth(GetSystemMetrics(SM_CXICON) + 6);
}

//�����򿪡���ť
BOOL COpenIcoDlg::OnFileNameOK()
{
	IconIndex=IconListBox.GetCurSel();
	if (IconIndex==LB_ERR)
	{
		IconIndex=0;
		return 1;
	}			
	/*
	// This avoids an assert		
	_AFX_THREAD_STATE* pThreadState = AfxGetThreadState();
	pThreadState->m_pAlternateWndInit = NULL;
	*/
	return 0;
}
/////////////////////////////////////////////////////////////////////////////
// CIconListBox

CIconListBox::CIconListBox()
{
}

CIconListBox::~CIconListBox()
{
}


BEGIN_MESSAGE_MAP(CIconListBox, CListBox)
//{{AFX_MSG_MAP(CIconListBox)
// NOTE - the ClassWizard will add and remove mapping macros here.
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIconListBox message handlers

void CIconListBox::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
}

void CIconListBox::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
	
}

void COpenIcoDlg::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	if (nIDCtl==IDC_ICONLIST)
	{
		//��ͼ���б�	
		DRAWITEMSTRUCT *lpDIS = lpDrawItemStruct;
		CDC* pDC = CDC::FromHandle(lpDIS->hDC);
		
		if ((lpDIS->itemState & ODS_SELECTED) &&                         
			(lpDIS->itemAction & (ODA_SELECT | ODA_DRAWENTIRE)))
		{
			// ����ѡ�� - ��ѡ�����
			COLORREF crHilite = GetSysColor(COLOR_HIGHLIGHT);
			CBrush br(crHilite);
			pDC->FillRect(&lpDIS->rcItem, &br);
		}
		
		if (!(lpDIS->itemState & ODS_SELECTED) &&  (lpDIS->itemAction & ODA_SELECT))
		{	
			// ���ѡ�� -- ɾ��ѡ�����
			CBrush br(RGB(255, 255, 255));
			pDC->FillRect(&lpDIS->rcItem, &br);
		}	
		//��ͼ��
		pDC->DrawIcon(lpDIS->rcItem.left+2, lpDIS->rcItem.top+4, (HICON) lpDIS->itemData);
	}		
	CHMHOpenFile::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

void COpenIcoDlg::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
	if (nIDCtl==IDC_ICONLIST)
		lpMeasureItemStruct->itemHeight = GetSystemMetrics(SM_CYICON) +12;	
	CHMHOpenFile::OnMeasureItem(nIDCtl, lpMeasureItemStruct);
}


void COpenIcoDlg::OnIconlistSelchange()
{
			int Index=IconListBox.GetCurSel();
			CString Str="";
			if (Index!=LB_ERR)
				Str.Format("%d",Index);
			StCurrentIcon.SetWindowText((LPCTSTR)Str);
}

void COpenIcoDlg::OnIconlistDblclk()
{
	int Index=IconListBox.GetCurSel();
	if (Index!=LB_ERR)
	{
		GetParent()->SendMessage(WM_COMMAND,IDOK);
	}
}
