// PropertySheetWithLogoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PropertySheetWithLogoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertySheetWithLogoDlg

IMPLEMENT_DYNAMIC(CPropertySheetWithLogoDlg, CPropertySheet)

CPropertySheetWithLogoDlg::CPropertySheetWithLogoDlg(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
	TextColor=1;	//Ĭ����ɫΪϵͳ3D��ɫ
	ShadowColor=1;	
}


CPropertySheetWithLogoDlg::~CPropertySheetWithLogoDlg()
{
}


BEGIN_MESSAGE_MAP(CPropertySheetWithLogoDlg, CPropertySheet)
	//{{AFX_MSG_MAP(CPropertySheetWithLogoDlg)
	ON_WM_PAINT()
	ON_WM_MOUSEMOVE()
	ON_WM_SETCURSOR()
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//
void CPropertySheetWithLogoDlg::SetLogoText(CString Text)
{
	m_LogoText = Text;
	TipText="�������ߵ���ҳ";
}

void CPropertySheetWithLogoDlg::SetLogoFont(CString Name, int nHeight/* = 24*/,
	int nWeight/* = FW_BOLD*/, BYTE bItalic/* = true*/, BYTE bUnderline/* = false*/)
{
	if(m_fontLogo.m_hObject)
		m_fontLogo.Detach();

	m_fontLogo.CreateFont(nHeight, 0, 0, 0, nWeight, bItalic, bUnderline,0,0,0,0,0,0, Name);
}

/////////////////////////////////////////////////////////////////////////////
// CPropertySheetWithLogoDlg message handlers

void CPropertySheetWithLogoDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	if(m_LogoText.IsEmpty())
		return;

	CRect rectTabCtrl;
	GetTabControl()->GetWindowRect(rectTabCtrl);
	ScreenToClient(rectTabCtrl);

	CRect rectOk;
	GetDlgItem(IDOK)->GetWindowRect(rectOk);
	ScreenToClient(rectOk);

	dc.SetBkMode(TRANSPARENT);

	CRect rectText;
	rectText.left = rectTabCtrl.left;
	rectText.top = rectOk.top;
	rectText.bottom = rectOk.bottom;
	rectText.right = rectOk.left;

	CFont * OldFont = dc.SelectObject(&m_fontLogo);
	COLORREF OldColor;
	// ��DC���ı�
	if (TextColor==1)
	  OldColor = dc.SetTextColor( ::GetSysColor( COLOR_3DHILIGHT));
	else
	  OldColor = dc.SetTextColor( TextColor);
	dc.DrawText( m_LogoText, rectText + CPoint(1,1), DT_SINGLELINE | DT_LEFT | DT_VCENTER);
	if (ShadowColor==1)
	  dc.SetTextColor( ::GetSysColor( COLOR_3DSHADOW));
	else
      dc.SetTextColor( ShadowColor);

	dc.DrawText( m_LogoText, rectText, DT_SINGLELINE | DT_LEFT | DT_VCENTER);
	CSize ChSize=dc.GetTextExtent(m_LogoText);
	TextRect=rectText;
	//TextRect.bottom=TextRect.top+ChSize.cy;
	//TextRect.right=TextRect.left+ChSize.cx;
	m_ToolTip.SetToolRect(this,305,TextRect);

	// �ָ�ԭ��ɫ
	dc.SetTextColor( OldColor);
	// �ָ�ԭ����
	dc.SelectObject(OldFont);			  	
}

BOOL CPropertySheetWithLogoDlg::OnInitDialog() 
{
	BOOL bResult = CPropertySheet::OnInitDialog();
	
	SetLogoFont("����");		//Ĭ������Ϊ����	
    m_ToolTip.Create(this);	
    TextRect.SetRect(0,0,0,0);
    m_ToolTip.AddTool(this, TipText, TextRect,305);

	return bResult;
}

//�����ַ���ɫ
void CPropertySheetWithLogoDlg::SetColor(COLORREF TextCo, COLORREF ShadowCo)
{
	TextColor=TextCo;
	ShadowColor=ShadowCo;	
}

void CPropertySheetWithLogoDlg::OnMouseMove(UINT nFlags, CPoint point) 
{

	ValidateRect(&TextRect);
	//CPropertySheet::OnMouseMove(nFlags, point);
}

BOOL CPropertySheetWithLogoDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	POINT point;
	GetCursorPos(&point);
	ScreenToClient(&point);
	if (TextRect.PtInRect(point))
	{
		::SetCursor(AfxGetApp()->LoadCursor("HYPERLINK"));
		return TRUE;
	}
	return FALSE;
}

void CPropertySheetWithLogoDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if (TextRect.PtInRect(point))
	{
		GoRun();
	}
}

void CPropertySheetWithLogoDlg::GoRun()
{
  ::ShellExecute(m_hWnd,"Open","http://xksoft.yeah.net",NULL,NULL,SW_SHOWMAXIMIZED);
}

BOOL CPropertySheetWithLogoDlg::PreTranslateMessage(MSG* pMsg) 
{
    m_ToolTip.RelayEvent(pMsg);
    return CPropertySheet::PreTranslateMessage(pMsg);
}


void CPropertySheetWithLogoDlg::SetTipText(CString String)
{
  TipText=String;
  m_ToolTip.UpdateTipText(TipText,this,305);
}
