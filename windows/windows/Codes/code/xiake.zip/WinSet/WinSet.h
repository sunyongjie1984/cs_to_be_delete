// WinSet.h : main header file for the WINSET application
//

#if !defined(AFX_WINSET_H__C62226E6_5FD7_11D2_8573_ECD904C10000__INCLUDED_)
#define AFX_WINSET_H__C62226E6_5FD7_11D2_8573_ECD904C10000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CWinSetApp:
// See WinSet.cpp for the implementation of this class
//

class CWinSetApp : public CWinApp
{
public:
	bool GetModifyflag();
	void SetModifyflag();
	CString NumToString(DWORD nNum);
	void SetListboxWidth(CListBox &m_cListBox);
	CWinSetApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinSetApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CWinSetApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
protected:
	bool ModifyFlag;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WINSET_H__C62226E6_5FD7_11D2_8573_ECD904C10000__INCLUDED_)

