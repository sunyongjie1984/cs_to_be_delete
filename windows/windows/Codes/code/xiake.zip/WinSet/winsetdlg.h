// WindowSet.h : header file
//
// This class defines custom modal property sheet 
// CWinSetDlg.
 
#ifndef __WINDOWSET_H__
#define __WINDOWSET_H__

#include "StartMenu.h"
#include "ExplorerSet.h"
#include "AdddelSoft.h"
#include "General.h"
#include "StartrunProg.h"
#include "OtherItem.h"
#include "PropertySheetWithLogoDlg.h"

/////////////////////////////////////////////////////////////////////////////
// CWinSetDlg

class CWinSetDlg : public CPropertySheetWithLogoDlg
{
	DECLARE_DYNAMIC(CWinSetDlg)

// Construction
public:
	CWinSetDlg(CWnd* pWndParent = NULL);

// Attributes
public:
	void SetStatusText(LPCTSTR lpszText);
	void ShowStatusBar();
	CStartMenu m_StartmenuPage;
	CExplorerSet m_ExplorerSet;
	CAdddelSoft m_AdddelSoft;
	CGeneral m_General;
	CStartrunProg m_StartrunProg;
	COtherItem m_OtherItem;
	HICON m_hIcon;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinSetDlg)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	virtual void WinHelp(DWORD dwData, UINT nCmd = HELP_CONTEXT);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CWinSetDlg();

// Generated message map functions
protected:
	CStatusBarCtrl  m_wndStatusBar;
	bool MouseInMinibox;
	bool ShowStatus;
	CImageList m_imageTab;
	virtual void GoRun();
	//{{AFX_MSG(CWinSetDlg)
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	afx_msg void OnWinsetFiruse();
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg void OnDestroy();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// __WINDOWSET_H__
/////////////////////////////////////////////////////////////////////////////
// CInputPass dialog

class CInputPass : public CDialog
{
// Construction
public:
	CInputPass(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CInputPass)
	enum { IDD = IDD_PASSWORD };
	CString	m_sPassword;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInputPass)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInputPass)
	afx_msg void OnChangePassword();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
