#if !defined(AFX_PROPERTYSHEETWITHLOGODLG_H__D17EA810_E6A4_11D1_BB81_0040F684401F__INCLUDED_)
#define AFX_PROPERTYSHEETWITHLOGODLG_H__D17EA810_E6A4_11D1_BB81_0040F684401F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PropertySheetWithLogoDlg.h 
// һ�����ձ�����Ա�

/////////////////////////////////////////////////////////////////////////////
// CPropertySheetWithLogoDlg

class CPropertySheetWithLogoDlg : public CPropertySheet
{
	DECLARE_DYNAMIC(CPropertySheetWithLogoDlg)

// Construction
public:
	CPropertySheetWithLogoDlg(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);


// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropertySheetWithLogoDlg)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetLogoFont(CString Name, int nHeight = 24, int nWeight = FW_BOLD,
		BYTE bItalic = true, BYTE bUnderline = false);
	void SetLogoText(CString Text);
	void SetColor(COLORREF TextColor,COLORREF ShadowColor);
	virtual ~CPropertySheetWithLogoDlg();

	// Generated message map functions
protected:
	void SetTipText(CString String);
	virtual void GoRun();

	//{{AFX_MSG(CPropertySheetWithLogoDlg)
	afx_msg void OnPaint();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	CFont 	m_fontLogo; //�ձ�ʹ������
	CString m_LogoText; //�ձ��ı�
	COLORREF TextColor;	  //�ı���ɫ
	COLORREF ShadowColor; //�ı���Ӱ��ɫ
	CRect	TextRect;
	CToolTipCtrl m_ToolTip;
	CString TipText;		//��ʾ�ı�
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTYSHEETWITHLOGODLG_H__D17EA810_E6A4_11D1_BB81_0040F684401F__INCLUDED_)
