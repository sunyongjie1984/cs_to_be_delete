
#ifndef __CHECKFRM_H__
#define __CHECKFRM_H__

/*
����һ��������
*/

BOOL IsRectContainedInRect(CRect &rcChild, CRect &rcMother);

class CCheckFrame : public CObject
{
public:
	virtual void Enable(BOOL bEnable);
	void Set(CWnd *pParentWnd,UINT nFrmCtl);

	CWnd* m_pFrame; 
	CWnd* m_pDialog;
	CRect m_rFrm;
	CDWordArray m_adwWndHandles;


protected:
};

#endif