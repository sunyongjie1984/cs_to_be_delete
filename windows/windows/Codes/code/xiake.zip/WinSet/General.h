#if !defined(AFX_GENERAL_H__E5C06E43_660C_11D2_B397_9B53D16184AD__INCLUDED_)
#define AFX_GENERAL_H__E5C06E43_660C_11D2_B397_9B53D16184AD__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// General.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGeneral dialog
#include <afxtempl.h>

class CGeneral : public CPropertyPage
{
	DECLARE_DYNCREATE(CGeneral)

// Construction
public:
	bool Change;
	CGeneral();
	~CGeneral();

// Dialog Data
	//{{AFX_DATA(CGeneral)
	enum { IDD = IDD_GENERAL };
	CCheckListBox	m_cSetting;
	CEdit	m_cFoldLocal;
	CComboBox	m_cSpecFold;
	CString	m_sUserName;
	CString	m_sOrgName;
	CString	m_sSysVer;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CGeneral)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	bool Modify;
	//��ǰѡ���ļ���
	int CurSel;
	//ϵͳ�ļ���
	CArray<CString,CString> Folder;
	// Generated message map functions
	//{{AFX_MSG(CGeneral)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeSpecialfold();
	afx_msg void OnDestroy();
	afx_msg void OnChangelocal();
	afx_msg void OnChange();
	afx_msg void OnLChange();
	afx_msg void OnOpenSysfolder();
	afx_msg void OnRestoreSysfolder();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GENERAL_H__E5C06E43_660C_11D2_B397_9B53D16184AD__INCLUDED_)
