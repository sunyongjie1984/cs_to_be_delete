/*************************************************************************

BmpDlg.h header file

COpenBmpDialog: һ����λͼ�ļ���Ԥչ�Ի���
**************************************************************************/

#ifndef _BMPDIALOG_H_
#define _BMPDIALOG_H_
#include "HMHOpenFile.h"

// COpenBmpDialog dialog

class COpenBmpDialog : public CHMHOpenFile
{
	DECLARE_DYNAMIC(COpenBmpDialog)

public:
	COpenBmpDialog(BOOL bOpenFileDialog = TRUE, // TRUE for FileOpen, FALSE for FileSaveAs. Who would want a save with preview?
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT|OFN_FILEMUSTEXIST,
		LPCTSTR lpszFilter = NULL,
		CWnd* pParentWnd = NULL);

    static BOOL m_showpreview;  // Store this variable in the registry if you want the "Show Preview" setting to be persistent

    static HBITMAP hpreview;

protected:
	//{{AFX_MSG(COpenBmpDialog)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


#endif