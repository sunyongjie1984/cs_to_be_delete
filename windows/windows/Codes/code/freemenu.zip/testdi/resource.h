//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by testdi.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TESTDI_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define ID_MENUITEM32771                32771
#define ID_MENUITEM32772                32772
#define ID_MENUITEM32773                32773
#define ID_MENUITEM32774                32774
#define ID_MENUITEM32775                32775
#define ID_MENUITEM32776                32776
#define ID_MENUITEM32777                32777
#define ID_MENUITEM32778                32778
#define ID_MENUITEM32779                32779
#define ID_MENUITEM32780                32780
#define ID_MENUITEM32781                32781
#define ID_MENUITEM32782                32782
#define ID_MENUITEM32783                32783
#define ID_MENUITEM32784                32784
#define ID_MENUITEM32785                32785

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32786
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
