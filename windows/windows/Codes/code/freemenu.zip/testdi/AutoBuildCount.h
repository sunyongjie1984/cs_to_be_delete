// 4
#ifndef AUTOBUILDCOUNT_H
#define AUTOBUILDCOUNT_H
#define BUILDCOUNT_NUM 4
#define BUILDCOUNT_STR "4"
#endif
