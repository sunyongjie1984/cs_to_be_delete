#include<stdio.h>
#include<dos.h>
#define MemSize *(unsigned far *)0x00400013
void ReadStr(char *str)
{
 unsigned char Plength=1;
 unsigned xx,yy,x;
 union REGS r;
 xx=wherex();yy=wherey();
 x=xx;
 do{
     gotoxy(xx,yy);
     r.h.ah=0;
     int86(0x16,&r,&r);
     if((r.h.ah!=28)&&(r.h.ah!=14)&&(r.h.ah!=1))
     {
      *(str+Plength)=(r.h.al-20)|0x80;
      gotoxy(xx,yy);
      putch('*');
      xx++;Plength++;
     }
     else if(r.h.ah==14)
          {
           xx--;
           if(xx<x)xx=x;
           gotoxy(xx,yy);
           putch(' ');
           if(Plength>1)Plength--;
          }
          else if(r.h.ah==1)Plength=0;
    }while((r.h.ah!=28)&&(r.h.ah!=1)&&(Plength<15));
    *(str+0)=Plength-1;
}
int ReadPass(char *buffer)
{
 union REGS ireg;
 struct SREGS oreg;
 ireg.x.ax=0x0201;
 ireg.x.bx=FP_OFF(buffer);
 ireg.x.cx=0x0006;
 ireg.x.dx=0x0080;
 oreg.es=FP_SEG(buffer);
 int86x(0x50,&ireg,&ireg,&oreg);
 return ireg.h.ah;
}
int ReadPart(char *buffer)
{
 union REGS ireg;
 struct SREGS oreg;
 ireg.x.ax=0x0201;
 ireg.x.bx=FP_OFF(buffer);
 ireg.x.cx=0x0003;
 ireg.x.dx=0x0080;
 oreg.es=FP_SEG(buffer);
 int86x(0x50,&ireg,&ireg,&oreg);
 return ireg.h.ah;
}
int WritePart(char *buffer)
{
 union REGS ireg;
 struct SREGS oreg;
 ireg.x.ax=0x0301;
 ireg.x.bx=FP_OFF(buffer);
 ireg.x.cx=0x0001;
 ireg.x.dx=0x0080;
 oreg.es=FP_SEG(buffer);
 int86x(0x50,&ireg,&ireg,&oreg);
 return ireg.h.ah;
}
int CheckPass(char *src,char *dest)
{
 unsigned char Plength,p2;
 Plength=*(src+0);
 p2=*(dest+0);
 if(Plength!=p2)return -1;
 while(Plength>0)
 {
  if(*(src+Plength)!=*(dest+Plength))return -1;
  Plength--;
 }
 return 1;
}
void reboot(void)
{
 void (far *reboot_ptr)(void);
 unsigned int far *i_ptr;
 clrscr();
 i_ptr=MK_FP(0x0040,0x0072);
 *i_ptr=0x1234;
 reboot_ptr=MK_FP(0xF000,0xFFF0);
 reboot_ptr();
}
void copyright()
{
 printf("\n Babysoft  (R) Hard Disk Keeper Killer version 1.0");
 printf("\n Copyright (C) 1997.12 LiuYaDing,Babysoft Corp.\n");
}
void main()
{
 char buffer[512];
 char passwd[16],passwd1[16];
 char *source;
 char key;
 copyright();
 if(MemSize==0x280)
 {
  printf("\n\a Babysoft-Hard Disk Keeper Not Installed.");
  printf("\n If you boot from drive A: ,please try drive C: again.\n");
  exit(1);
 }
 while(ReadPass(buffer)!=0);
 source=buffer+0x200-32;
 printf("\n Password: ");
 ReadStr(passwd);
 if(CheckPass(source,passwd)==1)
 {
  while((ReadPart(buffer))!=0);
  while((WritePart(buffer))!=0);
  printf("\n Babysoft-Hard Disk Keeper Killed ok.");
  printf("\n Press any key reboot system...");
  getch();
  reboot();
 }
 else {printf("\n\a Wrong Password!");exit(1);}
}

