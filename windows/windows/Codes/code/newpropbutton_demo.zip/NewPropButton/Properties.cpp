// Properties.cpp : implementation file
//

#include "stdafx.h"
#include "NewPropButton.h"
#include "Properties.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProperties property page

IMPLEMENT_DYNCREATE(CProperties, CPropertyPage)

CProperties::CProperties() : CPropertyPage(CProperties::IDD)
{
	//{{AFX_DATA_INIT(CProperties)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CProperties::~CProperties()
{
}

void CProperties::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProperties)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CProperties, CPropertyPage)
	//{{AFX_MSG_MAP(CProperties)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProperties message handlers
