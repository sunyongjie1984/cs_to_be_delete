#if !defined(AFX_PROPERTIES_H__44E2B130_CA4F_11D2_BE77_080030002FC3__INCLUDED_)
#define AFX_PROPERTIES_H__44E2B130_CA4F_11D2_BE77_080030002FC3__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Properties.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CProperties dialog

class CProperties : public CPropertyPage
{
	DECLARE_DYNCREATE(CProperties)

// Construction
public:
	CProperties();
	~CProperties();

// Dialog Data
	//{{AFX_DATA(CProperties)
	enum { IDD = IDD_PROPERTYPAGE };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CProperties)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CProperties)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTIES_H__44E2B130_CA4F_11D2_BE77_080030002FC3__INCLUDED_)
