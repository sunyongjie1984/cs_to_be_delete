#define VC_EXTRALEAN


#include <afxext.h> 
#include <afxtempl.h>
