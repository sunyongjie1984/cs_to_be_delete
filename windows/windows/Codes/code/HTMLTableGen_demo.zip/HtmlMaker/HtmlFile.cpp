// HtmlFile.cpp : implementation of the CHtmlFile class
//

#include "stdafx.h"
#include "HtmlFile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CHtmlFile::CHtmlFile()
{
	m_sStyleFileName = _T("Style\\HtmlFile.dat");
	m_sHtmlContent = _T("");
}

CHtmlFile::~CHtmlFile()
{
}

BOOL CHtmlFile::ReadStyleFile()
{
	CString msg, data, styledata;
	int start, end;
	CFile m_File;
	char *cBuff;
	CFileStatus status;

	if (m_File.Open(m_sStyleFileName, CFile::modeRead, NULL) == 0) {
		msg.Format("Can't Open %s File!", m_sStyleFileName);
		AfxMessageBox(msg, MB_ICONEXCLAMATION);
		return FALSE;
	}

	m_File.GetStatus(status);

	// Read Data File;
	cBuff = (char *)calloc(status.m_size + 1, sizeof(char));
	m_File.Read(cBuff, status.m_size);
	styledata = cBuff;
	free(cBuff);

	// Extract Data from Style Content
	// Read Html Body
	start = 0;
	start = styledata.Find("[HTML_BODY]");
	start += 11;
	end = styledata.Find("[END]", start);
	m_sStyHeader = styledata.Mid(start, end - start);

	// Close TargetFile
	m_File.Close();
	return TRUE;
}

BOOL CHtmlFile::CreateHtmlFile(CString filename)
{
	CString data;

	ReadStyleFile();

	m_sTargetHtmlFile = filename;
	m_sTitle = _T("");

	m_sHtmlContent = _T("");

	// Write Header
	data = m_sStyHeader;
	data = SetData(data, _T("^TITLE^"), m_sTitle);

	m_sHtmlContent = data;

	return TRUE;
}

BOOL CHtmlFile::CreateHtmlFile(CString filename, CString title)
{
	CString data;

	ReadStyleFile();

	m_sTargetHtmlFile = filename;
	m_sTitle = title;

	m_sHtmlContent = _T("");

	// Write Header
	data = m_sStyHeader;
	data = SetData(data, _T("^TITLE^"), m_sTitle);

	m_sHtmlContent = data;

	return TRUE;
}

void CHtmlFile::AddTable(CHtmlTable *pTable)
{
	CString data;
	int start;

	start = m_sHtmlContent.Find("</body>");
	if (pTable->m_sTableContent == _T(""))
		pTable->MakeHtmlTable();

	m_sHtmlContent.Insert(start, pTable->m_sTableContent);
}

BOOL CHtmlFile::WriteHtmlFile()
{
	CFile file;
	CString msg;

	// Write TargetFile
//	CFile::Remove(m_sTargetHtmlFile);
	if (file.Open(m_sTargetHtmlFile, CFile::modeWrite | CFile::modeCreate, NULL) == 0) {
		msg.Format("Can't Write %s File!", m_sTargetHtmlFile);
		AfxMessageBox(msg, MB_ICONEXCLAMATION);
		return FALSE;
	}

	// Remove ^BODY^ tag
	m_sHtmlContent = SetData(m_sHtmlContent, _T("^BODY^"), _T("none"));
	file.Write(m_sHtmlContent.GetBuffer(0), m_sHtmlContent.GetLength());

	file.Close();

	return TRUE;
}

CString CHtmlFile::SetData(CString msg, CString sKey, CString text)
{
	int start;

	if (text == _T("")) text = _T("&nbsp");
	if (text == _T("none")) text = _T("");

	start = msg.Find(sKey);
	if (start == -1) return msg;
	msg.Delete(start, sKey.GetLength());
	msg.Insert(start, text);

	return msg;
}

CString CHtmlFile::GetMidData(CString msg, CString first, CString second)
{
	CString tmp;
	int start, end;

	start = 0;
	start = msg.Find(first);
	start += first.GetLength();
	end = msg.Find(second, start);

	if (start == -1 || end == -1) return msg;

	tmp = msg.Mid(start, end - start);
	tmp.TrimLeft();
	tmp.TrimRight();
	if (tmp == _T("")) tmp = _T("&nbsp;");

	return tmp;
}