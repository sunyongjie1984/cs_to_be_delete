// HtmlMakerView.h : interface of the CHtmlMakerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_HTMLMAKERVIEW_H__9DB890E6_AEBB_11D3_A0C3_080009B45370__INCLUDED_)
#define AFX_HTMLMAKERVIEW_H__9DB890E6_AEBB_11D3_A0C3_080009B45370__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CHtmlMakerView : public CHtmlView
{
protected: // create from serialization only
	CHtmlMakerView();
	DECLARE_DYNCREATE(CHtmlMakerView)

// Attributes
public:
	CHtmlMakerDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHtmlMakerView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnTitleChange(LPCTSTR lpszText);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CHtmlMakerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CHtmlMakerView)
	afx_msg void OnGenerate();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in HtmlMakerView.cpp
inline CHtmlMakerDoc* CHtmlMakerView::GetDocument()
   { return (CHtmlMakerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HTMLMAKERVIEW_H__9DB890E6_AEBB_11D3_A0C3_080009B45370__INCLUDED_)
