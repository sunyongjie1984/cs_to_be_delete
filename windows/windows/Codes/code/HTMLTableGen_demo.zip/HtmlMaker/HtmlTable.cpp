// HtmlTable.cpp : implementation of the CHtmlTable class
//

#include "stdafx.h"
#include "MainFrm.h"
#include "HtmlTable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Define default table type as HTML_TABLE_GRAY

CHtmlTable::CHtmlTable()
{
	m_iTableType = HTML_TABLE_GRAY;
	m_iRow = m_iColumn = m_iFixedRow = m_iFixedColumn = 0;
	m_iWidth = m_iColumn = 0;
	m_sTitle = m_sStyTable = m_sStyHeader = m_sStyData = _T("");
	m_sStyDataHeader1 = m_sStyDataHeader2 = _T("");
	m_sDataArray.RemoveAll();
	m_sHeaderArray.RemoveAll();
	m_sAddressArray.RemoveAll();
	m_sStyleFileName = _T("Style\\HtmlFile.dat");
}

CHtmlTable::CHtmlTable(CString title)
{
	m_iTableType = HTML_TABLE_GRAY;
	m_iRow = m_iColumn = m_iFixedRow = m_iFixedColumn = 0;
	m_iWidth = m_iColumn = 0;
	m_sTitle = title;
	m_sStyTable = m_sStyHeader = m_sStyData = _T("");
	m_sStyDataHeader1 = m_sStyDataHeader2 = _T("");
	m_sDataArray.RemoveAll();
	m_sHeaderArray.RemoveAll();
	m_sAddressArray.RemoveAll();
	m_sStyleFileName = _T("Style\\HtmlFile.dat");
}

CHtmlTable::~CHtmlTable()
{
	m_sDataArray.RemoveAll();
	m_sHeaderArray.RemoveAll();
	m_sAddressArray.RemoveAll();
}

BOOL CHtmlTable::ReadDataFile(CString filename)
{
	int start, end, i, j;
	CFile m_File;
	CFileStatus status;
	char *cBuff;
	CString data, msg, tmp, tabledata;

	if (m_File.Open(filename, CFile::modeRead, NULL) == 0) {
		msg.Format("Can't Open %s File!", filename);
		AfxMessageBox(msg, MB_ICONEXCLAMATION);
		return FALSE;
	}

	m_File.GetStatus(status);

	// Read Data File;
	cBuff = (char *)calloc(status.m_size + 1, sizeof(char));
	m_File.Read(cBuff, status.m_size);
	data = cBuff;
	free(cBuff);

	m_File.Close();

	// Read Title;
	m_sTitle = GetMidData(data, _T("[TITLE]"), _T("["));
	m_iTableType = GetMidIntData(data, _T("[TYPE]"), _T("["));
	m_iColumn = GetMidIntData(data, _T("[COLUMN]"), _T("["));
	m_iRow = GetMidIntData(data, _T("[ROW]"), _T("["));
	m_iFixedRow = GetMidIntData(data, _T("[FIXEDROW]"), _T("["));
	m_iFixedColumn = GetMidIntData(data, _T("[FIXEDCOLUMN]"), _T("["));
	m_iWidth = GetMidIntData(data, _T("[WIDTH]"), _T("["));

	// Read Table Data;
	tabledata = GetMidData(data, _T("[DATA]"), _T("[END]"));

	start = 0;
	i = j = 0;
	do {
		end = tabledata.Find(',', start);
		if (end == -1) break;
		tmp = tabledata.Mid(start, end-start);
		if (i < m_iColumn * m_iFixedRow) {
			m_sHeaderArray.Add(tmp);
			++i;
		}
		else {
			m_sDataArray.Add(tmp);
			++j;
		}
		start = end + 1;
	} while (end != -1);

	if (i != m_iColumn*m_iFixedRow) {
		msg.Format("%s file's Header data count is not equal to table header size.", filename);
		AfxMessageBox(msg, MB_ICONEXCLAMATION);
		return FALSE;
	}
	if (j != ((m_iRow - m_iFixedRow) * m_iColumn)) {
		msg.Format("%s file's data count is not equal to table size.", filename);
		AfxMessageBox(msg, MB_ICONEXCLAMATION);
		return FALSE;
	}

	// Make Table
	MakeHtmlTable();

	return TRUE;
}

void CHtmlTable::MakeHtmlTable()
{
	// Make Table Content String with DataArray
	CString tmp, data;
	int  i, j, start, end;

	tmp = data = _T("");

	ReadStyleFile(m_iTableType);

	// in case of Bitmap Button 
	if (m_iTableType == HTML_TABLE_BITMAP) {
		if (m_sAddressArray.GetSize() == m_sDataArray.GetSize() &&
			m_sAddressArray.GetSize() == m_iColumn) {
			data = _T("<TR>");
			for (i = 0; i < m_iColumn; ++i) {
				data += _T("<TD>");
				tmp = m_sStyData;
				if (m_sAddressArray.GetAt(i) == _T("") ||
					m_sAddressArray.GetAt(i) == _T("none") ||
					m_sAddressArray.GetAt(i) == _T("&nbsp;")) {
					start = tmp.Find("<a href");
					end = tmp.Find("S^");
					end += 4;
					tmp.Delete(start, end - start);
					start = tmp.Find("</a>");
					tmp.Delete(start, 4);
				}
				else {
					tmp = SetData(tmp, _T("^ADDRESS^"), m_sAddressArray.GetAt(i));
				}
				tmp = SetData(tmp, _T("^DATA^"), m_sDataArray.GetAt(i));
				data += _T("</TD>");
				data += tmp;
			}
			data += _T("</TR>");
		}

		m_sTableContent = m_sStyTable;

		// Set Table Width and Height
		m_sTableContent = SetData(m_sTableContent, _T("^WIDTH^"), m_iWidth);

		// Write Table Content
		m_sTableContent = SetData(m_sTableContent, _T("^BODY^"), data);
		return;
	}

	// in case of Table 
	if (m_sHeaderArray.GetSize() > 0) {
		for (i = 0; i < m_iFixedRow; ++i) {
			data = _T("<TR>");
			for (j = 0; j < m_iColumn; ++j) {
				tmp = m_sStyHeader;
				tmp = SetData(tmp, _T("^DATA^"), m_sHeaderArray.GetAt(i*m_iColumn + j));
				tmp = DrawCell(tmp, 0, j);
				data += tmp;
			}
			data += _T("</TR>");
		}
	}

	if (m_sDataArray.GetSize() > 0 &&
		m_sDataArray.GetSize() == (m_iRow - m_iFixedRow) * m_iColumn) {
		for (i = 0; i < m_iRow - m_iFixedRow; ++i) {
			data += _T("<TR>");
			switch(m_iFixedColumn) {
			case 1 :
				if (m_sStyDataHeader1 != _T(""))
					tmp = m_sStyDataHeader1;
				else tmp = m_sStyData;
				tmp = SetData(tmp, _T("^DATA^"), m_sDataArray.GetAt(i*m_iColumn));
				tmp = DrawCell(tmp, m_iFixedRow+i, 0);
				data += tmp;
				break;

			case 2 :
				if (m_sStyDataHeader1 != _T(""))
					tmp = m_sStyDataHeader1;
				else tmp = m_sStyData;
				tmp = SetData(tmp, _T("^DATA^"), m_sDataArray.GetAt(i*m_iColumn));
				tmp = DrawCell(tmp, m_iFixedRow+i, 0);
				data += tmp;

				if (m_sStyDataHeader2 != _T(""))
					tmp = m_sStyDataHeader2;
				else tmp = m_sStyData;
				tmp = SetData(tmp, _T("^DATA^"), m_sDataArray.GetAt(i*m_iColumn+1));
				tmp = DrawCell(tmp, m_iFixedRow+i, 1);
				data += tmp;
				break;
			}

			for (j = m_iFixedColumn; j < m_iColumn; ++j) {
				tmp = m_sStyData;
				tmp = SetData(tmp, _T("^DATA^"), m_sDataArray.GetAt(i*m_iColumn+j));
				tmp = DrawCell(tmp, m_iFixedRow+i, j);
				data += tmp;
			}
			data += _T("</TR>");
		}
	}
	else {
		if (m_sDataArray.GetSize() != m_iColumn * (m_iRow - m_iFixedRow)) 
			AfxMessageBox("data is lack to fill all table ce;;.", MB_ICONEXCLAMATION);
	}

	m_sTableContent = m_sStyTable;

	// Set Table Width and Height
	m_sTableContent = SetData(m_sTableContent, _T("^WIDTH^"), m_iWidth);

	// Write Table Title;
	if (m_sTitle == _T("") || m_sTitle == _T("&nbsp;")) {
		start = m_sTableContent.Find("<tr>");
		end = m_sTableContent.Find("</tr>");
		end += 5;
		m_sTableContent.Delete(start, end - start);
	}
	else {
		m_sTableContent = SetData(m_sTableContent, _T("^TABLETITLE^"), m_sTitle);
	}

	// Write Table Content
	m_sTableContent = SetData(m_sTableContent, _T("^BODY^"), data);
}

// Check cell boundary to draw line or not
CString CHtmlTable::DrawCell(CString cell, int row, int col)
{
	if (row == 0 && col == m_iColumn-1) {
		cell = SetData(cell, _T("^LEFT_SOLID^"), _T("solid"));
		cell = SetData(cell, _T("^RIGHT_SOLID^"), _T("solid"));
		cell = SetData(cell, _T("^TOP_SOLID^"), _T("solid"));
		cell = SetData(cell, _T("^BOTTOM_SOLID^"), _T("solid"));
	}
	else if (row == 0) {
		cell = SetData(cell, _T("^LEFT_SOLID^"), _T("solid"));
		cell = SetData(cell, _T("^RIGHT_SOLID^"), _T("none"));
		cell = SetData(cell, _T("^TOP_SOLID^"), _T("solid"));
		cell = SetData(cell, _T("^BOTTOM_SOLID^"), _T("solid"));
	}
	else if (col == m_iColumn-1) {
		cell = SetData(cell, _T("^LEFT_SOLID^"), _T("solid"));
		cell = SetData(cell, _T("^RIGHT_SOLID^"), _T("solid"));
		cell = SetData(cell, _T("^TOP_SOLID^"), _T("none"));
		cell = SetData(cell, _T("^BOTTOM_SOLID^"), _T("solid"));
	}
	else {
		cell = SetData(cell, _T("^LEFT_SOLID^"), _T("solid"));
		cell = SetData(cell, _T("^RIGHT_SOLID^"), _T("none"));
		cell = SetData(cell, _T("^TOP_SOLID^"), _T("none"));
		cell = SetData(cell, _T("^BOTTOM_SOLID^"), _T("solid"));
	}

	return cell;
}

// Write string data into cell
CString CHtmlTable::SetData(CString msg, CString sKey, CString text)
{
	int start;

	if (text == _T("")) text = _T("&nbsp;");
	if (text == _T("none")) text = _T("");

	start = msg.Find(sKey);
	if (start == -1) return msg;

	msg.Delete(start, sKey.GetLength());
	msg.Insert(start, text);

	return msg;
}

// Write integer value into cell
CString CHtmlTable::SetData(CString msg, CString sKey, int value)
{
	CString tmp;
	int start;

	tmp.Format("%d", value);
	tmp += _T("%");

	start = msg.Find(sKey);
	if (start == -1) return msg;
	msg.Delete(start, sKey.GetLength());
	msg.Insert(start, tmp);

	return msg;
}

CString CHtmlTable::GetMidData(CString msg, CString first, CString second)
{
	CString tmp;
	int start, end;

	start = 0;
	start = msg.Find(first);
	start += first.GetLength();
	end = msg.Find(second, start);

	if (start == -1 || end == -1) return msg;

	tmp = msg.Mid(start, end - start);

	tmp.TrimLeft();
	tmp.TrimRight();
	if (tmp == _T("")) tmp = _T("&nbsp;");
	return tmp;
}

CString CHtmlTable::GetMidData(CString msg, CString first, CString second, int startpoint)
{
	CString tmp;
	int start = 0, end;

	start = msg.Find(first, startpoint);
	start += first.GetLength();
	end = msg.Find(second, start);

	if (start == -1 || end == -1) return msg;

	tmp = msg.Mid(start, end - start);
	tmp.TrimLeft();
	tmp.TrimRight();
	if (tmp == _T("")) tmp = _T("&nbsp;");
	
	return tmp;
}

int CHtmlTable::GetMidIntData(CString msg, CString first, CString second)
{
	CString tmp;
	int start, value, end;

	start = 0;
	start = msg.Find(first);
	start += first.GetLength();
	end = msg.Find(second, start);

	if (start == -1 || end == -1) return -1;

	tmp = msg.Mid(start, end - start);
	tmp.TrimLeft();
	tmp.TrimRight();

	value = (int)atoi(tmp);
	return value;
}

BOOL CHtmlTable::ReadStyleFile(int TABLE_STYLE)
{
	CString msg, data, tmp, styledata, tabledata;
	int start, tablestart, tableend;
	CFile m_File;
	char *cBuff;
	CFileStatus status;

	if (m_File.Open(m_sStyleFileName, CFile::modeRead, NULL) == 0) {
		msg.Format("Can't Open %s File!", m_sStyleFileName);
		AfxMessageBox(msg, MB_ICONEXCLAMATION);
		return FALSE;
	}

	m_File.GetStatus(status);

	// Read Data File;
	cBuff = (char *)calloc(status.m_size + 1, sizeof(char));
	m_File.Read(cBuff, status.m_size);
	styledata = cBuff;
	free(cBuff);

	// Find Starting Point
	tmp.Format("[%d_", TABLE_STYLE);
	start = styledata.Find(tmp);

	start = styledata.Find("[TABLE]", start);		
	if (start == -1) return FALSE;

	// Read Table Data
	tablestart = start;
	tableend = styledata.Find("[END]", start);
	tableend += 5;

	tabledata = styledata.Mid(tablestart, tableend - tablestart);

	// Read Table Defintion
	tablestart = 7;
	tableend = tabledata.Find("[HEADER]", tablestart);

	m_sStyTable = tabledata.Mid(tablestart, tableend - tablestart);

	// Read Head Definition
	tablestart = tableend;
	tablestart += 8;
	tableend = tabledata.Find("[DATA]", tablestart);

	m_sStyHeader = tabledata.Mid(tablestart, tableend - tablestart);

	// Read Data Header Definition
	tablestart = tableend;
	tablestart += 6;

	if (tabledata.Find("[DATAHEADER2]", tablestart) != -1) {
		tableend = tabledata.Find("[DATAHEADER1]", tablestart);
		m_sStyData = tabledata.Mid(tablestart, tableend - tablestart);
		tablestart = tableend;
		tablestart += 13;

		tableend = tabledata.Find("[DATAHEADER2]", tablestart);
		m_sStyDataHeader1 = tabledata.Mid(tablestart, tableend - tablestart);
		tablestart = tableend;
		tablestart += 13;

		tableend = tabledata.Find("[END]", tablestart);
		m_sStyDataHeader2 = tabledata.Mid(tablestart, tableend - tablestart);
		tablestart = tableend;
		tablestart += 5;
	}
	else if (tabledata.Find("[DATAHEADER1]", tablestart) != -1) {
		tableend = tabledata.Find("[DATAHEADER1]", tablestart);
		m_sStyData = tabledata.Mid(tablestart, tableend - tablestart);
		tablestart = tableend;
		tablestart += 13;

		tableend = tabledata.Find("[END]", tablestart);
		m_sStyDataHeader1 = tabledata.Mid(tablestart, tableend - tablestart);
		tablestart = tableend;
		tablestart += 5;
	}
	else {
		tableend = tabledata.Find("[END]", tablestart);
		m_sStyData = tabledata.Mid(tablestart, tableend - tablestart);
		tablestart = tableend;
		tablestart += 5;
	}

	// Close TargetFile
	m_File.Close();

	return TRUE;
}