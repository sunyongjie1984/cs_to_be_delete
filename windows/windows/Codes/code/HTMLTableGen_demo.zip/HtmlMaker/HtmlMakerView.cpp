// HtmlMakerView.cpp : implementation of the CHtmlMakerView class
//

#include "stdafx.h"
#include "HtmlMaker.h"

#include "MainFrm.h"
#include "HtmlFile.h"
#include "HtmlTable.h"
#include "HtmlMakerDoc.h"
#include "HtmlMakerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHtmlMakerView

IMPLEMENT_DYNCREATE(CHtmlMakerView, CHtmlView)

BEGIN_MESSAGE_MAP(CHtmlMakerView, CHtmlView)
	//{{AFX_MSG_MAP(CHtmlMakerView)
	ON_COMMAND(ID_GENERATE, OnGenerate)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CHtmlView::OnFilePrint)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHtmlMakerView construction/destruction

CHtmlMakerView::CHtmlMakerView()
{
	// TODO: add construction code here

}

CHtmlMakerView::~CHtmlMakerView()
{
}

BOOL CHtmlMakerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CHtmlView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CHtmlMakerView drawing

void CHtmlMakerView::OnDraw(CDC* pDC)
{
	CHtmlMakerDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CHtmlMakerView::OnInitialUpdate()
{
	CHtmlView::OnInitialUpdate();

	// TODO: This code navigates to a popular spot on the web.
	//  change the code to go where you'd like.
	Navigate2(_T("about:blank"),NULL,NULL);
}

/////////////////////////////////////////////////////////////////////////////
// CHtmlMakerView printing


/////////////////////////////////////////////////////////////////////////////
// CHtmlMakerView diagnostics

#ifdef _DEBUG
void CHtmlMakerView::AssertValid() const
{
	CHtmlView::AssertValid();
}

void CHtmlMakerView::Dump(CDumpContext& dc) const
{
	CHtmlView::Dump(dc);
}

CHtmlMakerDoc* CHtmlMakerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CHtmlMakerDoc)));
	return (CHtmlMakerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHtmlMakerView message handlers

void CHtmlMakerView::OnGenerate() 
{
	CHtmlFile m_HtmlFile;
	CHtmlTable *pButton, *pTable;
	CString tmpStr, path;

	path = _T("result\\");

	// Write Html File
	m_HtmlFile.CreateHtmlFile(_T("result\\result.htm"), _T("Simulation Result"));

	// Init Table
	// Button Table
	pButton = new CHtmlTable();
	pButton->m_iTableType = HTML_TABLE_BITMAP;
	pButton->m_iColumn = 2;
	pButton->m_iRow = 1;
	pButton->m_iFixedRow = 0;
	pButton->m_iFixedColumn = 0;
	pButton->m_iWidth = 50;

	// Write Header Data
	pButton->m_sAddressArray.Add(_T("http://www.rist.re.kr/eng"));
	pButton->m_sAddressArray.Add(_T("http://www.codeguru.com"));

	// Write Table Data
	pButton->m_sDataArray.Add(_T("image\\rist.gif"));
	pButton->m_sDataArray.Add(_T("image\\codeguru.gif"));

	pButton->MakeHtmlTable();
	m_HtmlFile.AddTable(pButton);
	delete pButton;

	pTable = new CHtmlTable();
	pTable->ReadDataFile(path+_T("slab.txt"));
	m_HtmlFile.AddTable(pTable);
	delete pTable;

	pTable = new CHtmlTable();
	pTable->ReadDataFile(path+_T("size.txt"));
	m_HtmlFile.AddTable(pTable);
	delete pTable;

	pTable = new CHtmlTable();
	pTable->ReadDataFile(path+_T("Result.txt"));
	m_HtmlFile.AddTable(pTable);
	delete pTable;

	pTable = new CHtmlTable();
	pTable->ReadDataFile(path+_T("Result1.txt"));
	m_HtmlFile.AddTable(pTable);
	delete pTable;

	m_HtmlFile.WriteHtmlFile();

	char CurrentDirectory[256];

	::GetCurrentDirectory(255, CurrentDirectory);
	tmpStr.Format("%s\\result\\result.htm", CurrentDirectory);
	Navigate2(tmpStr,NULL,NULL);
}

void CHtmlMakerView::OnTitleChange(LPCTSTR lpszText) 
{
	CString m_strTitle;
	
	m_strTitle = lpszText;
	m_strTitle += _T(" - HtmlMaker");

	CWnd *pWnd = GetParent();
	if (pWnd != NULL) {
		if (::IsWindow(pWnd->m_hWnd)) {
			pWnd->SetWindowText((LPCTSTR)m_strTitle);
		}
	}

	UpdateData(FALSE);
}
