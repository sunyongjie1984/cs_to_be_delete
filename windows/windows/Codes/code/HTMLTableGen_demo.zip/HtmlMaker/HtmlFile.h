#ifndef HTML_FILE
#define HTML_FILE

#include "HtmlTable.h"

class CHtmlFile
{
public:
	CString m_sHtmlContent;

	BOOL CreateHtmlFile(CString filename);
	BOOL CreateHtmlFile(CString filename, CString title);
	void AddTable(CHtmlTable *pTable);

	CHtmlFile();
	virtual ~CHtmlFile();
	BOOL WriteHtmlFile();

protected:
	CString m_sStyHeader;
	CString m_sTitle;
	CString m_sTargetHtmlFile;
	CString m_sStyleFileName;
	CString SetData(CString msg, CString sKey, CString text);
	CString GetMidData(CString msg, CString first, CString Second);
	BOOL ReadStyleFile();
};

#endif