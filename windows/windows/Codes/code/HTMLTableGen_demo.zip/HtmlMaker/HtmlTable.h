#ifndef HTML_TABLE
#define HTML_TABLE

#define HTML_TABLE_GRAY			0
#define HTML_TABLE_WHITE		1
#define HTML_TABLE_GRAYBAND		2
#define HTML_TABLE_GRAY2BAND	3
#define HTML_TABLE_DARKGRAYBAND	4
#define HTML_TABLE_BITMAP		5

class CHtmlTable
{
public:
	int m_iTableType;
	int m_iRow, m_iColumn, m_iFixedRow, m_iFixedColumn;
	int m_iWidth, m_iHeight; // in percent 
	CString m_sStyleFileName;
	CString m_sTitle;
	CStringArray m_sAddressArray;
	CStringArray m_sDataArray;
	CStringArray m_sHeaderArray;
	CString m_sTableContent;

	CHtmlTable();
	CHtmlTable(CString title);
	virtual ~CHtmlTable();
	void MakeHtmlTable();
	BOOL ReadDataFile(CString filename);
	BOOL ReadStyleFile(int TABLE_STYLE);

protected:
	CString m_sStyTable;
	CString m_sStyHeader;
	CString m_sStyDataHeader1;
	CString m_sStyDataHeader2;
	CString m_sStyData;

protected:

	CString DrawCell(CString cell, int row, int col);
	CString SetData(CString msg, CString sKey, CString text);
	CString SetData(CString msg, CString sKey, int value);
	CString GetMidData(CString msg, CString first, CString Second);
	CString GetMidData(CString msg, CString first, CString second, int startpoint);
	int GetMidIntData(CString msg, CString first, CString Second);
};

#endif