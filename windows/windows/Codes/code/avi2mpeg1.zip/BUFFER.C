/*************************************************************************
*  mplex - MPEG/SYSTEMS multiplexer					 *
*  Copyright (C) 1994 1995 Christoph Moar				 *
*  Siemens ZFE ST SN 11 / T SN 6					 *
*									 *
*  moar@informatik.tu-muenchen.de 					 *
*       (Christoph Moar)			 			 *
*  klee@heaven.zfe.siemens.de						 *
*       (Christian Kleegrewe, Siemens only requests)			 *
*									 *
*  This program is free software; you can redistribute it and/or modify	 *
*  it under the terms of the GNU General Public License as published by	 *	
*  the Free Software Foundation; either version 2 of the License, or	 *
*  (at your option) any later version.					 *
*									 *
*  This program is distributed in the hope that it will be useful,	 *
*  but WITHOUT ANY WARRANTY; without even the implied warranty of	 *
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the	 *
*  GNU General Public License for more details.				 *
*									 *
*  You should have received a copy of the GNU General Public License	 *
*  along with this program; if not, write to the Free Software		 *
*  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.		 *
*************************************************************************/
/*
 * 4/4/97 - John Schlichther
 *
 * extensively altered to create avi2mpg1 - avi to mpeg-1 encoder
 *
 * Since avi file, and the avi subsystem are platform dependant, cross
 * platform compatibility removed, many optional features disabled or
 * removed, code generally trimmed to a minimum.
 *
 */
#include "mplex.h"
/******************************************************************
	Buffer_Clean
	entfern aus der verketteten Buffereintragsliste diejenigen
	Eintraege, deren DTS kleiner der aktuellen SCR ist. Diese
	Packetdaten sind naemlich bereits dekodiert worden und
	damit aus dem STD elementary stream buffer entfernt.

	Remove entries from FIFO buffer list, if their DTS is 
	less than actual SCR. These packet data have been already
	decoded and have been removed from the system target
	decoder's elementary stream buffer.
******************************************************************/

void buffer_clean (buffer, SCR)
Buffer_struc  *buffer;
Timecode_struc *SCR;
{
    Buffer_queue *pointer;

    while ((buffer->first != NULL) &&
	(comp_timecode(&buffer->first->DTS, SCR)))
    {
	pointer = buffer->first;
	buffer->first = buffer->first->next;
	free (pointer);	
    }
}

/******************************************************************
	Buffer_Space
	liefert den im Buffer noch freien Platz zurueck.

	returns free space in the buffer
******************************************************************/

unsigned  int buffer_space (buffer)
Buffer_struc *buffer;
{
    unsigned int used_bytes;
    Buffer_queue *pointer;

    pointer=buffer->first;
    used_bytes=0;

    while (pointer != NULL)
    {
	used_bytes += pointer->size;
	pointer = pointer->next;
    }

    return (buffer->max_size - used_bytes);

}

/******************************************************************
	Queue_Buffer
	fuegt einen Eintrag (bytes, DTS) in der Bufferkette ein.

	adds entry into the buffer FIFO queue
******************************************************************/

void queue_buffer (buffer, bytes, TS)
Buffer_struc *buffer;
unsigned int bytes;
Timecode_struc *TS;
{
    Buffer_queue *pointer;

    pointer=buffer->first;
    if (pointer==NULL)
    {
	buffer->first = (Buffer_queue*) malloc (sizeof (Buffer_queue));
	buffer->first->size = bytes;
	buffer->first->next=NULL;
	copy_timecode (TS, &buffer->first->DTS);
    } else
    {
	while ((pointer->next)!=NULL)
	{
	    pointer = pointer->next;
	}
    
	pointer->next = (Buffer_queue*) malloc (sizeof (Buffer_queue));
	pointer->next->size = bytes;
	pointer->next->next = NULL;
	copy_timecode (TS, &pointer->next->DTS);
    }
}
