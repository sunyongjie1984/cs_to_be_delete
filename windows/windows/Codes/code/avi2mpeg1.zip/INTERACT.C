/*************************************************************************
*  mplex - MPEG/SYSTEMS multiplexer					 *
*  Copyright (C) 1994 1995 Christoph Moar				 *
*  Siemens ZFE ST SN 11 / T SN 6					 *
*									 *
*  moar@informatik.tu-muenchen.de 					 *
*       (Christoph Moar)			 			 *
*  klee@heaven.zfe.siemens.de						 *
*       (Christian Kleegrewe, Siemens only requests)			 *
*									 *
*  This program is free software; you can redistribute it and/or modify	 *
*  it under the terms of the GNU General Public License as published by	 *	
*  the Free Software Foundation; either version 2 of the License, or	 *
*  (at your option) any later version.					 *
*									 *
*  This program is distributed in the hope that it will be useful,	 *
*  but WITHOUT ANY WARRANTY; without even the implied warranty of	 *
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the	 *
*  GNU General Public License for more details.				 *
*									 *
*  You should have received a copy of the GNU General Public License	 *
*  along with this program; if not, write to the Free Software		 *
*  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.		 *
*************************************************************************/
/*
 * 4/4/97 - John Schlichther
 *
 * extensively altered to create avi2mpg1 - avi to mpeg-1 encoder
 *
 * Since avi file, and the avi subsystem are platform dependant, cross
 * platform compatibility removed, many optional features disabled or
 * removed, code generally trimmed to a minimum.
 *
 */
#include <windows.h>
#include <vfw.h>

#include <stdio.h>
#include <stdlib.h>

#include "global.h"
#include "mplex.h"
/*************************************************************************
    File vorhanden?

    File found?
*************************************************************************/

int open_file(name, bytes)			
char *name;
unsigned int *bytes;				
{
    FILE* datei;

    datei=fopen (name, "rwb");
    if (datei==NULL)
    {	
	printf("File %s not found.\n", name);
	return (TRUE);
    }
    fseek (datei, 0, 2);
    *bytes = ftell(datei);
    fclose(datei);
    return (FALSE);
}


/*************************************************************************
	ask_continue
	Nach Anzeige der Streaminformationen Abfrage, ob weiter
	gearbeitet werden soll.

	After displaying Stream informations there is a check, wether
	we should continue computing or not.
*************************************************************************/

void ask_continue ()
{
    char input[20];

    printf ("\nContinue processing (y/n) : ");
    do gets (input);
    while (input[0]!='N'&&input[0]!='n'&&input[0]!='y'&&input[0]!='Y');

    if (input[0]=='N' || input[0]=='n')
    {
	printf ("\nStop processing.\n\n");
	exit (0);

    }

}

/*************************************************************************
	ask_verbose
	Soll die letzte, MPEG/SYSTEM Tabelle vollstaendig ausgegeben
	werden?

	Should we print the MPEG/SYSTEM table very verbose or not?
*************************************************************************/

unsigned char ask_verbose ()
{
    char input[20];

    printf ("\nVery verbose mode (y/n) : ");
    do gets (input);
    while (input[0]!='N'&&input[0]!='n'&&input[0]!='y'&&input[0]!='Y');

    if (input[0]=='N' || input[0]=='n') return (FALSE); else return (TRUE);
}

/******************************************************************
	Status_Info
	druckt eine Statuszeile waehrend des Multiplexens aus.

	prints a status line during multiplexing
******************************************************************/

void status_info (nsectors_a, nsectors_v, nsectors_p, nbytes, 
		  buf_v, buf_a,verbose)
unsigned int nsectors_a;
unsigned int nsectors_v;
unsigned int nsectors_p;
unsigned int nbytes;
unsigned int buf_v;
unsigned int buf_a;
unsigned char verbose;
{
    printf ("| %7d | %7d |",nsectors_a,nsectors_v);
    printf (" %7d | %11d |",nsectors_p,nbytes);
    printf (" %6d | %6d |",buf_a,buf_v);
    printf ((verbose?"\n":"\r"));
    fflush (stdout);
}

void status_header ()
{
    status_footer();
    printf("|  Audio  |  Video  | Padding | Bytes  MPEG | Audio  | Video  |\n");
    printf("| Sectors | Sectors | Sectors | System File | Buffer | Buffer |\n");
    status_footer();
}


void status_message (what)
unsigned char what;
{
  switch (what)
  {
  case STATUS_AUDIO_END:
  //printf("\n|file  end|         |         |             |        |        |\n");
	  audio_end_early++;
  break;
  case STATUS_AUDIO_TIME_OUT:
  //printf("\n|time  out|         |         |             |        |        |\n");
	  audio_time_out++;
  break;
  case STATUS_VIDEO_END:
  //printf("\n|         |file  end|         |             |        |        |\n");
	  video_end_early++;
  break;
  case STATUS_VIDEO_TIME_OUT:
  //printf("\n|         |time  out|         |             |        |        |\n");
	  video_time_out++;
  break;
  default:
	  fprintf(stderr, "\nInvalid mplex status message\n");
  }
}

void status_footer ()
{
  printf("+---------+---------+---------+-------------+--------+--------+\n");
}
