#include "resource.h"
#include "btnst.h"
/////////////////////////////////////////////////////////////////////////////
// CToolDlg dialog

class CToolDlg : public CDialogBar
{
public:
	CToolDlg();

// Dialog Data
	//{{AFX_DATA(CToolDlg)
	enum { IDD = IDD_TOOL };
	//}}AFX_DATA

private:
	CButtonST m_btnHome;
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToolDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CTollDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

