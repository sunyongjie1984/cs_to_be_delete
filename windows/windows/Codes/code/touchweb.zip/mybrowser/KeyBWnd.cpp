// KeyBWnd.cpp : implementation file
//

#include "stdafx.h"
#include "MyBrowser.h"
#include "KeyBWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKeyBWnd

CKeyBWnd::CKeyBWnd()
{
}

CKeyBWnd::~CKeyBWnd()
{
}


BEGIN_MESSAGE_MAP(CKeyBWnd, CWnd)
	//{{AFX_MSG_MAP(CKeyBWnd)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CKeyBWnd message handlers
