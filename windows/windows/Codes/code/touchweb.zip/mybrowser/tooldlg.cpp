#include "stdafx.h"
#include "btnst.h"
#include "tooldlg.h"

CToolDlg::CToolDlg() : CDialogBar()
{
	//{{AFX_DATA_INIT(CToolDlg)
	//}}AFX_DATA_INIT
}

BOOL CToolDlg::OnInitDialog()
{
	m_btnHome.SubclassDlgItem(ID_HOME, this);
	m_btnHome.SetIcon(IDR_MAINFRAME);

	return TRUE;
}

void CToolDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CToolDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CToolDlg, CDialog)
	//{{AFX_MSG_MAP(CToolDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

