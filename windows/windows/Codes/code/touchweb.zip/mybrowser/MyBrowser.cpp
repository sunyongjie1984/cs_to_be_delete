// MyBrowser.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "MyBrowser.h"

#include "MainFrm.h"
#include "MyBrowserDoc.h"
#include "MyBrowserView.h"
#include "screensaver.h"
#include "kbwnd.h"
#include "extern.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

char init_file[128];
char g_black_html[128];
BOOL g_fScreenSaverShowed =FALSE;
screensaver ScreenSaverWnd;
extern HWND g_hWndFrame, g_hDlgKeyB;
HWND g_hWndScreenSaver;
HANDLE g_hProcessApp =NULL;
HANDLE g_hThreadApp =NULL;

int ShowScreenSaver();
int UnShowScreenSaver();
int get_init();
int save_init();
int run_app();
int term_app();
int HideCursor();

/////////////////////////////////////////////////////////////////////////////
// CMyBrowserApp

BEGIN_MESSAGE_MAP(CMyBrowserApp, CWinApp)
	//{{AFX_MSG_MAP(CMyBrowserApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyBrowserApp construction

CMyBrowserApp::CMyBrowserApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
	char cur_path[128];

	GetCurrentDirectory(sizeof(cur_path), cur_path);
	wsprintf(init_file, "%s\\touchweb.ini", cur_path);
	wsprintf(g_black_html, "%s\\black.htm", cur_path);
	get_init();
}

CMyBrowserApp::~CMyBrowserApp()
{
	save_init();
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CMyBrowserApp object

CMyBrowserApp theApp;
HINSTANCE g_hInstance;
/////////////////////////////////////////////////////////////////////////////
// CMyBrowserApp initialization

BOOL CMyBrowserApp::InitInstance()
{
	AfxEnableControlContainer();
	g_hInstance =m_hInstance;
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CMyBrowserDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CMyBrowserView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
	// The one and only window has been initialized, so show and update it.
    m_pMainWnd->SetMenu(NULL);
	::SetWindowLong(m_pMainWnd->m_hWnd, GWL_STYLE, WS_POPUP);

	m_pMainWnd->ShowWindow(SW_MAXIMIZE);
	m_pMainWnd->UpdateWindow();
	create_keyboard();
	ScreenSaverWnd.Create();
	/*Ex(0,AfxRegisterWndClass(0, NULL, (HBRUSH)GetStockObject(BLACK_BRUSH), NULL),
		"", WS_POPUP, 0, 0, 2, 2, NULL, NULL, NULL);*/
	g_hWndScreenSaver =ScreenSaverWnd.m_hWnd;
	if(g_fShowCursor ==FALSE) HideCursor();
	//ShowScreenSaver(); // test
	return TRUE;
}

BOOL CMyBrowserApp::PreTranslateMessage(MSG *pmsg)
{
	static time_t t_start;
	time_t t;

	if(g_fActiveIdle)
	{
		time(&t);
		if(t_start ==0) t_start =t;
		if(t -t_start > g_IdleWaitTime*60)  // ��Ļ����ʱ������Ϊ����
		{
			if(!g_fScreenSaverShowed)
			{
				if(ShowScreenSaver() ==0)
					g_fScreenSaverShowed =TRUE;
			}
		}

		if(pmsg->message ==WM_LBUTTONDOWN || pmsg->message ==WM_RBUTTONDOWN
			|| pmsg->message ==WM_KEYDOWN/*||pmsg->message ==WM_MOUSEMOVE*/)
		{
			if(g_fScreenSaverShowed)
			{
 				UnShowScreenSaver();
				g_fScreenSaverShowed =FALSE;
				time(&t_start);
				return TRUE;
			}
			time(&t_start);
		}
	}
	return CWinApp::PreTranslateMessage(pmsg);
}

/////////////////////////////////////////////////////////////////////////////
// CMyBrowserApp commands

int CMyBrowserApp::ShowScreenSaver()	// ֻ������Windows��Ļ����
{
	switch(g_IdleType)
	{
	case TYPE_BITMAP:
		if(ScreenSaverWnd.m_hWnd ==NULL) return 0;
		if(ScreenSaverWnd.IsWindowVisible()) return 0;
		ScreenSaverWnd.Show();
		break;
	case TYPE_URL:
		CMyBrowserView *pview;
		pview =(CMyBrowserView *)((CMainFrame *)m_pMainWnd)->GetActiveView();
		if(pview && g_IdleURL[0]) pview->m_Browser.Navigate(g_IdleURL);
		break;
	case TYPE_APP:
		if(strstr(g_IdleApp, ".exe"))
			run_app();
		else
			ShellExecute(NULL, "Open", g_IdleApp, NULL, NULL, SW_MAXIMIZE);
		return 0;
	}
	return 0;
}

int CMyBrowserApp::UnShowScreenSaver()
{
	switch(g_IdleType)
	{
	case TYPE_BITMAP:
		if(ScreenSaverWnd.m_hWnd ==NULL) return 0;
		if(ScreenSaverWnd.IsWindowVisible())
			ScreenSaverWnd.Hide();
		break;
	case TYPE_URL:
		break;
	case TYPE_APP:
		if(strstr(g_IdleApp, ".exe"))
			term_app();
		else
		{
			HWND hwnd;
			hwnd =GetForegroundWindow();
			if(hwnd && (HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE) !=g_hInstance)
				SendMessage(hwnd, WM_CLOSE, 0, 0L);
		}
		break;
	}
	//SendMessage(g_hWndFrame, WM_COMMAND, ID_HOME, 0L);
	
	return 0;
}

int get_init()
{
	int i;
	char temp[80];

	GetPrivateProfileString("BROWSER", "home", "http://sdn.yeah.net", g_StartURL,
			sizeof(g_StartURL), init_file);
	g_fCanClose =GetPrivateProfileInt("BROWSER", "can_close", 0, init_file);
	g_BackSound[0] =0;
	GetPrivateProfileString("BROWSER", "back_sound", NULL, g_BackSound,
			sizeof(g_BackSound), init_file);
	g_ForbidURLCount =GetPrivateProfileInt("FORBITD_URL", "count", 0, init_file);
	for(i =0; i< g_ForbidURLCount && i<20; i++)
	{
		wsprintf(temp, "URL%d", i+1);
		if(GetPrivateProfileString("FORBITD_URL", temp, NULL, g_ForbidURLs[i],
			sizeof(g_ForbidURLs[i]), init_file) ==0)
			return -1;
	}
	g_fForbidFtp =GetPrivateProfileInt("BROWSER", "forbid_ftp", 0, init_file);
	g_fShowCursor =GetPrivateProfileInt("BROWSER", "show_cursor", 0, init_file);
	g_fActiveIdle =GetPrivateProfileInt("SCREENSAVER", "active", 1, init_file);
	g_IdleWaitTime =GetPrivateProfileInt("SCREENSAVER", "wait_time", 5, init_file);
	g_IdleType =GetPrivateProfileInt("SCREENSAVER", "type", 0, init_file);
	g_IdleImageCount =GetPrivateProfileInt("IDLE_IMAGES", "count", 0, init_file);
	for(i =0; i< g_IdleImageCount && i<20; i++)
	{
		wsprintf(temp, "IMAGE%d", i+1);
		if(GetPrivateProfileString("IDLE_IMAGES", temp, NULL, g_IdleImages[i],
			sizeof(g_IdleImages[i]), init_file) ==0)
			return -1;
	}
	GetPrivateProfileString("SCREENSAVER", "URL", NULL, g_IdleURL,
			sizeof(g_IdleURL), init_file);
	g_IdleApp[0] =0;
	GetPrivateProfileString("SCREENSAVER", "APP", NULL, g_IdleApp,
			sizeof(g_IdleApp), init_file);

	return 0;
}

int save_init()
{
	int i;
	char temp[80];

	WritePrivateProfileString("BROWSER", "home", g_StartURL, init_file);
	WritePrivateProfileString("BROWSER", "back_sound", g_BackSound, init_file);
	wsprintf(temp, "%d", g_fCanClose);
	WritePrivateProfileString("BROWSER", "can_close", temp, init_file);
	wsprintf(temp, "%d", g_ForbidURLCount);
	WritePrivateProfileString("FORBITD_URL", "count", temp, init_file);
	for(i =0; i< g_ForbidURLCount && i<20; i++)
	{
		wsprintf(temp, "URL%d", i+1);
		WritePrivateProfileString("FORBITD_URL", temp, g_ForbidURLs[i], init_file);
	}
	wsprintf(temp, "%d", g_fForbidFtp);
	WritePrivateProfileString("BROWSER", "forbid_ftp", temp, init_file);
	wsprintf(temp, "%d", g_fShowCursor);
	WritePrivateProfileString("BROWSER", "show_cursor", temp, init_file);
	wsprintf(temp, "%d", g_fActiveIdle);
	WritePrivateProfileString("SCREENSAVER", "active", temp, init_file);
	wsprintf(temp, "%d", g_IdleType);
	WritePrivateProfileString("SCREENSAVER", "type", temp, init_file);
	wsprintf(temp, "%d", g_IdleWaitTime);
	WritePrivateProfileString("SCREENSAVER", "wait_time", temp, init_file);
	wsprintf(temp, "%d", g_IdleImageCount);
	WritePrivateProfileString("IDLE_IMAGES", "count", temp, init_file);
	for(i =0; i< g_IdleImageCount && i<20; i++)
	{
		wsprintf(temp, "IMAGE%d", i+1);
		WritePrivateProfileString("IDLE_IMAGES", temp, g_IdleImages[i], init_file);
	}
	WritePrivateProfileString("SCREENSAVER", "URL", g_IdleURL, init_file);
	WritePrivateProfileString("SCREENSAVER", "APP", g_IdleApp, init_file);

	return 0;
}

int run_app()
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	if(g_IdleApp[0] ==0) return 0;
	memset(&si, 0, sizeof(si));
	if(CreateProcess(g_IdleApp, g_IdleApp, NULL, NULL, false, 0, NULL, NULL, &si, &pi) ==0)
		return -1;
	g_hThreadApp =pi.hThread;
	g_hProcessApp =pi.hProcess;

	return 0;
}

int term_app()
{
	if(g_hProcessApp)
	{
		TerminateProcess(g_hProcessApp, 1);
		CloseHandle(g_hThreadApp);
		CloseHandle(g_hProcessApp);
		g_hThreadApp =NULL;
		g_hProcessApp =NULL;
	}

	return 0;
}

int HideCursor()
{
	return ShowCursor(FALSE);
}

HWND GetBrowserWnd()
{
	CMyBrowserView *pview =(CMyBrowserView *)((CFrameWnd *)theApp.m_pMainWnd)->GetActiveView();

	if(pview ==NULL) return NULL;
	CWnd *pwnd =pview->m_Browser.GetWindow(GW_CHILD);
	if(pwnd)
		pwnd =pwnd->GetWindow(GW_CHILD);
	if(pwnd)
		return pwnd->m_hWnd;
	else return NULL;
}

