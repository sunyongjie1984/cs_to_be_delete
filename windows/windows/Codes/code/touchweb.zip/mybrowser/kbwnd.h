int destroy_keyboard();
int create_keyboard();
extern HWND g_hDlgKeyB, g_hWndFocus;