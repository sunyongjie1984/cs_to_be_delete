// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include <mmsystem.h>
#include "MyBrowser.h"
#include "resource.h"
#include "btnst.h"
#include "MainFrm.h"
#include "extern.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame
HWND g_hWndFrame =NULL;
IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_WM_PARENTNOTIFY()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	g_hWndFrame =m_hWnd;
	SetTimer(1, 3000, NULL);
/*	if (!m_wndToolBar.CreateEx(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |CBRS_FLYBY|CBRS_FLOAT_MULTI);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	//DockControlBar(&m_wndToolBar);
	CPoint pt;
	pt.x =10; pt.y =10;
	FloatControlBar(&m_wndToolBar, pt);
*/	
/*	m_wndDlgBar.Create(this, MAKEINTRESOURCE(IDD_TOOL), CBRS_BOTTOM, IDD_TOOL);
	m_btnHome.SubclassDlgItem(ID_HOME, &m_wndDlgBar);
	m_btnHome.SetBitmap(IDB_HOME);//, IDB_HOME, 64, 64);
	m_btnUrl.SubclassDlgItem(ID_URL, &m_wndDlgBar);
	m_btnUrl.SetBitmap(IDB_URL);//, IDB_HOME, 64, 64);
	m_btnBack.SubclassDlgItem(ID_BACK, &m_wndDlgBar);
	m_btnBack.SetBitmap(IDB_BACK);//, IDB_HOME, 64, 64);
	m_btnForward.SubclassDlgItem(IDC_FORWARD, &m_wndDlgBar);
	m_btnForward.SetBitmap(IDB_FORWARD);//, IDB_HOME, 64, 64);
	m_btnLeft.SubclassDlgItem(ID_LEFT, &m_wndDlgBar);
	m_btnLeft.SetBitmap(IDB_LEFT);//, IDB_HOME, 64, 64);
	m_btnTop.SubclassDlgItem(ID_TOP, &m_wndDlgBar);
	m_btnTop.SetBitmap(IDB_TOP);//, IDB_HOME, 64, 64);
	m_btnRight.SubclassDlgItem(ID_RIGHT, &m_wndDlgBar);
	m_btnRight.SetBitmap(IDB_RIGHT);//, IDB_HOME, 64, 64);
	m_btnBottom.SubclassDlgItem(ID_BOTTOM, &m_wndDlgBar);
	m_btnBottom.SetBitmap(IDB_BOTTOM);//, IDB_HOME, 64, 64);
	m_btnSearch.SubclassDlgItem(ID_FIND, &m_wndDlgBar);
	m_btnSearch.SetBitmap(IDB_FIND);//, IDB_HOME, 64, 64);
*/
	/*m_wndDlgBar.SetBarStyle(m_wndDlgBar.GetBarStyle() |CBRS_FLYBY|CBRS_FLOAT_MULTI);
	m_wndDlgBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndDlgBar);
	*/
	if(g_BackSound[0])
		//PlaySound(g_BackSound, NULL, SND_LOOP|SND_ASYNC|SND_FILENAME);
		sndPlaySound(g_BackSound, SND_LOOP|SND_ASYNC);
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
//extern HWND g_hWndScreenSaver;
void CMainFrame::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	if(g_fCanClose ==FALSE) return;

	PlaySound(NULL, NULL, 0);
	KillTimer(1);
	CFrameWnd::OnClose();
}
void CMainFrame::OnParentNotify(UINT msg, LPARAM lParam) 
{
	// TODO: Add your message handler code here and/or call default
	
	CFrameWnd::OnParentNotify(msg, lParam);
	//if(msg ==WM_LBUTTONDOWN) MessageBeep(0);
}

void CMainFrame::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	CFrameWnd::OnTimer(nIDEvent);
}
