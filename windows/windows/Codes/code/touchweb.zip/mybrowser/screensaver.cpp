// screensaver.cpp : implementation file
//

#include "stdafx.h"
#include "MyBrowser.h"
#include "webbrowser.h"
#include "screensaver.h"
#include "extern.h"
#include "dib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// screensaver

screensaver::screensaver()
{
	m_num =0;
}

screensaver::~screensaver()
{
}


BEGIN_MESSAGE_MAP(screensaver, CWnd)
	//{{AFX_MSG_MAP(screensaver)
	ON_WM_CLOSE()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// screensaver message handlers
extern char g_black_html[128];
BOOL screensaver::Create()
{
	if(!CreateEx(0,AfxRegisterWndClass(0, NULL, (HBRUSH)GetStockObject(BLACK_BRUSH), NULL),
		"", WS_POPUP|WS_MAXIMIZE, 0, 0, 2, 2, NULL, NULL, NULL))
		return FALSE;
	return TRUE;
}

int screensaver::Show()
{
	m_num =0;
	SetTimer(1, 5000, NULL);
	::SetWindowPos(m_hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE|SWP_SHOWWINDOW);
	SendMessage(WM_TIMER, 1, 0L);
	return 0;
}

int screensaver::Hide()
{
	KillTimer(1);
	ShowWindow(SW_HIDE);
	return 0;
}

void screensaver::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	CWnd::OnClose();
}

void screensaver::OnTimer(UINT nIDEvent) 
{
	RECT rc, rcClient;

	if(g_IdleImageCount <=0) return;
	m_num %=g_IdleImageCount;
	GetClientRect(&rcClient);
	CFile m_file;
	if(m_file.Open(g_IdleImages[m_num], CFile::modeRead) ==0) return;
	CDib *pdib =new CDib();
	if(pdib->Read(m_file))
	{
		rc.left =rc.top =0;
		rc.right =pdib->Width();
		rc.bottom =pdib->Height();
		rcClient.left =(rcClient.right-rc.right)/2;
		rcClient.top =(rcClient.bottom-rc.bottom)/2;
		rcClient.right =rcClient.left+rc.right;
		rc.bottom =rcClient.top+rc.bottom;
		CDC *pDC =GetDC();
		pdib->Paint(pDC->m_hDC, &rcClient, &rc);
		ReleaseDC(pDC);
	}
	m_file.Close();
	m_num++;
	delete pdib;

	CWnd::OnTimer(nIDEvent);
}
