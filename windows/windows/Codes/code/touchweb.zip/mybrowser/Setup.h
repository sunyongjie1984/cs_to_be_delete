#if !defined(AFX_SETUP_H__2CB37B40_B854_11D3_AF02_001060FC88D5__INCLUDED_)
#define AFX_SETUP_H__2CB37B40_B854_11D3_AF02_001060FC88D5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Setup.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSetup dialog

class CSetup : public CDialog
{
// Construction
public:
	CSetup(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSetup)
	enum { IDD = IDD_SETUP };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetup)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSetup)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETUP_H__2CB37B40_B854_11D3_AF02_001060FC88D5__INCLUDED_)
