// SetupSheet.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "MyBrowser.h"
#include "SetupSheet.h"
#include "extern.h"
#include "urldlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

LRESULT CALLBACK PageProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
WNDPROC OldPageProc;
extern HWND GetBrowserWnd();
/////////////////////////////////////////////////////////////////////////////
// SetupSheet

IMPLEMENT_DYNAMIC(SetupSheet, CPropertySheet)

SetupSheet::SetupSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
}

SetupSheet::SetupSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	PageScreensaver.Construct(IDD_SET_SCREENSAVER);
	PageBrowser.Construct(IDD_SET_BROWSER);
	AddPage(&PageBrowser);
	AddPage(&PageScreensaver);
}

SetupSheet::~SetupSheet()
{
}


BEGIN_MESSAGE_MAP(SetupSheet, CPropertySheet)
	//{{AFX_MSG_MAP(SetupSheet)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// SetupSheet message handlers

BOOL SetupSheet::OnInitDialog() 
{
	char temp[20];

	BOOL bResult = CPropertySheet::OnInitDialog();
	
	//HWND hwnd =::GetDlgItem(m_hWnd, IDD_SET_BROWSER);

	// TODO: Add your specialized code here
	PageBrowser.SetDlgItemText(IDE_HOME, g_StartURL);
	PageBrowser.SetDlgItemText(IDE_BACKSOUND, g_BackSound);
	int i;
	for(i =0; i<g_ForbidURLCount; i++)
		PageBrowser.SendDlgItemMessage(IDC_FORBIDURLS, LB_ADDSTRING, 0, (LPARAM)g_ForbidURLs[i]);
	if(g_fShowCursor) PageBrowser.CheckDlgButton(IDC_SHOW_CURSOR, BST_CHECKED);
	if(g_fForbidFtp) PageBrowser.CheckDlgButton(IDC_FORBID_FTP, BST_CHECKED);
	SetActivePage(1);
	if(g_fActiveIdle)
		PageScreensaver.CheckDlgButton(IDC_ALLOW_IDLE, BST_CHECKED);
	wsprintf(temp, "%d", g_IdleWaitTime);
	PageScreensaver.SetDlgItemText(IDC_WAIT_TIME, temp);
	switch(g_IdleType)
	{
	case TYPE_BITMAP:
		PageScreensaver.CheckDlgButton(IDC_SHOW_GRAPH, BST_CHECKED);
		break;
	case TYPE_URL:
		PageScreensaver.CheckDlgButton(IDC_SHOW_HTTP, BST_CHECKED);
		break;
	case TYPE_APP:
		PageScreensaver.CheckDlgButton(IDC_RUN_FILE, BST_CHECKED);
		break;
	}
	for(i =0; i<g_IdleImageCount; i++)
		PageScreensaver.SendDlgItemMessage(IDC_IMAGES, LB_ADDSTRING, 0, (LPARAM)g_IdleImages[i]);
	PageScreensaver.SetDlgItemText(IDE_IDLE_URL, g_IdleURL);
	PageScreensaver.SetDlgItemText(IDE_IDLE_APP, g_IdleApp);
	
	OldPageProc =(WNDPROC)::GetWindowLong(PageBrowser.m_hWnd, GWL_WNDPROC);
	::SetWindowLong(PageBrowser.m_hWnd, GWL_WNDPROC, (LONG)(WNDPROC)PageProc);
	//OldPage2Proc =(WNDPROC)::GetWindowLong(PageScreensaver.m_hWnd, GWL_WNDPROC);
	::SetWindowLong(PageScreensaver.m_hWnd, GWL_WNDPROC, (LONG)(WNDPROC)PageProc);
	SetActivePage(0);

	return bResult;
}

extern int save_init();

BOOL SetupSheet::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	switch(wParam)
	{
	case IDOK:
		int i;
		PageBrowser.GetDlgItemText(IDE_HOME, g_StartURL, sizeof(g_StartURL));
		PageBrowser.GetDlgItemText(IDE_BACKSOUND, g_BackSound, sizeof(g_BackSound));
		g_ForbidURLCount =PageBrowser.SendDlgItemMessage(IDC_FORBIDURLS, LB_GETCOUNT, 0, 0L);
		for(i =0; i<g_ForbidURLCount; i++)
			PageBrowser.SendDlgItemMessage(IDC_FORBIDURLS, LB_GETTEXT, i, (LPARAM)g_ForbidURLs[i]);
		g_fShowCursor =PageBrowser.IsDlgButtonChecked(IDC_SHOW_CURSOR);
		
		g_fForbidFtp = PageBrowser.IsDlgButtonChecked(IDC_FORBID_FTP);
		g_fActiveIdle =PageScreensaver.IsDlgButtonChecked(IDC_ALLOW_IDLE);
		g_IdleWaitTime =PageScreensaver.GetDlgItemInt(IDC_WAIT_TIME);
		if(PageScreensaver.IsDlgButtonChecked(IDC_SHOW_GRAPH))
			g_IdleType =TYPE_BITMAP;
		else if(PageScreensaver.IsDlgButtonChecked(IDC_SHOW_HTTP))
			g_IdleType =TYPE_URL;
		else g_IdleType =TYPE_APP;
		g_IdleImageCount =PageScreensaver.SendDlgItemMessage(IDC_IMAGES, LB_GETCOUNT, 0, 0L);
		for(i =0; i<g_IdleImageCount; i++)
			PageScreensaver.SendDlgItemMessage(IDC_IMAGES, LB_GETTEXT, i, (LPARAM)g_IdleImages[i]);
		PageScreensaver.GetDlgItemText(IDE_IDLE_URL, g_IdleURL, sizeof(g_IdleURL));
		PageScreensaver.GetDlgItemText(IDE_IDLE_APP, g_IdleApp, sizeof(g_IdleApp));
		save_init();
		break;
	}
	return CPropertySheet::OnCommand(wParam, lParam);
}

LRESULT CALLBACK PageProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	CFileDialog *fd;
	UrlDlg *ud;
	int i;
	
	switch(msg)
	{
	case WM_COMMAND:
		switch(wParam)
		{
		case IDC_OPENDIALOG:
			fd =new CFileDialog(true, "*.htm;*.htm", "*.htm;*.html", 0, "html files (*.htm;*.html)|*.htm;*.html||", NULL);
			if(fd->DoModal() ==IDOK)
				SetDlgItemText(hWnd, IDE_HOME, fd->GetPathName());
			delete fd;
			break;

		case IDC_BACK_SOUND:
			fd =new CFileDialog(true, "*.wav", "*.wav", 0, "wave files (*.wav)|*.wav||", NULL);
			if(fd->DoModal() ==IDOK)
				SetDlgItemText(hWnd, IDE_BACKSOUND, fd->GetPathName());
			delete fd;
			break;
		case IDC_OPENDIALOG2:
			fd =new CFileDialog(true, "*.htm;*.html", "*.htm;*.html", 0, "html files (*.htm;*.html)|*.htm;*.html||", NULL);
			if(fd->DoModal() ==IDOK)
				SetDlgItemText(hWnd, IDE_IDLE_URL, fd->GetPathName());
			delete fd;
			break;
		case IDC_OPENDIALOG3:
			fd =new CFileDialog(true, "*.exe;*.scr", "*.exe;*.scr", 0, "html files (*.exe;*.scr)|*.exe;*.scr||", NULL);
			if(fd->DoModal() ==IDOK)
				SetDlgItemText(hWnd, IDE_IDLE_APP, fd->GetPathName());
			delete fd;
			break;
		case IDC_ADD_IMAGE:
			fd =new CFileDialog(true, "*.bmp", "*.bmp", 0, "Bitmap files (*.bmp)|*.bmp||", NULL);
			if(fd->DoModal() ==IDOK)
			{
				if(SendDlgItemMessage(hWnd, IDC_IMAGES, LB_GETCOUNT, 0, 0L) <20)
					SendDlgItemMessage(hWnd, IDC_IMAGES, LB_ADDSTRING, 0, (LPARAM)LPCTSTR(fd->GetPathName()));
				else
					MessageBox(hWnd, "���ֻ����20��", "webtouch", MB_OK);
			}
			delete fd;
			break;

		case IDC_ADD_URL:
			ud =new UrlDlg();
			if(ud->DoModal() ==IDOK)
			{
				if(SendDlgItemMessage(hWnd, IDC_FORBIDURLS, LB_GETCOUNT, 0, 0L) <20)
					SendDlgItemMessage(hWnd, IDC_FORBIDURLS, LB_ADDSTRING, 0, (LPARAM)LPCTSTR(ud->m_Edit));
				else
					MessageBox(hWnd, "���ֻ����20��", "webtouch", MB_OK);
			}
			delete ud;
			break;
		case IDC_ALLOW_IDLE:
			break;
		case IDC_DEL_URL:
			if((i =SendDlgItemMessage(hWnd, IDC_FORBIDURLS, LB_GETCURSEL, 0, 0L)) >=0)
				SendDlgItemMessage(hWnd, IDC_FORBIDURLS, LB_DELETESTRING, i, 0L);
			break;
		case IDC_DEL_IMAGE:
			if((i =SendDlgItemMessage(hWnd, IDC_IMAGES, LB_GETCURSEL, 0, 0L)) >=0)
				SendDlgItemMessage(hWnd, IDC_IMAGES, LB_DELETESTRING, i, 0L);
			break;
		case IDC_SET_IE:
			HWND hwnd;
			hwnd =GetBrowserWnd();
			if(hwnd)
				SendMessage(GetBrowserWnd(), WM_COMMAND, 2135, 0L);
			else ShellExecute(hWnd, "open", "control.exe", "inetcpl.cpl", ".", SW_SHOW);
			break;
		}
		break;
	}
	return CallWindowProc(OldPageProc, hWnd, msg, wParam, lParam);
}
