// �����̣�������800x600������ʾ
#include "stdafx.h"
#include <imm.h>
#include "resource.h"
#include "kb_data.h"
#include "kbwnd.h"

LRESULT CALLBACK KBWndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK BtnProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
WNDPROC OldBtnProc;
extern HINSTANCE g_hInstance;
HWND g_hDlgKeyB =NULL;
HWND g_hWndFocus =NULL;
HBITMAP g_hBmpKeyB =NULL;
int g_bmpWidth =0, g_bmpHeight =0;
void SetKBEvent(BYTE key, BYTE scancode, BOOL f_down);
extern HWND g_hWndFrame;
int DrawTest(HWND hDlg, char *str);
int create_keyboard()
{
	int x, y;
	RECT rc;
	WNDCLASS wc;

	memset(&wc, 0, sizeof(wc));
	wc.lpfnWndProc =KBWndProc;
	wc.lpszClassName ="myKBWnd";
	wc.hInstance =g_hInstance;
	wc.hbrBackground =(HBRUSH)GetStockObject(LTGRAY_BRUSH);
	wc.hCursor =LoadCursor(NULL, IDC_ARROW);
	if(!RegisterClass(&wc))
		return -1;
	BITMAP bmp;
	g_hBmpKeyB =LoadBitmap(g_hInstance, MAKEINTRESOURCE(IDB_KEYBOARD));
	if(g_hBmpKeyB ==NULL) return -1;
	GetObject(g_hBmpKeyB, sizeof(bmp), &bmp);
	g_bmpWidth =bmp.bmWidth;
	g_bmpHeight =bmp.bmHeight;
	//g_hDlgKeyB =Create(g_hInstance, MAKEINTRESOURCE(IDD_KEYBOARD), g_hWndFrame, KBDlgProc);
	g_hDlgKeyB =::CreateWindowEx(0, "myKBWnd", "myKBWnd", WS_POPUP, 0, 0, 20, 20, g_hWndFrame, NULL, g_hInstance, NULL);
	if(g_hDlgKeyB ==NULL) return -2;
	x =GetSystemMetrics(SM_CXSCREEN);
	y =GetSystemMetrics(SM_CYSCREEN);
	GetClientRect(GetDlgItem(g_hDlgKeyB, ID_SHOW_KEYBOARD), &rc);
	SetWindowPos(g_hDlgKeyB, HWND_TOPMOST, x -rc.right-2, y-rc.bottom-2, 
		bmp.bmWidth+rc.right+4,bmp.bmHeight+2, SWP_NOACTIVATE);
	ShowWindow(g_hDlgKeyB, SW_SHOWNOACTIVATE);
	//SendMessage(g_hDlgKeyB, WM_COMMAND, ID_SHOW_KEYBOARD, 0L);
	return 0;
}

int destroy_keyboard()
{
	if(g_hBmpKeyB) DeleteObject(g_hBmpKeyB);
	return 0;
}

LRESULT CALLBACK KBWndProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	RECT rc;
	HDC hDC;
	static int cur_button =-1;
	int i, x;
	static BOOL f_shift_down =0;
	static BOOL f_caps_down =0;
	static BOOL f_chinese =0;
	char temp[80];
	static int x_start, y_start;
	static RECT rcMove;

	HWND hwnd;

	switch(msg)
	{
	case WM_CREATE:
		hwnd =CreateWindow("Button", "��ʾ����", WS_CHILD|WS_VISIBLE, 0, 0, 80, 30, hDlg, (HMENU)ID_SHOW_KEYBOARD, g_hInstance, NULL);
		OldBtnProc =(WNDPROC)GetWindowLong(hwnd, GWL_WNDPROC);
		SetWindowLong(hwnd, GWL_WNDPROC, (LONG)(WNDPROC)BtnProc);
		hwnd =CreateWindow("Button", "��������", WS_CHILD|WS_VISIBLE, 0, 35, 80, 30, hDlg, (HMENU)ID_CHINESE, g_hInstance, NULL);
		OldBtnProc =(WNDPROC)GetWindowLong(hwnd, GWL_WNDPROC);
		SetWindowLong(hwnd, GWL_WNDPROC, (LONG)(WNDPROC)BtnProc);
		hwnd =CreateWindow("Button", "����", WS_CHILD|WS_VISIBLE, 0, 70, 80, 30, hDlg, (HMENU)ID_ALIGN_TOP, g_hInstance, NULL);
		OldBtnProc =(WNDPROC)GetWindowLong(hwnd, GWL_WNDPROC);
		SetWindowLong(hwnd, GWL_WNDPROC, (LONG)(WNDPROC)BtnProc);
		hwnd =CreateWindow("Button", "����", WS_CHILD|WS_VISIBLE, 0, 105, 80, 30, hDlg, (HMENU)ID_ALIGN_BOTTOM, g_hInstance, NULL);
		OldBtnProc =(WNDPROC)GetWindowLong(hwnd, GWL_WNDPROC);
		SetWindowLong(hwnd, GWL_WNDPROC, (LONG)(WNDPROC)BtnProc);
		break;
	//case WM_NCHITTEST:
	case WM_LBUTTONDOWN:
		if(msg ==WM_LBUTTONDOWN)
		{
			SetCapture(hDlg);
			cur_button =-1;
		}
		POINT pt;
		pt.x =LOWORD(lParam);
		pt.y =HIWORD(lParam);
		if(msg ==WM_NCHITTEST)
			ScreenToClient(hDlg, &pt);
		GetClientRect(GetDlgItem(hDlg, ID_SHOW_KEYBOARD), &rc);
		x =rc.right+4;
		for(i =0; i<sizeof(g_kb_datas)/sizeof(KB_DATA); i++)
		{
			rc.left =g_kb_datas[i].left+x;
			rc.top =g_kb_datas[i].top+2;
			rc.right =g_kb_datas[i].right+x;
			rc.bottom =g_kb_datas[i].bottom+2;
			if(PtInRect(&rc, pt)) break;
		}
		if(i ==sizeof(g_kb_datas)/sizeof(KB_DATA))
		{
			if(msg ==WM_NCHITTEST)  // �϶�
			{
				int ret;
				ret =DefWindowProc(hDlg, msg, wParam, lParam);
				if(ret ==HTCLIENT)
					return HTCAPTION;
				else return ret;
			}
			x_start =LOWORD(lParam);
			y_start =HIWORD(lParam);
			GetWindowRect(hDlg, &rcMove);
			hDC =GetDC(NULL);
			SetROP2(hDC, R2_NOT);
			SelectObject(hDC, GetStockObject(NULL_BRUSH));
			Rectangle(hDC, rcMove.left, rcMove.top, rcMove.right, rcMove.bottom);
			ReleaseDC(hDlg, hDC);
			SetCursor(LoadCursor(NULL, IDC_SIZEALL));
			break;
		}
		else if(msg ==WM_NCHITTEST) break;
		cur_button =i;
		InvertRect((hDC =GetDC(hDlg)), &rc);
		ReleaseDC(hDlg, hDC);
		break;
	case WM_LBUTTONUP:
		ReleaseCapture();
		if(cur_button <0)
		{
			//GetWindowRect(hDlg, &rc);
			hDC =GetDC(NULL);
			SelectObject(hDC, GetStockObject(NULL_BRUSH));
			SetROP2(hDC, R2_NOT);
			Rectangle(hDC, rcMove.left, rcMove.top, rcMove.right, rcMove.bottom);
			SetWindowPos(hDlg, NULL, rcMove.left, rcMove.top,
				0, 0, SWP_NOSIZE|SWP_NOZORDER);
			SetCursor(LoadCursor(NULL, IDC_ARROW));
		}
		if(g_hWndFocus && g_hWndFocus !=hDlg)
			SetFocus(g_hWndFocus);
		if(cur_button >=0)
		{

			switch(g_kb_datas[cur_button].vk_val)
			{
			case VK_SHIFT:
				f_shift_down =!f_shift_down;
				break;
			case VK_CAPITAL:
				f_caps_down =!f_caps_down;
				break;
			default:
				GetClientRect(GetDlgItem(hDlg, ID_SHOW_KEYBOARD), &rc);
				x =rc.right+4;
				rc.left =g_kb_datas[cur_button].left+x;
				rc.top =g_kb_datas[cur_button].top+2;
				rc.right =g_kb_datas[cur_button].right+x;
				rc.bottom =g_kb_datas[cur_button].bottom+2;
				InvertRect((hDC =GetDC(hDlg)), &rc);
				ReleaseDC(hDlg, hDC);
				if(g_hWndFocus)
				{
					//if(f_chinese)
					{
						SetKBEvent(g_kb_datas[cur_button].vk_val, g_kb_datas[cur_button].scancode, true);
						SetKBEvent(g_kb_datas[cur_button].vk_val, g_kb_datas[cur_button].scancode, false);
						break;
					}
					/*
					switch(g_kb_datas[cur_button].vk_val)
					{
					case VK_BACK:
					case VK_ESCAPE:
						SendMessage(g_hWndFocus, WM_CHAR, g_kb_datas[cur_button].val, 1L);
					case VK_DELETE:
					case VK_INSERT:
						if(g_kb_datas[cur_button].scancode ==0x0C)  goto do_def;
						SendMessage(g_hWndFocus, WM_KEYDOWN, g_kb_datas[cur_button].vk_val, 1L);
						break;
do_def:				default:
						SendMessage(g_hWndFocus, WM_KEYDOWN, g_kb_datas[cur_button].vk_val, 1L);
						if(f_shift_down || f_caps_down)
						{
							SendMessage(g_hWndFocus, WM_CHAR, g_kb_datas[cur_button].tval, 1L);
						}
						else
						{
							SendMessage(g_hWndFocus, WM_CHAR, g_kb_datas[cur_button].val, 1L);
						}
						SendMessage(g_hWndFocus, WM_KEYUP, g_kb_datas[cur_button].vk_val, 1L);
						break;
					}*/
				}
				break;
			}
		}
	case WM_MOUSEMOVE:
		if(wParam !=MK_LBUTTON) break;
		if(cur_button >=0) break;
		GetWindowRect(hDlg, &rc);
		hDC =GetDC(NULL);
		SelectObject(hDC, GetStockObject(NULL_BRUSH));
		SetROP2(hDC, R2_NOT);
		Rectangle(hDC, rcMove.left, rcMove.top, rcMove.right, rcMove.bottom);
		rc.right -=rc.left;
		rc.bottom -=rc.top;
		rc.left +=LOWORD(lParam)-x_start;
		rc.top +=HIWORD(lParam)-y_start;
		rc.right +=rc.left;
		rc.bottom +=rc.top;
		Rectangle(hDC, rc.left, rc.top, rc.right, rc.bottom);
		ReleaseDC(hDlg, hDC);
		memcpy(&rcMove, &rc, sizeof(rc));
		break;
	case WM_SETFOCUS:
		if((HWND)wParam ==NULL) break;
		hwnd =GetParent((HWND)wParam);
		if(hwnd !=g_hDlgKeyB && (HWND)wParam !=g_hDlgKeyB)
		{
			g_hWndFocus =(HWND)wParam;
			//SetFocus(g_hWndFocus);
		}
		break;
	case WM_LBUTTONDBLCLK:
		cur_button =-1;
		break;
	case WM_MOUSEACTIVATE:
		hwnd =GetFocus();
		if(hwnd !=hDlg && GetParent(hwnd) !=hDlg)
			g_hWndFocus =hwnd;
		return MA_NOACTIVATE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case ID_SHOW_KEYBOARD:
			int x, y;

			GetDlgItemText(hDlg, ID_SHOW_KEYBOARD, temp, sizeof(temp));
			x =GetSystemMetrics(SM_CXSCREEN);
			y =GetSystemMetrics(SM_CYSCREEN);
			if(g_hWndFocus) SetFocus(g_hWndFocus);
			if(!strcmp(temp, "��ʾ����"))
			{
				SetDlgItemText(hDlg, ID_SHOW_KEYBOARD, "���ؼ���");
				GetClientRect(hDlg, &rc);
				SetWindowPos(g_hDlgKeyB, HWND_TOPMOST, x -rc.right-2, y-rc.bottom-2,
					0, 0, SWP_NOACTIVATE|SWP_NOSIZE);
			}
			else
			{
				SetDlgItemText(hDlg, ID_SHOW_KEYBOARD, "��ʾ����");
				GetClientRect(GetDlgItem(hDlg, ID_SHOW_KEYBOARD), &rc);
				SetWindowPos(g_hDlgKeyB, HWND_TOPMOST, x -rc.right-2, y-rc.bottom-2, 
					0,0, SWP_NOACTIVATE|SWP_NOSIZE);
			}
			break;
		case ID_ALIGN_TOP:
			if(g_hWndFocus) SetFocus(g_hWndFocus);
			SetWindowPos(g_hDlgKeyB, HWND_TOPMOST, 0, 0,
					0, 0, SWP_NOACTIVATE|SWP_NOSIZE);
			break;
		case ID_ALIGN_BOTTOM:
			if(g_hWndFocus) SetFocus(g_hWndFocus);
			x =GetSystemMetrics(SM_CXSCREEN);
			y =GetSystemMetrics(SM_CYSCREEN);
			GetClientRect(hDlg, &rc);
			SetWindowPos(g_hDlgKeyB, HWND_TOPMOST, x -rc.right-2, y-rc.bottom-2,
				0, 0, SWP_NOACTIVATE|SWP_NOSIZE);
			break;
		case ID_CHINESE:
			if(g_hWndFocus) SetFocus(g_hWndFocus);
			GetDlgItemText(hDlg, ID_CHINESE, temp, sizeof(temp));
			HIMC hImc=ImmGetContext(g_hWndFocus);
			if(!strcmp(temp, "��������"))
			{
				f_chinese =true;
				SetDlgItemText(hDlg, ID_CHINESE, "Ӣ������");
				////if(hImc ==NULL)
				//	ImmSimulateHotKey(g_hWndFocus, IME_CHOTKEY_IME_NONIME_TOGGLE);
				//SendMessage(g_hWndFocus, WM_IME_SETCONTEXT, 1, ISC_SHOWUIALL);
				//ImmSetOpenStatus(hImc, TRUE);
				SetKBEvent(VK_CONTROL, 0x1D, true);// control
				SetKBEvent(VK_SPACE, 0x39, true);  // space
				SetKBEvent(VK_CONTROL, 0x1D, false);// control
				SetKBEvent(VK_SPACE, 0x39, false);  // space
			}
			else
			{
				f_chinese =false;
				////SendMessage(g_hWndFocus, WM_IME_CONTROL, IMC_SETOPENSTATUS, 0); 

				SetDlgItemText(hDlg, ID_CHINESE, "��������");
				////SendMessage(g_hWndFocus, WM_IME_SETCONTEXT, 1, 0L);
				//ImmSetOpenStatus(hImc, FALSE);
				SendMessage(g_hWndFocus, WM_IME_CONTROL, IMC_CLOSESTATUSWINDOW, 0); 
				SetKBEvent(VK_CONTROL, 0x1D, true);// control
				SetKBEvent(VK_SPACE, 0x39, true);  // space
				SetKBEvent(VK_CONTROL, 0x1D, false);// control
				SetKBEvent(VK_SPACE, 0x39, false);  // space
			}
			break;
		}
	case WM_PAINT:
		PAINTSTRUCT ps;
		HDC hMemDC;

		GetClientRect(GetDlgItem(hDlg, ID_SHOW_KEYBOARD), &rc);
		hDC =BeginPaint(hDlg, &ps);
		hMemDC =CreateCompatibleDC(hDC);
		SelectObject(hMemDC, g_hBmpKeyB);
		BitBlt(hDC, rc.right+2, 2, g_bmpWidth, g_bmpHeight, hMemDC, 0, 0, SRCCOPY);
		EndPaint(hDlg, &ps);
		DeleteObject(hMemDC);
		break;
	case WM_CLOSE:
		return 0;;
	}
	return DefWindowProc(hDlg, msg, wParam, lParam);;
}

LRESULT CALLBACK BtnProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	HWND hwnd;

	switch(msg)
	{
	case WM_SETFOCUS:
		hwnd =GetParent((HWND)wParam);
		if(hwnd !=g_hDlgKeyB && (HWND)wParam !=g_hDlgKeyB)
			g_hWndFocus =(HWND)wParam;
		break;
	}
	return CallWindowProc(OldBtnProc, hWnd, msg, wParam, lParam);
}

void SetKBEvent(BYTE key, BYTE scancode, BOOL f_down)
{
	// 0x1D: control, 0x2A: shift
	keybd_event(key, scancode, f_down?KEYEVENTF_EXTENDEDKEY:KEYEVENTF_KEYUP, 0);
}

int DrawTest(HWND hDlg, char *str)
{
	HDC hDC =GetDC(hDlg);
	TextOut(hDC, 200, 2, "                               ", 30);
	TextOut(hDC, 200, 2, str, strlen(str));
	ReleaseDC(hDlg, hDC);
	return 0;
}
