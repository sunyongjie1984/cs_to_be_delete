#if !defined(AFX_KEYBWND_H__60F3DEE0_B3F9_11D3_AF02_001060FC88D5__INCLUDED_)
#define AFX_KEYBWND_H__60F3DEE0_B3F9_11D3_AF02_001060FC88D5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// KeyBWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CKeyBWnd window

class CKeyBWnd : public CWnd
{
// Construction
public:
	CKeyBWnd();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CKeyBWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CKeyBWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CKeyBWnd)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KEYBWND_H__60F3DEE0_B3F9_11D3_AF02_001060FC88D5__INCLUDED_)
