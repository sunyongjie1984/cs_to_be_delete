#ifndef _EXTERN_H
#define _EXTERN_H

#define TYPE_BITMAP	0
#define TYPE_URL	1
#define TYPE_APP	2

extern char g_ForbidURLs[20][256];
extern int g_ForbidURLCount;
extern char g_StartURL[128];
extern char g_BackSound[128];
extern BOOL g_fForbidFtp;
extern BOOL g_fShowCursor;
extern BOOL g_fActiveIdle;
extern int g_IdleWaitTime;
extern int g_IdleType;
extern char g_IdleImages[20][256];
extern int g_IdleImageCount;
extern char g_IdleURL[128];
extern char g_IdleApp[128]; 
extern BOOL g_fCanClose;

char *my_lowercase(char *);

#endif
