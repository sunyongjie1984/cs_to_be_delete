// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__7A73961D_F300_11D1_9F48_C49E4E07811D__INCLUDED_)
#define AFX_MAINFRM_H__7A73961D_F300_11D1_9F48_C49E4E07811D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include "btnst.h"
class CMainFrame : public CFrameWnd
{
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CDialogBar	m_wndDlgBar;
	CToolBar m_wndToolBar;
	CButtonST	m_btnHome;
	CButtonST	m_btnUrl;
	CButtonST	m_btnBack;
	CButtonST	m_btnForward;
	CButtonST	m_btnLeft;
	CButtonST	m_btnTop;
	CButtonST	m_btnRight;
	CButtonST	m_btnBottom;
	CButtonST	m_btnSearch;
// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg void OnParentNotify(UINT msg, LPARAM lParam);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__7A73961D_F300_11D1_9F48_C49E4E07811D__INCLUDED_)
