#include "stdafx.h"
#include "extern.h"

char g_ForbidURLs[20][256];
int g_ForbidURLCount =0;
char g_StartURL[128];
char g_BackSound[128];
BOOL g_fForbidFtp =0;
BOOL g_fShowCursor =1;
BOOL g_fActiveIdle =1;
int g_IdleType =0;
char g_IdleImages[20][256];
int g_IdleImageCount =0;
char g_IdleURL[128];
char g_IdleApp[128];
int g_IdleWaitTime =5;
BOOL g_fCanClose =FALSE;

char *my_lowercase(char *str)
{
	char *p =str;

	while(*p)
	{
		if(*p >='A' && *p <='Z')
			*p ='a'+*p-'A';
		p++;
	}
	return str;
}
