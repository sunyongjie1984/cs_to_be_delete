#if !defined(AFX_SCREENSAVER_H__7B831C61_B397_11D3_AF02_001060FC88D5__INCLUDED_)
#define AFX_SCREENSAVER_H__7B831C61_B397_11D3_AF02_001060FC88D5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// screensaver.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// screensaver window

class screensaver : public CWnd
{
// Construction
public:
	screensaver();

// Attributes
public:
	int m_num;
// Operations
public:
	int Show();
	int Hide();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(screensaver)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~screensaver();
	BOOL Create();
	// Generated message map functions
protected:
	//{{AFX_MSG(screensaver)
	afx_msg void OnClose();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCREENSAVER_H__7B831C61_B397_11D3_AF02_001060FC88D5__INCLUDED_)
