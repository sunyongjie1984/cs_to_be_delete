// MyBrowserView.cpp : implementation of the CMyBrowserView class
//

#include "stdafx.h"
#include "MyBrowser.h"

#include "MyBrowserDoc.h"
#include "MyBrowserView.h"
#include "UrlDlg.h"
#include "SetupSheet.h"
#include "extern.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyBrowserView
IMPLEMENT_DYNCREATE(CMyBrowserView, CView)

BEGIN_MESSAGE_MAP(CMyBrowserView, CView)
	//{{AFX_MSG_MAP(CMyBrowserView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(IDC_FORWARD, OnForward)
	ON_COMMAND(ID_BACK, OnBack)
	ON_COMMAND(ID_STOP, OnStop)
	ON_COMMAND(ID_URL, OnUrl)
	ON_COMMAND(ID_SETUP, OnSetup)
	ON_COMMAND(ID_HOME, OnHome)
	ON_COMMAND(ID_LEFT, OnLeft)
	ON_COMMAND(ID_TOP, OnTop)
	ON_COMMAND(ID_RIGHT, OnRight)
	ON_COMMAND(ID_BOTTOM, OnBottom)
	ON_COMMAND(ID_FIND, OnFind)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CMyBrowserView construction/destruction

CMyBrowserView::CMyBrowserView()
{
	// TODO: add construction code here

}

CMyBrowserView::~CMyBrowserView()
{
}

BOOL CMyBrowserView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMyBrowserView drawing

void CMyBrowserView::OnDraw(CDC* pDC)
{
	CMyBrowserDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CMyBrowserView diagnostics

#ifdef _DEBUG
void CMyBrowserView::AssertValid() const
{
	CView::AssertValid();
}

void CMyBrowserView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMyBrowserDoc* CMyBrowserView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMyBrowserDoc)));
	return (CMyBrowserDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMyBrowserView message handlers

int CMyBrowserView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	if ( ! m_Browser.Create( NULL, WS_CHILD | WS_VISIBLE, CRect(), this,
		 IDX_BROWSER ) )
		return -1;
	
	COleVariant varEmpty; // Default is VT_EMPTY

	m_Browser.Navigate( g_StartURL, &varEmpty, &varEmpty,
						&varEmpty, &varEmpty );

	//SetTimer(1, 200, NULL);  ������ҳ����������
	return 0;
}

void CMyBrowserView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	m_Browser.MoveWindow( 0, 0, cx, cy );
	m_Browser.UpdateWindow();	
}


/*void CMyBrowserView::OnReload() 
{
	// TODO: Add your command handler code here
	m_Browser.Refresh();
}
*/
void CMyBrowserView::OnForward() 
{
	// TODO: Add your command handler code here
	m_Browser.GoForward();
}

void CMyBrowserView::OnBack() 
{
	// TODO: Add your command handler code here
	m_Browser.GoBack();
}

void CMyBrowserView::OnStop() 
{
	// TODO: Add your command handler code here
	m_Browser.Stop();
}

void CMyBrowserView::OnHome() 
{
	// TODO: Add your command handler code here
	COleVariant varEmpty; // Default is VT_EMPTY
	m_Browser.Navigate( g_StartURL, &varEmpty, &varEmpty,
						&varEmpty, &varEmpty );
}

void CMyBrowserView::OnLeft() 
{
	// TODO: Add your command handler code here
	CWnd *pwnd =m_Browser.GetWindow(GW_CHILD);
	if(pwnd)
		pwnd =pwnd->GetWindow(GW_CHILD);
	if(pwnd)
	{
		LPARAM lParam;
		lParam =MAKELONG(3, 3);
		pwnd->SendMessage(WM_LBUTTONDOWN, 0, lParam);
		pwnd->SendMessage(WM_LBUTTONUP, 0, lParam);
		pwnd->SendMessage(WM_KEYDOWN, VK_LEFT, 1L);
	}
}

void CMyBrowserView::OnRight() 
{
	// TODO: Add your command handler code here
	CWnd *pwnd =m_Browser.GetWindow(GW_CHILD);
	if(pwnd)
		pwnd =pwnd->GetWindow(GW_CHILD);
	if(pwnd)
	{
		LPARAM lParam;
		lParam =MAKELONG(3, 3);
		pwnd->SendMessage(WM_LBUTTONDOWN, 0, lParam);
		pwnd->SendMessage(WM_LBUTTONUP, 0, lParam);
		pwnd->SendMessage(WM_KEYDOWN, VK_RIGHT, 1L);
	}
}

void CMyBrowserView::OnTop() 
{
	// TODO: Add your command handler code here
	CWnd *pwnd =m_Browser.GetWindow(GW_CHILD);
	if(pwnd)
		pwnd =pwnd->GetWindow(GW_CHILD);
	if(pwnd)
	{
		LPARAM lParam;
		lParam =MAKELONG(3, 3);
		pwnd->SendMessage(WM_LBUTTONDOWN, 0, lParam);
		pwnd->SendMessage(WM_LBUTTONUP, 0, lParam);
		pwnd->SendMessage(WM_KEYDOWN, VK_UP, 1L);
	}
}

void CMyBrowserView::OnBottom() 
{
	// TODO: Add your command handler code here
	LPARAM lParam;
	CWnd *pwnd =m_Browser.GetWindow(GW_CHILD);
	if(pwnd)
		pwnd =pwnd->GetWindow(GW_CHILD);
	if(pwnd)
	{
		lParam =MAKELONG(3, 3);
		pwnd->SendMessage(WM_LBUTTONDOWN, 0, lParam);
		pwnd->SendMessage(WM_LBUTTONUP, 0, lParam);
		pwnd->SendMessage(WM_KEYDOWN, VK_DOWN, 1L);
	}
}

void CMyBrowserView::OnUrl() 
{
	char temp[400];
	// TODO: Add your command handler code here
	COleVariant varEmpty; // Default is VT_EMPTY
	
	UrlDlg *Dlg = new UrlDlg( this );
	if( Dlg->DoModal() == IDOK )
	{
		int i;
		strcpy(temp, Dlg->m_Edit);
		my_lowercase(temp);
		
		for(i =0; i<g_ForbidURLCount; i++)
		{
			if(strstr(temp, g_ForbidURLs[i]))
			{
				MessageBox("�Բ��𣬲��ܷ��ʴ˵�ַ", "touchweb", MB_OK|MB_ICONSTOP);
				delete Dlg;
				return;
			}
		}
		if(g_fForbidFtp && strstr(temp, "ftp:"))
		{
			MessageBox("�Բ��𣬲���ʹ��FTP", "touchweb", MB_OK|MB_ICONSTOP);
			delete Dlg;
			return;
		}

		m_Browser.Navigate( Dlg->m_Edit, &varEmpty, &varEmpty,
						&varEmpty, &varEmpty );
	}
	delete Dlg;
}

void CMyBrowserView::OnSetup() 
{
	// TODO: Add your command handler code here
	
	extern char init_file[128];
	if(GetPrivateProfileInt("BROWSER", "forbid_setup", 1, init_file) !=0) return;
	SetupSheet *setup = new SetupSheet("����");
	if(setup->DoModal() ==IDOK)
		MessageBox("��Щ�޸ĵ�����Ҫ�������г������������", "webtouch", MB_OK|MB_ICONINFORMATION);
	delete setup;
}

void CMyBrowserView::OnFind()
{
	CWnd *pwnd =m_Browser.GetWindow(GW_CHILD);
	if(pwnd)
		pwnd =pwnd->GetWindow(GW_CHILD);
	if(pwnd)
	{
		//pwnd->SendMessage(WM_LBUTTONDOWN, 0, 0L);
		//pwnd->SendMessage(WM_LBUTTONUP, 0, 0L);
		pwnd->SendMessage(WM_COMMAND, 67, (LPARAM)pwnd->m_hWnd);
	}
	//m_Browser.GoSearch();
}

void CMyBrowserView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	m_Browser.Refresh();

	CView::OnTimer(nIDEvent);
}
