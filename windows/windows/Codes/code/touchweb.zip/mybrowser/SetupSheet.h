#if !defined(AFX_SETUPSHEET_H__2CB37B41_B854_11D3_AF02_001060FC88D5__INCLUDED_)
#define AFX_SETUPSHEET_H__2CB37B41_B854_11D3_AF02_001060FC88D5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SetupSheet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// SetupSheet

class SetupSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(SetupSheet)

// Construction
public:
	CPropertyPage PageScreensaver;
	CPropertyPage PageBrowser;
	SetupSheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	SetupSheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(SetupSheet)
	public:
	virtual BOOL OnInitDialog();
	protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~SetupSheet();

	// Generated message map functions
protected:
	//{{AFX_MSG(SetupSheet)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETUPSHEET_H__2CB37B41_B854_11D3_AF02_001060FC88D5__INCLUDED_)
