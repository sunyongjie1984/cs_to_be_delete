//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyBrowser.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_TOOL                        100
#define IDX_BROWSER                     101
#define IDR_MAINFRAME                   128
#define IDR_MYBROWTYPE                  129
#define IDD_URL                         134
#define IDI_HOME                        140
#define IDB_HOME                        142
#define IDB_URL                         143
#define IDB_BACK                        144
#define IDB_FORWARD                     145
#define IDB_LEFT                        146
#define IDB_TOP                         147
#define IDB_RIGHT                       148
#define IDB_BOTTOM                      149
#define IDB_FIND                        150
#define IDD_KEYBOARD                    151
#define IDB_KEYBOARD                    152
#define IDB_KEY01                       153
#define IDD_SET_SCREENSAVER             156
#define IDD_SET_BROWSER                 158
#define IDC_EDIT1                       1004
#define ID_HOME                         1006
#define ID_TOP                          1010
#define ID_BOTTOM                       1011
#define ID_SHOW_KEYBOARD                1015
#define ID_ALIGN_TOP                    1020
#define ID_ALIGN_BOTTOM                 1021
#define ID_CHINESE                      1022
#define IDE_HOME                        1026
#define IDC_OPENDIALOG                  1027
#define IDC_SET_IE                      1029
#define IDC_LIST2                       1031
#define IDC_FORBIDURLS                  1031
#define IDC_ADD_URL                     1032
#define IDC_DEL_URL                     1033
#define IDC_EDIT2                       1034
#define IDE_IDLE_URL                    1034
#define IDC_BACK_SOUND                  1035
#define IDC_FORBID_FTP                  1036
#define IDC_SHOW_CURSOR                 1037
#define IDC_ALLOW_IDLE                  1038
#define IDC_SHOW_GRAPH                  1039
#define IDC_SHOW_HTTP                   1040
#define IDC_RUN_FILE                    1041
#define IDC_IMAGES                      1042
#define IDC_ADD_IMAGE                   1043
#define IDC_DEL_IMAGE                   1044
#define IDC_OPENDIALOG2                 1045
#define IDC_EDIT3                       1046
#define IDE_IDLE_APP                    1046
#define IDC_OPENDIALOG3                 1047
#define IDC_WAIT_TIME                   1048
#define IDE_BACKSOUND                   1049
#define ID_BACK                         32771
#define IDC_FORWARD                     32772
#define ID_FIND                         32773
#define ID_STOP                         32775
#define ID_URL                          32776
#define ID_BUTTON32781                  32781
#define ID_RIGHT                        32782
#define ID_UP                           32783
#define ID_DOWN                         32789
#define ID_LEFT                         32790
#define ID_SETUP                        32792

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        160
#define _APS_NEXT_COMMAND_VALUE         32793
#define _APS_NEXT_CONTROL_VALUE         1050
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
