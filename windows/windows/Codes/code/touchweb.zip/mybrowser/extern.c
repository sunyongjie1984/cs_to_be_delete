#include "extern.h"

char g_ForbidURLs[20][256];
char g_StartURL[128];
char g_BackSound[128];
BOOL g_fForbidFtp;
BOOL g_fShowCursor;
BOOL g_fActiveIdle;
int g_IdleType;
char g_IdleImages[20][256];
char g_IdleURL[128];
char g_IdleApp[128]; 
