//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FScript.rc
//
#define IDD_VIEW1                       101
#define IDB_BITMAP1                     102
#define IDD_VIEW2                       104
#define IDB_BITMAP2                     105
#define IDB_BITMAP3                     106
#define IDB_BITMAP4                     107
#define IDD_VIEW3                       108
#define IDD_VIEW4                       109
#define IDR_MENU                        110
#define IDC_EDIT1                       1000
#define IDM_1                           40001
#define IDM_2                           40002
#define IDM_3                           40003
#define IDM_4                           40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
