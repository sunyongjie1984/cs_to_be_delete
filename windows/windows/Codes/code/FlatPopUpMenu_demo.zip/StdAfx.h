// A flat popup menu for controls
// Copyright (c) 1999 Andy Brown <andy@mirage.dabsol.co.uk>
// You may do whatever you like with this file, I just don't care.


#if !defined(AFX_STDAFX_H__570E5253_6392_11D3_A25F_0000B45C6D5E__INCLUDED_)
#define AFX_STDAFX_H__570E5253_6392_11D3_A25F_0000B45C6D5E__INCLUDED_
#pragma once


#define VC_EXTRALEAN


#include <afxwin.h>     // MFC core and standard components
#include <afxext.h>     // MFC extensions
#include <afxcmn.h>			// MFC support for Windows Common Controls

#include <vector>
#include <string>


//{{AFX_INSERT_LOCATION}}


#endif // !defined(AFX_STDAFX_H__570E5253_6392_11D3_A25F_0000B45C6D5E__INCLUDED_)
