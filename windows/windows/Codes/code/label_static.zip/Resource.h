//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestBed.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_TESTBETYPE                  129
#define IDC_HAND                        130
#define IDC_STC1                        1000
#define IDC_TCOLOR                      1002
#define IDC_BCOLOR                      1003
#define IDC_TULINE                      1004
#define IDC_ITALICS                     1005
#define IDC_FNAME                       1006
#define IDC_BOLD                        1007
#define IDC_BORDER                      1008
#define IDC_SUNKEN                      1009
#define IDC_MONTY                       1011
#define IDC_FSIZE                       1012
#define IDC_FLASH                       1013
#define IDC_LINK                        1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
