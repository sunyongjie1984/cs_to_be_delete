// ListCtrlDemoView.cpp : implementation of the CListCtrlDemoView class
//

#include "stdafx.h"
#include "ListCtrlDemo.h"

#include "ListCtrlDemoDoc.h"
#include "ListCtrlDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CListCtrlDemoView

IMPLEMENT_DYNCREATE(CListCtrlDemoView, CView)

BEGIN_MESSAGE_MAP(CListCtrlDemoView, CView)
	//{{AFX_MSG_MAP(CListCtrlDemoView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CListCtrlDemoView construction/destruction

CListCtrlDemoView::CListCtrlDemoView()
{
	// TODO: add construction code here

}

CListCtrlDemoView::~CListCtrlDemoView()
{
}

BOOL CListCtrlDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CListCtrlDemoView drawing

void CListCtrlDemoView::OnDraw(CDC* pDC)
{
	CListCtrlDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CListCtrlDemoView printing

BOOL CListCtrlDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CListCtrlDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CListCtrlDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CListCtrlDemoView diagnostics

#ifdef _DEBUG
void CListCtrlDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CListCtrlDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CListCtrlDemoDoc* CListCtrlDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CListCtrlDemoDoc)));
	return (CListCtrlDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CListCtrlDemoView message handlers
