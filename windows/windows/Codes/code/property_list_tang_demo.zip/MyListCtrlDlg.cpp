// MyListCtrlDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ListCtrlDemo.h"
#include "MyListCtrlDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyListCtrlDlg dialog


CMyListCtrlDlg::CMyListCtrlDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyListCtrlDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyListCtrlDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_MyFont	= new LOGFONT;
	m_MyFont->lfHeight			= -13;   
	m_MyFont->lfWidth			= 0;   
	m_MyFont->lfEscapement		= 0;   
	m_MyFont->lfOrientation		= 0;
	m_MyFont->lfWeight			= 400;   
	m_MyFont->lfItalic			= 0;   
	m_MyFont->lfUnderline		= 1;   
	m_MyFont->lfStrikeOut		= 0;
	m_MyFont->lfCharSet			= 0;   
	m_MyFont->lfOutPrecision	= 3;   
	m_MyFont->lfClipPrecision	= 2;
	m_MyFont->lfQuality			= 1;   
	m_MyFont->lfPitchAndFamily	= 18;   
	lstrcpy(m_MyFont->lfFaceName, (const char*) "Times New Roman");

	m_MyColorRef	= RGB(255,255,255);
}


void CMyListCtrlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyListCtrlDlg)
	DDX_Control(pDX, IDC_MYLISTCTRL, m_MyListCtrl_Cnt);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyListCtrlDlg, CDialog)
	//{{AFX_MSG_MAP(CMyListCtrlDlg)
	ON_BN_CLICKED(IDC_GET_DATA, OnGetData)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_GET_DATA_FROM_TITLE, OnGetDataFromTitle)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyListCtrlDlg message handlers

BOOL CMyListCtrlDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	// TODO: Add extra initialization here
	m_MyListCtrl_Cnt.Initial("Key", 100, "Information", 150);
	CStringList		InputStringList;
	InputStringList.AddTail("Com 1");
	InputStringList.AddTail("Com 3");
	InputStringList.AddTail("Com 2");
	InputStringList.AddTail("Com 4");
	long	LongData	= 555555555;
	int		IntData		= 12345;
	m_MyListCtrl_Cnt.AddItem("Text String",					//	Key 
							"AAAAA",						//	Data 
							FPSPROPERTYITEMTYPE_TEXT);		//	Type
	m_MyListCtrl_Cnt.AddItem("Int String",					//	Key
							IntData,						//	Data
							FPSPROPERTYITEMTYPE_INTEGER);	//	Type
	m_MyListCtrl_Cnt.AddItem("Long String",					//	Key
							LongData,						//	Data
							FPSPROPERTYITEMTYPE_LONG);		//	Type
	m_MyListCtrl_Cnt.AddItem("Font String",					//	Key
							"",								//	No Used
							FPSPROPERTYITEMTYPE_FONT,		//	Type
							(void*)m_MyFont);				//	Data
	m_MyListCtrl_Cnt.AddItem("Color String",				//	Key
							"",								//	No Used
							FPSPROPERTYITEMTYPE_COLOR,		//	Type
							(void*) m_MyColorRef);			//	Data
	m_MyListCtrl_Cnt.AddItem("File String", 				//	Key
							"C:\\autoexec.bat",				//	Data
							FPSPROPERTYITEMTYPE_FILE);		//	Type
	m_MyListCtrl_Cnt.AddItem("COMBO String",				//	Key
							"Com 3",						//	Selectec Data
							FPSPROPERTYITEMTYPE_COMBOBOX,	//	Type
							(void*) &InputStringList);		//	Combo Data
	m_MyListCtrl_Cnt.AddItem("BOOL String",					//	Key
							"",								//	No Used
							FPSPROPERTYITEMTYPE_BOOL,		//	Type
							(void*) TRUE);					//	Data
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMyListCtrlDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	delete	m_MyFont;
}

void CMyListCtrlDlg::OnGetData() 
{
	// TODO: Add your control notification handler code here
	int	Index;
	//	Set TotalItem > Itemcount to test error message
	int	TotalItem	= m_MyListCtrl_Cnt.GetItemCount() + 1;
	OPERATION_TYPE	Op_type;
	CString			Title;
	CString			Data;
	void*			DataPointer	= NULL;
	for (Index	= 0; Index < TotalItem; Index++)
	{
		if (m_MyListCtrl_Cnt.GetData(Index,	Op_type,
									 Title,	Data,
									 DataPointer))
		{
			switch (Op_type)
			{
				case FPSPROPERTYITEMTYPE_INTEGER:
				case FPSPROPERTYITEMTYPE_LONG:
				case FPSPROPERTYITEMTYPE_TEXT:
				case FPSPROPERTYITEMTYPE_FILE:
				case FPSPROPERTYITEMTYPE_COMBOBOX:
					MessageBox(Data, Title,MB_OK);
				break;
				case FPSPROPERTYITEMTYPE_BOOL:
					if (DataPointer)
						MessageBox("TRUE", Title,MB_OK);
					else
						MessageBox("FALSE", Title,MB_OK);
				break;
				case FPSPROPERTYITEMTYPE_FONT:
					m_MyListCtrl_Cnt.FontPassing((LOGFONT*)DataPointer, m_MyFont);
					MessageBox("Put a break point here to watch 'm_MyFont'", 
								Title,MB_OK);
				break;
				case FPSPROPERTYITEMTYPE_COLOR:
					m_MyColorRef	= (COLORREF)DataPointer;
					MessageBox("Put a break point here to watch 'm_MyColorRef'", 
								Title,MB_OK);
				break;
				case FPSPROPERTYITEMTYPE_UNKNOW:
				default:
				break;
			}
		}
		else
			MessageBox("Out of Range", "MyListCtrl Error", MB_OK);
	}
}


void CMyListCtrlDlg::OnGetDataFromTitle() 
{
	// TODO: Add your control notification handler code here
	int				Index;
	OPERATION_TYPE	Op_type;
	CString			Title	= "File String";
	CString			Data;
	void*			DataPointer	= NULL;

	for (int i=0;i<m_MyListCtrl_Cnt.GetItemCount();i++)
	{
		m_MyListCtrl_Cnt.GetTitle(i, Title);
		if (m_MyListCtrl_Cnt.FindData ( Title,		Index,	
										Op_type,	Data,
										DataPointer))
		{
			switch (Op_type)
			{
				case FPSPROPERTYITEMTYPE_INTEGER:
				case FPSPROPERTYITEMTYPE_LONG:
				case FPSPROPERTYITEMTYPE_TEXT:
				case FPSPROPERTYITEMTYPE_FILE:
				case FPSPROPERTYITEMTYPE_COMBOBOX:
					MessageBox(Data, Title,MB_OK);
				break;
				case FPSPROPERTYITEMTYPE_BOOL:
					if (DataPointer)
						MessageBox("TRUE", Title,MB_OK);
					else
						MessageBox("FALSE", Title,MB_OK);
				break;
				case FPSPROPERTYITEMTYPE_FONT:
					m_MyListCtrl_Cnt.FontPassing((LOGFONT*)DataPointer, m_MyFont);
					MessageBox("Put a break point here to watch 'm_MyFont'", 
								Title,MB_OK);
				break;
				case FPSPROPERTYITEMTYPE_COLOR:
					m_MyColorRef	= (COLORREF)DataPointer;
					MessageBox("Put a break point here to watch 'm_MyColorRef'", 
								Title,MB_OK);
				break;
				case FPSPROPERTYITEMTYPE_UNKNOW:
				default:
				break;
			}
		}
		else
			MessageBox("Out of Range", "MyListCtrl Error", MB_OK);
	}
	
	//	Test if Title is not found
	if (!m_MyListCtrl_Cnt.FindData ("ABCDEFG",Index,Op_type,Data,DataPointer))
		MessageBox("Can't find ABCDEFG", "MyListCtrl Error", MB_OK);
}
