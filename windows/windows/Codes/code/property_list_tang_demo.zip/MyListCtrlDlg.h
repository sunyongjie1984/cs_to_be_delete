#if !defined(AFX_MYLISTCTRLDLG_H__470DF1C7_9672_11D2_9F6C_0000C0A3B9F2__INCLUDED_)
#define AFX_MYLISTCTRLDLG_H__470DF1C7_9672_11D2_9F6C_0000C0A3B9F2__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MyListCtrlDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyListCtrlDlg dialog
#include "MyListCtrl.h"

class CMyListCtrlDlg : public CDialog
{
// Construction
public:
	CMyListCtrlDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMyListCtrlDlg)
	enum { IDD = IDD_DLG_LISTCTRL_DEMO };
	CMyListCtrl	m_MyListCtrl_Cnt;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyListCtrlDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	LOGFONT*		m_MyFont;;
	COLORREF		m_MyColorRef;
	// Generated message map functions
	//{{AFX_MSG(CMyListCtrlDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnGetData();
	afx_msg void OnDestroy();
	afx_msg void OnGetDataFromTitle();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYLISTCTRLDLG_H__470DF1C7_9672_11D2_9F6C_0000C0A3B9F2__INCLUDED_)
