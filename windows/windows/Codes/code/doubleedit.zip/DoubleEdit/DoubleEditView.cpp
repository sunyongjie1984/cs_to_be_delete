// DoubleEditView.cpp : implementation of the CDoubleEditView class
//

#include "stdafx.h"
#include "DoubleEdit.h"

#include "DoubleEditDoc.h"
#include "DoubleEditView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDoubleEditView

IMPLEMENT_DYNCREATE(CDoubleEditView, CFormView)

BEGIN_MESSAGE_MAP(CDoubleEditView, CFormView)
	//{{AFX_MSG_MAP(CDoubleEditView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDoubleEditView construction/destruction

CDoubleEditView::CDoubleEditView()
	: CFormView(CDoubleEditView::IDD)
{
	//{{AFX_DATA_INIT(CDoubleEditView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CDoubleEditView::~CDoubleEditView()
{
}

void CDoubleEditView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDoubleEditView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BOOL CDoubleEditView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CDoubleEditView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

/////////////////////////////////////////////////////////////////////////////
// CDoubleEditView diagnostics

#ifdef _DEBUG
void CDoubleEditView::AssertValid() const
{
	CFormView::AssertValid();
}

void CDoubleEditView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CDoubleEditDoc* CDoubleEditView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDoubleEditDoc)));
	return (CDoubleEditDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDoubleEditView message handlers

BOOL CDoubleEditView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	BOOL bRetVal = FALSE;

	//SAMPLE: if we've created the window, then subclass the edit control
	if (CFormView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext))
	{
		if (m_myEdit.SubclassDlgItem(IDC_EDIT1, this))
			bRetVal = TRUE;
	}

	return bRetVal;
}
