// DoubleEditView.h : interface of the CDoubleEditView class
//
/////////////////////////////////////////////////////////////////////////////

// need the CMyEdit definition

#include "MyEdit.h"

#if !defined(AFX_DOUBLEEDITVIEW_H__4E5DACC2_ABC3_11D2_90AC_0080C7F8D8BF__INCLUDED_)
#define AFX_DOUBLEEDITVIEW_H__4E5DACC2_ABC3_11D2_90AC_0080C7F8D8BF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDoubleEditView : public CFormView
{
protected: // create from serialization only
	CDoubleEditView();
	DECLARE_DYNCREATE(CDoubleEditView)

public:
	//{{AFX_DATA(CDoubleEditView)
	enum{ IDD = IDD_DOUBLEEDIT_FORM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CDoubleEditDoc* GetDocument();

	CMyEdit m_myEdit;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDoubleEditView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDoubleEditView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDoubleEditView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in DoubleEditView.cpp
inline CDoubleEditDoc* CDoubleEditView::GetDocument()
   { return (CDoubleEditDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DOUBLEEDITVIEW_H__4E5DACC2_ABC3_11D2_90AC_0080C7F8D8BF__INCLUDED_)
