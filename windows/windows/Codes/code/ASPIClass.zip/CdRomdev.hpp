////////////////////////////////////////////////////////////
//
// Module CDROMDEV.HPP
//
// ASPI class library
// SCSI CD-ROM device class
//
// Project: A Programmer's Guide to SCSI
//
// Copyright (C) 1997, Brian Sawert
// Portions copyright (C) 1995, Larry Martin
// All rights reserved
//
////////////////////////////////////////////////////////////


#ifndef CDROMDEV_HPP_INCLUDED
#define CDROMDEV_HPP_INCLUDED

// Portions copyright 1995 by Larry Martin
// All rights reserved.

#ifndef BASEDEV_HPP_INCLUDED
#include "basedev.hpp"
#endif


#define MAX_BLOCK_SIZE  0xFFFF


// SCSI CD-ROM device class
class ScsiCdRomDevice : public ScsiBaseDevice
   {
   public:

   ScsiCdRomDevice();
   ~ScsiCdRomDevice();

   ScsiError_t ReadCapacity(DWORD *blklast, DWORD *blksize);
   ScsiError_t ReadToc(void *bufp, DWORD maxbytes, DWORD *bytesread = NULL);
   ScsiError_t LockUnlock(int fLock);
   ScsiError_t Eject();

   };

#endif

