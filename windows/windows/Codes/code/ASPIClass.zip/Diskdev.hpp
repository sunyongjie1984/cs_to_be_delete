////////////////////////////////////////////////////////////
//
// Module DISKDEV.HPP
//
// ASPI class library
// SCSI direct access device class
//
// Project: A Programmer's Guide to SCSI
//
// Copyright (C) 1997, Brian Sawert
// Portions copyright (C) 1995, Larry Martin
// All rights reserved
//
////////////////////////////////////////////////////////////


#ifndef DISKDEV_HPP_INCLUDED
#define DISKDEV_HPP_INCLUDED

#ifndef BASEDEV_HPP_INCLUDED
#include "basedev.hpp"
#endif


#define MAX_BLOCK_SIZE  0xFFFF


// SCSI direct access device class
class ScsiDiskDevice : public ScsiBaseDevice
   {
   public:

   ScsiDiskDevice();
   ~ScsiDiskDevice();

   ScsiError_t ReadCapacity(DWORD *blklast, DWORD *blksize);
   ScsiError_t ReadSector(DWORD sectnum, void *bufp, DWORD maxbytes, DWORD *bytesread = NULL);
   ScsiError_t LockUnlock(int fLock);
   ScsiError_t Eject();

   };

#endif

