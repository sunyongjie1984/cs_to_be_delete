////////////////////////////////////////////////////////////
//
// Module ASPI.CPP
//
// ASPI class library
//
// Project: A Programmer's Guide to SCSI
//
// Copyright (C) 1997, Brian Sawert
// Portions copyright (C) 1995, Larry Martin
// All rights reserved
//
////////////////////////////////////////////////////////////


#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>

#include <windows.h>
#include "aspi.h"


HMODULE WinAspiHandle;
DWORD (*GetASPI32SupportInfo)(void);
DWORD (*SendASPI32Command)(void *);

static int RunningNT;

// use for debugging console apps
static int PrintAspiCommands;
static char PrintBuf[128];


int aspi_GetSupportInfo(void)
   {
   OSVERSIONINFO v;

   if (getenv("DEBUGASPI"))
      PrintAspiCommands = 1;

   RunningNT = 0;

   v.dwOSVersionInfoSize = sizeof(v);
   if (!GetVersionEx(&v))
      return SS_FAILED_INIT << 8;

   switch (v.dwPlatformId)
      {
      case VER_PLATFORM_WIN32_NT:
         RunningNT = 1;
         // fall through to Win95

      case VER_PLATFORM_WIN32_WINDOWS:
         {
         WinAspiHandle = LoadLibrary("WNASPI32.DLL");
         if (!WinAspiHandle)
            return SS_FAILED_INIT << 8;

         GetASPI32SupportInfo = (DWORD (*)(void)) GetProcAddress(WinAspiHandle,"GetASPI32SupportInfo");
         SendASPI32Command = (DWORD (*)(void *)) GetProcAddress(WinAspiHandle,"SendASPI32Command");

         if (!GetASPI32SupportInfo || !SendASPI32Command)
            {
            FreeLibrary(WinAspiHandle);
            return SS_FAILED_INIT << 8;
            }

         int rval =  GetASPI32SupportInfo();
         return rval;
         }

      default:
         // unknown platform
         return SS_FAILED_INIT << 8;
      }
   }


void aspi_SendCommand(LPSRB p)
   {
   if (PrintAspiCommands)
      {
      SRB_ExecSCSICmd *s = (SRB_ExecSCSICmd *) p;
      unsigned i;
      sprintf(PrintBuf,"  SRB CMD=%d,HA=%d,FL=%02X",s->SRB_Cmd,s->SRB_HaId,s->SRB_Flags);
      cout << PrintBuf;
      if (s->SRB_Cmd == SC_EXEC_SCSI_CMD)
         {
         if (s->SRB_CDBLen == 0)
            sprintf(PrintBuf,",NO CDB!");
         else
         sprintf(PrintBuf,",cdb=%02X",s->SRB_CDBByte[0]);
         cout << PrintBuf;
         for (i=1; i<s->SRB_CDBLen; i++)
            {
            sprintf(PrintBuf," %02X",s->SRB_CDBByte[i]);
            cout << PrintBuf;
            }
         cout << ",BUFLEN=" << (int) s->SRB_BufLen;
         cout << ",SENSELEN=" << (int) s->SRB_SenseLen;
         }
      cout << '\n';
      cout.flush();
      }

      SendASPI32Command(p);
   }

