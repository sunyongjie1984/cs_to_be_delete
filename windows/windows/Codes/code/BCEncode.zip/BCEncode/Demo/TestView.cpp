// TestView.cpp : implementation of the CTestView class
//

#include "stdafx.h"
#include "Test.h"

#include "TestDoc.h"
#include "TestView.h"
#include "..\Include\BCEncode.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestView

IMPLEMENT_DYNCREATE(CTestView, CScrollView)

BEGIN_MESSAGE_MAP(CTestView, CScrollView)
	//{{AFX_MSG_MAP(CTestView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestView construction/destruction

CTestView::CTestView()
{
	// TODO: add construction code here

}

CTestView::~CTestView()
{
}

BOOL CTestView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTestView drawing

void CTestView::OnDraw(CDC* pDC)
{
	CTestDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	CDC mDC;
	CBitmap mBit,OldBit;
	BITMAP bm;
	static int w = 100;
	CString Txt;

//  ��ʾCODE128��

	Txt.Format("Code 128 %d",w);		
	mBit.Attach(MakeBarCode(3,Txt,3,0,100,180));

	mBit.GetObject(sizeof BITMAP,&bm);
	mDC.CreateCompatibleDC(pDC);
	OldBit.Attach(mDC.SelectObject(&mBit));
	
	pDC->TextOut(100,10,"CODE 128��");
	pDC->BitBlt(100,30,bm.bmWidth,bm.bmHeight ,&mDC,0,0,SRCCOPY);
	pDC->TextOut(100,140,Txt);

//  ��ʾCODE39��
	mBit.DeleteObject();
	Txt.Format("CODE 39 %d",w);
	mBit.Attach(MakeBarCode(1,Txt,2,6,100,0));

	mBit.GetObject(sizeof BITMAP,&bm);
	mDC.SelectObject(&mBit);
	
	pDC->TextOut(100,210,"CODE 39��");
	pDC->BitBlt(100,230,bm.bmWidth,bm.bmHeight ,&mDC,0,0,SRCCOPY);
	pDC->TextOut(100,340,Txt);

	mDC.SelectObject(&OldBit);

}

void CTestView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: calculate the total size of this view
	sizeTotal.cx = sizeTotal.cy = 1000;
	SetScrollSizes(MM_TEXT, sizeTotal);
}

/////////////////////////////////////////////////////////////////////////////
// CTestView printing

BOOL CTestView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTestView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTestView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTestView diagnostics

#ifdef _DEBUG
void CTestView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CTestView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CTestDoc* CTestView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestDoc)));
	return (CTestDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestView message handlers

void CTestView::OnPrint(CDC* pDC, CPrintInfo* pInfo) 
{
	// TODO: Add your specialized code here and/or call the base class
	CDC  mDC;
	mDC.CreateCompatibleDC(pDC);	
	CBitmap mBit;
	CBitmap * mOldBit;
	BITMAP bm;

//  ��ӡCODE128��
	pDC->TextOut(400,200,"CODE 128��");
	TCHAR TTT[11] = {0x1,0x2,0x3,0x4,0x5,0x6,0x7,0x8,0x9,0xA,0x0};
	int i,j;
	static int w = 10;
	for (i = 1;i<=3;i++)
		for (j = 1;j<=4;j++)
		{
			mBit.DeleteObject();
			mBit.Attach(MakeBarCode(3,TTT,6,15,200,0));
			mOldBit= mDC.SelectObject(&mBit);
			mBit.GetObject(sizeof BITMAP,&bm);
			pDC->BitBlt(400 + (i -1)*1200,400+(j-1)*300,bm.bmWidth,bm.bmHeight ,&mDC,0,0,SRCCOPY);
			pDC->TextOut(400 + (i -1)*1200,600+(j-1)*300,TTT);
			mDC.SelectObject(mOldBit);
			for (int k = 0 ;k < 10 ; k++)
				if (TTT[k] < 118)
					TTT[k] += 10;
		};

//  ��ӡCODE39��
	pDC->TextOut(400,3200,"CODE 39��");
	CString Txt;
	for (i = 1;i<=3;i++)
		for (j = 1;j<=8;j++)
		{
			Txt.Format("ABCD%3d",i*4+j);
			mBit.DeleteObject();
			mBit.Attach(MakeBarCode(1,Txt,8,20,200,0));
			mOldBit = mDC.SelectObject(&mBit);
			mBit.GetObject(sizeof BITMAP,&bm);
			pDC->BitBlt(400 + (i -1)*1200,400+(j-1)*300+3000,bm.bmWidth,bm.bmHeight ,&mDC,0,0,SRCCOPY);
			pDC->TextOut(400 + (i -1)*1200,600+(j-1)*300+3000,Txt);
			mDC.SelectObject(mOldBit);
		};

}
