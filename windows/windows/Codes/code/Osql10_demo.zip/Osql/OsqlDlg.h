// OsqlDlg.h : header file
//
// Release 1, Copyright (C) 1999 Ben Bryant
// This is sample source code, nothing more is implied. Use it only as such.
// This software is provided 'as-is', without warranty. In no event will the
// author be held liable for any damages arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose.
// The origin of this software must not be misrepresented; you must not claim
// that you wrote the original software. Altered source versions must be plainly
// marked as such, and must not be misrepresented as being the original software.
// Ben Bryant bcbryant@firstobject.com
//

#if !defined(AFX_OSQLDLG_H__C7257218_0484_11D3_A0D8_00105A27C570__INCLUDED_)
#define AFX_OSQLDLG_H__C7257218_0484_11D3_A0D8_00105A27C570__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// COsqlDlg dialog

#include "CommandCtrl.h"
#include "Odb.h"

class COsqlDlg : public CDialog
{
// Construction
public:
	COsqlDlg(CWnd* pParent = NULL);	// standard constructor

	CString m_csTitle;

// Dialog Data
	//{{AFX_DATA(COsqlDlg)
	enum { IDD = IDD_OSQL_DIALOG };
	CCmdOutCtrl	m_cmdOutput;
	CCmdInCtrl	m_cmdInput;
	CButton	m_buttonDo;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COsqlDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	COdb m_db;
	CCommand m_cmd;
	void Output( CString csOut, int nEffect = 0 ) { m_cmdOutput.Output(csOut,nEffect); };
	void About();
	void Help();
	HRESULT RunCommand( CString csCommandLine );
	void CalcSize(int cx, int cy);

	// Generated message map functions
	//{{AFX_MSG(COsqlDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonDo();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OSQLDLG_H__C7257218_0484_11D3_A0D8_00105A27C570__INCLUDED_)
