// Odb.h: interface for the COdb class.
//
// Release 1, Copyright (C) 1999 Ben Bryant
// This is sample source code, nothing more is implied. Use it only as such.
// This software is provided 'as-is', without warranty. In no event will the
// author be held liable for any damages arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose.
// The origin of this software must not be misrepresented; you must not claim
// that you wrote the original software. Altered source versions must be plainly
// marked as such, and must not be misrepresented as being the original software.
// Ben Bryant bcbryant@firstobject.com
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ODB_H__6B1568A3_A4E0_11D2_A0C3_00105A27C570__INCLUDED_)
#define AFX_ODB_H__6B1568A3_A4E0_11D2_A0C3_00105A27C570__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class COdb  
{
public:
	COdb();
	virtual ~COdb();

	// Public methods
	HRESULT Open( CString csConnect );
	HRESULT Close();
	HRESULT Exec( CString csStatement );
	HRESULT Select( CString csStatement );
	HRESULT FetchNext();
	BOOL IsEOS();
	CString GetErrorDescription();
	CString ProcessQuotes( CString csValue );
	CString GetField( int iField );
	CString GetField( CString csName );
	BOOL GetField( int iField, CString& csName, CString& csValue, BOOL bQuotesIfValueRequires = FALSE );
	CString GetResults() { return m_csResults; };
	void StartLog() { m_csLog.Empty(); };
	CString GetLog() { return m_csLog; };

protected:
	// These structs are defined in the cpp	because they use oci.h types
	struct OdbContext; // status of the instantiated COdb
	struct OdbRecordSet; // defines select list and holds the results
	struct OdbField; // name, type, and result value of a field

	// Protected members
	OdbContext* m_po;
	CString m_csResults; // fetch row
	CString m_csLog; // PL/SQL statement log

	// Internal functions
	void CheckErr( short status );
	static void CleanWhitespace( CString& csStatement );
};

#endif // !defined(AFX_ODB_H__6B1568A3_A4E0_11D2_A0C3_00105A27C570__INCLUDED_)
