#if !defined(AFX_COMMANDCTRL_H__2BF4ECE9_F408_11D2_A0D2_00105A27C570__INCLUDED_)
#define AFX_COMMANDCTRL_H__2BF4ECE9_F408_11D2_A0D2_00105A27C570__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CommandCtrl.h : header file
//
// Release 1, Copyright (C) 1999 Ben Bryant
// This is sample source code, nothing more is implied. Use it only as such.
// This software is provided 'as-is', without warranty. In no event will the
// author be held liable for any damages arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose.
// The origin of this software must not be misrepresented; you must not claim
// that you wrote the original software. Altered source versions must be plainly
// marked as such, and must not be misrepresented as being the original software.
// Ben Bryant bcbryant@firstobject.com
//

class CCommand;

/////////////////////////////////////////////////////////////////////////////
// CCommand class

class CCommand
{
// Construction
public:
	CCommand();
	virtual ~CCommand();

	friend class CCmdOutCtrl;
	friend class CCmdInCtrl;

	void Init( CWnd* pWnd, CCmdOutCtrl* pOut, CCmdInCtrl* pIn, CButton *pDo );

// Attributes
public:

// Operations
public:

	void MoveControls( CRect& rectBorder );

	void ParseCommandLine( LPCTSTR szCommand, const char* szaCommandDefns[] );
	CString GetCommand() { return m_parsedcommand.csCommand; };
	CString GetService() { return m_parsedcommand.csService; };
	CString GetCommandLine() { return m_csProcessedCommandLine; };
	CStringArray* GetArgs() { return &m_csaArgs; };
	CString GetSyntaxError() { return m_csSyntaxError; };
	static CString CCommand::GetTimeDate();

// Implementation
protected:
	CString m_csProcessedCommandLine;
	CStringArray m_csaArgs;
	CString m_csSyntaxError;
	struct ParsedCommand
	{
		CString csService;
		CString csCommand;
		CString csArgDefns;
		CString csDescription;
	};
	ParsedCommand m_parsedcommand;
	static void ParseCommandDefn( CString csDefn, ParsedCommand* pCmd );

	void Resize();

	CWnd* m_pWnd;
	CCmdOutCtrl* m_pOut;
	CCmdInCtrl* m_pIn;
	CButton * m_pDo;
};

/////////////////////////////////////////////////////////////////////////////
// CCmdOutCtrl window

class CCmdOutCtrl : public CRichEditCtrl
{
// Construction
public:
	CCmdOutCtrl();

	void Set( CCommand* pCmd ) { m_pCmd = pCmd; };
	void SetFontFace( CString csFaceName = "" );

// Effects
	enum EffectType
	{
		Normal = 0,
		Large = 1,
		Bold = 2,
		Underline = 4,
		Italic = 8,
		Small = 16,
	};

// Operations
	void Output( CString csOut, int nEffect=0, CString* pcsRolledOver=NULL );
	void OutputHelp( CString csCommand, const char* szaCommandDefns[] );
	void OutputTimeDate() { Output( m_pCmd->GetTimeDate() ); };

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCmdOutCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCmdOutCtrl();

protected:
	CCommand* m_pCmd;

	BOOL m_bEraseBackground;
	CString m_csFaceName;

	// Generated message map functions
protected:
	afx_msg void OnRunSelection();
	afx_msg void OnCopyToCmdEntry();
	afx_msg void OnCopySelection();
	//{{AFX_MSG(CCmdOutCtrl)
	afx_msg void OnSysColorChange();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
// CCmdInCtrl window

class CCmdInCtrl : public CEdit
{
// Construction
public:
	CCmdInCtrl();

	void Set( CCommand* pCmd ) { m_pCmd = pCmd; };

// Attributes
public:

	void CheckLines();

// Operations
public:

	void SetCommandText( CString csCommand ) { SetWindowText(csCommand); CheckLines(); };

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCmdInCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCmdInCtrl();

protected:
	int m_nLines;
	CCommand* m_pCmd;

	// Generated message map functions
protected:
	//{{AFX_MSG(CCmdInCtrl)
	afx_msg void OnChange();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMMANDCTRL_H__2BF4ECE9_F408_11D2_A0D2_00105A27C570__INCLUDED_)
