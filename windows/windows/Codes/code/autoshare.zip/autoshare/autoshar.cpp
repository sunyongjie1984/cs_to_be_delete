// Autoshar only to Set Windows NT 4.0 AutoShare option. by bingle

#include <windows.h>
#include <stdio.h>

char *GetMessageText(int nCode);

int main(int argc, char* argv[])
{
	long val=1;
	if(argc==2&&argv[1][0]=='0'&&argv[1][1]==0)val=0;
	puts(" Fingerling to Set WinNT 4.0/Win2000 AutoShare option. by bingle\r\n");
	if(argc>1&&val)
	{		
		printf("\t %s\t--Set AutoShare on\r\n",argv[0]);
		printf("\t %s 0\t--Set AutoShare off\r\n",argv[0]);
		puts(" Any suggestion mail to:bingle@email.com.cn");
		exit(0);
	}

	HKEY hkHive=HKEY_LOCAL_MACHINE, hkOS;
	char sOSKey[]="System\\CurrentControlSet\\Control\\ProductOptions";

	long ret=RegOpenKeyEx(hkHive, sOSKey, 0, KEY_QUERY_VALUE, &hkOS);
	if (ERROR_SUCCESS!=ret)
	{
		if(ret==2)printf(" Cannot found the registry key! Be sure run on the WinNT 4.0 or Win2000!\r\n");
		else if(ret==5)printf(" You have no rights to query NT/2000 type!\r\n");
		else
		{
			char *sMsg=GetMessageText(ret);
			if(sMsg==NULL)printf(" RegOpenKeyEx ProductOption Error, code: %d!\r\n", ret);
			else puts(sMsg);
		}
		exit(0);
	}

	unsigned long dwType=REG_SZ, dwSize=200;
	unsigned char sSubKey[]="ProductType";
	unsigned char sOSType[200];

    ret=RegQueryValueEx(hkOS, (LPTSTR)sSubKey, 0, &dwType ,sOSType, &dwSize);
	if (ERROR_SUCCESS!=ret)
	{
		char *sMsg=GetMessageText(ret);
		if(sMsg==NULL)printf(" RegQueryValueEx ProductType Error, code: %d!\r\n", ret);
		else puts(sMsg);
		RegCloseKey(hkOS);
		exit(0);
	}
	RegCloseKey(hkOS);

	char *sAutoSubkey="AutoShareServer";//asume a server
	if(stricmp((char*)sOSType, "WinNT")==0)sAutoSubkey="AutoShareWks";


	HKEY hkAutoShare;
	char sASKey[]="System\\CurrentControlSet\\Services\\LanmanServer\\Parameters";

	ret=RegOpenKeyEx(hkHive, sASKey, 0, KEY_SET_VALUE, &hkAutoShare);
	if(ERROR_SUCCESS!=ret)
	{
		if(ret==2)printf(" Cannot found the registry key! Be sure run on the WinNT 4.0 or Win2000!\r\n");
		else if(ret==5)printf(" You have no rights to change AutoShare value!\r\n");
		else
		{
			char *sMsg=GetMessageText(ret);
			if(sMsg==NULL)printf(" RegOpenKeyEx Parameters Error, code: %d!\r\n", ret);
			else puts(sMsg);
		}
		exit(0);
	}

	ret=RegSetValueEx(hkAutoShare, sAutoSubkey, 0, REG_DWORD, (u_char*)&val, sizeof(val));
	if(ERROR_SUCCESS!=ret)
	{
		char *sMsg=GetMessageText(ret);
		if(sMsg==NULL)printf(" RegOpenKeyEx Parameters Error, code: %d!\r\n", ret);
		else puts(sMsg);
		exit(0);
	}
	else printf(" Set %s %s Success.\n", sAutoSubkey, val?"ON":"OFF");
	RegCloseKey(hkAutoShare);

	return 0;
}

char *GetMessageText(int nCode)
{
	static char sMsg[1024];
	LPVOID lpMsgBuf;
	int nLen=FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL, nCode,   MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR) &lpMsgBuf,	0,  NULL );
	
	if(nLen==0)return NULL;
	
	strncpy(sMsg, (char*)lpMsgBuf, 1023);
	sMsg[1023]=0;
	LocalFree( lpMsgBuf );
	return sMsg;
}