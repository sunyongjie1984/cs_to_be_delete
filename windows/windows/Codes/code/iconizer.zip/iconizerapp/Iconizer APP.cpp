//===========================================================================
//
//	HomeWork from Belgium			Not licensed software  
//	1999 - 2000						No rights reserved
//
//===========================================================================
//
//	Project/Product :	Iconizer APP
//  FileName		:	Iconizer APPDlg.cpp
//	Author(s)		:	Bart Gysens
//
//	Description		:	Implementation of the Iconizer APP
//
//	Classes			:	CIconizerAPPApp
//						CIconizerAppDlg
//						CAboutBox
//
//	Information		:
//	  Compiler(s)	:	Visual C++ 6.0
//	  Target(s)		:	Windows 95/98 and Windows NT (x86)
//	  Editor		:	Visual C++ 6.0 internal editor
//
//	History
//	Vers.  Date      Aut.  Type     Description
//  -----  --------  ----  -------  -----------------------------------------
//	1.00   22 05 99  BG    Create   Original
//
//===========================================================================

#include "stdafx.h"
#include "Iconizer DLL.h"
#include "Iconizer APP.h"

//===========================================================================
//	Macros and typedefs
//===========================================================================

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//===========================================================================
// 
//	Class			:	CIconizerAPPApp
//	Author(s)		:	Bart Gysens
//
//	Description		:	Implementation of the CIconizerAPPApp class
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

BEGIN_MESSAGE_MAP(CIconizerAPPApp, CWinApp)
	//{{AFX_MSG_MAP(CIconizerAPPApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

CIconizerAPPApp::CIconizerAPPApp()
{
}

BOOL CIconizerAPPApp::InitInstance()
{
	AfxEnableControlContainer();

#ifdef _AFXDLL
	Enable3dControls();
#else
	Enable3dControlsStatic();
#endif

	CIconizerAPPDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	return FALSE;
}


///////////////////////////
// Create the app object //
///////////////////////////

CIconizerAPPApp theApp;


//===========================================================================
// 
//	Class			:	CIconizerAPPDlg
//	Author(s)		:	Bart Gysens
//
//	Description		:	Implementation of the CIconizerAPPDlg class
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

BEGIN_MESSAGE_MAP(CIconizerAPPDlg, CDialog)
	//{{AFX_MSG_MAP(CIconizerAPPDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_HOOK, OnHook)
	ON_BN_CLICKED(IDC_UNHOOK, OnUnhook)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CIconizerAPPDlg::CIconizerAPPDlg(CWnd* pParent )
				:CDialog(CIconizerAPPDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIconizerAPPDlg)
	//}}AFX_DATA_INIT

	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CIconizerAPPDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIconizerAPPDlg)
	//}}AFX_DATA_MAP
}

BOOL CIconizerAPPDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);
	return TRUE;
}

void CIconizerAPPDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CIconizerAPPDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this);
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CIconizerAPPDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CIconizerAPPDlg::OnHook() 
{
	if ( StartHook() )
	{
		GetDlgItem( IDC_HOOK )->EnableWindow( false );
		GetDlgItem( IDC_UNHOOK )->EnableWindow( true );
	}
}

void CIconizerAPPDlg::OnUnhook() 
{
	if ( StopHook() )
	{
		GetDlgItem( IDC_UNHOOK )->EnableWindow( false );
		GetDlgItem( IDC_HOOK )->EnableWindow( true );
	}
}


//===========================================================================
// 
//	Class			:	CAboutDlg
//	Author(s)		:	Bart Gysens
//
//	Description		:	Implementation of the CIconizerAPPDlg class
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}
