//===========================================================================
//
//	HomeWork from Belgium			Not licensed software  
//	1999 - 2000						No rights reserved
//
//===========================================================================
//
//	Project/Product :	Iconizer APP
//  FileName		:	Iconizer APPDlg.h
//	Author(s)		:	Bart Gysens
//
//	Description		:	Header of the Iconizer APP
//
//	Classes			:	CIconizerAPPApp
//						CIconizerAppDlg
//						CAboutBox
//
//	Information		:
//	  Compiler(s)	:	Visual C++ 6.0
//	  Target(s)		:	Windows 95/98 and Windows NT (x86)
//	  Editor		:	Visual C++ 6.0 internal editor
//
//	History
//	Vers.  Date      Aut.  Type     Description
//  -----  --------  ----  -------  -----------------------------------------
//	1.00   22 05 99  BG    Create   Original
//
//===========================================================================

#ifndef _ICONIZERAPP_H_INCLUDED__
#define _ICONIZERAPP_H_INCLUDED__

#include "resource.h"

//===========================================================================
//	Macros and typedefs
//===========================================================================

//===========================================================================
// 
//	Class			:	CIconizerAPPApp
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of the CIconizerAPPApp class
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

class CIconizerAPPApp : public CWinApp
{
	DECLARE_MESSAGE_MAP()

	// Member variables
	public:
	//{{AFX_VIRTUAL(CIconizerAPPApp)
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	// Member functions
	public:
	CIconizerAPPApp();

	public:
	//{{AFX_MSG(CIconizerAPPApp)
	//}}AFX_MSG
};


//===========================================================================
// 
//	Class			:	CIconizerAPPDlg
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of the CIconizerAPPDlg class
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

class CIconizerAPPDlg : public CDialog
{
	DECLARE_MESSAGE_MAP()

	// Member variables
	public:
	//{{AFX_DATA(CIconizerAPPDlg)
	enum { IDD = IDD_ICONIZERAPP_DIALOG };
	//}}AFX_DATA

	protected:
	HICON m_hIcon;

	// Member functions
	public:
	CIconizerAPPDlg(CWnd* pParent = NULL);

	protected:
	//{{AFX_VIRTUAL(CIconizerAPPDlg)
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

	protected:
	//{{AFX_MSG(CIconizerAPPDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnHook();
	afx_msg void OnUnhook();
	//}}AFX_MSG	
};


//===========================================================================
// 
//	Class			:	CAboutBox
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of the CIconizerAPPDlg class
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

class CAboutDlg : public CDialog
{
	DECLARE_MESSAGE_MAP()

	// Member variables
	public:
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// Member functions
	public:
	CAboutDlg();

	protected:
	//{{AFX_VIRTUAL(CAboutDlg)
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

	protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG	
};

//{{AFX_INSERT_LOCATION}}

#endif // _ICONIZERAPP_H_INCLUDED__
