//===========================================================================
//
//	HomeWork from Belgium			Not licensed software  
//	1999 - 2000						No rights reserved
//
//===========================================================================
//
//	Project/Product :	Iconizer DLL
//  FileName		:	log.cpp
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of CLog class
//
//	Classes			:	CLog
//
//	Information		:
//	  Compiler(s)	:	Visual C++ 6.0
//	  Target(s)		:	Windows 95/98 and Windows NT (x86)
//	  Editor		:	Visual C++ 6.0 internal editor
//
//	History
//	Vers.  Date      Aut.  Type     Description
//  -----  --------  ----  -------  -----------------------------------------
//	1.00   22 05 99  BG    Create   Original
//
//===========================================================================

#include "stdafx.h"
#include "stdio.h"
#include "log.h"

//===========================================================================
//	Macros and typedefs
//===========================================================================


//===========================================================================
// 
//	Class			:	CLog
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of the CLog class
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

CLog::CLog()
{
}

void CLog::PutLog( LPSTR pFmt, ... )
{
	FILE * pFile;

	pFile = fopen( "C:\\LOG.TXT", "a" );
	if ( pFile != NULL )
	{
		va_list arg;
		va_start( arg, pFmt );
		vfprintf( pFile, pFmt, arg );
		va_end( arg );
		fclose( pFile );
	}
}
