//===========================================================================
//
//	HomeWork from Belgium			Not licensed software  
//	1999 - 2000						No rights reserved
//
//===========================================================================
//
//	Project/Product :	Iconizer DLL
//  FileName		:	HookList.h
//	Author(s)		:	Bart Gysens
//
//	Description		:	Header file for the CHookList class
//
//	Classes			:	CHookItem
//						CHookList
//
//	Information		:
//	  Compiler(s)	:	Visual C++ 6.0
//	  Target(s)		:	Windows 95/98 and Windows NT (x86)
//	  Editor		:	Visual C++ 5.0 internal editor
//
//	History
//	Vers.  Date      Aut.  Type     Description
//  -----  --------  ----  -------  -----------------------------------------
//	1.00   22 05 99  BG    Create   Original
//
//===========================================================================

#ifndef	_HOOKLIST_H_INCLUDED__
#define	_HOOKLIST_H_INCLUDED__

//===========================================================================
//	Macros and typedefs
//===========================================================================

//===========================================================================
// 
//	Class			:	CHookItem
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of the CHookItem class
//
//	Comments		:	This class is used by the CCom class
//
//	History			:	1.00  : Create
//
//===========================================================================

class CHookItem
{
	// Member variables
	public:
	HWND	m_hWnd			;
	WNDPROC	m_HookWndProc	;
	WNDPROC	m_DefWndProc	;
	BOOL	m_LBtnDown		;	

	// Member functions
	public:
	CHookItem( HWND hWnd, WNDPROC hookWndProc, WNDPROC defWndProc )
	{
		m_hWnd		  = hWnd		;
		m_HookWndProc = hookWndProc	;
		m_DefWndProc  = defWndProc	;
		m_LBtnDown	  = FALSE		;
	}
};

//===========================================================================
// 
//	Class			:	CHookList
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of the CHookList class
//
//	Comments		:	This class is used by the CCom class
//
//	History			:	1.00  : Create
//
//===========================================================================

class CHookList
{
	// Member variables
	protected:
	UINT		m_NbrItems	;
	CHookItem *	m_pHookItem	;

	// Member functions
	public:
	CHookList	();
	~CHookList	();

	public:
	BOOL		AddItem		( CHookItem& Item )	;
	CHookItem *	GetItem		( HWND hWnd )		;
	BOOL		DelItem		( HWND hWnd )		;
	BOOL		DelAllItems	()					;
};

#endif // _HOOKLIST_H_INCLUDED__