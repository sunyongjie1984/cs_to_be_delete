//===========================================================================
//
//	HomeWork from Belgium			Not licensed software  
//	1999 - 2000						No rights reserved
//
//===========================================================================
//
//	Project/Product :	Iconizer
//  FileName		:	HookList.cpp
//	Author(s)		:	Bart Gysens
//
//	Description		:	Implementation file for the CHookList class
//
//	Classes			:	CHookList
//
//	Information		:
//	  Compiler(s)	:	Visual C++ 6.0
//	  Target(s)		:	Windows 95/98 and Windows NT (x86)
//	  Editor		:	Visual C++ 5.0 internal editor
//
//	History
//	Vers.  Date      Aut.  Type     Description
//  -----  --------  ----  -------  -----------------------------------------
//	1.00   22 05 99  BG    Create   Original
//
//===========================================================================

#include "stdafx.h"
#include "malloc.h"
#include "assert.h"
#include "hooklist.h"

//===========================================================================
//	Macros and typedefs
//===========================================================================

//===========================================================================
// 
//	Class			:	CHookList
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of the CHookList class
//
//	Comments		:	This class is used by the CCom class
//
//	History			:	1.00  : Create
//
//===========================================================================

CHookList::CHookList()
{
	m_NbrItems  = 0;
	m_pHookItem = NULL;
}

CHookList::~CHookList()
{
	if ( m_pHookItem != NULL )
		free( m_pHookItem );
}

BOOL CHookList::AddItem( CHookItem& Item )
{
	m_NbrItems++;
	if ( m_pHookItem == NULL )
		m_pHookItem = (CHookItem*) malloc( m_NbrItems * sizeof( CHookItem ) );
	else
		m_pHookItem = (CHookItem*) realloc( m_pHookItem, m_NbrItems * sizeof( CHookItem ) );

	memcpy( m_pHookItem, &Item, sizeof( CHookItem ) );
	return FALSE;
}

CHookItem * CHookList::GetItem( HWND hWnd )
{
	for( UINT i=0; i<m_NbrItems; i++ )
	{
		if ( m_pHookItem[i].m_hWnd == hWnd )
			return &m_pHookItem[i];
	}			
	return NULL;
}

BOOL CHookList::DelItem( HWND hWnd )
{
	BOOL RetVal = FALSE;

	for( UINT i=0; i<m_NbrItems; i++ )
	{
		if ( m_pHookItem[i].m_hWnd = hWnd )
		{
			m_NbrItems--;
			memcpy( &m_pHookItem[i], &m_pHookItem[i+1], ( m_NbrItems - i ) * sizeof( CHookItem ) );
			m_pHookItem = (CHookItem*) realloc( m_pHookItem, m_NbrItems * sizeof( CHookItem ) ); 
		}
	}
	return RetVal;
}

BOOL CHookList::DelAllItems()
{
	free( m_pHookItem );
	m_pHookItem = NULL;
	m_NbrItems  = 0;
	return FALSE;
}
