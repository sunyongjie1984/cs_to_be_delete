//===========================================================================
//
//	HomeWork from Belgium			Not licensed software  
//	1999 - 2000						No rights reserved
//
//===========================================================================
//
//	Project/Product :	Iconizer DLL
//  FileName		:	caption.h
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of caption related functionality
//
//	Classes			:	CCaptionRect	
//
//	Information		:
//	  Compiler(s)	:	Visual C++ 6.0
//	  Target(s)		:	Windows 95/98 and Windows NT (x86)
//	  Editor		:	Visual C++ 6.0 internal editor
//
//	History
//	Vers.  Date      Aut.  Type     Description
//  -----  --------  ----  -------  -----------------------------------------
//	1.00   22 05 99  BG    Create   Original
//
//===========================================================================

#ifndef _CAPTION_H_INCLUDED__
#define _CAPTION_H_INCLUDED__

//===========================================================================
//	Macros and typedefs
//===========================================================================


//===========================================================================
// 
//	Class			:	CCaptionRect
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of the CCaptionRect class
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

class CCaption
{
	// Member functions
	public:
	CCaption();

	protected:
	void CalcCaptionRect( HWND hWnd, RECT& Rect );
	void DrawIconize	( HDC hDc, int x, int y, int off );
	void DrawButtons	( HWND hWnd );	

	public:
	void OnNcActivate	( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem );
	void OnNcPaint		( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem );
	void OnSetText		( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem );
	void OnNcLButtonDown( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem );
	void OnNcLButtonUp	( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem );
	void OnNcMouseMove	( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem );	
};

#endif // _CAPTION_H_INCLUDED__
