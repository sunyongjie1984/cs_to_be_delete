//===========================================================================
//
//	HomeWork from Belgium			Not licensed software  
//	1999 - 2000						No rights reserved
//
//===========================================================================
//
//	Project/Product :	Iconizer DLL
//  FileName		:	TrayIcon.h
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of CTrayIcon class
//
//	Classes			:	CTrayIcon
//
//	Information		:
//	  Compiler(s)	:	Visual C++ 6.0
//	  Target(s)		:	Windows 95/98 and Windows NT (x86)
//	  Editor		:	Visual C++ 6.0 internal editor
//
//	History
//	Vers.  Date      Aut.  Type     Description
//  -----  --------  ----  -------  -----------------------------------------
//	1.00   22 05 99  BG    Create   Original
//
//===========================================================================

#ifndef _TRAYICON_H_INCLUDED__
#define _TRAYICON_H_INCLUDED__

#include "hooklist.h"

//===========================================================================
//	Macros and typedefs
//===========================================================================

#define	WM_NOTIFYICON		( WM_USER + 0x543 )

//===========================================================================
// 
//	Class			:	CTrayIcon
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of the CTrayIcon class
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

class CTrayIcon
{
	// Member functions
	public:
	CTrayIcon();

	public:
	void AddTrayIcon( HWND hWnd );
	void DelTrayIcon( HWND hWnd );

	public:
	virtual void OnNotifyIcon( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem );

	protected:
	HICON GetAppIcon ( HWND hWnd );
	BOOL  TrayMessage( HWND hWnd, DWORD dMsg );
};

#endif // _TRAYICON_H_INCLUDED__
