//===========================================================================
//
//	HomeWork from Belgium			Not licensed software  
//	1999 - 2000						No rights reserved
//
//===========================================================================
//
//	Project/Product :	Iconizer DLL
//  FileName		:	Iconizer DLL.h
//	Author(s)		:	Bart Gysens
//
//	Description		:	Header file of the Iconizer DLL
//
//	Classes			:	None
//
//	Information		:
//	  Compiler(s)	:	Visual C++ 6.0
//	  Target(s)		:	Windows 95/9(8 and Windows NT (x86)
//	  Editor		:	Visual C++ 6.0 internal editor
//
//	History
//	Vers.  Date      Aut.  Type     Description
//  -----  --------  ----  -------  -----------------------------------------
//	1.00   22 05 99  BG    Create   Original
//
//===========================================================================

#ifndef _ICONIZER_DLL_H_INCLUDED__
#define _ICONIZER_DLL_H_INCLUDED__

//===========================================================================
//	Macro's and typedefs
//===========================================================================

#ifndef DLLAPI_ICONIZER
#define DLLAPI_ICONIZER _declspec( dllimport )
#endif

//===========================================================================
//	Declarations
//===========================================================================

DLLAPI_ICONIZER BOOL WINAPI StartHook( void );
DLLAPI_ICONIZER BOOL WINAPI StopHook ( void );

#endif // _ICONIZER_DLL_H_INCLUDED__

