//===========================================================================
//
//	HomeWork from Belgium			Not licensed software  
//	1999 - 2000						No rights reserved
//
//===========================================================================
//
//	Project/Product :	Iconizer DLL
//  FileName		:	Iconizer DLL.cpp
//	Author(s)		:	Bart Gysens
//
//	Description		:	Implementation file of the Iconize DLL
//
//	Classes			:	
//
//	Information		:
//	  Compiler(s)	:	Visual C++ 6.0
//	  Target(s)		:	Windows 95/98 and Windows NT (x86)
//	  Editor		:	Visual C++ 6.0 internal editor
//
//	History
//	Vers.  Date      Aut.  Type     Description
//  -----  --------  ----  -------  -----------------------------------------
//	1.00   22 05 99  BG    Create   Original
//
//===========================================================================

#include "stdafx.h"
#define DLLAPI_ICONIZER __declspec( dllexport )
#include "iconizer DLL.h"
#include "hooklist.h"
#include "caption.h"
#include "trayicon.h"
#include "log.h"

//===========================================================================
//	Macros and typedefs
//===========================================================================

#define WM_UNHOOK			( WM_APP + 0x2500 )
#define GETDEFWNDPROC( h )	( (WNDPROC) GetWindowLong( h, GWL_WNDPROC ) )

//===========================================================================
//	Global variables
//===========================================================================

HINSTANCE	g_hModule	= NULL	;
#pragma data_seg( "Shared" )
HHOOK		g_hHook		= NULL	;
CHookList	g_HookList			;
CCaption	g_Caption			;
CTrayIcon   g_TrayIcon			;
#pragma data_seg()
#pragma comment( linker, "/section:Shared, rws" ) // read, write and share


//===========================================================================
// 
//	Function		:	HookProc
//	Author(s)		:	Bart Gysens
//
//	Description		:	Function that encapsulates the hook
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

LRESULT CALLBACK HookWndProc( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam )
{
	CHookItem * pItem;	
	
	// Search for a known window, quit if unknown
	if ( ( pItem = g_HookList.GetItem( hWnd ) ) == NULL )
		return 0;

	// Hook messages
	switch( Msg )
	{
		case WM_UNHOOK:
			// Message send by DLL on unhook!
			// CLog::PutLog( "* WM_UNHOOK     * HWND = %08X * P: %08X *\r\n", hWnd, GETDEFWNDPROC( hWnd ) );
			SetWindowLong( hWnd, GWL_WNDPROC, (long) pItem->m_DefWndProc );			
			g_HookList.DelItem( hWnd );
			SendMessage( hWnd, WM_NCPAINT, 1, 0 );
			return 0;

		case WM_NCDESTROY:
			// CLog::PutLog( "* WM_NCDESTROY  * HWND = %08X * P: %08X *\r\n", hWnd, GETDEFWNDPROC( hWnd ) );
			SetWindowLong( hWnd, GWL_WNDPROC, (long) pItem->m_DefWndProc );
			CallWindowProc( pItem->m_DefWndProc, hWnd, Msg, wParam, lParam );			
			g_HookList.DelItem( hWnd );
			return 0;

		case WM_NCACTIVATE:
			g_Caption.OnNcActivate( hWnd, Msg, wParam, lParam, pItem );
			return TRUE;

		case WM_NCPAINT:
			g_Caption.OnNcPaint( hWnd, Msg, wParam, lParam, pItem );
			return 0;

		case WM_SETTEXT:
			g_Caption.OnSetText( hWnd, Msg, wParam, lParam, pItem );
			return TRUE;

		case WM_NCLBUTTONDOWN:
			g_Caption.OnNcLButtonDown( hWnd, Msg, wParam, lParam, pItem );
			return 0;

		case WM_NCLBUTTONUP:
			g_Caption.OnNcLButtonUp( hWnd, Msg, wParam, lParam, pItem );
			return 0;

		case WM_NCMOUSEMOVE:
			g_Caption.OnNcMouseMove( hWnd, Msg, wParam, lParam, pItem );
			return 0;

		case WM_NOTIFYICON:
			g_TrayIcon.OnNotifyIcon( hWnd, Msg, wParam, lParam, pItem );
			return 0;

		default:
			break;
	}
	
	// We didn't process the message, so process with default window procedure
	LRESULT RetVal = CallWindowProc( pItem->m_DefWndProc, hWnd, Msg, wParam, lParam );
	return RetVal;
}

//===========================================================================
// 
//	Function		:	HookProc
//	Author(s)		:	Bart Gysens
//
//	Description		:	Function that will replace the normal WndProc with
//						the HookWndProc procedure
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

LRESULT WINAPI CallWndHookProc( int nCode, WPARAM wParam, LPARAM lParam )
{
	LRESULT RetVal = CallNextHookEx( g_hHook, nCode, wParam, lParam );	

	if ( nCode == HC_ACTION )
	{
		LPCREATESTRUCT pCs;
		LPCWPSTRUCT    pCwp  = (LPCWPSTRUCT) lParam	;
		CHookItem *    pItem = g_HookList.GetItem( pCwp->hwnd );

		switch( pCwp->message )
		{
			case WM_NCCREATE:
				pCs = (LPCREATESTRUCT) pCwp->lParam;
				if (   ( ( pCs->style & WS_CAPTION ) == WS_CAPTION )
					&& ( ( pCs->style & WS_MINIMIZEBOX ) == WS_MINIMIZEBOX )
					&& ( ( pCs->style & WS_SYSMENU ) == WS_SYSMENU )
					&& ( pCs->hwndParent == NULL )
					)
				{
					//CLog::PutLog( "* WM_NCCREATE   * HWND = %08X * P: %08X *\r\n", pCwp->hwnd, GETDEFWNDPROC( pCwp->hwnd ) );

					// Add item to hook list
					if ( g_HookList.GetItem( pCwp->hwnd ) == NULL )
						g_HookList.AddItem( CHookItem( pCwp->hwnd, HookWndProc, NULL ) );						
				}
				break;

			case WM_NCPAINT:
				{					
					CHookItem * pItem = g_HookList.GetItem( pCwp->hwnd );

					if ( ( pItem != NULL ) && ( pItem->m_DefWndProc == NULL ) )
					{					
						pItem->m_DefWndProc = GETDEFWNDPROC( pCwp->hwnd );
						SetWindowLong( pCwp->hwnd, GWL_WNDPROC, (long) HookWndProc );
					}
				}
				break;

			default:
				break;
		}
	}

	return RetVal;
}

//===========================================================================
// 
//	Function		:	StartHook
//	Author(s)		:	Bart Gysens
//
//	Description		:	Function to start system wide hook
//
//	Arguments		:	None
//
//	Return value	:	TRUE  = hook successful installed
//						FALSE = hook already installed
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

BOOL WINAPI StartHook( void )
{
	if ( g_hHook != NULL )
		return FALSE;

	g_hHook = SetWindowsHookEx( WH_CALLWNDPROC, CallWndHookProc, g_hModule, 0 );
	return( g_hHook != NULL ); 
}

//===========================================================================
// 
//	Function		:	StopHook
//	Author(s)		:	Bart Gysens
//
//	Description		:	Function to stop system wide hook
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

BOOL WINAPI StopHook( void )
{
	if ( g_hHook != NULL )
	{
		SendMessage( HWND_BROADCAST, WM_UNHOOK, 0, 0 );
		Sleep( 100 );
				
		if ( UnhookWindowsHookEx( g_hHook ) != 0 )
			g_hHook = NULL;
	}

	return( g_hHook == NULL );
}

//===========================================================================
// 
//	Function		:	DllMain
//	Author(s)		:	Bart Gysens
//
//	Description		:	Implementation of the main dll procedure
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			g_hModule = (HINSTANCE) hModule;
			break;

		case DLL_PROCESS_DETACH:
			//	g_HookList.~CHookList();

			// TODO: Major problem:
			// All the windows that where hooked will crash on dll process
			// detach, even if we have unhooked them. I have not yet found the
			// reason why this happens...
			break;
    }

    return TRUE;
}
