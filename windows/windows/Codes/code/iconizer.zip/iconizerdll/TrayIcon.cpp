//===========================================================================
//
//	HomeWork from Belgium			Not licensed software  
//	1999 - 2000						No rights reserved
//
//===========================================================================
//
//	Project/Product :	Iconizer DLL
//  FileName		:	TrayIcon.cpp
//	Author(s)		:	Bart Gysens
//
//	Description		:	Implementation of CTrayIcon class
//
//	Classes			:	CTrayIcon
//
//	Information		:
//	  Compiler(s)	:	Visual C++ 6.0
//	  Target(s)		:	Windows 95/98 and Windows NT (x86)
//	  Editor		:	Visual C++ 6.0 internal editor
//
//	History
//	Vers.  Date      Aut.  Type     Description
//  -----  --------  ----  -------  -----------------------------------------
//	1.00   22 05 99  BG    Create   Original
//
//===========================================================================

#include "stdafx.h"
#include "shellapi.h"
#include "trayicon.h"

//===========================================================================
//	Macros and typedefs
//===========================================================================

//===========================================================================
// 
//	Class			:	CTrayIcon
//	Author(s)		:	Bart Gysens
//
//	Description		:	Implementation of the CTrayIcon class
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

CTrayIcon::CTrayIcon()
{
}

void CTrayIcon::AddTrayIcon( HWND hWnd )
{
	TrayMessage( hWnd, NIM_ADD );
}

void CTrayIcon::DelTrayIcon( HWND hWnd )
{
	TrayMessage( hWnd, NIM_DELETE );
}

void CTrayIcon::OnNotifyIcon( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem )
{
	switch( lParam )
	{
		case WM_RBUTTONDOWN:
			{
				HMENU		 hMenu;
				POINT		 pPos ;
				MENUITEMINFO mItem;
				UINT		 uCmd ;
				char		 About[] = "About Iconizer...";				

				// Get cursor position
				GetCursorPos( &pPos );
				
				// Get window system menu
				hMenu = GetSystemMenu( hWnd, FALSE );				

				// Add separtor menu item
				mItem.cbSize		= sizeof( MENUITEMINFO );
				mItem.fMask			= MIIM_TYPE;
				mItem.fType			= MFT_SEPARATOR;
				mItem.fState		= MFS_ENABLED;
				mItem.wID			= 0xFFFE;
				mItem.hSubMenu		= NULL;
				mItem.hbmpChecked	= NULL;
				mItem.hbmpUnchecked = NULL;
				mItem.dwItemData    = 0;
				mItem.dwTypeData    = 0;
				mItem.cch           = 0;
				InsertMenuItem( hMenu, GetMenuItemCount( hMenu ), TRUE, &mItem );

				// Add "About Iconizer..." item
				mItem.cbSize		= sizeof( MENUITEMINFO );
				mItem.fMask			= MIIM_ID | MIIM_STATE | MIIM_TYPE;
				mItem.fType			= MFT_STRING;
				mItem.fState		= MFS_ENABLED;
				mItem.wID			= 0xFFFF;
				mItem.hSubMenu		= NULL;
				mItem.hbmpChecked	= NULL;
				mItem.hbmpUnchecked = NULL;
				mItem.dwItemData    = 0;
				mItem.dwTypeData    = About;
				mItem.cch           = strlen( About );
				InsertMenuItem( hMenu, GetMenuItemCount( hMenu ), TRUE, &mItem );

				// Show system menu, and execute system command if necessary

				//
				// Remark: Bug fix on TrackPopupMenuEx
				// 1. Set window as foreground window
				// 2. Call TrackPopupMenuEx
				// 3. Post a WM_NULL message
				//
				// => Normal behavior should be a single call to TrackPopupMenuEx

				//
				// TODO: Major problem
				// The menu of the notifyicon is not up-to-date, i.e.
				// sometime the Restore command is disabled!
				//

				SetForegroundWindow( hWnd );
				if ( ( uCmd = TrackPopupMenuEx( hMenu,
							  				    TPM_RETURNCMD | TPM_LEFTBUTTON, 
												pPos.x, 
												pPos.y, 
												hWnd,
												NULL ) ) != 0 )
				{
					// Execute user selected command
					switch( uCmd )
					{
						//
						// TODO:
						// The message 0xFFFF should be made unique by means
						// of RegisterWindowMessage
						//
						case 0xFFFF:
							MessageBox( NULL, "I C O N I Z E R   V 0 . 0 1\n\n   Author: Bart Gysens\nMail @: inggb@hotmail.com", "About Iconizer...", MB_ICONINFORMATION | MB_OK );
							break;

						case SC_MINIMIZE:
						case SC_MAXIMIZE:
						case SC_RESTORE:	
						case SC_CLOSE:
							CTrayIcon::DelTrayIcon( hWnd );
							ShowWindow( hWnd, SW_SHOW );
							SendMessage( hWnd, WM_SYSCOMMAND, uCmd, 0 );
							break;

						default:
							// Delete tray icon, make window visible and restore it
							CTrayIcon::DelTrayIcon( hWnd );
							ShowWindow( hWnd, SW_SHOW );
							SendMessage( hWnd, WM_SYSCOMMAND, SC_RESTORE, 0 );

							// Execute user selected command
							SendMessage( hWnd, WM_SYSCOMMAND, uCmd, 0 );
							break;
					}					
				}

				PostMessage( hWnd, WM_NULL, 0, 0 );

				// Delete added menu items
				DeleteMenu( hMenu, GetMenuItemCount( hMenu ) - 1, MF_BYPOSITION );
				DeleteMenu( hMenu, GetMenuItemCount( hMenu ) - 1, MF_BYPOSITION );

				// Close menu
				SetMenu( hWnd, NULL );				
			}
			break;

		case WM_LBUTTONDOWN:
			CTrayIcon::DelTrayIcon( hWnd );
			ShowWindow( hWnd, SW_SHOW );
			SendMessage( hWnd, WM_SYSCOMMAND, SC_RESTORE, 0 );			
			break;

		default:
			break;
	}
}

BOOL CTrayIcon::TrayMessage( HWND hWnd, DWORD dMsg )
{
	NOTIFYICONDATA	Icon;
	
	Icon.cbSize				= sizeof( NOTIFYICONDATA );
	Icon.hWnd				= hWnd;
	Icon.uID				= 0;
	Icon.uFlags				= NIF_MESSAGE | NIF_ICON | NIF_TIP;
	Icon.uCallbackMessage	= WM_NOTIFYICON;
	Icon.hIcon				= GetAppIcon( hWnd );
	GetWindowText( hWnd, Icon.szTip, sizeof( Icon.szTip ) );

	return Shell_NotifyIcon( dMsg, &Icon );
}

HICON CTrayIcon::GetAppIcon( HWND hWnd )
{
	HICON	  hIcon			;
	char	  FileName[1024];
	HINSTANCE hInst			;
		
	hInst = (HINSTANCE) GetWindowLong( hWnd, GWL_HINSTANCE );
	GetModuleFileName( hInst, FileName, sizeof( FileName ) );	
	ExtractIconEx( FileName, 0, NULL, &hIcon, 1 );
	return hIcon;
}
