//===========================================================================
//
//	HomeWork from Belgium			Not licensed software  
//	1999 - 2000						No rights reserved
//
//===========================================================================
//
//	Project/Product :	Iconizer DLL
//  FileName		:	caption.cpp
//	Author(s)		:	Bart Gysens
//
//	Description		:	Implementation of caption related functionality
//
//	Classes			:	CCaptionRect	
//
//	Information		:
//	  Compiler(s)	:	Visual C++ 6.0
//	  Target(s)		:	Windows 95/98 and Windows NT (x86)
//	  Editor		:	Visual C++ 6.0 internal editor
//
//	History
//	Vers.  Date      Aut.  Type     Description
//  -----  --------  ----  -------  -----------------------------------------
//	1.00   22 05 99  BG    Create   Original
//
//===========================================================================

#include "stdafx.h"
#include "hooklist.h"
#include "trayicon.h"
#include "caption.h"

//===========================================================================
//	Macros and typedefs
//===========================================================================

extern CTrayIcon g_TrayIcon;

//===========================================================================
// 
//	Class			:	CCaptionRect
//	Author(s)		:	Bart Gysens
//
//	Description		:	Implementation of the CCaptionRect class
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

CCaption::CCaption()
{
}

void CCaption::CalcCaptionRect( HWND hWnd, RECT& Rect )
{	
	DWORD dStyle		;
	SIZE  sFrame		;
	int	  Icon			;	

	// Get frame size of window
	dStyle    = GetWindowLong( hWnd, GWL_STYLE );
	sFrame.cx = GetSystemMetrics( ( dStyle & WS_THICKFRAME ) ? SM_CXSIZEFRAME : SM_CXFIXEDFRAME );
	sFrame.cy = GetSystemMetrics( ( dStyle & WS_THICKFRAME ) ? SM_CYSIZEFRAME : SM_CYFIXEDFRAME );

	// Get width of icon/button in caption
	Icon = GetSystemMetrics( SM_CXSIZE );

	// Calculate rectangle dimensions
	GetWindowRect( hWnd, &Rect );
	Rect.bottom -= Rect.top;
	Rect.right  -= Rect.left;
	Rect.top     = 0;
	Rect.left    = 0;

	Rect.left   += sFrame.cx;
	Rect.right  -= sFrame.cx;
	Rect.top    += sFrame.cy;
	Rect.bottom  = Rect.top + GetSystemMetrics( SM_CYCAPTION )
	                        - GetSystemMetrics( SM_CYBORDER );
}

void CCaption::DrawIconize( HDC hDc, int x, int y, int off )
{
	//
	// TODO:
	// This should be done flikker free by means
	// of a memory DC
	//

	HPEN Pen, oldPen;
	int	 cxBtn = GetSystemMetrics( SM_CXSIZE ) - 5;
	int  cyBtn = GetSystemMetrics( SM_CYSIZE ) - 5;
	
	Pen = CreatePen( PS_SOLID, 1, RGB( 0, 0, 0 ) );
	oldPen = (HPEN)   SelectObject( hDc, Pen );

	MoveToEx( hDc, x + 1 + cxBtn/4 + off, y + 1 + cyBtn/4, NULL );
	LineTo( hDc, x + 1 + cxBtn*3/4 + off, y + 1 + cyBtn/4 );
	LineTo( hDc, x + 1 + cxBtn*3/4 + off, y + 1 + cyBtn/4 );
	LineTo( hDc, x + 1 + cxBtn/2 + off, y + 1 + cyBtn*3/4 );
	LineTo( hDc, x + 1 + cxBtn/4 + off, y + 1 + cyBtn/ 4 );

	SelectObject( hDc, oldPen );
	DeleteObject( Pen );
}

void CCaption::DrawButtons( HWND hWnd )
{
	HDC	  hDc		;
	RECT  rCap		;
	DWORD dStyle	;
	DWORD dExStyle	;
	int	  cxBtn		;
	int   cyBtn		;
	RECT  rPos		;

	// Get window device context		
	if ( ( hDc = GetWindowDC( hWnd ) ) != NULL )
	{
		// Get caption coordinates
		CCaption::CalcCaptionRect( hWnd, rCap );

		// Get window style
		dStyle   = GetWindowLong( hWnd, GWL_STYLE );
		dExStyle = GetWindowLong( hWnd, GWL_EXSTYLE );
	
		// Check if we have a caption
		if ( ( dStyle & WS_CAPTION ) == WS_CAPTION )
		{
			// Get button dimensions
			cxBtn = GetSystemMetrics( SM_CXSIZE );
			cyBtn = GetSystemMetrics( SM_CYSIZE );

			// Calc position and draw close button
			rPos.top    = rCap.top + 2;
			rPos.bottom = rCap.bottom - 2;
			rPos.right  = rCap.right - 2;
			rPos.left   = rCap.right - 2 - ( cxBtn - 2);
			DrawFrameControl( hDc, &rPos, DFC_CAPTION, DFCS_CAPTIONCLOSE );

			// Calc position and draw maximize<->restore/help button
			if ( ( dStyle & WS_MAXIMIZEBOX ) == WS_MAXIMIZEBOX )
			{
				rPos.right -= cxBtn;
				rPos.left  -= cxBtn;
				DrawFrameControl( hDc, &rPos, DFC_CAPTION, IsZoomed( hWnd ) ? DFCS_CAPTIONRESTORE 
				                                                            : DFCS_CAPTIONMAX );
			}
			else if ( ( dExStyle & WS_EX_CONTEXTHELP ) == WS_EX_CONTEXTHELP )
			{
				rPos.right -= cxBtn;
				rPos.left  -= cxBtn;
				DrawFrameControl( hDc, &rPos, DFC_CAPTION, DFCS_CAPTIONHELP );
			}

			// Calc position and draw minimize and iconize button
			if ( ( dStyle & WS_MINIMIZEBOX ) == WS_MINIMIZEBOX )
			{
				// Minimize button
				rPos.right -= ( cxBtn - 2 );
				rPos.left  -= ( cxBtn - 2 );
				DrawFrameControl( hDc, &rPos, DFC_CAPTION, DFCS_CAPTIONMIN );

				// Iconize button
				rPos.right -= ( cxBtn - 2 );
				rPos.left  -= ( cxBtn - 2 );
				DrawFrameControl( hDc, &rPos, DFC_BUTTON, DFCS_BUTTONPUSH );

				// Draw a btnface
				DrawIconize( hDc, rPos.left, rPos.top, 0 );
			}
		}

		// Release device context
		ReleaseDC( hWnd, hDc );
	}
}

void CCaption::OnNcActivate( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem )
{
	// Call default window procedure
	CallWindowProc( pItem->m_DefWndProc, hWnd, Msg, wParam, lParam );

	// Send WM_NCPAINT message
	SendMessage( hWnd, WM_NCPAINT, 1, 0 );
}

void CCaption::OnNcPaint( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem )
{
	// Call default window procedure
	CallWindowProc( pItem->m_DefWndProc, hWnd, Msg, wParam, lParam );

	// Add iconize button to caption
	CCaption::DrawButtons( hWnd );
}

void CCaption::OnSetText( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem )
{
	// Call default window procedure
	CallWindowProc( pItem->m_DefWndProc, hWnd, Msg, wParam, lParam );

	// Redraw caption buttons
	CCaption::DrawButtons( hWnd );
}

void CCaption::OnNcLButtonDown( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem )
{
	HDC		hDc		;
	POINT	Pnt		;
	RECT	rPos	;
	RECT	rWin	;

	// Redraw caption buttons
	if ( ( hDc = GetWindowDC( hWnd ) ) != NULL )
	{
		// Convert mouse postion relative to caption rectangle
		GetWindowRect( hWnd, &rWin );
		Pnt.x = MAKEPOINTS( lParam ).x - rWin.left;
		Pnt.y = MAKEPOINTS( lParam ).y - rWin.top;

		// Calculate rectangle position of iconize button
		CCaption::CalcCaptionRect( hWnd, rPos );
		rPos.top    += 2;	
		rPos.bottom -= 2;
		rPos.right  -= ( ( GetSystemMetrics( SM_CXSIZE ) * 3 ) - 2 );
		rPos.left    = rPos.right - ( GetSystemMetrics( SM_CXSIZE ) - 2 );

		// Check if mouse position is in rectangle
		if ( PtInRect( &rPos, Pnt ) )
		{
			pItem->m_LBtnDown = TRUE;
			DrawFrameControl( hDc, &rPos, DFC_BUTTON, DFCS_BUTTONPUSH | DFCS_PUSHED );
			DrawIconize( hDc, rPos.left, rPos.top, 1 );			
		}
		else
			CallWindowProc( pItem->m_DefWndProc, hWnd, Msg, wParam, lParam );
		
		DeleteObject( hDc );
	}
}

void CCaption::OnNcLButtonUp( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem )
{
	HDC		hDc		;
	POINT	Pnt		;
	RECT	rPos	;
	RECT	rWin	;

	// Redraw caption buttons
	if ( ( hDc = GetWindowDC( hWnd ) ) != NULL )
	{
		// Convert mouse postion relative to caption rectangle
		GetWindowRect( hWnd, &rWin );
		Pnt.x = MAKEPOINTS( lParam ).x - rWin.left;
		Pnt.y = MAKEPOINTS( lParam ).y - rWin.top;

		// Calculate rectangle position of iconize button
		CCaption::CalcCaptionRect( hWnd, rPos );
		rPos.top    += 2;	
		rPos.bottom -= 2;
		rPos.right  -= ( ( GetSystemMetrics( SM_CXSIZE ) * 3 ) - 2 );
		rPos.left    = rPos.right - ( GetSystemMetrics( SM_CXSIZE ) - 2 );

		// Check if mouse position is in rectangle
		if ( PtInRect( &rPos, Pnt ) )
		{	
			SendMessage( hWnd, WM_SYSCOMMAND, SC_MINIMIZE, 0 );
			ShowWindow( hWnd, SW_HIDE );
			g_TrayIcon.AddTrayIcon( hWnd );
		}
		else
			CallWindowProc( pItem->m_DefWndProc, hWnd, Msg, wParam, lParam );

		DrawFrameControl( hDc, &rPos, DFC_BUTTON, DFCS_BUTTONPUSH );
		DrawIconize( hDc, rPos.left, rPos.top, 0 );		
		pItem->m_LBtnDown = FALSE;
		DeleteObject( hDc );
	}
}

void CCaption::OnNcMouseMove( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam, CHookItem * pItem )
{
	HDC		hDc		;
	POINT	Pnt		;
	RECT	rPos	;
	RECT	rWin	;

	// Redraw caption buttons
	if ( ( hDc = GetWindowDC( hWnd ) ) != NULL )
	{
		// Convert mouse postion relative to caption rectangle
		GetWindowRect( hWnd, &rWin );
		Pnt.x = MAKEPOINTS( lParam ).x - rWin.left;
		Pnt.y = MAKEPOINTS( lParam ).y - rWin.top;

		// Calculate rectangle position of iconize button
		CCaption::CalcCaptionRect( hWnd, rPos );
		rPos.top    += 2;	
		rPos.bottom -= 2;
		rPos.right  -= ( ( GetSystemMetrics( SM_CXSIZE ) * 3 ) - 2 );
		rPos.left    = rPos.right - ( GetSystemMetrics( SM_CXSIZE ) - 2 );

		// Check if mouse position is in rectangle
		if ( PtInRect( &rPos, Pnt ) )
		{
			DrawFrameControl( hDc, &rPos, DFC_BUTTON, ( pItem ->m_LBtnDown ) ? DFCS_BUTTONPUSH | DFCS_PUSHED : DFCS_BUTTONPUSH );
			DrawIconize( hDc, rPos.left, rPos.top, ( pItem ->m_LBtnDown ) ? 1 : 0 );
		}
		else
		{
			pItem->m_LBtnDown = FALSE;
			DrawFrameControl( hDc, &rPos, DFC_BUTTON, DFCS_BUTTONPUSH );
			DrawIconize( hDc, rPos.left, rPos.top, 0 );
			CallWindowProc( pItem->m_DefWndProc, hWnd, Msg, wParam, lParam );
		}
	
		DeleteObject( hDc );
	}
}
