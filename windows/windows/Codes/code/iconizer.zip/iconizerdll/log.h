//===========================================================================
//
//	HomeWork from Belgium			Not licensed software  
//	1999 - 2000						No rights reserved
//
//===========================================================================
//
//	Project/Product :	Iconizer DLL
//  FileName		:	log.h
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of CLog class
//
//	Classes			:	CLog
//
//	Information		:
//	  Compiler(s)	:	Visual C++ 6.0
//	  Target(s)		:	Windows 95/98 and Windows NT (x86)
//	  Editor		:	Visual C++ 6.0 internal editor
//
//	History
//	Vers.  Date      Aut.  Type     Description
//  -----  --------  ----  -------  -----------------------------------------
//	1.00   22 05 99  BG    Create   Original
//
//===========================================================================

#ifndef _LOG_H_INCLUDED__
#define _LOG_H_INCLUDED__

//===========================================================================
//	Macros and typedefs
//===========================================================================


//===========================================================================
// 
//	Class			:	CLog
//	Author(s)		:	Bart Gysens
//
//	Description		:	Declaration of the CLog class
//
//	Comments		:	none
//
//	History			:	1.00  : Create
//
//===========================================================================

class CLog
{
	// Member functions
	public:
	CLog();

	public:
	static void PutLog( LPSTR pFmt, ... );
};

#endif // _LOG_H_INCLUDED__
