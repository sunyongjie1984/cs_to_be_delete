/*************************************************************************

DiscEx

PC disk excerciser

Use this program to burn in a disk drive or test for intermittent errors
or to force a "dying" disk to fail.

Usage:  DiscEx <no passes>

        <no passes> in the number of times you want DiscEx to execute
        the random seek test.  Each pass executes 500 random positions
        and reads.
        
        The test is performed on the current (default) drive.
        
License and copyright:

        The program (DiscEx.exe and DiscEx.c) is copyright (c) 1988 by 
        Steven D. Stern.  
        
        If you find this program useful, please send a couple of bucks
        to the author:
           Steven D. Stern
           Crown Software Corporation
           900 North Michigan Avenue, Suite 900
           Chicago, IL  60611
           
        The author may contacted via Compuserve:  70327,135
        
*************************************************************************/
        
          
#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <memory.h>
#include <sys\timeb.h>

#define BUFSIZE 4096

long random();

main(int argc, char *argv[] )
   {
   long bytes,                  /* max file size in bytes */
        blocks,                 /* max no. of BUFSIZE blocks */
        position;
   long dpi;
   int ret;
   int pass;                    /* no of times to repeat random reads */
   struct timeb TIME;   
   struct diskfree_t drive;
   char filebuf[BUFSIZE];
   char filename[9];
   FILE *testfile;
   
   if (argc > 1) pass = atoi(argv[1]);
   
   printf("DiscEx:  The PC disk excerciser\n");
   printf("Copyright (c) 1988, Steven D. Stern\n\n");
   
   _dos_getdiskfree(0,&drive);   /* how much free space on disk? */
   
   bytes =                       /* convert it to byte-size      */
      (long)drive.bytes_per_sector * 
      (long)drive.sectors_per_cluster * 
      (long)drive.avail_clusters;
   
   strcpy(filebuf,"DXXXXXXX");
   
   mktemp(filebuf);
   
   testfile = fopen(filebuf,"a+b");
   
   if (testfile == NULL)
      {
      printf("Unable to open scratch file: %s\n",filebuf);
      exit(1);
      }
      
   printf("Creating scratch file: %s\n",filebuf);
   strcpy(filename,filebuf);
   
   setvbuf(testfile,NULL,_IOFBF,4096);
   
   blocks = bytes / BUFSIZE;
   
   memset(filebuf,0xF5,BUFSIZE);        /* load buf with some data */
   
   printf("Loading scratch file for %ld bytes\n",blocks*BUFSIZE);
   
   for (dpi = 0; dpi < blocks; dpi++)
      {
      ret = fwrite(filebuf,BUFSIZE,1,testfile);
      if (ret != 1)
         {
         printf("Error writing scratch file\n");
         fclose(testfile);
         unlink(filename);
         exit(1);
         }
      }
   fflush(testfile);
   printf("Load successful\n");
   
   printf("Beginning sequential read test\n");
   
   fseek(testfile,0L,SEEK_SET);         /* rewind the file */
   for (dpi = 0; dpi < blocks; dpi++)
      {
      ret = fread(filebuf,BUFSIZE,1,testfile);
      }
   printf("Sequential read test complete\n");
   
   
   while (pass)
      {
      ftime(&TIME);
      srand(TIME.millitm);
      printf("%d pass(es) remaining",pass);
      fflush(stdout);
      for (dpi = 0; dpi < 500L; dpi++)
         {
         position = random(bytes);
         fseek(testfile,position,SEEK_SET);
         fread(filebuf,1,1,testfile);
         }
      printf("... complete\n");
      pass--;
      }
   printf("Random seek test complete\n");
   printf("Erasing scratch file\n");
   
   fclose(testfile);
   unlink(filename);
   }

long random( long top )
   {
   double scale;
   int i;
   double d;
   
   i = rand();
   scale = (double)top / (double)32768;
   d= scale * (double) i;
   if ( (long)d > top)
      {
      printf("Random problem\n");
      return (0L);
      }
   return ( (long)d );
   }
