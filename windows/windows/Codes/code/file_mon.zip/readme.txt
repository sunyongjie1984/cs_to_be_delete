________________________________________________________________ 

OpenTrap, Version 1.2
Copyright (c) 1997-1998 Ziff-Davis, Inc.
Written by Rick Knoblaugh and Gregory Wolking
First Published in PC Magazine, US Edition, July 1997
http://www.zdnet.com/pcmag/pctech/content/16/13/ut1613.001.html
________________________________________________________________ 

PLATFORMS:
Windows 95, Windows 98

DESCRIPTION:
When you try to launch an application and get a message such as "Can't find 
foo.bar or one of its components," you can't tell what file is missing. OpenTrap 
solves this problem. It logs which files were successfully accessed and which 
were not. It also can eavesdrop on file close functions to help you track the 
time spent working on particular files.

REVISION HISTORY:
Version 1.2
- Fixed a bug in FuncTrap.vxd that caused the program to crash when certain
types of applications using VxDs were loaded before OpenTrap and then unloaded 
while OpenTrap was running.

Version 1.1
- Updated FuncTrap.vxd for use with Windows 95b (OSR2) and Windows 98.

INSTALLATION:
Place the program files OpenTrap.EXE, OpenTrap.HLP, and OpenTrap.CNT files files 
in the folder of your choice, place the file FuncTrap.vxd in your Windows SYSTEM 
directory, and then create a shortcut to OpenTrap.EXE.
	Note that our BigBin utility (PC Magazine, June 10, 1997) also uses the 
FuncTrap.vxd device driver. For both programs to work correctly, there must be 
exactly one copy of Functrap.vxd on your system.
	To remove OpenTrap from your system, launch the program with the /U switch 
on the command line and OpenTrap will remove its settings from the system 
Registry. Once the uninstall process is complete, you may delete OpenTrap's 
files from your hard disk.
	Note: If you also have the PC Magazine Utility "BigBin" installed on your 
system, do not delete the FuncTrap.vxd virtual device driver. BigBin requires 
that file to operate.
	For details on program usage, refer to OpenTrap's online Help file.

SUPPORT:
Help for PC Magazine's free utilities can be obtained in our online discussion 
areas, both on the World Wide Web (www.pcmag.com/discuss.htm) and on CompuServe 
(GO ZNT:TIPS, Section 2). You may find an answer to your question simply by 
reading the posted messages. The authors of current utilities generally visit 
these forums daily. If the author is not available and the forum sysops can't 
answer your question, the Utilities column editor, who also checks the forums 
each day, will contact the author for you.

LICENSE INFORMATION:
PC Magazine programs are copyrighted and cannot be distributed, whether modified 
or unmodified. Use is subject to the terms and conditions of the license 
agreement distributed with the programs.

----

Rick Knoblaugh, who wrote the FuncTrap.vxd device driver, is a systems 
programming expert and a frequent contributor to PC Magazine. Gregory Wolking, 
who wrote the OpenTrap interface, is the primary sysop of the ZNT:TIPS Forum 
on ZDNet/CompuServe and the PC Magazine Utilities discussion 
area on the Web (www.pcmag.com/discuss.htm). Sheryl Canter is the editor of the 
Utilities column and a Contributing Editor of PC Magazine. 

