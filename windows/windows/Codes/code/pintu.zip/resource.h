//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resource.rc
//
#define IDI_MOVE_PIC                    112
#define ID_MENUITEM40001                40001
#define ID_HELP_ABOUT                   40001
#define IDM_HELP_ABOUT                  40001
#define ID_MENUITEM40002                40002
#define ID_PIC_ONE                      40002
#define ID_MENUITEM40003                40003
#define ID_PIC_TWO                      40003
#define ID_MENUITEM40004                40004
#define ID_PIC_THREE                    40004
#define ID_MENUITEM40005                40005
#define ID_PIC_FOUR                     40005
#define ID_MENUITEM40006                40006
#define ID_PIC_FIVE                     40006
#define ID_MENUITEM40007                40007
#define ID_PIC_CUS                      40007
#define IDM_PIC_OPEN                    40007
#define ID_MENUITEM40009                40009
#define ID_GAME_RESET                   40009
#define IDM_GAME_RESET                  40009
#define ID_MENUITEM40010                40010
#define ID_GAME_EXIT                    40010
#define IDM_GAME_EXIT                   40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
