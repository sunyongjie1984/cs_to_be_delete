// CDirTreeDlgDlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "CDirTreeDlg.h"
#include "CDirTreeDlgDlg.h"
#include <direct.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg-Dialogfeld f�r Anwendungsbefehl "Info"

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialogfelddaten
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// Keine Nachrichten-Handler
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCDirTreeDlgDlg Dialogfeld

CCDirTreeDlgDlg::CCDirTreeDlgDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCDirTreeDlgDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCDirTreeDlgDlg)
	m_strSelection = _T("");
	m_strPathName = _T("");
	//}}AFX_DATA_INIT
	// Beachten Sie, dass LoadIcon unter Win32 keinen nachfolgenden DestroyIcon-Aufruf ben�tigt
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCDirTreeDlgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCDirTreeDlgDlg)
	DDX_Text(pDX, IDC_SELTEXT, m_strSelection);
	DDX_Text(pDX, IDC_PATHNAME, m_strPathName);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCDirTreeDlgDlg, CDialog)
	//{{AFX_MSG_MAP(CCDirTreeDlgDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SELECT, OnSelect)
	ON_NOTIFY(TVN_SELCHANGED, IDC_DIRTREE, OnSelchangedDirtree)
	ON_BN_CLICKED(IDC_SELOK, OnSelok)
	ON_BN_CLICKED(IDC_FILENAMES, OnFilenames)
	ON_BN_CLICKED(IDC_FOLDERS, OnFolders)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCDirTreeDlgDlg Nachrichten-Handler

BOOL CCDirTreeDlgDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Hinzuf�gen des Men�befehls "Info..." zum Systemmen�.

	// IDM_ABOUTBOX muss sich im Bereich der Systembefehle befinden.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Symbol f�r dieses Dialogfeld festlegen. Wird automatisch erledigt
	//  wenn das Hauptfenster der Anwendung kein Dialogfeld ist
	SetIcon(m_hIcon, TRUE);			// Gro�es Symbol verwenden
	SetIcon(m_hIcon, FALSE);		// Kleines Symbol verwenden
	
	// ZU ERLEDIGEN: Hier zus�tzliche Initialisierung einf�gen
	// First step
	// subclassing the DirTreeCtrl
	m_DirTree.SubclassDlgItem( IDC_DIRTREE, this );
	// next step
	// setting the StartPath if NULL the DirTreeCtrl
	// displays all drives on this PC
	m_DirTree.DisplayTree( NULL /*Display all*/, TRUE /* TRUE = Display Files*/ );
	char szWorkDir[256];
	_getcwd( szWorkDir, 256 );
	// set the Path to the current Work-Directory
	m_DirTree.SetSelPath( szWorkDir );
	((CButton*)GetDlgItem(IDC_FILENAMES))->SetCheck( 1 );
	return TRUE;  // Geben Sie TRUE zur�ck, au�er ein Steuerelement soll den Fokus erhalten
}

void CCDirTreeDlgDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// Wollen Sie Ihrem Dialogfeld eine Schaltfl�che "Minimieren" hinzuf�gen, ben�tigen Sie 
//  den nachstehenden Code, um das Symbol zu zeichnen. F�r MFC-Anwendungen, die das 
//  Dokument/Ansicht-Modell verwenden, wird dies automatisch f�r Sie erledigt.

void CCDirTreeDlgDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Ger�tekontext f�r Zeichnen

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Symbol in Client-Rechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// Die Systemaufrufe fragen den Cursorform ab, die angezeigt werden soll, w�hrend der Benutzer
//  das zum Symbol verkleinerte Fenster mit der Maus zieht.
HCURSOR CCDirTreeDlgDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCDirTreeDlgDlg::OnSelect() 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	UpdateData();
	CString strOldPath = m_strPathName;  // save the current path

	if ( !m_DirTree.SetSelPath( m_strSelection ) )
	{
		MessageBox("Whoops, this path does not exist!",
			       "Setting the selection",
				   MB_ICONINFORMATION );
	}
}

void CCDirTreeDlgDlg::OnSelchangedDirtree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	m_strPathName = m_DirTree.GetFullPath( pNMTreeView->itemNew.hItem );
	UpdateData( FALSE );
	*pResult = 0;
}

void CCDirTreeDlgDlg::OnOK() 
{
	// TODO: Zus�tzliche Pr�fung hier einf�gen
	
	
}

void CCDirTreeDlgDlg::OnSelok() 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	CString strTemp;
	
	UpdateData();
	
	strTemp.Format("You have select:\n%s", m_strPathName );
	AfxMessageBox( strTemp );
	CDialog::OnOK();
}

void CCDirTreeDlgDlg::OnFilenames() 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	m_DirTree.DisplayTree( NULL, TRUE );
}

void CCDirTreeDlgDlg::OnFolders() 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	m_DirTree.DisplayTree( NULL, FALSE );
}
