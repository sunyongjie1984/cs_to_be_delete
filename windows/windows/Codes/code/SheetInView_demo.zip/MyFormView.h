#if !defined(AFX_MYFORMVIEW_H__96C3F27F_AD99_11D3_AB38_005004CF7A2A__INCLUDED_)
#define AFX_MYFORMVIEW_H__96C3F27F_AD99_11D3_AB38_005004CF7A2A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyFormView.h : header file
//

#include "PropPgFormView.h"
#include "PropPages.h"

/////////////////////////////////////////////////////////////////////////////
// CMyFormView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CMyFormView : public CPropPgFormView
{
protected:
	CMyFormView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMyFormView)

// Form Data
public:
	//{{AFX_DATA(CMyFormView)
	enum { IDD = IDD_VIEW_DLG };
	CSpinButtonCtrl	m_ctlOffset;
	//}}AFX_DATA

	CPropPage1	m_Page1;	
	CPropPage2	m_Page2;	
	CPropPage3	m_Page3;

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyFormView)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMyFormView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CMyFormView)
	afx_msg void OnClose();
	afx_msg void OnResizeFrame();
	afx_msg void OnDisable();
	afx_msg void OnDeltaposOffset(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCenter();
	afx_msg void OnAllowPageChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYFORMVIEW_H__96C3F27F_AD99_11D3_AB38_005004CF7A2A__INCLUDED_)
