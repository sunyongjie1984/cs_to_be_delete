// PropPage1.h : header file
//

#ifndef __PROPPAGE1_H__
#define __PROPPAGE1_H__

#include "ViewPropertyPage.h"
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CPropPage1 dialog

class CPropPage1 : public CViewPropertyPage
{
	DECLARE_DYNCREATE(CPropPage1)

// Construction
public:
	CPropPage1();
	~CPropPage1();

// Dialog Data
	//{{AFX_DATA(CPropPage1)
	enum { IDD = IDD_PROPPAGE1 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPage1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropPage1)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};


/////////////////////////////////////////////////////////////////////////////
// CPropPage2 dialog

class CPropPage2 : public CViewPropertyPage
{
	DECLARE_DYNCREATE(CPropPage2)

// Construction
public:
	CPropPage2();
	~CPropPage2();

// Dialog Data
	//{{AFX_DATA(CPropPage2)
	enum { IDD = IDD_PROPPAGE2 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPage2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropPage2)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};


/////////////////////////////////////////////////////////////////////////////
// CPropPage3 dialog

class CPropPage3 : public CViewPropertyPage
{
	DECLARE_DYNCREATE(CPropPage3)

// Construction
public:
	CPropPage3();
	~CPropPage3();

// Dialog Data
	//{{AFX_DATA(CPropPage3)
	enum { IDD = IDD_PROPPAGE3 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPage3)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropPage3)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};



#endif // __PROPPAGE1_H__
