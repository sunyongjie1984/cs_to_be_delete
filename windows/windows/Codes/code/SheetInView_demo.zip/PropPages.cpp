// PropPages.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "PropPages.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CPropPage1, CViewPropertyPage)
IMPLEMENT_DYNCREATE(CPropPage2, CViewPropertyPage)
IMPLEMENT_DYNCREATE(CPropPage3, CViewPropertyPage)


/////////////////////////////////////////////////////////////////////////////
// CPropPage1 property page

CPropPage1::CPropPage1() : CViewPropertyPage(CPropPage1::IDD)
{
	//{{AFX_DATA_INIT(CPropPage1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPropPage1::~CPropPage1()
{
}

void CPropPage1::DoDataExchange(CDataExchange* pDX)
{
	CViewPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPage1)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPage1, CViewPropertyPage)
	//{{AFX_MSG_MAP(CPropPage1)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CPropPage2 property page

CPropPage2::CPropPage2() : CViewPropertyPage(CPropPage2::IDD)
{
	//{{AFX_DATA_INIT(CPropPage2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPropPage2::~CPropPage2()
{
}

void CPropPage2::DoDataExchange(CDataExchange* pDX)
{
	CViewPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPage2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPage2, CViewPropertyPage)
	//{{AFX_MSG_MAP(CPropPage2)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CPropPage3 property page

CPropPage3::CPropPage3() : CViewPropertyPage(CPropPage3::IDD)
{
	//{{AFX_DATA_INIT(CPropPage3)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPropPage3::~CPropPage3()
{
}

void CPropPage3::DoDataExchange(CDataExchange* pDX)
{
	CViewPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPage3)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPage3, CViewPropertyPage)
	//{{AFX_MSG_MAP(CPropPage3)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


