// MyFormView.cpp : implementation file
//

#include "stdafx.h"
#include "PropPgFormView.h"
#include "MyFormView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyFormView

IMPLEMENT_DYNCREATE(CMyFormView, CPropPgFormView)

CMyFormView::CMyFormView()
	: CPropPgFormView(CMyFormView::IDD)
{
	//{{AFX_DATA_INIT(CMyFormView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CMyFormView::~CMyFormView()
{
}

void CMyFormView::DoDataExchange(CDataExchange* pDX)
{
	CPropPgFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyFormView)
	DDX_Control(pDX, IDC_OFFSET, m_ctlOffset);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyFormView, CPropPgFormView)
	//{{AFX_MSG_MAP(CMyFormView)
	ON_BN_CLICKED(IDC_CLOSE, OnClose)
	ON_BN_CLICKED(IDC_RESIZE_FRAME, OnResizeFrame)
	ON_BN_CLICKED(IDC_DISABLE, OnDisable)
	ON_NOTIFY(UDN_DELTAPOS, IDC_OFFSET, OnDeltaposOffset)
	ON_BN_CLICKED(IDC_CENTER, OnCenter)
	ON_BN_CLICKED(IDC_ALLOW_PAGE_CHANGE, OnAllowPageChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyFormView diagnostics

#ifdef _DEBUG
void CMyFormView::AssertValid() const
{
	CPropPgFormView::AssertValid();
}

void CMyFormView::Dump(CDumpContext& dc) const
{
	CPropPgFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMyFormView message handlers

BOOL CMyFormView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	if (!CPropPgFormView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext))
		return FALSE;

	m_PropSheet.AddPage(&m_Page1);
	m_PropSheet.AddPage(&m_Page2);
	m_PropSheet.AddPage(&m_Page3);

	// create a modeless property sheet
	if (!m_PropSheet.Create(this)) {
		DestroyWindow();
		return FALSE;
	}
	((CButton*)GetDlgItem(IDC_CENTER))->SetCheck(m_PropSheet.m_Center);
	((CButton*)GetDlgItem(IDC_ALLOW_PAGE_CHANGE))->SetCheck(m_PropSheet.m_bOKToLeaveTab);

	return TRUE;	
}

void CMyFormView::OnClose() 
{
	GetParentFrame()->SendMessage(WM_CLOSE);
}

void CMyFormView::OnResizeFrame() 
{
	ResizeParentFrame();
}

void CMyFormView::OnDisable() 
{
	CViewPropertyPage	*pPg = (CViewPropertyPage*)m_PropSheet.GetActivePage(); 
	pPg->EnableControls(!pPg->IsEnabled());
	GetDlgItem(IDC_DISABLE)->SetWindowText((pPg->IsEnabled() ? "Disable" : "Enable") + CString(" page controls"));
}

void CMyFormView::OnDeltaposOffset(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	int	iOffset = GetPropertySheetOffset();
	iOffset = pNMUpDown->iPos + pNMUpDown->iDelta;
	if (iOffset < 0)
		iOffset = 0;
	else if (iOffset > 100)
		iOffset = 100;
	if (iOffset != GetPropertySheetOffset())
		SetPropertySheetOffset(iOffset, TRUE);
	*pResult = 0;
}

void CMyFormView::OnInitialUpdate() 
{
	CPropPgFormView::OnInitialUpdate();
	
	m_ctlOffset.SetPos(GetPropertySheetOffset());
}

BOOL CMyFormView::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
	if (TCN_SELCHANGE == ((LPNMHDR)lParam)->code) {		// just changed tabs
		GetDlgItem(IDC_DISABLE)->SetWindowText((((CViewPropertyPage*)m_PropSheet.GetActivePage())->IsEnabled() ? "Disable" : "Enable") + CString(" page controls"));
		return TRUE;
	}
	
	return CPropPgFormView::OnNotify(wParam, lParam, pResult);
}

void CMyFormView::OnCenter() 
{
	m_PropSheet.CenterControls(((CButton*)GetDlgItem(IDC_CENTER))->GetCheck());
}

void CMyFormView::OnAllowPageChange() 
{
	m_PropSheet.AllowPageChange(((CButton*)GetDlgItem(IDC_ALLOW_PAGE_CHANGE))->GetCheck());
}

