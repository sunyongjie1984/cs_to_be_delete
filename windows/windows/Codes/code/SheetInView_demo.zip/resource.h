//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SheetInView.rc
//
#define IDD_ABOUTBOX                    100
#define IDS_PROPSHT_CAPTION             102
#define IDD_PROPPAGE1                   103
#define IDD_PROPPAGE2                   104
#define IDD_PROPPAGE3                   105
#define IDR_MAINFRAME                   128
#define IDR_SHEETITYPE                  129
#define IDD_VIEW_DLG                    130
#define IDC_RESIZE_FRAME                1001
#define ID_TEST                         1005
#define IDC_CLOSE                       1007
#define IDC_DISABLE                     1008
#define IDC_OFFSET                      1009
#define IDC_CENTER                      1010
#define IDC_ALLOW_PAGE_CHANGE           1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
