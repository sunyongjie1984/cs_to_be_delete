// EZMenuTest.h : main header file for the EZMENUTEST application
//

#if !defined(AFX_EZMENUTEST_H__916EB6E7_9C94_11D1_9D77_8FF0D684A318__INCLUDED_)
#define AFX_EZMENUTEST_H__916EB6E7_9C94_11D1_9D77_8FF0D684A318__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CEZMenuTestApp:
// See EZMenuTest.cpp for the implementation of this class
//

class CEZMenuTestApp : public CWinApp
{
public:
	CEZMenuTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEZMenuTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CEZMenuTestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EZMENUTEST_H__916EB6E7_9C94_11D1_9D77_8FF0D684A318__INCLUDED_)
