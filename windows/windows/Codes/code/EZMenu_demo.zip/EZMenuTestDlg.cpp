// EZMenuTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EZMenuTest.h"
#include "EZMenuTestDlg.h"
#include "EZMenu.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEZMenuTestDlg dialog

CEZMenuTestDlg::CEZMenuTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEZMenuTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEZMenuTestDlg)
	m_bLargeIcons = FALSE;
	m_bProgressbar = FALSE;
	m_nProgress = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_bLargeIcons=m_bProgressbar=FALSE;
	m_nProgress=50;
}

void CEZMenuTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEZMenuTestDlg)
	DDX_Check(pDX, IDC_CHECK1, m_bLargeIcons);
	DDX_Check(pDX, IDC_CHECK2, m_bProgressbar);
	DDX_Text(pDX, IDC_EDIT1, m_nProgress);
	DDV_MinMaxInt(pDX, m_nProgress, 0, 100);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CEZMenuTestDlg, CDialog)
	//{{AFX_MSG_MAP(CEZMenuTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEZMenuTestDlg message handlers

BOOL CEZMenuTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CEZMenuTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEZMenuTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEZMenuTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CEZMenuTestDlg::OnButton1() 
{
	
	UpdateData(TRUE);	
	CEZMenu ezmenu;
	CMenu menu;
	menu.LoadMenu(IDR_MENU1);
	ezmenu.Attach(menu.GetSubMenu(0)->GetSafeHmenu());
	CBitmap bmp;
	bmp.LoadBitmap(IDB_MENU_TITLE/*The title bitmap*/);
	ezmenu.SetTotalItems(6);
	ezmenu.SetMenuBitmap((HBITMAP)bmp.Detach());
	ezmenu.SetBitmapDimension(CSize(20,94));
	ezmenu.SetLargeIcon(m_bLargeIcons);
	ezmenu.SetExtensionColor(RGB(255,255,50));
	CSize szIcon=m_bLargeIcons?CSize(32,32):CSize(16,16);
	HICON hItemIconLarge=(HICON)::LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON2),IMAGE_ICON,szIcon.cx,szIcon.cy,LR_DEFAULTCOLOR);
	HICON hItemIconSmall=(HICON)::LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON3),IMAGE_ICON,szIcon.cx,szIcon.cy,LR_DEFAULTCOLOR);;
	for(int i=0;i<5;++i)
	{
		LPEZMENUITEMDATA lpez=new CEZMenuItemData;
		if(i==0 && m_bProgressbar)
		{
			lpez->bProgress=TRUE;
			lpez->nProgress=m_nProgress;
			lpez->bChecked=TRUE;
			lpez->strItemText="Check,Progress";				
			
		}
		else
		{
			lpez->hItemIconLarge=hItemIconLarge;
			lpez->hItemIconSmall=hItemIconSmall;
			lpez->strItemText.Format("%s%d","Item-",i);
		}
		ezmenu.InsertOwnerDrawnMenuItem(ID_EZMENU_ITEMS+i,lpez);
	}
	ezmenu.RemoveMenu(ID_EZMENUITEMTEMP,MF_BYCOMMAND);
	LPEZMENUITEMDATA lpez=new CEZMenuItemData;
	lpez->bSeperator=TRUE;
	ezmenu.InsertOwnerDrawnMenuItem(ID_EZMENU_ITEMS+6,lpez,1);
	CPoint mouse;
	::GetCursorPos(&mouse);
	ezmenu.TrackPopupMenu(TPM_RIGHTALIGN,mouse.x,mouse.y,this);
}



