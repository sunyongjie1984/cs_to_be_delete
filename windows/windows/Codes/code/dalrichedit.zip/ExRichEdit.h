// ExRichEdit.h : main header file for the EXRICHEDIT application
//

#if !defined(AFX_EXRICHEDIT_H__60815083_AA8B_11D2_9D7B_00207415044C__INCLUDED_)
#define AFX_EXRICHEDIT_H__60815083_AA8B_11D2_9D7B_00207415044C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CExRichEditApp:
// See ExRichEdit.cpp for the implementation of this class
//

class CExRichEditApp : public CWinApp
{
public:
	CExRichEditApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExRichEditApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CExRichEditApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXRICHEDIT_H__60815083_AA8B_11D2_9D7B_00207415044C__INCLUDED_)
