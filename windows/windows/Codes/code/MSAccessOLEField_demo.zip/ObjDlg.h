#if !defined(AFX_OBJDLG_H__FDF05422_DB8A_11D0_B8EE_0020AF233A70__INCLUDED_)
#define AFX_OBJDLG_H__FDF05422_DB8A_11D0_B8EE_0020AF233A70__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ObjDlg.h : header file
//

#include "ObjNameSet.h"

/////////////////////////////////////////////////////////////////////////////
// CObjDlg dialog


class CObjDlg : public CDialog
{
// Construction
public:
	CObjNameSet * m_pSet;
	CObjDlg(CObjNameSet * pSet, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CObjDlg)
	enum { IDD = IDD_OBJDLG };
	CString	m_ObjectName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CObjDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CObjDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OBJDLG_H__FDF05422_DB8A_11D0_B8EE_0020AF233A70__INCLUDED_)
