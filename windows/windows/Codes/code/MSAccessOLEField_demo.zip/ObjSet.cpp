// ObjSet.cpp : implementation file
//

#include "stdafx.h"
#include "contain.h"
#include "ObjSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CObjectSet

IMPLEMENT_DYNAMIC(CObjectSet, CRecordset)

CObjectSet::CObjectSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CObjectSet)
	m_Name = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}


CString CObjectSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=OLE2BIN");
}

CString CObjectSet::GetDefaultSQL()
{
	return _T("[Object]");
}

void CObjectSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CObjectSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[Name]"), m_Name);
	RFX_LongBinary(pFX, _T("[OleObject]"), m_OleObject);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CObjectSet diagnostics

#ifdef _DEBUG
void CObjectSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CObjectSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
