// ObjNameSet.cpp : implementation file
//

#include "stdafx.h"
#include "contain.h"
#include "ObjNameSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CObjNameSet

IMPLEMENT_DYNAMIC(CObjNameSet, CRecordset)

CObjNameSet::CObjNameSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CObjNameSet)
	m_Name = _T("");
	m_nFields = 1;
	//}}AFX_FIELD_INIT
	m_nDefaultType = forwardOnly;
}


CString CObjNameSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=OLE2BIN");
}

CString CObjNameSet::GetDefaultSQL()
{
	return _T("[Object]");
}

void CObjNameSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CObjNameSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[Name]"), m_Name);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CObjNameSet diagnostics

#ifdef _DEBUG
void CObjNameSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CObjNameSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
