//----------------------------------------
// (c) Reliable Software 1997
//----------------------------------------
#ifndef _com_H_INCLUDED
#define _com_H_INCLUDED

#include <windows.h>
#include <objbase.h>

class UseCom
{
public:
    UseCom ()
    {
        HRESULT err = CoInitialize (0);
        if (err != S_OK)
            throw "Couldn't initialize COM";
    }
    ~UseCom ()
    {
        CoUninitialize ();
    }
};


#endif // _com_H_INCLUDED
