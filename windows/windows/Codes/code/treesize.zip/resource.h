//----------------------------------------
// (c) Reliable Software 1997
//----------------------------------------
#ifndef _RESOURCE_H_INCLUDED
#define _RESOURCE_H_INCLUDED

#define IDC_STATIC             -1

#define DIALOG_MAIN           200

#define TREESIZER_ICON         300

#define IDC_PATHNAME	100
#define IDC_BROWSE		101
#define IDC_CALCULATE	102
#define IDC_RESULT		106
#define IDC_EXIT		107
#define IDC_NEW			108


#endif // _RESOURCE_H_INCLUDED






