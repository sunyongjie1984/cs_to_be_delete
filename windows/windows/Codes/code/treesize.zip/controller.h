//----------------------------------------
// (c) Reliable Software 1997
//----------------------------------------
#ifndef _controller_H_INCLUDED
#define _controller_H_INCLUDED

#include <windows.h>
#include <strstrea.h>
#include "controls.h"
#include "com.h"

class Controller
{
public:
    Controller(HWND hwnd);
    void Command (HWND hwnd, int controlID, int command);
	ULONG CalculateFolderSize(char const * folderName);
private:
	void BeginNewCalculation();
	void CreateResultString(ULONG size, ostrstream & ostr);

	UseCom		_uc;
	HWND		_hwnd;

    Edit        _pathField;
    Button      _browse;
	Button		_calculate;
    Edit        _resultField;
    Button      _exit;
    Button      _clear;
};

#endif // _controller_H_INCLUDED
