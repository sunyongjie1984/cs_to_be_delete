//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CColorStaticST_demo.rc
//
#define IDD_CCOLORSTATICST_DEMO_DIALOG  102
#define IDD_ABOUTBOX                    103
#define IDR_MAINFRAME                   128
#define IDC_HAND                        140
#define IDC_TEXT1                       1000
#define IDC_CALLING                     1000
#define IDC_DANGER                      1001
#define IDC_STSIGN                      1002
#define IDC_DANGERCOUNT                 1003
#define IDB_ABOUT                       1004
#define IDC_EMAILLINK                   1012
#define IDC_HOMEPAGELINK                1013
#define IDC_VERSION                     1019
#define IDC_FRIENDS                     1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
