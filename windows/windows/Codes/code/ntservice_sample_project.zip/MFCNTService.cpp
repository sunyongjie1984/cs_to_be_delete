#include "stdafx.h"
#include "NTService.cpp"