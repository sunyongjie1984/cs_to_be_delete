#include <afxwin.h>
#include "NTService.h"