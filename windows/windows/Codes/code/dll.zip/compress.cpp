#include <windows.h>
#include <stdio.h>

#define MAIN        /* header has defining instances of globals */
#include "compress.h" /* contains the rest of the include file declarations */

#define ARGVAL() (*++(*argv) || (--argc && *++argv))
char suffix[] = SUFFIX ;          /* only used in this file */
//FILE *fp_src =NULL, *fp_zip =NULL;

int compress_file( char *file_src, char *file_zip )
{
	static COMP_PARAMS params;

	//if(should_compress(file_src) ==false) return 100;

	memset(&params, 0, sizeof(params));
	
	params.maxbits = DFLTBITS;
	params.block_compress = BLOCK_MASK;
    /* adjust for possible errors or conflicts */
    if(params.maxbits < MINBITS || params.maxbits > MAXBITS){
        //fprintf(stderr,"\n%s: illegal bit value, range = %d to %d\n",prog_name,MINBITS,MAXBITS);
        return -1;
    }
	params.nomagic =FALSE;
    if((params.fp_src =fopen(file_src, "rb")) ==NULL)
	{
		return -1;
	}
	if((params.fp_zip =fopen(file_zip, "wb")) ==NULL)
	{
		fclose(params.fp_src);
		return -1;
	}
	setvbuf(params.fp_src,params.xbuf,_IOFBF,XBUFSIZE);
	
	int ret =compress(&params);
	
	fclose(params.fp_src);
	fclose(params.fp_zip);

	return ret;
}

int uncompress_file( char *file_zip, char *file_src)
{
	COMP_PARAMS params;

	memset(&params, 0, sizeof(params));

	//if(should_compress(file_src) ==false) return 100;

	params.maxbits = DFLTBITS;
	params.block_compress = BLOCK_MASK;
    /* adjust for possible errors or conflicts */
    if(params.maxbits < MINBITS || params.maxbits > MAXBITS){
        //fprintf(stderr,"\n%s: illegal bit value, range = %d to %d\n",prog_name,MINBITS,MAXBITS);
        return -1;
    }
	params.nomagic =FALSE;
    if((params.fp_zip =fopen(file_zip, "rb")) ==NULL)
	{
		return -1;
	}
	if((params.fp_src =fopen(file_src, "wb")) ==NULL)
	{
		fclose(params.fp_zip);
		return -1;
	}
	setvbuf(params.fp_zip,params.zbuf,_IOFBF,ZBUFSIZE);
	if(!params.nomagic) 
	{             /* Check the magic number */
		if ((fgetc(params.fp_zip) != (magic_header[0] & 0xFF))
                     || (fgetc(params.fp_zip) != (magic_header[1] & 0xFF))) 
		{
                       //fprintf(stderr, "%s: not in compressed format\n",
                         //  ifname);
                       fclose(params.fp_src);
						fclose(params.fp_zip);
						return -1;
		}
		params.maxbits = fgetc(params.fp_zip);    /* set -b from file */
		params.block_compress = params.maxbits & BLOCK_MASK;
		params.maxbits &= BIT_MASK;
		if(params.maxbits > MAXBITS) 
		{
                        //fprintf(stderr,
                        //"%s: compressed with %d bits, can only handle %d bits\n",
                        //ifname, maxbits, MAXBITS);
                        fclose(params.fp_src);
						fclose(params.fp_zip);
						return -1;
		}
	}
	
	int ret =uncompress(&params);
	
	fclose(params.fp_src);
	fclose(params.fp_zip);
	
	return ret;
}

void Usage(int flag)
{
static char *keep2 =  "keep";
static char *keep3 =  "kill (erase)";
static char *on = "on";
static char *off = "off";

#ifdef DEBUG
//    fprintf(stderr,"Usage: %s [-cCdDf?hkKvV][-b maxbits][-Iinpath][-Ooutpath][filenames...]\n",
//        prog_name);
#else
//    fprintf(stderr,"Usage: %s [-cCdf?hkKvV][-b maxbits][-Iinpath][-Ooutpath][filenames...]\n",
//        prog_name);
#endif
    if (flag)
        return;
//    fprintf(stderr,"Argument Processing..case is significant:\n");
//    fprintf(stderr,"     MUST use '-' for switch character\nAll flags are optional.\n");
#ifdef DEBUG
//    fprintf(stderr,"     -D => debug; Keep file on error.\n");
//    fprintf(stderr,"     -V => print Version; debug verbose\n");
#else
//    fprintf(stderr,"     -V => print Version\n");
#endif
//    fprintf(stderr,"     -d => do_decomp default = %s\n",(do_decomp)?on:off);
//    fprintf(stderr,"     -v => verbose\n");
//    fprintf(stderr,"     -f => force overwrite of output file default = %s\n",
//        (force)?on:off);
//    fprintf(stderr,"     -n => no header: useful to uncompress old files\n");
//    fprintf(stderr,"     -c => cat all output to  default = %s\n",
//        (zcat_flg)?on:off);
//    fprintf(stderr,"     -C => generate output compatible with compress 2.0.\n");
//    fprintf(stderr,"     -k => %s input file, default == %s\n",(keep)?keep3:keep2,
//            (keep)?keep2:keep3);
//    fprintf(stderr,"     -K => %s output file on error, default == %s\n",
//            (keep_error)?keep3:keep2,(keep_error)?keep2:keep3);
//    fprintf(stderr,"     -b maxbits  => default == %d bits, max == %d bits\n",maxbits,MAXBITS);
//    fprintf(stderr,"     -I pathname => infile path  == %s\n",inpath);
//    fprintf(stderr,"     -O pathname => outfile path == %s\n",outpath);
//    fprintf(stderr,"     -? -h => help usage.\n");
}

/*
 * All previous #ifdef'ed code should return() a value.
 * If no other option is available, the following is the original code.
 * It not only reads from stderr (not a defined operation)
 * but it does so via an explicit read() call on file descriptor 2!
 * So much for portability.                    -Dal
 */
/* Dal included code to use the MSC getche() but it crashes because of
   the freopening of . Have to use the cludge for MSC. This function is
   included so that others who have problems with the keyboard read can
   change this function for their system.  DjG
 */

char get_one()
/*
 * get a single character, with echo.
 */
{
    char tmp[2];
    int fd;

#ifdef SOZOBON
    return(0x7F & getche());
}
#else
#   ifdef MINIX
            fd = open("/dev/tty", 0);   /* open the tty directly */
#   else
            fd = fileno(stderr);             /* read from stderr */
#   endif
        read(fd, tmp, 2);
        while (tmp[1] != '\n') {
                if (read(fd, tmp+1, 1) < 0) {   /* Ack! */
                        perror("stderr");
                        break;
                }
        }
    return(tmp[0]);
}
#endif

void writeerr()
{
    perror ( ofname );
    if (!zcat_flg && !keep_error){
        //fclose(stdout);
        unlink ( ofname );
    }
    exit ( 1 );
}

#ifndef NOSIGNAL
/*
 * This routine returns 1 if we are running in the foreground and stderr
 * is a tty.
 */
int foreground()
{
    if(bgnd_flag) { /* background? */
        return(0);
    }
    else {            /* foreground */
        if(isatty(2)) {     /* and stderr is a tty */
            return(1);
        } else {
            return(0);
        }
    }
}
#endif

void prratio(FILE *stream, long int num, long int den)
{
    register int q;         /* Doesn't need to be long */

    if(num > 214748L) {     /* 2147483647/10000 */
        q = (int) (num / (den / 10000L));
    }
    else {
        q = (int) (10000L * num / den);     /* Long calculations, though */
    }
    if (q < 0) {
        putc('-', stream);
        q = -q;
    }
    fprintf(stream, "%d.%02d%%", q / 100, q % 100);
}


int check_error()     /* returning OK continues with processing next file */
{
    switch(exit_stat) {
  case OK:
    return (OK);
  case NOMEM:
    if (do_decomp)
        fprintf(stderr,"%s: not enough memory to decompress '%s'.\n", prog_name, ifname);
    else
        fprintf(stderr,"%s: not enough memory to compress '%s'.\n", prog_name, ifname);
    break;
    /* return(OK); */   /* DjG removed causes problems */
  case SIGNAL_ERROR:
    fprintf(stderr,"%s: error setting signal interupt.\n",prog_name);
    exit(ERROR);
    break;
  case READERR:
    fprintf(stderr,"%s: read error on input '%s'.\n", prog_name, ifname);
    break;
  case WRITEERR:
    fprintf(stderr,"%s: write error on output '%s'.\n", prog_name, ofname);
    break;
   case TOKTOOBIG:
    fprintf(stderr,"%s: token too long in '%s'. Failed on realloc().\n", prog_name, ifname);
    break;
  case INFILEBAD:
    fprintf(stderr, "%s: '%s' in unknown compressed format.\n", prog_name, ifname);
    break;
 case CODEBAD:
    fprintf(stderr,"%s: file token bad in '%s'.\n", prog_name,ifname);
    break;
 case TABLEBAD:
    fprintf(stderr,"%s: internal error -- tables corrupted.\n", prog_name);
    break;
  case NOTOPENED:
    fprintf(stderr,"%s: could not open output file %s\n",prog_name,ofname);
    exit(ERROR);
    break;
  case NOSAVING:
    if (force)
        exit_stat = OK;
    return (OK);
  default:
    fprintf(stderr,"%s: internal error -- illegal return value = %d.\n", prog_name,exit_stat);
  }
  if (!zcat_flg && !keep_error){
        //fclose(stdout);         /* won't get here without an error */
        unlink ( ofname );
    }
  exit(exit_stat);
  return(ERROR);
}
