// des_dll.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "des_dll.h"
#include "des.h"

unsigned char des_key[8];

#define DEFAULT_KEY	"&@$+/;f`"

int set_des_key(char *key)
{
	memset(des_key, 0, sizeof(des_key));
	strncpy((char *)des_key, key, sizeof(des_key)-1);
	
	return 0;
}

int encrypt_file(char *file_src, char *file_crypt)
{
	DES des;
	FILE *fp_in, *fp_out;
	unsigned char buf[4097];
	int len;
	
	if(des_key[0] ==0) memcpy(des_key, DEFAULT_KEY, 8);
	
	if((fp_in =fopen(file_src, "rb")) ==NULL)
		return -1;
	if((fp_out =fopen(file_crypt, "wb")) ==NULL)
	{
		fclose(fp_in);
		return -1;
	}
	while(!feof(fp_in))
	{
		memset(buf, 0, sizeof(buf));
		if((len =fread(buf, 1, sizeof(buf)-1, fp_in)) <=0) break;
		des.encrypt(des_key, buf, len/8);
		fwrite(buf, 1, len, fp_out);
	}
	fclose(fp_in);
	fclose(fp_out);

	return 0;
}

int decrypt_file(char *file_crypt, char *file_src)
{
	DES des;
	FILE *fp_in, *fp_out;
	unsigned char buf[4096];
	int len;
	
	if(des_key[0] ==0) memcpy(des_key, DEFAULT_KEY, 8);

	if((fp_in =fopen(file_crypt, "rb")) ==NULL)
		return -1;
	if((fp_out =fopen(file_src, "wb")) ==NULL)
	{
		fclose(fp_in);
		return -1;
	}
	while(!feof(fp_in))
	{
		memset(buf, 0, sizeof(buf));
		if((len =fread(buf, 1, sizeof(buf), fp_in)) <=0) break;
		des.decrypt(des_key, buf, len/8);
		fwrite(buf, 1, len, fp_out);
	}
	fclose(fp_in);
	fclose(fp_out);
	
	return 0;
}
