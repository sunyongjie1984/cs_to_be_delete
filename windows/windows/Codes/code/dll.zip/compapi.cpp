#include <windows.h>
#include <stdio.h>

#include "compress.h" /* contains the rest of the include file declarations */

//int size;
//static HASH hashsize;
//static int  bits;

/*
 * The following two parameter tables are the hash table sizes and
 * maximum code values for various code bit-lengths.  The requirements
 * are that Hashsize[n] must be a prime number and Maxcode[n] must be less
 * than Maxhash[n].  Table occupancy factor is (Maxcode - 256)/Maxhash.
 * Note:  I am using a lower Maxcode for 16-bit codes in order to
 * keep the hash table size less than 64k entries.
 */
CONST HASH hs[] = {
  0x13FF,       /* 12-bit codes, 75% occupancy */
  0x26C3,       /* 13-bit codes, 80% occupancy */
  0x4A1D,       /* 14-bit codes, 85% occupancy */
  0x8D0D,       /* 15-bit codes, 90% occupancy */
  0xFFD9        /* 16-bit codes, 94% occupancy, 6% of code values unused */
};
#define Hashsize(maxb) (hs[(maxb) -MINBITS])

CONST INTCODE mc[] = {
  0x0FFF,       /* 12-bit codes */
  0x1FFF,       /* 13-bit codes */
  0x3FFF,       /* 14-bit codes */
  0x7FFF,       /* 15-bit codes */
  0xEFFF        /* 16-bit codes, 6% of code values unused */
};
#define Maxcode(maxb) (mc[(maxb) -MINBITS])

#ifdef __STDC__
#ifdef DEBUG
#define allocx(type, ptr, size) \
    (((ptr) = (type FAR *) emalloc((unsigned int)(size),sizeof(type))) == NULLPTR(type) \
    ?   (/*fprintf(stderr,"%s: "#ptr" -- ", prog_name), */NOMEM) : OK \
    )
#else
#define allocx(type,ptr,size) \
    (((ptr) = (type FAR *) emalloc((unsigned int)(size),sizeof(type))) == NULLPTR(type) \
    ? NOMEM : OK \
    )
#endif
#else
#define allocx(type,ptr,size) \
    (((ptr) = (type FAR *) emalloc((unsigned int)(size),sizeof(type))) == NULLPTR(type) \
    ? NOMEM : OK \
    )
#endif

#define free_array(type,ptr,offset) \
    if (ptr != NULLPTR(type)) { \
        efree((ALLOCTYPE FAR *)((ptr) + (offset))); \
        (ptr) = NULLPTR(type); \
    }

  /*
   * Macro to allocate new memory to a pointer with an offset value.
   */
#define alloc_array(type, ptr, size, offset) \
    ( allocx(type, ptr, (size) - (offset)) != OK \
      ? NOMEM \
      : (((ptr) -= (offset)), OK) \
    )

static char FAR *sfx = NULLPTR(char) ;
#define suffix(code)     sfx[code]


#if (SPLIT_PFX)
  static CODE FAR *pfx[2] = {NULLPTR(CODE), NULLPTR(CODE)};
#else
  static CODE FAR *pfx = NULLPTR(CODE);
#endif


#if (SPLIT_HT)
  static CODE FAR *ht[2] = {NULLPTR(CODE),NULLPTR(CODE)};
#else
  static CODE FAR *ht = NULLPTR(CODE);
#endif


int alloc_tables(INTCODE maxcode, HASH hashsize, COMP_PARAMS *pparams)
{
    //static INTCODE oldmaxcode;
    //static HASH oldhashsize;

  if (hashsize > pparams->oldhashsize) {
#if (SPLIT_HT)
      free_array(CODE,ht[1], 0);
      free_array(CODE,ht[0], 0);
#else
      free_array(CODE,ht, 0);
#endif
    pparams->oldhashsize = 0;
  }

    if (maxcode > pparams->oldmaxcode) {
#if (SPLIT_PFX)
        free_array(CODE,pfx[1], 128);
        free_array(CODE,pfx[0], 128);
#else
        free_array(CODE,pfx, 256);
#endif
        free_array(char,sfx, 256);

        if (   alloc_array(char, sfx, maxcode + 1, 256)
#if (SPLIT_PFX)
            || alloc_array(CODE, pfx[0], (maxcode + 1) / 2, 128)
            || alloc_array(CODE, pfx[1], (maxcode + 1) / 2, 128)
#else
            || alloc_array(CODE, pfx, (maxcode + 1), 256)
#endif
        ) {
            pparams->oldmaxcode = 0;
            exit_stat = NOMEM;
            return(NOMEM);
        }
        pparams->oldmaxcode = maxcode;
    }
    if (hashsize > pparams->oldhashsize) {
        if (
#if (SPLIT_HT)
            alloc_array(CODE, ht[0], (hashsize / 2) + 1, 0)
            || alloc_array(CODE, ht[1], hashsize / 2, 0)
#else
            alloc_array(CODE, ht, hashsize, 0)
#endif
        ) {
            pparams->oldhashsize = 0;
            exit_stat = NOMEM;
            return(NOMEM);
        }
        pparams->oldhashsize = hashsize;
    }
    return (OK);
}

#if (SPLIT_PFX)
    /*
     * We have to split pfx[] table in half,
     * because it's potentially larger than 64k bytes.
     */
#define prefix(code)   (pfx[(code) & 1][(code) >> 1])
#else
    /*
     * Then pfx[] can't be larger than 64k bytes,
     * or we don't care if it is, so we don't split.
     */
#define prefix(code) (pfx[code])
#endif


/* The initializing of the tables can be done quicker with memset() */
/* but this way is portable through out the memory models.          */
/* If you use Microsoft halloc() to allocate the arrays, then       */
/* include the pragma #pragma function(memset)  and make sure that  */
/* the length of the memory block is not greater than 64K.          */
/* This also means that you MUST compile in a model that makes the  */
/* default pointers to be far pointers (compact or large models).   */
/* See the file COMPUSI.DOS to modify function emalloc().           */

#if (SPLIT_HT)
    /*
     * We have to split ht[] hash table in half,
     * because it's potentially larger than 64k bytes.
     */
#define probe(hash)    (ht[(hash) & 1][(hash) >> 1])
#define init_tables() \
    { \
      hash = pparams->hashsize >> 1; \
      ht[0][hash] = 0; \
      while (hash--) ht[0][hash] = ht[1][hash] = 0; \
      pparams->highcode = ~(~(INTCODE)0 << (pparams->bits = INITBITS)); \
      pparams->nextfree = (pparams->block_compress ? FIRSTFREE : 256); \
    }

#else

    /*
     * Then ht[] can't be larger than 64k bytes,
     * or we don't care if it is, so we don't split.
     */
#define probe(hash) (ht[hash])
#define init_tables() \
    { \
      hash = pparams->hashsize; \
      while (hash--) ht[hash] = 0; \
      pparams->highcode = ~(~(INTCODE)0 << (pparams->bits = INITBITS)); \
      pparams->nextfree = (pparams->block_compress ? FIRSTFREE : 256); \
    }

#endif

#ifdef COMP40
/* table clear for block compress */
/* this is for adaptive reset present in version 4.0 joe release */
/* DjG, sets it up and returns TRUE to compress and FALSE to not compress */
int cl_block (COMP_PARAMS *pparams)     
{
    register long int rat;

    checkpoint = pparams->in_count + CHECK_GAP;
#ifdef DEBUG
	if ( debug ) {
        //fprintf ( stderr, "count: %ld, ratio: ", pparams->in_count );
        //prratio ( stderr, pparams->in_count, pparams->bytes_out );
		//fprintf ( stderr, "\n");
	}
#endif

    if(pparams->in_count > 0x007fffff) {	/* shift will overflow */
        rat = pparams->bytes_out >> 8;
        if(rat == 0)       /* Don't divide by zero */
            rat = 0x7fffffff;
        else
            rat = pparams->in_count / rat;
    }
    else
        rat = (pparams->in_count << 8) / pparams->bytes_out;  /* 8 fractional bits */

    if ( rat > pparams->ratio ){
        pparams->ratio = rat;
        return FALSE;
    }
    else {
        pparams->ratio = 0;
#ifdef DEBUG
        //if(debug)
    	//	fprintf ( stderr, "clear\n" );
#endif
        return TRUE;    /* clear the table */
    }
    return FALSE; /* don't clear the table */
}
#endif

/*
 * compress  to 
 *
 */
int compress(COMP_PARAMS *pparams)
{
    int c,adjbits;
    register HASH hash;
    register INTCODE code;
    HASH hashf[256];

    pparams->maxcode = Maxcode(pparams->maxbits);
    pparams->hashsize = Hashsize(pparams->maxbits);

#ifdef COMP40
/* Only needed for adaptive reset */
    checkpoint = CHECK_GAP;
    pparams->ratio = 0;
#endif

    adjbits = pparams->maxbits -10;
    for (c = 256; --c >= 0; ){
        hashf[c] = ((( c &0x7) << 7) ^ c) << adjbits;
    }
    exit_stat = OK;
    if (alloc_tables(pparams->maxcode, pparams->hashsize, pparams))  /* exit_stat already set */
        return NOMEM;
    init_tables();
    /* if not zcat or filter */
    if(is_list && !zcat_flg) {  /* Open output file */
    //    if (freopen(ofname, WRITE_FILE_TYPE, fp_zip) == NULL) {
      //      exit_stat = NOTOPENED;
        //    return NOTOPENED;
        //}
        //if (!quiet)
          //  fprintf(stderr, "%s: ",ifname);
    }
    //setvbuf(stdout,zbuf,_IOFBF,ZBUFSIZE);
 /*
   * Check the input stream for previously seen strings.  We keep
   * adding characters to the previously seen prefix string until we
   * get a character which forms a new (unseen) string.  We then send
   * the code for the previously seen prefix string, and add the new
   * string to our tables.  The check for previous strings is done by
   * hashing.  If the code for the hash value is unused, then we have
   * a new string.  If the code is used, we check to see if the prefix
   * and suffix values match the current input; if so, we have found
   * a previously seen string.  Otherwise, we have a hash collision,
   * and we try secondary hash probes until we either find the current
   * string, or we find an unused entry (which indicates a new string).
   */
    if (!pparams->nomagic) {
        fputc(magic_header[0], pparams->fp_zip);
		fputc(magic_header[1], pparams->fp_zip);
        fputc((char)(pparams->maxbits | pparams->block_compress), pparams->fp_zip);
        if(ferror(pparams->fp_zip)){  /* check it on entry */
            exit_stat = WRITEERR;
            return WRITEERR;
        }
        pparams->bytes_out = 3L;     /* includes 3-byte header mojo */
    }
    else
        pparams->bytes_out = 0L;      /* no 3-byte header mojo */
    pparams->in_count = 1L;
    pparams->offset = 0;

    if ((c = fgetc(pparams->fp_src)) == EOF) {
        exit_stat = ferror(pparams->fp_src) ? READERR : OK;
        return exit_stat;
    }
    pparams->prefxcode = (INTCODE)c;

    while ((c = fgetc(pparams->fp_src)) != EOF) {
        pparams->in_count++;
        hash = pparams->prefxcode ^ hashf[c];
        /* I need to check that my hash value is within range
        * because my 16-bit hash table is smaller than 64k.
        */
        if (hash >= pparams->hashsize)
            hash -= pparams->hashsize;
        if ((code = (INTCODE)probe(hash)) != UNUSED) {
            if (suffix(code) != (char)c || (INTCODE)prefix(code) != pparams->prefxcode) {
            /* hashdelta is subtracted from hash on each iteration of
            * the following hash table search loop.  I compute it once
            * here to remove it from the loop.
            */
                HASH hashdelta = (0x120 - c) << (adjbits);
                do  {
                    /* rehash and keep looking */
                    assert(code >= FIRSTFREE && code <= pparams->maxcode);
                    if (hash >= hashdelta) hash -= hashdelta;
                        else hash += (pparams->hashsize - hashdelta);
                    assert(hash < pparams->hashsize);
                    if ((code = (INTCODE)probe(hash)) == UNUSED)
                        goto newcode;
                } while (suffix(code) != (char)c || (INTCODE)prefix(code) != pparams->prefxcode);
            }
            pparams->prefxcode = code;
        }
        else {
            newcode: {
                putcode(pparams->prefxcode, pparams->bits, pparams);
                code = pparams->nextfree;
                assert(hash < pparams->hashsize);
                assert(code >= FIRSTFREE);
                assert(code <= pparams->maxcode + 1);
                if (code <= pparams->maxcode) {
                    probe(hash) = (CODE)code;
                    prefix(code) = (CODE)pparams->prefxcode;
                    suffix(code) = (char)c;
                    if (code > pparams->highcode) {
                        pparams->highcode += code;
                        ++pparams->bits;
                    }
                    pparams->nextfree = code + 1;
                }
#ifdef COMP40
                else if (pparams->in_count >= checkpoint && pparams->block_compress ) {
                    if (cl_block(pparams)){
#else
                else if (pparams->block_compress){
#endif
                        putcode((INTCODE)c, pparams->bits, pparams);
                        putcode(CLEAR, pparams->bits, pparams);
                        init_tables();
                        if ((c = fgetc(pparams->fp_src)) == EOF)
                            break;
                        pparams->in_count++;
#ifdef COMP40
                    }
#endif
                }
                pparams->prefxcode = (INTCODE)c;
            }
        }
    }
    putcode(pparams->prefxcode, pparams->bits, pparams);
    putcode(CLEAR, 0, pparams);
    if (ferror(pparams->fp_zip)){ /* check it on exit */
        exit_stat = WRITEERR;
        return WRITEERR;
    }
    /*
     * Print out stats on stderr
     */
    if(zcat_flg == 0 && !quiet) {
#ifdef DEBUG
        //fprintf( stderr,
          //  "%ld chars in, (%ld bytes) out, compression factor: ",
            //pparams->in_count, pparams->bytes_out );
        //prratio( stderr, pparams->in_count, pparams->bytes_out );
        //fprintf( stderr, "\n");
        //fprintf( stderr, "\tCompression as in compact: " );
        //prratio( stderr, pparams->in_count-pparams->bytes_out, pparams->in_count );
        //fprintf( stderr, "\n");
        //fprintf( stderr, "\tLargest code (of last block) was %d (%d bits)\n",
          //  pparams->prefxcode - 1, bits );
#else
        //fprintf( stderr, "Compression: " );
        //prratio( stderr, pparams->in_count-pparams->bytes_out, pparams->in_count );
#endif /* DEBUG */
    }
    if(pparams->bytes_out > pparams->in_count)      /*  if no savings */
        exit_stat = NOSAVING;
    return exit_stat;
}

CONST UCHAR rmask[9] = {0x00, 0x01, 0x03, 0x07, 0x0f, 0x1f, 0x3f, 0x7f, 0xff};

void putcode(INTCODE code, int bits, COMP_PARAMS *pparams)
{
  register UCHAR *buf;
  register int shift;
	//static UCHAR outbuf[MAXBITS];

  if (bits != pparams->oldbits) {
    if (bits == 0) {
      /* bits == 0 means EOF, write the rest of the buffer. */
      if (pparams->offset > 0) {
          fwrite(pparams->outbuf,1,(pparams->offset +7) >> 3, pparams->fp_zip);
          pparams->bytes_out += ((pparams->offset +7) >> 3);
      }
      pparams->offset = 0;
      pparams->oldbits = 0;
      fflush(pparams->fp_zip);
      return;
    }
    else {
      /* Change the code size.  We must write the whole buffer,
       * because the expand side won't discover the size change
       * until after it has read a buffer full.
       */
      if (pparams->offset > 0) {
        fwrite(pparams->outbuf, 1, pparams->oldbits, pparams->fp_zip);
        pparams->bytes_out += pparams->oldbits;
        pparams->offset = 0;
      }
      pparams->oldbits = bits;
#ifdef DEBUG
      //if ( debug )
        //fprintf( stderr, "\nChange to %d bits\n", bits );
#endif /* DEBUG */
    }
  }
  /*  Get to the first byte. */
  buf = pparams->outbuf + ((shift = pparams->offset) >> 3);
  if ((shift &= 7) != 0) {
    *(buf) |= (*buf & rmask[shift]) | (UCHAR)(code << shift);
    *(++buf) = (UCHAR)(code >> (8 - shift));
    if (bits + shift > 16)
        *(++buf) = (UCHAR)(code >> (16 - shift));
  }
  else {
    /* Special case for fast execution */
    *(buf) = (UCHAR)code;
    *(++buf) = (UCHAR)(code >> 8);
  }
  if ((pparams->offset += bits) == (bits << 3)) {
    pparams->bytes_out += bits;
    fwrite(pparams->outbuf,1,bits,pparams->fp_zip);
    pparams->offset = 0;
  }
  return;
}

int nextcode(INTCODE *codeptr, COMP_PARAMS *pparams)
/* Get the next code from input and put it in *codeptr.
 * Return (TRUE) on success, or return (FALSE) on end-of-file.
 * Adapted from COMPRESS V4.0.
 */
{
  register INTCODE code;
  //static int size;
  //static UCHAR inbuf[MAXBITS];
  register int shift;
  UCHAR *bp;

  /* If the next entry is a different bit-size than the preceeding one
   * then we must adjust the size and scrap the old buffer.
   */
  if (pparams->prevbits != pparams->bits) {
    pparams->prevbits = pparams->bits;
    pparams->size = 0;
  }
  /* If we can't read another code from the buffer, then refill it.
   */
  if (pparams->size - (shift = pparams->offset) < pparams->bits) {
    /* Read more input and convert size from # of bytes to # of bits */
    if ((pparams->size = fread(pparams->inbuf, 1, pparams->bits, pparams->fp_zip) << 3) <= 0 || ferror(pparams->fp_zip))
      return(NO);
    pparams->offset = shift = 0;
  }
  /* Get to the first byte. */
  bp = pparams->inbuf + (shift >> 3);
  /* Get first part (low order bits) */
  code = (*bp++ >> (shift &= 7));
  /* high order bits. */
  code |= *bp++ << (shift = 8 - shift);
  if ((shift += 8) < pparams->bits) code |= *bp << shift;
  *codeptr = code & pparams->highcode;
  pparams->offset += pparams->bits;
  return (TRUE);
}

int uncompress(COMP_PARAMS *pparams)
{
  register int i;
  register INTCODE code;
  char sufxchar;
  INTCODE savecode;
  FLAG fulltable, cleartable;
  static char *token= NULL;         /* String buffer to build token */
  static int maxtoklen = MAXTOKLEN;

  exit_stat = OK;

  /* Initialze the token buffer. */
    if (token == NULL && (token = (char*)malloc(maxtoklen)) == NULL) {
    	    exit_stat = NOMEM;
    	    return NOMEM;
	}

  if (alloc_tables(pparams->maxcode = ~(~(INTCODE)0 << pparams->maxbits),0, pparams)) /* exit_stat already set */
     return NOMEM;

    /* if not zcat or filter */
    if(is_list && !zcat_flg) {  /* Open output file */
        //if (freopen(ofname, WRITE_FILE_TYPE, pparams->fp_src) == NULL) {
          //  exit_stat = NOTOPENED;
            //return NOTOPENED;
        //}
        //if (!quiet)
          //  fprintf(stderr, "%s: ",ifname);
        //setvbuf(pparams->fp_src,xbuf,_IOFBF,XBUFSIZE);
    }
  cleartable = TRUE;
  savecode = CLEAR;
  pparams->offset = 0;
  do {
    if ((code = savecode) == CLEAR && cleartable) {
      pparams->highcode = ~(~(INTCODE)0 << (pparams->bits = INITBITS));
      fulltable = FALSE;
      pparams->nextfree = (cleartable = pparams->block_compress) == FALSE ? 256 : FIRSTFREE;
      if (!nextcode(&pparams->prefxcode, pparams))
        break;
      fputc((sufxchar = (char)pparams->prefxcode), pparams->fp_src);
      continue;
    }
    i = 0;
    if (code >= pparams->nextfree && !fulltable) {
      if (code != pparams->nextfree){
        exit_stat = CODEBAD;
        return CODEBAD ;     /* Non-existant code */
    }
      /* Special case for sequence KwKwK (see text of article)         */
      code = pparams->prefxcode;
      token[i++] = sufxchar;
    }
    /* Build the token string in reverse order by chasing down through
     * successive prefix tokens of the current token.  Then output it.
     */
    while (code >= 256) {
#     ifdef DEBUG
        /* These are checks to ease paranoia. Prefix codes must decrease
         * monotonically, otherwise we must have corrupt tables.  We can
         * also check that we haven't overrun the token buffer.
         */
        if (code <= (INTCODE)prefix(code)){
            exit_stat= TABLEBAD;
            return TABLEBAD;
        }
#     endif
      if (i >= maxtoklen) {
        maxtoklen *= 2;   /* double the size of the token buffer */
        if ((token = (char *)realloc(token, maxtoklen)) == NULL) {
          exit_stat = TOKTOOBIG;
          return TOKTOOBIG;
        }
      }
      token[i++] = suffix(code);
      code = (INTCODE)prefix(code);
    }
    fputc(sufxchar = (char)code, pparams->fp_src);
    while (--i >= 0)
        fputc(token[i], pparams->fp_src);
    if (ferror(pparams->fp_src)) {
        exit_stat = WRITEERR;
        return WRITEERR;
    }
    /* If table isn't full, add new token code to the table with
     * codeprefix and codesuffix, and remember current code.
     */
    if (!fulltable) {
      code = pparams->nextfree;
      assert(256 <= code && code <= pparams->maxcode);
      prefix(code) = (CODE)pparams->prefxcode;
      suffix(code) = sufxchar;
      pparams->prefxcode = savecode;
      if (code++ == pparams->highcode) {
        if (pparams->highcode >= pparams->maxcode) {
          fulltable = TRUE;
          --code;
        }
        else {
          ++pparams->bits;
          pparams->highcode += code;           /* pparams->nextfree == pparams->highcode + 1 */
        }
      }
      pparams->nextfree = code;
    }
  } while (nextcode(&savecode, pparams));
  exit_stat = (ferror(pparams->fp_zip))? READERR : OK;
  return exit_stat;
}

