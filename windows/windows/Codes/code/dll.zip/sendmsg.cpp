#include "stdafx.h"

/*#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT
*/
BOOL sendmsg(char *msg1, char *msg2, char *msg3)
{
	BOOL vret;
	/*COleDispatchDriver odriver;
	
	if(odriver.CreateDispatch("aastring.Document") ==0) return FALSE;
	static BYTE parms[] =VTS_BSTR VTS_BSTR VTS_BSTR;
	odriver.InvokeHelper(0x08, DISPATCH_METHOD, VT_BOOL, &vret, parms, msg1, msg2, msg3);
	odriver.ReleaseDispatch();
	*/
	return vret;
}
