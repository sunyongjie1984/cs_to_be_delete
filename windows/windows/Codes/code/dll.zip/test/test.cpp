// test.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include <time.h>

extern int compress_file(char *, char *);
extern int uncompress_file(char *, char *);

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
/*	typedef	int (*COMPFUNC)(char *, char *);
 	COMPFUNC compress, uncompress;

	HINSTANCE hModule =LoadLibrary("compress.dll");
	if(!hModule) return -1;
	if((compress =(COMPFUNC)GetProcAddress(hModule, "compress")) ==NULL)
	{
		FreeLibrary(hModule);
		return -1;
	}
	if((uncompress =(COMPFUNC)GetProcAddress(hModule, "uncompress")) ==NULL)
	{
		FreeLibrary(hModule);
		return -1;
	}
	int ret;
	ret =(*compress)("readme", "readme.Z");
	ret =(*uncompress)("readme.Z", "readme.1");

	FreeLibrary(hModule);
*/
	int ret;
	time_t t1, t2;
	char buf[100];
	time(&t1);
	ret =compress_file("readme", "readme.Z");
	time(&t2);
	wsprintf(buf, "compress: ret =%d, time =%d", ret, t2-t1);
	MessageBox(NULL, buf, "test", MB_OK);
	ret =uncompress_file("readme.Z", "readme.1");
	time(&t1);
	wsprintf(buf, "uncompress: ret =%d, time =%d", ret, t1-t2);
	MessageBox(NULL, buf, "test", MB_OK);
	return 0;
}
