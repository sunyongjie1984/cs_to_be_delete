#include "stdafx.h"
#include "compress.h"

UCHAR magic_header[] = { 0x1F,0x9D };  /* 1F 9D */

char rcs_ident[] = TITLE;

int keep = KEEPFLAG;            /* True = don't kill file */
int keep_error = FALSE;     /* True = keep output file even if error exist */
//char *prog_name;
char endchar[1];
//char xbuf[XBUFSIZE];
//char zbuf[ZBUFSIZE];

#ifdef MSDOS
char separator[] = "\\";
#else
char separator[] = "/";
#endif
/*
 * block compression parameters -- after all codes are used up,
 * and compression rate changes, start over.
 */
//int block_compress = BLOCK_MASK;
#ifdef COMP40
long int ratio = 0L;
long checkpoint = CHECK_GAP;
#endif

/* force the overwrite */
int force = 0;

#ifdef DEBUG
int verbose = VERBOSE;
int debug = FALSE;
#endif /* DEBUG */

#ifndef NOSIGNAL
SIGTYPE (*bgnd_flag)();
#endif

