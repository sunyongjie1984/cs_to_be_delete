//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MIDIGenerator.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_ABOUTBOX_OLD                101
#define IDD_ABOUTBOX1                   102
#define IDR_MAINFRAME                   128
#define IDR_MIDIGETYPE                  129
#define IDD_INPUTDIALOG                 144
#define IDC_HYPERLINK                   170
#define IDC_ANIMATE1                    1074
#define IDC_EMAIL                       1075
#define IDC_HOMEPAGE                    1076
#define IDC_INPUTLINE1                  1080
#define IDC_INPUTLINE2                  1081
#define IDC_INPUTLINE3                  1082
#define IDC_PROMPT1                     1083
#define IDC_PROMPT2                     1084
#define IDC_PROMPT3                     1085
#define IDC_INPUTLINE4                  1088
#define IDC_PROMPT4                     1091
#define IDC_INPUTLINE5                  1093
#define IDC_PROMPT5                     1095
#define IDC_INPUTLINE6                  1097
#define IDC_PROMPT6                     1099
#define IDC_INPUTLINE7                  1101
#define IDC_PROMPT7                     1103
#define IDC_INPUTLINE8                  1105
#define IDC_PROMPT8                     1107
#define ID_BEARBEITEN_MIDIDATEIGENERIEREN 32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
