// GetLink.h : main header file for the GETLINK application
//

#if !defined(AFX_GETLINK_H__7ACE6FC7_80BD_11D3_90F9_00105AA6C48C__INCLUDED_)
#define AFX_GETLINK_H__7ACE6FC7_80BD_11D3_90F9_00105AA6C48C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CGetLinkApp:
// See GetLink.cpp for the implementation of this class
//

class CGetLinkApp : public CWinApp
{
public:
	CGetLinkApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGetLinkApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CGetLinkApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GETLINK_H__7ACE6FC7_80BD_11D3_90F9_00105AA6C48C__INCLUDED_)
