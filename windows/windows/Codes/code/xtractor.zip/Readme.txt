Build instructions:
  Basically, to build CD-DA X-Tractor, you'll need to build the DLL first,
and then the exe itself.  These instructions assume that you're using
GCC 2.95.2 (Mingw32), along with a few misc. unix-port utilities
(rm mainly) from the VirtUnix site:
  Switch to the akrip directory and run 'make'.  If it builds (should create
a dll and an import library), then switch back to the project's root
directory and run 'make' there.  That's all there is to it.


If you're using another compiler and would like to provide project/makefiles,
please feel free to contribute them.


Questions, comments, complaints, suggestions, etc... should be sent to
scsiprog@geocities.com.

-Andy Key
