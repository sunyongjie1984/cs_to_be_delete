/*
 * globals.h - Copyright (C) 1999,2000 Jay A. Key
 *
 * extern declarations for global variables used throughout the program
 *
 **********************************************************************
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */
#ifndef _GLOBALS_G_INC
#define _GLOBALS_G_INC

#include <windows.h>
#include "akrip/akrip32.h"
#include "bladedll.h"

typedef enum {
  NOENCODER=0,
  BLADE_ENC_DLL,
  LAME_ENC_DLL
} ENCODER;
#define MAXENCODER  LAME_ENC_DLL

extern int iMajorVer;
extern int iMinorVer;
extern unsigned char validFnameChar[256];
extern HINSTANCE ghInstance;
extern BOOL bAutoTOC;
extern BOOL bAutoCheck;
extern BOOL bHiColor;
extern CDLIST cdlist;
extern int cdlistIdx;
extern HCDROM hCD;
extern BYTE bReadType;
extern DWORD maxRip;
extern DWORD jitterCheck;
extern DWORD numOverlap;
extern DWORD readMode;
extern char szWavOutputDir[MAX_PATH+1];
extern char szMP3OutputDir[MAX_PATH+1];
extern BOOL bMP3;
extern BOOL bWavMirror;
extern HANDLE hBladeDll;
extern HANDLE hLameDll;
extern BEINITSTREAM   beInitStream;
extern BEENCODECHUNK  beEncodeChunk;
extern BEDEINITSTREAM beDeinitStream;
extern BECLOSESTREAM  beCloseStream;
extern BEVERSION      beVersion;
extern WORD wBitrate;
extern BOOL bCRC;
extern int  iNumEncoders;
extern BOOL bBladeAvail;
extern BOOL bLameAvail;
extern BOOL bID3;
extern BOOL bCopyright;
extern BOOL bPrivate;
extern BOOL bOriginal;
extern int iEncoder;
extern WORD wMaxBitrate;
extern BOOL bVBR;
extern BOOL bVBRHeader;
extern INT nVBRQuality;
extern MPEG_QUALITY nQuality;
extern WORD wMode;

extern ATOM atomBmpPanel;
extern char *szBmpPanel;
extern char szCDDBServer[81];
extern int iHTTPPort;
extern char szProxyAddr[81];
extern int iProxyPort;
extern BOOL bUseProxy;
extern BOOL bInCDDBQuery;
extern char szCGI[81];
extern BOOL bCDDB;
extern BOOL bRippingTracks;

#endif
