/*
 * outdlg.c - Copyright (C) 1999,2000 Jay A. Key
 *
 * Output options dialog for options property sheet.  Selection of 
 * output format (WAV/MP3), plus output directories are configured here.
 *
 **********************************************************************
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */
#include <windows.h>
#include <commctrl.h>
#include "resources.h"
#include "globals.h"

BOOL SelectDirectory( HWND hParent, LPTSTR lpszDir, int len, BOOL bAutoCreate );
BOOL DirExists( char *dir );

// save old settings for output dialog config
static BOOL bInInit = FALSE;
static char szTmpWavOutputDir[MAX_PATH+1];
static char szTmpMP3OutputDir[MAX_PATH+1];
static BOOL bMP3Tmp;
//static HWND hOutDlg;


/*
 * Called in response to PSN_KILLACTIVE.  Should validate all values in the
 * dialog, and save them to the temp variables.
 */
BOOL ValidateOutputDlg( HWND hWnd )
{
  // get the items from the text edits IDM_WAVDIR and IDM_MP3DIR
  if ( !DirExists( szTmpWavOutputDir ) )
    {
      MessageBox( hWnd, "The folder you have selected for WAV output does not exist, or is not accessible.", "Huh?!?", MB_APPLMODAL | MB_ICONERROR | MB_OK );
      return FALSE;
    }

  if ( !DirExists( szTmpMP3OutputDir ) )
    {
      MessageBox( hWnd, "The folder you have selected for MP3 output does not exist, or is not accessible.", "Huh?!?", MB_APPLMODAL | MB_ICONERROR | MB_OK );
      return FALSE;
    }

  bMP3Tmp = IsDlgButtonChecked( hWnd, IDRBN_MP3 );

  return TRUE;
}



/*
 * Called in response to PSN_SETACTIVE.  Sets dialog items with the values
 * from the temp variables.
 */
void ConfigureOutputDlg( HWND hWnd )
{
  bInInit = FALSE;

  // sets the dialog's items with the temporary values.
  SetDlgItemText( hWnd, IDE_WAVDIR, szTmpWavOutputDir );
  SetDlgItemText( hWnd, IDE_MP3DIR, szTmpMP3OutputDir );
  if ( bMP3Tmp && ( hBladeDll || hLameDll ) )
    {
      CheckDlgButton( hWnd, IDRBN_MP3, BST_CHECKED );
      CheckDlgButton( hWnd, IDRBN_WAV, BST_UNCHECKED );
    }
  else
    {
      CheckDlgButton( hWnd, IDRBN_WAV, BST_CHECKED );
      CheckDlgButton( hWnd, IDRBN_MP3, BST_UNCHECKED );
    }

  // if we have no encoders present, disable the radio button
  if ( !( hBladeDll || hLameDll ) )
    EnableWindow( GetDlgItem( hWnd, IDRBN_MP3 ), FALSE );

  // until the browse for output director dialog is done, just disable the
  // buttons
  //SendDlgItemMessage( hWnd, IDBN_BRWSEWAVDIR, WM_ENABLE, 0, 0L );
  //SendDlgItemMessage( hWnd, IDBN_BRWSEMP3DIR, WM_ENABLE, 0, 0L );

  bInInit = TRUE;
}


BOOL CALLBACK OutputDlgProc( HWND hWnd, UINT uMsg, WPARAM wParam,
			     LPARAM lParam )
{
  //  char buf[81];
  NMHDR *l = (NMHDR *)lParam;
  WORD wID;
  WORD wNotify;
  BOOL bChanged;

  switch( uMsg )
    {
    case WM_INITDIALOG:
      //hOutDlg = hWnd;
      break;

    case WM_COMMAND:
      wID = LOWORD( wParam );
      wNotify = HIWORD( wParam );
      bChanged = TRUE;
      switch( wID )
	{
	case IDE_WAVDIR:
	  if ( wNotify == EN_CHANGE )
	    GetDlgItemText( hWnd, IDE_WAVDIR, szTmpWavOutputDir, MAX_PATH+1 );
	  else
	    bChanged = FALSE;
	  break;

	case IDE_MP3DIR:
	  if ( wNotify == EN_CHANGE )
	    GetDlgItemText( hWnd, IDE_MP3DIR, szTmpMP3OutputDir, MAX_PATH+1 );
	  else
	    bChanged = FALSE;
	  break;

	case IDBN_BRWSEWAVDIR:
	  if ( SelectDirectory( hWnd, szTmpWavOutputDir, MAX_PATH + 1, TRUE ) )
	    SetDlgItemText( hWnd, IDE_WAVDIR, szTmpWavOutputDir );
	  else
	    bChanged = FALSE;
	  break;

	case IDBN_BRWSEMP3DIR:
	  if ( SelectDirectory( hWnd, szTmpMP3OutputDir, MAX_PATH + 1, TRUE ) )
	    SetDlgItemText( hWnd, IDE_MP3DIR, szTmpWavOutputDir );
	  else
	    bChanged = FALSE;
	  break;

	case IDRBN_MP3:
	  bMP3Tmp = TRUE;
	  break;

	case IDRBN_WAV:
	  bMP3Tmp = FALSE;
	  break;

	default:
	  break;
	}
      if ( bInInit && bChanged )
	SendMessage( (HWND)GetWindowLong( hWnd, GWL_HWNDPARENT ),
		     PSM_CHANGED, (WPARAM)hWnd, 0L );
      break;

    case WM_NOTIFY:
      switch( l->code )
	{
	case PSN_SETACTIVE:  // sent before page is shown
	  ConfigureOutputDlg( hWnd );
	  break;

	case PSN_KILLACTIVE:  //losing focus
#if 1
	  if ( ValidateOutputDlg( hWnd ) )
	    // ok to lose focus
	    SetWindowLong( hWnd, DWL_MSGRESULT, FALSE );
	  else
	    {
	      // don't use allow loss of focus
	      SetWindowLong( hWnd, DWL_MSGRESULT, TRUE );
	      return TRUE;
	    }
#endif
	  break;

	case PSN_QUERYCANCEL:
	  break;

	case PSN_APPLY:
	  bMP3 = bMP3Tmp;
	  lstrcpy( szWavOutputDir, szTmpWavOutputDir );
	  lstrcpy( szMP3OutputDir, szTmpMP3OutputDir );
	  break;

	case PSN_HELP:
	  break;

	case PSN_RESET:
	  break;

	default:
	  break;
	}
      break;
    }

  return FALSE;
}


/*
 * Used to initialize the values in the dialog.  If bGet is TRUE, values are
 * read and stored in tmp variables.  Otherwise, the values of the tmp vars
 * are written to the dialogs values.
 */
void GetSetOutputDlgCurrentVals( BOOL bGet )
{
  if ( bGet )
    {
      lstrcpy( szTmpWavOutputDir, szWavOutputDir );
      lstrcpy( szTmpMP3OutputDir, szMP3OutputDir );
      bMP3Tmp = bMP3;
    }
  else
    {
      lstrcpy( szWavOutputDir, szTmpWavOutputDir );
      lstrcpy( szMP3OutputDir, szTmpMP3OutputDir );
      bMP3 = bMP3Tmp;
    }
}

