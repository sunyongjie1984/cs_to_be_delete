AKRip32.dll v.94 readme:
25 Feb 2000

This archive contains the full source code to AKRip32.dll, plus the
precompiled DLL and an import library for Mingw32.  Holger Dor's
Delphi interface is available at the main AKRIP32 site (URL below).

AKRip32.DLL is released under the Lesser Gnu General Public License (see
COPYING-2.1).  Under the terms of the license, you are allowed to use the
library in other (even commercial) products, but must always let your end
users know that they have the right to get the source code to the library.

The latest full source code to the library is available at 
  http://akrip.sourceforge.net/
The Delphi unit is also available at the URL above.

Example applications using the library are at
  http://www.geocities.com/SiliconValley/Byte/7125/

If you plan on including it in a product, commercial, shareware or freeware,
I'd like to hear about it, although it's by no means mandatory.

Andy Key
scsiprog@geocities.com
