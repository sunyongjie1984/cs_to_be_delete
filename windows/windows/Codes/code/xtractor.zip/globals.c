/*
 * globals.c - Copyright (C) 1999,2000 Jay A. Key
 *
 * Global variables used by CD-DA X-Tractor
 *
 **********************************************************************
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */
#include <windows.h>
#include "akrip/akrip32.h"
#include "bladedll.h"


int iMajorVer = 0;
int iMinorVer = 15;


HINSTANCE ghInstance = NULL;

unsigned char validFnameChar[256];

BOOL bAutoTOC = FALSE;            // Automatically read TOC on startup
BOOL bAutoCheck = FALSE;          // Automatically check all tracks
BOOL bHiColor = FALSE;            // use hi-color toolbar bitmaps

CDLIST cdlist;                    // list of CD drives found on machine
int cdlistIdx;                    // index of currently selected drive

HCDROM hCD = NULL;
BYTE bReadType = CDR_ANY;         // read algorithm to use
DWORD maxRip = 27;                // maximum frames to rip at once
DWORD jitterCheck = 1;            // number of frames to match
DWORD numOverlap = 3;             // number of frames to overlap
DWORD readMode = CDRM_JITTERONERR; // when to do jitter correction

char szWavOutputDir[MAX_PATH+1] = ".";    // default output to curr. dir
char szMP3OutputDir[MAX_PATH+1] = ".";    // default output to curr. dir

/*
 * MP3 related
 */
// Generic
int iNumEncoders = 0;
int iEncoder = 0;                 // which encoder to use
BOOL bMP3 = FALSE;                // encode to MP3 (if avail)?
BOOL bWavMirror = FALSE;          // create WAV at same time as MP3?
BEINITSTREAM   beInitStream;      // BladeEnc function pointer
BEENCODECHUNK  beEncodeChunk;     // BladeEnc function pointer
BEDEINITSTREAM beDeinitStream;    // BladeEnc function pointer
BECLOSESTREAM  beCloseStream;     // BladeEnc function pointer
BEVERSION      beVersion;         // BladeEnc function pointer
WORD wBitrate = 192;              // bitrate to use for MP3 encoding
BOOL bCRC = FALSE;                // generate CRC for MP3 frames?
BOOL bID3 = FALSE;                // id3 tagging?
BOOL bCopyright = FALSE;
BOOL bPrivate = FALSE;
BOOL bOriginal = FALSE;

// BladeEnc
HANDLE hBladeDll = NULL;          // handle to BladeEnc DLL
BOOL bBladeAvail = FALSE;         // BladeEnc DLL loaded successfully

// lame_enc specific items
HANDLE hLameDll = NULL;           // handle to Lame_Enc DLL
BOOL bLameAval = FALSE;           // Lame_Enc DLL loaded successfully
WORD wMaxBitrate = 320;           // Max. VBR bitrate
WORD wMode = BE_MP3_MODE_STEREO;
MPEG_QUALITY nQuality = HIGH_QUALITY;
BOOL bVBR = TRUE;
BOOL bVBRHeader = TRUE;
INT nVBRQuality = 5;


// about dialog
ATOM atomBmpPanel = 0;
char *szBmpPanel = "ctrlbmppanel";

// CDDB Support
BOOL bCDDB = FALSE;
char szCDDBServer[81] = "www.freedb.org";
int iHTTPPort = 80;
char szCGI[81] = "/~cddb/cddb.cgi";
char szProxyAddr[81] = "";
int iProxyPort = 0;
BOOL bUseProxy = FALSE;
BOOL bInCDDBQuery = FALSE;          // when a query thread is open
                                    // should be set to TRUE

BOOL bRippingTracks = FALSE;
