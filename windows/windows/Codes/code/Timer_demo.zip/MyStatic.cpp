// MyStatic.cpp : implementation file
//

#include "stdafx.h"
#include "TimerTst.h"
#include "MyStatic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyStatic

CMyStatic::CMyStatic()
{
}

CMyStatic::~CMyStatic()
{
}


BEGIN_MESSAGE_MAP(CMyStatic, CStatic)
	//{{AFX_MSG_MAP(CMyStatic)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyStatic message handlers

void CMyStatic::Tick()
{	
	CRect rect;
	GetClientRect(rect);
	CDC* pDC=GetDC();
//	pDC->FillSolidRect(rect,RGB(10,15,40));
	pDC->InvertRect(rect);
	Sleep(500);
//	pDC->FillSolidRect(rect,::GetSysColor(COLOR_BTNFACE));
	pDC->InvertRect(rect);
	ReleaseDC(pDC);
	
}
