/************************************
  REVISION LOG ENTRY
  Revision By: Mihai Filimon
  Revised on 5/22/98 8:52:03 AM
  Comments: TSortColumn.h: interface for the CTSortColumn class.
 ************************************/

#if !defined(AFX_TSORTCOLUMN_H__395EEE51_E42C_11D1_85EF_0040055C08D9__INCLUDED_)
#define AFX_TSORTCOLUMN_H__395EEE51_E42C_11D1_85EF_0040055C08D9__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include <math.h>

#include <afxtempl.h>

class CTSortColumns;

typedef int  (*COLUMNCALLBACKCOMPARE) (const TCHAR* stringi, const TCHAR* stringj);
typedef void (*SHOWPROGRESSBAR) (CTSortColumns* pSort);

struct ColumnOrder
{
	int m_nColumn;
	short m_nAsc;
	ColumnOrder(int nColumn = 0, short nAsc = 1)
	{
		m_nColumn = nColumn;
		m_nAsc = nAsc;
	}
};

typedef struct _SItemStruct
{
	CStringArray m_arStrItemText;
	LPARAM m_lParam;

} SItemStruct;

typedef struct _SItemStructUni
{
	_SItemStructUni(CString& strItemText, LPARAM lParam)
	{
		m_strItemText = strItemText;
		m_lParam = lParam;
	};
	CString m_strItemText;
	LPARAM m_lParam;

} SItemStructUni;

typedef struct _CompareColumnOrder
{
	_CompareColumnOrder(COLUMNCALLBACKCOMPARE pCallBackCompare, short nAsc)
	{
		m_pCallBackCompare = pCallBackCompare;
		m_nAsc = nAsc;
	};
	COLUMNCALLBACKCOMPARE m_pCallBackCompare;
	short m_nAsc;

} CompareColumnOrder;


class CTsyslistviewex;

class CTSortColumns
{
public:
	void Sort();
	int m_nCmpsMax;
	int m_nCmpsCur;
	int GetCountOrderColumn() const;
	void AddOrderColumn(int nColumn, short nAsc = 1);
	void ResetOrderColumn();
	void AttachControl(CTsyslistviewex* pListCtrl = NULL);
	void Add(int nColumn, COLUMNCALLBACKCOMPARE pCallBackCompare);
	void Delete(int nColumn);
	SHOWPROGRESSBAR m_pFctShowProgressBar;

	CTSortColumns();
	virtual ~CTSortColumns();
	CTsyslistviewex* m_pListCtrl;
	CMap<int, int, COLUMNCALLBACKCOMPARE, COLUMNCALLBACKCOMPARE> m_mapColumnsSort;
	CArray<ColumnOrder*, ColumnOrder*> m_arOrderColumn;
	int m_nOrderColumn;
protected:
	void SortMultiColumn();
	void SortUniColumn();
private:
};

#endif // !defined(AFX_TSORTCOLUMN_H__395EEE51_E42C_11D1_85EF_0040055C08D9__INCLUDED_)
