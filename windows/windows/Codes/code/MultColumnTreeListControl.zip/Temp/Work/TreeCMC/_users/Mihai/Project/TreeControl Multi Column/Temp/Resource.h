//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LLL.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_LLL_DIALOG                  102
#define IDS_GRUPA                       102
#define IDS_TEAMS                       111
#define IDR_MAINFRAME                   128
#define IDB_CHECK                       130
#define IDB_BITMAP1                     140
#define IDB_BITMAP2                     141
#define IDB_BITMAP3                     142
#define IDB_BITMAP4                     143
#define IDB_BITMAP5                     144
#define IDB_BITMAP6                     145
#define IDB_BITMAP7                     146
#define IDB_BITMAP8                     147
#define IDB_BITMAP9                     148
#define IDB_BITMAP10                    149
#define IDB_BITMAP11                    150
#define IDB_BITMAP12                    151
#define IDB_BITMAP13                    152
#define IDB_BITMAP14                    153
#define IDB_BITMAP15                    154
#define IDB_BITMAP16                    155
#define IDB_BITMAP17                    156
#define IDB_BITMAP18                    157
#define IDB_BITMAP19                    158
#define IDB_BITMAP20                    159
#define IDB_BITMAP21                    160
#define IDB_BITMAP22                    161
#define IDB_BITMAP23                    162
#define IDB_BITMAP24                    163
#define IDB_BITMAP25                    164
#define IDB_BITMAP26                    165
#define IDB_BITMAP27                    166
#define IDB_BITMAP28                    167
#define IDB_BITMAP29                    168
#define IDB_BITMAP30                    169
#define IDB_BITMAP31                    170
#define IDB_BITMAP32                    171
#define IDC_LIST1                       1000
#define IDC_LIST2                       1001
#define IDC_BUTTON_DEL                  1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        172
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
