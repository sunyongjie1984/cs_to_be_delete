/************************************
  REVISION LOG ENTRY
  Revision By: Mihai Filimon
  Revised on 6/20/98 2:45:52 PM
  Comments: TreeCtrlMultiColumn.h: interface for the CTreeMultiColumnCtrl class.
 ************************************/

#if !defined(AFX_TREECTRLMULTICOLUMN_H__3FDB7CD3_028A_11D2_861E_0040055C08D9__INCLUDED_)
#define AFX_TREECTRLMULTICOLUMN_H__3FDB7CD3_028A_11D2_861E_0040055C08D9__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Tsyslistviewex.h"

#define LVM_SETPARENT	WM_USER + 1
#define LVM_EXPAND		WM_USER + 2
#define LVM_COLLAPSE	WM_USER + 3

struct _STTreeMCCloneMessage {
	CMap<UINT,UINT,BOOL,BOOL> m_mapMessage;
	CMap<UINT,UINT,BOOL,BOOL> m_mapMessageHeader;
	_STTreeMCCloneMessage()
	{
		m_mapMessage[LVM_INSERTITEMA] = TRUE;
		m_mapMessage[LVM_INSERTITEMW] = TRUE;
		m_mapMessage[LVM_DELETEITEM] = TRUE;
		m_mapMessage[LVM_DELETEALLITEMS] = TRUE;
		m_mapMessage[LVM_SETITEMTEXTA] = TRUE;
		m_mapMessage[LVM_SETITEMTEXTW] = TRUE;
		m_mapMessage[LVM_SETITEMA] = TRUE;
		m_mapMessage[LVM_SETITEMW] = TRUE;
		m_mapMessage[LVM_GETITEMCOUNT] = TRUE;

		m_mapMessageHeader[LVM_INSERTCOLUMNA] = TRUE;
		m_mapMessageHeader[LVM_INSERTCOLUMNW] = TRUE;
		m_mapMessageHeader[LVM_DELETECOLUMN] = TRUE;
		m_mapMessageHeader[LVM_SETCOLUMNA] = TRUE;
		m_mapMessageHeader[LVM_SETCOLUMNW] = TRUE;
	}

	BOOL Get(CMap<UINT,UINT,BOOL,BOOL>* pMap, UINT message)
	{
		BOOL value = FALSE;
		BOOL result = pMap->Lookup(message, value);
		if (result) result = value;
		return result;
	}

	BOOL IsCloneMessage(UINT message)
	{
		return Get(&m_mapMessage, message);
	}

	BOOL IsHeaderMessage(UINT message)
	{
		return Get(&m_mapMessageHeader, message);
	}
};

class CTreeMultiColumnCtrl : public CTsyslistviewex  
{
public:
	virtual BOOL Delete(int nItem);
	void Fill(LPCTSTR lpszItems);
	int GetRootColumn() const;
	virtual int SetRootColumn(int nNewTreeColumn);
	virtual void RecExpandItems(int nItem);
	virtual int GetFirstItemChild(int nItem);
	virtual int GetNextItemChild();
	void ExpandItem(int nItem);
	void CollapseItem(int nItem);
	BOOL ItemIsExpanded(int iItem);
	BOOL IsLastChildren(int iItem);
	int GetItemPath(int iItem, CArray<int, int>& arParents);
	BOOL ItemHasChildren(int iItem);
	int GetItemParent(int iItem);
	BOOL SetItemParent(int iItem, int iItemParent);
	CTreeMultiColumnCtrl(int nHeightRel = 4);
	virtual ~CTreeMultiColumnCtrl();
	virtual void ViewGridLines(BOOL bEnable = true) {return;};
	virtual void EnableSort(BOOL bEnable = true) {return;};
	virtual void PreSubclassWindow( );
	virtual LRESULT WindowProc( UINT message, WPARAM wParam, LPARAM lParam ); 
	//{{AFX_PUBLIC_DATA:)
	//}}AFX_PUBLIC_DATA:)
protected:
	BOOL IsDeleted(int nItem);
	virtual int GetItemLevel(int nItem);
	virtual BOOL IsPtnInSquareRect(CPoint point);
	virtual void UpdateTree(UINT message, WPARAM wParam, LPARAM lParam, LRESULT result);
	virtual void DrawCell(CDC* pDC, CRect& drawRect, DWORD format, int nItem, int nColumn);
	//{{AFX_MSG(CTreeMultiColumnCtrl)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
private:
	int m_nLastItemFound;
	int m_nLastItemFind;
	int m_nTreeColumn;
	short m_bInsideCode;
	static _STTreeMCCloneMessage m_mapCloneMessage;
	CListCtrl m_listItems;
	CMap<int,int,int,int> m_mapParents;
	CMap<int,int,BOOL,BOOL> m_mapItemExpanded;
	CMap<int,int,BOOL,BOOL> m_mapItemDeleted;
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_TREECTRLMULTICOLUMN_H__3FDB7CD3_028A_11D2_861E_0040055C08D9__INCLUDED_)
