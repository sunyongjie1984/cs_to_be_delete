/************************************
  REVISION LOG ENTRY
  Revision By: Mihai Filimon
  Revised on 6/20/98 11:19:36 AM
  Comments: ProgressCtrlEx.h : header file
 ************************************/

#if !defined(AFX_PROGRESSCTRLEX_H__5F2D1D11_E278_11D1_8540_9B1C6856D236__INCLUDED_)
#define AFX_PROGRESSCTRLEX_H__5F2D1D11_E278_11D1_8540_9B1C6856D236__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CProgressCtrlEx window

class CProgressCtrlEx : public CProgressCtrl
{
// Construction
public:
	CProgressCtrlEx();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProgressCtrlEx)
	protected:
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CProgressCtrlEx();

	// Generated message map functions
protected:
	//{{AFX_MSG(CProgressCtrlEx)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROGRESSCTRLEX_H__5F2D1D11_E278_11D1_8540_9B1C6856D236__INCLUDED_)
