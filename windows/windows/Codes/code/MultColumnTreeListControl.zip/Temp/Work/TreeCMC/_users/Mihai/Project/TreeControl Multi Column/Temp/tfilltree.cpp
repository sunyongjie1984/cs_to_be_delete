#include "stdafx.h"
#include "tfilltree.h"

CString _STSeparatorsMultiColumn::separators(_T("(,)"));
TCHAR _STSeparatorsMultiColumn::separatorItem = TCHAR('%');
