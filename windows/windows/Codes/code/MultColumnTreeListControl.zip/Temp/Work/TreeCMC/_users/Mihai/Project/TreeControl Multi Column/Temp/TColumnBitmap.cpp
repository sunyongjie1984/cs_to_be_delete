/************************************
  REVISION LOG ENTRY
  Revision By: Mihai Filimon 
  Revised on 5/21/98 1:51:04 PM
  Comments: TColumnBitmap.cpp: implementation of the CTColumnBitmap class.
 ************************************/

#include "stdafx.h"
#include "TColumnBitmap.h"
#include <wingdi.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

COLORREF CTColumnBitmap::m_crMaskedColor = RGB(0,255,0);

// Function name	: CTColumnBitmap::Init
// Description	    : Initialize bitmap size and index
// Return type		: void 
// Argument         : int nImageWidth ; bitmap width
// Argument         : int nImageHeight ; bitmap height
// Argument         : int nRowImage ; bitmap index
void CTColumnBitmap::Init(int nImageWidth, int nImageHeight, int nRowImage)
{
	m_nImageWidth = nImageWidth;
	m_nImageHeight = nImageHeight;
	m_nRowImage = nRowImage;
}

// Function name	: CTColumnBitmap::CTColumnBitmap
// Description	    : constructor
// Return type		: -
CTColumnBitmap::CTColumnBitmap()
{
	Init(0,0,0);
	m_bLoad = false;
	ASSERT(false);
}

// Function name	: CTColumnBitmap::CTColumnBitmap
// Description	    : constructor
// Return type		: -
// Argument         : UINT nIDResource ; resource identifier
// Argument         : int nImageWidth ; bitmap width
// Argument         : int nImageHeight ; bitmap height
// Argument         : int nRowImage ; bitmap index
CTColumnBitmap::CTColumnBitmap(UINT nIDResource, int nImageWidth , int nImageHeight , int nRowImage )
{
	if (m_bLoad = m_bitmap.LoadBitmap(nIDResource))
		Init(nImageWidth, nImageHeight, nRowImage);
}

// Function name	: CTColumnBitmap::~CTColumnBitmap
// Description	    : destructor
// Return type		: -
CTColumnBitmap::~CTColumnBitmap()
{
	if (m_bLoad)
		m_bitmap.DeleteObject();
}

// Function name	: CTColumnBitmap::GetRectImage
// Description	    : get bitmap rect
// Return type		: CRect ; bimap rect
// Argument         : int nColumn ; column to get bitmap from
CRect CTColumnBitmap::GetRectImage(int nColumn)
{
	return CRect(CPoint(nColumn * m_nImageWidth, m_nRowImage * m_nImageHeight), CSize(m_nImageWidth, m_nImageHeight));
}

// Function name	: CTColumnBitmap::IsLoad
// Description	    : tells if is any bitmap loaded
// Return type		: BOOL ; TRUE if so
BOOL CTColumnBitmap::IsLoad() const
{
	return m_bLoad;
}

// Function name	: CTColumnBitmap::GetBitmap
// Description	    : get bitmap address
// Return type		: CBitmap* ; in fact the address of m_bitmap member
CBitmap* CTColumnBitmap::GetBitmap() 
{
	return &m_bitmap;
}

// Function name	: CTColumnBitmap::Put
// Description	    : put a bitmap into a client DC
// Return type		: void 
// Argument         : int nColumn ; bitmap column
// Argument         : CDC * pDC ; client DC
// Argument         : int x ; x position
// Argument         : int y ; y position
// Argument         : int dxMax ; x size?
void CTColumnBitmap::Put(int nColumn, CDC * pDC, int x, int y, int dxMax)
{
	CDC memDC, maskDC, tempDC;
	if (maskDC.CreateCompatibleDC(pDC))
		if (memDC.CreateCompatibleDC(pDC))
			if (tempDC.CreateCompatibleDC(pDC))
			{
				CRect rect = GetRectImage(nColumn);
				int nHeight = rect.Height();
				int nWidth = min(rect.Width(),dxMax);
				int xImage = rect.left;
				int yImage = rect.top;
				// Create a compatible bitmap with pDC in memDC, for copy image from bitmap source
				CBitmap bmpImage, maskBitmap;
				bmpImage.CreateCompatibleBitmap( pDC, nWidth, nHeight );
				CBitmap* pOldBitmapMem = memDC.SelectObject( &bmpImage );
				CBitmap* pOldBitmapTemp = tempDC.SelectObject(GetBitmap());
				memDC.BitBlt( 0,0, nWidth, nHeight, &tempDC, xImage, yImage , SRCCOPY );
				COLORREF f= memDC.GetPixel(27,30);
				// memDC contain image of bitmap which must be view in pDC.

				// Create monochrome bitmap for the mask
				maskBitmap.CreateBitmap( nWidth, nHeight, 1, 1, NULL );
				CBitmap*  pOldBitmapMask = maskDC.SelectObject( &maskBitmap );
				memDC.SetBkColor( m_crMaskedColor );

				// Create the mask from the memDC
				maskDC.BitBlt( 0, 0, nWidth, nHeight, &memDC, 0, 0, SRCCOPY );

				// Set the background in memDC to black. Using SRCPAINT with black 
				// and any other color results in the other color, thus making 
				// black the transparent color
				memDC.SetBkColor(RGB(0,0,0));
				memDC.SetTextColor(RGB(255,255,255));
				memDC.BitBlt(0, 0, nWidth, nHeight, &maskDC, 0, 0, SRCAND);

				// Set the foreground to black. See comment above.
				COLORREF oldBkColor = pDC->SetBkColor(RGB(255,255,255));
				COLORREF oldFgColor = pDC->SetTextColor(RGB(0,0,0));

				pDC->BitBlt(x, y, nWidth, nHeight, &maskDC, 0, 0, SRCAND);
				pDC->BitBlt(x, y, nWidth, nHeight, &memDC, 0, 0, SRCPAINT);

				pDC->SetBkColor(oldBkColor);
				pDC->SetTextColor(oldFgColor);
				maskDC.SelectObject( pOldBitmapMask );
				tempDC.SelectObject( pOldBitmapTemp );
				memDC.SelectObject( pOldBitmapMem );
			}
}

// Function name	: CTColumnBitmap::GetWidth
// Description	    : Return the width of image
// Return type		: int 
int CTColumnBitmap::GetWidth()
{
	return m_nImageWidth;
}
