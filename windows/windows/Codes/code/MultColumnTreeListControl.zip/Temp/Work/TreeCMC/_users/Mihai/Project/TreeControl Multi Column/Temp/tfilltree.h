/************************************
  REVISION LOG ENTRY
  Revision By: Mihai Filimon
  Revised on 6/11/98 2:28:47 PM
  Comments: Header of struct STFillTree and _STSeparators
 ************************************/

#if !defined(AFX_FILLTREE_H__INCLUDED_)
#define AFX_FILLTREE_H__INCLUDED_

#include "stdafx.h"
#include "TreeCtrlMultiColumn.h"

struct _STSeparatorsMultiColumn {
	static CString separators;  // contain charcters: "(,)"
	static TCHAR separatorItem;
	CTreeMultiColumnCtrl* m_pTreeCtrl;		// tree control destination
	
	// Function name	: _STSeparatorsMultiColumn
	// Description	    : Constructor
	// Return type		: 
	// Argument         : CTreeMultiColumnCtrl* pTreeCtrl
	_STSeparatorsMultiColumn(CTreeMultiColumnCtrl* pTreeCtrl)
	{
		m_pTreeCtrl = pTreeCtrl;
		ASSERT (m_pTreeCtrl);
	};

	// Function name	: Action
	// Description	    : 
	// Return type		: void 
	// Argument         : int& n
	// Argument         : int nParent
	// Argument         : TCHAR c
	void Action(int& n, int nParent, TCHAR c)
	{
		switch (c)
		{
			case TCHAR(','):
				n = nParent;
				break;
			case TCHAR(')'):
				n = m_pTreeCtrl->GetItemParent(nParent);
				break;
			case TCHAR('('):
				break;
		}
	};
};


struct STFillTreeMultiColumn {
	CTreeMultiColumnCtrl* m_pTreeCtrl;
	CString m_sItems;
	_STSeparatorsMultiColumn* m_oSep;
	
	STFillTreeMultiColumn (CWnd* pTreeCtrl, LPCTSTR lpszItems): m_sItems(lpszItems)
	{
		m_pTreeCtrl = (CTreeMultiColumnCtrl*)pTreeCtrl;
		ASSERT (m_pTreeCtrl && ::IsWindow(m_pTreeCtrl->m_hWnd));
		m_oSep = new _STSeparatorsMultiColumn(m_pTreeCtrl);
	};

	~STFillTreeMultiColumn()
	{
		delete m_oSep;
	};

	virtual void Fill()
	{
		m_pTreeCtrl->DeleteAllItems();
		RecFill();
	};

	// Function name	: AddItem
	// Description	    : 
	// Return type		: virtual int 
	// Argument         : CString* psItem
	// Argument         : int nParent
	virtual int AddItem(CString* psItem, int nParent)
	{
		int rnItem = nParent;
		if (!psItem->IsEmpty())
		{
			CString sItem;
			AfxExtractSubString(sItem, (LPCTSTR)*psItem, 0, _STSeparatorsMultiColumn::separatorItem);
			rnItem = m_pTreeCtrl->InsertItem(m_pTreeCtrl->GetItemCount(), sItem);
			for (int i = 1; i < m_pTreeCtrl->GetCountColumn(); i++)
			{
				AfxExtractSubString(sItem, (LPCTSTR)*psItem, i, _STSeparatorsMultiColumn::separatorItem);
				m_pTreeCtrl->SetItemText(rnItem, i, sItem);
			}
			if (nParent >= 0)
				m_pTreeCtrl->SetItemParent(rnItem, nParent);
		}
		return rnItem;
	};


	// Function name	: RecFill
	// Description	    : Recursive fill
	// Return type		: void 
	// Argument         : int nCurrent = 0 : position in string
	// Argument         : int nParent = -1 ; as root item
	void RecFill(int nCurrent = 0, int nParent = -1)
	{
		int n = nParent;
		CString sItems = m_sItems.Mid(nCurrent);
		int nSeparator = sItems.FindOneOf(m_oSep.separators);
		if (nSeparator < 0)
			AddItem(&sItems, nParent);
		else
		{
			n = AddItem(&sItems.Left(nSeparator), nParent);
			m_oSep->Action(n, nParent, sItems[nSeparator]);
			RecFill(nCurrent + nSeparator + 1, n);
		}
	};

};

#endif //AFX_FILLTREE_H__INCLUDED_
