/************************************
  REVISION LOG ENTRY
  Revision By: Mihai Filimon
  Revised on 6/20/98 2:46:25 PM
  Comments: TColumnBitmap.h: interface for the CTColumnBitmap class.
 ************************************/

#if !defined(AFX_TCOLUMNBITMAP_H__1CED3233_E31B_11D1_85EB_0040055C08D9__INCLUDED_)
#define AFX_TCOLUMNBITMAP_H__1CED3233_E31B_11D1_85EB_0040055C08D9__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CTColumnBitmap  
{
public:
	int GetWidth();
	void Put(int nColumn, CDC * pDC, int x, int y, int dxMax);
	static COLORREF m_crMaskedColor;
	CBitmap* GetBitmap();
	BOOL IsLoad() const;
	CRect GetRectImage(int nColumn);
	void Init(int nImageWidth, int nImageHeight, int nRowImage);
	CTColumnBitmap();
	CTColumnBitmap(UINT nIDResource, int nImageWidth = 14, int nImageHeight = 14, int nRowImage = 0);
	virtual ~CTColumnBitmap();
private:
	int m_nImageWidth;
	int m_nImageHeight;
	int m_nRowImage;
	BOOL m_bLoad;
	CBitmap m_bitmap;

};

#endif // !defined(AFX_TCOLUMNBITMAP_H__1CED3233_E31B_11D1_85EB_0040055C08D9__INCLUDED_)
