/************************************
  REVISION LOG ENTRY
  Revision By: Mihai Filimon
  Revised on 5/22/98 8:51:37 AM
  Comments: ProgressCtrlEx.cpp : implementation file
 ************************************/

#include "stdafx.h"
#include "ProgressCtrlEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProgressCtrlEx

// Function name	: CProgressCtrlEx::CProgressCtrlEx
// Description	    : Constructor
// Return type		: 
CProgressCtrlEx::CProgressCtrlEx()
{
}

// Function name	: CProgressCtrlEx::~CProgressCtrlEx
// Description	    : Destructor
// Return type		: 
CProgressCtrlEx::~CProgressCtrlEx()
{
}


BEGIN_MESSAGE_MAP(CProgressCtrlEx, CProgressCtrl)
	//{{AFX_MSG_MAP(CProgressCtrlEx)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProgressCtrlEx message handlers

// Function name	: CProgressCtrlEx::WindowProc
// Description	    : Corupt message PBM_SETPOS for put on center percent.
// Return type		: LRESULT 
// Argument         : UINT message
// Argument         : WPARAM wParam
// Argument         : LPARAM lParam
LRESULT CProgressCtrlEx::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	LRESULT result = CProgressCtrl::WindowProc(message, wParam, lParam);
	if (message == PBM_SETPOS)
	{
		int percent = (int)wParam;
		if (percent <= 100)
		{
			CString percentStr; percentStr.Format(_T("%i%%"),percent);
			CRect rect; GetClientRect(rect);
			CDC* pDC = GetDC();
			CFont* pOldFont = pDC->SelectObject(GetParent()->GetFont());
			CSize dSize = pDC->GetTextExtent(percentStr);
			CRect rectPercent = rect;
			rectPercent.left += (rect.Width() - dSize.cx)/2;
			rectPercent.right = rectPercent.left + dSize.cx + 4;
			rectPercent.left -= 2;
			rectPercent.right += 2;
			rectPercent.top += (rect.Height() - dSize.cy)/2;
			rectPercent.bottom = rectPercent.top + dSize.cy;

			CBrush brush(GetSysColor(COLOR_BTNFACE));
			CBrush* pOldBrush = pDC->SelectObject(&brush);
			pDC->Rectangle(rectPercent);
			pDC->SetBkMode(TRANSPARENT);
			pDC->DrawText(percentStr, rectPercent, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
			pDC->SelectObject(pOldFont);
			pDC->SelectObject(pOldBrush);
			ReleaseDC(pDC);
		}
	}
	return result;
}
