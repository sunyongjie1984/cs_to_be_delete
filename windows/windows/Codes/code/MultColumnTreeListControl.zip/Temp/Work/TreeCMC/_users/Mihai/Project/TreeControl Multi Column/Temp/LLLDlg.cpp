// LLLDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LLL.h"
#include "LLLDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLLLDlg dialog

CLLLDlg::CLLLDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLLLDlg::IDD, pParent), m_treeCtrl(12), m_listCtrl(12)
{
	//{{AFX_DATA_INIT(CLLLDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CLLLDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLLLDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CLLLDlg, CDialog)
	//{{AFX_MSG_MAP(CLLLDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_DEL, OnButtonDel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLLLDlg message handlers

BOOL CLLLDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// Fill the tree control
	m_treeCtrl.SubclassDlgItem(IDC_LIST1, this);
	m_treeCtrl.InsertColumn(0, _T("Team"), LVCFMT_LEFT,192);
	m_treeCtrl.InsertColumn(1, _T("Favorites"),LVCFMT_CENTER,24);
	m_treeCtrl.AttachBitmap(1, IDB_CHECK);
	CString teams, favourite;
	if (teams.LoadString(IDS_TEAMS))
	{
		for (char g = 'A'; g <= 'H'; g++)
			m_treeCtrl.InsertItem(m_treeCtrl.GetItemCount(), _T("Group ") + CString(g));
		CString team, name, group;
		int i = 0;
		for (UINT iBitmap = IDB_BITMAP1; iBitmap <= IDB_BITMAP32; iBitmap++)
		{
			AfxExtractSubString(team, teams, iBitmap - IDB_BITMAP1);
			AfxExtractSubString(name, team, 0, TCHAR(';'));
			AfxExtractSubString(group, team, 1, TCHAR(';'));
			AfxExtractSubString(favourite, team, 2, TCHAR(';'));
			int nItem = m_treeCtrl.InsertItem(m_treeCtrl.GetItemCount(),_T("0:") + name);
			m_treeCtrl.SetItemParent(nItem, group[0]-'A');
			m_treeCtrl.SetItemText(nItem, 1, favourite);
			m_treeCtrl.SetItemData(nItem, nItem + 1);
			m_treeCtrl.AttachBitmapCell(nItem, 0, iBitmap, 25, 19);
			if (!favourite.IsEmpty())
				m_treeCtrl.SetBoldRow(nItem + 1);
		}
		m_treeCtrl.ExpandHeader();
		// Fill the list control
		m_listCtrl.SubclassDlgItem(IDC_LIST2, this);
		m_listCtrl.InsertColumn(0, _T("Team"), LVCFMT_LEFT,192);
		m_listCtrl.InsertColumn(1, _T("Group"),LVCFMT_LEFT,48);
		m_listCtrl.InsertColumn(2, _T("Flag"),LVCFMT_LEFT,48);
		m_listCtrl.ViewGridLines();
		for (iBitmap = IDB_BITMAP1; iBitmap <= IDB_BITMAP32; iBitmap++)
		{
			AfxExtractSubString(team, teams, iBitmap - IDB_BITMAP1);
			AfxExtractSubString(name, team, 0, TCHAR(';'));
			AfxExtractSubString(group, team, 1, TCHAR(';'));
			AfxExtractSubString(favourite, team, 2, TCHAR(';'));
			int nItem = m_listCtrl.InsertItem(m_listCtrl.GetItemCount(),name);
			m_listCtrl.SetItemData(nItem, nItem + 1);
			m_listCtrl.AttachBitmapCell(nItem + 1, 2, iBitmap, 25, 19);
			m_listCtrl.SetItemText(nItem, 1, group);
			if (!favourite.IsEmpty())
			{
				m_listCtrl.SetBoldRow(nItem + 1);
				if (name == _T("Romania"))
					m_listCtrl.SetItalicRow(nItem + 1);
			}
		}
		m_listCtrl.EnableSort();
		m_listCtrl.SortAllItems(_T("1,0"));
		m_listCtrl.ExpandHeader();
	}
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CLLLDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CLLLDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CLLLDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CLLLDlg::OnButtonDel() 
{
	int iSelected = NULL;
	while ((iSelected = m_treeCtrl.GetNextItem(-1, LVNI_SELECTED))>=0)
		if (!m_treeCtrl.Delete(iSelected))
			return;
}
