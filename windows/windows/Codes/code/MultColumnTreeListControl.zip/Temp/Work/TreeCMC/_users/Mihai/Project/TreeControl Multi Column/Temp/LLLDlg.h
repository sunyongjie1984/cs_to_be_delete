// LLLDlg.h : header file
//

#if !defined(AFX_LLLDLG_H__77232567_0814_11D2_8627_0040055C08D9__INCLUDED_)
#define AFX_LLLDLG_H__77232567_0814_11D2_8627_0040055C08D9__INCLUDED_

#include "TreeCtrlMultiColumn.h"	// Added by ClassView
#include "Tsyslistviewex.h"	// Added by ClassView
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CLLLDlg dialog

class CLLLDlg : public CDialog
{
// Construction
public:
	CTsyslistviewex m_listCtrl;
	CTreeMultiColumnCtrl m_treeCtrl;
	CLLLDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CLLLDlg)
	enum { IDD = IDD_LLL_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLLLDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CLLLDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonDel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LLLDLG_H__77232567_0814_11D2_8627_0040055C08D9__INCLUDED_)
