/************************************
  REVISION LOG ENTRY
  Revision By: Mihai Filimon
  Revised on 5/27/98 1:04:03 PM
  Comments: CTsyslistviewex header file
 ************************************/

#if !defined(AFX_TSYSLISTVIEWEX_H__78A1F553_DB56_11D1_85D8_0040055C08D9__INCLUDED_)
#define AFX_TSYSLISTVIEWEX_H__78A1F553_DB56_11D1_85D8_0040055C08D9__INCLUDED_

#include "THeaderCtrlEx.h"	// Added by ClassView
#include "TColumnBitmap.h"	// Added by ClassView
#include "tsortcolumn.h"
#include "progressctrlex.h"
#include <afxtempl.h>

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Tsyslistviewex.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTsyslistviewex window

#define OFFSET 2
#define LIST_UNSUBCLASSED 0x00000000
#define LIST_SUBCLASSED   0x00000001
#define LIST_MASKCLASS    0x00000001
#define LIST_SECTION	  _T("ListControls")

class CTsyslistviewex;

typedef void (CTsyslistviewex :: *FCTDRAWITEM) ( LPDRAWITEMSTRUCT lpDrawItemStruct );

class CTsyslistviewex : public CListCtrl
{
	// constructor/destructor
public:
	CTsyslistviewex(int nHeightRel = 4);
	static TCHAR m_cImageTextSeparator;
	static BOOL SetHeader(CListCtrl * pList, CString newHeader);
	virtual void PreSubclassWindow( );

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTsyslistviewex)
	protected:
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
public:
	CString GetHeaderSortString();
	CString GetHeaderString();
	int GetCountRowsItalic();
	int GetCountColumn();
	int GetCountRowsBold();
	BOOL GetSubItemRect(int item, int subItem, CRect & rect);
	BOOL IsHeaderSaved();
	BOOL m_bSortWhenClickHeader;
	BOOL AttachBitmap(int nColumn, UINT nIDBitmap, int nImageWidth = 14, int nImageHeight = 14, int nRowImage = 0);
	DWORD ComposeKeyForCell(USHORT nIDRow, USHORT nColumn);
	BOOL AttachBitmapCell(USHORT nLParam, USHORT nColumn, UINT nIDBitmap, int nImageWidth = 14, int nImageHeight = 14, int nRowImage = 0);
	void SelectItem(int i);
	void DeselectAll();
	void SetBoldRow(LPARAM lParam = NULL, BOOL bBold = true, BOOL bInvalidate = false);
	void SetItalicRow(LPARAM lParam = NULL, BOOL bItalic = true, BOOL bInvalidate = false);
	void ResetBoldLines();
	void SortAllItems(LPCTSTR lpszColumnsSort);
	void SortAllItems();
	void AddSortCallBack(int nColumn, COLUMNCALLBACKCOMPARE pCallBack);
	virtual void EnableSort(BOOL bEnable = true);
	void EnableSaveHeader(BOOL bEnable = true);
	virtual void ViewGridLines(BOOL bEnable = true);
	void ExpandHeader();
	void Progress(int nPercent);
	virtual ~CTsyslistviewex();
	
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	// for speed...
	void DrawItemGrid(LPDRAWITEMSTRUCT lpDrawItemStruct);
	void DrawItemNoGrid(LPDRAWITEMSTRUCT lpDrawItemStruct);
	// Generated message map functions
protected:
	CTSortColumns m_sortColumns;
	void SaveHeader();
	//{{AFX_MSG(CTsyslistviewex)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	afx_msg void MeasureItem( LPMEASUREITEMSTRUCT lpMeasureItemStruct ); 


	static LPCTSTR MakeShortString(CDC* pDC, LPCTSTR lpszLong, int nColumnLen, int nOffset);

	DECLARE_MESSAGE_MAP()
protected:
	virtual void DrawCell(CDC* pDC, CRect& drawRect, DWORD format, int nItem, int nColumn);
	CTColumnBitmap* GetBitmapCell(DWORD nIDRow, int nColumn);
	CTColumnBitmap* GetBitmapColumn(int nColumn);
	CTHeaderCtrlEx m_wndSortHeaderEx;
	int HitTestEx(CPoint point, int& subItem);
private:
	BOOL GetRegisteredSort(CString& dest);
	int NeedCY();
	int NeedCX();
	BOOL m_bSaveHeader;
	CFont m_boldFont;
	CFont m_italicFont;
	CFont m_italicBoldFont;
	int m_nIProgress;
	int m_nSortItems;
	CProgressCtrlEx m_wndProgress;
	BOOL m_bSorted;
	CWnd* m_pOldHeaderCtrl;
	FCTDRAWITEM m_fctDrawItem;
	int m_nHeightRel;
	CMap<int,int, CTColumnBitmap*, CTColumnBitmap*> m_bmpColumns;
	CMap<DWORD,DWORD, CTColumnBitmap*, CTColumnBitmap*> m_bmpCells;
	CMap<LPARAM, LPARAM, BYTE, BYTE> m_mapRowsBold;
	CMap<LPARAM, LPARAM, BYTE, BYTE> m_mapRowsItalic;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TSYSLISTVIEWEX_H__78A1F553_DB56_11D1_85D8_0040055C08D9__INCLUDED_)
