/************************************
  REVISION LOG ENTRY
  Revision By: Mihai Filimon
  Revised on 5/22/98 9:22:52 AM
  Comments: TSortColumn.cpp: implementation of the CTSortColumns class.
 ************************************/

#include "stdafx.h"
#include "TSortColumn.h"
#include "tsyslistviewex.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// Function name	: ShowProgressBar
// Description	    : Shows progress bar indicator
// Return type		: void 
// Argument         : CTSortColumns* pSort
void ShowProgressBar(CTSortColumns* pSort)
{
	pSort->m_pListCtrl->Progress((int)((double)pSort->m_nCmpsCur++ / pSort->m_nCmpsMax * 100));
}

// Function name	: HideProgressBar
// Description	    : Hides progress bar indicator
// Return type		: void 
// Argument         : CTSortColumns* pSort
void HideProgressBar(CTSortColumns* pSort)
{
	return;
}

// Function name	: CTSortColumns::CTSortColumns
// Description	    : Constructor
// Return type		:  -
CTSortColumns::CTSortColumns()
{
	m_pListCtrl = NULL;
	m_nOrderColumn = 0;
	m_nCmpsMax = 0;
	m_nCmpsCur = 0;
}

// Function name	: CTSortColumns::~CTSortColumns
// Description	    : Destructor
// Return type		: -
CTSortColumns::~CTSortColumns()
{
	m_mapColumnsSort.RemoveAll();
	ResetOrderColumn();
}

// Function name	: CTSortColumns::AttachControl
// Description	    : Attach a control to the table
// Return type		: void 
// Argument         : CTsyslistviewex * pListCtrl ; control to attach
void CTSortColumns::AttachControl(CTsyslistviewex * pListCtrl)
{
	m_pListCtrl = pListCtrl;
}

// Function name	: CTSortColumns::Delete
// Description	    : Delete a sort column
// Return type		: void 
// Argument         : int nColumn
void CTSortColumns::Delete(int nColumn)
{
	m_mapColumnsSort.RemoveKey(nColumn);
}

// Function name	: CTSortColumns::Add
// Description	    : Add a sort column with callback function for comparation
// Return type		: void 
// Argument         : int nColumn
// Argument         : COLUMNCALLBACKCOMPARE pCallBackCompare
void CTSortColumns::Add(int nColumn, COLUMNCALLBACKCOMPARE pCallBackCompare)
{
	ASSERT ( pCallBackCompare != NULL);
	ASSERT ( m_pListCtrl != NULL );
		
	m_mapColumnsSort[nColumn] = pCallBackCompare;
}

// Function name	: CTSortColumns::ResetOrderColumn
// Description	    : Remove all sort columns from this object
// Return type		: void 
void CTSortColumns::ResetOrderColumn()
{
	for (int i = 0; i < m_arOrderColumn.GetSize(); i++)
		delete m_arOrderColumn[i];
	m_arOrderColumn.RemoveAll();
	m_nOrderColumn = 0 ;
}

// Function name	: CTSortColumns::AddOrderColumn
// Description	    : New sort column
// Return type		: void 
// Argument         : int nColumn
// Argument         : short nAsc
void CTSortColumns::AddOrderColumn(int nColumn, short nAsc)
{
	ASSERT (m_pListCtrl != NULL);
	ASSERT (nAsc != 0);
	ASSERT (nAsc == 1 || nAsc == -1);

	if (ColumnOrder* pColumnOrder = new ColumnOrder(nColumn, nAsc))
	{
		m_arOrderColumn.Add(pColumnOrder);
		m_nOrderColumn++;
		COLUMNCALLBACKCOMPARE pCallBackCompare  = NULL;;
		if (!m_mapColumnsSort.Lookup(nColumn, pCallBackCompare))
			m_mapColumnsSort[nColumn] = strcmp;
	}
}

// Function name	: CTSortColumns::GetCountOrderColumn
// Description	    : Get number of order columns
// Return type		: int 
int CTSortColumns::GetCountOrderColumn() const
{
	return m_nOrderColumn;
}

// Function name	: CompareFuncUni 
// Description	    : Function for compare an unique column. For speed only.
// Return type		: int CALLBACK 
// Argument         : LPARAM lParam1
// Argument         : LPARAM lParam2
// Argument         : LPARAM lParamSort
int CALLBACK CompareFuncUni (LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	CompareColumnOrder* pCco = (CompareColumnOrder*)lParamSort;
	int result = pCco->m_pCallBackCompare ( ((SItemStructUni*)lParam1)->m_strItemText, ((SItemStructUni*)lParam2)->m_strItemText );
	result *= pCco->m_nAsc;
	return result;
}

// Function name	: CompareFuncMulti 
// Description	    : Function for compare more columns.
// Return type		: int CALLBACK 
// Argument         : LPARAM lParam1
// Argument         : LPARAM lParam2
// Argument         : LPARAM lParamSort
int CALLBACK CompareFuncMulti (LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	CTSortColumns* pSort = (CTSortColumns*)lParamSort;
	SItemStruct* pItemTextDataI = (SItemStruct*)lParam1;
	SItemStruct* pItemTextDataJ = (SItemStruct*)lParam2;

	pSort->m_pFctShowProgressBar(pSort);
		
	register int result = 0;
	for (int i = 0; (i < pSort->m_nOrderColumn) && (result == 0); i++)
	{
		COLUMNCALLBACKCOMPARE pCallBackCompare = NULL;;
		pSort->m_mapColumnsSort.Lookup(pSort->m_arOrderColumn[i]->m_nColumn, pCallBackCompare);
		ASSERT( pCallBackCompare  != NULL);
		result = pCallBackCompare ( pItemTextDataI->m_arStrItemText[i], pItemTextDataJ->m_arStrItemText[i] );
		result *= pSort->m_arOrderColumn[i]->m_nAsc;
	}
	return result;
}

// Function name	: CTSortColumns::SortMultiColumn
// Description	    : Sort more columns.
// Return type		: void 
void CTSortColumns::SortMultiColumn()
{
	CListCtrl* pListCtrl = m_pListCtrl;
	int nItems = pListCtrl->GetItemCount();
	for (int i = 0 ; i < nItems; i++)
	{
		SItemStruct* pItemTextData = new SItemStruct();
		pItemTextData->m_lParam = pListCtrl->GetItemData(i);
		pItemTextData->m_arStrItemText.SetSize(m_nOrderColumn);
		for (int j = 0; j < m_nOrderColumn; j++)
			pItemTextData->m_arStrItemText[j] = pListCtrl->GetItemText(i, m_arOrderColumn[j]->m_nColumn);
		pListCtrl->SetItemData(i, (DWORD)pItemTextData);
	}

	pListCtrl->SortItems(CompareFuncMulti, (LPARAM)this);

	for (i = 0 ; i < nItems; i++)
	{
		SItemStruct* pItemTextData = (SItemStruct*)pListCtrl->GetItemData(i);
		pListCtrl->SetItemData(i, (DWORD)pItemTextData->m_lParam);
		delete pItemTextData;
	}
}

// Function name	: CTSortColumns::SortUniColumn
// Description	    : Sort one column
// Return type		: void 
void CTSortColumns::SortUniColumn()
{
	ASSERT (m_arOrderColumn.GetSize() == 1);

	CListCtrl* pListCtrl = m_pListCtrl;
	int nItems = pListCtrl->GetItemCount();
	ColumnOrder* pColumnOrder = m_arOrderColumn[0];
	int nSortColumn = pColumnOrder->m_nColumn;
	
	for (int i = 0 ; i < nItems; i++)
	{
		SItemStructUni* pItemTextData = new SItemStructUni(pListCtrl->GetItemText(i, nSortColumn), pListCtrl->GetItemData(i));
		pListCtrl->SetItemData(i, (DWORD)pItemTextData);
	}

	COLUMNCALLBACKCOMPARE pCallBackCompare = NULL;;
	m_mapColumnsSort.Lookup(pColumnOrder->m_nColumn, pCallBackCompare);
	ASSERT (pCallBackCompare != NULL);
	CompareColumnOrder cco(pCallBackCompare, pColumnOrder->m_nAsc);
	pListCtrl->SortItems(CompareFuncUni, (LPARAM)&cco);

	for (i = 0 ; i < nItems; i++)
	{
		SItemStructUni* pItemTextData = (SItemStructUni*)pListCtrl->GetItemData(i);
		pListCtrl->SetItemData(i, (DWORD)pItemTextData->m_lParam);
		delete pItemTextData;
	}
}

// Function name	: CTSortColumns::Sort
// Description	    : Sort.
// Return type		: void 
void CTSortColumns::Sort()
{
	if (GetCountOrderColumn() == 1)
		SortUniColumn();
	else
	{
		CListCtrl* pListCtrl = m_pListCtrl;
		int nItems = pListCtrl->GetItemCount();
		m_nCmpsMax = int( nItems * log(nItems) / log(2) + nItems ) / 2;
		m_nCmpsCur = 0;
		BOOL bShow = nItems >= 256;
		m_pFctShowProgressBar = bShow ? ShowProgressBar : HideProgressBar;
		SortMultiColumn();
		if (bShow)
			m_pListCtrl->Progress(100);
	}
}
