/************************************
  REVISION LOG ENTRY
  Revision By: Mihai Filimon
  Revised on 6/20/98 2:46:45 PM
  Comments: THeaderCtrlEx.h : header file
 ************************************/

#if !defined(AFX_THEADERCTRLEX_H__F28DAA63_E02B_11D1_85E6_0040055C08D9__INCLUDED_)
#define AFX_THEADERCTRLEX_H__F28DAA63_E02B_11D1_85E6_0040055C08D9__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CTHeaderCtrlEx window
#include <afxtempl.h>

#define SET TRUE				// used in SetColumnFormat to set ownerdraw style of a column
#define REMOVE FALSE			// used in SetColumnFormat to remove ownerdraw style of a column

class CTHeaderCtrlEx : public CHeaderCtrl
{
// Construction
public:
	CTHeaderCtrlEx();

// Attributes
public:
	virtual void DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct );

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTHeaderCtrlEx)
	//}}AFX_VIRTUAL

// Implementation
public:
	void ResetSortColumns(BOOL bInvalidate = true);
	BOOL GetPositionColumn(int nPosition, BOOL & bAsc, int & nColumn) const;
	BOOL GetColumnOrder(int nColumn, BOOL & bAsc, int & nPosition) const;
	BOOL SetColumnOrder(int iColumn, BOOL bAsc = TRUE);
	void DeleteColumnOrder(int iColumn);
	virtual ~CTHeaderCtrlEx();

	// Generated message map functions
protected:
	CMap <int,int, WORD, WORD> m_mapSortColumns; // contain sort columns
	//{{AFX_MSG(CTHeaderCtrlEx)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	void SignMoreSortColumns(CDC & dc, int nPosition,  CRect& rectWhere);
	void SetColumnFormat(int iColumn, int format, BOOL bOr = SET);
	int m_nLastPosition;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_THEADERCTRLEX_H__F28DAA63_E02B_11D1_85E6_0040055C08D9__INCLUDED_)
