// RWLock.cpp: implementation of the CRWLock class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TestLock.h"
#include "RWLock.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//---------------------------------------------------------------------
// CCURWLock - constructs a read-write lock object and events
//
// Exceptions   : NONE
// Return Codes : NONE 
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
CRWLock::CRWLock() : m_nLockCount(0), m_nWaitingReaders(0), m_nWaitingWriters(0)
///////////////////////////////////////////////////////////////////////
{
	 m_hReaderEvent = CreateEvent(NULL, 0, 0, NULL); 
	 m_hWriterEvent = CreateEvent(NULL, 0, 0, NULL);
	 m_hLockCountMutex = CreateMutex(NULL, FALSE, NULL);
}

//---------------------------------------------------------------------
// ~CRWLock - destroys the read-write lock object and events
//
// Exceptions   : NONE
// Return Codes : NONE 
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
CRWLock::~CRWLock()
///////////////////////////////////////////////////////////////////////
{
	// Make sure mutex is unlocked when object is destroyed
	ReleaseMutex(m_hLockCountMutex);

	// clean-up all handles
	CloseHandle(m_hLockCountMutex);
	CloseHandle(m_hWriterEvent);
	CloseHandle(m_hReaderEvent);
}

//---------------------------------------------------------------------
// lockRead - allows multiple reading threads to lock a resource
// for shared access
//
// Exceptions   : NONE
// Return Codes : TRUE (success), FALSE (failure)
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
int CRWLock::lockRead()
///////////////////////////////////////////////////////////////////////
{
	if (waitingReader() == FALSE)
	{
		return FALSE;
	}

	if (m_nLockCount < 0)
	{
		// a reader thread must wait for the read event.. if a writer is holding lock
		if (WaitForSingleObject(m_hReaderEvent, INFINITE) != WAIT_OBJECT_0)
		{
			return FALSE;
		}

		ResetEvent(m_hReaderEvent);
	}

	if (incrementReaders() == FALSE)
	{
		return FALSE;
	}

	return TRUE;
}

//---------------------------------------------------------------------
// unlockRead - allows reader threads to unlock a resource
//
// Exceptions   : NONE
// Return Codes : TRUE (success), FALSE (failure)
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
int CRWLock::unlockRead()
///////////////////////////////////////////////////////////////////////
{
	if (decrementReaders() == FALSE)
	{
		return FALSE;
	}

	if (!m_nWaitingReaders && !m_nLockCount)
	{
		if (!SetEvent(m_hWriterEvent)) // will release one waiting writer
		{
			return FALSE;
		}
	}

	return TRUE;
}

//---------------------------------------------------------------------
// lockWrite - allows single writer thread to lock a resource
// for exclusive access
//
// Exceptions   : NONE
// Return Codes : TRUE (success), FALSE (failure)
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
int CRWLock::lockWrite()
///////////////////////////////////////////////////////////////////////
{
	if (waitingWriter() == FALSE)
	{
		return FALSE;
	}

	// writers compete with readers and fellow-writers ...
	while (m_nLockCount)
	{
		if (WaitForSingleObject(m_hWriterEvent, INFINITE) != WAIT_OBJECT_0)
		{
			return FALSE;
		}
	}

	if (incrementWriters() == FALSE)
	{
		return FALSE;
	}

	return TRUE;
}

//---------------------------------------------------------------------
// unlockWrite - allows single writing thread to unlock a resource
//
// Exceptions   : NONE
// Return Codes : TRUE (success), FALSE (failure)
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
int CRWLock::unlockWrite()
///////////////////////////////////////////////////////////////////////
{
	if (decrementWriters() == FALSE)
	{
		return FALSE;
	}

	// Readers are preferred in the following section....
	if (m_nWaitingWriters && !m_nWaitingReaders)
	{
		// when no readers are waiting... signal writers, if any
		if (!SetEvent(m_hWriterEvent)) // will release one waiting writer
		{
			return FALSE;
		}
	}
	else
	{
		while (m_nWaitingReaders > 0)
		{
			if (!SetEvent(m_hReaderEvent)) // will release ALL waiting readers
			{
				return FALSE;
			}
		}
	}
	
	return TRUE;
}

//---------------------------------------------------------------------
// waitingReader() - increments waiting reader count
//
// Exceptions   : NONE
// Return Codes : TRUE (success), FALSE (failure)
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
int CRWLock::waitingReader()
///////////////////////////////////////////////////////////////////////
{
	if (WaitForSingleObject(m_hLockCountMutex, INFINITE) != WAIT_OBJECT_0)
	{
		return FALSE;
	}

	// One more thread is waiting on read event
	m_nWaitingReaders++;

	ReleaseMutex(m_hLockCountMutex);

	return TRUE;
}

//---------------------------------------------------------------------
// incrementReaders() - decrements waiting reader count and increments
// lock count
//
// Exceptions   : NONE
// Return Codes : TRUE (success), FALSE (failure)
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
int CRWLock::incrementReaders()
///////////////////////////////////////////////////////////////////////
{
	// InterlockedIncrement() could also be used, instead of this mutex
	if (WaitForSingleObject(m_hLockCountMutex, INFINITE) != WAIT_OBJECT_0)
	{
		return FALSE;
	}

	// One more thread has obtained a read lock and is no longer waiting
	if (m_nLockCount >= 0)
	{
		m_nLockCount++;
		m_nWaitingReaders--;
	}

	ReleaseMutex(m_hLockCountMutex);

	return TRUE;
}

//---------------------------------------------------------------------
// decrementReaders() - decrements lock count
//
// Exceptions   : NONE
// Return Codes : TRUE (success), FALSE (failure)
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
int CRWLock::decrementReaders()
///////////////////////////////////////////////////////////////////////
{
	// InterlockedDecrement() could also be used, instead of this mutex
	if (WaitForSingleObject(m_hLockCountMutex, INFINITE) != WAIT_OBJECT_0)
	{
		return FALSE;
	}

	if (m_nLockCount > 0)
	{
		// One less thread holding read lock
		m_nLockCount--;
	}

	ReleaseMutex(m_hLockCountMutex);

	return TRUE;
}

//---------------------------------------------------------------------
// waitingWriter() - increments waiting writer count
//
// Exceptions   : NONE
// Return Codes : TRUE (success), FALSE (failure)
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
int CRWLock::waitingWriter()
///////////////////////////////////////////////////////////////////////
{
	if (WaitForSingleObject(m_hLockCountMutex, INFINITE) != WAIT_OBJECT_0)
	{
		return FALSE;
	}

	m_nWaitingWriters++;

	ReleaseMutex(m_hLockCountMutex);

	return TRUE;
}

//---------------------------------------------------------------------
// incrementWriters() - decrements waiting writer count and pushes
// lock count below ground level
//
// Exceptions   : NONE
// Return Codes : TRUE (success), FALSE (failure)
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
int CRWLock::incrementWriters()
///////////////////////////////////////////////////////////////////////
{
	if (WaitForSingleObject(m_hLockCountMutex, INFINITE) != WAIT_OBJECT_0)
	{
		return FALSE;
	}

	// Only one thread can obtain a write lock .. so lock count goes underground
	// InterlockedDecrement() could also be used
	if (m_nLockCount == 0)
	{
		m_nLockCount = -1;
		m_nWaitingWriters--;
	}

	ReleaseMutex(m_hLockCountMutex);

	return TRUE;
}

//---------------------------------------------------------------------
// decrementWriters() - pulls lock count to ground level
//
// Exceptions   : NONE
// Return Codes : TRUE (success), FALSE (failure)
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
int CRWLock::decrementWriters()
///////////////////////////////////////////////////////////////////////
{
	if (WaitForSingleObject(m_hLockCountMutex, INFINITE) != WAIT_OBJECT_0)
	{
		return FALSE;
	}

	if (m_nLockCount == -1)
	{
		m_nLockCount = 0;
	}

	ReleaseMutex(m_hLockCountMutex);

	return TRUE;
}

//---------------------------------------------------------------------
// getLockCount() - returns current lock count
//
// Exceptions   : NONE
// Returns      : lock count (int)
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
int CRWLock::getLockCount()
{
	int nCount = 0;

	if (WaitForSingleObject(m_hLockCountMutex, INFINITE) != WAIT_OBJECT_0)
	{
		return FALSE;
	}

	nCount = m_nLockCount;

	ReleaseMutex(m_hLockCountMutex);

	return nCount;
}


//---------------------------------------------------------------------
// getWaitingReaders() - returns current no. of threads waiting for
// read access
//
// Exceptions   : NONE
// Returns      : waiting readers (int)
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
int CRWLock::getWaitingReaders()
{
	int nCount = 0;

	if (WaitForSingleObject(m_hLockCountMutex, INFINITE) != WAIT_OBJECT_0)
	{
		return FALSE;
	}

	nCount = m_nWaitingReaders;

	ReleaseMutex(m_hLockCountMutex);

	return nCount;
}

//---------------------------------------------------------------------
// getWaitingWriters() - returns current no. of threads waiting for
// write access
//
// Exceptions   : NONE
// Returns      : waiting writers (int)
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
int CRWLock::getWaitingWriters()
{
	int nCount = 0;

	if (WaitForSingleObject(m_hLockCountMutex, INFINITE) != WAIT_OBJECT_0)
	{
		return FALSE;
	}

	nCount = m_nWaitingWriters;

	ReleaseMutex(m_hLockCountMutex);

	return nCount;
}
