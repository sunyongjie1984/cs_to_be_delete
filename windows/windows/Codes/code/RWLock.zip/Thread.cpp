// Thread.cpp: implementation of the CThread class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TestLock.h"
#include "Thread.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//---------------------------------------------------------------------
// CThread - creates shutdown event, creates thread and 
// constructs thread object
//
// Exceptions   : NONE
// Return Codes : NONE 
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
CThread::CThread()
///////////////////////////////////////////////////////////////////////
{
	// Create an event for thread shutdown
	m_hShutdownEvent = CreateEvent(NULL, 0, 0, NULL);

	// Create a thread and set it running
	m_hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadStart, (void *)this, 0, &m_lThreadId);
}

//---------------------------------------------------------------------
// ~CThread - waits for thread termination and destroys thread object
//
// Exceptions   : NONE
// Return Codes : NONE 
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
CThread::~CThread()
///////////////////////////////////////////////////////////////////////
{
	// ensure that thread has been terminated before destroying object
	shutdown();
	join();
}

//---------------------------------------------------------------------
// ThreadStart() - startup routine for thread... declared static so that
// it can be called from Win32 thread system. It just calls the run method
// of the thread object that is passed as argument.
//
// Exceptions   : NONE
// Return Codes : NONE
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
void CThread::ThreadStart(void * argument)
///////////////////////////////////////////////////////////////////////
{
	CThread * pThreadObj = (CThread *)argument;

	pThreadObj->run();

	ExitThread(0);
}


//---------------------------------------------------------------------
// run() - executes the actual work of the thread... derived classes
// can override this method, but should take care that the thread waits 
// on shutdown event
//
// Exceptions   : NONE
// Return Codes : NONE
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
void CThread::run()
///////////////////////////////////////////////////////////////////////
{
	while (WaitForSingleObject(m_hShutdownEvent, 0) != WAIT_OBJECT_0)
	{
		// do something here
		Sleep(100);
	}
}

//---------------------------------------------------------------------
// shutdown() - signals shutdown event.. so that the thread exits
//
// Exceptions   : NONE
// Return Codes : NONE
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
void CThread::shutdown()
///////////////////////////////////////////////////////////////////////
{
	SetEvent(m_hShutdownEvent);
}

//---------------------------------------------------------------------
// join() - makes current thread wait for all handles of target thread
// to be released
//
// Exceptions   : NONE
// Return Codes : NONE
//---------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
void CThread::join()
///////////////////////////////////////////////////////////////////////
{
	// thread waiting for its own handle will cause deadlock
	if (m_lThreadId == GetCurrentThreadId())
	{
		return;
	}

	while (WaitForSingleObject(m_hThread, INFINITE) != WAIT_OBJECT_0)
	{
		Sleep(1);
	}
}
