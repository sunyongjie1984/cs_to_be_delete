// TestLockDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestLock.h"
#include "TestLockDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestLockDlg dialog

CTestLockDlg::CTestLockDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestLockDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestLockDlg)
	m_nReaderThreadSelectionIndex = 0;
	m_nWriterThreadSelectionIndex = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestLockDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestLockDlg)
	DDX_LBIndex(pDX, IDC_NUM_READER_THREADS, m_nReaderThreadSelectionIndex);
	DDX_LBIndex(pDX, IDC_NUM_WRITER_THREADS, m_nWriterThreadSelectionIndex);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestLockDlg, CDialog)
	//{{AFX_MSG_MAP(CTestLockDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(ID_EXIT, OnExit)
	ON_BN_CLICKED(ID_START, OnStart)
	ON_BN_CLICKED(ID_STOP, OnStop)
	ON_LBN_SELCHANGE(IDC_NUM_READER_THREADS, OnSelchangeNumReaderThreads)
	ON_LBN_SELCHANGE(IDC_NUM_WRITER_THREADS, OnSelchangeNumWriterThreads)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestLockDlg message handlers

BOOL CTestLockDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	for (int i = MAX_READER_THREADS; i > 0; i--)
	{
		m_pcThreadObjects[i] = NULL;

		CString szTemp;
		szTemp.Format("%d", i);
		int iRetVal = static_cast<CListBox*> (GetDlgItem(IDC_NUM_READER_THREADS))->AddString(szTemp);

		if (iRetVal == LB_ERR || iRetVal == LB_ERRSPACE)
		{
			AfxMessageBox("Error!! Adding String to List box -  Aborting");
			EndDialog(FALSE);
		}
	}

	for (int j = MAX_WRITER_THREADS; j > 0; j--)
	{
		m_pcThreadObjects[j + MAX_READER_THREADS] = NULL;

		CString szTemp;
		szTemp.Format("%d", j);
		int iRetVal = static_cast<CListBox*> (GetDlgItem(IDC_NUM_WRITER_THREADS))->AddString(szTemp);

		if (iRetVal == LB_ERR || iRetVal == LB_ERRSPACE)
		{
			AfxMessageBox("Error!! Adding String to List box -  Aborting");
			EndDialog(FALSE);
		}
	}

	m_bTestStarted = FALSE;

	m_pcLock = new CRWLock;

	EnableStartButton(FALSE);
	EnableStopButton(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestLockDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else if ((nID & 0xFFF0) == SC_CLOSE)
	{
		OnExit();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestLockDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestLockDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CTestLockDlg::EnableStartButton(bool bEnable)
{
	GetDlgItem(ID_START)->EnableWindow(bEnable);
}

void CTestLockDlg::EnableStopButton(bool bEnable)
{
	GetDlgItem(ID_STOP)->EnableWindow(bEnable);
}

void CTestLockDlg::OnExit() 
{
	// TODO: Add your control notification handler code here
	OnStop();

	delete m_pcLock;

	EndDialog(ID_EXIT);
}

void CTestLockDlg::OnStart() 
{
	// TODO: Add your control notification handler code here


	if(m_bTestStarted)
	{
		OnStop();
	}

	UpdateData(true);

	pThreadArgument pArg = new threadArgument;

	pArg->pListBox  = static_cast <CListBox *> (GetDlgItem(IDC_THREAD_OUTPUT));
	pArg->pRwLock   = m_pcLock;
	
	for (int i = 0; i < (MAX_READER_THREADS - m_nReaderThreadSelectionIndex); i++)
	{
		pArg->bReader = true;
		m_pcThreadObjects[i] = new CDerivedThread((void *)pArg);
	}

	for (int j = 0; j < (MAX_WRITER_THREADS - m_nWriterThreadSelectionIndex); j++)
	{
		pArg->bReader = false;
		m_pcThreadObjects[j + i] = new CDerivedThread((void *)pArg);
	}

	m_bTestStarted = TRUE;

	EnableStopButton(TRUE);
}

void CTestLockDlg::OnStop() 
{
	// TODO: Add your control notification handler code here
	if ( !m_bTestStarted )
	{
		return;
	}

	for (int i = 0; i < (MAX_READER_THREADS - m_nReaderThreadSelectionIndex); i++)
	{
		delete m_pcThreadObjects[i];
		m_pcThreadObjects[i] = NULL;
	}

	for (int j = 0; j < (MAX_WRITER_THREADS - m_nWriterThreadSelectionIndex); j++)
	{
		delete m_pcThreadObjects[j + i];
		m_pcThreadObjects[j + i] = NULL;
	}

	m_bTestStarted = FALSE;
}

void CTestLockDlg::OnSelchangeNumReaderThreads() 
{
	// TODO: Add your control notification handler code here
	CDataExchange dx(this, TRUE);
	DDX_Check(&dx, IDC_NUM_READER_THREADS, m_nReaderThreadSelectionIndex);
}

void CTestLockDlg::OnSelchangeNumWriterThreads()
{
	// TODO: Add your control notification handler code here
	CDataExchange dx(this, TRUE);
	DDX_Check(&dx, IDC_NUM_WRITER_THREADS, m_nWriterThreadSelectionIndex);

	EnableStartButton(TRUE);
}
