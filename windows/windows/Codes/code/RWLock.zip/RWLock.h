// RWLock.h: interface for the CRWLock class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RWLOCK_H__0F267374_9905_11D3_8D3E_00105AAA7BB6__INCLUDED_)
#define AFX_RWLOCK_H__0F267374_9905_11D3_8D3E_00105AAA7BB6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRWLock  
{
public:
	int unlockWrite();
	int lockWrite();
	int unlockRead();
	int lockRead();

	CRWLock();
	virtual ~CRWLock();

	////// Accessor functions
	int getWaitingWriters();
	int getWaitingReaders();
	int getLockCount();

private:
	// Disallow copies of read write lock via copy and assignment
	CRWLock(const CRWLock&);
	operator =(const CRWLock &);

	int waitingWriter();
	int incrementWriters();
	int decrementWriters();

	int waitingReader();
	int incrementReaders();
	int decrementReaders();

	int m_nLockCount;

	int m_nWaitingWriters;
	int m_nWaitingReaders;

	HANDLE m_hReaderEvent;
	HANDLE m_hWriterEvent;
	HANDLE m_hLockCountMutex;
};

#endif // !defined(AFX_RWLOCK_H__0F267374_9905_11D3_8D3E_00105AAA7BB6__INCLUDED_)
