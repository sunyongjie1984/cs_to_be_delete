// Thread.h: interface for the CThread class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_THREAD_H__65C44176_9AA3_11D3_8D3F_00105AAA7BB6__INCLUDED_)
#define AFX_THREAD_H__65C44176_9AA3_11D3_8D3F_00105AAA7BB6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CThread  
{
public:
	CThread();
	virtual ~CThread();

	// Calling thread waits for target thread to terminate.
	virtual void join();

	// Calling thread shuts down the target thread.  
	virtual void shutdown();

protected:
	// Override this method to provide functionality to your thread.
	// This method is the content of the thread
	virtual void run();

	HANDLE	m_hShutdownEvent; // shutdown event to be monitored by the thread

	unsigned long m_lThreadId; // Thread's ID

private:
	// Disallow copies of thread via copy and assignment
	CThread(const CThread&);
	operator=(const CThread&);

	HANDLE m_hThread; // Thread's handle ... has all access permissions

	static void ThreadStart(void * argument); // startup routine callable from WIN32 thread library
};

#endif // !defined(AFX_THREAD_H__65C44176_9AA3_11D3_8D3F_00105AAA7BB6__INCLUDED_)
