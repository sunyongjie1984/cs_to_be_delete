// DerivedThread.h: interface for the CDerivedThread class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DERIVEDTHREAD_H__65C44177_9AA3_11D3_8D3F_00105AAA7BB6__INCLUDED_)
#define AFX_DERIVEDTHREAD_H__65C44177_9AA3_11D3_8D3F_00105AAA7BB6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Thread.h"
#include "RWLock.h"	// Added by ClassView

typedef struct threadArgumentTag {
	CListBox * pListBox;
	CRWLock  * pRwLock;
	bool       bReader;
}threadArgument, *pThreadArgument;

class CDerivedThread : public CThread  
{
public:

	CDerivedThread(void * pArg=NULL) 
	{ 
		pThreadArgument pArgStruct = (pThreadArgument)pArg;

		m_pcListBox =  (CListBox *)pArgStruct->pListBox;
		m_pcLock = (CRWLock *)pArgStruct->pRwLock;
		m_bReader = (bool)pArgStruct->bReader;
	}
	virtual ~CDerivedThread() {}

	static char g_szStringToUpdate[128];
	static int g_nWriteLockAccesses;
	static int g_nReadLockAccesses;

protected:
	void run();

private:
	CDerivedThread(const CDerivedThread&);
	operator=(const CDerivedThread&);

	CListBox * m_pcListBox;

	CRWLock *  m_pcLock;
	bool       m_bReader;
};

#endif // !defined(AFX_DERIVEDTHREAD_H__65C44177_9AA3_11D3_8D3F_00105AAA7BB6__INCLUDED_)
