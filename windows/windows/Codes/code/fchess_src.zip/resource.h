//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by fchess.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_ESTDLG                      130
#define IDI_WHITE                       131
#define IDI_BLACK                       132
#define IDC_CHESS                       133
#define IDC_CHESSB                      133
#define IDI_LASTB                       133
#define IDI_LASTW                       134
#define IDD_MESSAGEBAR                  136
#define IDC_CHESSW                      137
#define IDC_EFFECT                      1000
#define IDC_OTHERNAME                   1001
#define IDC_CONNECT                     1002
#define IDC_LISTEN                      1003
#define IDC_ONE                         1005
#define IDC_TWO                         1006
#define IDC_SEND                        1008
#define IDC_RECV                        1009
#define IDC_WIN_AND_LOST                1010
#define ID_GAME_NEW                     32771
#define ID_FUNCTION_SENDMESSAGETOOTHER  32772
#define ID_GAME_QUITCURRENTGAME         32773
#define IDM_BEEP                        32778
#define IDS_CONN_FAIL                   57346

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
