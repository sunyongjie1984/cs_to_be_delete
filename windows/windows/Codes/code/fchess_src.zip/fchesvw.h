// fchesvw.h : interface of the CFchessView class
//
/////////////////////////////////////////////////////////////////////////////

#define XVALUE    20
#define YVALUE	  15
#define XSTART		14
#define YSTART		14
#define XSIZE		28

#define BLACK_CHESS     1
#define WHITE_CHESS 	   2

#define I_WIN          1
#define I_LOST         2
#define NEED_TO_GO     3

typedef struct strChessPos
{
   BYTE bX,bY;
}  CHESSPOS;

#define SetQuit(CP)       (CP.bX=CP.bY=0XFF)
#define IsAskToQuit(CP)   (CP.bX==0XFF&&CP.bY==0XFF)
#define SetMessage(CP)    (CP.bX=CP.bY=0XEE)
#define IsMessage(CP)	  (CP.bX==0XEE&&CP.bY==0XEE)
#define IsValid(CP)       (CP.bX<XVALUE&&CP.bY<YVALUE)
#define MakeNew(CP)       (CP.bX=CP.bY=0XDD)
#define IsNew(CP)         (CP.bX==0XDD&&CP.bY==0XDD)

class CFchessView : public CView
{
protected: // create from serialization only
	CFchessView();
	DECLARE_DYNCREATE(CFchessView)
	void PlayMessage(void);
	BOOL m_fSound;
	int m_iTotalWin,m_iTotalLost;
// Attributes
public:
	CFchessDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFchessView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFchessView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	BYTE m_bChessArray[XVALUE][YVALUE];
	BOOL m_fFirstDeside,m_fCanDeside;
	BOOL m_fEst,m_fLastMessage;
	CTCPSocket m_tsComm;
	CHESSPOS m_CP;
	CHESSPOS m_CPLast;
protected:
    void DrawCurrent(CDC* pDC);
    void DrawBoard(CDC* pDC);
    void DrawChess(CDC* pDC);
	void ReadMessage(void);
	void AskNew(void);
	void EstNew(void);
	void SetMess(const char* pszMess);
	BOOL JudgeWin(void);
	BOOL JudgeLost(void);
	BOOL IsWin(int iChessValue);
	BOOL IsMatch(const int iX,const int iY);
	BOOL IsMatch2(const int iX,const int iY);
// Generated message map functions
protected:
	LONG OnWSARead(UINT uP,LONG lP);
	//{{AFX_MSG(CFchessView)
	afx_msg void OnGameNew();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnDestroy();
	afx_msg void OnFunctionSendMessage();
	afx_msg void OnUpdateFunctionSendMessage(CCmdUI* pCmdUI);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnAbortGame();
	afx_msg void OnUpdateAbortGame(CCmdUI* pCmdUI);
	afx_msg void OnBeep();
	afx_msg void OnUpdateBeep(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in fchesvw.cpp
inline CFchessDoc* CFchessView::GetDocument()
   { return (CFchessDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
