// messageb.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMessageBar dialog

class CMessageBar : public CDialogBar
{
// Construction
public:
	CMessageBar(CWnd* pParent = NULL);   // standard constructor
	void GetSend(CString& szSend);
	void SetRecv(CString& szRecv);
// Dialog Data
	//{{AFX_DATA(CMessageBar)
	enum { IDD = IDD_MESSAGEBAR };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMessageBar)
	protected:
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMessageBar)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
