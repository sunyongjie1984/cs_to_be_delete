// messageb.cpp : implementation file
//

#include "stdafx.h"
#include "fchess.h"
#include "messageb.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMessageBar dialog


CMessageBar::CMessageBar(CWnd* pParent /*=NULL*/)
{
	CDialogBar::CDialogBar();
}
void CMessageBar::GetSend(CString& szSend)
{
	CWnd* pWnd=GetDlgItem(IDC_SEND);
	pWnd->GetWindowText(szSend);
}
void CMessageBar::SetRecv(CString& szRecv)
{
	CWnd* pWnd=GetDlgItem(IDC_RECV);
	pWnd->SetWindowText(szRecv);
}
BEGIN_MESSAGE_MAP(CMessageBar, CDialogBar)
	//{{AFX_MSG_MAP(CMessageBar)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CMessageBar message handlers
