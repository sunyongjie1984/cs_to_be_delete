//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by tcpsock.rc
//
#define IDI_TWO                         129
#define IDD_ESTDLG                      130
#define IDI_ONE                         130
#define IDC_EFFECT                      1000
#define IDC_OTHERNAME                   1001
#define IDC_CONNECT                     1002
#define IDC_LISTEN                      1003
#define IDC_ONE                         1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
