// tcpsock.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include <afxdllx.h>

#include "winsock.h"
#include "ts.h"
#include "estdlg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

static AFX_EXTENSION_MODULE tcpsockDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("TCPSOCK.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		AfxInitExtensionModule(tcpsockDLL, hInstance);

		// Insert this DLL into the resource chain
		new CDynLinkLibrary(tcpsockDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("TCPSOCK.DLL Terminating!\n");
	}
	return 1;   // ok
}

BOOL EstComm(CTCPSocket* ptsEst,
			 SOCKET sockEst,
			 CWnd* pP,
			 LPCSTR lpszOtherName,
			 BOOL fListen)
{
	HINSTANCE hInstRes=AfxGetResourceHandle();
	AfxSetResourceHandle(tcpsockDLL.hModule);
	CEstDlg dlg(ptsEst,lpszOtherName,pP,sockEst);
	dlg.m_fInitListen=fListen;
	BOOL fOK=(dlg.DoModal()==IDOK);
	AfxSetResourceHandle(hInstRes);
	ptsEst->CloseListenSocket();
	return fOK;
}
