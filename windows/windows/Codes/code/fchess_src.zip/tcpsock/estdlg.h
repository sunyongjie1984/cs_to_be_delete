// estdlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEstDlg dialog
#ifndef __CONNDLG_H
#define __CONNDLG_H


class CEstDlg : public CDialog
{
// Construction
public:
	CEstDlg(CTCPSocket *ptsEst,LPCSTR pszON,CWnd* pParent = NULL,SOCKET sockEst=ESTSOCKET);   // standard constructor
	CTCPSocket *m_ptsEst;
	CString m_szON;
	BOOL m_fInitListen;
// Dialog Data
	//{{AFX_DATA(CEstDlg)
	CStatic	m_staOne;
	CButton	m_raConnect;
	CEdit	m_edOtherName;
	//}}AFX_DATA

protected:
    int m_iTimer;
	SOCKET m_sockEst;
    void OnOK(){OnEffect();};
	void OnCancel();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEstDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	afx_msg LONG OnWSAAccept(UINT uP,LONG lP);
	// Generated message map functions
	//{{AFX_MSG(CEstDlg)
	afx_msg void OnEffect();
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnConnect();
	afx_msg void OnListen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
#endif
