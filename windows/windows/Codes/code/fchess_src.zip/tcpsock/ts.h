#ifndef __CSOCKET_H
#define __CSOCKET_H

//extern "C" AFX_EXT_API void WINAPI InitCTCPSocket(void);
#define ESTSOCKET    0X2022

//  connect flags for connection methed
#define BLOCKING_NOTIFY      0X0001
#define THREAD_NOTIFY        0X0010
#define WSA_NOTIFY           0X0100

#define LISTEN_SIDE   0X1000
#define CONNECT_SIDE  0X0000

// define message for WSA
#define ID_THREADACCEPT    WM_USER + 0X0F00	 //  when ThreadListen
#define WSA_ACCEPT         ID_THREADACCEPT
#define WSA_READ           WM_USER + 0X0F01

class AFX_EXT_CLASS CTCPSocket
{
public:
   CTCPSocket(void);
   ~CTCPSocket(void);
   
   void InitData(HWND hWndOwner,WORD wPort,
                     BOOL fListen,WORD wFlag,
                          BYTE bMax=5,UINT uAccept=WSA_ACCEPT);
   BOOL Establish(LPCSTR lpszOtherHost=NULL);
   BOOL WSAAccept(void);
   BOOL ThreadAccept(void){m_hListenThread=NULL;return TRUE;};
   BOOL Established(HWND hWndOwner,UINT uRead=WSA_READ);
   void CancelListen(void);   // when WSA or Thread
   void Close(void);
   void CloseListenSocket(void);
   
   BOOL IsListenSide(void)
      {return m_wFlag&LISTEN_SIDE;};
   SOCKET GetCommSocket(void)
      {return (IsListenSide())?m_sockUse[1]:m_sockUse[0];};
   int Read(LPSTR pRead,DWORD dwRead);
   int Write(LPCSTR pWrite,DWORD dwWrite);

protected:
   BOOL ListenSide(void);
   BOOL ConnectSide(LPCSTR lpszServer);
   BOOL WSAListen(void);
   BOOL BSDListen(void);
   BOOL ThreadListen(void);
protected:
   HWND m_hWnd;
   HANDLE m_hListenThread;
   SOCKET m_sockUse[2];
   WORD m_wPort;
   WORD m_wFlag;
   BYTE m_bMaxListen;
   UINT m_uAccept;
   UINT m_uRead;
};

BOOL EstComm(CTCPSocket* ptsEst,
			 SOCKET sockEst=ESTSOCKET,
			 CWnd* pP=NULL,
			 LPCSTR lpszOtherName=NULL,
			 BOOL fListen=FALSE);

#endif

