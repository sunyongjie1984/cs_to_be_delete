#include "stdafx.h"
#include <winsock.h>
#include "string.h"
#include "ts.h"

struct strListen
{
   HWND hWnd;
   WORD wPort;
   BYTE bMaxListen;
   UINT uMessage;
   BOOL fDelAuto;
   SOCKET *psockUse;
};
DWORD ListenThread(strListen* pstrListen);
DWORD dwRet;

CTCPSocket::CTCPSocket(void)
{
   m_sockUse[0]=m_sockUse[1]=-1;
   m_hListenThread=NULL;
}
CTCPSocket::~CTCPSocket(void)
{
   Close();
}
void CTCPSocket::CancelListen(void)
{
   ASSERT(IsListenSide());
   ASSERT(m_wFlag&WSA_NOTIFY||m_wFlag&THREAD_NOTIFY);
   switch(m_wFlag&0X0111)
   {
	  case(WSA_NOTIFY):
	  WSAAsyncSelect(m_sockUse[0],m_hWnd,0,0);
	  closesocket(m_sockUse[0]);
	  m_sockUse[0]=-1;
	  break;
	  case(THREAD_NOTIFY):
	  if(m_hListenThread)
	  {
		 TerminateThread(m_hListenThread,0);
		 m_hListenThread=NULL;
	  }
	  break;
	  default:
	  break;
   }
   Close();
}
void CTCPSocket::Close(void)
{
   if(m_sockUse[1]>0)
	 closesocket(m_sockUse[1]);
   if(m_sockUse[0]>0)
	 closesocket(m_sockUse[0]);
   m_sockUse[0]=m_sockUse[1]=-1;
}
void CTCPSocket::InitData(HWND hWndOwner,
                          WORD wPort,
                          BOOL fListen,
                          WORD wFlag,
                          BYTE bMax,
                          UINT uAccept)
{
   Close();
   m_hWnd=hWndOwner;
   m_uAccept=uAccept;
   m_wFlag=wFlag;
   m_wPort=wPort;
   m_bMaxListen=bMax;
   m_wFlag |=( fListen )?
                 LISTEN_SIDE:CONNECT_SIDE;

}
void CTCPSocket::CloseListenSocket(void)
{
	if(!IsListenSide())
		return;
   if(m_sockUse[0]>0)
	 closesocket(m_sockUse[0]);
	m_sockUse[0]=SOCKET_ERROR;
}
BOOL CTCPSocket::Established(HWND hWndOwner,UINT uRead)
{
   ASSERT(hWndOwner);
   m_uRead=uRead;
   int iStatus=WSAAsyncSelect(GetCommSocket(),hWndOwner,
                                  m_uRead,FD_READ|FD_CLOSE);
   return !(iStatus>0);
}
BOOL CTCPSocket::Establish(LPCSTR lpszOtherHost)
{
   ASSERT(m_sockUse[0]==-1);
   if(IsListenSide())
      return ListenSide();
	else
	   {
	      ASSERT(lpszOtherHost);
	      return ConnectSide(lpszOtherHost);
	   }
}
BOOL CTCPSocket::ListenSide(void)
{
   WORD wFlag=m_wFlag;
   wFlag&=0X0111;
   switch(wFlag)
   {
	  case(BLOCKING_NOTIFY):
	  return BSDListen();
	  break;
	  case(THREAD_NOTIFY):
	  return ThreadListen();
	  break;
	  case(WSA_NOTIFY):
	  return WSAListen();
	  break;
	  default:
	  ASSERT(0);
	  break;
   }
 return FALSE;
}
BOOL CTCPSocket::WSAAccept(void)
{
   SOCKADDR_IN sinClient;
   int iLength;
   ASSERT(m_sockUse[0]!=-1);
   ASSERT(m_wFlag&WSA_NOTIFY);
   iLength=sizeof(sinClient);
   m_sockUse[1]=accept(m_sockUse[0],
                    (struct sockaddr FAR *)&sinClient,
                         (int FAR*)&iLength);
   
   if(SOCKET_ERROR==m_sockUse[1])
   {
      closesocket(m_sockUse[0]);
	  m_sockUse[0]=-1;
      return FALSE;
   }
	  else
	     return TRUE;

}
BOOL CTCPSocket::WSAListen(void)
{
   SOCKADDR_IN sinLocal;
   PHOSTENT pHost;
   char szHostName[60];
   int iStatus;
   
   m_sockUse[0]=socket(AF_INET,SOCK_STREAM,0);
   if(m_sockUse[0]<0)
      return FALSE;
   
   sinLocal.sin_family=AF_INET;
   sinLocal.sin_port=htons(m_wPort);
   
   gethostname(szHostName,60);
   pHost=gethostbyname(szHostName);
   
   if(pHost==NULL)
      return FALSE;
   
   memcpy((LPSTR)&(sinLocal.sin_addr),
             (LPSTR)pHost->h_addr,
                 pHost->h_length);
   
   iStatus=bind(m_sockUse[0],(struct sockaddr FAR*)&sinLocal,sizeof(sinLocal));
   if(iStatus<0)
   {
      closesocket(m_sockUse[0]);
	  m_sockUse[0]=-1;
      return FALSE;
   }
   
   if(0>(iStatus=listen(m_sockUse[0],m_bMaxListen)))
   {
      closesocket(m_sockUse[0]);
	  m_sockUse[0]=-1;
      return FALSE;
   }
   iStatus=WSAAsyncSelect(m_sockUse[0],m_hWnd,m_uAccept,FD_ACCEPT);
   if(iStatus>0)
   {
      closesocket(m_sockUse[0]);
	  m_sockUse[0]=-1;
      return FALSE;
   }
	  else
	  return TRUE;
}
BOOL CTCPSocket::BSDListen(void)
{
   SOCKADDR_IN sinLocal,sinClient;
   PHOSTENT pHost;
   char szHostName[60];
   int iStatus;
   int iLength;

   m_sockUse[0]=socket(AF_INET,SOCK_STREAM,0);
   if(m_sockUse[0]<0)
      return FALSE;
   
   sinLocal.sin_family=AF_INET;
   sinLocal.sin_port=htons(m_wPort);
   
   gethostname(szHostName,60);
   pHost=gethostbyname(szHostName);
   
   if(pHost==NULL)
      return FALSE;
   
   memcpy((LPSTR)&(sinLocal.sin_addr),
             (LPSTR)pHost->h_addr,
                 pHost->h_length);
   
   iStatus=bind(m_sockUse[0],(struct sockaddr FAR*)&sinLocal,sizeof(sinLocal));
   if(iStatus<0)
   {
      closesocket(m_sockUse[0]);
	  m_sockUse[0]=-1;
      return FALSE;
   }
   
   if(0>(iStatus=listen(m_sockUse[0],m_bMaxListen)))
   {
      closesocket(m_sockUse[0]);
	  m_sockUse[0]=-1;
      return FALSE;
   }
   iLength=sizeof(sinClient);
   m_sockUse[1]=accept(m_sockUse[0],
                    (struct sockaddr FAR *)&sinClient,
                         (int FAR*)&iLength);
   
   if(SOCKET_ERROR==m_sockUse[1])
   {
      closesocket(m_sockUse[0]);
	  m_sockUse[0]=-1;
      return FALSE;
   }
	  else
	     return TRUE;
}
BOOL CTCPSocket::ThreadListen(void)
{
   strListen* pstrListen=new (strListen);
   pstrListen->hWnd=m_hWnd;
   pstrListen->bMaxListen=m_bMaxListen;
   pstrListen->uMessage=m_uAccept;
   pstrListen->fDelAuto=TRUE;
   pstrListen->wPort=m_wPort;
   pstrListen->psockUse=m_sockUse;
   m_hListenThread=CreateThread(NULL,
                                0,
                                (LPTHREAD_START_ROUTINE)ListenThread,
								pstrListen,
								0,
								&dwRet);
   return (m_hListenThread!=NULL);
}
BOOL CTCPSocket::ConnectSide(LPCSTR lpszServer)
{
   //SOCKET sockConnect;
   SOCKADDR_IN sinServer;
   PHOSTENT pHost;
   int iStatus;

   sinServer.sin_family=AF_INET;
   pHost=gethostbyname(lpszServer);
   if(pHost==NULL)
      return FALSE;
   sinServer.sin_port=htons(m_wPort);
   
   memcpy(&sinServer.sin_addr,pHost->h_addr,pHost->h_length);
   m_sockUse[0]=socket(AF_INET,SOCK_STREAM,0);
   if(m_sockUse[0]<0)
   	  return FALSE;
   iStatus=connect(m_sockUse[0],(struct sockaddr*)&sinServer,sizeof(sinServer));
   if(iStatus<0)
   {
      closesocket(m_sockUse[0]);
	  m_sockUse[0]=-1;
      return FALSE;
   }
	else
	   return TRUE;
}
int CTCPSocket::Read(LPSTR pRead,DWORD dwRead)
{
   DWORD dwR=0;
   DWORD dwLeft=dwRead;
   SOCKET sockRead=GetCommSocket();
   while(dwLeft)
   {
	  dwR=recv(sockRead,pRead+dwRead-dwLeft,dwLeft,0);
	  if(dwR==-1)
	  {
	     char szError[100];
		 sprintf(szError,"%X Read Error",WSAGetLastError());
	     //AfxMessageBox(szError,MB_OK);
		 return -1;
	  }
   	  dwLeft-=dwR;
   }
   return (dwRead-dwLeft);
}
int CTCPSocket::Write(LPCSTR pWrite,DWORD dwWrite)
{
   DWORD dwW=0;
   DWORD dwLeft=dwWrite;
   SOCKET sockWrite=GetCommSocket();
   while(dwLeft)
   {
	  dwW=send(sockWrite,pWrite+dwWrite-dwLeft,dwLeft,0);
	  if(dwW==-1)
	     return -1;
   	  dwLeft-=dwW;
   }
   return (dwWrite-dwLeft);
}

DWORD ListenThread(strListen *pstrListen)
{
   SOCKADDR_IN sinLocal,sinClient;
   PHOSTENT pHost;
   char szHostName[60];
   int iStatus;
   int iLength;
   strListen strListen;
   memcpy((void*)&strListen,(void*)pstrListen,sizeof(strListen));
   if(pstrListen->fDelAuto)
      delete pstrListen;
   strListen.psockUse[0]=socket(AF_INET,SOCK_STREAM,0);
   if(strListen.psockUse[0]<0)
      {
         SendMessage(strListen.hWnd,
                     strListen.uMessage,
					 0,
                     WSAMAKESELECTREPLY(FD_ACCEPT,1));
         return 0;
	  }
   
   sinLocal.sin_family=AF_INET;
   sinLocal.sin_port=htons(strListen.wPort);
   
   gethostname(szHostName,60);
   pHost=gethostbyname(szHostName);
   
   if(pHost==NULL)
      return FALSE;
   
   memcpy((LPSTR)&(sinLocal.sin_addr),
             (LPSTR)pHost->h_addr,
                 pHost->h_length);
   
   iStatus=bind(strListen.psockUse[0],(struct sockaddr FAR*)&sinLocal,sizeof(sinLocal));
   if(iStatus<0)
   {
      closesocket(strListen.psockUse[0]);
	  strListen.psockUse[0]=-1;
      SendMessage(strListen.hWnd,
                  strListen.uMessage,
				  0,
                  WSAMAKESELECTREPLY(FD_ACCEPT,1));
	  return 0;
   }
   
   if(0>(iStatus=listen(strListen.psockUse[0],strListen.bMaxListen)))
   {
      closesocket(strListen.psockUse[0]);
	  strListen.psockUse[0]=-1;
	  SendMessage(strListen.hWnd,
                  strListen.uMessage,
				  0,
                  WSAMAKESELECTREPLY(FD_ACCEPT,1));
	  return 0;
   }
   iLength=sizeof(sinClient);
   strListen.psockUse[1]=accept(strListen.psockUse[0],
                    (struct sockaddr FAR *)&sinClient,
                         (int FAR*)&iLength);
   
   if(SOCKET_ERROR==strListen.psockUse[1])
   {
      closesocket(strListen.psockUse[0]);
	  strListen.psockUse[0]=-1;
      SendMessage(strListen.hWnd,
                  strListen.uMessage,
				  0,
                  WSAMAKESELECTREPLY(FD_ACCEPT,1));
      return 0;
   }
	  else
	  {
	     SendMessage(strListen.hWnd,
                     strListen.uMessage,
					 0,
                     WSAMAKESELECTREPLY(FD_ACCEPT,0));
         return TRUE;
	  }
}
