// estdlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "winsock.h"
#include "ts.h"
#include "estdlg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEstDlg dialog
CEstDlg::CEstDlg(CTCPSocket *ptsEst,LPCSTR pszON,CWnd* pParent /*=NULL*/,SOCKET sockEst)
	: CDialog(IDD_ESTDLG, pParent)
{
	m_ptsEst=ptsEst;
	m_szON=pszON;
	ASSERT(m_ptsEst);
	m_sockEst=sockEst;
	m_iTimer=0;
}


void CEstDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEstDlg)
	DDX_Control(pDX, IDC_ONE, m_staOne);
	DDX_Control(pDX, IDC_CONNECT, m_raConnect);
	DDX_Control(pDX, IDC_OTHERNAME, m_edOtherName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEstDlg, CDialog)
	ON_MESSAGE(WSA_ACCEPT, OnWSAAccept)
	//{{AFX_MSG_MAP(CEstDlg)
	ON_BN_CLICKED(IDC_EFFECT, OnEffect)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_CONNECT, OnConnect)
	ON_BN_CLICKED(IDC_LISTEN, OnListen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEstDlg message handlers

void CEstDlg::OnEffect() 
{
	BOOL fConnect=(1==m_raConnect.GetCheck());
	CString szOtherName;
	m_edOtherName.GetWindowText(szOtherName);
	HWND hwndParent=GetSafeHwnd();
	if(fConnect&&(0==szOtherName.GetLength()))
	    {
		   AfxMessageBox("You need input the other PC's name!",MB_OK);
		   return;
		}
	GetDlgItem(IDC_EFFECT)->EnableWindow(FALSE);
	m_ptsEst->InitData(hwndParent,ESTSOCKET,
	                         !fConnect,WSA_NOTIFY);
	if(m_ptsEst->Establish(szOtherName))
	{
		if(fConnect)
			CDialog::OnOK();
		else
		{
			SetTimer(1,500,NULL);
			m_iTimer=1;
		}
    }
	else
		AfxMessageBox("Connect Fail",MB_OK);
	if(fConnect)
		GetDlgItem(IDC_EFFECT)->EnableWindow(TRUE);
}
LONG CEstDlg::OnWSAAccept(UINT uP,LONG lP)
{
	if(m_iTimer)
	   KillTimer(1);
	GetDlgItem(IDC_EFFECT)->EnableWindow(TRUE);
	if(WSAGETSELECTERROR(lP)==0)
	{
       m_ptsEst->WSAAccept();
       CDialog::OnOK();
	}
	else
	{
		m_ptsEst->CancelListen();
	    AfxMessageBox("Connect Failed !",MB_OK);
	}
	return 0L;
}
void CEstDlg::OnCancel()
{
	if(m_iTimer)
	{
	   KillTimer(1);
	   m_iTimer=0;
	   m_ptsEst->CancelListen();
	   GetDlgItem(IDC_EFFECT)->EnableWindow(TRUE);
	}
	else
		CDialog::OnCancel();
}
BOOL CEstDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_edOtherName.SetWindowText(m_szON);
	if(m_fInitListen)
	{
		((CButton*)GetDlgItem(IDC_LISTEN))->SetCheck(1);
		m_raConnect.SetCheck(0);
	}
	else
	{
		((CButton*)GetDlgItem(IDC_LISTEN))->SetCheck(0);
		m_raConnect.SetCheck(1);
	}
	m_edOtherName.EnableWindow(m_raConnect.GetCheck());
	HICON hIcon=AfxGetApp()->LoadIcon(IDI_ONE);
	m_staOne.SetIcon(hIcon);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CEstDlg::OnTimer(UINT nIDEvent) 
{
    static BOOL bOne=TRUE;
	bOne=!bOne;
	//m_staOne.ShowWindow((bOne)?SW_SHOW:SW_HIDE);
	//m_staTwo.ShowWindow((bOne)?SW_HIDE:SW_SHOW);
	HICON hIcon=AfxGetApp()->LoadIcon((bOne)?
									  IDI_ONE:IDI_TWO);
	m_staOne.SetIcon(hIcon);
	UpdateWindow();
	CDialog::OnTimer(nIDEvent);
}

void CEstDlg::OnConnect() 
{
	m_edOtherName.EnableWindow(m_raConnect.GetCheck());
}

void CEstDlg::OnListen() 
{
	m_edOtherName.EnableWindow(m_raConnect.GetCheck());
}
