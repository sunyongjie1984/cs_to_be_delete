// fchesdoc.cpp : implementation of the CFchessDoc class
//

#include "stdafx.h"
#include "fchess.h"

#include "fchesdoc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFchessDoc

IMPLEMENT_DYNCREATE(CFchessDoc, CDocument)

BEGIN_MESSAGE_MAP(CFchessDoc, CDocument)
	//{{AFX_MSG_MAP(CFchessDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFchessDoc construction/destruction

CFchessDoc::CFchessDoc()
{
	// TODO: add one-time construction code here

}

CFchessDoc::~CFchessDoc()
{
}

BOOL CFchessDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CFchessDoc serialization

void CFchessDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CFchessDoc diagnostics

#ifdef _DEBUG
void CFchessDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CFchessDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFchessDoc commands
