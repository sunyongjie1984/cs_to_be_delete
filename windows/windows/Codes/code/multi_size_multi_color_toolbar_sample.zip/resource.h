//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ExToolBar.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_EXTOOLTYPE                  129
#define IDB_SMALL_COLOR                 130
#define IDB_SMALL_BW                    131
#define IDB_LARGE_COLOR                 136
#define IDB_LARGE_BW                    137
#define ID_FILENEW                      140
#define IDB_SM_BW                       146
#define IDB_LG_BW                       147
#define IBD_SM                          148
#define IDB_LG                          149
#define IDB_LG_DB                       150
#define IDB_SM_DB                       151
#define IDB_SM_DB_16                    152
#define IDB_LG_16                       153
#define IDB_LG_DB_16                    154
#define IDB_SM_16                       155
#define IDB_SM_BW_16                    156
#define IDB_LG_BW_16                    157
#define IDB_WND_SM_DB                   158
#define IDB_WND_LG                      159
#define IDB_WND_LG_DB                   160
#define IDB_WND_SM_BW                   161
#define IDB_WND_SM                      162
#define IDB_WND_LG_BW                   163
#define IDR_WND_TOOLBAR                 164
#define IDR_ICONTOOLBAR                 168
#define ID_SHOWTEXT                     32771
#define ID_ICONMODE                     32772
#define ID_ZONE                         32773
#define ID_MAP                          32774
#define ID_TYPE                         32775
#define ID_PROGRAM                      32776
#define ID_OPTIONS                      32777
#define ID_ALARM                        32778
#define ID_APP                          32779
#define ID_FILETYPE                     32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        170
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
