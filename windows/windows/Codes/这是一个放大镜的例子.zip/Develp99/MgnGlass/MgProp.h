
enum {RECTANGULAR,ROUND};
enum {S100,S120,S150,S180};
enum {Z15,Z20,Z25,Z30};

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// CPPSize dialog

// Easy and boreing stuff with property pages

class CPPSize : public CPropertyPage
{
	DECLARE_DYNCREATE(CPPSize)

// Construction
public:
	CPPSize();
	~CPPSize();

// Dialog Data
	//{{AFX_DATA(CPPSize)
	enum { IDD = IPP_MG_SIZE };
	int		m_size;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPPSize)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPPSize)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CPPShape dialog

class CPPShape : public CPropertyPage
{
	DECLARE_DYNCREATE(CPPShape)

// Construction
public:
	CPPShape();
	~CPPShape();

// Dialog Data
	//{{AFX_DATA(CPPShape)
	enum { IDD = IPP_MG_SHAPE };
	int		m_shape;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPPShape)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPPShape)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CPPZoom dialog

class CPPZoom : public CPropertyPage
{
	DECLARE_DYNCREATE(CPPZoom)

// Construction
public:
	CPPZoom();
	~CPPZoom();

// Dialog Data
	//{{AFX_DATA(CPPZoom)
	enum { IDD = IPP_MG_ZOOM };
	int		m_zoom;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPPZoom)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPPZoom)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CPropMagn

class CPropMagn : public CPropertySheet
{
	DECLARE_DYNAMIC(CPropMagn)

// Construction
public:
	CPropMagn(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CPropMagn(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	void GetSettings(int& nShape, int& nSize, int& nZoom);
	void SetSettings(int nShape, int nSize, int nZoom);
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropMagn)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPropMagn();

	// Generated message map functions
protected:
	//{{AFX_MSG(CPropMagn)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	CPPSize m_ppSize;
	CPPShape m_ppShape;
	CPPZoom m_ppZoom;
};

/////////////////////////////////////////////////////////////////////////////
