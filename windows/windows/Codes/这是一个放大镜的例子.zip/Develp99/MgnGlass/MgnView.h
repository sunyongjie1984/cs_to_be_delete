// MgnView.h : interface of the CMgnView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MGNVIEW_H__3E7F23D4_C579_11D2_8D0C_080009CBC4A8__INCLUDED_)
#define AFX_MGNVIEW_H__3E7F23D4_C579_11D2_8D0C_080009CBC4A8__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "ImageWnd.h"

class CMgnView : public CView
{
protected: // create from serialization only
	CMgnView();
	DECLARE_DYNCREATE(CMgnView)

// Attributes
public:
	CMgnDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMgnView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMgnView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CImageWnd m_imageWnd;
// Generated message map functions
protected:
	BOOL m_bMagn;
	//{{AFX_MSG(CMgnView)
	afx_msg void OnMagnify();
	afx_msg void OnUpdateMagnify(CCmdUI* pCmdUI);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MgnView.cpp
inline CMgnDoc* CMgnView::GetDocument()
   { return (CMgnDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MGNVIEW_H__3E7F23D4_C579_11D2_8D0C_080009CBC4A8__INCLUDED_)
