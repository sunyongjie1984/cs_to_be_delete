//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MgnGlass.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MGNGLATYPE                  129
#define IDB_BITMAP1                     130
#define IDC_CURSOR_MGNFY                147
#define IPP_MG_SHAPE                    206
#define IPP_MG_SIZE                     207
#define IPP_MG_ZOOM                     208
#define IDC_GR_MG_SHAPE                 417
#define IDC_RADIO1                      418
#define IDC_RADIO2                      419
#define IDC_RADIO3                      420
#define IDC_RADIO4                      421
#define ID_MAGNIFY                      32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
