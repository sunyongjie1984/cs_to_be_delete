// MgnDoc.cpp : implementation of the CMgnDoc class
//

#include "stdafx.h"
#include "MgnGlass.h"

#include "MgnDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMgnDoc

IMPLEMENT_DYNCREATE(CMgnDoc, CDocument)

BEGIN_MESSAGE_MAP(CMgnDoc, CDocument)
	//{{AFX_MSG_MAP(CMgnDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMgnDoc construction/destruction

CMgnDoc::CMgnDoc()
{
	// TODO: add one-time construction code here

}

CMgnDoc::~CMgnDoc()
{
}

BOOL CMgnDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMgnDoc serialization

void CMgnDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMgnDoc diagnostics

#ifdef _DEBUG
void CMgnDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMgnDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMgnDoc commands
