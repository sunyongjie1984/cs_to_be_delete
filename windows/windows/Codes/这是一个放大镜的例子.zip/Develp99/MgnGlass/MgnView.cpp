// MgnView.cpp : implementation of the CMgnView class
//

#include "stdafx.h"
#include "MgnGlass.h"

#include "MgnDoc.h"
#include "MgnView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMgnView

IMPLEMENT_DYNCREATE(CMgnView, CView)

BEGIN_MESSAGE_MAP(CMgnView, CView)
	//{{AFX_MSG_MAP(CMgnView)
	ON_COMMAND(ID_MAGNIFY, OnMagnify)
	ON_UPDATE_COMMAND_UI(ID_MAGNIFY, OnUpdateMagnify)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMgnView construction/destruction

CMgnView::CMgnView()
{
	// TODO: add construction code here
	m_bMagn = FALSE;
}

CMgnView::~CMgnView()
{
}

BOOL CMgnView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMgnView drawing

void CMgnView::OnDraw(CDC* pDC)
{
	CMgnDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

//////////////// The part bellow to demonstrate Manify Glass /////////////////////
//Drow something else here to try Magnifying Glass.
	CRect rect;
	GetClientRect(rect);
 	pDC->SetTextAlign(TA_BASELINE | TA_CENTER);
	pDC->SetTextColor(::GetSysColor(COLOR_WINDOWTEXT));
	pDC->SetBkMode(TRANSPARENT);
	CString s("Activate Magnifying Glass on toolbar first");
	pDC->TextOut((rect.right / 2), (rect.bottom / 2 - 35), s);
	s = "Left mouse button to manify";
	pDC->TextOut((rect.right / 2), (rect.bottom / 2 - 5), s);
	s = "Right mouse button for properties";
	pDC->TextOut((rect.right / 2), (rect.bottom / 2 + 25), s);
//////////////// The part above to demonstrate Manify Glass /////////////////////

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CMgnView printing

BOOL CMgnView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMgnView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMgnView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMgnView diagnostics

#ifdef _DEBUG
void CMgnView::AssertValid() const
{
	CView::AssertValid();
}

void CMgnView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMgnDoc* CMgnView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMgnDoc)));
	return (CMgnDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMgnView message handlers

void CMgnView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	//This part is critical for  Magnifying Glass.
	CRect rect;
	GetClientRect(&rect);
	m_imageWnd.Create(AfxRegisterWndClass( NULL, NULL, (HBRUSH) GetStockObject(NULL_BRUSH)), NULL, WS_CHILD, rect, this, 0xffff);
	m_imageWnd.SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);

}

void CMgnView::OnMagnify() 
{
	// TODO: Add your command handler code here
	m_bMagn = m_bMagn?FALSE:TRUE;
	m_imageWnd.ShowWindow(m_bMagn ? SW_SHOW:SW_HIDE );
}

void CMgnView::OnUpdateMagnify(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_bMagn?1:0);
}

BOOL CMgnView::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default

	//////////////// The part bellow to demonstrate Manify Glass /////////////////////
	//It is just some drowing - Magnify glass does not depend on it
	//Drow something else here to try Magnifying Glass.

	CRect rect;
	GetClientRect(&rect);

	HDC hdcMem = ::CreateCompatibleDC(0);
	CDC dcMem;
	dcMem.Attach(hdcMem);

	CBitmap bmp;
	bmp.LoadBitmap(IDB_BITMAP1);

	dcMem.SelectObject(bmp);
	
	BITMAP bitmap ;
    bmp.GetObject( sizeof(BITMAP), &bitmap ) ;

	for (int nX = 0; nX < rect.Width(); nX += bitmap.bmWidth)
			for (int nY = 0; nY < rect.Height(); nY += bitmap.bmHeight)
				pDC->BitBlt(nX, nY, bitmap.bmWidth, bitmap.bmHeight, &dcMem, 0, 0, SRCCOPY);

	dcMem.Detach();
	BOOL i = ::DeleteDC(hdcMem);

	return TRUE;
}

void CMgnView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	//This part is critical for  Magnifying Glass.
	if (m_imageWnd.m_hWnd)
	{
		CRect rect;
		GetClientRect(rect);
		m_imageWnd.MoveWindow(rect,FALSE);
	}

}
