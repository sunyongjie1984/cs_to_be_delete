#include "stdafx.h"
#include "resource.h"
//#include "ImageWnd.h"
#include "mgprop.h"

/////////////////////////////////////////////////////////////////////////////
// CPPSize property page

IMPLEMENT_DYNCREATE(CPPSize, CPropertyPage)

CPPSize::CPPSize() : CPropertyPage(CPPSize::IDD)
{
	//{{AFX_DATA_INIT(CPPSize)
	m_size = 0;
	//}}AFX_DATA_INIT
}

CPPSize::~CPPSize()
{
}

void CPPSize::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPPSize)
	DDX_Radio(pDX, IDC_RADIO1, m_size);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPPSize, CPropertyPage)
	//{{AFX_MSG_MAP(CPPSize)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPPSize message handlers
/////////////////////////////////////////////////////////////////////////////
// CPPShape property page

IMPLEMENT_DYNCREATE(CPPShape, CPropertyPage)

CPPShape::CPPShape() : CPropertyPage(CPPShape::IDD)
{
	//{{AFX_DATA_INIT(CPPShape)
	m_shape = 0;
	//}}AFX_DATA_INIT
}

CPPShape::~CPPShape()
{
}

void CPPShape::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPPShape)
	DDX_Radio(pDX, IDC_RADIO1, m_shape);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPPShape, CPropertyPage)
	//{{AFX_MSG_MAP(CPPShape)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPPShape message handlers
/////////////////////////////////////////////////////////////////////////////
// CPPZoom property page

IMPLEMENT_DYNCREATE(CPPZoom, CPropertyPage)

CPPZoom::CPPZoom() : CPropertyPage(CPPZoom::IDD)
{
	//{{AFX_DATA_INIT(CPPZoom)
	m_zoom = 0;
	//}}AFX_DATA_INIT
}

CPPZoom::~CPPZoom()
{
}

void CPPZoom::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPPZoom)
	DDX_Radio(pDX, IDC_RADIO1, m_zoom);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPPZoom, CPropertyPage)
	//{{AFX_MSG_MAP(CPPZoom)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPPZoom message handlers
/////////////////////////////////////////////////////////////////////////////
// CPropMagn

IMPLEMENT_DYNAMIC(CPropMagn, CPropertySheet)

CPropMagn::CPropMagn(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
}

CPropMagn::CPropMagn(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	AddPage(&m_ppSize);
	AddPage(&m_ppZoom);
	AddPage(&m_ppShape);
}

CPropMagn::~CPropMagn()
{
}

void CPropMagn::GetSettings(int& nShape, int& nSize, int& nZoom)
{
	nShape = m_ppShape.m_shape;
	nSize = m_ppSize.m_size;
	nZoom = m_ppZoom.m_zoom;

}

void CPropMagn::SetSettings(int nShape, int nSize, int nZoom)
{

	switch (nZoom)
	{
		case 18: m_ppZoom.m_zoom = Z15; break;
		case 20: m_ppZoom.m_zoom = Z20; break;
		case 25: m_ppZoom.m_zoom = Z25; break;
		case 30: m_ppZoom.m_zoom = Z30; break;
		default: m_ppZoom.m_zoom = Z20;
	}

	switch (nSize)
	{
		case 100: m_ppSize.m_size = S100; break;
		case 120: m_ppSize.m_size = S120; break;
		case 150: m_ppSize.m_size = S150; break;
		case 180: m_ppSize.m_size = S180; break;
		default:  m_ppSize.m_size = S100;
	}

	m_ppShape.m_shape = nShape;

}

BEGIN_MESSAGE_MAP(CPropMagn, CPropertySheet)
	//{{AFX_MSG_MAP(CPropMagn)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropMagn message handlers



