#if !defined(AFX_MYPROPERTYPAGE_H__CEB2E061_1CC8_11CF_BAF0_0000210022D0__INCLUDED_)
#define AFX_MYPROPERTYPAGE_H__CEB2E061_1CC8_11CF_BAF0_0000210022D0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "EllipseButton.h"


typedef struct DetailStruct
{
	DetailStruct()
	{
		memset(m_aliasname,0,41);
		memset(m_filename,0,161);
		memset(m_comments,0,201);

		strcpy(m_aliasname,"�����������");
		strcpy(m_comments,"�������뱾�ļ�����;");
	}

	char m_aliasname[41];
	char m_filename[161];
	char m_comments[201];

	void ToFile(CFile & m_file)
	{
		int m_len=strlen(m_aliasname);
		m_file.Write((char *)&m_len,sizeof(int));
		m_file.Write(m_aliasname,m_len);
		
		m_len=strlen(m_filename);
		m_file.Write((char *)&m_len,sizeof(int));
		m_file.Write(m_filename,m_len);
		
		m_len=strlen(m_comments);
		m_file.Write((char *)&m_len,sizeof(int));
		m_file.Write(m_comments,m_len);
	}
	
	void FromFile(CFile & m_file)
	{
		int m_len=0;
		memset(m_aliasname,0,41);
		memset(m_filename,0,161);
		memset(m_comments,0,201);

		m_file.Read((char *)&m_len,sizeof(int));
		m_file.Read(m_aliasname,m_len);
		m_file.Read((char *)&m_len,sizeof(int));
		m_file.Read(m_filename,m_len);
		m_file.Read((char *)&m_len,sizeof(int));
		m_file.Read(m_comments,m_len);
	}
}FILECOMMENT;

class CMyPropertyPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CMyPropertyPage)

public:
	CMyPropertyPage();
	~CMyPropertyPage();

	//{{AFX_DATA(CMyPropertyPage)
	enum { IDD = IDD_PROPPAGE5 };
	CRoundButton m_ctrl1;
	CEdit	m_filterctrl;
	CEdit	m_comctrl;
	CEdit	m_sliasnamectrl;
	CRoundButton m_unsecctrl;
	CRoundButton m_secctrl;
	CEdit	m_passctrl;
	CListBox	m_fileslist;
	CListBox	m_aliaslist;
	CString	m_dirname;
	CString	m_password;
	CString	m_aliasname;
	CString	m_comments;
	CString	m_filter;
	//}}AFX_DATA


	//{{AFX_VIRTUAL(CMyPropertyPage)
	public:
	virtual void OnOK();
	virtual BOOL OnKillActive();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL


protected:
	BOOL m_notinit;
	CToolTipCtrl m_tooltip;

	void DirToPanel(CString m_dir);
	BOOL IsDirExist(CString m_dir);
	BOOL FileExist(CString filename);
	CString GetFileExtname(CString m_filename);
	void SecretFile(CString filename,char *password);
	BOOL UnSecretFile(CString filename,char *password);
	void SecretDirectory(CString m_dir,char * m_pass);
	void UnSecretDirectory(CString m_dir,char * m_pass);
	void EnablePanel();
	BOOL ExistDataFile();
	void AliasnameToPanel();
	void ReleaseMem();
	void MakeTheSameList(int  m_direct);
	void NItemToPanel();
	int  FileInAliaslist(char * m_filename);
	int  AliasInAFilelist(int m_index);
	void SaveComments();
	void CheckAliasValid();
	void CreateExplain();
	void DeleteExplain();
	void ForbidUnsecFile(CString filename);
	void ForbidUnsecDirectory(CString m_dir);


protected:
	//{{AFX_MSG(CMyPropertyPage)
	afx_msg void OnBrowse();
	afx_msg void OnChangeDirname();
	afx_msg void OnSelchangeFilelist();
	afx_msg void OnSelchangeAliaslist();
	afx_msg void OnChangeAliasname();
	afx_msg void OnChangeDestination();
	afx_msg void OnSecretallfiles();
	afx_msg void OnUnsecretallfiles();
	virtual BOOL OnInitDialog();
	afx_msg void OnChangePassword();
	afx_msg void OnDblclkFilelist();
	afx_msg void OnDblclkAliaslist();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_MYPROPERTYPAGE_H__CEB2E061_1CC8_11CF_BAF0_0000210022D0__INCLUDED_)
