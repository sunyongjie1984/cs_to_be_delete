#if !defined(AFX_CHANGEPASSWORD_H__251D5544_7011_11D2_BAEF_0000210022D0__INCLUDED_)
#define AFX_CHANGEPASSWORD_H__251D5544_7011_11D2_BAEF_0000210022D0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000




class CChangePassword : public CDialog
{
public:
	CChangePassword(CWnd* pParent = NULL);   // standard constructor

	//{{AFX_DATA(CChangePassword)
	enum { IDD = IDD_PASSWORD };
	CButton	m_ok;
	CString	m_newpass;
	CString	m_conpass;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CChangePassword)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
		void EnablePanel();
		CString GetPassword();


	protected:
	CToolTipCtrl m_tooltip;
	//{{AFX_MSG(CChangePassword)
	afx_msg void OnChangeNewpassword();
	afx_msg void OnChangeConfirmpassword();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_CHANGEPASSWORD_H__251D5544_7011_11D2_BAEF_0000210022D0__INCLUDED_)
