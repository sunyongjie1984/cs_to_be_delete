#ifndef __MYPROPERTYSHEET_H__
#define __MYPROPERTYSHEET_H__

#include "MyPropertyPage1.h"
#include "PropertyPage7.h"
#include "MyPropertyPage8.h"
#include "MyPropertyPage9.h"
#include "MyPropertyPage.h"
#include "EllipseButton.h"



class CMyPropertySheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CMyPropertySheet)

public:
	CMyPropertySheet(CWnd* pWndParent = NULL);
	virtual ~CMyPropertySheet();

	//{{AFX_VIRTUAL(CMyPropertySheet)
	public:
	virtual BOOL OnInitDialog();
	protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

	
public:
	CMyPropertyPage1 *m_Page1;
	CPropertyPage7	  *m_Page7;
	CMyPropertyPage8 *m_Page8;
	CMyPropertyPage4 *m_Page4;
	CMyPropertyPage2 *m_Page2;
	CMyPropertyPage3 *m_Page3;
	CMyPropertyPage  *m_Page5;
	CMyPropertyPage9 m_Page9;

	HICON m_hIcon;
	BOOL m_ClearEmpty,m_CanExit,m_discout;
	int  m_showcmd;
	int  m_curpage;

	CObList *m_tasklist;
	char m_playorder[20];
	char m_playenable[20];


public:
	void AllocPages();
	void AddTaskBarIcon();
	void DeleteTaskbarIcon();
	void SetTaskBarIcon();
	void ShowMenu();
	void ShowHideWindow();

	void ReleaseList();
	void ListFromFile(char *m_file);
	void ListToFile(char *m_file);
	void ShowWarning();
	BOOL AutoStartup();
	void DeleteNcb();
	void DeleteFileInDir(char * dirname,char * m_ext);
	BOOL IsDiscReady();

public:
	CString m_LogoText;
	CFont m_fontLogo;

	void SetLogoFont(CString Name,int nHeight=24,int nWeight=FW_BOLD,
		BYTE bItalic=true,BYTE bUnderline=false);
	void SetLogoText(CString Text);
	void DrawLogoText();


protected:
	//{{AFX_MSG(CMyPropertySheet)
	afx_msg void OnCalendar();
	afx_msg void OnDeskmanager();
	afx_msg void OnHelpabout();
	afx_msg void OnResourcemamager();
	afx_msg void OnSpeedmodem();
	afx_msg void OnStartup();
	afx_msg LONG OnHotKey(WPARAM wParam,LPARAM lParam);
	afx_msg void OnAppExit();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnThingdispose();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnRejectdisc();
	afx_msg void OnUpdateRejectdisc(CCmdUI* pCmdUI);
	afx_msg void OnShutdownpower();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


#endif	// __MYPROPERTYSHEET_H__
