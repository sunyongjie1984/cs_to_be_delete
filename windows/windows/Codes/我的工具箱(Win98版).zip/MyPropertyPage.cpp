#include "stdafx.h"
#include "io.h"
#include "string.h"
#include "mytoolpad.h"
#include "shlobj.h"
#include "MyPropertyPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int WINAPI BrowseProc( HWND hwnd, UINT uMsg, LPARAM lParam,LPARAM lpData) ;
IMPLEMENT_DYNCREATE(CMyPropertyPage, CPropertyPage)

CMyPropertyPage::CMyPropertyPage() : CPropertyPage(CMyPropertyPage::IDD)
{
	//{{AFX_DATA_INIT(CMyPropertyPage)
	m_dirname = _T("");
	m_password = _T("");
	m_aliasname = _T("");
	m_comments = _T("");
	m_filter = _T("");
	//}}AFX_DATA_INIT

	m_notinit=TRUE;
	m_dirname=AfxGetApp()->GetProfileString("ϵͳ����","����Ŀ¼��","");
	m_filter=AfxGetApp()->GetProfileString("ϵͳ����","�ļ�������","*.son");
}

CMyPropertyPage::~CMyPropertyPage()
{
	AfxGetApp()->WriteProfileString("ϵͳ����","����Ŀ¼��",m_dirname);
	AfxGetApp()->WriteProfileString("ϵͳ����","�ļ�������",m_filter);
}

void CMyPropertyPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyPropertyPage)
	DDX_Control(pDX, IDC_BROWSE, m_ctrl1);
	DDX_Control(pDX, IDC_FILEFILTER, m_filterctrl);
	DDX_Control(pDX, IDC_DESTINATION, m_comctrl);
	DDX_Control(pDX, IDC_ALIASNAME, m_sliasnamectrl);
	DDX_Control(pDX, IDC_UNSECRETALLFILES, m_unsecctrl);
	DDX_Control(pDX, IDC_SECRETALLFILES, m_secctrl);
	DDX_Control(pDX, IDC_PASSWORD, m_passctrl);
	DDX_Control(pDX, IDC_FILELIST, m_fileslist);
	DDX_Control(pDX, IDC_ALIASLIST, m_aliaslist);
	DDX_Text(pDX, IDC_DIRNAME, m_dirname);
	DDX_Text(pDX, IDC_PASSWORD, m_password);
	DDX_Text(pDX, IDC_ALIASNAME, m_aliasname);
	DDV_MaxChars(pDX, m_aliasname, 40);
	DDX_Text(pDX, IDC_DESTINATION, m_comments);
	DDV_MaxChars(pDX, m_comments, 200);
	DDX_Text(pDX, IDC_FILEFILTER, m_filter);
	//}}AFX_DATA_MAP

	m_notinit=FALSE;
}


BEGIN_MESSAGE_MAP(CMyPropertyPage, CPropertyPage)
	//{{AFX_MSG_MAP(CMyPropertyPage)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_EN_CHANGE(IDC_DIRNAME, OnChangeDirname)
	ON_LBN_SELCHANGE(IDC_FILELIST, OnSelchangeFilelist)
	ON_LBN_SELCHANGE(IDC_ALIASLIST, OnSelchangeAliaslist)
	ON_EN_CHANGE(IDC_ALIASNAME, OnChangeAliasname)
	ON_EN_CHANGE(IDC_DESTINATION, OnChangeDestination)
	ON_BN_CLICKED(IDC_SECRETALLFILES, OnSecretallfiles)
	ON_BN_CLICKED(IDC_UNSECRETALLFILES, OnUnsecretallfiles)
	ON_EN_CHANGE(IDC_PASSWORD, OnChangePassword)
	ON_LBN_DBLCLK(IDC_FILELIST, OnDblclkFilelist)
	ON_LBN_DBLCLK(IDC_ALIASLIST, OnDblclkAliaslist)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()




int WINAPI BrowseProc(HWND hwnd,UINT msg,LPARAM lParam,LPARAM lpData)
{
	switch( msg)
	{
		case BFFM_INITIALIZED:
			SendMessage(hwnd,BFFM_SETSTATUSTEXT,0,(LPARAM)"TORONTO");
			SendMessage(hwnd,BFFM_SETSELECTION,1,(LPARAM)"C:\\");
			break ;
		case BFFM_SELCHANGED:
			SendMessage(hwnd,BFFM_SETSTATUSTEXT,0,(LPARAM)"TORONTO");
			break ;
	}
	return FALSE ;
}

void CMyPropertyPage::OnBrowse() 
{
	ITEMIDLIST *m_dirs,*m_suc;
	SHGetSpecialFolderLocation(GetSafeHwnd(),CSIDL_DESKTOP,&m_dirs);
	BROWSEINFO m_info;
	m_info.hwndOwner=GetSafeHwnd();
	m_info.pidlRoot=m_dirs;
	m_info.pszDisplayName="c:\\";
	m_info.lpszTitle="����ѡ��Ŀ¼��";
	m_info.ulFlags=0;
	m_info.lpfn=BrowseProc;
	m_info.lParam=0;
	m_info.iImage=0;
	
	m_suc=SHBrowseForFolder(&m_info);
	if(m_suc)
	{
		SaveComments();

		char m_buffer[MAX_PATH];
		SHGetPathFromIDList(m_suc,m_buffer);
		m_dirname=_T(m_buffer);
		UpdateData(FALSE);
	}
	DirToPanel(m_dirname);
	EnablePanel();
}

void CMyPropertyPage::OnChangeDirname() 
{
	if(m_notinit)
		return ;

	DirToPanel(m_dirname);
	EnablePanel();
}

void CMyPropertyPage::OnSelchangeFilelist()
{
	if(m_notinit)
		return ;

	MakeTheSameList(1);
	NItemToPanel();
	EnablePanel();
}

void CMyPropertyPage::OnSelchangeAliaslist() 
{
	if(m_notinit)
		return ;

	MakeTheSameList(2);
	NItemToPanel();
}

void CMyPropertyPage::NItemToPanel()
{
	int m_index=m_aliaslist.GetCurSel();
	if(m_index>=0)
	{
		FILECOMMENT *m_this=(FILECOMMENT *)m_aliaslist.GetItemData(m_index);
		m_aliasname=_T(m_this->m_aliasname);
		m_comments=_T(m_this->m_comments);
	}
	else
	{
		m_aliasname=_T("�������ޱ���");
		m_comments=_T("��������ע����Ϣ");
	}
	UpdateData(FALSE);
}

void CMyPropertyPage::MakeTheSameList(int m_direct)
{
	char m_name1[161];
	int  m_index;

	switch(m_direct)
	{
	case 1:			//���ļ�������
		m_index=m_fileslist.GetCurSel();
		m_fileslist.GetText(m_index,m_name1);
		m_index=FileInAliaslist(m_name1);
		m_aliaslist.SetCurSel(m_index);
		break;

	case 2:			//�ӱ������ļ�
		m_index=m_aliaslist.GetCurSel();
		m_index=AliasInAFilelist(m_index);
		m_fileslist.SetCurSel(m_index);
		break;
	}
	UpdateData(FALSE);
}

int  CMyPropertyPage::AliasInAFilelist(int m_index)
{
	int	m_number=m_fileslist.GetCount();
	char m_name[161];
	FILECOMMENT *m_this=(FILECOMMENT *)m_aliaslist.GetItemData(m_index);

	for(int i=0;i<m_number;i++)
	{
		m_fileslist.GetText(i,m_name);
		if(strcmpi(m_this->m_filename,m_name)==0)
		{
			m_index=i;
			break;
		}
	}
	return m_index;
}

int  CMyPropertyPage::FileInAliaslist(char * m_filename)
{
	int  m_index=-1;
	int	m_number=m_aliaslist.GetCount();
	for(int i=0;i<m_number;i++)
	{
		FILECOMMENT *m_this=(FILECOMMENT *)m_aliaslist.GetItemData(i);
		if(strcmpi(m_filename,m_this->m_filename)==0)
		{
			m_index=i;
			break;
		}
	}
	return m_index;
}

void CMyPropertyPage::OnChangeAliasname() 
{
	if(m_notinit)
		return ;

	UpdateData(TRUE);
	int m_index=m_aliaslist.GetCurSel();
	if(m_index>=0)
	{
		FILECOMMENT *m_this=(FILECOMMENT *)m_aliaslist.GetItemData(m_index);
		memset(m_this->m_aliasname,0,41);
		strcpy(m_this->m_aliasname,m_aliasname);
		m_aliaslist.DeleteString(m_index);
		m_aliaslist.InsertString(m_index,m_this->m_aliasname);
		m_aliaslist.SetCurSel(m_index);
		m_aliaslist.SetItemData(m_index,(DWORD)m_this);
	}
}

void CMyPropertyPage::OnChangeDestination() 
{
	if(m_notinit)
		return ;
	UpdateData(TRUE);
	int m_index=m_aliaslist.GetCurSel();
	if(m_index>=0)
	{
		FILECOMMENT *m_this=(FILECOMMENT *)m_aliaslist.GetItemData(m_index);
		memset(m_this->m_comments,0,201);
		strcpy(m_this->m_comments,m_comments);
	}
}

void CMyPropertyPage::SecretDirectory(CString m_dir,char * m_pass)
{
	struct _finddata_t FileBlock;
	CString m_fullname,m_thisdir=m_dir;
	int  m_len=m_dir.GetLength();
	char * m_buffer=m_dir.GetBuffer(m_len);
	if(m_buffer[m_len-1]!='\\')
		m_thisdir+=_T("\\");

	long handle=_findfirst(m_thisdir+_T("*.*"),&FileBlock);
	int  m_ret=0;
	while(handle>0 && m_ret==0)
	{
		m_fullname=m_thisdir+_T(FileBlock.name);
		if(FileBlock.attrib&_A_SUBDIR)
		{
			if(strcmp(FileBlock.name,".")!=0 && strcmp(FileBlock.name,"..")!=0)
				SecretDirectory(m_fullname,m_pass);
		}
		else
		{
			CString m_ext=GetFileExtname(m_fullname);
			if(m_filter.Find(m_ext)==-1)
				SecretFile(m_fullname,m_pass);
		}
		m_ret=_findnext(handle,&FileBlock);
	}
}
void CMyPropertyPage::UnSecretDirectory(CString m_dir,char * m_pass)
{
	struct _finddata_t FileBlock;
	CString m_fullname,m_thisdir=m_dir;
	int  m_len=m_dir.GetLength();
	char * m_buffer=m_dir.GetBuffer(m_len);
	if(m_buffer[m_len-1]!='\\')
		m_thisdir+=_T("\\");

	long handle=_findfirst(m_thisdir+_T("*.*"),&FileBlock);
	int  m_ret=0;
	while(handle>0 && m_ret==0)
	{
		m_fullname=m_thisdir+_T(FileBlock.name);
		if(FileBlock.attrib&_A_SUBDIR)
		{
			if(strcmp(FileBlock.name,".")!=0 && strcmp(FileBlock.name,"..")!=0)
				UnSecretDirectory(m_fullname,m_pass);
		}
		else
		{
			if(strcmpi(FileBlock.name,"readme.txt")!=0)
			{
				if(!UnSecretFile(m_fullname,m_pass))
				{
					CString m_errormsg=_T("��ѹ�ļ�\"");
					m_errormsg+=m_fullname;
					m_errormsg+=_T("\"ʧ�ܣ�\n�Ƿ������");
					if(MessageBox(m_errormsg,"���󾯸�",MB_YESNO)==IDNO)
						break;
				}
			}
		}
		m_ret=_findnext(handle,&FileBlock);
	}
}

void CMyPropertyPage::ForbidUnsecDirectory(CString m_dir)
{
	struct _finddata_t FileBlock;
	CString m_fullname,m_thisdir=m_dir;
	int  m_len=m_dir.GetLength();
	char * m_buffer=m_dir.GetBuffer(m_len);
	if(m_buffer[m_len-1]!='\\')
		m_thisdir+=_T("\\");

	long handle=_findfirst(m_thisdir+_T("*.*"),&FileBlock);
	int  m_ret=0;
	while(handle>0 && m_ret==0)
	{
		m_fullname=m_thisdir+_T(FileBlock.name);
		if(FileBlock.attrib&_A_SUBDIR)
		{
			if(strcmp(FileBlock.name,".")!=0 && strcmp(FileBlock.name,"..")!=0)
				ForbidUnsecDirectory(m_fullname);
		}
		else
			ForbidUnsecFile(m_fullname);
		m_ret=_findnext(handle,&FileBlock);
	}
}
void CMyPropertyPage::OnSecretallfiles() 
{
	UpdateData(TRUE);
	if(IsDirExist(m_dirname))
	{
		SecretDirectory(m_dirname,m_password.GetBuffer(m_password.GetLength()));
		CreateExplain();
		MessageBox("����Ŀ¼�µ������ļ����ܳɹ���","��ϲ��ϲ",MB_OK);
	}
	else
		MessageBox("�������������������·������Ȼ�����ԣ�","��������");
}

void CMyPropertyPage::OnUnsecretallfiles() 
{
	UpdateData(TRUE);
	if(IsDirExist(m_dirname))
	{
		if(GetKeyState(VK_SHIFT)<0)
			ForbidUnsecDirectory(m_dirname);
		else
			UnSecretDirectory(m_dirname,m_password.GetBuffer(m_password.GetLength()));
		DeleteExplain();
		MessageBox("����Ŀ¼�µ������ļ�������ɣ����û��ʵ��\n���ܣ���ô�ǿ���ԣ���E_Mail to :cyh_c@263.net!","��ϲ��ϲ",MB_OK);
	}
	else
		MessageBox("�������������������·������Ȼ�����ԣ�","��������");
}

BOOL CMyPropertyPage::FileExist(CString filename)
{
	BOOL ret=FALSE;
	if(filename==_T(""))
		return ret;

	HANDLE file=CreateFile(filename,0,FILE_SHARE_READ,
		NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(file!=INVALID_HANDLE_VALUE)
	{
		CloseHandle(file);
		ret=TRUE;
	}
	return ret;
}
void CMyPropertyPage::DirToPanel(CString m_dir)
{
	m_fileslist.ResetContent();
	if(!IsDirExist(m_dir))
		return;

	SaveComments();
	ReleaseMem();
	UpdateData(TRUE);
	m_aliasname=_T("");
	m_comments=_T("");
	UpdateData(FALSE);

	struct _finddata_t FileBlock;
	CString m_thisdir=m_dir;
	int  m_len=m_dir.GetLength();
	char * m_buffer=m_dir.GetBuffer(m_len);
	if(m_buffer[m_len-1]=='\\')
		m_thisdir+=_T("*.*");
	else
		m_thisdir+=_T("\\*.*");
	long handle=_findfirst(m_thisdir,&FileBlock);
	int  m_ret=0;
	while(handle>0 && m_ret==0)
	{
		if(!(FileBlock.attrib&_A_SUBDIR))
			m_fileslist.AddString(FileBlock.name);
		m_ret=_findnext(handle,&FileBlock);
	}
	if(m_fileslist.GetCount()>0)
		m_fileslist.SetCurSel(0);

	AliasnameToPanel();
	UpdateData(FALSE);
}

void CMyPropertyPage::AliasnameToPanel()
{
	int m_len=m_dirname.GetLength();
	char * m_dir=m_dirname.GetBuffer(m_len);
	CString m_buffer=m_dirname;
	if(m_dir[m_len-1]!='\\')
		m_buffer+=_T("\\");
	m_buffer+=_T("comment.son");

	ReleaseMem();
	if(FileExist(m_buffer))
	{
		CFile m_file;
		if(m_file.Open(m_buffer,CFile::modeRead|CFile::typeBinary))
		{
			int  m_number=0;
			m_file.Read((char *)&m_number,sizeof(int));
			for(int i=0;i<m_number;i++)
			{
				FILECOMMENT *m_this=new FILECOMMENT;
				m_this->FromFile(m_file);
				m_aliaslist.AddString(m_this->m_aliasname);
				m_aliaslist.SetItemData(i,(DWORD)m_this);
			}
			m_file.Close();
		}
		OnSelchangeFilelist();
		EnablePanel();
	}
}

void CMyPropertyPage::CheckAliasValid()
{
	int m_count=m_aliaslist.GetCount();
	for(int i=0;i<m_count;i++)
	{
		if(AliasInAFilelist(i)==-1)
		{
			FILECOMMENT *m_this=(FILECOMMENT *)m_aliaslist.GetItemData(i);
			delete m_this;
			m_aliaslist.DeleteString(i);
		}
	}
}

void CMyPropertyPage::SaveComments()
{
	if(!IsDirExist(m_dirname))
		return;

	int m_number=m_aliaslist.GetCount();
	if(m_number<=0)
		return;
	CheckAliasValid();
	int m_len=m_dirname.GetLength();
	char * m_dir=m_dirname.GetBuffer(m_len);
	CString m_buffer=m_dirname;
	if(m_dir[m_len-1]!='\\')
		m_buffer+=_T("\\");
	m_buffer+=_T("comment.son");
	CFile m_file;
	if(m_file.Open(m_buffer,CFile::modeCreate|CFile::modeWrite|CFile::typeBinary))
	{
		m_file.Write((char *)&m_number,sizeof(int));
		for(int i=0;i<m_number;i++)
		{
			FILECOMMENT *m_this=(FILECOMMENT *)m_aliaslist.GetItemData(i);
			m_this->ToFile(m_file);
		}
		m_file.Close();
	}
}

void CMyPropertyPage::ReleaseMem()
{
	int m_number=m_aliaslist.GetCount();
	for(int i=0;i<m_number;i++)
	{
		FILECOMMENT *m_this=(FILECOMMENT *)m_aliaslist.GetItemData(i);
		delete m_this;
	}
	m_aliaslist.ResetContent();
}


BOOL CMyPropertyPage::IsDirExist(CString m_dir)
{
	if(m_dir==_T(""))
		return FALSE;

	struct _finddata_t FileBlock;
	CString m_thisdir=m_dir;
	int  m_len=m_dir.GetLength();
	char * m_buffer=m_dir.GetBuffer(m_len);
	if(m_buffer[m_len-1]=='\\')
		m_thisdir+=_T("*.*");
	else
		m_thisdir+=_T("\\*.*");
	long handle=_findfirst(m_thisdir,&FileBlock);
	if(handle>0)
		return TRUE;
	return FALSE;
}

CString CMyPropertyPage::GetFileExtname(CString m_filename)
{				    
	char *m_buffer=m_filename.GetBuffer(m_filename.GetLength());
	char * m_ext=strrchr(m_buffer,'.');
	return CString((char *)&m_ext[1]);
}

void CMyPropertyPage::SecretFile(CString filename,char *password)
{
	SetFileAttributes(filename,FILE_ATTRIBUTE_ARCHIVE|FILE_ATTRIBUTE_NORMAL);
	CFile m_file;
	if(m_file.Open(filename,CFile::modeReadWrite|CFile::typeBinary))
	{
		char m_buffer[1001];		
		m_file.Read(m_buffer,1000);
		if(strncmp(m_buffer,"������",6)==0)
		{
			m_file.Close();
			return;
		}
		int m_len=strlen(password);
		for(int i=0;i<1000;i++)
			m_buffer[i]^=password[i%m_len];
		m_len=m_file.GetLength();
		if(m_len<1000)
		{
			m_file.SeekToEnd();
			m_file.Write(m_buffer,1000-m_len);
		}
		m_file.SeekToEnd();
		m_file.Write(m_buffer,1000);

		memset(m_buffer,0,1001);
		strcpy(m_buffer,"������");
		int *data=(int *)&m_buffer[6];
		data[0]=m_len;
		data[1]=strlen(password);
		strcpy((char *)&m_buffer[2*sizeof(int)+6],password);
		m_file.SeekToBegin();
		m_file.Write(m_buffer,1000);
		m_file.Close();
	}
}

BOOL CMyPropertyPage::UnSecretFile(CString filename,char *password)
{
	SetFileAttributes(filename,FILE_ATTRIBUTE_ARCHIVE|FILE_ATTRIBUTE_NORMAL);
 
	CFile m_file;
	if(m_file.Open(filename,CFile::modeReadWrite|CFile::typeBinary))
	{
		char m_buffer[1001];		
		memset(m_buffer,0,1001);
		m_file.Read(m_buffer,1000);
		if(strncmp(m_buffer,"������",6)!=0)
		{
			m_file.Close();
			return FALSE;
		}

		int *data=(int *)&m_buffer[6];
		int m_len=data[1];
		if((m_len!=(int)strlen(password)) || (strcmp((char *)&m_buffer[6+2*sizeof(int)],password)!=0))
		{
			m_file.Close();
			return FALSE;
		}

		m_len=data[0];
		long m_pos=m_file.Seek(-1000,CFile::end);
		int  m_number=m_file.Read(m_buffer,1000);
		int  m_passlen=strlen(password);
		for(int i=0;i<1000;i++)
			m_buffer[i]^=password[i%m_passlen];
		m_file.SeekToBegin();
		m_file.Write(m_buffer,1000);
		m_file.SetLength(m_len);
		m_file.Close();

		return TRUE;
	}
	return FALSE;
}

void CMyPropertyPage::CreateExplain()
{
	CString m_explain=m_dirname;
	int  m_len=m_dirname.GetLength();
	char * m_dir=m_dirname.GetBuffer(m_len);
	if(m_dir[m_len-1]=='\\')
		m_explain+=_T("Readme.txt");
	else
		m_explain+=_T("\\Readme.txt");

	CFile m_file;
	if(m_file.Open(m_explain,CFile::modeCreate|CFile::modeWrite))
	{
		char * m_message="��Ŀ¼�µ������ļ��ѱ������Ա�д�Ĺ��߼��ܣ�����������룬�����������ϵ��";
		m_file.Write(m_message,strlen(m_message));
		m_file.Close();
	}
}

void CMyPropertyPage::DeleteExplain()
{
	CString m_explain=m_dirname;
	int  m_len=m_dirname.GetLength();
	char * m_dir=m_dirname.GetBuffer(m_len);
	if(m_dir[m_len-1]=='\\')
		m_explain+=_T("Readme.txt");
	else
		m_explain+=_T("\\Readme.txt");

	DeleteFile(m_explain);
}

void CMyPropertyPage::ForbidUnsecFile(CString filename)
{
	SetFileAttributes(filename,FILE_ATTRIBUTE_ARCHIVE|FILE_ATTRIBUTE_NORMAL);
 
	CFile m_file;
	if(m_file.Open(filename,CFile::modeReadWrite|CFile::typeBinary))
	{
		char m_buffer[1001];		
		memset(m_buffer,0,1001);
		m_file.Read(m_buffer,1000);
		if(strncmp(m_buffer,"������",6)!=0)
		{
			m_file.Close();
			return ;
		}

		int *data=(int *)&m_buffer[6];
		char * password=(char *)&m_buffer[6+2*sizeof(int)];
		int  m_len=data[0];
		long m_pos=m_file.Seek(-1000,CFile::end);
		int  m_number=m_file.Read(m_buffer,1000);
		int  m_passlen=data[1];
		for(int i=0;i<1000;i++)
			m_buffer[i]^=password[i%m_passlen];
		m_file.SeekToBegin();
		m_file.Write(m_buffer,1000);
		m_file.SetLength(m_len);
		m_file.Close();
	}
}

BOOL CMyPropertyPage::ExistDataFile()
{
	int m_len=m_dirname.GetLength();
	char * m_dir=m_dirname.GetBuffer(m_len);
	CString m_buffer=m_dirname;
	if(m_dir[m_len-1]!='\\')
		m_buffer+=_T("\\");
	m_buffer+=_T("comment.son");
	return FileExist(m_buffer);
}

void CMyPropertyPage::EnablePanel()
{
	UpdateData(TRUE);
	BOOL m_enable=(m_dirname!=_T("")) && IsDirExist(m_dirname);
	m_passctrl.EnableWindow(m_enable);
	m_filterctrl.EnableWindow(m_enable);
	m_fileslist.EnableWindow(m_enable);
	m_aliaslist.EnableWindow(m_enable);

	m_enable=m_enable && (m_aliaslist.GetCurSel()>=0) && ExistDataFile();
	m_comctrl.EnableWindow(m_enable);
	m_sliasnamectrl.EnableWindow(m_enable);

	m_enable=((m_dirname!=_T("")) && (m_password!=_T("")));
	m_secctrl.EnableWindow(m_enable);
	m_unsecctrl.EnableWindow(m_enable);
}

BOOL CMyPropertyPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	DirToPanel(m_dirname);
	EnablePanel();

	m_tooltip.Create(this);
	m_tooltip.Activate(TRUE);
	m_tooltip.AddTool(GetDlgItem(IDC_DIRNAME),"ָ��Ҫ������Ŀ¼");
	m_tooltip.AddTool(GetDlgItem(IDC_BROWSE),"����Ҫ������Ŀ¼");
	m_tooltip.AddTool(GetDlgItem(IDC_FILELIST),"ָ��Ŀ¼�µ��ļ��б�");
	m_tooltip.AddTool(GetDlgItem(IDC_ALIASLIST),"��Ӧ���ļ��б��Ľ�ע�б�");
	m_tooltip.AddTool(GetDlgItem(IDC_PASSWORD),"���ܸ�Ŀ¼�������ļ��Ŀ���");
	m_tooltip.AddTool(GetDlgItem(IDC_FILEFILTER),"����ָ����չ�����ļ�");
	m_tooltip.AddTool(GetDlgItem(IDC_SECRETALLFILES),"�������з����������ļ�");
	m_tooltip.AddTool(GetDlgItem(IDC_UNSECRETALLFILES),"���������ļ�");
	m_tooltip.AddTool(GetDlgItem(IDC_ALIASNAME),"Ϊָ���ļ��������");
	m_tooltip.AddTool(GetDlgItem(IDC_DESTINATION),"˵��ָ���ļ�����;");

	return TRUE;
}

void CMyPropertyPage::OnChangePassword() 
{
	if(m_notinit)
		return ;
	EnablePanel();
}

void CMyPropertyPage::OnDblclkFilelist() 
{
	char m_name[161];
	int  m_index=m_fileslist.GetCurSel();
	if(m_index>=0)
	{
		m_fileslist.GetText(m_index,m_name);
		if(FileInAliaslist(m_name)!=-1)
		{
			MakeTheSameList(1);
			NItemToPanel();
		}
		else
		{
			FILECOMMENT *m_this=new FILECOMMENT;
			strcpy(m_this->m_filename,m_name);
			m_index=m_aliaslist.AddString(m_this->m_aliasname);
			m_aliaslist.SetCurSel(m_index);
			m_aliaslist.SetItemData(m_index,(DWORD)m_this);
			NItemToPanel();
			EnablePanel();
		}

		EnablePanel();
		GotoDlgCtrl(&m_sliasnamectrl);
	}
}

void CMyPropertyPage::OnOK() 
{
	SaveComments();
	ReleaseMem();
	CPropertyPage::OnOK();
}

BOOL CMyPropertyPage::OnKillActive() 
{
	if(!m_notinit)
		SaveComments();
	return CPropertyPage::OnKillActive();
}

void CMyPropertyPage::OnDblclkAliaslist() 
{
	EnablePanel();
	GotoDlgCtrl(&m_sliasnamectrl);
}

BOOL CMyPropertyPage::PreTranslateMessage(MSG* pMsg) 
{
	m_tooltip.RelayEvent(pMsg);
	return CPropertyPage::PreTranslateMessage(pMsg);
}
