#include "stdafx.h"
#include "MyToolPad.h"
#include "io.h"
#include <direct.h>
#include "MyPropertySheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


BEGIN_MESSAGE_MAP(CMyToolPadApp, CWinApp)
	//{{AFX_MSG_MAP(CMyToolPadApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()


CMyToolPadApp::CMyToolPadApp()
{
}

CMyToolPadApp theApp;


BOOL CMyToolPadApp::InitInstance()
{
	if(HavePrevInstance())
	{
		if(MessageBox(NULL,"���Ѿ������˱������һ����������������\n����ǰ�������ر��˱����򣬵����˱��Ի�\n��ĳ��֣��Ƿ�ǿ��������","",MB_YESNO)!=IDYES)
			return FALSE;
	}
	m_atom=GlobalAddAtom("�����ԵĹ���");
	Enable3dControlsStatic();

	CMyPropertySheet propSheet;
	m_pMainWnd = &propSheet;
	propSheet.SetLogoText("�����Ա�д");
	propSheet.DoModal();
	if(propSheet.m_ClearEmpty)
		DeleteEmptyDir();

	GlobalDeleteAtom(m_atom);
	return FALSE;
}

BOOL CMyToolPadApp::FileIsEmpty(char * m_filename)
{
	CFile m_file;
	if(m_file.Open(m_filename,CFile::modeRead|CFile::typeBinary))
	{
		DWORD m_len=m_file.GetLength();
		m_file.Close();
		return (m_len==0);
	}
	return FALSE;
}

//ָ��Ŀ¼���е��ļ���
int  CMyToolPadApp::DirHasFiles(char *name)
{
	struct _finddata_t FileBlock;
	char *findfile=new char[strlen(name)+10];
	wsprintf(findfile,"%s\\*.*",name);
	long handle=_findfirst(findfile,&FileBlock);
	int  number=0,ret=0;

	while(handle>0 && ret==0)
	{
		if(!(FileBlock.attrib&_A_SUBDIR))
			number++;
		ret=_findnext(handle,&FileBlock);
	}
	delete findfile;
	return number;
}

//ָ��Ŀ¼���е���Ŀ¼��
int  CMyToolPadApp::DirHasSubdir(char *name)	   
{
	struct _finddata_t FileBlock;
	char *findfile=new char[strlen(name)+10];
	wsprintf(findfile,"%s\\*.*",name);
	long handle=_findfirst(findfile,&FileBlock);
	int  number=0,ret=0;

	while(handle>0 && ret==0)
	{
		if((FileBlock.attrib&_A_SUBDIR) && (strcmp(FileBlock.name,".")!=0) && (strcmp(FileBlock.name,"..")!=0))
			number++;
		ret=_findnext(handle,&FileBlock);
	}
	delete findfile;
	return number;
}


void CMyToolPadApp::DeleteEmptyDir()
{
	if(MessageBox(NULL,"�Ƿ��������Ӳ���еĿ�Ŀ¼�Ϳ��ļ���","����ȷ��",MB_YESNO)!=IDYES)
		return;

	char diskbuf[10];
	for(int i=0;i<26;i++)
	{
		wsprintf(diskbuf,"%c:\\",'A'+i);
		WORD ret=GetDriveType(diskbuf);
		switch(ret)
		{
		case DRIVE_FIXED:
		case DRIVE_REMOTE:
		case DRIVE_RAMDISK:
			wsprintf(diskbuf,"%c:",'A'+i);
			DeleteDir(diskbuf);
			break;
		}
	}
}

void CMyToolPadApp::DeleteDir(char *m_name)
{
	char findfile[255];
	GetWindowsDirectory(findfile,255);
	if(strcmpi(findfile,m_name)==0)
		return;

	struct _finddata_t FileBlock;
	wsprintf(findfile,"%s\\*.*",m_name);
	long handle=_findfirst(findfile,&FileBlock);
	int  ret=0;

	while(handle>0 && ret==0)
	{
		wsprintf(findfile,"%s\\%s",m_name,FileBlock.name);
		if(FileBlock.attrib & _A_SUBDIR)
		{
			if(strcmp(FileBlock.name,".")!=0 && strcmp(FileBlock.name,"..")!=0)
			{
				DeleteDir(findfile);
				if(DirHasFiles(findfile)==0 && DirHasSubdir(findfile)==0)
					_rmdir(findfile);
			}
		}
		else
		{
			if(FileIsEmpty(findfile))
			{
				SetFileAttributes(findfile,FILE_ATTRIBUTE_ARCHIVE|FILE_ATTRIBUTE_NORMAL);
				DeleteFile(findfile);
			}
		}
		ret=_findnext(handle,&FileBlock);
	}

	if(DirHasFiles(m_name)==0 && DirHasSubdir(m_name)==0)
		_rmdir(m_name);
}

BOOL CMyToolPadApp::HavePrevInstance()
{
	ATOM m_atom=GlobalFindAtom("�����ԵĹ���");
	return (m_atom!=NULL);
}