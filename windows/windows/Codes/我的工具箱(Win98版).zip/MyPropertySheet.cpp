#include "stdafx.h"
#include "resource.h"
#include "mmsystem.h"
#include "MyPropertySheet.h"
#include "io.h"


#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif


CMyPropertySheet *m_sheet=NULL;

IMPLEMENT_DYNAMIC(CMyPropertySheet, CPropertySheet)


CMyPropertySheet::CMyPropertySheet(CWnd* pWndParent)
	 : CPropertySheet(IDS_PROPSHT_CAPTION, pWndParent)
{
	m_sheet=this;
	CPropertyPage *m_pages[7];
	AllocPages();
	m_pages[0]=m_Page1;
	m_pages[1]=m_Page7;
	m_pages[2]=m_Page8;
	m_pages[3]=m_Page4;
	m_pages[4]=m_Page2;
	m_pages[5]=m_Page3;
	m_pages[6]=m_Page5;
	for(int i=0;i<7;i++)
	{
		int m_index=m_playorder[i]-'1';
		if(m_playenable[i]=='2')
			AddPage(m_pages[m_index]);
	}

	AddPage(&m_Page9);
	m_curpage=AfxGetApp()->GetProfileInt("ϵͳ����","��ǰҳ",0);
	SetActivePage(m_curpage);

	m_psh.dwFlags|=PSH_NOAPPLYNOW;
	m_psh.dwFlags&=(~PSH_HASHELP);

	m_hIcon = AfxGetApp()->LoadIcon(IDI_DEFRAG);
	m_ClearEmpty=AfxGetApp()->GetProfileInt("ϵͳ����","�����Ŀ¼",FALSE);
	m_discout=FALSE;
	m_CanExit=FALSE;
	m_tasklist=NULL;
	ListFromFile("c:\\My Documents\\tasklist.dat");
}

void CMyPropertySheet::AllocPages()
{
	m_Page1=NULL;
	m_Page7=NULL;
	m_Page8=NULL;
	m_Page4=NULL;
	m_Page2=NULL;
	m_Page3=NULL;
	m_Page5=NULL;
	
	CString m_temp=AfxGetApp()->GetProfileString("ϵͳ����","��������","1234567");
	strcpy(m_playorder,m_temp);
	m_temp=AfxGetApp()->GetProfileString("ϵͳ����","��������","2222222");
	strcpy(m_playenable,m_temp);

	for(int i=0;i<7;i++)
	{
		int m_index=m_playorder[i]-'1';
		if(m_playenable[i]=='2')
		{
			switch(m_index)
			{
			case 0:
				m_Page1=new CMyPropertyPage1;
				break;
			case 1:
				m_Page7=new CPropertyPage7;
				break;
			case 2:
				m_Page8=new CMyPropertyPage8;
				break;
			case 3:
				m_Page4=new CMyPropertyPage4;
				break;
			case 4:
				m_Page3=new CMyPropertyPage3;
				break;
			case 5:
				m_Page2=new CMyPropertyPage2;
				break;
			case 6:
				m_Page5=new CMyPropertyPage;
				break;
			}
		}
	}
}

CMyPropertySheet::~CMyPropertySheet()
{
	AfxGetApp()->WriteProfileInt("ϵͳ����","�����Ŀ¼",m_ClearEmpty);
	AfxGetApp()->WriteProfileInt("ϵͳ����","��ǰҳ",m_curpage);
	AfxGetApp()->WriteProfileString("ϵͳ����","��������",m_playorder);
	AfxGetApp()->WriteProfileString("ϵͳ����","��������",m_playenable);
	ListToFile("c:\\My Documents\\tasklist.dat");
	ReleaseList();
}


BEGIN_MESSAGE_MAP(CMyPropertySheet, CPropertySheet)
	//{{AFX_MSG_MAP(CMyPropertySheet)
	ON_COMMAND(ID_CALENDAR, OnCalendar)
	ON_COMMAND(ID_DESKMANAGER, OnDeskmanager)
	ON_COMMAND(ID_HELPABOUT, OnHelpabout)
	ON_COMMAND(ID_RESOURCEMAMAGER, OnResourcemamager)
	ON_COMMAND(ID_SPEEDMODEM, OnSpeedmodem)
	ON_COMMAND(ID_STARTUP, OnStartup)
	ON_MESSAGE(WM_HOTKEY,OnHotKey)
	ON_COMMAND(ID_APP_EXIT, OnAppExit)
	ON_WM_SYSCOMMAND()
	ON_COMMAND(ID_THINGDISPOSE, OnThingdispose)
	ON_WM_TIMER()
	ON_COMMAND(ID_REJECTDISC, OnRejectdisc)
	ON_UPDATE_COMMAND_UI(ID_REJECTDISC, OnUpdateRejectdisc)
	ON_COMMAND(ID_SHUTDOWNPOWER, OnShutdownpower)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



BOOL CMyPropertySheet::OnInitDialog() 
{
	BOOL bResult=CPropertySheet::OnInitDialog();

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);
	SetLogoFont("����",24,FW_BOLD,TRUE);

	CWnd *m_wnd=GetDlgItem(IDHELP);
	if(m_wnd!=NULL)
	{
		m_wnd->EnableWindow(FALSE);
		m_wnd->SetWindowText("��������");
	}
	HWND hWnd=::GetDlgItem(m_hWnd,IDOK);
	if(hWnd!=NULL)
		::SetWindowText(hWnd,"�˳�ϵͳ");
	hWnd=::GetDlgItem(m_hWnd,IDCANCEL);
	if(hWnd!=NULL)
		::SetWindowText(hWnd,"���ش���");

	AddTaskBarIcon();
	RegisterHotKey(GetSafeHwnd(),1000,MOD_WIN,0X41);
	RegisterHotKey(GetSafeHwnd(),1001,MOD_WIN,0X4F);
	RegisterHotKey(GetSafeHwnd(),1002,MOD_WIN,0X53);
	RegisterHotKey(GetSafeHwnd(),1003,MOD_WIN,0X58);
	RegisterHotKey(GetSafeHwnd(),1004,MOD_WIN,0X5A);
	m_showcmd=SW_HIDE;
	CenterWindow();
	SetTimer(100,100,NULL);
	SetTimer(200,200,NULL);

	return bResult;
}

void CMyPropertySheet::AddTaskBarIcon()
{  
	NOTIFYICONDATA nid;
	nid.cbSize=sizeof(NOTIFYICONDATA);
	nid.hWnd=GetSafeHwnd();
	nid.uID=0;
	nid.uFlags=NIF_MESSAGE;
	strcpy(nid.szTip,"�����Ա�Ĺ��߳���");
	nid.uCallbackMessage=WM_COMMAND;
	Shell_NotifyIcon(NIM_ADD,&nid);
	SetTaskBarIcon();
}

void CMyPropertySheet::DeleteTaskbarIcon()
{  
	NOTIFYICONDATA nid;
	nid.cbSize=sizeof(NOTIFYICONDATA);
	nid.hWnd=GetSafeHwnd();
	nid.uID=0;
	nid.uFlags=NULL;
	Shell_NotifyIcon(NIM_DELETE,&nid);
	SetTaskBarIcon();
}

void CMyPropertySheet::SetTaskBarIcon()
{
	NOTIFYICONDATA nid;
	nid.cbSize=sizeof(NOTIFYICONDATA);
	nid.hWnd=GetSafeHwnd();
	nid.uID=0;
	nid.uFlags=NIF_ICON|NIF_TIP;
	nid.hIcon=(HICON)LoadImage(AfxGetInstanceHandle(),
			MAKEINTRESOURCE(IDI_SHOUHUO),IMAGE_ICON,16,16,NULL);
	lstrcpy(nid.szTip,"�����Ա�Ĺ��߳���");
	Shell_NotifyIcon(NIM_MODIFY,&nid);
}


void CMyPropertySheet::OnSysCommand(UINT nID, LPARAM lParam) 
{
	WPARAM m_close=SC_CLOSE;
	if(nID==m_close && !m_CanExit)
	{
		m_showcmd=SW_HIDE;
		ShowHideWindow();
		return ;
	}

	DeleteTaskbarIcon();
	CPropertySheet::OnSysCommand(nID, lParam);
}

BOOL CMyPropertySheet::OnCommand(WPARAM wParam, LPARAM lParam) 
{	
	WPARAM m_close=WM_DESTROY;
	if(wParam==m_close && !m_CanExit)
	{
		m_showcmd=SW_HIDE;
		m_curpage=GetActiveIndex();
		ShowHideWindow();
		return TRUE;
	}

	if(wParam==0)
	{
		switch(lParam)
		{
		case WM_LBUTTONDOWN:
			m_showcmd=(m_showcmd==SW_HIDE)?SW_SHOW:SW_HIDE;
			m_curpage=GetActiveIndex();
			ShowHideWindow();
			break;
		case WM_RBUTTONDOWN:
			ShowMenu();
			break;
		}
		return TRUE;
	}

	DeleteTaskbarIcon();
	return CPropertySheet::OnCommand(wParam, lParam);
}

void CMyPropertySheet::ShowMenu()
{
	CMenu m_menu;
	m_menu.CreatePopupMenu();
	m_menu.AppendMenu(MF_ENABLED,ID_HELPABOUT,"����ϵͳ");
	if(m_discout)
		m_menu.AppendMenu(MF_ENABLED,ID_REJECTDISC,"�رչ���");
	else
		m_menu.AppendMenu(MF_ENABLED,ID_REJECTDISC,"��������");

	m_menu.AppendMenu(MF_ENABLED,ID_SHUTDOWNPOWER,"����ϵͳ");
	m_menu.AppendMenu(MF_ENABLED,MF_SEPARATOR);
	m_menu.AppendMenu(MF_ENABLED,ID_DESKMANAGER,"�������");
	m_menu.AppendMenu(MF_ENABLED,ID_RESOURCEMAMAGER,"���Ϲ���");
	m_menu.AppendMenu(MF_ENABLED,ID_CALENDAR,"��������");
	m_menu.AppendMenu(MF_ENABLED,ID_STARTUP,"��������");
	m_menu.AppendMenu(MF_ENABLED,ID_SPEEDMODEM,"����MODEM");
	m_menu.AppendMenu(MF_ENABLED,ID_THINGDISPOSE,"��������");
	m_menu.AppendMenu(MF_ENABLED,MF_SEPARATOR);
	m_menu.AppendMenu(MF_ENABLED,ID_APP_EXIT,"�˳�ϵͳ");
	CPoint m_point;
	GetCursorPos(&m_point);
	m_menu.TrackPopupMenu(TPM_LEFTALIGN,m_point.x,m_point.y,this);
}

void CMyPropertySheet::ShowHideWindow()
{
	AddTaskBarIcon();
	ShowWindow(m_showcmd);
	if(m_showcmd==SW_SHOW)
	{
		SetWindowPos(&CWnd::wndTopMost,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);
		SetWindowPos(&CWnd::wndNoTopMost,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);
		SetForegroundWindow();
		SetActivePage(m_curpage);
	}
}
void CMyPropertySheet::OnCalendar() 
{
	m_showcmd=SW_SHOW;
	m_curpage=3;
	ShowHideWindow();
}
void CMyPropertySheet::OnDeskmanager() 
{
	m_showcmd=SW_SHOW;
	m_curpage=0;
	ShowHideWindow();
}
void CMyPropertySheet::OnHelpabout() 
{
	m_showcmd=SW_SHOW;
	m_curpage=6;
	ShowHideWindow();
}
void CMyPropertySheet::OnResourcemamager() 
{
	m_showcmd=SW_SHOW;
	m_curpage=4;
	ShowHideWindow();
}
void CMyPropertySheet::OnSpeedmodem() 
{
	m_showcmd=SW_SHOW;
	m_curpage=2;
	ShowHideWindow();
}
void CMyPropertySheet::OnStartup() 
{
	m_showcmd=SW_SHOW;
	m_curpage=1;
	ShowHideWindow();
}

void CMyPropertySheet::OnThingdispose() 
{
	m_showcmd=SW_SHOW;
	m_curpage=5;
	ShowHideWindow();
}

LONG CMyPropertySheet::OnHotKey(WPARAM wParam,LPARAM lParam)
{
	switch(wParam)
	{
	case 1000:
		m_showcmd=(m_showcmd==SW_SHOW)?SW_HIDE:SW_SHOW;
		ShowHideWindow();
		break;

	case 1001:
		OnRejectdisc();
		break;

	case 1002:
		OnShutdownpower();
		break;

	case 1003:
		OnAppExit();
		break;

	case 1004:
		DeleteNcb();
		break;
	}
	return 1;
}
 

void CMyPropertySheet::OnAppExit() 
{
	m_CanExit=TRUE;
	DeleteTaskbarIcon();
	PostMessage(WM_CLOSE,0,0L);
}

void CMyPropertySheet::ReleaseList()
{
	if(!m_tasklist)
		return;

	if(!m_tasklist->IsEmpty())
	{
		CEverydayTask *m_task=(CEverydayTask *)m_tasklist->RemoveHead();
		while(m_task)
		{
			delete m_task;
			m_task=NULL;
			if(!m_tasklist->IsEmpty())
				m_task=(CEverydayTask *)m_tasklist->RemoveHead();
		}
	}
	delete m_tasklist;
}

void CMyPropertySheet::ListFromFile(char *m_filename)
{
	ReleaseList();
	m_tasklist=new CObList;

	CFile m_file;
	if(m_file.Open(m_filename,CFile::modeRead|CFile::typeBinary))
	{
		int  m_num=0;
		m_file.Read((char *)&m_num,sizeof(int));
		for(int i=0;i<m_num;i++)
		{
			CEverydayTask *m_task=new CEverydayTask;
			m_task->FromFile(m_file);
			if(!m_task->KeepInQuene())
				delete m_task;
			else
				m_tasklist->AddTail(m_task);
		}
		m_file.Close();
	}
}

void CMyPropertySheet::ListToFile(char *m_filename)
{
	CFile m_file;
	if(m_file.Open(m_filename,CFile::modeCreate|CFile::modeWrite|CFile::typeBinary))
	{
		int  m_num=m_tasklist->GetCount();
		m_file.Write((char *)&m_num,sizeof(int));
		POSITION m_pos;
		for(int i=0;i<m_num;i++)
		{
			m_pos=m_tasklist->FindIndex(i);
			if(m_pos!=NULL)
			{
				CEverydayTask *m_task=(CEverydayTask *)m_tasklist->GetAt(m_pos);
				if(m_task)
					m_task->ToFile(m_file);
			}
		}
		m_file.Close();
	}
}

BOOL CMyPropertySheet::AutoStartup()
{
	int m_pass=(int)(GetTickCount()/(DWORD)1000);
	return (m_pass<180);
}

void CMyPropertySheet::OnTimer(UINT nIDEvent) 
{
	KillTimer(nIDEvent);
	switch(nIDEvent)
	{
	case 100:
		ShowWarning();
		if(m_tasklist->GetCount()!=0)
			SetTimer(100,60000,NULL);
		break;

	case 200:
		if(AutoStartup())
		{
//			DeleteNcb();
			ShowHideWindow();
		}
		break;
	}
	
	CPropertySheet::OnTimer(nIDEvent);
}

void CMyPropertySheet::ShowWarning()
{
	int m_count=m_tasklist->GetCount();
	POSITION m_pos;
	for(int i=0;i<m_count;i++)
	{
		m_pos=m_tasklist->FindIndex(i);
		if(m_pos!=NULL)
		{
			CEverydayTask * m_task=(CEverydayTask *)m_tasklist->GetAt(m_pos);
			if(m_task->ReachTime())
				MessageBox(m_task->m_content);
		}
	}
}

//���������Ƿ��й��̻��߹����Ƿ�׼����
BOOL CMyPropertySheet::IsDiscReady()
{
	MCI_STATUS_PARMS mciStatusParms;
	mciStatusParms.dwCallback = (DWORD)GetSafeHwnd();
	mciStatusParms.dwItem  =MCI_STATUS_READY;
	mciStatusParms.dwReturn=0;
	mciSendCommand(MCI_DEVTYPE_CD_AUDIO,MCI_STATUS,MCI_STATUS_ITEM,(DWORD)&mciStatusParms);
	return mciStatusParms.dwReturn;
}

void CMyPropertySheet::OnRejectdisc()
{
	char retbuf[60];
	m_discout=IsDiscReady();
	if(m_discout)
		mciSendString("set cdaudio door open",retbuf,60,NULL);
	else
		mciSendString("set cdaudio door closed",retbuf,60,NULL);
	AddTaskBarIcon();
}

void CMyPropertySheet::OnUpdateRejectdisc(CCmdUI* pCmdUI) 
{
	if(m_discout)
		pCmdUI->SetText("�رչ���");
	else
		pCmdUI->SetText("��������");
}

void CMyPropertySheet::OnShutdownpower() 
{
	SetSystemPowerState(TRUE,TRUE);
}

void CMyPropertySheet::DeleteNcb()
{
	DeleteFileInDir("e:\\vcwork",".ncb;.opt;.plg");
	MessageBox("����������VC��ncb�ļ����˴�����","����ȷ��",MB_OK);
}

void CMyPropertySheet::DeleteFileInDir(char * dirname,char * m_ext)
{
	char findfile[255];
	struct _finddata_t FileBlock;
	int  m_len=strlen(dirname);
	if(dirname[m_len-1]=='\\')
		wsprintf(findfile,"%s*.*",dirname);
	else
		wsprintf(findfile,"%s\\*.*",dirname);
	long handle=_findfirst(findfile,&FileBlock);
	int  ret=0;

	while(handle>0 && ret==0)
	{
		wsprintf(findfile,"%s\\%s",dirname,FileBlock.name);
		if(FileBlock.attrib & _A_SUBDIR)
		{
			if(strcmp(FileBlock.name,".")!=0 && strcmp(FileBlock.name,"..")!=0)
				DeleteFileInDir(findfile,m_ext);
		}
		else
		{
			m_len=strlen(findfile);
			char * m_buffer=strrchr(findfile,'.');
			if(m_buffer)
			{
				char *m_addr=strstr(m_ext,m_buffer);
				if(m_addr!=0)
				{
					SetFileAttributes(findfile,FILE_ATTRIBUTE_ARCHIVE|FILE_ATTRIBUTE_NORMAL);
					DeleteFile(findfile);
				}
			}
		}
		ret=_findnext(handle,&FileBlock);
	}
}



void CMyPropertySheet::SetLogoText(CString Text)
{
	m_LogoText=Text;
}

void CMyPropertySheet::SetLogoFont(CString Name,int nHeight,
	int nWeight,BYTE bItalic,BYTE bUnderline)
{
	if(m_fontLogo.m_hObject)
		m_fontLogo.Detach();
	m_fontLogo.CreateFont(nHeight, 0, 0, 0, nWeight, bItalic, bUnderline,0,0,0,0,0,0, Name);
}

void CMyPropertySheet::DrawLogoText()
{
	if(m_LogoText.IsEmpty()) return;

	CPaintDC dc(this);
	CRect rectTabCtrl;
	GetTabControl()->GetWindowRect(rectTabCtrl);
	ScreenToClient(rectTabCtrl);

	CRect rectOk;
	GetDlgItem(IDOK)->GetWindowRect(rectOk);
	ScreenToClient(rectOk);

	dc.SetBkMode(TRANSPARENT);

	CRect rectText;
	rectText.left = rectTabCtrl.left;
	rectText.top = rectOk.top;
	rectText.bottom = rectOk.bottom;
	rectText.right = rectOk.left;

	CFont * OldFont = dc.SelectObject(&m_fontLogo);
	COLORREF OldColor = dc.SetTextColor( ::GetSysColor( COLOR_3DHILIGHT));

	dc.DrawText( m_LogoText, rectText + CPoint(1,1), DT_SINGLELINE | DT_LEFT | DT_VCENTER);
	dc.SetTextColor( ::GetSysColor( COLOR_3DSHADOW));
	dc.DrawText( m_LogoText, rectText, DT_SINGLELINE | DT_LEFT | DT_VCENTER);

	dc.SetTextColor( OldColor);
	dc.SelectObject(OldFont);
}

void CMyPropertySheet::OnPaint() 
{
	DrawLogoText();
}
