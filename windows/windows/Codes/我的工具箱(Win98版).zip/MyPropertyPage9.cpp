#include "stdafx.h"
#include "MyToolPad.h"
#include "MyPropertyPage9.h"
#include "MyPropertySheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


extern CMyPropertySheet *m_sheet;
IMPLEMENT_DYNCREATE(CMyPropertyPage9,CPropertyPage)


CMyPropertyPage9::CMyPropertyPage9() : CPropertyPage(CMyPropertyPage9::IDD)
{
	//{{AFX_DATA_INIT(CMyPropertyPage9)
	//}}AFX_DATA_INIT
}

CMyPropertyPage9::~CMyPropertyPage9()
{
}

void CMyPropertyPage9::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyPropertyPage9)
	DDX_Control(pDX, IDC_EMAIL, m_email);
	DDX_Control(pDX, IDC_CONFIGRECT, m_signalrect);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyPropertyPage9, CPropertyPage)
	//{{AFX_MSG_MAP(CMyPropertyPage9)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CMyPropertyPage9::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	m_email.SetURL(_T("mailto:cyh_c@263.net"));
	m_email.SetUnderline(TRUE);
	m_email.SetLinkCursor(AfxGetApp()->LoadCursor(IDC_CATCHCUR));

	CRect m_rect;
	m_signalrect.GetWindowRect(&m_rect);
	m_signalrect.ShowWindow(SW_HIDE);
	ScreenToClient(&m_rect);
	
	if(m_check.Create(m_rect,this,3001))
	{
		m_check.SetParams(RGB(0,128,128),RGB(255,255,255),RGB(128,255,0),IDC_CATCHCUR,25);
		char m_titlename[7][20]={
			"�������","������","��������","��������","���Ϲ���","�¼�����","�ļ�����"};
		for(int i=0;i<7;i++)
		{
			m_check.AddString(m_titlename[m_sheet->m_playorder[i]-'1']);
			m_check.SetItemData(i,m_sheet->m_playorder[i]);

			if(m_sheet->m_playenable[i]=='2')
				m_check.SetCheck(i,1);
		}
	}

	return TRUE;
}

BOOL CMyPropertyPage9::OnKillActive() 
{
	for(int i=0;i<7;i++)
	{
		m_sheet->m_playorder[i]=(char)m_check.GetItemData(i);
		if(m_check.GetCheck(i)==1)
			m_sheet->m_playenable[i]='2';
		else
			m_sheet->m_playenable[i]='1';
	}
	return CPropertyPage::OnKillActive();
}
