#include "stdafx.h"
#include "MyToolPad.h"
#include "MyToolPadDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CMyToolPadDlg::CMyToolPadDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyToolPadDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyToolPadDlg)
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMyToolPadDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyToolPadDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMyToolPadDlg, CDialog)
	//{{AFX_MSG_MAP(CMyToolPadDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CMyToolPadDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}


void CMyToolPadDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CMyToolPadDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
