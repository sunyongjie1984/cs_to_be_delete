#include "stdafx.h"
#include "io.h"
#include "MyToolPad.h"
#include "PropertyPage7.h"
#include "GetDirectory.h"
#include "OrganizeInifile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CString m_directory;
IMPLEMENT_DYNCREATE(CPropertyPage7, CPropertyPage)

CPropertyPage7::CPropertyPage7() : CPropertyPage(CPropertyPage7::IDD)
{
	//{{AFX_DATA_INIT(CPropertyPage7)
	m_exefile = _T("");
	m_shortname = _T("");
	m_text = TRUE;
	m_system = FALSE;
	m_read = FALSE;
	m_hidden = FALSE;
	m_error = _T("");
	m_end = _T("");
	m_reset = _T("");
	m_begin = _T("");
	//}}AFX_DATA_INIT

	char windows[200];
	GetWindowsDirectory(windows,200);
	m_directory=_T(windows);
	m_error=m_directory;

	if(FileExist("c:\\logo.sys"))
		m_begin=_T("c:\\logo.sys");

	m_end=_T(windows);
	m_end+=_T("\\logow.sys");
	if(!FileExist(m_end))
		m_end=_T("");

	m_reset=_T(windows);
	m_reset+=_T("\\logos.sys");
	if(!FileExist(m_reset))
		m_reset=_T("");
}

CPropertyPage7::~CPropertyPage7()
{
}

void CPropertyPage7::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertyPage7)
	DDX_Control(pDX, IDC_SELECTDIR, m_ctrl6);
	DDX_Control(pDX, IDC_SETUPATTRIBUTE, m_ctrl5);
	DDX_Control(pDX, IDC_BROWSEEXECUTE, m_ctrl4);
	DDX_Control(pDX, IDC_BROWSE3, m_ctrl3);
	DDX_Control(pDX, IDC_BROWSE2, m_ctrl2);
	DDX_Control(pDX, IDC_BROWSE, m_ctrl1);
	DDX_Control(pDX, IDC_SETUP3, m_s3);
	DDX_Control(pDX, IDC_SETUP2, m_s2);
	DDX_Control(pDX, IDC_SETUP, m_s1);
	DDX_Control(pDX, IDC_STARTTREE, m_start);
	DDX_Control(pDX, IDC_SHORTNAME, m_shortctrl);
	DDX_Control(pDX, IDC_MAKEEFFECT, m_effect);
	DDX_Text(pDX, IDC_EXECUTEFILE, m_exefile);
	DDX_Text(pDX, IDC_SHORTNAME, m_shortname);
	DDX_Check(pDX, IDC_TEXTONLY, m_text);
	DDX_Check(pDX, IDC_SYSTEMONLY, m_system);
	DDX_Check(pDX, IDC_READONLY, m_read);
	DDX_Check(pDX, IDC_HIDDENONLY, m_hidden);
	DDX_Text(pDX, IDC_ERROR, m_error);
	DDX_Text(pDX, IDC_ENDPICTURE, m_end);
	DDX_Text(pDX, IDC_RESTARTPICTURE, m_reset);
	DDX_Text(pDX, IDC_STARTPICTURE, m_begin);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertyPage7, CPropertyPage)
	//{{AFX_MSG_MAP(CPropertyPage7)
	ON_BN_CLICKED(IDC_BROWSEEXECUTE, OnBrowseexecute)
	ON_EN_CHANGE(IDC_EXECUTEFILE, OnChangeExecutefile)
	ON_BN_CLICKED(IDC_MAKEEFFECT, OnMakeeffect)
	ON_EN_CHANGE(IDC_SHORTNAME, OnChangeShortname)
	ON_BN_CLICKED(IDC_DELETESTART, OnDeleteshortcut)
	ON_BN_CLICKED(IDC_REFRESH, OnRefresh)
	ON_NOTIFY(NM_RCLICK, IDC_STARTTREE, OnRclickStarttree)
	ON_NOTIFY(TVN_ENDLABELEDIT, IDC_STARTTREE, OnEndlabeleditStarttree)
	ON_NOTIFY(TVN_KEYDOWN, IDC_STARTTREE, OnKeydownStarttree)
	ON_BN_CLICKED(IDC_SELECTDIR, OnSelectdir)
	ON_BN_CLICKED(IDC_SETUPATTRIBUTE, OnSetupattribute)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_BN_CLICKED(IDC_BROWSE2, OnBrowse2)
	ON_BN_CLICKED(IDC_BROWSE3, OnBrowse3)
	ON_EN_CHANGE(IDC_ENDPICTURE, OnChangeEndpicture)
	ON_EN_CHANGE(IDC_RESTARTPICTURE, OnChangeRestartpicture)
	ON_EN_CHANGE(IDC_STARTPICTURE, OnChangeStartpicture)
	ON_BN_CLICKED(IDC_SETUP, OnSetup)
	ON_BN_CLICKED(IDC_SETUP2, OnSetup2)
	ON_BN_CLICKED(IDC_SETUP3, OnSetup3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CPropertyPage7::OnSetActive() 
{
	InitPanel();
	EnablePanel();

	return CPropertyPage::OnSetActive();
}

void CPropertyPage7::OnBrowseexecute() 
{
	CFileDialog dlg(TRUE,"*.exe",m_exefile,OFN_FILEMUSTEXIST|OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"ִ���ļ� (*.exe)|*.exe||");
	if(dlg.DoModal()==IDOK)
	{
		m_exefile=dlg.GetPathName();
		UpdateData(FALSE);
		EnablePanel();
	}
}

void CPropertyPage7::OnChangeExecutefile() 
{
	EnablePanel();
}
void CPropertyPage7::OnChangeShortname() 
{
	EnablePanel();
}

void CPropertyPage7::OnMakeeffect() 
{
	COrganizeInifile m_ini;
	char * m_name=m_shortname.GetBuffer(m_shortname.GetLength());
	char * m_exe=m_exefile.GetBuffer(m_exefile.GetLength());
	m_ini.CreateStringKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",m_name,m_exe);
	InitPanel();
}


void CPropertyPage7::OnRclickStarttree(NMHDR* pNMHDR, LRESULT* pResult)
{
	CMenu menu;
	menu.CreatePopupMenu();
	CPoint point;
	GetCursorPos(&point);

	HTREEITEM m_item=m_start.GetSelectedItem();
	DWORD m_data=m_start.GetItemData(m_item);
	DWORD m_left=m_data%1000;
	if(m_item!=m_start.GetRootItem() && m_left!=0)
		menu.AppendMenu(MF_ENABLED,IDC_DELETESTART,"ɾ����ݷ�ʽ");
	menu.AppendMenu(MF_ENABLED,IDC_REFRESH,"ˢ�¿�ݷ�ʽ");
	menu.TrackPopupMenu(TPM_LEFTALIGN,point.x,point.y,this);
	
	*pResult = 0;
}
void CPropertyPage7::OnEndlabeleditStarttree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;
	if(pTVDispInfo->item.pszText==0)
	    return ;
	
	if(pTVDispInfo->item.hItem==NULL || pTVDispInfo->item.hItem==m_start.GetRootItem())
		return;
	DWORD m_data=m_start.GetItemData(pTVDispInfo->item.hItem);
	if(m_data==1000 || m_data==2000 || m_data==3000)
		return;

	m_start.SetItemText(pTVDispInfo->item.hItem,pTVDispInfo->item.pszText);
	*pResult = 0;
}
void CPropertyPage7::OnKeydownStarttree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_KEYDOWN* pTVKeyDown = (TV_KEYDOWN*)pNMHDR;

	HTREEITEM hSel=m_start.GetSelectedItem();
	if(hSel==NULL || hSel==m_start.GetRootItem())
		return;
	DWORD m_data=m_start.GetItemData(hSel);
	if(m_data==1000 || m_data==2000 || m_data==3000)
		return;

	switch(pTVKeyDown->wVKey)
	{
	case VK_DELETE:
		break;
	case VK_F2:
		m_start.EditLabel(hSel);
		break;
	}
	
	*pResult = 0;
}

void CPropertyPage7::InitPanel()
{
	m_start.DeleteAllItems();
	HTREEITEM m_root  =CreateTree(m_start,"������������");
	HTREEITEM m_first =InsertTreeItem(m_start,"Win.ini",1000,m_root,0);
	HTREEITEM m_second=InsertTreeItem(m_start,"����",2000,m_root,0);
	HTREEITEM m_third =InsertTreeItem(m_start,"ע���",3000,m_root,0);

	WinIniToTree(m_first);
	StartToTree(m_second);
	RegistryToTree(m_third);
	m_start.Expand(m_start.GetRootItem(),TVE_EXPAND);
	m_start.SelectItem(m_first);
	UpdateData(FALSE);
}

void CPropertyPage7::EnablePanel()
{
	UpdateData(TRUE);
	BOOL m_enable=FileExist(m_exefile);
	m_shortctrl.EnableWindow(m_enable);
	m_enable=(m_enable && (m_shortname!=_T("")));
	m_effect.EnableWindow(m_enable);

	m_enable=FileExist(m_begin);
	m_s1.EnableWindow(m_enable);
	m_enable=FileExist(m_end);
	m_s2.EnableWindow(m_enable);
	m_enable=FileExist(m_reset);
	m_s3.EnableWindow(m_enable);
}

int  CPropertyPage7::SplitToTree(HTREEITEM m_root,char * buffer,int m_startindex)
{
	int  m_len=strlen(buffer),m_index=0,m_itemindex=m_startindex;
	char m_item[200];
	memset(m_item,0,200);
	for(int i=0;i<m_len;i++)
	{
		if(buffer[i]==' ')
		{	
			if(strcmp(m_item,"")!=0)
			{
				m_itemindex++;
				InsertTreeItem(m_start,m_item,m_itemindex,m_root,0);
			}
			memset(m_item,0,200);
			m_index=0;
		}
		else
		{
			m_item[m_index]=buffer[i];
			m_index++;
		}
	}
	if(strcmp(m_item,"")!=0)
	{
		m_itemindex++;
		InsertTreeItem(m_start,m_item,m_itemindex,m_root,0);
	}
	return m_startindex;
}

void CPropertyPage7::WinIniToTree(HTREEITEM m_root)
{
	char buffer[255],windows[200];
	GetWindowsDirectory(windows,200);
	strcat(windows,"\\win.ini");
	GetPrivateProfileString("windows","load","",buffer,255,windows);
	int m_index=1001;
	m_index=SplitToTree(m_root,buffer,m_index);
	GetPrivateProfileString("windows","run","",buffer,255,windows);
	SplitToTree(m_root,buffer,m_index);
}

void CPropertyPage7::StartToTree(HTREEITEM m_root)
{
	char dir[200];
	GetWindowsDirectory(dir,200);
	int  id=2001,ret=0;
	struct _finddata_t fileinfo;
	strcat(dir,"\\Start Menu\\Programs\\����\\*.*");
	long handle=_findfirst(dir,&fileinfo);
	while(handle && (ret==0))
	{			
		if(!(fileinfo.attrib & _A_SUBDIR))
		{
			InsertTreeItem(m_start,fileinfo.name,id,m_root,0);
			id++;
		}
		ret=_findnext(handle,&fileinfo);
	}
}

void CPropertyPage7::RegistryToTree(HTREEITEM m_root)
{
	char m_key[255]="SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run";
	HKEY m_hkey;
	char m_name[200],m_dada[200];
	DWORD m_namelen=200,m_datalen=200,m_index=0;
	DWORD m_attr=REG_BINARY|REG_DWORD|REG_EXPAND_SZ|REG_MULTI_SZ|REG_NONE|REG_SZ;
	memset(m_name,0,200);
	memset(m_dada,0,200);

	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE,m_key,0,KEY_ALL_ACCESS,&m_hkey)==ERROR_SUCCESS)
	{
		m_namelen=200;
		m_datalen=200;
		memset(m_name,0,200);
		memset(m_dada,0,200);

		while(RegEnumValue(m_hkey,m_index,m_name,&m_namelen,NULL,&m_attr,(LPBYTE)m_dada,&m_datalen)==ERROR_SUCCESS)
		{
			m_index++;
			if(strcmp(m_name,"")!=0)
				InsertTreeItem(m_start,m_name,3001+m_index,m_root,0);

			m_namelen=200;
			m_datalen=200;
			memset(m_name,0,200);
			memset(m_dada,0,200);
		}
		RegCloseKey(m_hkey);
	}

	m_index=0;
	if(RegOpenKeyEx(HKEY_CURRENT_USER,m_key,0,KEY_ALL_ACCESS,&m_hkey)==ERROR_SUCCESS)
	{
		m_namelen=200;
		m_datalen=200;
		memset(m_name,0,200);
		memset(m_dada,0,200);

		while(RegEnumValue(m_hkey,m_index,m_name,&m_namelen,NULL,&m_attr,(LPBYTE)m_dada,&m_datalen)==ERROR_SUCCESS)
		{
			m_index++;
			if(strcmp(m_name,"")!=0)
				InsertTreeItem(m_start,m_name,3001+m_index,m_root,0);

			m_namelen=200;
			m_datalen=200;
			memset(m_name,0,200);
			memset(m_dada,0,200);
		}
		if(RegCloseKey(m_hkey)!=ERROR_SUCCESS)
			MessageBox("�رռ�ֵʧ��");
	}
}

BOOL CPropertyPage7::FileExist(CString m_file)
{
	BOOL ret=FALSE;
	if(m_file==_T(""))
		return ret;

	HANDLE file=CreateFile(m_file,0,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(file!=INVALID_HANDLE_VALUE)
	{
		CloseHandle(file);
		ret=TRUE;
	}
	return ret;
}

//������
HTREEITEM CPropertyPage7::CreateTree(CTreeCtrl &tree,char * text)
{
	TV_INSERTSTRUCT tci;
	tci.item.mask=TVIF_TEXT|TVIF_PARAM;
	tci.item.stateMask=0;
	tci.item.pszText=text;
	tci.item.iImage=I_IMAGECALLBACK;
	tci.item.iSelectedImage=I_IMAGECALLBACK;
	tci.item.cchTextMax=lstrlen(tci.item.pszText);
	tci.item.lParam=0;
	tci.hParent=NULL;
	tci.hInsertAfter=TVI_LAST;
	return(tree.InsertItem(&tci));
}

//����һ�����
HTREEITEM CPropertyPage7::InsertTreeItem(CTreeCtrl &tree,char * text,int index,HTREEITEM parent,int image)
{
	TV_INSERTSTRUCT tci;
	tci.item.mask=TVIF_TEXT|TVIF_PARAM;
	tci.item.stateMask=0;
	tci.item.pszText=text;
	tci.item.iImage=0;
	tci.item.iSelectedImage=image;
	tci.item.cchTextMax=lstrlen(tci.item.pszText);
	tci.item.lParam=index;
	tci.hParent=parent;
	tci.hInsertAfter=TVI_LAST;
	return(tree.InsertItem(&tci));
}

void CPropertyPage7::OnSelectdir() 
{
	CGetDirectory m_dir(this);
	m_dir.DoModal();
	m_error=m_directory;
	UpdateData(FALSE);
}

void CPropertyPage7::OnSetupattribute() 
{
	UpdateData(TRUE);
	m_error=_T("��ʼ��������");
	UpdateData(FALSE);

	DWORD m_attr=FILE_ATTRIBUTE_NORMAL;
	if(m_text)
		m_attr|=FILE_ATTRIBUTE_ARCHIVE;
	if(m_read)
		m_attr|=FILE_ATTRIBUTE_READONLY;
	if(m_hidden)
		m_attr|=FILE_ATTRIBUTE_HIDDEN;
	if(m_system)
		m_attr|=FILE_ATTRIBUTE_SYSTEM;

	char * m_dirname=m_directory.GetBuffer(m_directory.GetLength());
	SetAllFileAttrs(m_dirname,m_attr);

	m_error=_T("�����������");
	UpdateData(FALSE);
}

void CPropertyPage7::SetAllFileAttrs(char *m_dir,DWORD m_attr)
{
	int  ret=0;
	struct _finddata_t fileinfo;
	char m_dirname[250];

	wsprintf(m_dirname,"%s\\*.*",m_dir);
	long handle=_findfirst(m_dirname,&fileinfo);
	
	while(handle>0 && (ret==0))
	{			
		if(fileinfo.attrib & _A_SUBDIR)
		{
			if((strcmpi(fileinfo.name,".")!=0) && (strcmpi(fileinfo.name,"..")!=0))
			{
				wsprintf(m_dirname,"%s\\%s",m_dir,fileinfo.name);
				SetAllFileAttrs(m_dirname,m_attr);
			}
		}
		else
		{
			wsprintf(m_dirname,"%s\\%s",m_dir,fileinfo.name);
			SetFileAttributes(m_dirname,m_attr);

			m_error=_T(m_dirname);
			UpdateData(FALSE);
		}
		ret=_findnext(handle,&fileinfo);
	}
}

void CPropertyPage7::DeleteIni(char *buffer,char *m_name)
{
	char * m_find=strstr(buffer,m_name);
	int  m_len=strlen(m_name);
	if(m_find!=NULL)
	{
		strcpy(m_find,m_find+m_len);
		*(m_find+m_len)='\0';
	}
}

void CPropertyPage7::DeleteWinini(char * m_name)
{
	char buffer[255],windows[200];
	GetWindowsDirectory(windows,200);
	strcat(windows,"\\win.ini");
	GetPrivateProfileString("windows","load","",buffer,255,windows);
	DeleteIni(buffer,m_name);
	WritePrivateProfileString("windows","load",buffer,windows);

	GetPrivateProfileString("windows","run","",buffer,255,windows);
	DeleteIni(buffer,m_name);
	WritePrivateProfileString("windows","run",buffer,windows);
}
void CPropertyPage7::DeleteStartup(char * m_name)
{
	char m_dirname[200];
	GetWindowsDirectory(m_dirname,200);
	strcat(m_dirname,"\\Start Menu\\Programs\\����\\");
	strcat(m_dirname,m_name);
	DeleteFile(m_dirname);
}
void CPropertyPage7::DeleteRegistry(char * m_name)
{
	COrganizeInifile m_ini;
	m_ini.DeleteKeyValue(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",m_name);
	m_ini.DeleteKeyValue(HKEY_CURRENT_USER,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",m_name);
}
void CPropertyPage7::DeleteSelfStart(char * m_name,int m_pos)
{
	switch(m_pos)
	{
	case 1:
		DeleteWinini(m_name);
		break;
	case 2:
		DeleteStartup(m_name);
		break;
	case 3:
		DeleteRegistry(m_name);
		break;
	}
}

void CPropertyPage7::OnDeleteshortcut() 
{
	HTREEITEM hSel=m_start.GetSelectedItem();
	DWORD m_data=m_start.GetItemData(hSel);
	CString m_name=m_start.GetItemText(hSel);
	DeleteSelfStart(m_name.GetBuffer(m_name.GetLength()),(int)(m_data/1000));
	m_start.DeleteItem(hSel);
}

void CPropertyPage7::OnRefresh()
{
	InitPanel();
	EnablePanel();
}

void CPropertyPage7::OnBrowse() 
{
	CFileDialog dlg(TRUE,"*.bmp",m_begin,OFN_FILEMUSTEXIST|OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"ͼƬ�ļ� (*.bmp)|*.bmp||");
	if(dlg.DoModal()==IDOK)
	{
		m_begin=dlg.GetPathName();
		UpdateData(FALSE);
		EnablePanel();
	}
}

void CPropertyPage7::OnBrowse2() 
{
	CFileDialog dlg(TRUE,"*.bmp",m_end,OFN_FILEMUSTEXIST|OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"ͼƬ�ļ� (*.bmp)|*.bmp||");
	if(dlg.DoModal()==IDOK)
	{
		m_end=dlg.GetPathName();
		UpdateData(FALSE);
		EnablePanel();
	}
}

void CPropertyPage7::OnBrowse3() 
{
	CFileDialog dlg(TRUE,"*.bmp",m_reset,OFN_FILEMUSTEXIST|OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"ͼƬ�ļ� (*.bmp)|*.bmp||");
	if(dlg.DoModal()==IDOK)
	{
		m_reset=dlg.GetPathName();
		UpdateData(FALSE);
		EnablePanel();
	}
}

void CPropertyPage7::OnChangeEndpicture() 
{
	EnablePanel();
}

void CPropertyPage7::OnChangeRestartpicture() 
{
	EnablePanel();
}

void CPropertyPage7::OnChangeStartpicture() 
{
	EnablePanel();
}

void CPropertyPage7::SaveAsForeword(CString m_bit,int m_mode)
{
	char windows[200];
	GetWindowsDirectory(windows,200);
	CString m_desfile=_T(windows);
	char * sou,*des;
	DWORD m_attr=FILE_ATTRIBUTE_ARCHIVE|FILE_ATTRIBUTE_NORMAL;
	BOOL m_logo=FALSE;

	switch(m_mode)
	{
	case 1:
		m_desfile=_T("c:\\logo.sys");
		SetFileAttributes("c:\\msdos.sys",m_attr);
		wsprintf(windows,"%d",1);
		WritePrivateProfileString("Options","Logo",windows,"c:\\msdos.sys");
		m_attr|=FILE_ATTRIBUTE_HIDDEN|FILE_ATTRIBUTE_READONLY|FILE_ATTRIBUTE_SYSTEM;
		SetFileAttributes("c:\\msdos.sys",m_attr);
		break;
	case 2:
		m_desfile+=_T("\\logow.sys");
		break;
	case 3:
		m_desfile+=_T("\\logos.sys");
		break;
	}

	sou=m_bit.GetBuffer(m_bit.GetLength());
	des=m_desfile.GetBuffer(m_desfile.GetLength());
	if(strcmpi(sou,des)!=0)
	{
		SetFileAttributes(m_desfile,m_attr);
		DeleteFile(m_desfile);
		CopyFile(sou,des,FALSE);
	}
}

void CPropertyPage7::OnSetup() 
{
	SaveAsForeword(m_begin,1);
}

void CPropertyPage7::OnSetup2() 
{
	SaveAsForeword(m_end,2);
}

void CPropertyPage7::OnSetup3() 
{
	SaveAsForeword(m_reset,3);
}

BOOL CPropertyPage7::PreTranslateMessage(MSG* pMsg) 
{
	m_tooltip.RelayEvent(pMsg);
	
	return CPropertyPage::PreTranslateMessage(pMsg);
}

BOOL CPropertyPage7::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	m_tooltip.Create(this);
	m_tooltip.Activate(TRUE);
	m_tooltip.AddTool(GetDlgItem(IDC_EXECUTEFILE),"Ҫ������ݷ�ʽ�Ŀ�ִ���ļ���");
	m_tooltip.AddTool(GetDlgItem(IDC_BROWSEEXECUTE),"Ѱ�ҿ�ִ���ļ�");
	m_tooltip.AddTool(GetDlgItem(IDC_SHORTNAME),"��ݷ�ʽȫ��");
	m_tooltip.AddTool(GetDlgItem(IDC_STARTTREE),"���п�ݷ�ʽ�б�");
	m_tooltip.AddTool(GetDlgItem(IDC_MAKEEFFECT),"������ݷ�ʽ");
	m_tooltip.AddTool(GetDlgItem(IDC_TEXTONLY),"�����ļ�����Ϊ�ı�����");
	m_tooltip.AddTool(GetDlgItem(IDC_READONLY),"�����ļ�����Ϊֻ������");
	m_tooltip.AddTool(GetDlgItem(IDC_HIDDENONLY),"�����ļ�����Ϊ��������");
	m_tooltip.AddTool(GetDlgItem(IDC_SYSTEMONLY),"�����ļ�����Ϊϵͳ����");
	m_tooltip.AddTool(GetDlgItem(IDC_SELECTDIR),"ѡ��Ҫ������Ŀ¼");
	m_tooltip.AddTool(GetDlgItem(IDC_SETUPATTRIBUTE),"����Ŀ¼�µ������ļ�����Ϊ��ǰָ������");
	m_tooltip.AddTool(GetDlgItem(IDC_STARTPICTURE),"Windows������������");
	m_tooltip.AddTool(GetDlgItem(IDC_ENDPICTURE),"Windows�����ػ�����");
	m_tooltip.AddTool(GetDlgItem(IDC_RESTARTPICTURE),"Windows������������");
	m_tooltip.AddTool(GetDlgItem(IDC_BROWSE),"����Windows�������������ļ�(320x400x256)");
	m_tooltip.AddTool(GetDlgItem(IDC_BROWSE2),"����Windows�����ػ������ļ�(320x400x256)");
	m_tooltip.AddTool(GetDlgItem(IDC_BROWSE3),"����Windows�������������ļ�(320x400x256)");
	m_tooltip.AddTool(GetDlgItem(IDC_SETUP),"����Windows������������");
	m_tooltip.AddTool(GetDlgItem(IDC_SETUP2),"����Windows�����ػ�����");
	m_tooltip.AddTool(GetDlgItem(IDC_SETUP3),"����Windows������������");
	
	return TRUE;
}
