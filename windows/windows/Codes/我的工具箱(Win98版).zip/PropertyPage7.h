#if !defined(AFX_PROPERTYPAGE7_H__24E76DC1_69A6_11D2_BDED_0000210022D0__INCLUDED_)
#define AFX_PROPERTYPAGE7_H__24E76DC1_69A6_11D2_BDED_0000210022D0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "EllipseButton.h"



class CPropertyPage7 : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropertyPage7)

public:
	CPropertyPage7();
	~CPropertyPage7();

	//{{AFX_DATA(CPropertyPage7)
	enum { IDD = IDD_PROPPAGE7 };
	CRoundButton	m_ctrl6;
	CRoundButton	m_ctrl5;
	CRoundButton	m_ctrl4;
	CRoundButton	m_ctrl3;
	CRoundButton	m_ctrl2;
	CRoundButton	m_ctrl1;
	CRoundButton	m_s3;
	CRoundButton	m_s2;
	CRoundButton	m_s1;
	CTreeCtrl	m_start;
	CEdit	m_shortctrl;
	CRoundButton	m_effect;
	CString	m_exefile;
	CString	m_shortname;
	BOOL	m_text;
	BOOL	m_system;
	BOOL	m_read;
	BOOL	m_hidden;
	CString	m_error;
	CString	m_end;
	CString	m_reset;
	CString	m_begin;
	//}}AFX_DATA


	//{{AFX_VIRTUAL(CPropertyPage7)
	public:
	virtual BOOL OnSetActive();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	CToolTipCtrl m_tooltip;

	void InitPanel();
	void EnablePanel();

	BOOL FileExist(CString m_file);
	HTREEITEM CreateTree(CTreeCtrl &tree,char * text);
	HTREEITEM InsertTreeItem(CTreeCtrl &tree,char * text,int index,HTREEITEM parent,int image);

	void WinIniToTree(HTREEITEM m_root);
	void StartToTree(HTREEITEM m_root);
	void RegistryToTree(HTREEITEM m_root);
	void SetAllFileAttrs(char *m_directory,DWORD m_attr);
	int  SplitToTree(HTREEITEM m_root,char * buffer,int m_startindex);
	void DeleteWinini(char * m_name);
	void DeleteStartup(char * m_name);
	void DeleteRegistry(char * m_name);
	void DeleteSelfStart(char * m_name,int m_pos);
	void DeleteIni(char *buffer,char *m_name);
	void SaveAsForeword(CString m_bit,int m_mode);


protected:
	//{{AFX_MSG(CPropertyPage7)
	afx_msg void OnBrowseexecute();
	afx_msg void OnChangeExecutefile();
	afx_msg void OnMakeeffect();
	afx_msg void OnChangeShortname();
	afx_msg void OnDeleteshortcut();
	afx_msg void OnRefresh();
	afx_msg void OnRclickStarttree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEndlabeleditStarttree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnKeydownStarttree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelectdir();
	afx_msg void OnSetupattribute();
	afx_msg void OnBrowse();
	afx_msg void OnBrowse2();
	afx_msg void OnBrowse3();
	afx_msg void OnChangeEndpicture();
	afx_msg void OnChangeRestartpicture();
	afx_msg void OnChangeStartpicture();
	afx_msg void OnSetup();
	afx_msg void OnSetup2();
	afx_msg void OnSetup3();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_PROPERTYPAGE7_H__24E76DC1_69A6_11D2_BDED_0000210022D0__INCLUDED_)
