#if !defined(AFX_MYTOOLPADDLG_H__B16825E7_68F3_11D2_BDED_0000210022D0__INCLUDED_)
#define AFX_MYTOOLPADDLG_H__B16825E7_68F3_11D2_BDED_0000210022D0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CMyToolPadDlg : public CDialog
{
public:
	CMyToolPadDlg(CWnd* pParent = NULL);	// standard constructor

	//{{AFX_DATA(CMyToolPadDlg)
	enum { IDD = IDD_MYTOOLPAD_DIALOG };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CMyToolPadDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	HICON m_hIcon;

	//{{AFX_MSG(CMyToolPadDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_MYTOOLPADDLG_H__B16825E7_68F3_11D2_BDED_0000210022D0__INCLUDED_)
