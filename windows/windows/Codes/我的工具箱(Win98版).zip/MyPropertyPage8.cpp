#include "stdafx.h"
#include "MyToolPad.h"
#include "MyPropertyPage8.h"
#include "OrganizeInifile.h"
#include "MyPropertySheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CMyPropertySheet *m_sheet;



IMPLEMENT_DYNCREATE(CMyPropertyPage8, CPropertyPage)

CMyPropertyPage8::CMyPropertyPage8() : CPropertyPage(CMyPropertyPage8::IDD)
{
	GetDevicePath();

	char m_buffer[200],*m_add;
	COrganizeInifile m_ini;
	m_add=m_MTUpath.GetBuffer(m_MTUpath.GetLength());
	strcpy(m_buffer,m_ini.GetStringKey(HKEY_LOCAL_MACHINE,m_add,"MaxMTU"));
	int m_max=atoi(m_buffer);
	m_add=m_Otherpath.GetBuffer(m_Otherpath.GetLength());
	strcpy(m_buffer,m_ini.GetStringKey(HKEY_LOCAL_MACHINE,m_add,"DefaultTTL"));
	int m_tl =atoi(m_buffer);
	m_add=m_Otherpath.GetBuffer(m_Otherpath.GetLength());
	strcpy(m_buffer,m_ini.GetStringKey(HKEY_LOCAL_MACHINE,m_add,"DefaultRcvWindow"));
	int m_rec=atoi(m_buffer);
	m_add=m_Otherpath.GetBuffer(m_Otherpath.GetLength());
	strcpy(m_buffer,m_ini.GetStringKey(HKEY_LOCAL_MACHINE,m_add,"NameSrvQueryTimeout"));
	int m_que=atoi(m_buffer);

	//{{AFX_DATA_INIT(CMyPropertyPage8)
	m_maxmtu=m_max;
	m_ttl =m_tl;
	m_receive =m_rec;
	m_querytime=m_que;
	m_files =0;
	m_folders= 0;
	m_clear =FALSE;
	m_extname=_T("");
	m_linkfile=_T("");
	m_foot = _T("");
	m_menu = _T("");
	//}}AFX_DATA_INIT

	m_changed=FALSE;
}

CMyPropertyPage8::~CMyPropertyPage8()
{
}

void CMyPropertyPage8::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyPropertyPage8)
	DDX_Control(pDX, IDC_RIGHT, m_ctrl2);
	DDX_Control(pDX, IDC_DEFAULT, m_ctrl1);
	DDX_Control(pDX, IDC_FILELINKLIST, m_linklist);
	DDX_Control(pDX, IDC_BROWSE, m_browse);
	DDX_Control(pDX, IDC_LINK, m_link);
	DDX_Control(pDX, IDC_PATHNUMBER, m_pathcache);
	DDX_Control(pDX, IDC_FOLDERNUMBER, m_namecache);
	DDX_Control(pDX, IDC_EFFECT, m_effect);
	DDX_Text(pDX, IDC_MAXMTU, m_maxmtu);
	DDV_MinMaxInt(pDX, m_maxmtu, 0, 65535);
	DDX_Text(pDX, IDC_TTL, m_ttl);
	DDV_MinMaxInt(pDX, m_ttl, 0, 255);
	DDX_Text(pDX, IDC_RECEIVEWINDOW, m_receive);
	DDV_MinMaxInt(pDX, m_receive, 0, 65535);
	DDX_Text(pDX, IDC_QUERYTIME, m_querytime);
	DDV_MinMaxInt(pDX, m_querytime, 0, 65535);
	DDX_Text(pDX, IDC_FILENUMBER, m_files);
	DDV_MinMaxInt(pDX, m_files, 1, 500);
	DDX_Text(pDX, IDC_FOLDERS, m_folders);
	DDV_MinMaxInt(pDX, m_folders, 1, 20000);
	DDX_Check(pDX, IDC_CLEAREMPTYDIR, m_clear);
	DDX_Text(pDX, IDC_EXTNAME, m_extname);
	DDX_Text(pDX, IDC_LINKTOFILE, m_linkfile);
	DDX_Text(pDX, IDC_FOOTNAME, m_foot);
	DDX_Text(pDX, IDC_MENUNAME, m_menu);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyPropertyPage8, CPropertyPage)
	//{{AFX_MSG_MAP(CMyPropertyPage8)
	ON_BN_CLICKED(IDC_REFRESH, OnRefresh)
	ON_BN_CLICKED(IDC_DELETESTART, OnDeleteLink)
	ON_BN_CLICKED(IDC_DEFAULT, OnDefault)
	ON_BN_CLICKED(IDC_EFFECT, OnEffect)
	ON_BN_CLICKED(IDC_DESKTOP, OnDesktop)
	ON_BN_CLICKED(IDC_MOBILE, OnMobile)
	ON_BN_CLICKED(IDC_SERVER, OnServer)
	ON_EN_CHANGE(IDC_MAXMTU, OnChangeMaxmtu)
	ON_EN_CHANGE(IDC_QUERYTIME, OnChangeQuerytime)
	ON_EN_CHANGE(IDC_RECEIVEWINDOW, OnChangeReceivewindow)
	ON_EN_CHANGE(IDC_TTL, OnChangeTtl)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_RIGHT, OnRight)
	ON_EN_CHANGE(IDC_FILENUMBER, OnChangeFilenumber)
	ON_EN_CHANGE(IDC_FOLDERS, OnChangeFolders)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_EN_CHANGE(IDC_EXTNAME, OnChangeExtname)
	ON_NOTIFY(NM_RCLICK, IDC_FILELINKLIST, OnRclickFilelinklist)
	ON_NOTIFY(LVN_KEYDOWN, IDC_FILELINKLIST, OnKeydownFilelinklist)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_FILELINKLIST, OnColumnclickFilelinklist)
	ON_EN_CHANGE(IDC_LINKTOFILE, OnChangeLinktofile)
	ON_EN_CHANGE(IDC_FOOTNAME, OnChangeFootname)
	ON_EN_CHANGE(IDC_MENUNAME, OnChangeMenuname)
	ON_BN_CLICKED(IDC_LINK, OnLink)
	ON_BN_CLICKED(IDC_CLEAREMPTYDIR, OnClearemptydir)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



void CMyPropertyPage8::OnDefault() 
{
	m_maxmtu=1500;
	m_ttl =32;
	m_receive=8192;
	m_querytime=750;
	switch(m_platmode)
	{
	case 1:
		m_files =32;
		m_folders=677;
		break;
	case 2:
		m_files =16;
		m_folders=337;
		break;
	case 3:
		m_files =64;
		m_folders=2729;
		break;
	}
	UpdateData(FALSE);
	OnChangeFilenumber();
	OnChangeFolders();
	OnEffect();
}

void CMyPropertyPage8::OnEffect() 
{
	UpdateData(TRUE);
	COrganizeInifile m_ini;
	CString m_value;

	m_value.Format("%d",m_maxmtu);
	m_ini.CreateStringKey(HKEY_LOCAL_MACHINE,m_MTUpath,_T("MaxMTU"),m_value);
	m_value.Format("%d",m_ttl);
	m_ini.CreateStringKey(HKEY_LOCAL_MACHINE,m_Otherpath,_T("DefaultTTL"),m_value);
	m_value.Format("%d",m_receive);
	m_ini.CreateStringKey(HKEY_LOCAL_MACHINE,m_Otherpath,_T("DefaultRcvWindow"),m_value);
	m_value.Format("%d",m_querytime);
	m_ini.CreateStringKey(HKEY_LOCAL_MACHINE,m_Otherpath,_T("NameSrvQueryTimeout"),m_value);

	CString m_path;
	switch(m_platmode)
	{
	case 1:
		m_path=m_FilePath+_T("\\Desktop");
		break;
	case 2:
		m_path=m_FilePath+_T("\\Mobile");
		break;
	case 3:
		m_path=m_FilePath+_T("\\Server");
		break;
	}
	m_ini.CreateBinaryKey(HKEY_LOCAL_MACHINE,m_path,_T("NameCache"),(long)m_files);
	m_ini.CreateBinaryKey(HKEY_LOCAL_MACHINE,m_path,_T("PathCache"),(long)m_folders);
	ToSystemIni();

	m_changed=FALSE;
	EnablePanel();
}

void CMyPropertyPage8::OnDesktop() 
{
	m_platmode=1;
	m_changed=TRUE;
	EnablePanel();
}

void CMyPropertyPage8::OnMobile() 
{
	m_platmode=2;
	m_changed=TRUE;
	EnablePanel();
}

void CMyPropertyPage8::OnServer() 
{
	m_platmode=3;
	m_changed=TRUE;
	EnablePanel();
}

void CMyPropertyPage8::OnChangeMaxmtu() 
{
	m_changed=TRUE;
	EnablePanel();
}

void CMyPropertyPage8::OnChangeQuerytime() 
{
	m_changed=TRUE;
	EnablePanel();
}

void CMyPropertyPage8::OnChangeReceivewindow() 
{
	m_changed=TRUE;
	EnablePanel();
}

void CMyPropertyPage8::OnChangeTtl() 
{
	m_changed=TRUE;
	EnablePanel();
}

void CMyPropertyPage8::ShowMessage()
{
	m_files=m_namecache.GetPos();
	m_folders=m_pathcache.GetPos();
	UpdateData(FALSE);
}

void CMyPropertyPage8::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	m_changed=TRUE;
	EnablePanel();
	switch(nSBCode)
	{
	case SB_LEFT:
		ShowMessage();
		break;
	case SB_ENDSCROLL:
		ShowMessage();
		break;
	case SB_LINELEFT:
		ShowMessage();
		break;
	case SB_LINERIGHT:
		ShowMessage();
		break;
	case SB_PAGELEFT:
		ShowMessage();
		break;
	case SB_PAGERIGHT:
		ShowMessage();
		break;
	case SB_RIGHT:
		ShowMessage();
		break;
	case SB_THUMBPOSITION:
		ShowMessage();
		break;
	case SB_THUMBTRACK:
		ShowMessage();
		break;
	}

	CPropertyPage::OnHScroll(nSBCode, nPos, pScrollBar);
}


void CMyPropertyPage8::InitPanel()
{
	CWinApp* pApp = AfxGetApp();

	cil1.Create(32,32,TRUE,2,2);
	cil1.Add(pApp->LoadIcon(IDI_MALE));
	cil1.Add(pApp->LoadIcon(IDI_FEMALE));
	m_linklist.SetImageList(&cil1,LVSIL_NORMAL);
	
	cil2.Create(16,16,TRUE,2,2);
	cil2.Add(pApp->LoadIcon(IDI_MALE));
	cil2.Add(pApp->LoadIcon(IDI_FEMALE));
	m_linklist.SetImageList(&cil2,LVSIL_SMALL);

	LV_COLUMN lvc;
	lvc.mask=LVCF_FMT|LVCF_SUBITEM|LVCF_TEXT|LVCF_WIDTH;
	lvc.fmt=LVCFMT_LEFT;

	char *caption[]={"��չ��","�������ĳ�����������"};
	int subitem[]={80,400};
	for(int i=0;i<2;i++)
	{
		lvc.pszText=caption[i];
		lvc.iSubItem=i;
		lvc.cx=subitem[i];
		m_linklist.InsertColumn(i,&lvc);
	}

	AllLinkToList();

	m_linklist.SetBkColor(RGB(0,128,128));
	m_linklist.SetTextColor(RGB(255,255,0));
	m_linklist.SetTextBkColor(RGB(0,128,128));
	
	GetFileSystem();
	UpdateData(FALSE);
}

BOOL CMyPropertyPage8::FileExist(CString m_file)
{
	BOOL ret=FALSE;
	if(m_file==_T(""))
		return ret;

	HANDLE file=CreateFile(m_file,0,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(file!=INVALID_HANDLE_VALUE)
	{
		CloseHandle(file);
		ret=TRUE;
	}
	return ret;
}

void CMyPropertyPage8::EnablePanel()
{
	UpdateData(TRUE);
	BOOL m_enable=(m_extname!=_T(""));
	m_browse.EnableWindow(m_enable);
	m_enable=m_enable && (m_foot!=_T("")) && (m_menu!=_T(""));
	m_link.EnableWindow(m_enable && FileExist(m_linkfile));

	m_effect.EnableWindow(m_changed);
}

void CMyPropertyPage8::ResetToDefault()
{
	m_maxmtu=1500;
	m_ttl =32;
	m_receive=8192;
	m_querytime=750;
	UpdateData(FALSE);
}

void CMyPropertyPage8::SetToRegistry()
{
	COrganizeInifile m_ini;
}

BOOL CMyPropertyPage8::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	m_tooltip.Create(this);
	m_tooltip.Activate(TRUE);
	m_tooltip.AddTool(GetDlgItem(IDC_MAXMTU),"���MTU��Ԫ");
	m_tooltip.AddTool(GetDlgItem(IDC_TTL),"TTL��Ŀ");
	m_tooltip.AddTool(GetDlgItem(IDC_RECEIVEWINDOW),"���ջ�������С");
	m_tooltip.AddTool(GetDlgItem(IDC_QUERYTIME),"ͨѶ��ѯʱ��");
	m_tooltip.AddTool(GetDlgItem(IDC_DESKTOP),"�����̨ʽ������ѡ����");
	m_tooltip.AddTool(GetDlgItem(IDC_MOBILE),"����Ǳ�Я������ѡ����");
	m_tooltip.AddTool(GetDlgItem(IDC_SERVER),"����Ƿ���������ѡ����");
	m_tooltip.AddTool(GetDlgItem(IDC_FILENUMBER),"ϵͳ�����ļ���");
	m_tooltip.AddTool(GetDlgItem(IDC_FOLDERS),"ϵͳ��������·����");
	m_tooltip.AddTool(GetDlgItem(IDC_FOLDERNUMBER),"ϵͳ�����ļ���");
	m_tooltip.AddTool(GetDlgItem(IDC_PATHNUMBER),"ϵͳ��������·����");
	m_tooltip.AddTool(GetDlgItem(IDC_DEFAULT),"WindowsϵͳĬ��ֵ(��������)");
	m_tooltip.AddTool(GetDlgItem(IDC_RIGHT),"�ȽϺõ�����");
	m_tooltip.AddTool(GetDlgItem(IDC_EFFECT),"���õ�ϵͳ(����������Ч)");
	m_tooltip.AddTool(GetDlgItem(IDC_CLEAREMPTYDIR),"�˳�ʱ�����Ŀ¼�Ϳ��ļ�(��ʱ�ϳ�)");
	m_tooltip.AddTool(GetDlgItem(IDC_LINK),"��ָ����չ��������ָ����ִ�г���");
	m_tooltip.AddTool(GetDlgItem(IDC_EXTNAME),"ָ����չ��");
	m_tooltip.AddTool(GetDlgItem(IDC_LINKTOFILE),"�������Ŀ�ִ���ļ�");
	m_tooltip.AddTool(GetDlgItem(IDC_FOOTNAME),"Windows��Դ����������ʾ���ļ�������");
	m_tooltip.AddTool(GetDlgItem(IDC_MENUNAME),"Windows��Դ���������Ҽ��˵���");
	m_tooltip.AddTool(GetDlgItem(IDC_BROWSE),"Ѱ�ҿ�ִ���ļ�");

	m_clear =m_sheet->m_ClearEmpty;
	InitPanel();
	EnablePanel();

	return TRUE;
}

void CMyPropertyPage8::GetDevicePath()
{
	char m_key[200]="Enum\\Root\\Net",m_buffer[255];
	char m_name[200],m_this[100];
	HKEY m_hkey;
	DWORD m_namelen=200,m_index=0;
	DWORD m_attr=REG_BINARY|REG_DWORD|REG_EXPAND_SZ|REG_MULTI_SZ|REG_NONE|REG_SZ;
	memset(m_name,0,200);
	COrganizeInifile m_ini;

	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE,m_key,0,KEY_ALL_ACCESS,&m_hkey)==ERROR_SUCCESS)
	{
		m_namelen=200;
		memset(m_name,0,200);

		while(RegEnumKey(m_hkey,m_index,m_name,m_namelen)==ERROR_SUCCESS)
		{
			m_index++;
			wsprintf(m_buffer,"%s\\%s",m_key,m_name);

			strcpy(m_this,m_ini.GetStringKey(HKEY_LOCAL_MACHINE,m_buffer,"DeviceDesc"));
			if(strcmp(m_this,"��������������")==0)
			{
				strcat(m_buffer,"\\Bindings");

				DWORD m_datalen=200;
				DWORD m_thisindex=0;
				char  m_data[200];

				m_namelen=200;
				memset(m_name,0,200);
				memset(m_data,0,200);
				HKEY m_thiskey=0;
				if(RegOpenKeyEx(HKEY_LOCAL_MACHINE,m_buffer,0,KEY_ALL_ACCESS,&m_thiskey)==ERROR_SUCCESS)
				{
					while(RegEnumValue(m_thiskey,m_thisindex,m_name,&m_namelen,NULL,&m_attr,(LPBYTE)m_data,&m_datalen)==ERROR_SUCCESS)
					{
						if(strstr(m_name,"MSTCP")!=0)
							break;

						m_thisindex++;
						m_namelen=200;
						m_datalen=200;
						memset(m_data,0,200);
						memset(m_name,0,200);
					}
					RegCloseKey(m_thiskey);
				}

				m_MTUpath=_T("System\\CurrentControlSet\\Services\\Class\\");
				wsprintf(m_buffer,"Enum\\Network\\%s",m_name);
				m_MTUpath+=_T(m_ini.GetStringKey(HKEY_LOCAL_MACHINE,m_buffer,"Driver"));
				break;
			}

			m_namelen=200;
			memset(m_name,0,200);
		}
		RegCloseKey(m_hkey);
	}

	m_Otherpath=_T("System\\CurrentControlSet\\Services\\VxD\\MSTCP");
	m_FilePath=_T("Software\\Microsoft\\Windows\\CurrentVersion\\FS Templates");
	MakeAllKeyExist();
}

void CMyPropertyPage8::MakeAllKeyExist()
{
	COrganizeInifile m_ini;
	if(!m_ini.KeynameExist(HKEY_LOCAL_MACHINE,m_MTUpath,_T("MaxMTU")))
		m_ini.CreateStringKey(HKEY_LOCAL_MACHINE,m_MTUpath,_T("MaxMTU"),_T("1500"));

	if(!m_ini.KeynameExist(HKEY_LOCAL_MACHINE,m_Otherpath,_T("DefaultTTL")))
		m_ini.CreateStringKey(HKEY_LOCAL_MACHINE,m_Otherpath,_T("DefaultTTL"),_T("32"));

	if(!m_ini.KeynameExist(HKEY_LOCAL_MACHINE,m_Otherpath,_T("DefaultRcvWindow")))
		m_ini.CreateStringKey(HKEY_LOCAL_MACHINE,m_Otherpath,_T("DefaultRcvWindow"),_T("8192"));

	if(!m_ini.KeynameExist(HKEY_LOCAL_MACHINE,m_Otherpath,_T("NameSrvQueryTimeout")))
		m_ini.CreateStringKey(HKEY_LOCAL_MACHINE,m_Otherpath,_T("NameSrvQueryTimeout"),_T("750"));

	CString m_path=m_FilePath+_T("\\Desktop");
	long m_value=0;
	if(!m_ini.KeynameExist(HKEY_LOCAL_MACHINE,m_path,"NameCache"))
	{
		m_value=32;
		m_ini.CreateBinaryKey(HKEY_LOCAL_MACHINE,m_path,_T("NameCache"),m_value);
	}
	if(!m_ini.KeynameExist(HKEY_LOCAL_MACHINE,m_path,"PathCache"))
	{
		m_value=667;
		m_ini.CreateBinaryKey(HKEY_LOCAL_MACHINE,m_path,_T("PathCache"),m_value);
	}

	m_path=m_FilePath+_T("\\Mobile");
	if(!m_ini.KeynameExist(HKEY_LOCAL_MACHINE,m_path,"NameCache"))
	{
		m_value=16;
		m_ini.CreateBinaryKey(HKEY_LOCAL_MACHINE,m_path,_T("NameCache"),m_value);
	}
	if(!m_ini.KeynameExist(HKEY_LOCAL_MACHINE,m_path,"PathCache"))
	{
		m_value=337;
		m_ini.CreateBinaryKey(HKEY_LOCAL_MACHINE,m_path,_T("PathCache"),m_value);
	}

	m_path=m_FilePath+_T("\\Server");
	if(!m_ini.KeynameExist(HKEY_LOCAL_MACHINE,m_path,"NameCache"))
	{
		m_value=64;
		m_ini.CreateBinaryKey(HKEY_LOCAL_MACHINE,m_path,_T("NameCache"),m_value);
	}
	if(!m_ini.KeynameExist(HKEY_LOCAL_MACHINE,m_path,"PathCache"))
	{
		m_value=2729;
		m_ini.CreateBinaryKey(HKEY_LOCAL_MACHINE,m_path,_T("PathCache"),m_value);
	}
}

void	CMyPropertyPage8::GetFileSystem()
{
	COrganizeInifile m_ini;
	CString m_value=m_ini.GetStringKey(HKEY_LOCAL_MACHINE,m_FilePath,_T(""));
	CString m_path=m_FilePath;
	m_platmode=0;
	if(m_value.CompareNoCase("Desktop")==0)
	{
		m_path+=_T("\\Desktop");
		m_platmode=1;
	}
	if(m_value.CompareNoCase("Server")==0)
	{
		m_path+=_T("\\Server");
		m_platmode=2;
	}
	if(m_value.CompareNoCase("Mobile")==0)
	{
		m_path+=_T("\\Mobile");
		m_platmode=3;
	}

	m_namecache.SetRange(0,500);
	m_pathcache.SetRange(0,20000);
	m_files=m_ini.GetDwordKey(HKEY_LOCAL_MACHINE,m_path,_T("NameCache"));
	m_namecache.SetPos(m_files);
	m_folders=m_ini.GetDwordKey(HKEY_LOCAL_MACHINE,m_path,_T("PathCache"));
	m_pathcache.SetPos(m_folders);

	m_namecache.SetPageSize(10);
	m_pathcache.SetPageSize(50);

	switch(m_platmode)
	{
	case 0:
		AfxMessageBox("��ȡʧ��");
		break;
	case 1:
		CheckRadioButton(IDC_DESKTOP,IDC_SERVER,IDC_DESKTOP);
		break;
	case 2:
		CheckRadioButton(IDC_DESKTOP,IDC_SERVER,IDC_MOBILE);
		break;
	case 3:
		CheckRadioButton(IDC_DESKTOP,IDC_SERVER,IDC_SERVER);
		break;
	}
}

void CMyPropertyPage8::OnRight() 
{
	m_maxmtu=576;
	m_ttl =255;
	m_receive=5120;
	m_querytime=3000;
	m_files =128;
	m_folders=4096;
	UpdateData(FALSE);
	
	OnChangeFilenumber();
	OnChangeFolders();
	OnEffect();
}

void CMyPropertyPage8::OnChangeFilenumber() 
{
	UpdateData(TRUE);
	m_namecache.SetPos(m_files);
	m_changed=TRUE;
	EnablePanel();
}

void CMyPropertyPage8::OnChangeFolders() 
{
	UpdateData(TRUE);
	m_pathcache.SetPos(m_folders);
	m_changed=TRUE;
	EnablePanel();
}

void CMyPropertyPage8::ToSystemIni()
{
	char windows[200];
	GetWindowsDirectory(windows,200);
	strcat(windows,"\\system.ini");
	WritePrivateProfileString("386Enh","com4buffer","1024",windows);
}

void CMyPropertyPage8::InsertNItem(int n,char *extname,char *exename)
{
	SetNMItem(n,0,extname);
	SetNMItem(n,1,exename);
}

void CMyPropertyPage8::SetNMItem(int n,int m,char *value)
{
	LV_ITEM lvi;

	if(m==0)
	{
		lvi.mask=LVIF_TEXT|LVIF_IMAGE|LVIF_PARAM;
		lvi.iItem=n;
		lvi.iSubItem=m;
		lvi.pszText=value;
		lvi.iImage=0;
		lvi.lParam=n;
		m_linklist.InsertItem(&lvi);
	}
	else
	{
		lvi.mask=LVIF_TEXT;
		lvi.iItem=n;
		lvi.iSubItem=m;
		lvi.pszText=value;
		m_linklist.SetItem(&lvi);
	}
}

void CMyPropertyPage8::OnBrowse() 
{
	CFileDialog dlg(TRUE,"*.exe",m_linkfile,OFN_FILEMUSTEXIST|OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"��ִ���ļ� (*.exe)|*.exe||");
	if(dlg.DoModal()==IDOK)
	{
		m_linkfile=dlg.GetPathName();
		UpdateData(FALSE);
		EnablePanel();
	}
}

void CMyPropertyPage8::OnChangeExtname() 
{
	EnablePanel();
}

void CMyPropertyPage8::OnChangeLinktofile() 
{
	EnablePanel();
}

CListCtrl *m_list=NULL;
int CALLBACK CompareFunc(LPARAM lParam1,LPARAM lParam2,LPARAM lParamSort)
{
	char text1[255],text2[255];
	memset(text1,0,255);
	memset(text2,0,255);

	switch(lParamSort)
	{
	case 0L:
		m_list->GetItemText(lParam1,0,text1,255);
		m_list->GetItemText(lParam2,0,text2,255);
		break;
	case 1L:
		m_list->GetItemText(lParam1,1,text1,255);
		m_list->GetItemText(lParam2,1,text2,255);
		break;
	}
	return (strcmp(text1,text2));
}
void CMyPropertyPage8::OnColumnclickFilelinklist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	m_list=&m_linklist;
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	if(pNMListView->iSubItem==-1)
		return;

	int sortnum=pNMListView->iSubItem;
	m_linklist.SortItems((PFNLVCOMPARE)CompareFunc,sortnum);

	*pResult = 0;
}

void CMyPropertyPage8::OnRclickFilelinklist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CMenu menu;
	menu.CreatePopupMenu();
	CPoint point;
	GetCursorPos(&point);

     menu.AppendMenu(MF_ENABLED,IDC_DELETESTART,"ɾ������");
     menu.AppendMenu(MF_ENABLED,IDC_REFRESH,"ˢ�¹���");
	menu.TrackPopupMenu(TPM_LEFTALIGN,point.x,point.y,this);
	
	*pResult = 0;
}

void CMyPropertyPage8::OnKeydownFilelinklist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_KEYDOWN* pLVKeyDow = (LV_KEYDOWN*)pNMHDR;
	switch(pLVKeyDow->wVKey)
	{
	case VK_DELETE:
		OnDeleteLink();
		break;
	case VK_F2:
		{
			int itemsel=m_linklist.GetSelectedCount();
			int itemcount=m_linklist.GetItemCount();
			if(itemsel<1)
				return;

			while(itemcount)
			{
			    int state=m_linklist.GetItemState(itemcount-1,LVIS_SELECTED);
			    if(state!=0)
				    break;
			    itemcount--;
			}
			m_linklist.EditLabel(itemcount-1);
		}
		break;
	}
	*pResult = 0;
}

void CMyPropertyPage8::OnDeleteLink()
{
	char m_backfile[256];
	GetModuleFileName(AfxGetInstanceHandle(),m_backfile,256);
	char *m_pos=strrchr(m_backfile,'.');
	strcpy(m_pos,".reg");
	RegSaveKey(HKEY_CLASSES_ROOT,m_backfile,NULL);

	int itemsel=m_linklist.GetSelectedCount();
	int itemcount=m_linklist.GetItemCount();
	if(itemsel<1)
		return;

	char m_extfile[100],m_linkexefile[200];
	while(itemcount)
	{
		int state=m_linklist.GetItemState(itemcount-1,LVIS_SELECTED);
		if(state!=0)
		{
			memset(m_extfile,0,100);
			memset(m_linkexefile,0,200);
			m_linklist.GetItemText(itemcount-1,0,m_extfile,100);
			m_linklist.GetItemText(itemcount-1,1,m_linkexefile,200);
			if(strcmpi(m_linkexefile,"ϵͳ�ļ�")!=0)
				DeleteLink(_T(m_extfile));
			m_linklist.DeleteItem(itemcount-1);
		}
		itemcount--;
	}
	m_linklist.SetItemState(0,LVIF_STATE,LVIS_SELECTED);
}

CString CMyPropertyPage8::FindExecuteFile(char *m_indexname)
{
	COrganizeInifile m_ini;
	CString m_entry=m_ini.GetStringKey(HKEY_CLASSES_ROOT,_T(m_indexname),_T(""));
	m_entry+=_T("\\Shell");
	CString m_keyname=m_ini.GetStringKey(HKEY_CLASSES_ROOT,m_entry,_T(""));
	if(m_keyname==_T(""))
	{
		HKEY m_hkey;
		if(RegOpenKeyEx(HKEY_CLASSES_ROOT,m_entry,0,KEY_ALL_ACCESS,&m_hkey)==ERROR_SUCCESS)
		{
			char m_name[200];
			DWORD m_index=0;
			memset(m_name,0,200);

			while(RegEnumKey(m_hkey,m_index,m_name,200)==ERROR_SUCCESS)
			{
				if(strstr(m_name,"Open")!=0 || strstr(m_name,"open")!=0)
				{
					RegCloseKey(m_hkey);

					m_entry+=_T("\\");
					m_entry+=_T(m_name);
					m_entry+=_T("\\Command");
					return m_ini.GetStringKey(HKEY_CLASSES_ROOT,m_entry,_T(""));
				}
				memset(m_name,0,200);
				m_index++;
			}

			RegCloseKey(m_hkey);
		}
		return _T("");
	}
	else
	{
		m_entry+=_T("\\");
		m_entry+=m_keyname;
		m_entry+=_T("\\Command");
	}

	return m_ini.GetStringKey(HKEY_CLASSES_ROOT,m_entry,_T(""));
}

void CMyPropertyPage8::AllLinkToList()
{
	m_linklist.DeleteAllItems();

	HKEY m_key=HKEY_CLASSES_ROOT;
	char m_name[200];
	DWORD m_namelen=200,m_index=0;
	memset(m_name,0,200);

	while(RegEnumKey(m_key,m_index,m_name,m_namelen)==ERROR_SUCCESS)
	{
		if(m_name[0]=='.')
		{
			CString m_exe=FindExecuteFile(m_name);
			if(m_exe!=_T(""))
				InsertNItem(0,(char *)&m_name[1],m_exe.GetBuffer(m_exe.GetLength()));
			else
				InsertNItem(0,(char *)&m_name[1],_T("ϵͳ�ļ�"));
		}
		m_index++;
		m_namelen=200;
		memset(m_name,0,200);
	}
	
	m_linklist.SetItemState(0,LVIF_STATE,LVIS_SELECTED);
}

void CMyPropertyPage8::DeleteLink(CString m_ext)
{
	COrganizeInifile m_ini;
	m_ini.DeleteFileLink(m_ext);
}

void CMyPropertyPage8::AddLink(CString m_ext,CString m_exe,CString m_footname,CString m_menuname)
{
	COrganizeInifile m_ini;
	m_ini.AddFileLink(m_ext,m_exe,m_footname,m_menuname);
}

void CMyPropertyPage8::OnChangeFootname() 
{
	EnablePanel();
}

void CMyPropertyPage8::OnChangeMenuname() 
{
	EnablePanel();
}

void CMyPropertyPage8::OnRefresh() 
{
	AllLinkToList();
}

void CMyPropertyPage8::OnLink() 
{
	AddLink(m_extname,m_linkfile,m_foot,m_menu);
	OnRefresh();
}

void CMyPropertyPage8::OnClearemptydir() 
{
	UpdateData(TRUE);
	m_sheet->m_ClearEmpty=m_clear;
}

BOOL CMyPropertyPage8::PreTranslateMessage(MSG* pMsg) 
{
	m_tooltip.RelayEvent(pMsg);
	
	return CPropertyPage::PreTranslateMessage(pMsg);
}
