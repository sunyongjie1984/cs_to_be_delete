#include "stdafx.h"
#include "resource.h"
#include "OrganizeInifile.h"
#include "CalendarConvert.h"
#include "shlobj.h"
#include "io.h"
#include "MyPropertyPage1.h"
#include "ChangePassword.h"
#include "MyPropertySheet.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

extern CMyPropertySheet *m_sheet;


IMPLEMENT_DYNCREATE(CMyPropertyPage1, CPropertyPage)
IMPLEMENT_DYNCREATE(CMyPropertyPage2, CPropertyPage)
IMPLEMENT_DYNCREATE(CMyPropertyPage3, CPropertyPage)
IMPLEMENT_DYNCREATE(CMyPropertyPage4, CPropertyPage)



CMyPropertyPage1::CMyPropertyPage1() : CPropertyPage(CMyPropertyPage1::IDD)
{
	//{{AFX_DATA_INIT(CMyPropertyPage1)
	m_wallpaper = _T("");
	m_exefile = _T("");
	m_error = _T("");
	m_ondesk = FALSE;
	m_onstart = FALSE;
	m_onstatus = FALSE;
	m_shortname = _T("");
	//}}AFX_DATA_INIT

	m_wallmode=0;
}

CMyPropertyPage1::~CMyPropertyPage1()
{
}

void CMyPropertyPage1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyPropertyPage1)
	DDX_Control(pDX, IDC_DELWALLPAPER, m_delctrl);
	DDX_Control(pDX, IDC_BROWSEWALLPAPER, m_ctrl2);
	DDX_Control(pDX, IDC_BROWSEEXECUTE, m_ctrl1);
	DDX_Control(pDX, IDC_SHORTNAME, m_shortnamectrl);
	DDX_Control(pDX, IDC_SHORTCUTTREE, m_shortctrl);
	DDX_Control(pDX, IDC_CENTER, m_centerctrl);
	DDX_Control(pDX, IDC_TILE, m_tilectrl);
	DDX_Control(pDX, IDC_ONSTATUSBAR, m_onstatusctrl);
	DDX_Control(pDX, IDC_ONSTARTMENU, m_onstartctrl);
	DDX_Control(pDX, IDC_ONDESK, m_ondeskctrl);
	DDX_Control(pDX, IDC_CREATESHORTCUT, m_createshort);
	DDX_Control(pDX, IDC_SETWALLPAPER, m_setpaper);
	DDX_Text(pDX, IDC_WALLPAPER, m_wallpaper);
	DDX_Text(pDX, IDC_EXECUTEFILE, m_exefile);
	DDX_Text(pDX, IDC_ERRORPROMPT, m_error);
	DDX_Check(pDX, IDC_ONDESK, m_ondesk);
	DDX_Check(pDX, IDC_ONSTARTMENU, m_onstart);
	DDX_Check(pDX, IDC_ONSTATUSBAR, m_onstatus);
	DDX_Text(pDX, IDC_SHORTNAME, m_shortname);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyPropertyPage1, CPropertyPage)
	//{{AFX_MSG_MAP(CMyPropertyPage1)
	ON_BN_CLICKED(IDC_BROWSEWALLPAPER, OnBrowsewallpaper)
	ON_BN_CLICKED(IDC_BROWSEEXECUTE, OnBrowseexecute)
	ON_EN_CHANGE(IDC_WALLPAPER, OnChangeWallpaper)
	ON_BN_CLICKED(IDC_SETWALLPAPER, OnSetwallpaper)
	ON_BN_CLICKED(IDC_DELWALLPAPER, OnDelwallpaper)
	ON_BN_CLICKED(IDC_CREATESHORTCUT, OnCreateshortcut)
	ON_BN_CLICKED(IDC_DELETESHORTCUT, OnDeleteshortcut)
	ON_BN_CLICKED(IDC_REFRESH, OnRefresh)
	ON_EN_CHANGE(IDC_EXECUTEFILE, OnChangeExecutefile)
	ON_BN_CLICKED(IDC_CENTER, OnCenter)
	ON_BN_CLICKED(IDC_TILE, OnTile)
	ON_EN_CHANGE(IDC_SHORTNAME, OnChangeShortname)
	ON_BN_CLICKED(IDC_ONDESK, OnOndesk)
	ON_BN_CLICKED(IDC_ONSTARTMENU, OnOnstartmenu)
	ON_BN_CLICKED(IDC_ONSTATUSBAR, OnOnstatusbar)
	ON_NOTIFY(NM_RCLICK, IDC_SHORTCUTTREE, OnRclickShortcuttree)
	ON_NOTIFY(TVN_KEYDOWN, IDC_SHORTCUTTREE, OnKeydownShortcuttree)
	ON_NOTIFY(TVN_ENDLABELEDIT, IDC_SHORTCUTTREE, OnEndlabeleditShortcuttree)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()




CMyPropertyPage2::CMyPropertyPage2() : CPropertyPage(CMyPropertyPage2::IDD)
{
	//{{AFX_DATA_INIT(CMyPropertyPage2)
	m_content =_T("");
	m_filename=_T("");
	m_index = 0;
	m_password=_T("");
	m_sindex = 0;
	m_searchtitle=_T("");
	m_error = _T("");
	m_title = _T("");
	//}}AFX_DATA_INIT

	m_DataFile=NULL;
	m_passright=FALSE;
	m_haveinit=FALSE;
	m_pitchitems=0;
	m_filename=AfxGetApp()->GetProfileString("ϵͳ����","�����ļ�","");
	if(!FileExist(m_filename))
		m_filename=_T("");
}

CMyPropertyPage2::~CMyPropertyPage2()
{
}

void CMyPropertyPage2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyPropertyPage2)
	DDX_Control(pDX, IDC_BROWSE, m_ctrl2);
	DDX_Control(pDX, IDC_ADDITEM, m_ctrl1);
	DDX_Control(pDX, IDC_TITLE, m_titlectrl);
	DDX_Control(pDX, IDC_SEARCHTITLE, m_searchtitlectrl);
	DDX_Control(pDX, IDC_SEARCHSPIN, m_sindexspin);
	DDX_Control(pDX, IDC_SEARCHINDEX, m_sindexctrl);
	DDX_Control(pDX, IDC_SEARCH, m_searchctrl);
	DDX_Control(pDX, IDC_NEXT, m_next);
	DDX_Control(pDX, IDC_LAST, m_last);
	DDX_Control(pDX, IDC_INDEX, m_indexctrl);
	DDX_Control(pDX, IDC_DELETEITEM, m_deletectrl);
	DDX_Control(pDX, IDC_CONTENT, m_contentctrl);
	DDX_Control(pDX, IDC_CHANGEPASS, m_changepass);
	DDX_Control(pDX, IDC_ADDDEC, m_indexspin);
	DDX_Text(pDX, IDC_CONTENT, m_content);
	DDX_Text(pDX, IDC_FILENAME, m_filename);
	DDX_Text(pDX, IDC_INDEX, m_index);
	DDX_Text(pDX, IDC_PASSWORD, m_password);
	DDX_Text(pDX, IDC_SEARCHINDEX, m_sindex);
	DDX_Text(pDX, IDC_SEARCHTITLE, m_searchtitle);
	DDX_Text(pDX, IDC_SHOWERROR, m_error);
	DDX_Text(pDX, IDC_TITLE, m_title);
	//}}AFX_DATA_MAP

	m_haveinit=TRUE;
}


BEGIN_MESSAGE_MAP(CMyPropertyPage2, CPropertyPage)
	//{{AFX_MSG_MAP(CMyPropertyPage2)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_BN_CLICKED(IDC_SEARCH, OnSearch)
	ON_BN_CLICKED(IDC_ADDITEM, OnAdditem)
	ON_BN_CLICKED(IDC_DELETEITEM, OnDeleteitem)
	ON_BN_CLICKED(IDC_LAST, OnLast)
	ON_BN_CLICKED(IDC_NEXT, OnNext)
	ON_EN_CHANGE(IDC_INDEX, OnChangeIndex)
	ON_EN_CHANGE(IDC_SEARCHTITLE, OnChangeSearchtitle)
	ON_EN_CHANGE(IDC_TITLE, OnChangeTitle)
	ON_EN_CHANGE(IDC_CONTENT, OnChangeContent)
	ON_EN_CHANGE(IDC_FILENAME, OnChangeFilename)
	ON_EN_CHANGE(IDC_PASSWORD, OnChangePassword)
	ON_EN_CHANGE(IDC_SEARCHINDEX, OnChangeSearchindex)
	ON_BN_CLICKED(IDC_CHANGEPASS, OnChangepass)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


CEverydayTask::CEverydayTask()
{
	m_aliasname=_T("�����������");
	m_content=_T("�����ڴ˴�����������Ϣ");
	SYSTEMTIME m_time;
	GetLocalTime(&m_time);

	CCalendarConvert m_cal;
	CALENDAR m_first(m_time.wYear,m_time.wMonth,m_time.wDay);
	CALENDAR m_this=m_cal.GetDateAfterDays(m_first,10);
	m_year=m_this.year;
	m_month=m_this.month;
	m_day=m_this.day;
	m_days=2;
	m_hour=m_time.wHour;
	m_minute=m_time.wMinute;
	m_over=TRUE;
}

void CEverydayTask::FromFile(CFile& m_file)
{
	int  m_len=0;
	m_file.Read((char *)&m_len,sizeof(int));
	char * m_buffer=new char[m_len+1]; 
	memset(m_buffer,0,m_len+1);
	m_file.Read(m_buffer,m_len);
	m_aliasname=_T(m_buffer);
	delete m_buffer;

	m_file.Read((char *)&m_len,sizeof(int));
	m_buffer=new char[m_len+1]; 
	memset(m_buffer,0,m_len+1);
	m_file.Read(m_buffer,m_len);
	m_content=_T(m_buffer);
	delete m_buffer;

	m_file.Read((char *)&m_year,sizeof(int));
	m_file.Read((char *)&m_month,sizeof(int));
	m_file.Read((char *)&m_day,sizeof(int));
	m_file.Read((char *)&m_days,sizeof(int));
	m_file.Read((char *)&m_hour,sizeof(int));
	m_file.Read((char *)&m_minute,sizeof(int));
	m_file.Read((char *)&m_over,sizeof(int));
}

void CEverydayTask::ToFile(CFile& m_file)
{
	int  m_len=m_aliasname.GetLength();
	m_file.Write((char *)&m_len,sizeof(int));
	char * m_buffer=m_aliasname.GetBuffer(m_len);
	m_file.Write(m_buffer,m_len);

	m_len=m_content.GetLength();
	m_file.Write((char *)&m_len,sizeof(int));
	m_buffer=m_content.GetBuffer(m_len);
	m_file.Write(m_buffer,m_len);

	m_file.Write((char *)&m_year,sizeof(int));
	m_file.Write((char *)&m_month,sizeof(int));
	m_file.Write((char *)&m_day,sizeof(int));
	m_file.Write((char *)&m_days,sizeof(int));
	m_file.Write((char *)&m_hour,sizeof(int));
	m_file.Write((char *)&m_minute,sizeof(int));
	m_file.Write((char *)&m_over,sizeof(int));
}

BOOL CEverydayTask::IsOverDate()
{
	SYSTEMTIME m_time;
	GetLocalTime(&m_time);

	CCalendarConvert m_cal;
	CALENDAR m_newday,m_oldday;
	m_cal.MakeCalendar(&m_newday,m_time.wYear,m_time.wMonth,m_time.wDay);
	m_cal.MakeCalendar(&m_oldday,m_year,m_month,m_day);
	return (m_cal.CompareTwoDate(m_newday,m_oldday)>0);
}

BOOL CEverydayTask::AtLimited()
{
	if(IsOverDate())
		return FALSE;

	SYSTEMTIME m_time;
	GetLocalTime(&m_time);
	CCalendarConvert m_cal;
	CALENDAR m_newday,m_oldday;
	m_cal.MakeCalendar(&m_newday,m_time.wYear,m_time.wMonth,m_time.wDay);
	m_cal.MakeCalendar(&m_oldday,m_year,m_month,m_day);
	if(m_cal.GetGongDays(m_newday,m_oldday)<=m_days)
		return TRUE;
	return FALSE;
}

BOOL CEverydayTask::ReachTime()
{
	if(!AtLimited())
		return FALSE;

	SYSTEMTIME m_time;
	GetLocalTime(&m_time);
	BOOL m_reach=FALSE;
	if(m_time.wHour==m_hour && m_time.wMinute==m_minute)
		m_reach=TRUE;
	return m_reach;
}

BOOL CEverydayTask::KeepInQuene()
{
	if(IsOverDate() && m_over)
		return FALSE;
	return TRUE;
}




CMyPropertyPage3::CMyPropertyPage3() : CPropertyPage(CMyPropertyPage3::IDD)
{
	//{{AFX_DATA_INIT(CMyPropertyPage3)
	m_aliasname = _T("");
	m_content = _T("");
	m_over =FALSE;
	m_day  =0;
	m_month=0;
	m_year =0;
	m_days =0;
	m_hour =0;
	m_minute=0;
	//}}AFX_DATA_INIT

	SYSTEMTIME m_stime;
	GetLocalTime(&m_stime);
	m_year =(int)m_stime.wYear;
	m_month=(int)m_stime.wMonth;
	m_day  =(int)m_stime.wDay;
	m_hour =(int)m_stime.wHour;
	m_minute=(int)m_stime.wMinute;

	m_tasks=NULL;
	m_curindex=-1;
}

CMyPropertyPage3::~CMyPropertyPage3()
{
}

void CMyPropertyPage3::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyPropertyPage3)
	DDX_Control(pDX, IDC_ADDNOTICE, m_ctrl1);
	DDX_Control(pDX, IDC_WARNMINUTE, m_minutectrl);
	DDX_Control(pDX, IDC_WARNHOUR, m_hourctrl);
	DDX_Control(pDX, IDC_OVERDELETE, m_overctrl);
	DDX_Control(pDX, IDC_DAYS, m_daysctrl);
	DDX_Control(pDX, IDC_DATEDAY, m_dayctrl);
	DDX_Control(pDX, IDC_DATEMONTH, m_monthctrl);
	DDX_Control(pDX, IDC_DATEYEAR, m_yearctrl);
	DDX_Control(pDX, IDC_NOTICECONTENT, m_contentctrl);
	DDX_Control(pDX, IDC_ALIASNAME, m_aliasctrl);
	DDX_Control(pDX, IDC_DELETENOTICE, m_delctrl);
	DDX_Control(pDX, IDC_TASKLIST, m_tasklist);
	DDX_Text(pDX, IDC_ALIASNAME, m_aliasname);
	DDX_Text(pDX, IDC_NOTICECONTENT, m_content);
	DDX_Check(pDX, IDC_OVERDELETE, m_over);
	DDX_Text(pDX, IDC_DATEDAY, m_day);
	DDV_MinMaxInt(pDX, m_day, 1, 31);
	DDX_Text(pDX, IDC_DATEMONTH, m_month);
	DDV_MinMaxInt(pDX, m_month, 1, 12);
	DDX_Text(pDX, IDC_DATEYEAR, m_year);
	DDX_Text(pDX, IDC_DAYS, m_days);
	DDV_MinMaxInt(pDX, m_days, 0, 50);
	DDX_Text(pDX, IDC_WARNHOUR, m_hour);
	DDV_MinMaxInt(pDX, m_hour, 0, 23);
	DDX_Text(pDX, IDC_WARNMINUTE, m_minute);
	DDV_MinMaxInt(pDX, m_minute, 0, 59);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyPropertyPage3, CPropertyPage)
	//{{AFX_MSG_MAP(CMyPropertyPage3)
	ON_BN_CLICKED(IDC_ADDNOTICE, OnAddnotice)
	ON_BN_CLICKED(IDC_DELETENOTICE, OnDeletenotice)
	ON_LBN_SELCHANGE(IDC_TASKLIST, OnSelchangeTasklist)
	ON_EN_CHANGE(IDC_ALIASNAME, OnChangeAliasname)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


CMyPropertyPage4::CMyPropertyPage4() : CPropertyPage(CMyPropertyPage4::IDD)
{
	SYSTEMTIME m_sys;
	GetLocalTime(&m_sys);

	//{{AFX_DATA_INIT(CMyPropertyPage4)
	m_time   = _T("");
	m_ganzhi = _T("");
	m_gongyear=m_sys.wYear;
	m_nongyear=m_sys.wYear;
	//}}AFX_DATA_INIT

	m_gongday=m_sys.wDay;
	m_gong.FillThis(m_gongyear,m_sys.wMonth,m_gongday);
	CALENDAR m_nongli=m_cal.ConvertToNongLi(m_gong);
	m_nong.year=m_nongli.year;
	m_nong.month=m_nongli.month;
	m_nong.day=m_nongli.day;
	m_nongyear=m_nong.year;
	m_nongday=m_nong.day;
		
	m_memdc=NULL;
	m_oldbit=NULL;
	m_oldpen=NULL;
	m_itemw=16;
	m_itemh=16;
}

CMyPropertyPage4::~CMyPropertyPage4()
{
	ReleaseMemdc();
}

void CMyPropertyPage4::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyPropertyPage4)
	DDX_Control(pDX, IDC_NONGRECT, m_nongrect);
	DDX_Control(pDX, IDC_GONGRECT, m_gongrect);
	DDX_Control(pDX, IDC_NONGMONTH, m_nongmonth);
	DDX_Control(pDX, IDC_GONGMONTH, m_gongmonth);
	DDX_Text(pDX, IDC_TIME, m_time);
	DDX_Text(pDX, IDC_GANZHI, m_ganzhi);
	DDX_Text(pDX, IDC_GONGYEAR, m_gongyear);
	DDX_Text(pDX, IDC_NONGYEAR, m_nongyear);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyPropertyPage4, CPropertyPage)
	//{{AFX_MSG_MAP(CMyPropertyPage4)
	ON_WM_TIMER()
	ON_WM_PAINT()
	ON_EN_CHANGE(IDC_GONGYEAR, OnChangeGongyear)
	ON_EN_CHANGE(IDC_NONGYEAR, OnChangeNongyear)
	ON_WM_LBUTTONDOWN()
	ON_CBN_SELCHANGE(IDC_GONGMONTH, OnSelchangeGongmonth)
	ON_CBN_SELCHANGE(IDC_NONGMONTH, OnSelchangeNongmonth)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()






BOOL CMyPropertyPage1::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	m_tooltip.Create(this);
	m_tooltip.Activate(TRUE);
	m_tooltip.AddTool(GetDlgItem(IDC_WALLPAPER),"����������ǽֽ�ļ���");
	m_tooltip.AddTool(GetDlgItem(IDC_BROWSEWALLPAPER),"���ǽֽ�ļ�");
	m_tooltip.AddTool(GetDlgItem(IDC_SETWALLPAPER),"������ǽֽ");
	m_tooltip.AddTool(GetDlgItem(IDC_DELWALLPAPER),"ɾ����ǰǽֽ");
	m_tooltip.AddTool(GetDlgItem(IDC_CENTER),"��ǽֽ����Ļ����(������)");
	m_tooltip.AddTool(GetDlgItem(IDC_TILE),"��ǽֽ������Ļ(�ص��̷�)");
	m_tooltip.AddTool(GetDlgItem(IDC_EXECUTEFILE),"Ҫ������ݷ�ʽ�Ŀ�ִ���ļ���");
	m_tooltip.AddTool(GetDlgItem(IDC_BROWSEEXECUTE),"Ѱ�ҿ�ִ���ļ�");
	m_tooltip.AddTool(GetDlgItem(IDC_SHORTNAME),"��ݷ�ʽȫ��");
	m_tooltip.AddTool(GetDlgItem(IDC_CREATESHORTCUT),"������ݷ�ʽ");
	m_tooltip.AddTool(GetDlgItem(IDC_ONDESK),"����ݷ�ʽ�ŵ�������");
	m_tooltip.AddTool(GetDlgItem(IDC_ONSTARTMENU),"����ݷ�ʽ�ŵ�Windows�����˵�");
	m_tooltip.AddTool(GetDlgItem(IDC_ONSTATUSBAR),"����ݷ�ʽ�ŵ�Windows״̬��");
	m_tooltip.AddTool(GetDlgItem(IDC_SHORTCUTTREE),"Windows�������ݷ�ʽ�б�");

	InitPanel();
	EnablePanel();
	return TRUE;
}

void CMyPropertyPage1::ShortcutToTree()
{
	m_shortctrl.DeleteAllItems();

	HTREEITEM m_root=CreateTree(m_shortctrl,"�ҵĵ���");
	HTREEITEM m_child=InsertTreeItem(m_shortctrl,"����",1000,m_root,0);
	char m_buffer[255],m_windir[255];
	GetWindowsDirectory(m_buffer,255);
	int  m_len=strlen(m_buffer);
	if(m_buffer[m_len-1]!='\\')
		strcat(m_buffer,"\\");
	wsprintf(m_windir,"%s%s",m_buffer,"Desktop");
	DirToTree(m_shortctrl,m_windir,m_child,1001);

	m_child=InsertTreeItem(m_shortctrl,"״̬��(��Win98)",2000,m_root,0);
	wsprintf(m_windir,"%s%s",m_buffer,"Application Data\\Microsoft\\Internet Explorer\\Quick Launch");
	DirToTree(m_shortctrl,m_windir,m_child,2001);

	m_child=InsertTreeItem(m_shortctrl,"�����˵�",3000,m_root,0);
	wsprintf(m_windir,"%s%s",m_buffer,"Start Menu");
	DirToTree(m_shortctrl,m_windir,m_child,3001);
	
	m_shortctrl.Expand(m_root,TVE_EXPAND);
	m_shortctrl.Expand(m_child,TVE_EXPAND);
	m_shortctrl.SelectItem(m_child);
}

void CMyPropertyPage1::OnRefresh()
{
	ShortcutToTree();
}
void CMyPropertyPage1::InitPanel()
{
	ShortcutToTree();

	COrganizeInifile org;
	m_wallpaper=_T(org.GetStringKey(HKEY_CURRENT_USER,"Control Panel\\desktop","Wallpaper"));
	m_exefile=_T("");
	m_error=m_wallpaper;

	m_ondesk=TRUE;
	m_onstatus=TRUE;
	m_onstart=FALSE;
	m_shortname=_T("");
	CheckRadioButton(IDC_CENTER,IDC_TILE,(m_wallmode==0)?IDC_CENTER:IDC_TILE);

	UpdateData(FALSE);
}
void CMyPropertyPage1::EnablePanel()
{
	UpdateData(TRUE);
	BOOL m_enable=FileExist(m_wallpaper);
	m_setpaper.EnableWindow(m_enable);
	m_centerctrl.EnableWindow(m_enable);
	m_tilectrl.EnableWindow(m_enable);

	m_enable=FileExist(m_exefile);
	m_shortnamectrl.EnableWindow(m_enable);
	
	m_onstatusctrl.EnableWindow(m_enable&&(!m_onstart));
	m_ondeskctrl.EnableWindow(m_enable&&(!m_onstart));
	m_onstartctrl.EnableWindow(m_enable && (!(m_ondesk || m_onstatus)));

	m_enable=(m_enable && (m_shortname!=_T("")));
	m_createshort.EnableWindow(m_enable);
}

void CMyPropertyPage1::SetWallpaper(CString m_file,int m_mode)
{
	UpdateData(TRUE);
	COrganizeInifile org;
	char buffer[10];
	wsprintf(buffer,"%d",0);
	org.CreateStringKey(HKEY_CURRENT_USER,"Control Panel\\desktop","WallpaperStyle",buffer);
	wsprintf(buffer,"%d",m_mode);
	org.CreateStringKey(HKEY_CURRENT_USER,"Control Panel\\desktop","TileWallpaper",buffer);

	char * filename=m_file.GetBuffer(m_file.GetLength());
	SystemParametersInfo(SPI_SETDESKWALLPAPER,m_mode,filename,
	       SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
}

void CMyPropertyPage1::DelWallpaper()
{
	SystemParametersInfo(SPI_SETDESKWALLPAPER,m_wallmode,"",
	       SPIF_UPDATEINIFILE|SPIF_SENDWININICHANGE);
}

CString CMyPropertyPage1::GetShortcutPath(HTREEITEM hitem)
{
	if((hitem==NULL) || (hitem==m_shortctrl.GetRootItem()))
		return _T("");

	char windows[200];
	GetWindowsDirectory(windows,200);
	CString m_itemname,ret,middle;
	DWORD m_data=m_shortctrl.GetItemData(hitem);
	if(m_data==1000 || m_data==2000 || m_data==3000)
	{
		m_itemname=m_shortctrl.GetItemText(hitem);
		if(m_itemname.Find("����")!=-1)
		{
			ret=_T(windows);
			ret+=_T("\\Desktop");
		}
		if(m_itemname.Find("����")!=-1)
		{
			ret=_T(windows);
			ret+=_T("\\Start Menu");
		}
		if(m_itemname.Find("״̬")!=-1)
		{
			ret=_T(windows);
			ret+=_T("\\Application Data\\Microsoft\\Internet Explorer\\Quick Launch");
		}
		return ret;
	}

	if(m_shortctrl.ItemHasChildren(hitem))
		m_itemname=m_shortctrl.GetItemText(hitem);
	ret=m_itemname;
	HTREEITEM temp=m_shortctrl.GetParentItem(hitem);
	while(temp)
	{
		m_itemname=m_shortctrl.GetItemText(temp);
		if(m_itemname.Find("����")!=-1)
		{
			middle=_T(windows);
			if(ret!=_T(""))
				middle+=_T("\\Desktop\\")+ret;
			else
				middle+=_T("\\Desktop");
			ret=middle;
			break;
		}
		if(m_itemname.Find("�����˵�")!=-1)
		{
			middle=_T(windows);
			if(ret!=_T(""))
				middle+=_T("\\Start Menu\\")+ret;
			else
				middle+=_T("\\Start Menu");
			ret=middle;
			break;
		}
		if(m_itemname.Find("״̬")!=-1)
		{
			middle=_T(windows);
			if(ret!=_T(""))
				middle+=_T("\\Application Data\\Microsoft\\Internet Explorer\\Quick Launch\\")+ret;
			else
				middle+=_T("\\Application Data\\Microsoft\\Internet Explorer\\Quick Launch");
			ret=middle;
			break;
		}

		if(ret!=_T(""))
			middle=m_itemname+_T("\\")+ret;
		else
			middle=m_itemname;
		ret=middle;
		temp=m_shortctrl.GetParentItem(temp);
	}
	return ret;
}

void CMyPropertyPage1::CreateShortcut(CString m_file,CString m_name)
{
	CString m_path;
	char windows[200];
	GetWindowsDirectory(windows,200);
	if(m_ondesk)
	{
		m_path=_T(windows);
		m_path+=_T("\\Desktop\\");
		m_path+=m_name;
		m_path+=_T(".lnk");
		CreateShellObjectLink(m_file.GetBuffer(m_file.GetLength()),m_name.GetBuffer(m_name.GetLength()),m_path.GetBuffer(m_path.GetLength()));
		if(!m_onstatus)
		{
			ShortcutToTree();
			return ;
		}
	}
	if(m_onstatus)
	{
		m_path=_T(windows);
		m_path+=_T("\\Application Data\\Microsoft\\Internet Explorer\\Quick Launch\\");
		m_path+=m_name;
		m_path+=_T(".lnk");
		CreateShellObjectLink(m_file.GetBuffer(m_file.GetLength()),m_name.GetBuffer(m_name.GetLength()),m_path.GetBuffer(m_path.GetLength()));
		ShortcutToTree();
		return ;
	}
	
	HTREEITEM m_item=m_shortctrl.GetSelectedItem();
	m_path=GetShortcutPath(m_item);
	m_path+=_T("\\");
	m_path+=m_name;
	m_path+=_T(".lnk");
	CreateShellObjectLink(m_file.GetBuffer(m_file.GetLength()),m_name.GetBuffer(m_name.GetLength()),m_path.GetBuffer(m_path.GetLength()));
	ShortcutToTree();
}

void CMyPropertyPage1::OnBrowsewallpaper() 
{
	CFileDialog dlg(TRUE,"*.bmp",m_wallpaper,OFN_FILEMUSTEXIST|OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"ͼƬ�ļ� (*.bmp)|*.bmp||");
	if(dlg.DoModal()==IDOK)
	{
		m_wallpaper=dlg.GetPathName();
		m_error=m_wallpaper;
		UpdateData(FALSE);
		EnablePanel();
	}
}
void CMyPropertyPage1::OnChangeWallpaper() 
{
	EnablePanel();
	m_error=m_wallpaper;
	UpdateData(FALSE);
}
void CMyPropertyPage1::OnSetwallpaper() 
{
	UpdateData(TRUE);
	SetWallpaper(m_wallpaper,m_wallmode);
}
void CMyPropertyPage1::OnDelwallpaper() 
{
	DelWallpaper();
}


void CMyPropertyPage1::OnDeleteshortcut() 
{
	HTREEITEM hSel=m_shortctrl.GetSelectedItem();
	DeleteAllChild(m_shortctrl,hSel);
}

//ɾ�����е�ǰ�����������
void CMyPropertyPage1::DeleteAllChild(CTreeCtrl &tree,HTREEITEM hitem)
{
	if(hitem==NULL)
		return;

	if(tree.ItemHasChildren(hitem))
	{
		HTREEITEM m_child=tree.GetChildItem(hitem);
		while(m_child)
		{
			DeleteAllChild(tree,m_child);
			m_child=tree.GetChildItem(hitem);
		}
		DeleteChild(hitem);
	}
	else
		DeleteChild(hitem);
}

BOOL CMyPropertyPage1::IsDirExist(char *buffer)
{
	BOOL ret=FALSE;
	struct _finddata_t FileBlock;
	char *findfile=new char[strlen(buffer)+10];
	wsprintf(findfile,"%s\\*.*",buffer);
	long handle=_findfirst(findfile,&FileBlock);
	if(handle>0)
		ret=TRUE;
	delete findfile;
	return ret;
}

void CMyPropertyPage1::DeleteChild(HTREEITEM hitem)
{
	CString m_path=GetShortcutPath(hitem);
	if(m_path==_T(""))
		return;

	CString m_name=m_shortctrl.GetItemText(hitem);
	m_path+="\\";
	m_path+=m_name;
	if(IsDirExist(m_path.GetBuffer(m_path.GetLength())))
		RemoveDirectory(m_path);
	else
		DeleteFile(m_path);
	m_shortctrl.DeleteItem(hitem);
}

void CMyPropertyPage1::OnCreateshortcut() 
{
	CreateShortcut(m_exefile,m_shortname);
}

void CMyPropertyPage1::OnBrowseexecute() 
{
	CFileDialog dlg(TRUE,"*.exe",m_exefile,OFN_FILEMUSTEXIST|OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"ִ���ļ� (*.exe)|*.exe||");
	if(dlg.DoModal()==IDOK)
	{
		m_exefile=dlg.GetPathName();
		m_error=m_exefile;
		UpdateData(FALSE);
		EnablePanel();
	}
}
void CMyPropertyPage1::OnChangeExecutefile() 
{
	EnablePanel();
	m_error=m_exefile;
	UpdateData(FALSE);
}


BOOL CMyPropertyPage1::FileExist(CString m_file)
{
	BOOL ret=FALSE;
	if(m_file==_T(""))
		return ret;
	HANDLE file=CreateFile(m_file,0,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(file!=INVALID_HANDLE_VALUE)
	{
		CloseHandle(file);
		ret=TRUE;
	}
	return ret;
}

void CMyPropertyPage1::OnCenter() 
{
	m_wallmode=0;
}
void CMyPropertyPage1::OnTile() 
{
	m_wallmode=1;
}

BOOL CMyPropertyPage1::CreateShellObjectLink(char * sObjectPath,char *sDescription,char *sLinkPath)
{
	IShellLink * shelllink;
	CoInitialize(NULL);
	HRESULT res=CoCreateInstance(CLSID_ShellLink,NULL,
		 CLSCTX_INPROC_SERVER,IID_IShellLink,(LPVOID *)&shelllink);
	if(res==S_OK)
	{
		IPersistFile * file;
		shelllink->SetPath(sObjectPath);
		shelllink->SetDescription(sDescription);
		res=shelllink->QueryInterface(IID_IPersistFile,(void * *)&file);
	     if(res==S_OK)
		{
			WORD wstr[MAX_PATH];
			MultiByteToWideChar(CP_ACP,0,sLinkPath,-1,wstr,MAX_PATH);
			res=file->Save(wstr,TRUE);
			file->Release();
		}
	     shelllink->Release();
	}						
	CoUninitialize();
	return (res==S_OK)?TRUE:FALSE;
}

//������
HTREEITEM CMyPropertyPage1::CreateTree(CTreeCtrl &tree,char * text)
{
	TV_INSERTSTRUCT tci;
	tci.item.mask=TVIF_TEXT|TVIF_PARAM;
	tci.item.stateMask=0;
	tci.item.pszText=text;
	tci.item.iImage=I_IMAGECALLBACK;
	tci.item.iSelectedImage=I_IMAGECALLBACK;
	tci.item.cchTextMax=lstrlen(tci.item.pszText);
	tci.item.lParam=0;
	tci.hParent=NULL;
	tci.hInsertAfter=TVI_LAST;
	return(tree.InsertItem(&tci));
}

//����һ�����
HTREEITEM CMyPropertyPage1::InsertTreeItem(CTreeCtrl &tree,char * text,int index,HTREEITEM parent,int image)
{
	TV_INSERTSTRUCT tci;
	tci.item.mask=TVIF_TEXT|TVIF_PARAM;
	tci.item.stateMask=0;
	tci.item.pszText=text;
	tci.item.iImage=0;
	tci.item.iSelectedImage=image;
	tci.item.cchTextMax=lstrlen(tci.item.pszText);
	tci.item.lParam=index;
	tci.hParent=parent;
	tci.hInsertAfter=TVI_LAST;
	return(tree.InsertItem(&tci));
}

//��Ŀ¼�µ������ļ�����Ŀ¼���뵽����
void CMyPropertyPage1::DirToTree(CTreeCtrl &tree,char *dirname,HTREEITEM root,int iden)
{
	char dir[200];
	int id=iden,ret=0;
	struct _finddata_t fileinfo;
	wsprintf(dir,"%s\\*.*",dirname);
	long handle=_findfirst(dir,&fileinfo);
	while(handle && (ret==0))
	{			
		if(fileinfo.attrib & _A_SUBDIR)
		{
			if((strcmpi(fileinfo.name,".")!=0) && (strcmpi(fileinfo.name,"..")!=0))
			{
				HTREEITEM hCur=InsertTreeItem(tree,fileinfo.name,id,root,0);
				wsprintf(dir,"%s\\%s",dirname,fileinfo.name);
				id++;
				DirToTree(tree,dir,hCur,id);
				id+=30;
			}
		}
		else
		{
			InsertTreeItem(tree,fileinfo.name,id,root,0);
			id++;
		}
		ret=_findnext(handle,&fileinfo);
	}
}

void CMyPropertyPage1::OnChangeShortname() 
{
	EnablePanel();
	m_error=m_shortname;
	UpdateData(FALSE);
}

void CMyPropertyPage1::OnOndesk() 
{
	UpdateData(TRUE);
	m_onstart=!m_ondesk;
	m_error=_T("λ��������");
	EnablePanel();
}
void CMyPropertyPage1::OnOnstartmenu() 
{
	UpdateData(TRUE);
	m_ondesk=!m_onstart;
	m_onstatus=!m_onstart;
	m_error=_T("λ�ڿ�ʼ�˵�����");
	EnablePanel();
}
void CMyPropertyPage1::OnOnstatusbar() 
{
	UpdateData(TRUE);
	m_onstart=!m_onstatus;
	m_error=_T("λ��״̬����(����֧��Win98)");
	EnablePanel();
}

void CMyPropertyPage1::OnRclickShortcuttree(NMHDR* pNMHDR, LRESULT* pResult)
{
	HTREEITEM m_item=m_shortctrl.GetSelectedItem();
	DWORD m_data=m_shortctrl.GetItemData(m_item);

	CMenu menu;
	menu.CreatePopupMenu();
	CPoint point;
	GetCursorPos(&point);

	if(m_item!=m_shortctrl.GetRootItem())
	{
		if(FileExist(m_exefile) && m_shortname!=_T("") && m_onstart)
		{
			if(m_shortctrl.ItemHasChildren(m_item) || m_data==1000 || m_data==2000 || m_data==3000)
				menu.AppendMenu(MF_ENABLED,IDC_CREATESHORTCUT,"������ݷ�ʽ");
		}
		if(!(m_data==1000 || m_data==2000 || m_data==3000))
			menu.AppendMenu(MF_ENABLED,IDC_DELETESHORTCUT,"ɾ����ݷ�ʽ");
	}
	menu.AppendMenu(MF_ENABLED,IDC_REFRESH,"ˢ�¿�ݷ�ʽ");
	menu.TrackPopupMenu(TPM_LEFTALIGN,point.x,point.y,this);
	
	*pResult = 0;
}

void CMyPropertyPage1::OnKeydownShortcuttree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_KEYDOWN* pTVKeyDown=(TV_KEYDOWN*)pNMHDR;

	HTREEITEM hSel=m_shortctrl.GetSelectedItem();
	if(hSel==NULL || hSel==m_shortctrl.GetRootItem())
		return;
	DWORD m_data=m_shortctrl.GetItemData(hSel);
	if(m_data==1000 || m_data==2000 || m_data==3000)
		return;

	switch(pTVKeyDown->wVKey)
	{
	case VK_DELETE:
		OnDeleteshortcut();
		break;
	case VK_F2:
		m_shortctrl.EditLabel(hSel);
		break;
	}
	*pResult = 0;
}

void CMyPropertyPage1::OnEndlabeleditShortcuttree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;

	if(pTVDispInfo->item.pszText==0)
		return ;
	if(pTVDispInfo->item.hItem==NULL || pTVDispInfo->item.hItem==m_shortctrl.GetRootItem())
		return;
	DWORD m_data=m_shortctrl.GetItemData(pTVDispInfo->item.hItem);
	if(m_data==1000 || m_data==2000 || m_data==3000)
		return;

	CString m_path=GetShortcutPath(pTVDispInfo->item.hItem);
	CString m_oldname=m_shortctrl.GetItemText(pTVDispInfo->item.hItem);
	m_shortctrl.SetItemText(pTVDispInfo->item.hItem,pTVDispInfo->item.pszText);
	CString m_newname=m_shortctrl.GetItemText(pTVDispInfo->item.hItem);
	CString m_oldfile=m_path+_T("\\")+m_oldname;
	CString m_newfile=m_path+_T("\\")+m_newname;
	if(m_shortctrl.ItemHasChildren(pTVDispInfo->item.hItem))
		rename(m_oldfile,m_newfile);
	else
		rename(m_oldfile,m_newfile);
	
	*pResult = 0;
}








BOOL CMyPropertyPage4::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	m_tooltip.Create(this);
	m_tooltip.Activate(TRUE);
	m_tooltip.AddTool(GetDlgItem(IDC_GONGYEAR),"�������");
	m_tooltip.AddTool(GetDlgItem(IDC_GONGMONTH),"�����·�");
	m_tooltip.AddTool(GetDlgItem(IDC_NONGYEAR),"ũ�����");
	m_tooltip.AddTool(GetDlgItem(IDC_NONGMONTH),"ũ���·�");

	NongMonthToList();
	GetAllInformation();
	m_ganzhi=m_cal.GetGanZhi(m_nong.year);
	return TRUE;
}

void CMyPropertyPage4::OnTimer(UINT nIDEvent) 
{
	KillTimer(nIDEvent);
	switch(nIDEvent)
	{
	case 100:
		SetTimer(100,1000,NULL);
		ShowTime();
		break;
	}
	CPropertyPage::OnTimer(nIDEvent);
}

BOOL CMyPropertyPage4::OnKillActive() 
{
	KillTimer(100);
	return CPropertyPage::OnKillActive();
}

BOOL CMyPropertyPage4::OnSetActive() 
{
	SetTimer(100,0,NULL);
	return CPropertyPage::OnSetActive();
}

void CMyPropertyPage4::ShowTime()
{
	SYSTEMTIME m_systime;
	GetLocalTime(&m_systime);
	int m_pass=(int)(GetTickCount()/(DWORD)1000);
	m_time.Format("%d:%d:%d,  ����%d��(%d��)",m_systime.wHour,m_systime.wMinute,m_systime.wSecond,m_pass,m_pass/60);
	
	UpdateData(FALSE);
}

void CMyPropertyPage4::OnPaint() 
{
	CPaintDC dc(this);
	ShowPanel(dc);
}

void CMyPropertyPage4::ShowPanel(CDC & dc)
{
	ShowGongDay(dc);
	ShowNongDay(dc);
}
void CMyPropertyPage4::DrawPanel()
{
	DrawGongDay();
	DrawNongDay();
}

void CMyPropertyPage4::ShowGongDay(CDC & dc)
{
	dc.BitBlt(m_rectgong.left,m_rectgong.top,m_rectgong.Width(),
		m_rectgong.Height(),m_memdc,0,0,SRCCOPY);
}
void CMyPropertyPage4::ShowNongDay(CDC & dc)
{
	dc.BitBlt(m_rectnong.left,m_rectnong.top,m_rectnong.Width(),
		m_rectnong.Height(),m_memdc,m_rectnong.Width()+1,0,SRCCOPY);
}

void CMyPropertyPage4::DrawGongDay()
{
	m_memdc->FillRect(&CRect(0,m_itemh,m_rectgong.Width(),m_rectgong.Height()),&CBrush(RGB(192,192,192)));
	CPen m_pen(PS_SOLID,2,RGB(0,0,0));
	m_oldpen=m_memdc->SelectObject(&m_pen);
	m_memdc->MoveTo(1,m_rectgong.Height());
	m_memdc->LineTo(1,1);
	m_memdc->LineTo(m_rectgong.Width(),1);
	if(m_oldpen)
		m_memdc->SelectObject(m_oldpen);

	CPen m_pen1(PS_SOLID,1,RGB(255,255,255));
	m_oldpen=m_memdc->SelectObject(&m_pen1);
	m_memdc->MoveTo(1,m_rectgong.Height()-1);
	m_memdc->LineTo(m_rectgong.Width()-1,m_rectgong.Height()-1);
	m_memdc->LineTo(m_rectgong.Width()-1,0);
	m_memdc->MoveTo(2,m_rectgong.Height()-2);
	m_memdc->LineTo(m_rectgong.Width()-2,m_rectgong.Height()-2);
	m_memdc->LineTo(m_rectgong.Width()-2,1);
	if(m_oldpen)
		m_memdc->SelectObject(m_oldpen);

	m_memdc->SetTextColor(RGB(0,0,0));
	int m_days=m_cal.GetGongMonthDays(m_gong.year,m_gong.month);
	CALENDAR m_gongli(m_gong.year,m_gong.month,1);
	m_gongweekstart=m_cal.GetWeekInfo(m_gongli);
	int m_startx=0;
	int m_starty=0;
	int m_index=0,m_ver=0;
	char buffer[10];
	for(int i=0;i<m_days;i++)
	{
		m_index=(i+m_gongweekstart)%7;
		m_ver=(i+m_gongweekstart)/7+1;
		m_startx=m_index*m_itemw+2;
		m_starty=m_ver*m_itemh+2;
		wsprintf(buffer,"%2d",i+1);
		m_memdc->TextOut(m_startx,m_starty,buffer,strlen(buffer));
	}

	m_index=(m_gong.day+m_gongweekstart-1)%7;
	m_ver=(m_gong.day+m_gongweekstart-1)/7+1;
	int m_left=m_index*m_itemw;
	int m_top=m_ver*m_itemh;
	CRect m_thisrect(m_left,m_top+1,m_left+m_itemw-2,m_top+m_itemh-2);
	CPen m_pen2(PS_SOLID,1,RGB(0,0,0));
	m_oldpen=m_memdc->SelectObject(&m_pen2);
	m_memdc->MoveTo(m_thisrect.left,m_thisrect.bottom);
	m_memdc->LineTo(m_thisrect.left,m_thisrect.top);
	m_memdc->LineTo(m_thisrect.right,m_thisrect.top);
	if(m_oldpen)
		m_memdc->SelectObject(m_oldpen);

	CPen m_pen3(PS_SOLID,1,RGB(255,255,255));
	m_oldpen=m_memdc->SelectObject(&m_pen3);
	m_memdc->MoveTo(m_thisrect.left,m_thisrect.bottom);
	m_memdc->LineTo(m_thisrect.right,m_thisrect.bottom);
	m_memdc->LineTo(m_thisrect.right,m_thisrect.top);
	if(m_oldpen)
		m_memdc->SelectObject(m_oldpen);
	m_memdc->SetTextColor(RGB(255,255,0));
	wsprintf(buffer,"%2d",m_gong.day);
	m_memdc->TextOut(m_left+2,m_top+2,buffer,strlen(buffer));
}
void CMyPropertyPage4::DrawNongDay()
{
	int  m_left=m_rectnong.Width()+1;
	int  m_right=m_left+m_rectnong.Width()-1;
	int  m_bottom=m_rectnong.Height();

	m_memdc->FillRect(&CRect(m_left,m_itemh,m_right,m_rectgong.Height()),&CBrush(RGB(192,192,192)));
	CPen m_pen(PS_SOLID,2,RGB(0,0,0));
	m_oldpen=m_memdc->SelectObject(&m_pen);
	m_memdc->MoveTo(m_left+1,m_bottom);
	m_memdc->LineTo(m_left+1,1);
	m_memdc->LineTo(m_right,1);
	m_memdc->SelectObject(&m_oldpen);

	CPen m_pen1(PS_SOLID,1,RGB(255,255,255));
	m_oldpen=m_memdc->SelectObject(&m_pen1);
	m_memdc->MoveTo(m_left,m_bottom-1);
	m_memdc->LineTo(m_right-1,m_bottom-1);
	m_memdc->LineTo(m_right-1,0);
	m_memdc->MoveTo(m_left+1,m_bottom-2);
	m_memdc->LineTo(m_right-2,m_bottom-2);
	m_memdc->LineTo(m_right-2,1);
	m_memdc->SelectObject(&m_oldpen);


	int m_days=m_cal.GetNongMonthDays(m_nong.year,m_nong.month,m_nong.isrunyue);
	CALENDAR m_nongli(m_nong.year,m_nong.month,1);
	m_nongli.isrunyue=m_nong.isrunyue;
	CALENDAR m_gongli=m_cal.ConvertToGongLi(m_nongli);
	m_nongweekstart=m_cal.GetWeekInfo(m_gongli);
	int m_startx=0;
	int m_starty=0;
	int m_index=0,m_ver=0;
	char buffer[10];
	m_memdc->SetTextColor(RGB(0,0,0));
	for(int i=0;i<m_days;i++)
	{
		m_index=(i+m_nongweekstart)%7;
		m_ver=(i+m_nongweekstart)/7+1;
		m_startx=m_left+m_index*m_itemw+2;
		m_starty=m_ver*m_itemh+2;
		wsprintf(buffer,"%2d",i+1);
		m_memdc->TextOut(m_startx,m_starty,buffer,strlen(buffer));
	}

	m_index=(m_nong.day+m_nongweekstart-1)%7;
	m_ver=(m_nong.day+m_nongweekstart-1)/7+1;
	m_startx=m_left+m_index*m_itemw;
	m_starty=m_ver*m_itemh;

	CRect m_thisrect(m_startx,m_starty+1,m_startx+m_itemw-2,m_starty+m_itemh-2);
	CPen m_pen2(PS_SOLID,1,RGB(0,0,0));
	m_oldpen=m_memdc->SelectObject(&m_pen2);
	m_memdc->MoveTo(m_thisrect.left,m_thisrect.bottom);
	m_memdc->LineTo(m_thisrect.left,m_thisrect.top);
	m_memdc->LineTo(m_thisrect.right,m_thisrect.top);
	if(m_oldpen)
		m_memdc->SelectObject(m_oldpen);

	CPen m_pen3(PS_SOLID,1,RGB(255,255,255));
	m_oldpen=m_memdc->SelectObject(&m_pen3);
	m_memdc->MoveTo(m_thisrect.left,m_thisrect.bottom);
	m_memdc->LineTo(m_thisrect.right,m_thisrect.bottom);
	m_memdc->LineTo(m_thisrect.right,m_thisrect.top);
	if(m_oldpen)
		m_memdc->SelectObject(m_oldpen);

	m_memdc->SetTextColor(RGB(255,255,0));
	wsprintf(buffer,"%2d",m_nong.day);
	m_memdc->TextOut(m_startx+2,m_starty+2,buffer,strlen(buffer));
}

void CMyPropertyPage4::GetAllInformation()
{
	m_nongrect.GetWindowRect(&m_rectnong);
	m_gongrect.GetWindowRect(&m_rectgong);

	ScreenToClient(&m_rectnong);
	ScreenToClient(&m_rectgong);

	m_nongrect.ShowWindow(SW_HIDE);
	m_gongrect.ShowWindow(SW_HIDE);

	m_itemw=m_rectnong.Width()/7;
	m_itemh=m_rectnong.Height()/7;

	CreateMemdc();
}

void CMyPropertyPage4::CreateMemdc()
{
	CBitmap m_bitmap,m_xiaobit;

	int m_width =m_rectnong.Width()+m_rectgong.Width();
	int m_height=m_rectnong.Height();
	CClientDC dc(this);
	int m_bits=dc.GetDeviceCaps(BITSPIXEL);
	m_memdc=new CDC;
	m_memdc->CreateCompatibleDC(&CClientDC(this));
	m_bitmap.CreateBitmap(m_width,m_height,1,m_bits,NULL);
	m_oldbit=m_memdc->SelectObject(&m_bitmap);
	m_memdc->FillRect(&CRect(0,0,m_width,m_height),&CBrush(RGB(192,192,192)));
	m_memdc->FillRect(&CRect(0,0,m_width,m_itemh),&CBrush(RGB(0,128,128)));
	m_memdc->SetTextColor(RGB(255,255,0));
	m_memdc->SetBkMode(TRANSPARENT);
	char buffer[20]="��һ����������";
	for(int i=0;i<7;i++)
	{
		m_memdc->TextOut(m_itemw*i+2,2,(char *)&buffer[i*2],2);
		m_memdc->TextOut(m_rectgong.Width()+3+m_itemw*i,2,(char *)&buffer[i*2],2);
	}

	DrawPanel();
}

void CMyPropertyPage4::ReleaseMemdc()
{
	if(m_memdc)
	{
		if(m_oldbit)
		{
			CBitmap * m_bit=m_memdc->SelectObject(m_oldbit);
			if(m_bit)
				m_bit->DeleteObject();
		}
		delete m_memdc;
	}
}

BOOL CMyPropertyPage4::IsValidateNongDay(int m_day)
{
	int m_days=m_cal.GetNongMonthDays(m_nong.year,m_nong.month,m_nong.isrunyue);
	BOOL m_valid=(m_day>0 && m_day<=m_days);
	if(!m_valid)
		m_nong.day=1;
	return m_valid;
}
BOOL CMyPropertyPage4::IsValidateGongDay(int m_day)
{
	int m_days=m_cal.GetGongMonthDays(m_gong.year,m_gong.month);
	BOOL m_valid=(m_day>0 && m_day<=m_days);
	if(!m_valid)
		m_gong.day=1;
	return m_valid;
}

void CMyPropertyPage4::OnLButtonDown(UINT nFlags, CPoint point) 
{
	int m_left,m_top,m_x,m_y;

	CClientDC dc(this);
	if(m_rectgong.PtInRect(point))
	{
		m_left=point.x-m_rectgong.left;
		m_top=point.y-m_rectgong.top-m_itemh;
		m_x=m_left/m_itemw;
		m_y=m_top/m_itemh;
		int day=m_y*7+m_x-m_gongweekstart+1;
		if(IsValidateGongDay(day))
		{
			m_gong.day=day;
			GongDayChanged();
		}
	}
	if(m_rectnong.PtInRect(point))
	{
		m_left=point.x-m_rectnong.left;
		m_top=point.y-m_rectnong.top-m_itemh;
		m_x=m_left/m_itemw;
		m_y=m_top/m_itemh;
		int day=m_y*7+m_x-m_nongweekstart+1;
		if(IsValidateNongDay(day))
		{
			m_nong.day=day;
			NongDayChanged();
		}
	}

	CPropertyPage::OnLButtonDown(nFlags, point);
}

void CMyPropertyPage4::OnChangeGongyear() 
{
	UpdateData(TRUE);
	if(m_gongyear>1949 && m_gongyear<2050)
	{
		m_gong.year=m_gongyear;
		GongYearChanged();
		m_ganzhi=m_cal.GetGanZhi(m_nong.year);
		UpdateData(FALSE);
	}
}

void CMyPropertyPage4::OnChangeNongyear() 
{
	UpdateData(TRUE);
	if(m_nongyear>1949 && m_nongyear<2050)
	{
		m_nong.year=m_nongyear;
		NongYearChanged();
		m_ganzhi=m_cal.GetGanZhi(m_nong.year);
		UpdateData(FALSE);
	}
}

void CMyPropertyPage4::GongYearChanged()
{
	GongMonthChanged();
}
void CMyPropertyPage4::GongMonthChanged()
{
	GongDayChanged();
}
void CMyPropertyPage4::GongDayChanged()
{
	IsValidateGongDay(m_gong.day);
	GongToNong();
	DrawGongDay();
	CClientDC dc(this);
	ShowGongDay(dc);
	UpdateNongli();
}
void CMyPropertyPage4::UpdateGongli()
{
	m_gongyear=m_gong.year;
	m_gongmonth.SetCurSel(m_gong.month-1);
	DrawGongDay();
	CClientDC dc(this);
	ShowGongDay(dc);
	UpdateData(FALSE);
}


void CMyPropertyPage4::NongYearChanged()
{
	NongMonthToList();
	OnSelchangeNongmonth();
//	NongMonthChanged();
}
void CMyPropertyPage4::NongMonthChanged()
{
	NongDayChanged();
}
void CMyPropertyPage4::NongDayChanged()
{
	IsValidateNongDay(m_nong.day);
	NongToGong();
	DrawNongDay();
	CClientDC dc(this);
	ShowNongDay(dc);
	UpdateGongli();
}
void CMyPropertyPage4::UpdateNongli()
{
	m_nongyear=m_nong.year;
	NongMonthToList();
	DrawNongDay();
	CClientDC dc(this);
	ShowNongDay(dc);
	UpdateData(FALSE);
}


void CMyPropertyPage4::NongMonthToList()
{
	m_cal.NongMonthToList(m_nongyear,m_nongmonth);
	int m_run=m_cal.GetNongRunYue(m_nongyear);
	m_gongmonth.SetCurSel(m_gong.month-1);
	if(m_nong.month<m_run)
		m_nongmonth.SetCurSel(m_nong.month-1);
	else
	{
		if(m_nong.month==m_run)
		{
			if(m_nong.isrunyue)
				m_nongmonth.SetCurSel(m_nong.month);
			else
				m_nongmonth.SetCurSel(m_nong.month-1);
		}
		else
		{
			if(m_run==0)
				m_nongmonth.SetCurSel(m_nong.month-1);
			else
				m_nongmonth.SetCurSel(m_nong.month);
		}
	}
}

void CMyPropertyPage4::GongToNong()
{
	CALENDAR m_nongli=m_cal.ConvertToNongLi(m_gong);
	m_nong.year=m_nongli.year;
	m_nong.month=m_nongli.month;
	m_nong.day=m_nongli.day;
	m_nong.isrunyue=m_nongli.isrunyue;
}
void CMyPropertyPage4::NongToGong()
{
	CALENDAR m_gongli=m_cal.ConvertToGongLi(m_nong);
	m_gong.year=m_gongli.year;
	m_gong.month=m_gongli.month;
	m_gong.day=m_gongli.day;
}

void CMyPropertyPage4::OnSelchangeGongmonth() 
{
	m_gong.month=m_gongmonth.GetCurSel()+1;
	GongMonthChanged();
}

void CMyPropertyPage4::OnSelchangeNongmonth()
{
	int month=m_nongmonth.GetCurSel();
	int m_run=m_cal.GetNongRunYue(m_nong.year);
	if(m_run==0)			 //�����û������
	{
		m_nong.month=month+1;
		m_nong.isrunyue=FALSE;
	}
	else					 //�����������
	{
		if(month==m_run)	 //ѡ������
		{
			m_nong.month=month;
			m_nong.isrunyue=TRUE;
		}
		else				 //û��ѡ������
		{
			m_nong.isrunyue=FALSE;
			if(month<m_run)
				m_nong.month=month+1;
			else
				m_nong.month=month;
		}
	}
	NongMonthChanged();
}




void CMyPropertyPage2::OnBrowse() 
{
	CFileDialog dlg(TRUE,"*.dcq",m_filename,OFN_FILEMUSTEXIST|OFN_HIDEREADONLY,"�����ļ� (*.dcq)|*.dcq||");
	if(dlg.DoModal()==IDOK)
	{
		m_filename=dlg.GetPathName();
		UpdateData(FALSE);
		ReadFromFile(m_filename);
	}
}

void CMyPropertyPage2::OnAdditem()
{
	if(m_filename==_T(""))
	{
		CFileDialog dlg(FALSE,"*.dcq",m_filename,OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"�����ļ� (*.dcq)|*.dcq||");
		if(dlg.DoModal()==IDOK)
		{
			m_filename=dlg.GetPathName();
			UpdateData(FALSE);
			CreateDataFile(m_filename);
			ReadFromFile(m_filename);
			OnAdditem();
			return;
		}
		else
			return;
	}

	if(m_filehead.m_totalitems>0)
	{
		if(!m_passright)
		{
			MessageBox("1.������ȷ���ļ�����;\n2.������ȷ�Ŀ����;\n3.�ٲ�����");
			return;
		}
		else
		{
			SaveCurData(m_index);
			m_filehead.m_totalitems++;
			m_title=_T("���ڴ˴�����ע��");
			m_content=_T("���ڴ˴���������");
			m_index=m_filehead.m_totalitems;
			m_changed=TRUE;
			UpdateData(FALSE);
			m_indexspin.SetRange(1,m_filehead.m_totalitems);
			EnablePanel();
		}
	}
	else
	{
		m_filehead.m_totalitems=1;
		m_title=_T("���ڴ˴�����ע��");
		m_content=_T("���ڴ˴���������");
		m_index=m_filehead.m_totalitems;
		m_changed=TRUE;
		UpdateData(FALSE);
		m_indexspin.SetRange(1,m_filehead.m_totalitems);
		EnablePanel();
	}
}

void CMyPropertyPage2::OnLast() 
{
	SaveCurData(m_index);
	m_index--;
	GetCurData();
	EnablePanel();
}
void CMyPropertyPage2::OnNext() 
{
	SaveCurData(m_index);
	m_index++;
	GetCurData();
	EnablePanel();
}

void CMyPropertyPage2::OnSearch() 
{
	SaveCurData(m_index);

	CString m_info,m_thiscon;
	m_pitchitems=0;
	for(int i=0;i<m_filehead.m_totalitems;i++)
	{
		m_info=GetNTitle(i+1);
		m_thiscon=GetNContent(i+1);
		if((m_info.Find(m_searchtitle)!=-1) || (m_thiscon.Find(m_searchtitle)!=-1))
			m_pitchitems++;
	}
	if(m_pitchitems>0)
	{
		m_sindexspin.SetRange(1,m_pitchitems);
		if(m_sindex>m_pitchitems)
			m_sindex=m_pitchitems;
		if(m_sindex<1)
			m_sindex=1;
		SetSearchItem(m_sindex);
	}
	m_error.Format("�ҵ�%d����¼",m_pitchitems);
	UpdateData(FALSE);
	EnablePanel();
}

void CMyPropertyPage2::SetSearchItem(int index)
{
	CString m_info,m_thiscon;
	int m_num=0;
	for(int i=0;i<m_filehead.m_totalitems;i++)
	{
		m_info=GetNTitle(i+1);
		m_thiscon=GetNContent(i+1);
		if((m_info.Find(m_searchtitle)!=-1) || (m_thiscon.Find(m_searchtitle)!=-1))
		{
			m_num++;
			if(m_num==index)
			{
				m_index=i+1;
				GetCurData();
			}
		}
	}
}

void CMyPropertyPage2::DeleteNItem(int index)
{
	m_title=_T("");
	m_content=_T("");
	char m_buffer[6001];

	DWORD m_start=0;
	for(int i=index;i<m_filehead.m_totalitems;i++)
	{
		m_start=i*6000L;
		m_DataFile->Seek(m_start,CFile::begin);
		m_DataFile->Read(m_buffer,6000);

		m_start-=6000L;
		m_DataFile->Seek(m_start,CFile::begin);
		m_DataFile->Write(m_buffer,6000);
	}

	m_filehead.m_totalitems--;
	m_filehead.ToFile(*m_DataFile);
	m_DataFile->SetLength(m_filehead.m_totalitems*6000L+100L);
}

void CMyPropertyPage2::OnDeleteitem() 
{
	DeleteNItem(m_index);
	if(m_index>=m_filehead.m_totalitems)
		m_index=m_filehead.m_totalitems;
	GetCurData();

	if(m_filehead.m_totalitems>0)
		m_indexspin.SetRange(1,m_filehead.m_totalitems);
	else
		m_indexspin.SetRange(0,0);
	EnablePanel();
}

void CMyPropertyPage2::OnChangeIndex() 
{
	if(!m_haveinit)
		return;

	SaveCurData(m_index);
	UpdateData(TRUE);
	if(m_index>m_filehead.m_totalitems)
		m_index=m_filehead.m_totalitems;
	GetCurData();
	EnablePanel();
}
void CMyPropertyPage2::OnChangeSearchtitle() 
{
	EnablePanel();
}
void CMyPropertyPage2::OnChangeTitle() 
{
	m_changed=TRUE;
}
void CMyPropertyPage2::OnChangeContent() 
{
	m_changed=TRUE;
}
void CMyPropertyPage2::CloseCurFile()
{
	if(m_DataFile)
	{
		SaveCurData(m_index);
		m_DataFile->Close();
		delete m_DataFile;
		m_DataFile=NULL;
	}
}
void CMyPropertyPage2::OnChangeFilename() 
{
	if(!m_haveinit)
		return;

	CloseCurFile();
	UpdateData(TRUE);
	m_index=0;
	m_filehead.m_totalitems=0;
	if(FileExist(m_filename))
		ReadFromFile(m_filename);
	EnablePanel();
}

BOOL CMyPropertyPage2::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	if(!m_haveinit)
		return TRUE;

	m_tooltip.Create(this);
	m_tooltip.Activate(TRUE);
	m_tooltip.AddTool(GetDlgItem(IDC_FILENAME),"ָ�����ܺ�������ļ�");
	m_tooltip.AddTool(GetDlgItem(IDC_BROWSE),"Ѱ�Ҽ��ܺ�������ļ�");
	m_tooltip.AddTool(GetDlgItem(IDC_PASSWORD),"���ڴ˴����뱾�ļ��Ŀ���(����Բ��ܽ���)");
	m_tooltip.AddTool(GetDlgItem(IDC_CHANGEPASS),"���Ŀ���");
	m_tooltip.AddTool(GetDlgItem(IDC_SEARCHINDEX),"����������");
	m_tooltip.AddTool(GetDlgItem(IDC_SEARCH),"��ʼ����");
	m_tooltip.AddTool(GetDlgItem(IDC_SEARCHTITLE),"�����ؼ���");
	m_tooltip.AddTool(GetDlgItem(IDC_INDEX),"��ǰ��Ŀ������");
	m_tooltip.AddTool(GetDlgItem(IDC_ADDITEM),"������һ��");
	m_tooltip.AddTool(GetDlgItem(IDC_DELETEITEM),"ɾ����ǰ��(���ɻָ�)");
	m_tooltip.AddTool(GetDlgItem(IDC_TITLE),"�������(���������ؼ���)");
	m_tooltip.AddTool(GetDlgItem(IDC_CONTENT),"��������");

	UpdateData(FALSE);
	ReadFromFile(m_filename);
	InitPanel();
	return TRUE;
}

void CMyPropertyPage2::InitPanel()
{
	if(m_filehead.m_totalitems>0)
	{
		m_index=1;
		UpdateData(FALSE);
		GetCurData();
	}
	EnablePanel();
}

void CMyPropertyPage2::EnablePanel()
{
	if(!m_haveinit)
		return;
	
	UpdateData(TRUE);
	BOOL m_enable=m_passright && m_filehead.m_totalitems>0;
	m_changepass.EnableWindow(m_enable);
	m_sindexspin.EnableWindow(m_enable && m_pitchitems!=0);
	m_sindexctrl.EnableWindow(m_enable && m_pitchitems!=0);
	m_searchtitlectrl.EnableWindow(m_enable);
	m_indexctrl.EnableWindow(m_enable);
	m_indexspin.EnableWindow(m_enable);
	m_titlectrl.EnableWindow(m_enable);
	m_contentctrl.EnableWindow(m_enable);
	m_deletectrl.EnableWindow(m_enable);
	m_searchctrl.EnableWindow(m_enable && m_searchtitle!=_T(""));

	m_enable=m_passright && m_index<m_filehead.m_totalitems;
	m_next.EnableWindow(m_enable);
	m_enable=m_passright && m_index>1;
	m_last.EnableWindow(m_enable);

	UpdateData(FALSE);
}

void CMyPropertyPage2::SaveCurData(int m_curindex)
{
	if(m_changed)
	{
		m_filehead.ToFile(*m_DataFile);
		if(m_curindex<1)
			return ;

		UpdateData(TRUE);
		char buffer[5001];
		DWORD m_start=(m_curindex-1)*6000L+100L;
		m_DataFile->Seek(m_start,CFile::begin);
		memset(buffer,0,1001);
		strcpy(buffer,m_title);
		int m_len=strlen(m_filehead.m_password);
		for(int i=0;i<1000;i++)
			buffer[i]^=m_filehead.m_password[i%m_len];
		m_DataFile->Write(buffer,1000);

		m_start=(m_curindex-1)*6000L+1100L;
		m_DataFile->Seek(m_start,CFile::begin);
		memset(buffer,0,5001);
		strcpy(buffer,m_content);
		for(i=0;i<5000;i++)
			buffer[i]^=m_filehead.m_password[i%m_len];
		m_DataFile->Write(buffer,5000);

		m_changed=FALSE;
	}
}

CString CMyPropertyPage2::GetNContent(int index)
{
	char m_buffer[5001];
	memset(m_buffer,0,5001);
	DWORD m_start=(index-1)*6000L+1100L;
	m_DataFile->Seek(m_start,CFile::begin);
	m_DataFile->Read(m_buffer,5000);
	int m_len=strlen(m_filehead.m_password);
	for(int i=0;i<5000;i++)
		m_buffer[i]^=m_filehead.m_password[i%m_len];
	return _T(m_buffer);
}

CString CMyPropertyPage2::GetNTitle(int index)
{
	char m_buffer[1001];
	memset(m_buffer,0,1001);
	DWORD m_start=(index-1)*6000L+100L;
	m_DataFile->Seek(m_start,CFile::begin);
	m_DataFile->Read(m_buffer,1000);
	int m_len=strlen(m_filehead.m_password);
	for(int i=0;i<1000;i++)
		m_buffer[i]^=m_filehead.m_password[i%m_len];
	return _T(m_buffer);
}
void CMyPropertyPage2::GetCurData()
{
	if(m_index<=0)
		return;

	m_title=GetNTitle(m_index);
	m_content=GetNContent(m_index);
	UpdateData(FALSE);
}

void CMyPropertyPage2::ReadFromFile(CString m_file)
{
	CopyFile(m_file,m_file+_T(".bak"),FALSE);

	if(FileExist(m_file))
	{
		CloseCurFile();
		m_DataFile=new CFile;
		m_DataFile->Open(m_file,CFile::modeReadWrite|CFile::typeBinary);
		m_filehead.FromFile(*m_DataFile);
		if(m_filehead.m_totalitems>0)
		{
			m_index=1;
			UpdateData(FALSE);
		}
		m_indexspin.SetRange(1,m_filehead.m_totalitems);
		m_passright=(m_password.Compare(m_filehead.m_password)==0);
		EnablePanel();
	}
}

void CMyPropertyPage2::CreateDataFile(CString m_name)
{
	CFile m_openfile;
	if(m_openfile.Open(m_name,CFile::modeCreate|CFile::modeReadWrite|CFile::typeBinary))
	{
		m_filehead.ToFile(m_openfile);
		m_openfile.Close();
	}
}

BOOL CMyPropertyPage2::FileExist(CString m_findfile)
{
	BOOL ret=FALSE;
	HANDLE file=CreateFile(m_findfile,0,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(file!=INVALID_HANDLE_VALUE)
	{
		CloseHandle(file);
		ret=TRUE;
	}
	return ret;
}

void CMyPropertyPage2::OnOK() 
{
	if(m_DataFile!=0)
		SaveCurData(m_index);
	CloseCurFile();
	AfxGetApp()->WriteProfileString("ϵͳ����","�����ļ�",m_filename);

	CPropertyPage::OnOK();
}

BOOL CMyPropertyPage2::OnQueryCancel() 
{
	if(m_DataFile!=0)
		SaveCurData(m_index);
	return CPropertyPage::OnQueryCancel();
}


void CMyPropertyPage2::OnChangePassword() 
{
	if(!m_haveinit)
		return;

	UpdateData(TRUE);
	m_passright=(m_password.Compare(m_filehead.m_password)==0);
	EnablePanel();
}

void CMyPropertyPage2::OnChangeSearchindex() 
{
	if(!m_haveinit)
		return;

	UpdateData(TRUE);
	if(m_sindex>m_pitchitems)
	{
		m_sindex=m_pitchitems;
		UpdateData(FALSE);
	}
	SetSearchItem(m_sindex);
	EnablePanel();
}

void CMyPropertyPage2::OnChangepass() 
{
	if(!m_haveinit)
		return;

	CChangePassword m_pass;
	if(m_pass.DoModal()==IDOK)
	{
		m_password=m_pass.GetPassword();
		UpdateData(FALSE);
		char *m_newpass=m_password.GetBuffer(m_password.GetLength());
		for(int i=0;i<m_filehead.m_totalitems;i++)
			NItemChangePass(i+1,m_filehead.m_password,m_newpass);
		strcpy(m_filehead.m_password,m_password);
		m_filehead.ToFile(*m_DataFile);
		OnChangePassword();
	}
}

void CMyPropertyPage2::NItemChangePass(int index,char *oldpass,char *newpass)
{
	char m_buffer[6001];
	memset(m_buffer,0,6001);
	DWORD m_start=(index-1)*6000L+100L;
	m_DataFile->Seek(m_start,CFile::begin);
	m_DataFile->Read(m_buffer,6000);
	int m_len=strlen(oldpass);
	for(int i=0;i<1000;i++)
		m_buffer[i]^=oldpass[i%m_len];
	for(i=0;i<5000;i++)
		m_buffer[1000+i]^=oldpass[i%m_len];
	m_len=strlen(newpass);
	for(i=0;i<1000;i++)
		m_buffer[i]^=newpass[i%m_len];
	for(i=0;i<5000;i++)
		m_buffer[1000+i]^=newpass[i%m_len];
	m_DataFile->Seek(m_start,CFile::begin);
	m_DataFile->Write(m_buffer,6000);
}








BOOL CMyPropertyPage3::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	m_tooltip.Create(this);
	m_tooltip.Activate(TRUE);
	m_tooltip.AddTool(GetDlgItem(IDC_TASKLIST),"���е�ǰ��Ч�б�");
	m_tooltip.AddTool(GetDlgItem(IDC_ADDNOTICE),"����һ��������Ϣ");
	m_tooltip.AddTool(GetDlgItem(IDC_DELETENOTICE),"ɾ��һ��������Ϣ");
	m_tooltip.AddTool(GetDlgItem(IDC_NOTICECONTENT),"���ѵ�����");
	m_tooltip.AddTool(GetDlgItem(IDC_ALIASNAME),"������Ϣ����(����)");
	m_tooltip.AddTool(GetDlgItem(IDC_DATEYEAR),"�������");
	m_tooltip.AddTool(GetDlgItem(IDC_DATEMONTH),"�����·�");
	m_tooltip.AddTool(GetDlgItem(IDC_DATEDAY),"������");
	m_tooltip.AddTool(GetDlgItem(IDC_DAYS),"��ǰ��������");
	m_tooltip.AddTool(GetDlgItem(IDC_WARNHOUR),"����������ʱ���Сʱ");
	m_tooltip.AddTool(GetDlgItem(IDC_WARNMINUTE),"����������ʱ��ķ���");
	m_tooltip.AddTool(GetDlgItem(IDC_OVERDELETE),"���ں��Ƿ�ɾ����¼");
	
	InitPanel();
	return TRUE;
}

void CMyPropertyPage3::InitPanel()
{
	m_tasks=m_sheet->m_tasklist;

	int  m_count=m_tasks->GetCount();
	m_tasklist.ResetContent();
	for(int i=0;i<m_count;i++)
	{
		POSITION m_pos=m_tasks->FindIndex(i);
		if(m_pos!=NULL)
		{
			CEverydayTask *m_this=(CEverydayTask *)m_tasks->GetAt(m_pos);
			m_tasklist.AddString(m_this->m_aliasname);
		}
	}
	if(m_tasklist.GetCount()>0)
	{
		m_curindex=0;
		m_tasklist.SetCurSel(m_curindex);
		ItemToPanel(m_curindex);
	}

	EnablePanel();
}

void CMyPropertyPage3::EnablePanel()
{
	BOOL m_enable=m_tasklist.GetCurSel()>=0;
	m_minutectrl.EnableWindow(m_enable);
	m_hourctrl.EnableWindow(m_enable);
	m_overctrl.EnableWindow(m_enable);
	m_daysctrl.EnableWindow(m_enable);
	m_dayctrl.EnableWindow(m_enable);
	m_monthctrl.EnableWindow(m_enable);
	m_yearctrl.EnableWindow(m_enable);
	m_contentctrl.EnableWindow(m_enable);
	m_aliasctrl.EnableWindow(m_enable);
	m_delctrl.EnableWindow(m_enable);
}

void CMyPropertyPage3::ItemToPanel(int m_index)
{
	POSITION m_pos=m_tasks->FindIndex(m_index);
	if(m_pos!=NULL)
	{
		CEverydayTask *m_this=(CEverydayTask *)m_tasks->GetAt(m_pos);
		m_aliasname=m_this->m_aliasname;
		m_content=m_this->m_content;
		m_year=m_this->m_year;
		m_month=m_this->m_month;
		m_day=m_this->m_day;
		m_days=m_this->m_days;
		m_minute=m_this->m_minute;
		m_hour=m_this->m_hour;
		m_over=m_this->m_over;
		UpdateData(FALSE);
	}
}

void CMyPropertyPage3::PanelToItem(int m_index)
{
	UpdateData(TRUE);
	if(m_index<0)
		return;

	POSITION m_pos=m_tasks->FindIndex(m_index);
	if(m_pos!=NULL)
	{
		CEverydayTask *m_this=(CEverydayTask *)m_tasks->GetAt(m_pos);
		m_this->m_aliasname=m_aliasname;
		m_this->m_content=m_content;
		m_this->m_year=m_year;
		m_this->m_month=m_month;
		m_this->m_day=m_day;
		m_this->m_days=m_days;
		m_this->m_minute=m_minute;
		m_this->m_hour=m_hour;
		m_this->m_over=m_over;
	}
}

void CMyPropertyPage3::OnAddnotice() 
{
	PanelToItem(m_curindex);
	CEverydayTask *m_this=new CEverydayTask;
	m_tasks->AddTail(m_this);
	m_curindex=m_tasklist.GetCount();
	m_tasklist.InsertString(m_curindex,m_this->m_aliasname);
	m_tasklist.SetCurSel(m_curindex);
	ItemToPanel(m_curindex);
	EnablePanel();
}

void CMyPropertyPage3::OnDeletenotice() 
{
	m_curindex=m_tasklist.GetCurSel();
	int m_count=m_tasklist.GetCount()-1;
	POSITION m_pos=m_tasks->FindIndex(m_curindex);
	if(m_pos==NULL)
		return;

	CEverydayTask *m_this=(CEverydayTask *)m_tasks->GetAt(m_pos);
	m_tasks->RemoveAt(m_pos);
	delete m_this;
	m_tasklist.DeleteString(m_curindex);
	if(m_curindex>=m_count)
		m_curindex=m_count-1;
	if(m_curindex>=0)
	{
		m_tasklist.SetCurSel(m_curindex);
		ItemToPanel(m_curindex);
	}
	EnablePanel();
}

void CMyPropertyPage3::OnSelchangeTasklist() 
{
	PanelToItem(m_curindex);
	m_curindex=m_tasklist.GetCurSel();
	ItemToPanel(m_curindex);
	EnablePanel();
}

void CMyPropertyPage3::OnChangeAliasname() 
{
	UpdateData(TRUE);
	m_curindex=m_tasklist.GetCurSel();
	POSITION m_pos=m_tasks->FindIndex(m_curindex);
	if(m_pos==NULL)
		return;

	CEverydayTask *m_this=(CEverydayTask *)m_tasks->GetAt(m_pos);
	m_this->m_aliasname=m_aliasname;
	m_tasklist.DeleteString(m_curindex);
	m_tasklist.InsertString(m_curindex,m_aliasname);
	m_tasklist.SetCurSel(m_curindex);
}

BOOL CMyPropertyPage3::OnKillActive() 
{
	PanelToItem(m_curindex);
	return CPropertyPage::OnKillActive();
}

BOOL CMyPropertyPage1::PreTranslateMessage(MSG* pMsg) 
{
	m_tooltip.RelayEvent(pMsg);
	return CPropertyPage::PreTranslateMessage(pMsg);
}

BOOL CMyPropertyPage2::PreTranslateMessage(MSG* pMsg) 
{
	m_tooltip.RelayEvent(pMsg);
	return CPropertyPage::PreTranslateMessage(pMsg);
}



BOOL CMyPropertyPage3::PreTranslateMessage(MSG* pMsg) 
{
	m_tooltip.RelayEvent(pMsg);
	return CPropertyPage::PreTranslateMessage(pMsg);
}

BOOL CMyPropertyPage4::PreTranslateMessage(MSG* pMsg) 
{
	m_tooltip.RelayEvent(pMsg);
	return CPropertyPage::PreTranslateMessage(pMsg);
}

