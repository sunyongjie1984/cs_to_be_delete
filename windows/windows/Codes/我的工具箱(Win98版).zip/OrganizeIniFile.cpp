#include "stdafx.h"
#include "OrganizeInifile.h"


/**********   �����ʹ�÷���   *************
********************************************
INI �ļ��ṹ��
[������Ϣ]
������=1
��1��=yesterday once more;��������;����δ֪

1.   COrganizeInifile org;
	org.SetParameter("c:\\windows\\win.ini","������Ϣ","��%d��");
2.	org.DeleteNItem(5);

3.   ����ͬʱ���Բ�����¼��
********************************************
***********   ʹ�÷�������   **************/



COrganizeInifile::COrganizeInifile()
{
	m_beenset=FALSE;
	m_totalitem=0;
}

void COrganizeInifile::SetParameter(char * inifile,char *yield,char *format)
{
	m_beenset=TRUE;
	strcpy(IniFileName,inifile);
	strcpy(YieldName,yield);
	strcpy(SectionFormat,format);
	m_totalitem=GetPrivateProfileInt(YieldName,"������",0,IniFileName);
}

//ɾ����N��
void COrganizeInifile::DeleteNItem(int n)
{
	if(!m_beenset || n>m_totalitem || m_totalitem<=0)
		return;

	for(int i=n;i<m_totalitem;i++)
		CopyNItemAsMItem(i+1,i);
	m_totalitem--;
	char buffer[100];
	wsprintf(buffer,"%d",m_totalitem);
	WritePrivateProfileString(YieldName,"������",buffer,IniFileName);
}

//����N���Ƶ���һ��
void COrganizeInifile::NItemToHead(int n)
{
	if(!m_beenset || n>m_totalitem || m_totalitem<=0)
		return;
	MoveNItemToMPos(n,1);
}

//����N���Ƶ����һ��
void COrganizeInifile::NItemToTail(int n)
{
	if(!m_beenset || n>m_totalitem || m_totalitem<=0)
		return;
	MoveNItemToMPos(n,m_totalitem);
}

//���Ƶ�N���M��
void COrganizeInifile::CopyNItemAsMItem(int n,int m)
{
	if(!m_beenset || n>m_totalitem || m_totalitem<=0)
		return;

	char buffer[255];
	char section[100];
	wsprintf(section,SectionFormat,n);
	GetPrivateProfileString(YieldName,section,"",buffer,255,IniFileName);

	wsprintf(section,SectionFormat,m);
	WritePrivateProfileString(YieldName,section,buffer,IniFileName);
}

//�ƶ���N�����λ��M
void COrganizeInifile::MoveNItemToMPos(int n,int m)
{
	if(!m_beenset || n>m_totalitem || m_totalitem<=0)
		return;

	char buffer[255];
	char section[100];
	wsprintf(section,SectionFormat,n);
	GetPrivateProfileString(YieldName,section,"",buffer,255,IniFileName);
	DeleteNItem(n);
	InsertItemToNPos(buffer,m);
}

//�����������ݲ��뵽��N��λ��
void COrganizeInifile::InsertItemToNPos(char *buffer,int n)
{
	if(!m_beenset)
		return;

	char section[100];
	m_totalitem++;
	wsprintf(section,"%d",m_totalitem);
	WritePrivateProfileString(YieldName,"������",section,IniFileName);

	for(int i=m_totalitem;i>n;i--)
		CopyNItemAsMItem(i-1,i);

	wsprintf(section,SectionFormat,n);
	WritePrivateProfileString(YieldName,section,buffer,IniFileName);
}

//��N�����M���λ��
void COrganizeInifile::ChangeNMPos(int n,int m)
{
	if(!m_beenset || n>m_totalitem || m_totalitem<=0)
		return;

	char buffer[255];
	char section[100];
	wsprintf(section,SectionFormat,n);
	GetPrivateProfileString(YieldName,section,"",buffer,255,IniFileName);
	CopyNItemAsMItem(m,n);

	wsprintf(section,SectionFormat,m);
	WritePrivateProfileString(YieldName,section,buffer,IniFileName);
}



//��ȡ��Ŀ���ݵĵ�N�����ַ���
char * COrganizeInifile::GetNItemMData(char *buffer,int n)
{
	return GetNSubString(_T(buffer),n);
}

char *COrganizeInifile::GetNSubString(CString config,int n)
{
	int  number=0;
	CString make;
	char buffer[200];
	memset(buffer,0,200);

	make.Format("%c%s%c",';',config,';');
	char *start=make.GetBuffer(make.GetLength());
	int  len=strlen(start);
	for(int i=0;i<len;i++)
	{
		if(start[i]==';')
		{
			number++;
			if(number==n)
			{
				strcpy(buffer,&start[i+1]);
				char *end=strchr(buffer,',');
				strcpy(end,"");
				break;
			}
		}
	}
	return &buffer[0];
}


int  COrganizeInifile::GetNItemMAsInt(char *data,int m)
{
	char buffer[200];
	strcpy(buffer,GetNItemMData(data,m));
	return (atoi(buffer));
}

int  COrganizeInifile::GetNItemMAsInt(int n,int m)
{
	char buffer[200];
	char section[100];
	wsprintf(section,SectionFormat,n);
	GetPrivateProfileString(YieldName,section,"",buffer,200,IniFileName);
	return GetNItemMAsInt(buffer,m);
}


//������¼���ַ�����ֵ(����,�Ӽ�,��ֵ��,��ֵ)
BOOL COrganizeInifile::CreateDwordKey(HKEY parent,char *child,char *keyname,DWORD value)
{
	HKEY handle=NULL,hinter=NULL;
     unsigned long create=0;
	DWORD keyvalue=value;
     LONG ret=RegCreateKeyEx(parent,child,0,"",REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hinter,&create);
	if(ret!=ERROR_SUCCESS)
		return FALSE;
	ret=RegSetValueEx(hinter,keyname,0,REG_DWORD,(BYTE *)&keyvalue,sizeof(DWORD));
	RegCloseKey(hinter);
	return (ret==ERROR_SUCCESS);
}

BOOL COrganizeInifile::CreateBinaryKey(HKEY parent,char *child,char *keyname,long value)
{
	HKEY handle=NULL,hinter=NULL;
     unsigned long create=0,keyvalue=(unsigned long)value;
     LONG ret=RegCreateKeyEx(parent,child,0,"",REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hinter,&create);
	if(ret!=ERROR_SUCCESS)
		return FALSE;
	ret=RegSetValueEx(hinter,keyname,0,REG_BINARY,(BYTE *)&keyvalue,sizeof(DWORD));
	RegCloseKey(hinter);
	return (ret==ERROR_SUCCESS);
}

BOOL COrganizeInifile::CreateStringKey(HKEY parent,char *child,char *keyname,char * keyvalue)
{
	HKEY handle=NULL,hinter=NULL;
     unsigned long create=0;
     LONG ret=RegCreateKeyEx(parent,child,0,"",REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hinter,&create);
	if(ret!=ERROR_SUCCESS)
		return FALSE;
	ret=RegSetValueEx(hinter,keyname,0,REG_SZ,(BYTE *)keyvalue,strlen(keyvalue));
	RegCloseKey(hinter);
	return (ret==ERROR_SUCCESS);
}

//��ȡ��¼���ַ�����ֵ(����,�Ӽ�,��ֵ��,��ֵ)
DWORD COrganizeInifile::GetDwordKey(HKEY parent,char *child,char *keyname)
{
	HKEY keyhand;
	LONG ret=RegOpenKeyEx(parent,child,0,KEY_ALL_ACCESS,&keyhand);
	if(ret!=ERROR_SUCCESS)
		return 0;
	DWORD type=REG_DWORD;
	DWORD data;
     DWORD size=sizeof(DWORD);
	ret=RegQueryValueEx(keyhand,keyname,0,&type,(BYTE *)&data,&size);
	if(ret!=ERROR_SUCCESS)
		return 0;
	RegCloseKey(keyhand);
	return data;
}

char *COrganizeInifile::GetStringKey(HKEY parent,char *child,char *keyname)
{
	HKEY keyhand;
	LONG ret=RegOpenKeyEx(parent,child,0,KEY_ALL_ACCESS,&keyhand);
	if(ret!=ERROR_SUCCESS)
		return NULL;

	DWORD type=REG_SZ;
	char  data[1000];
     DWORD size=1000;
	ret=RegQueryValueEx(keyhand,keyname,0,&type,(BYTE *)&data,&size);
	if(ret!=ERROR_SUCCESS)
		return NULL;
	RegCloseKey(keyhand);
	return &data[0];
}

BOOL COrganizeInifile::DeleteKey(HKEY parent,char *child,char *keyname)
{
	HKEY keyhand;
	LONG ret=RegOpenKeyEx(parent,child,0,KEY_ALL_ACCESS,&keyhand);
	if(ret!=ERROR_SUCCESS)
		return FALSE;

	ret=RegDeleteKey(keyhand,keyname);
	if(ret!=ERROR_SUCCESS)
		return FALSE;

	RegCloseKey(keyhand);
	return (ret==ERROR_SUCCESS);
}

BOOL COrganizeInifile::DeleteKeyValue(HKEY parent,char *child,char *valuename)
{
	HKEY keyhand;
	LONG ret=RegOpenKeyEx(parent,child,0,KEY_ALL_ACCESS,&keyhand);
	if(ret!=ERROR_SUCCESS)
		return FALSE;

	ret=RegDeleteValue(keyhand,valuename);
	if(ret!=ERROR_SUCCESS)
		return FALSE;
	
	RegCloseKey(keyhand);
	return (ret==ERROR_SUCCESS);
}

BOOL COrganizeInifile::SaveKeyAsFile(HKEY parent,char *child,char *filename)
{
	HKEY keyhand;
	LONG ret=RegOpenKeyEx(parent,child,0,KEY_ALL_ACCESS,&keyhand);
	if(ret!=ERROR_SUCCESS)
		return FALSE;

	ret=RegSaveKey(keyhand,filename,NULL);
	if(ret!=ERROR_SUCCESS)
		return FALSE;
	
	RegCloseKey(keyhand);
	return (ret==ERROR_SUCCESS);
}

BOOL COrganizeInifile::SaveFileAsKey(HKEY parent,char *child,char *filename)
{
	DWORD ret=RegLoadKey(parent,child,filename);
	return (ret==ERROR_SUCCESS);
}

BOOL COrganizeInifile::SubkeyExist(HKEY parent,char *child,char *subname)
{
	BOOL m_ret=FALSE;
	HKEY m_key=parent;
	if(RegOpenKeyEx(parent,child,0,KEY_ALL_ACCESS,&m_key)==ERROR_SUCCESS)
	{
		char m_name[200];
		DWORD m_namelen=200,m_index=0;
		memset(m_name,0,200);

		while(RegEnumKey(m_key,m_index,m_name,m_namelen)==ERROR_SUCCESS)
		{
			if(strcmpi(m_name,subname)==0)
			{
				m_ret=TRUE;
				break;
			}
			m_index++;
			m_namelen=200;
			memset(m_name,0,200);
		}
		RegCloseKey(m_key);
	}
	return m_ret;
}

BOOL COrganizeInifile::KeynameExist(HKEY parent,char *child,char *keyname)
{
	BOOL m_ret=FALSE;
	HKEY m_key=parent;
	if(RegOpenKeyEx(parent,child,0,KEY_ALL_ACCESS,&m_key)==ERROR_SUCCESS)
	{
		char m_name[200];
		DWORD m_namelen=200,m_index=0;
		DWORD m_attr=REG_BINARY|REG_DWORD|REG_EXPAND_SZ|REG_MULTI_SZ|REG_NONE|REG_SZ;
		memset(m_name,0,200);

		while(RegEnumValue(m_key,m_index,m_name,&m_namelen,NULL,&m_attr,NULL,NULL)==ERROR_SUCCESS)
		{
			if(strcmpi(m_name,keyname)==0)
			{
				m_ret=TRUE;
				break;
			}
			m_index++;
			m_namelen=200;
			memset(m_name,0,200);
		}
		RegCloseKey(m_key);
	}
	return m_ret;
}

//Visual C++ �汾
BOOL COrganizeInifile::CreateDwordKey(HKEY parent,CString child,CString keyname,DWORD value)
{
	char *m_child=child.GetBuffer(child.GetLength());
	char *m_keyname=keyname.GetBuffer(keyname.GetLength());
	return CreateDwordKey(parent,m_child,m_keyname,value);
}

BOOL COrganizeInifile::CreateBinaryKey(HKEY parent,CString child,CString keyname,long value)
{
	char *m_child=child.GetBuffer(child.GetLength());
	char *m_keyname=keyname.GetBuffer(keyname.GetLength());
	return CreateBinaryKey(parent,m_child,m_keyname,value);
}

BOOL COrganizeInifile::CreateStringKey(HKEY parent,CString child,CString keyname,CString keyvalue)
{
	char *m_child=child.GetBuffer(child.GetLength());
	char *m_keyname=keyname.GetBuffer(keyname.GetLength());
	char *m_keyvalue=keyvalue.GetBuffer(keyvalue.GetLength());
	return CreateStringKey(parent,m_child,m_keyname,m_keyvalue);
}

DWORD COrganizeInifile::GetDwordKey(HKEY parent,CString child,CString keyname)
{
	char *m_child=child.GetBuffer(child.GetLength());
	char *m_keyname=keyname.GetBuffer(keyname.GetLength());
	return GetDwordKey(parent,m_child,m_keyname);
}

CString COrganizeInifile::GetStringKey(HKEY parent,CString child,CString keyname)
{
	char *m_child=child.GetBuffer(child.GetLength());
	char *m_keyname=keyname.GetBuffer(keyname.GetLength());
	return _T(GetStringKey(parent,m_child,m_keyname));
}

BOOL COrganizeInifile::DeleteKey(HKEY parent,CString child,CString keyname)
{
	char *m_child=child.GetBuffer(child.GetLength());
	char *m_keyname=keyname.GetBuffer(keyname.GetLength());
	return DeleteKey(parent,m_child,m_keyname);
}

BOOL COrganizeInifile::DeleteKeyValue(HKEY parent,CString child,CString valuename)
{
	char *m_child=child.GetBuffer(child.GetLength());
	char *m_valuename=valuename.GetBuffer(valuename.GetLength());
	return DeleteKeyValue(parent,m_child,m_valuename);
}

BOOL COrganizeInifile::SaveKeyAsFile(HKEY parent,CString child,CString filename)
{
	char *m_child=child.GetBuffer(child.GetLength());
	char *m_filename=filename.GetBuffer(filename.GetLength());
	return SaveKeyAsFile(parent,m_child,m_filename);
}

BOOL COrganizeInifile::SaveFileAsKey(HKEY parent,CString child,CString filename)
{
	char *m_child=child.GetBuffer(child.GetLength());
	char *m_filename=filename.GetBuffer(filename.GetLength());
	return SaveFileAsKey(parent,m_child,m_filename);
}

BOOL COrganizeInifile::SubkeyExist(HKEY parent,CString child,CString subname)
{
	char *m_child=child.GetBuffer(child.GetLength());
	char *m_subname=subname.GetBuffer(subname.GetLength());
	return SubkeyExist(parent,m_child,m_subname);
}

BOOL COrganizeInifile::KeynameExist(HKEY parent,CString child,CString keyname)
{
	char *m_child=child.GetBuffer(child.GetLength());
	char *m_keyname=keyname.GetBuffer(keyname.GetLength());
	return KeynameExist(parent,m_child,m_keyname);
}

void COrganizeInifile::DeleteFileLink(CString m_extname)
{
	CString m_link=GetStringKey(HKEY_CLASSES_ROOT,_T(".")+m_extname,_T(""));
	DeleteKey(HKEY_CLASSES_ROOT,_T(""),m_link);
	DeleteKey(HKEY_CLASSES_ROOT,_T(""),_T(".")+m_extname);
}

void COrganizeInifile::AddFileLink(CString m_extname,CString m_exefile,CString m_footname,CString m_menuname)
{
	CreateStringKey(HKEY_CLASSES_ROOT,_T(".")+m_extname,_T(""),m_extname);
	CreateStringKey(HKEY_CLASSES_ROOT,m_extname,_T(""),m_footname);
	CreateStringKey(HKEY_CLASSES_ROOT,m_extname+_T("\\DefauleIcon"),_T(""),m_exefile+_T(",1"));
	CreateStringKey(HKEY_CLASSES_ROOT,m_extname+_T("\\shell"),_T(""),m_menuname);

	CString m_thiskey=m_extname+_T("\\shell\\");
	m_thiskey+=m_menuname;
	m_thiskey+=_T("\\Command");
	CreateStringKey(HKEY_CLASSES_ROOT,m_thiskey,_T(""),m_exefile+_T(" \"%1\""));
}