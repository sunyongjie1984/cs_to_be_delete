#include "stdafx.h"
#include "MyToolPad.h"
#include "ChangePassword.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CChangePassword::CChangePassword(CWnd* pParent /*=NULL*/)
	: CDialog(CChangePassword::IDD, pParent)
{
	//{{AFX_DATA_INIT(CChangePassword)
	m_newpass = _T("");
	m_conpass = _T("");
	//}}AFX_DATA_INIT
}


void CChangePassword::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChangePassword)
	DDX_Control(pDX, IDOK, m_ok);
	DDX_Text(pDX, IDC_NEWPASSWORD, m_newpass);
	DDX_Text(pDX, IDC_CONFIRMPASSWORD, m_conpass);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CChangePassword, CDialog)
	//{{AFX_MSG_MAP(CChangePassword)
	ON_EN_CHANGE(IDC_NEWPASSWORD, OnChangeNewpassword)
	ON_EN_CHANGE(IDC_CONFIRMPASSWORD, OnChangeConfirmpassword)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


void CChangePassword::OnChangeNewpassword() 
{
	EnablePanel();
}

void CChangePassword::OnChangeConfirmpassword() 
{
	EnablePanel();
}

BOOL CChangePassword::OnInitDialog() 
{
	CDialog::OnInitDialog();
	EnablePanel();
	m_tooltip.Create(this);
	m_tooltip.Activate(TRUE);
	m_tooltip.AddTool(GetDlgItem(IDC_NEWPASSWORD),"���������¿���");
	m_tooltip.AddTool(GetDlgItem(IDC_CONFIRMPASSWORD),"����ȷ�ϸղ�����Ŀ���");
	return TRUE;
}

void CChangePassword::EnablePanel()
{
	BOOL m_enable=(m_newpass==m_conpass && m_newpass!=_T(""));
	m_ok.EnableWindow(m_enable);
}

CString CChangePassword::GetPassword()
{
	return m_newpass;
}

BOOL CChangePassword::PreTranslateMessage(MSG* pMsg)
{
	m_tooltip.RelayEvent(pMsg);
	return CDialog::PreTranslateMessage(pMsg);	// CG: This was added by the ToolTips component.
}
