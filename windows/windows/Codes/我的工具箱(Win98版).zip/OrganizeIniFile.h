#ifndef __ORGANIZEINIFILE__H_
#define __ORGANIZEINIFILE__H_
#endif


class COrganizeInifile
{
public:
	COrganizeInifile();

public:
	void SetParameter(char * inifile,char *yield,char *format);
	void DeleteNItem(int n);			//ɾ����N��
	void NItemToHead(int n);			//����N���Ƶ���һ��
	void NItemToTail(int n);			//����N���Ƶ����һ��
	void CopyNItemAsMItem(int n,int m);//���Ƶ�N���M��
	void MoveNItemToMPos(int n,int m);	//�ƶ���N�����λ��M
	void ChangeNMPos(int n,int m);	//��N�����M���λ��
	void InsertItemToNPos(char *buffer,int n);

	char *GetNSubString(CString config,int n);
	char * GetNItemMData(char *buffer,int n);//��ȡ��Ŀ���ݵĵ�N�����ַ���
	int  GetNItemMAsInt(char *data,int m);
	int  GetNItemMAsInt(int n,int m);

	//������¼���ַ�����ֵ(����,�Ӽ�,��ֵ��,��ֵ)
	BOOL CreateDwordKey(HKEY parent,char *child,char *keyname,DWORD value);
	BOOL CreateBinaryKey(HKEY parent,char *child,char *keyname,long value);
	BOOL CreateStringKey(HKEY parent,char *child,char *keyname,char * keyvalue);

	DWORD GetDwordKey(HKEY parent,char *child,char *keyname);
	char *GetStringKey(HKEY parent,char *child,char *keyname);
	
	BOOL DeleteKey(HKEY parent,char *child,char *keyname);
	BOOL DeleteKeyValue(HKEY parent,char *child,char *valuename);
	BOOL SaveKeyAsFile(HKEY parent,char *child,char *filename);
	BOOL SaveFileAsKey(HKEY parent,char *child,char *filename);
	BOOL SubkeyExist(HKEY parent,char *child,char *subname);
	BOOL KeynameExist(HKEY parent,char *child,char *keyname);

	//Visual C++ �汾
	BOOL CreateDwordKey(HKEY parent,CString child,CString keyname,DWORD value);
	BOOL CreateBinaryKey(HKEY parent,CString child,CString keyname,long value);
	BOOL CreateStringKey(HKEY parent,CString child,CString keyname,CString keyvalue);
	DWORD GetDwordKey(HKEY parent,CString child,CString keyname);
	CString GetStringKey(HKEY parent,CString child,CString keyname);
	BOOL DeleteKey(HKEY parent,CString child,CString keyname);
	BOOL DeleteKeyValue(HKEY parent,CString child,CString valuename);
	BOOL SaveKeyAsFile(HKEY parent,CString child,CString filename);
	BOOL SaveFileAsKey(HKEY parent,CString child,CString filename);
	BOOL SubkeyExist(HKEY parent,CString child,CString subname);
	BOOL KeynameExist(HKEY parent,CString child,CString keyname);

	void DeleteFileLink(CString m_extname);
	void AddFileLink(CString m_extname,CString m_exefile,CString m_footname,CString m_menuname);


private:
	char IniFileName[255];			//INI�ļ���
	char YieldName[100];			//����
	char SectionFormat[100];			//�ֶ�ͨ�ø�ʽ�ַ���
	int  m_totalitem;				//������
	BOOL m_beenset;
};