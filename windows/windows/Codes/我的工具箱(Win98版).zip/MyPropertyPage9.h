#if !defined(AFX_MYPROPERTYPAGE9_H__077AAF41_6E9C_11D2_BDED_0000210022D0__INCLUDED_)
#define AFX_MYPROPERTYPAGE9_H__077AAF41_6E9C_11D2_BDED_0000210022D0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#include "MyCheckListBox.h"
#include "HyperLink.h"



class CMyPropertyPage9 : public CPropertyPage
{
	DECLARE_DYNCREATE(CMyPropertyPage9)

public:
	CMyPropertyPage9();
	~CMyPropertyPage9();

	//{{AFX_DATA(CMyPropertyPage9)
	enum { IDD = IDD_PROPPAGE9 };
	CHyperLink m_email;
	CStatic	m_signalrect;
	//}}AFX_DATA


	//{{AFX_VIRTUAL(CMyPropertyPage9)
	public:
	virtual BOOL OnKillActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL


protected:
	CMyCheckListBox m_check;

	//{{AFX_MSG(CMyPropertyPage9)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_MYPROPERTYPAGE9_H__077AAF41_6E9C_11D2_BDED_0000210022D0__INCLUDED_)
