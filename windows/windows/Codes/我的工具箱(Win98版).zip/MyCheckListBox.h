#if !defined(AFX_MYCHECKLISTBOX_H__76E7584E_7DF8_11D2_BAF0_0000210022D0__INCLUDED_)
#define AFX_MYCHECKLISTBOX_H__76E7584E_7DF8_11D2_BAF0_0000210022D0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000




class CMyCheckListBox:public CCheckListBox
{
	DECLARE_DYNAMIC(CMyCheckListBox)

public:
	CMyCheckListBox();
	virtual ~CMyCheckListBox();
	BOOL Create(const RECT& rect, CWnd* pParentWnd, UINT nID);
	void SetParams(COLORREF m_backc,COLORREF m_forec,COLORREF m_focusc,UINT m_Id,int m_ih);

	
private:
	void DrawListItem(CDC * dc,char *m_buffer,COLORREF m_color,CRect &m_rect);
	void ExchangeItems(int m_start,int m_end);
	BOOL EraseOldLine(CDC &dc,CRect &m_rect,CPoint &point);
	void DrawNewLine(CDC &dc,CRect &m_rect,CPoint &point);


public:
	COLORREF m_backcolor,m_forecolor,m_focuscolor;
	UINT m_CurId;
	int  m_ItemHeight;

	BOOL m_draging;
	int  m_sindex;
	int  m_eindex;
	int  m_oldsel;


public:
	//{{AFX_VIRTUAL(CMyCheckListBox)
	public:
	virtual int CompareItem(LPCOMPAREITEMSTRUCT lpCompareItemStruct);
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CMyCheckListBox)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYCHECKLISTBOX_H__76E7584E_7DF8_11D2_BAF0_0000210022D0__INCLUDED_)
