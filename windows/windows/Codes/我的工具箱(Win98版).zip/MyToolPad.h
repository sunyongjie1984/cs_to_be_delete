#if !defined(AFX_MYTOOLPAD_H__B16825E5_68F3_11D2_BDED_0000210022D0__INCLUDED_)
#define AFX_MYTOOLPAD_H__B16825E5_68F3_11D2_BDED_0000210022D0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols


class CMyToolPadApp : public CWinApp
{
public:
	CMyToolPadApp();

	//{{AFX_VIRTUAL(CMyToolPadApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	ATOM m_atom;
	
	BOOL FileIsEmpty(char * m_filename);
	int  DirHasFiles(char *name);
	int  DirHasSubdir(char *name);
	void DeleteEmptyDir();
	void DeleteDir(char *m_name);
	BOOL HavePrevInstance();

	//{{AFX_MSG(CMyToolPadApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};



//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_MYTOOLPAD_H__B16825E5_68F3_11D2_BDED_0000210022D0__INCLUDED_)
