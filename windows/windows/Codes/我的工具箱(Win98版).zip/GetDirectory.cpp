#include "stdafx.h"
#include "MyToolPad.h"
#include "GetDirectory.h"
#include "io.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString m_directory;


CGetDirectory::CGetDirectory(CWnd* pParent /*=NULL*/)
	: CDialog(CGetDirectory::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGetDirectory)
	m_dirname = _T("");
	//}}AFX_DATA_INIT
}


void CGetDirectory::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGetDirectory)
	DDX_Control(pDX, IDC_DIRTREE, m_tree);
	DDX_Text(pDX, IDC_DIRNAME, m_dirname);
	DDV_MaxChars(pDX, m_dirname, 250);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGetDirectory, CDialog)
	//{{AFX_MSG_MAP(CGetDirectory)
	ON_NOTIFY(NM_DBLCLK, IDC_DIRTREE, OnDblclkDirtree)
	ON_NOTIFY(TVN_ITEMEXPANDING, IDC_DIRTREE, OnItemexpandingDirtree)
	ON_NOTIFY(TVN_SELCHANGED, IDC_DIRTREE, OnSelchangedDirtree)
	ON_NOTIFY(TVN_ITEMEXPANDED, IDC_DIRTREE, OnItemexpandedDirtree)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CGetDirectory::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_dirname=m_directory;
	AllDiskToTree();
	UpdateData(FALSE);
	
	return TRUE;
}

void CGetDirectory::OnOK() 
{
	UpdateData(TRUE);
	m_directory=m_dirname;
	CDialog::OnOK();
}

//��ȡĳ���ڵ��ȫ��
CString CGetDirectory::GetFullName(HTREEITEM root)
{
	CString ret=m_tree.GetItemText(root);
	CString itemname,temp;
	HTREEITEM parent=m_tree.GetParentItem(root);
	while(parent)
	{
		itemname=m_tree.GetItemText(parent);
		parent=m_tree.GetParentItem(parent);
		temp=ret;
		ret=itemname+_T("\\")+temp;
	}
	if(ret.GetLength()<10)
		return ret;
	char *pt=(char *)(strstr(ret,"(")+1);
	itemname.Format("%c:",pt[0]);
	itemname+=_T(&pt[3]);
	return itemname;
}

//�������������������������
void CGetDirectory::AllDiskToTree()
{
	char diskname[80];
	
	CBitmap bitmap;
	imagelist.Create(16,16,TRUE,2,5);
	bitmap.LoadBitmap(IDB_CLOSEFOLD);
	imagelist.Add(&bitmap,(COLORREF)0xFFFFFF);
	bitmap.DeleteObject();
	bitmap.LoadBitmap(IDB_OPENFOLD);
	imagelist.Add(&bitmap,(COLORREF)0xFFFFFF);
	bitmap.DeleteObject();
	m_tree.SetImageList(&imagelist,TVSIL_NORMAL);

	HTREEITEM hRoot,hCur,First=NULL;
	hRoot=CreateTree("�ҵĵ���");
	for(int i=0;i<26;i++)
	{
		wsprintf(diskname,"%c:\\",'A'+i);
		if(GetDriveType(diskname)==DRIVE_FIXED)
		{
			long param=0;
			SetHiword(param,0);
			SetLoword(param,GetChildDirNumber(diskname));
			wsprintf(diskname,"%s (%c:)",GetDiskVolumnName('A'+i),'A'+i);
			hCur=InsertTreeItem(diskname,param,hRoot,0);
			InsertTreeItem("��ʱĿ¼",param,hCur,0);
			if(!First)
				First=hCur;
		}
	}
	m_tree.Expand(m_tree.GetRootItem(),TVE_EXPAND);
	m_tree.SelectItem(First);
}

void CGetDirectory::DirToTree(CString dirname,HTREEITEM root)
{
	DirToTree(dirname.GetBuffer(dirname.GetLength()),root);
}
//��ǰĿ¼������������
void CGetDirectory::DirToTree(char *dirname,HTREEITEM root)
{			
	DWORD data=m_tree.GetItemData(root);
	if(LOWORD(data)==0)//����Ϊ������Ŀ
		return;
	if(HIWORD(data)!=0)//����Ϊ1��ʾ�Ѿ�������Ŀ¼
		return;
	
	DeleteAllChild(root);
	SetItemHighParam(root,1);

	char Searchname[200],buffer[250];
	int  ret=0;
	wsprintf(Searchname,"%s\\%s",dirname,"*.*");
	struct _finddata_t fileinfo;
	long handle=_findfirst(Searchname,&fileinfo);
	while((handle>0) && (ret==0))
	{			
		if(fileinfo.attrib & _A_SUBDIR)
		{
			if((strcmpi(fileinfo.name,".")!=0) && (strcmpi(fileinfo.name,"..")!=0) && (strcmpi(fileinfo.name,"RECYCLED")!=0))
			{
				wsprintf(buffer,"%s\\%s",dirname,fileinfo.name);
				long attr=0;
				int number=GetChildDirNumber(buffer);
				SetHiword(attr,0);
				SetLoword(attr,number);
				HTREEITEM hCur=InsertTreeItem(fileinfo.name,attr,root,0);
				if(number>0)
				{
					InsertTreeItem("��ʱĿ¼",attr,hCur,0);
					SetItemHighParam(hCur,0);
				}
			}
		}
		ret=_findnext(handle,&fileinfo);
	}
}

void CGetDirectory::SetItemHighParam(HTREEITEM cur,WORD high)
{
	DWORD ret=m_tree.GetItemData(cur);
	DWORD temp=(DWORD)high;
	temp<<=16;
	ret&=0x0000ffff;
	ret|=temp;
	m_tree.SetItemData(cur,ret);
}


/*********************/
//���ش��̾�������
char *CGetDirectory::GetDiskVolumnName(char disk)
{
	char  RootPathName[100]="g:\\";
	RootPathName[0]=disk;
	char  VolumeNameBuffer[200];
	DWORD nVolumeNameSize=200;
	DWORD VolumeSerialNumber;
	DWORD MaximumComponentLength;
	DWORD FileSystemFlags=FS_FILE_COMPRESSION|FS_VOL_IS_COMPRESSED;
	char  FileSystemNameBuffer[200];
	DWORD nFileSystemNameSize=200;

	GetVolumeInformation(RootPathName,VolumeNameBuffer,
		    nVolumeNameSize,&VolumeSerialNumber,
		    &MaximumComponentLength,&FileSystemFlags,
		    FileSystemNameBuffer,nFileSystemNameSize);
	return &VolumeNameBuffer[0];
}

//��ǰĿ¼�Ƿ�����Ŀ¼
BOOL CGetDirectory::DirHaveChildDir(char * dirname)
{
	return (GetChildDirNumber(dirname)==0);
}

//ĳ��Ŀ¼����Ŀ¼����Ŀ
int  CGetDirectory::GetChildDirNumber(char * dirname)
{
	int  number=0;
	char Searchname[200];
	struct _finddata_t fileinfo;
	int  len=strlen(dirname);
	if(dirname[len-1]=='\\')
		wsprintf(Searchname,"%s%s",dirname,"*.*");
	else
		wsprintf(Searchname,"%s\\%s",dirname,"*.*");

	long handle=_findfirst(Searchname,&fileinfo);
	int  ret=0;
	while((handle>0) && (ret==0))
	{			
		if(fileinfo.attrib & _A_SUBDIR)
		{
			if((strcmpi(fileinfo.name,".")!=0) && (strcmpi(fileinfo.name,"..")!=0))
				number++;
		}
		ret=_findnext(handle,&fileinfo);
	}
	return number;
}

//������
HTREEITEM CGetDirectory::CreateTree(char * text)
{
	TV_INSERTSTRUCT tci;
	tci.item.mask=TVIF_TEXT|TVIF_PARAM;
	tci.item.stateMask=0;
	tci.item.pszText=text;
	tci.item.iImage=I_IMAGECALLBACK;
	tci.item.iSelectedImage=I_IMAGECALLBACK;
	tci.item.cchTextMax=lstrlen(tci.item.pszText);
	tci.item.lParam=0;
	tci.hParent=NULL;
	tci.hInsertAfter=TVI_LAST;
	return(m_tree.InsertItem(&tci));
}

//����һ�����
HTREEITEM CGetDirectory::InsertTreeItem(char * text,long index,HTREEITEM parent,int image)
{
	TV_INSERTSTRUCT tci;
	tci.item.mask=TVIF_TEXT|TVIF_PARAM;
	tci.item.stateMask=0;
	tci.item.pszText=text;
	tci.item.iImage=0;
	tci.item.iSelectedImage=image;
	tci.item.cchTextMax=lstrlen(tci.item.pszText);
	tci.item.lParam=index;
	tci.hParent=parent;
	tci.hInsertAfter=TVI_LAST;
	return(m_tree.InsertItem(&tci));
}

//ɾ������ĳ�����е������������������
void CGetDirectory::DeleteAllChild(HTREEITEM parent)
{
	if(m_tree.ItemHasChildren(parent))
	{
		HTREEITEM first=m_tree.GetChildItem(parent);
		while(first)
		{
			m_tree.DeleteItem(first);
			first=m_tree.GetChildItem(parent);
		}
	}
}

//����LONG�ͱ������ֲ���
void CGetDirectory::SetHiword(long &want,int value)
{
	long temp=(long)value;
	temp<<=16;
	want|=temp;
}

//����LONG�ͱ������ֲ���
void CGetDirectory::SetLoword(long &want,int value)
{
	long temp=(long)value;
	want|=temp;
}



void CGetDirectory::OnItemexpandingDirtree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	HTREEITEM root=pNMTreeView->itemNew.hItem;
	if(root!=m_tree.GetRootItem())
		DirToTree(GetFullName(root),root);
	*pResult = 0;
}

void CGetDirectory::OnSelchangedDirtree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

	HTREEITEM m_new=pNMTreeView->itemNew.hItem;
	HTREEITEM m_old=pNMTreeView->itemOld.hItem;
	if(m_old!=0)
	{
		UINT m_state=m_tree.GetItemState(m_old,TVIF_STATE);
		m_state&=TVIS_EXPANDED;
		m_tree.SetItemImage(m_old,(m_state==0)?0:1,0);  
	}
	m_tree.SetItemImage(m_new,1,1);  

	UpdateData(TRUE);
	HTREEITEM root=m_tree.GetSelectedItem();
	if(root!=m_tree.GetRootItem())
	{
		CString content=m_dirname;
		char *tail=content.GetBuffer(content.GetLength());
		char * name=strrchr(tail,'\\');
		m_dirname=GetFullName(root);
		UpdateData(FALSE);
	}
	
	*pResult = 0;
}

//˫��ĳ��
void CGetDirectory::OnDblclkDirtree(NMHDR* pNMHDR, LRESULT* pResult) 
{				    
	HTREEITEM root=m_tree.GetSelectedItem();
	if(root!=m_tree.GetRootItem())
		DirToTree(GetFullName(root),root);
	*pResult = 0;
}


void CGetDirectory::OnItemexpandedDirtree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	HTREEITEM root=pNMTreeView->itemNew.hItem;
	m_tree.SetItemImage(root,1,1);  
	*pResult = 0;
}
