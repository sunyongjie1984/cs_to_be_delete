class CGetDirectory : public CDialog
{
public:
	CGetDirectory(CWnd* pParent = NULL);

	//{{AFX_DATA(CGetDirectory)
	enum { IDD = IDD_GETDIRECTORY };
	CTreeCtrl	m_tree;
	CString	m_dirname;
	//}}AFX_DATA


	//{{AFX_VIRTUAL(CGetDirectory)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	CImageList imagelist;

	CString GetFullName(HTREEITEM root);
	void AllDiskToTree();
	void DirToTree(CString dirname,HTREEITEM root);
	void DirToTree(char *dirname,HTREEITEM root);
	void SetItemHighParam(HTREEITEM cur,WORD high);

	char *GetDiskVolumnName(char disk);
	BOOL DirHaveChildDir(char * dirname);

	HTREEITEM CreateTree(char * text);
	HTREEITEM InsertTreeItem(char * text,long index,HTREEITEM parent,int image);
	int  GetChildDirNumber(char * dirname);
	void DeleteAllChild(HTREEITEM parent);

	void SetHiword(long &want,int value);
	void SetLoword(long &want,int value);

	//{{AFX_MSG(CGetDirectory)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnDblclkDirtree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemexpandingDirtree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangedDirtree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemexpandedDirtree(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
