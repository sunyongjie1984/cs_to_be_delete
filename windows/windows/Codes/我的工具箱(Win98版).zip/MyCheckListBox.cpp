#include "stdafx.h"
#include "mytoolpad.h"
#include "MyCheckListBox.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNAMIC(CMyCheckListBox,CCheckListBox)

CMyCheckListBox::CMyCheckListBox()
{
	m_backcolor=RGB(0,128,128);
	m_forecolor=RGB(255,255,255);
	m_focuscolor=RGB(0,255,0);
	m_CurId=0;
	m_ItemHeight=20;

	m_draging=FALSE;
	m_sindex=-1;
	m_eindex=-1;
	m_oldsel=-1;
}

CMyCheckListBox::~CMyCheckListBox()
{
}


BEGIN_MESSAGE_MAP(CMyCheckListBox, CCheckListBox)
	//{{AFX_MSG_MAP(CMyCheckListBox)
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CMyCheckListBox::Create(const RECT& rect, CWnd* pParentWnd, UINT nID)
{
	DWORD m_style=LBS_OWNERDRAWVARIABLE|LBS_HASSTRINGS|WS_CHILD|WS_HSCROLL|WS_VSCROLL|WS_TABSTOP|WS_VISIBLE|WS_BORDER;
	return CCheckListBox::Create(m_style,rect,pParentWnd,nID);
}

int  CMyCheckListBox::CompareItem(LPCOMPAREITEMSTRUCT lpCompareItemStruct)
{
	char m_buffer1[200],m_buffer2[200];
	GetText(lpCompareItemStruct->itemID1,m_buffer1);
	GetText(lpCompareItemStruct->itemID2,m_buffer2);
	int  m_result=strcmp(m_buffer1,m_buffer2);
	int  m_ret=0;
	if(m_result==0)
		m_ret=0;
	else
	{
		if(m_ret>0)
			m_ret=1;
		else
			m_ret=-1;
	}
	
	return m_ret;
}

void CMyCheckListBox::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CCheckListBox::OnLButtonDown(nFlags, point);

	SetCapture();
	m_draging=TRUE;
	int m_isout=FALSE;
	m_sindex=ItemFromPoint(point,m_isout);

	if(m_CurId!=0)
	{
		HCURSOR m_cru=AfxGetApp()->LoadCursor(m_CurId);
		SetCursor(m_cru);
	}
}
void CMyCheckListBox::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if(m_draging)
	{
		ReleaseCapture();
		m_draging=FALSE;
		int m_isout=FALSE;
		m_eindex=ItemFromPoint(point,m_isout);

		CRect m_rect;
		GetClientRect(&m_rect);
		CPen m_pen(PS_SOLID,2,RGB(255,0,0));
		CClientDC dc(this);
		CPen * m_oldpen=dc.SelectObject(&m_pen);
		dc.SetROP2(R2_XORPEN);
		dc.MoveTo(m_rect.left,m_oldsel*m_ItemHeight);
		dc.LineTo(m_rect.right,m_oldsel*m_ItemHeight);
		if(m_oldpen)
			dc.SelectObject(&m_oldpen);
		m_oldsel=-1;

		ExchangeItems(m_sindex,m_eindex);
	}

	CCheckListBox::OnLButtonUp(nFlags, point);
}

void CMyCheckListBox::ExchangeItems(int m_start,int m_end)
{
	if(m_start==m_end)
		return;

	char m_buffer[200];
	GetText(m_start,m_buffer);
	DWORD m_data=GetItemData(m_start);
	int  m_state=GetCheck(m_start);
	DeleteString(m_start);
	InsertString(m_end,m_buffer);
	SetItemData(m_end,m_data);
	SetCheck(m_end,m_state);
	SetCurSel(m_end);
}

void CMyCheckListBox::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	int m_isout=FALSE;
	int m_index=ItemFromPoint(point,m_isout);
	SetCurSel(m_index);

	m_index=GetCurSel();
	if(m_index>=0)
	{
		int  m_check=GetCheck(m_index);
		if(m_check==0)
			m_check=1;
		else
			m_check=0;
		SetCheck(m_index,m_check);
	}
}

void CMyCheckListBox::OnRButtonDown(UINT nFlags, CPoint point) 
{
	int m_isout=FALSE;
	int m_index=ItemFromPoint(point,m_isout);
	SetCurSel(m_index);

	m_index=GetCurSel();
	if(m_index>=0)
	{
		int  m_check=GetCheck(m_index);
		if(m_check==0)
			m_check=1;
		else
			m_check=0;
		SetCheck(m_index,m_check);
	}

	CCheckListBox::OnRButtonDown(nFlags, point);
}

void CMyCheckListBox::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
	lpMeasureItemStruct->itemHeight=m_ItemHeight;
}

void CMyCheckListBox::DrawListItem(CDC * dc,char *m_buffer,COLORREF m_color,CRect &m_rect)
{
	CSize m_size=dc->GetTextExtent(m_buffer,strlen(m_buffer));
	int  m_height=m_rect.Height();
	int  m_x=m_rect.left;
	int  m_y=m_rect.top;
	if(m_height>m_size.cy)
		m_y+=(m_height-m_size.cy)/2;

	dc->SetTextColor(m_color);
	dc->TextOut(m_x,m_y,m_buffer,strlen(m_buffer));
}

void CMyCheckListBox::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CDC* pDC=CDC::FromHandle(lpDrawItemStruct->hDC);
	pDC->SetBkMode(TRANSPARENT);

	int  m_index=GetCurSel();
	char m_buffer[200];
	GetText(m_index,m_buffer);
	CRect m_rect(lpDrawItemStruct->rcItem);

	if (lpDrawItemStruct->itemAction & ODA_DRAWENTIRE)
	{
		pDC->FillRect(&lpDrawItemStruct->rcItem,&CBrush(m_backcolor));
		GetText(lpDrawItemStruct->itemID,m_buffer);
		DrawListItem(pDC,m_buffer,m_forecolor,m_rect);
	}

	if ((lpDrawItemStruct->itemState & ODS_SELECTED) && (lpDrawItemStruct->itemAction & (ODA_SELECT | ODA_DRAWENTIRE)))
	{
		pDC->FillRect(&lpDrawItemStruct->rcItem,&CBrush(RGB(0,128,128)));
		DrawListItem(pDC,m_buffer,m_focuscolor,m_rect);
	}

	if (!(lpDrawItemStruct->itemState & ODS_SELECTED) && (lpDrawItemStruct->itemAction & ODA_SELECT))
	{
		pDC->FillRect(&lpDrawItemStruct->rcItem,&CBrush(RGB(0,128,128)));
		DrawListItem(pDC,m_buffer,m_forecolor,m_rect);
	}
}

BOOL CMyCheckListBox::OnEraseBkgnd(CDC* pDC) 
{	
	CRect m_rect;
	GetClientRect(&m_rect);
	pDC->FillRect(&m_rect,&CBrush(m_backcolor));
	return TRUE;
}

BOOL CMyCheckListBox::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.dwExStyle|=WS_EX_STATICEDGE;
	return CCheckListBox::PreCreateWindow(cs);
}

void CMyCheckListBox::SetParams(COLORREF m_backc,COLORREF m_forec,COLORREF m_focusc,UINT m_Id,int m_ih)
{
	m_backcolor=m_backc;
	m_forecolor=m_forec;
	m_focuscolor=m_focusc;
	m_CurId=m_Id;
	if(m_ih<20)
		m_ih=20;
	m_ItemHeight=m_ih;
}

void CMyCheckListBox::OnMouseMove(UINT nFlags,CPoint point)
{
	if(m_draging)
	{
		CRect m_rect;
		GetClientRect(&m_rect);
		CClientDC dc(this);
		DrawNewLine(dc,m_rect,point);
	}

	CCheckListBox::OnMouseMove(nFlags, point);
}

BOOL CMyCheckListBox::EraseOldLine(CDC &dc,CRect &m_rect,CPoint &point)
{
	int  m_isout=FALSE;
	int	m_newsel=ItemFromPoint(point,m_isout);
	if(m_oldsel==m_newsel)
		return FALSE;

	CPen m_pen(PS_SOLID,2,RGB(255,0,0));
	CPen * m_oldpen=dc.SelectObject(&m_pen);
	dc.SetROP2(R2_XORPEN);

	if(m_oldsel!=-1)
	{
		dc.MoveTo(m_rect.left,m_oldsel*m_ItemHeight);
		dc.LineTo(m_rect.right,m_oldsel*m_ItemHeight);
	}

	if(m_oldpen)
		dc.SelectObject(&m_oldpen);
	return TRUE;
}

void CMyCheckListBox::DrawNewLine(CDC &dc,CRect &m_rect,CPoint &point)
{
	if(EraseOldLine(dc,m_rect,point))
	{
		int  m_isout=FALSE;
		m_oldsel=ItemFromPoint(point,m_isout);
		CPen m_pen(PS_SOLID,2,RGB(255,0,0));
		CPen * m_oldpen=dc.SelectObject(&m_pen);
		dc.SetROP2(R2_XORPEN);
		dc.MoveTo(m_rect.left,m_oldsel*m_ItemHeight);
		dc.LineTo(m_rect.right,m_oldsel*m_ItemHeight);
		if(m_oldpen)
			dc.SelectObject(&m_oldpen);
	}
}
