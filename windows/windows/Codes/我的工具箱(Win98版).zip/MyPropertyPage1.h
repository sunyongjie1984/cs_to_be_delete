#ifndef __MYPROPERTYPAGE1_H__
#define __MYPROPERTYPAGE1_H__

#include "CalendarConvert.h"
#include "EllipseButton.h"



class CMyPropertyPage1 : public CPropertyPage
{
	DECLARE_DYNCREATE(CMyPropertyPage1)

public:
	CMyPropertyPage1();
	~CMyPropertyPage1();

	//{{AFX_DATA(CMyPropertyPage1)
	enum { IDD = IDD_PROPPAGE1 };
	CRoundButton m_delctrl;
	CRoundButton m_ctrl2;
	CRoundButton m_ctrl1;
	CEdit	m_shortnamectrl;
	CTreeCtrl	m_shortctrl;
	CButton m_centerctrl;
	CButton m_tilectrl;
	CButton m_onstatusctrl;
	CButton m_onstartctrl;
	CButton m_ondeskctrl;
	CRoundButton m_createshort;
	CRoundButton m_setpaper;
	CString	m_wallpaper;
	CString	m_exefile;
	CString	m_error;
	BOOL	m_ondesk;
	BOOL	m_onstart;
	BOOL	m_onstatus;
	CString	m_shortname;
	//}}AFX_DATA


	//{{AFX_VIRTUAL(CMyPropertyPage1)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	int  m_wallmode;
	CToolTipCtrl m_tooltip;

	void InitPanel();
	void EnablePanel();
	void SetWallpaper(CString m_file,int m_mode);
	void DelWallpaper();
	void CreateShortcut(CString m_file,CString m_name);
	CString GetShortcutPath(HTREEITEM hitem);
	BOOL FileExist(CString m_file);
	BOOL IsDirExist(char *buffer);

	BOOL CreateShellObjectLink(char * sObjectPath,char *sDescription,char *sLinkPath);
	HTREEITEM CreateTree(CTreeCtrl &tree,char * text);
	HTREEITEM InsertTreeItem(CTreeCtrl &tree,char * text,int index,HTREEITEM parent,int image);
	void DirToTree(CTreeCtrl &tree,char *dirname,HTREEITEM root,int iden);
	void DeleteChild(HTREEITEM hitem);
	void DeleteAllChild(CTreeCtrl &tree,HTREEITEM hitem);
	void ShortcutToTree();


protected:
	//{{AFX_MSG(CMyPropertyPage1)
	virtual BOOL OnInitDialog();
	afx_msg void OnBrowsewallpaper();
	afx_msg void OnBrowseexecute();
	afx_msg void OnChangeWallpaper();
	afx_msg void OnSetwallpaper();
	afx_msg void OnDelwallpaper();
	afx_msg void OnCreateshortcut();
	afx_msg void OnDeleteshortcut();
	afx_msg void OnRefresh();
	afx_msg void OnChangeExecutefile();
	afx_msg void OnCenter();
	afx_msg void OnTile();
	afx_msg void OnChangeShortname();
	afx_msg void OnOndesk();
	afx_msg void OnOnstartmenu();
	afx_msg void OnOnstatusbar();
	afx_msg void OnRclickShortcuttree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnKeydownShortcuttree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEndlabeleditShortcuttree(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};



typedef struct DataHead
{	
	DataHead()
	{
		memset(m_flag,0,10);
		m_totalitems=0;
		memset(m_password,0,40);
		strcpy(m_password,"cyh");
	}

	char m_flag[10];
	int  m_totalitems;
	char m_password[40];

	BOOL FromFile(CFile& m_file)
	{
		m_file.Seek(0,CFile::begin);
		m_file.Read(m_flag,10);
		if(strcmp(m_flag,"������")!=0)
			return FALSE;
		m_file.Read((char *)&m_totalitems,sizeof(int));
		m_file.Read(m_password,40);
		for(int i=39;i>0;i--)
			m_password[i-1]^=m_password[i];
		return TRUE;
	}
	void ToFile(CFile& m_file)
	{
		m_file.Seek(0,CFile::begin);
		strcpy(m_flag,"������");
		m_file.Write(m_flag,10);
		m_file.Write((char *)&m_totalitems,sizeof(int));
		char m_buffer[100];
		memset(m_buffer,0,41);
		strcpy(m_buffer,m_password);
		for(int i=0;i<39;i++)
			m_buffer[i]^=m_buffer[i+1];
		m_file.Write(m_buffer,40);
		m_file.Write(m_buffer,50-sizeof(int));
	}
}DATAFILEHEAD;



class CMyPropertyPage2 : public CPropertyPage
{
	DECLARE_DYNCREATE(CMyPropertyPage2)

public:
	CMyPropertyPage2();
	~CMyPropertyPage2();

	//{{AFX_DATA(CMyPropertyPage2)
	enum { IDD = IDD_PROPPAGE2 };
	CRoundButton m_ctrl2;
	CRoundButton m_ctrl1;
	CEdit	m_titlectrl;
	CEdit	m_searchtitlectrl;
	CSpinButtonCtrl	m_sindexspin;
	CEdit	m_sindexctrl;
	CRoundButton m_searchctrl;
	CRoundButton m_next;
	CRoundButton m_last;
	CEdit	m_indexctrl;
	CRoundButton m_deletectrl;
	CEdit	m_contentctrl;
	CRoundButton m_changepass;
	CSpinButtonCtrl	m_indexspin;
	CString	m_content;
	CString	m_filename;
	int		m_index;
	CString	m_password;
	int		m_sindex;
	CString	m_searchtitle;
	CString	m_error;
	CString	m_title;
	//}}AFX_DATA


	//{{AFX_VIRTUAL(CMyPropertyPage2)
	public:
	virtual void OnOK();
	virtual BOOL OnQueryCancel();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	CFile *m_DataFile;
	DATAFILEHEAD m_filehead;
	BOOL m_changed,m_passright,m_haveinit;
	int  m_pitchitems;
	CToolTipCtrl m_tooltip;

	void InitPanel();							  //��ʼ�����
	void EnablePanel();							  //����/��ֹ���
	void SaveCurData(int m_curindex);							  //���浱ǰ����
	void GetCurData();							  //��ȡ��N������
	void ReadFromFile(CString m_file);				  //�������ļ����һ�ȡͷ��Ϣ
	void CreateDataFile(CString m_name);			  //���������ļ�
	BOOL FileExist(CString m_findfile);			  //�ļ��Ƿ����
	void CloseCurFile();
	CString GetNContent(int index);
	CString GetNTitle(int index);
	void DeleteNItem(int index);
	void SetSearchItem(int index);
	void NItemChangePass(int index,char *oldpass,char *newpass);



protected:
	//{{AFX_MSG(CMyPropertyPage2)
	afx_msg void OnBrowse();
	afx_msg void OnSearch();
	afx_msg void OnAdditem();
	afx_msg void OnDeleteitem();
	afx_msg void OnLast();
	afx_msg void OnNext();
	afx_msg void OnChangeIndex();
	afx_msg void OnChangeSearchtitle();
	afx_msg void OnChangeTitle();
	afx_msg void OnChangeContent();
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeFilename();
	afx_msg void OnChangePassword();
	afx_msg void OnChangeSearchindex();
	afx_msg void OnChangepass();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};



class CEverydayTask:public CObject
{
public:
	CEverydayTask();

	CString m_aliasname;
	CString m_content;
	int  m_year,m_month,m_day;
	int  m_days;
	int  m_hour,m_minute;
	BOOL m_over;

public:
	void FromFile(CFile& m_file);		    //���ļ���ȡ
	void ToFile(CFile& m_file);		    //д�뵽�ļ�
	BOOL IsOverDate();				    //�Ƿ��Ѿ�����
	BOOL ReachTime();				    //�Ƿ��Ѿ����˱���ʱ��
	BOOL AtLimited();				    //�Ƿ���Ԥ������
	BOOL KeepInQuene();				    //�Ƿ���������ڶ�����
};				

class CMyPropertyPage3 : public CPropertyPage
{
	DECLARE_DYNCREATE(CMyPropertyPage3)

public:
	CMyPropertyPage3();
	~CMyPropertyPage3();

	//{{AFX_DATA(CMyPropertyPage3)
	enum { IDD = IDD_PROPPAGE3 };
	CRoundButton m_ctrl1;
	CEdit	m_minutectrl;
	CEdit	m_hourctrl;
	CButton m_overctrl;
	CEdit	m_daysctrl;
	CEdit	m_dayctrl;
	CEdit	m_monthctrl;
	CEdit	m_yearctrl;
	CEdit	m_contentctrl;
	CEdit	m_aliasctrl;
	CRoundButton m_delctrl;
	CListBox	m_tasklist;
	CString	m_aliasname;
	CString	m_content;
	BOOL	m_over;
	int		m_day;
	int		m_month;
	int		m_year;
	int		m_days;
	int		m_hour;
	int		m_minute;
	//}}AFX_DATA


	//{{AFX_VIRTUAL(CMyPropertyPage3)
	public:
	virtual BOOL OnKillActive();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	CObList * m_tasks;
	int  m_curindex;
	CToolTipCtrl m_tooltip;

	void InitPanel();
	void EnablePanel();
	void ItemToPanel(int m_index);
	void PanelToItem(int m_index);

protected:
	//{{AFX_MSG(CMyPropertyPage3)
	virtual BOOL OnInitDialog();
	afx_msg void OnAddnotice();
	afx_msg void OnDeletenotice();
	afx_msg void OnSelchangeTasklist();
	afx_msg void OnChangeAliasname();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};




class CMyPropertyPage4 : public CPropertyPage
{
	DECLARE_DYNCREATE(CMyPropertyPage4)

public:
	CMyPropertyPage4();
	~CMyPropertyPage4();

	//{{AFX_DATA(CMyPropertyPage4)
	enum { IDD = IDD_PROPPAGE4 };
	CStatic	m_nongrect;
	CStatic	m_gongrect;
	CComboBox	m_nongmonth;
	CComboBox	m_gongmonth;
	CString	m_time;
	CString	m_ganzhi;
	int		m_gongyear;
	int		m_nongyear;
	//}}AFX_DATA


	//{{AFX_VIRTUAL(CMyPropertyPage4)
	public:
	virtual BOOL OnKillActive();
	virtual BOOL OnSetActive();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	CRect m_rectgong;
	CRect m_rectnong;
	CDC * m_memdc;
	CBitmap *m_oldbit;
	CPen * m_oldpen;
	int   m_itemw,m_itemh;
	int   m_gongday,m_nongday;
	CCalendarConvert m_cal;
	CALENDAR m_nong,m_gong;
	int   m_nongweekstart,m_gongweekstart; 
	CToolTipCtrl m_tooltip;



protected:
	void GetAllInformation();
	void CreateMemdc();
	void ReleaseMemdc();
	void ShowTime();
	
	void ShowPanel(CDC & dc);
	void ShowGongDay(CDC & dc);
	void ShowNongDay(CDC & dc);

	void DrawPanel();
	void DrawGongDay();
	void DrawNongDay();

	void NongMonthToList();
	void GongYearChanged();
	void GongMonthChanged();
	void GongDayChanged();
	void UpdateGongli();

	void NongYearChanged();
	void NongMonthChanged();
	void NongDayChanged();
	void UpdateNongli();
	void GongToNong();
	void NongToGong();
	BOOL IsValidateNongDay(int m_day);
	BOOL IsValidateGongDay(int m_day);


protected:
	//{{AFX_MSG(CMyPropertyPage4)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnPaint();
	afx_msg void OnChangeGongyear();
	afx_msg void OnChangeNongyear();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnSelchangeGongmonth();
	afx_msg void OnSelchangeNongmonth();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};





#endif // __MYPROPERTYPAGE1_H__
