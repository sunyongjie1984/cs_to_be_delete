#if !defined(AFX_MYPROPERTYPAGE8_H__3D303EE1_6E40_11D2_BDED_0000210022D0__INCLUDED_)
#define AFX_MYPROPERTYPAGE8_H__3D303EE1_6E40_11D2_BDED_0000210022D0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "EllipseButton.h"


class CMyPropertyPage8 : public CPropertyPage
{
	DECLARE_DYNCREATE(CMyPropertyPage8)

public:
	CMyPropertyPage8();
	~CMyPropertyPage8();

	//{{AFX_DATA(CMyPropertyPage8)
	enum { IDD = IDD_PROPPAGE8 };
	CRoundButton	m_ctrl2;
	CRoundButton	m_ctrl1;
	CListCtrl	m_linklist;
	CRoundButton	m_browse;
	CRoundButton	m_link;
	CSliderCtrl	m_pathcache;
	CSliderCtrl	m_namecache;
	CRoundButton	m_effect;
	int		m_maxmtu;
	int		m_ttl;
	int		m_receive;
	int		m_querytime;
	int		m_files;
	int		m_folders;
	BOOL		m_clear;
	CString	m_extname;
	CString	m_linkfile;
	CString	m_foot;
	CString	m_menu;
	//}}AFX_DATA


	//{{AFX_VIRTUAL(CMyPropertyPage8)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	CImageList cil1;
	CImageList cil2;

	void InsertNItem(int n,char *extname,char *exename);
	void SetNMItem(int n,int m,char *value);
	void DeleteLink(CString m_ext);
	void AddLink(CString m_ext,CString m_exe,CString m_foot,CString m_menu);

	
	BOOL m_changed;
	int  m_platmode;
	CString m_MTUpath,m_Otherpath,m_FilePath;
	CToolTipCtrl m_tooltip;

	void InitPanel();
	void EnablePanel();
	void ResetToDefault();
	void SetToRegistry();
	void GetDevicePath();
	void MakeAllKeyExist();
	void	GetFileSystem();
	void ShowMessage();
	void ToSystemIni();
	BOOL FileExist(CString m_file);
	void AllLinkToList();
	CString FindExecuteFile(char *m_name);


protected:
	//{{AFX_MSG(CMyPropertyPage8)
	afx_msg void OnRefresh();
	afx_msg void OnDeleteLink();
	afx_msg void OnDefault();
	afx_msg void OnEffect();
	afx_msg void OnDesktop();
	afx_msg void OnMobile();
	afx_msg void OnServer();
	afx_msg void OnChangeMaxmtu();
	afx_msg void OnChangeQuerytime();
	afx_msg void OnChangeReceivewindow();
	afx_msg void OnChangeTtl();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	virtual BOOL OnInitDialog();
	afx_msg void OnRight();
	afx_msg void OnChangeFilenumber();
	afx_msg void OnChangeFolders();
	afx_msg void OnBrowse();
	afx_msg void OnChangeExtname();
	afx_msg void OnRclickFilelinklist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnKeydownFilelinklist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnColumnclickFilelinklist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChangeLinktofile();
	afx_msg void OnChangeFootname();
	afx_msg void OnChangeMenuname();
	afx_msg void OnLink();
	afx_msg void OnClearemptydir();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_MYPROPERTYPAGE8_H__3D303EE1_6E40_11D2_BDED_0000210022D0__INCLUDED_)
