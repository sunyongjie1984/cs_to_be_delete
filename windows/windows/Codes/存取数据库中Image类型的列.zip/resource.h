//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ISAM.rc
//
#define IDS_SERVER                      102
#define IDR_DATA                        105
#define IDR_LIST                        106
#define IDR_LISTITEM                    107

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         103
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
