//////////////////////////////////////////////////////////////////////////
//
// ClipSpy, Copyright 1999 by Michael Dunn <mdunn at inreach dot com>
//
// This is a utility to view the raw contents of the clipboard, or the 
// data in a drag-and-drop operation.  There are still some quirks and
// bugs.  Comments/suggestions are always welcome!
//
// Revision history:
//  Dec 20, 1999: Version 1.0, first release.
//
// You can get the latest updates for ClipSpy at:
//  http://home.inreach.com/mdunn/code/
//
//////////////////////////////////////////////////////////////////////////

// stdafx.cpp : source file that includes just the standard includes
//	ClipSpy.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



