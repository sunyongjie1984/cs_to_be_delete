// digitalcounterDlg.h : header file
//

#if !defined(AFX_DIGITALCOUNTERDLG_H__3CCE2746_C65C_11D2_BA4A_00104B6C2FFE__INCLUDED_)
#define AFX_DIGITALCOUNTERDLG_H__3CCE2746_C65C_11D2_BA4A_00104B6C2FFE__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include "cdxCSizingDialog.h"
#include "DigiDisplay.h"
/////////////////////////////////////////////////////////////////////////////
// CDigitalcounterDlg dialog

class CDigitalcounterDlg : public cdxCSizingDialog
{
// Construction
public:
	CDigitalcounterDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDigitalcounterDlg)
	enum { IDD = IDD_DIGITALCOUNTER_DIALOG };
	CDigiDisplay	m_QuoteText;
	CDigiDisplay	m_Count4;
	CDigiDisplay	m_Count3;
	CDigiDisplay	m_Count2;
	CDigiDisplay	m_Count1;
	CDigiClock	m_TimeStatic;
	double	m_dVal;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDigitalcounterDlg)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	double	m_dNew;
	CString m_csQuote;

	// Generated message map functions
	//{{AFX_MSG(CDigitalcounterDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIGITALCOUNTERDLG_H__3CCE2746_C65C_11D2_BA4A_00104B6C2FFE__INCLUDED_)
