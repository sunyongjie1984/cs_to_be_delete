//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by digitalcounter.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DIGITALCOUNTER_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDB_COOLDIGITDOT                130
#define IDB_Digit0                      136
#define IDB_Digit3                      140
#define IDB_Digit4                      141
#define IDB_Digit5                      142
#define IDB_Digit6                      143
#define IDB_Digit7                      144
#define IDB_Digit8                      145
#define IDB_Digit9                      146
#define IDB_DigitBlank                  147
#define IDB_Digit2                      157
#define IDB_Digit1                      158
#define IDB_COOLDIGIT                   160
#define IDB_DigitDot                    165
#define IDB_DigitMinus                  166
#define IDB_DigitY                      167
#define IDB_DigitX                      168
#define IDB_DigitZ                      169
#define IDB_DigitColon                  170
#define IDB_COOLDIGITCOLON              171
#define IDC_TIME_STATIC                 1000
#define IDC_BUTTON1                     1001
#define IDC_EDIT1                       1002
#define IDC_COUNT1                      1003
#define IDC_COUNT2                      1004
#define IDC_COUNT3                      1005
#define IDC_COUNT4                      1006
#define IDC_QUOTE_STATIC                1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
