// CDigiDisplay.cpp : implementation file
//
// Copyright (C) 1999 by Michel Wassink
// All rights reserved
//
// This is free software.
// You may redistribute it by any means providing it is not sold for profit
// without the author written consent.
//
// No warrantee of any kind, expressed or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Basic idea from J�rg K�nig of the completely free tetris clone "CGTetris".
// Clock stuff from by Xie Jingwei. 
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc., and
// I'll try to keep a version up to date.  I can be reached as follows:
//    mww@mitutoyo.nl                 (company site)
//    mwassink@csi.com				  (private site)
// An email letting me know that you are using it would be nice.
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <math.h>
#include "resource.h"
#include "DigiDisplay.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Segment numbering:
// -----          13 
//|\ | /|      8  0  12  
//| \|/ |        1 2 
// -----   ==    6 7    
//| /|\ |        3 4    
//|/ | \|      9  5  11 
// -----          10    

#define NSEGCOLORS	14
#define BACKGROUND	RGB(000, 000, 000)	// BLACK

COLORREF SEGM_COLORS[NSEGCOLORS] = {
RGB(128, 128, 128),	// DARKGRAY
RGB(128, 000, 128),	// DARKMAGENTA
RGB(000, 255, 255),	// LIGHTCYAN
RGB(000, 000, 128),	// DARKBLUE
RGB(000, 000, 255),	// LIGHTBLUE
RGB(192, 192, 192),	// LIGHTGRAY
RGB(255, 000, 000),	// LIGHTRED
RGB(255, 255, 000),	// YELLOW
RGB(128, 000, 000),	// DARKRED
RGB(000, 128, 000),	// DARKGREEN
RGB(255, 000, 255),	// LIGHTMAGENTA
RGB(000, 128, 128),	// DARKCYAN
RGB(255, 255, 255),	// WHITE
RGB(128, 128, 000)	// BROWN
};

//									   SP		0		1		2		3		4		5		6	
WORD CHAR_SEGMENTS[MAXSEGCHARS] = {0x0000, 0x3F00, 0x1800, 0x36C0, 0x3CC0, 0x19C0, 0x2DC0, 0x2FC0, 
//		7		8		9		A		B		C		D		E		F		G		H
   0x3800, 0x3FC0, 0x3DC0, 0x3BC0, 0x3CA1, 0x2700, 0x3C21, 0x27C0, 0x23C0, 0x2F80, 0x1BC0,
//		I		J		K		L		M		N		O		P		Q		R		S
   0x2421, 0x1E00, 0x0354, 0x0700, 0x1B06, 0x1B12, 0x3F00, 0x33C0, 0x3F10, 0x33D0, 0x2DC0,
//		T		U		V		W		X		Y		Z		*		+		-
   0x2021, 0x1F00, 0x030C, 0x1B18, 0x001E, 0x11E0, 0x240C, 0x00FF, 0x00E1, 0x00C0};

/////////////////////////////////////////////////////////////////////////////
// CDigiDisplay

CDigiDisplay::CDigiDisplay()
	: m_strText(_T("EMPTY"))
{
	TCHAR szCharSet[] = _T(" 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ*+-:.");
	int iBmp;
	HBITMAP Temp;

	m_OffColor = DARKRED;
	m_OnColor = LIGHTRED;
	m_BackColor = BLACK;

	for(int i = 0; i < TOTCHARS; i++)
	{
		iBmp = GetDigit(szCharSet[i]);
		Temp = LoadDigitBitMap(iBmp);
		::GetObject(Temp, sizeof BITMAP, &m_BM[i]);
		::DeleteObject(Temp);
	}
}

BEGIN_MESSAGE_MAP(CDigiDisplay, CStatic)
	//{{AFX_MSG_MAP(CDigiDisplay)
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CDigiDisplay::SetText(LPCSTR lpszText)
{
	if (m_strText != lpszText)
	{
		m_strText = lpszText;
		Invalidate();
	}
}

void CDigiDisplay::SetColor(COLORREF OffColor, COLORREF OnColor)
{
	if (m_OnColor == OnColor && m_OffColor == OffColor)
		return;
	m_OnColor = OnColor;
	m_OffColor = OffColor;
	Invalidate();
}

void CDigiDisplay::SetBackColor(COLORREF BackColor /* = BLACK */)
{
	if (m_BackColor == BackColor)
		return;
	m_BackColor = BackColor;
	Invalidate();
}

HBITMAP CDigiDisplay::LoadDigitBitMap(int iBmp)
{
	int			iResID;
	COLORMAP	mapColor[NSEGCOLORS + 1];
	WORD		SegMask;

	if (iBmp < MAXSEGCHARS)
	{
		SegMask = 1;
		for (int iColor = 0; iColor < NSEGCOLORS; iColor++)
		{
			mapColor[iColor].from = SEGM_COLORS[iColor];
			mapColor[iColor].to = (CHAR_SEGMENTS[iBmp] & SegMask)?m_OnColor:m_OffColor;
			SegMask <<= 1;
		}
		mapColor[NSEGCOLORS].from = BACKGROUND;
		mapColor[NSEGCOLORS].to  = m_BackColor;
		return ::CreateMappedBitmap(AfxGetInstanceHandle(), IDB_COOLDIGIT, 0, mapColor, NSEGCOLORS + 1);
	}
	else
	{
		mapColor[0].from = BACKGROUND;
		mapColor[0].to  = m_BackColor;
		mapColor[1].from = SEGM_COLORS[6]; // LIGHTRED
		mapColor[1].to  = m_OnColor;
		switch(iBmp)
		{
			case MAXSEGCHARS	: iResID = IDB_COOLDIGITDOT;	break; // '.'
			case MAXSEGCHARS + 1: iResID = IDB_COOLDIGITCOLON;	break; // ':'
		}
		return ::CreateMappedBitmap(AfxGetInstanceHandle(), iResID, 0, mapColor, 2);
	}

	return NULL;
}

int CDigiDisplay::GetDigit(TCHAR cChar)
{
	int iBmp = 0;

	if (cChar >= _T('0') && cChar <= _T('9'))
	{
		iBmp = cChar - _T('0') + 1;
	}
	else if (cChar >= _T('A') && cChar <= _T('Z'))
	{
		iBmp = cChar - _T('A') + 11;
	}
	else
	{
		switch(cChar)
		{
			case _T(' '): iBmp = 0; break;
			case _T('.'): iBmp = MAXSEGCHARS; break;
			case _T(':'): iBmp = MAXSEGCHARS + 1; break;
			case _T('*'): iBmp = 37; break;
			case _T('+'): iBmp = 38; break;
			case _T('-'): iBmp = 39; break;
			default : ASSERT(FALSE);
		}
	}
	return iBmp;
}

/////////////////////////////////////////////////////////////////////////////
// CDigiDisplay message handlers
void CDigiDisplay::OnPaint() 
{
	CPaintDC dc(this);
	CDC dcMem;
	VERIFY(dcMem.CreateCompatibleDC(0));

	CRect rect;
	GetClientRect(rect);

	const int nHeight = rect.Height();
	register int i;

	register const int len = m_strText.GetLength();
	double pixWidth = 0, RelSize, OffSet = 0;
	int iBmp;

	// Get length of total string
	for (i = 0; i < len; i++)
	{
		iBmp = GetDigit(m_strText[i]);
		pixWidth += m_BM[iBmp].bmWidth;
	}

	// Calculate resize factor.
	RelSize = rect.Width() / pixWidth;

	// Show it...
	for (i = 0; i < len; i++)
	{
		CBitmap * pBmp;
		iBmp = GetDigit(m_strText[i]);
		HBITMAP temp = LoadDigitBitMap(iBmp);
		pBmp = CBitmap::FromHandle(temp);

		CBitmap* pBmpOld = dcMem.SelectObject(pBmp);
		double nDum;

		VERIFY(dc.StretchBlt(int(OffSet + 0.5), 0, int(modf(OffSet, &nDum) + 0.5 + m_BM[iBmp].bmWidth * RelSize + 0.5), 
				nHeight, &dcMem, 0, 0, m_BM[iBmp].bmWidth, m_BM[iBmp].bmHeight, SRCCOPY));
 		dcMem.SelectObject(pBmpOld);
		VERIFY(::DeleteObject(temp));
		OffSet += m_BM[iBmp].bmWidth * RelSize;
	}
	VERIFY(dcMem.DeleteDC());
}

BOOL CDigiDisplay::OnEraseBkgnd(CDC* /*pDC*/) 
{
	return TRUE;
}

void DDX_DigiDisplay(CDataExchange* pDX, int nIDC, LPCTSTR lpszFormat, ...)
{
	TCHAR szMessage[256];

	HWND hWndCtrl = pDX->PrepareCtrl(nIDC);
	ASSERT(hWndCtrl);
	CDigiDisplay * pCtrl = (CDigiDisplay*) CWnd::FromHandle(hWndCtrl);
	ASSERT(pCtrl);

	if(!pDX->m_bSaveAndValidate)
	{
		va_list argp;
		va_start(argp, lpszFormat);
		_vsnprintf(szMessage, 255, lpszFormat, argp);
		va_end(argp);                               

		pCtrl->SetText(szMessage);
	}
}

CDigiClock::CDigiClock()
{
	m_bAlarm  = FALSE;
	m_style	  = XDC_SECOND;
	m_strText = _T("--:--:--");
	m_nCount  = 0;
}

BEGIN_MESSAGE_MAP(CDigiClock, CDigiDisplay)
	//{{AFX_MSG_MAP(CDigiClock)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDigiClock message handlers

void CDigiClock::PreSubclassWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	m_nTimer = SetTimer(1, 1000, NULL);
	ASSERT(m_nTimer);
	
	CDigiDisplay::PreSubclassWindow();
}

void CDigiClock::OnDestroy() 
{
	CDigiDisplay::OnDestroy();
	
	// TODO: Add your message handler code here
	KillTimer(m_nTimer);	
}

void CDigiClock::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == m_nTimer)
	{
		m_nCount++;
		CTime time = CTime::GetCurrentTime();
		int nh = time.GetHour();
		int nm = time.GetMinute();
		int ns = time.GetSecond();

		switch(m_style) {
			case XDC_SECOND:
			{
				if (m_bAlarm && m_nCount%2)
					m_strText = _T("  :  :  ");
				else
					m_strText.Format(_T("%02d:%02d:%02d"), nh, nm, ns);
			}
			break;
			case XDC_NOSECOND:
			default:
				if (m_bAlarm && m_nCount%2)
					m_strText = _T("  :  ");
				else
					m_strText.Format(_T("%02d:%02d:"), nh, nm);
				break;
		};
		if (m_bAlarm)
			MessageBeep(MB_OK);
		Invalidate();
	}

	CDigiDisplay::OnTimer(nIDEvent);
}

BOOL CDigiClock::SetAlarm(BOOL bAlarm /*= TRUE*/)
{
	BOOL temp = m_bAlarm;
	m_bAlarm = bAlarm;
	return temp;
}
