// CDigiDisplay.h : header file
//
// Copyright (C) 1998 by Michel Wassink
// All rights reserved
//
// This is free software.
// You may redistribute it by any means providing it is not sold for profit
// without the author written consent.
//
// No warrantee of any kind, expressed or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Basic idea from J�rg K�nig of the completely free tetris clone "CGTetris".
// Clock stuff from by Xie Jingwei. 

// Version: 1.1
// Release: 2 (may 1999 to www.codeguru.com)
// -----------------------------------------------------------------------
// Notes to changes for release 2 (V1.1):
//  -	Now can be used in an extension dll. It gets the bitmaps from the 
//		correct resource.(C. Shawn Bowlin)
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc., and
// I'll try to keep a version up to date.  I can be reached as follows:
//    mww@mitutoyo.nl                 (company site)
//    mwassink@csi.com				  (private site)
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CDigiDisplay_H__84DF3FA2_067D_11D2_9AA5_0060B0CDC13E__INCLUDED_)
#define AFX_CDigiDisplay_H__84DF3FA2_067D_11D2_9AA5_0060B0CDC13E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include "RGBCOLOR.H"

#define MAXSEGCHARS 40
#define TOTCHARS	(MAXSEGCHARS+2)

/////////////////////////////////////////////////////////////////////////////
// CDigiDisplay window

class CDigiDisplay : public CStatic
{
// Construction
public:
	CDigiDisplay();

// Attributes
public:
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDigiDisplay)
	//}}AFX_VIRTUAL

// Implementation
public:
	void	SetText(LPCSTR lpszText);
	COLORREF GetColor() const { return m_OnColor;}
	void	SetColor(COLORREF OffColor, COLORREF OnColor);
	void	SetBackColor(COLORREF BackColor = BLACK);

	// Generated message map functions
protected:
	//{{AFX_MSG(CDigiDisplay)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	//}}AFX_MSG
	void UpdateColor();
	HBITMAP LoadDigitBitMap(int iBmp);
	int GetDigit(TCHAR cChar);

	DECLARE_MESSAGE_MAP()
protected:
	CString		m_strText;				// Text to display
private:
	BITMAP		m_BM[TOTCHARS];			// character dimensions
	COLORREF    m_OffColor;				// LED off color
	COLORREF    m_OnColor;				// LED on color
	COLORREF    m_BackColor;			// Background color
};

void DDX_DigiDisplay(CDataExchange* pDX, int nIDC, LPCTSTR lpszFormat, ... );

class CDigiClock : public CDigiDisplay
{
// Construction
public:
	CDigiClock();
// Attributes
public:
	enum CClockStyle { XDC_SECOND, XDC_NOSECOND };
// Operations
public:
	CClockStyle GetStyle() const { return m_style;}
	CClockStyle SetStyle(CClockStyle style);
	BOOL GetAlarm() const { return m_bAlarm;}
	BOOL SetAlarm(BOOL bAlarm = TRUE);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDigiClock)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

	// Implementation
public:

	// Generated message map functions
protected:
	//{{AFX_MSG(CDigiClock)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	//}}AFX_MSG
private:
	BOOL		m_bAlarm;				// Alarm mode
	CClockStyle m_style;				// clock style
	UINT		m_nTimer;				// active timer
	UINT		m_nCount;				// timer counts

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CDigiDisplay_H__84DF3FA2_067D_11D2_9AA5_0060B0CDC13E__INCLUDED_)
