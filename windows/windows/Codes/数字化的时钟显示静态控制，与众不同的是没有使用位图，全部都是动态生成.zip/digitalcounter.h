// digitalcounter.h : main header file for the DIGITALCOUNTER application
//

#if !defined(AFX_DIGITALCOUNTER_H__3CCE2744_C65C_11D2_BA4A_00104B6C2FFE__INCLUDED_)
#define AFX_DIGITALCOUNTER_H__3CCE2744_C65C_11D2_BA4A_00104B6C2FFE__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CDigitalcounterApp:
// See digitalcounter.cpp for the implementation of this class
//

class CDigitalcounterApp : public CWinApp
{
public:
	CDigitalcounterApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDigitalcounterApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDigitalcounterApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIGITALCOUNTER_H__3CCE2744_C65C_11D2_BA4A_00104B6C2FFE__INCLUDED_)
