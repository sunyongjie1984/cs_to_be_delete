//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by digitalclock.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DIGITALCLOCK_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDB_BITMAP2                     130
#define IDB_BITMAP3                     131
#define IDB_BITMAP4                     132
#define IDB_BITMAP5                     133
#define IDB_BITMAP6                     134
#define IDB_BITMAP7                     135
#define IDB_BITMAP8                     136
#define IDB_BITMAP9                     137
#define IDB_BITMAP10                    138
#define IDB_BITMAP11                    139
#define IDB_BITMAP12                    140
#define IDC_STATIC_1                    1000
#define IDC_BUTTON1                     1001
#define IDC_STATIC_2                    1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
