// Ccc.cpp : implementation file
//

#include "stdafx.h"
#include "GuestInfo.h"
#include "Ccc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCcc

IMPLEMENT_DYNAMIC(CCcc, CRecordset)

CCcc::CCcc(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CCcc)
	m_NAME = _T("");
	m_EMAIL = _T("");
	m_COMMENTS = _T("");
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}


CString CCcc::GetDefaultConnect()
{
	return _T("ODBC;DSN=gajerry");
}

CString CCcc::GetDefaultSQL()
{
	return _T("[FONT].[SIGNBOOK]");
}

void CCcc::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CCcc)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[NAME]"), m_NAME);
	RFX_Text(pFX, _T("[EMAIL]"), m_EMAIL);
	RFX_Text(pFX, _T("[COMMENTS]"), m_COMMENTS);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CCcc diagnostics

#ifdef _DEBUG
void CCcc::AssertValid() const
{
	CRecordset::AssertValid();
}

void CCcc::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
