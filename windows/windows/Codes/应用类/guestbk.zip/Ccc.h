#if !defined(AFX_CCC_H__8C664753_E07D_11D2_A17C_0000E83EA9A3__INCLUDED_)
#define AFX_CCC_H__8C664753_E07D_11D2_A17C_0000E83EA9A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Ccc.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCcc recordset

class CCcc : public CRecordset
{
public:
	CCcc(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CCcc)

// Field/Param Data
	//{{AFX_FIELD(CCcc, CRecordset)
	CString	m_NAME;
	CString	m_EMAIL;
	CString	m_COMMENTS;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCcc)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCC_H__8C664753_E07D_11D2_A17C_0000E83EA9A3__INCLUDED_)
