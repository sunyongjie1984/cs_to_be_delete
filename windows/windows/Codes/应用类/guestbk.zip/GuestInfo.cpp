// GUESTINFO.CPP - Implementation file for your Internet Server
//    GuestInfo Extension SQL_DRIVER_NOPROMPT

#include "stdafx.h"
#include "ccc.h"
#include "GuestInfo.h"
#include "Coolhttpserver.h"
// here's a table of all the available Server Environmental Variables
const char *cEnvironment[] = { "ALL_HTTP", "AUTH_TYPE", "CONTENT_LENGTH", 
	"CONTENT_TYPE", "HTTP_AUTHORIZATION", "LOGON_USER", "URL",
	"GATEWAY_INTERFACE", "HTTP_ACCEPT", "USER_AGENT", "PATH_INFO",
	"PATH_TRANSLATED", "QUERY_STRING", "REMOTE_HOST", "REMOTE_ADDR",
	"REMOTE_IDENT", "REQUEST_METHOD", "REMOTE_USER", "SERVER_NAME",
	"SERVER_SOFTWARE", "SERVER_PORT", "SERVER_PROTOCOL", "SCRIPT_NAME",
	"HTTP_COOKIE", "HTTP_REFERER" };

const int cNumberOfVars = 25;

///////////////////////////////////////////////////////////////////////
// The one and only CWinApp object
// NOTE: You may remove this object if you alter your project to no
// longer use MFC in a DLL.

CWinApp theApp;
class CFormParser;

///////////////////////////////////////////////////////////////////////
// command-parsing map

BEGIN_PARSE_MAP(CGuestInfoExtension, CCoolHttpServer)
	// TODO: insert your ON_PARSE_COMMAND() and 
	// ON_PARSE_COMMAND_PARAMS() here to hook up your commands.
	// For example:

	ON_PARSE_COMMAND(Default, CGuestInfoExtension, ITS_EMPTY)
	DEFAULT_PARSE_COMMAND(Default, CGuestInfoExtension)
	ON_PARSE_COMMAND(ShowComments, CGuestInfoExtension, ITS_EMPTY)
	ON_PARSE_COMMAND(SignBook, CGuestInfoExtension, ITS_PSTR ITS_PSTR ITS_PSTR ITS_PSTR )
	ON_PARSE_COMMAND_PARAMS("name email comments task")
END_PARSE_MAP(CGuestInfoExtension)


///////////////////////////////////////////////////////////////////////
// The one and only CGuestInfoExtension object

CGuestInfoExtension theExtension;


///////////////////////////////////////////////////////////////////////
// CGuestInfoExtension implementation

CGuestInfoExtension::CGuestInfoExtension()
{
}

CGuestInfoExtension::~CGuestInfoExtension()
{
}

BOOL CGuestInfoExtension::GetExtensionVersion(HSE_VERSION_INFO* pVer)
{
	// Call default implementation for initialization
	CCoolHttpServer::GetExtensionVersion(pVer);

	// Load description string
	TCHAR sz[HSE_MAX_EXT_DLL_NAME_LEN+1];
	ISAPIVERIFY(::LoadString(AfxGetResourceHandle(),
			IDS_SERVER, sz, HSE_MAX_EXT_DLL_NAME_LEN));
	_tcscpy(pVer->lpszExtensionDesc, sz);
	return TRUE;
}

///////////////////////////////////////////////////////////////////////
// CGuestInfoExtension command handlers

void CGuestInfoExtension::Default(CHttpServerContext* pCtxt)
{
	StartContent(pCtxt);
	WriteTitle(pCtxt);

	*pCtxt << _T("This default message was produced by the Internet");
	*pCtxt << _T(" Server DLL Wizard. Edit your CGuestInfoExtension::Default()");
	*pCtxt << _T(" implementation to change it.\r\n");

	EndContent(pCtxt);
}

// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CGuestInfoExtension, CCoolHttpServer)
	//{{AFX_MSG_MAP(CGuestInfoExtension)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0



///////////////////////////////////////////////////////////////////////
// If your extension will not use MFC, you'll need this code to make
// sure the extension objects can find the resource handle for the
// module.  If you convert your extension to not be dependent on MFC,
// remove the comments arounn the following AfxGetResourceHandle()
// and DllMain() functions, as well as the g_hInstance global.

/****

static HINSTANCE g_hInstance;

HINSTANCE AFXISAPI AfxGetResourceHandle()
{
	return g_hInstance;
}

BOOL WINAPI DllMain(HINSTANCE hInst, ULONG ulReason,
					LPVOID lpReserved)
{
	if (ulReason == DLL_PROCESS_ATTACH)
	{
		g_hInstance = hInst;
	}

	return TRUE;
}

****/

//
//	function:	DoGuestBook
//	purpose:	Calls member functions to add or view guests 
//				from our database.
//	returns:	nada
//	
void CGuestInfoExtension::SignBook(CHttpServerContext* pCtxt,LPCTSTR szName,LPCTSTR szEmail,LPCTSTR szComments,LPCTSTR szTask)
{
	StartContent(pCtxt);

/*
	TCHAR buffer[256];
	unsigned long bufferSize;
	FILE *fp;
	fp=fopen("smithvar.txt","w+t");
	if( fp==NULL) throw(-1);
	fprintf(fp,"%s\n","Server Variable");
	for(short index=0;index != cNumberOfVars; index++)
	{
		bufferSize=sizeof(buffer);
		if(pCtxt->GetServerVariable(const_cast<char *>(cEnvironment[index]),buffer,&bufferSize))
			fprintf(fp,"%s = %s\n",cEnvironment[index],buffer);
	}
	fprintf(fp,"%s = %s\n","lpszQueryString",pCtxt->m_pECB->lpszQueryString);
	fclose(fp);
*/
	// make sure no one else passes this point
	// until we unlock things
	CSingleLock	lock(&m_guestSection, TRUE);
	try
	{
		// do we want to view guests, or add our name?
		if (  strcmp(szTask,"�ύ����") != 0 )
			ShowComments(pCtxt);
		else
		{
			// our guest record
			CCcc	guestRec;
			bool		dontAdd = false;

			// open links to our database table
			guestRec.Open();

			// see if the guest is in our database already
			if ( !guestRec.IsEOF() )
			{	
				guestRec.MoveFirst();								// start with the first entry
				while( !guestRec.IsEOF() )
				{
					// what are they doing there already?
					if ( (strcmp( guestRec.m_NAME,szName)==0)&&(strcmp( guestRec.m_EMAIL,szEmail)==0) ){
						dontAdd = true;								// they already entered the info
						break;										// but ended up here again?	
					}
					guestRec.MoveNext();
				}
			}
			
			// don't add them?
			if ( dontAdd )
			{
				*pCtxt << "<CENTER><H1>Thanks, but you're already listed!"
					"</H1><BR><BR><BR></CENTER>";
			}
			else	// stuff them in the database!
			{
				guestRec.AddNew();									// new blank record
				guestRec.m_NAME = szName;
				guestRec.m_EMAIL = szEmail;
				guestRec.m_COMMENTS = szComments;

				if ( guestRec.CanUpdate() )
					guestRec.Update();								// update the entry in the db
				guestRec.Requery();									// make sure the changes hold
		
				*pCtxt << "<CENTER><H1>Thank you for signing our Guest Book!"
					"</H1><BR><BR><BR></CENTER>";
			}

			guestRec.Close();

			// better unlock things, or we'll keep threads out and
			// our dll will look dead -- and might as well be!
			if ( lock.IsLocked() )
				lock.Unlock();
		}
	}

	catch(CDBException *ex)
	{
		if ( lock.IsLocked() )
			lock.Unlock();
		TCHAR	errorMsg[1024];
		*pCtxt << "<b><center>Sorry, an error occurred with the database.<br></center></b>";
		if ( ex->GetErrorMessage(errorMsg,sizeof(errorMsg)) )
		{
			*pCtxt << "<center>";
			*pCtxt << errorMsg;
			*pCtxt << "</center><br>";
		}
		EndContent( pCtxt );
	}

	catch(...)
	{
		if ( lock.IsLocked() )
			lock.Unlock();
		*pCtxt << "<H1><CENTER>Please fill out <B>all</B> information completely and resubmit.</CENTER></H1><BR><BR><BR>";
		EndContent( pCtxt );
	}

	EndContent(pCtxt);

} // DoGuestBook...

void CGuestInfoExtension::ShowComments(CHttpServerContext* pCtxt)
{
	CCcc	guestInfo;

	guestInfo.Open();							// open DB table, find item if it's there
	if ( !guestInfo.IsEOF() )					// not an empty table?
	{
				// display ouput as a table
		*pCtxt << "<CENTER><H2>Guests who have signed in:</H2><BR>";
		*pCtxt << "<TABLE BORDER=1 CELLSPACING=3>";
		*pCtxt << "<TR><TH>Name</TH><TH>Home Town</TH><TH>Comments</TH></TR>";

		guestInfo.MoveFirst();					// start at beginning
		do									// loop until we find our item
		{
			*pCtxt << "<TR><TD>" << guestInfo.m_NAME << "</TD><TD>" <<
				 guestInfo.m_EMAIL << "</TD><TD>" <<  guestInfo.m_COMMENTS << "</TD></TR><BR>";
			guestInfo.MoveNext();
		} 
		while ( !guestInfo.IsEOF() );

		// to get here, we had to be successful, so respond!
		*pCtxt << "</TABLE></CENTER><BR><BR><BR>";
	}

	guestInfo.Close();
} // ViewGuestBook...
