// GuestBk.cpp : implementation file
//

#include "stdafx.h"
#include "GuestInfo.h"
#include "GuestBk.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGuestBk

IMPLEMENT_DYNAMIC(CGuestBk, CRecordset)

CGuestBk::CGuestBk(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CGuestBk)
	m_NAME = _T("");
	m_EMAIL = _T("");
	m_COMMENTS = _T("");
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
	//	m_nDefaultType = snapshot;
}


CString CGuestBk::GetDefaultConnect()
{
	return _T("ODBC;DSN=oracle; UID=font; PWD=font");
//	return _T("ODBC;DSN=oracle");
}

CString CGuestBk::GetDefaultSQL()
{
	return _T("[FONT].[SIGNBOOK]");
}

void CGuestBk::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CGuestBk)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[NAME]"), m_NAME);
	RFX_Text(pFX, _T("[EMAIL]"), m_EMAIL);
	RFX_Text(pFX, _T("[COMMENTS]"), m_COMMENTS);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CGuestBk diagnostics

#ifdef _DEBUG
void CGuestBk::AssertValid() const
{
	CRecordset::AssertValid();
}

void CGuestBk::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
