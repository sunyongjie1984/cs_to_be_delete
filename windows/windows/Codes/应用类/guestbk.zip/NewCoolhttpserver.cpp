// COOLHTTPSERVER.CPP - Implementation file for your Internet Server
//    CoolHttpServer Extension

#include "stdafx.h"
#include "NewCoolHttpServer.h"
#include <fstream.h>


// our header and footer file names
const char *cHeaderName = "c:\\inetpub\\gigantor\\coriolis\\head.htm";
const char *cFooterName = "c:\\inetpub\\gigantor\\coriolis\\foot.htm";

///////////////////////////////////////////////////////////////////////
// The one and only CWinApp object
// NOTE: You may remove this object if you alter your project to no
// longer use MFC in a DLL.

//CWinApp theApp;

///////////////////////////////////////////////////////////////////////
// command-parsing map

BEGIN_PARSE_MAP(CCoolHttpServer, CHttpServer)
	// TODO: insert your ON_PARSE_COMMAND() and 
	// ON_PARSE_COMMAND_PARAMS() here to hook up your commands.
	// For example:

	ON_PARSE_COMMAND(Default, CCoolHttpServer, ITS_EMPTY)
	DEFAULT_PARSE_COMMAND(Default, CCoolHttpServer)
END_PARSE_MAP(CCoolHttpServer)


///////////////////////////////////////////////////////////////////////
// The one and only CCoolHttpServer object

//CCoolHttpServer theExtension;


///////////////////////////////////////////////////////////////////////
// CCoolHttpServer implementation

CCoolHttpServer::CCoolHttpServer()
{
}

CCoolHttpServer::~CCoolHttpServer()
{
}

BOOL CCoolHttpServer::GetExtensionVersion(HSE_VERSION_INFO* pVer)
{
	// Call default implementation for initialization
	CHttpServer::GetExtensionVersion(pVer);

	// Load description string
	TCHAR sz[HSE_MAX_EXT_DLL_NAME_LEN+1];
	ISAPIVERIFY(::LoadString(AfxGetResourceHandle(),
			IDS_SERVER, sz, HSE_MAX_EXT_DLL_NAME_LEN));
	_tcscpy(pVer->lpszExtensionDesc, sz);
	return TRUE;
}

///////////////////////////////////////////////////////////////////////
// CCoolHttpServer command handlers

void CCoolHttpServer::Default(CHttpServerContext* pCtxt)
{
	StartContent(pCtxt);
	WriteTitle(pCtxt);

	*pCtxt << _T("This default message was produced by the Internet");
	*pCtxt << _T(" Server DLL Wizard. Edit your CCoolHttpServer::Default()");
	*pCtxt << _T(" implementation to change it.\r\n");

	EndContent(pCtxt);
}

// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CCoolHttpServer, CHttpServer)
	//{{AFX_MSG_MAP(CCoolHttpServer)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0



///////////////////////////////////////////////////////////////////////
// If your extension will not use MFC, you'll need this code to make
// sure the extension objects can find the resource handle for the
// module.  If you convert your extension to not be dependent on MFC,
// remove the comments arounn the following AfxGetResourceHandle()
// and DllMain() functions, as well as the g_hInstance global.

/****

static HINSTANCE g_hInstance;

HINSTANCE AFXISAPI AfxGetResourceHandle()
{
	return g_hInstance;
}

BOOL WINAPI DllMain(HINSTANCE hInst, ULONG ulReason,
					LPVOID lpReserved)
{
	if (ulReason == DLL_PROCESS_ATTACH)
	{
		g_hInstance = hInst;
	}

	return TRUE;
}

****/

void CCoolHttpServer::EndContent(CHttpServerContext* pCtxt) const
{
	StreamFile( pCtxt, cFooterName );
	CHttpServer::EndContent(pCtxt);
}

void CCoolHttpServer::StartContent(CHttpServerContext* pCtxt) const
{
	CHttpServer::StartContent(pCtxt);
	StreamFile( pCtxt, cHeaderName );
}

//
//	function:	CCoolHttpServer::StreamFile
//	purpose:	streams the designated file via CHttpServerContext.
//	returns:	nothing.
//
void 
CCoolHttpServer::StreamFile( CHttpServerContext* pCtxt, const char *inFile) const
{
	try
	{
		ifstream	file( inFile );	// file stream
		
		if ( !file )				// if we don't get the file, then
			throw(-1);				// throw an exception

		char buffer[BUFSIZ];			// just a line of characters
		memset(buffer,0,BUFSIZ);
		
		// here we loop through the file line by line until we hit the end
		//	sending all the data to cout.
	/*	while ( file.getline(buffer,sizeof(buffer)) )
			*pCtxt << buffer;*/
		while( file.get( buffer,sizeof(buffer),'\0') )
			*pCtxt << buffer;

		file.close();
	}

	catch(...)
	{
		cout << "<center><b>Couldn't locate the file to stream.<br></center></b>";
	}
} // CCoolHttpServer::StreamFile

//
//	function:CCoolHttpServer::CallFunction
//	purpose:	overrides CHttpServer's member to facilitate variable input
//				argumnets.
//	returns:	whatever CHttpServer normally returns
//
int 
CCoolHttpServer::CallFunction( CHttpServerContext* pCtxt, LPTSTR pszQuery,  LPTSTR pszCommand )
{
	string	functionToCall;
	LPTSTR	tempStorage;

	// check to see if we're using a GET method
	if ( !pszCommand )
	{
		// now we just want to get the name of the member function to call
		functionToCall = pszQuery;	
		int index = functionToCall.find('?',0);
		functionToCall[index+1] = '\0';

		// now get the variables set up in our map
		string variables = pszQuery + index;
		//m_formParserP = new CFormParser( variables.c_str() );
	}
	else// must be a POST
	{
		functionToCall = pszCommand;
		if ( functionToCall.compare("StoreUserData") == 0 )
		{
			tempStorage = pCtxt->m_pECB->lpszQueryString;
			pCtxt->m_pECB->lpszQueryString = pszQuery;
			functionToCall += "?";
		}
	}

	// call base member and let it use the Parse Maps for us
	if ( functionToCall.compare("StoreUserData?") == 0 /*|| functionToCall.compare("DoGuestBook") == 0*/)
	{
		int result = CHttpServer::CallFunction( pCtxt, const_cast<char *>(functionToCall.c_str()), NULL );
		pCtxt->m_pECB->lpszQueryString = tempStorage;
		return result;
	}
	else
		return CHttpServer::CallFunction( pCtxt, pszQuery, pszCommand );
} // CCoolHttpServer::CallFunciton...

