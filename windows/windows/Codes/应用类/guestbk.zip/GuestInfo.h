#if !defined(AFX_GUESTINFO_H__F6B5C893_6206_11D2_BBAC_444553540000__INCLUDED_)
#define AFX_GUESTINFO_H__F6B5C893_6206_11D2_BBAC_444553540000__INCLUDED_

// GUESTINFO.H - Header file for your Internet Server
//    GuestInfo Extension

#include "resource.h"
#include "Coolhttpserver.h"

class CGuestInfoExtension : public CCoolHttpServer
{
//zxn
private:
	CCriticalSection	m_guestSection;

	void ShowComments(CHttpServerContext* pCtxt);
//
public:
	CGuestInfoExtension();
	~CGuestInfoExtension();

// Overrides
	// ClassWizard generated virtual function overrides
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//{{AFX_VIRTUAL(CGuestInfoExtension)
	public:
	virtual BOOL GetExtensionVersion(HSE_VERSION_INFO* pVer);
	//}}AFX_VIRTUAL

	// TODO: Add handlers for your commands here.
	// For example:

	void Default(CHttpServerContext* pCtxt);
	void SignBook(CHttpServerContext* pCtxt,LPCTSTR szName,LPCTSTR szEmail,LPCTSTR szComments,LPCTSTR szTask);

	DECLARE_PARSE_MAP()

	//{{AFX_MSG(CGuestInfoExtension)
	//}}AFX_MSG
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GUESTINFO_H__F6B5C893_6206_11D2_BBAC_444553540000__INCLUDED)
