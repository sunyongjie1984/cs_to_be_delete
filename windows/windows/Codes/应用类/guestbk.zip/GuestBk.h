#if !defined(AFX_GUESTBK_H__2C81A1A6_E075_11D2_A179_0000E83EA9A3__INCLUDED_)
#define AFX_GUESTBK_H__2C81A1A6_E075_11D2_A179_0000E83EA9A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GuestBk.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGuestBk recordset

class CGuestBk : public CRecordset
{
public:
	CGuestBk(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CGuestBk)

// Field/Param Data
	//{{AFX_FIELD(CGuestBk, CRecordset)
	CString	m_NAME;
	CString	m_EMAIL;
	CString	m_COMMENTS;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGuestBk)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GUESTBK_H__2C81A1A6_E075_11D2_A179_0000E83EA9A3__INCLUDED_)
