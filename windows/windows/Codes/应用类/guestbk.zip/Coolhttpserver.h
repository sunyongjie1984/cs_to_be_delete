// COOLHTTPSERVER.H - Header file for your Internet Server
//    CoolHttpServer Extension

#ifndef _COOLHTTPSERVER
#define _COOLHTTPSERVER
#include "resource.h"

class CCoolHttpServer : public CHttpServer
{
public:
	void StreamFile( CHttpServerContext *pCtxt, const char *inFile) const;
	CCoolHttpServer();
	~CCoolHttpServer();

// Overrides
	// ClassWizard generated virtual function overrides
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//{{AFX_VIRTUAL(CCoolHttpServer)
	public:
	virtual BOOL GetExtensionVersion(HSE_VERSION_INFO* pVer);
	virtual void EndContent(CHttpServerContext* pCtxt) const;
	virtual void StartContent(CHttpServerContext* pCtxt) const;
	virtual int CallFunction( CHttpServerContext* pCtxt, LPTSTR pszQuery,  LPTSTR pszCommand );
	//}}AFX_VIRTUAL

	// TODO: Add handlers for your commands here.
	// For example:

	void Default(CHttpServerContext* pCtxt);

	DECLARE_PARSE_MAP()

	//{{AFX_MSG(CCoolHttpServer)
	//}}AFX_MSG
};

#endif

