/*
 WiZ version header file
*/
#ifndef _WIZVER_H
#define _WIZVER_H

#include "unzip\windll\unzver.h"
#include "zip\windll\zipver.h"
/*
#define BETA
*/
#ifdef BETA
#undef BETA
#endif

#define APPLICATION "About WiZ\0"
#define WIZ_MAJORVER 4
#define WIZ_MINORVER 0
#define WIZ_FILE_VER "4.00.00\0"

#ifdef BETA
#  define WIZBETALEVEL "h Beta"
#  define WIZ_VERSION_DATE "27 Oct 97"
#else
#define WIZBETALEVEL ""
#  define WIZ_VERSION_DATE "3 Nov 97"
#endif

#define WIZ_PATCHLEVEL   0
#endif /* _WIZVER_H */

