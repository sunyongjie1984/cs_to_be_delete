/*
 WiZ 4.0 header file
*/
#ifndef _RESOURCE_H
#define _RESOURCE_H

/* Group Box defines for resource compiler, not actually used */
#define IDC_OTHER_BOX            100
#define IDC_ZIP_BOX              101
#define IDC_UNZIP_BOX            102
#define IDC_EXTRACTION_BOX       103
#define IDC_SELECTION_BOX        104
#define IDC_GENERAL_BOX          105

/* Main Window Message Codes
 */

#define IDM_OPEN                 106
#define IDM_EXIT                 107

#define IDM_SHORT                108
#define IDM_LONG                 109

#define IDM_SHIFT_HELP           110
#define IDM_HELP                 111
#define IDM_ESCAPE               112
#define IDM_ABOUT                113

#define IDM_RECR_DIR_STRUCT      114
#define IDM_OVERWRITE            115
#define IDM_SAVE_UNZIP_FROM_DIR  116
#define IDM_SAVE_UNZIP_TO_DIR    117
#define IDM_EXTRACT_ONLY_NEWER   118
#define IDM_TRANSLATE            119
#define IDM_SPACE_TO_UNDERSCORE  120
#define IDM_UNZIP_TO_ZIP_DIR     121

#define IDM_LB_EXTRACT           122
#define IDM_LB_DISPLAY           123
#define IDM_LB_TEST              124

#define IDM_UNZIP_FROM_DIR       125
#define IDM_COMMENT              126
#define IDM_SOUND_OPTIONS        127
#define IDM_SELECT_ALL           128

/* These seven items' ID's must be kept
 * in order.
 */
#define IDM_LISTBOX              129
#define IDM_EXTRACT              130
#define IDM_DISPLAY              131
#define IDM_TEST                 132
#define IDM_GET_ZIPINFO          133
#define IDM_ZIP_DELETE_ENTRIES   134
#define IDM_UPDATE_ZIP           135

#define IDM_SHOW_COMMENT         136
#define IDM_STATUS               137

#define IDM_ZIP_STATS            138

#define IDM_SELECT_BY_PATTERN    139

#define IDM_MAX_STATUS           140

#define IDM_DESELECT_ALL         142
#define IDM_CLEAR_STATUS         143
#define IDM_HELP_KEYBOARD        144
#define IDM_HELP_HELP            145
#define IDM_CHDIR                146
#define IDM_SETFOCUS_ON_STATUS   147 /* internal: posted after extraction to Status window */


/* For the Copy, Move, Delete and Rename File functions */
#define IDM_COPY_ARCHIVE         148
#define IDM_MOVE_ARCHIVE         149
#define IDM_DELETE_ARCHIVE       150
#define IDM_RENAME_ARCHIVE       151

#define IDM_SAVE_AS_DEFAULT      152

#define IDM_MAKE_DIR             153
#define IDM_MAKEDIR_PATH         154
#define IDM_MAKEDIR_HELP         155
#define IDM_CURRENT_PATH         156
#define IDM_SHOW_BUBBLE_HELP     157
#define IDM_PROMPT_TO_OVERWRITE  158

#define IDM_PASSWORD             159
/*
 * About box identifiers used to display the current version number
 * information.
 */
#define IDM_ABOUT_VERSION_INFO   160
#define IDM_ABOUT_UNZIP_INFO     161
#define IDM_ABOUT_ZIP_INFO       162


#define IDM_EDIT_SAVE_AS         163
#define IDM_EDIT_OPEN_FILE       164

/* Identifiers used for popup edit menu */
#define IDM_EDIT_UNDO            165
#define IDM_EDIT_CUT             166
#define IDM_EDIT_COPY            167
#define IDM_EDIT_PASTE           168
#define IDM_EDIT_DELETE          169
#define IDM_EDIT_SELECT_ALL      170

#define IDM_ZIP_TARGET           201
#define IDC_ZIP_EXCLUDE_DATE     202
#define IDC_ZIP_INCLUDE_DATE     203

#define IDC_SELECT_ALL           242
#define IDC_DESELECT_ALL         243
#define IDC_ADD                  245
#define IDC_DELETE               246
#define IDC_FILE_LIST            244

#define IDM_SAVE_ZIP_TO_DIR      250

#define IDC_SET_ROOT             251
#define IDC_FREE_ROOT            252
#define IDC_ROOT_DIR             253
#define IDC_MONTH                254
#define IDC_DAY                  255
#define IDC_YEAR                 256
#define IDC_DOWN                 257
#define IDC_UP                   258
#define IDC_DONE                 259

#define IDC_SET_REF              265
#define IDC_FREE_REF             266
#define IDC_REF_DIR              267

#define IDC_RECURSE              270
#define IDC_INCLUDE              271
#define IDC_RECURSE_EDITBOX      272

/* Defines for check boxes in preferences dialog box */
/* Zip Options */
#define IDC_REPAIR               299
#define IDC_REPAIR_MORE          300
#define IDC_MSDOS                301
#define IDC_SYS_FILES            302
#define IDC_VOL_LABEL            303
#define IDC_NO_DIR_ENTRY         304
#define IDC_IGNORE_DIR           305
#define IDC_CRLFLF               306
#define IDC_LFCRLF               307
#define IDC_ENCRYPT              308
#define IDC_MOVE                 309
#define IDC_FILETIME             310
#define IDC_UPDATE               311
#define IDC_FRESHEN              312
#define IDC_QUIET                313
#define IDC_VERBOSE              314
#define IDC_COMPRESSION          315
#define IDC_COMMENT              316
#define IDC_MAKE_DOS_SFX         317
#define IDC_MAKE_W32_SFX         318
#define IDC_OFFSETS              319
/* IDC_PRIVILEGE is also used for the unzip options */
#define IDC_PRIVILEGE            320

/* UnZip Options */
#define IDC_RECREATE_DIR         340
#define IDC_OVERWRITE            341
#define IDC_NEWER                342
#define IDC_PROMPT_OVERWRITE     343
#define IDC_LF_CRLF              344
#define IDC_SPACE_UNDERSCORE     345
#define IDC_LBS_EXTRACT          346
#define IDC_LBS_DISPLAY          347
#define IDC_LBS_TEST             348
#define IDC_ACL                  349

/* General Options */
#define IDC_SAVE_UNZIP_TO        360
#define IDC_SAVE_UNZIP_FROM      361
#define IDC_SAVE_ZIP_TO          362
#define IDC_VIEW_SHORT           363
#define IDC_VIEW_LONG            364
#define IDC_SHOW_TOOLBAR         365
#define IDC_UNZIP_TO_ARCHIVE     366
#define IDC_CLEAR_STATUS         367
#define IDC_CLEAR_DISPLAY        368

#define ID_HELP                  399

#define IDM_EDIT_BOX             400

#define IDM_ZIP_PREFERENCES      401
#define IDM_UNZIP_PREFERENCES    402
#define IDC_TEMP_PREFERENCES     403

#define IDC_PATTERN              410
#define IDM_GREP_ARCHIVE         411

#endif /* _RESOURCE_H */

