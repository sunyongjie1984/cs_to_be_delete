// SampleDlg.h : header file
//

#if !defined(AFX_SAMPLEDLG_H__CDDAAEA6_B78B_11D3_8F9F_0080AD4311B1__INCLUDED_)
#define AFX_SAMPLEDLG_H__CDDAAEA6_B78B_11D3_8F9F_0080AD4311B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// PSAPI wrapper
//

typedef BOOL (WINAPI *TFEnumProcesses)(
    DWORD * lpidProcess, DWORD cb, DWORD * cbNeeded
);
typedef BOOL (WINAPI *TFEnumProcessModules)(
    HANDLE hProcess, HMODULE *lphModule, DWORD cb, LPDWORD lpcbNeeded
);
typedef DWORD (WINAPI *TFGetModuleBaseName)(
    HANDLE hProcess, HMODULE hModule, LPSTR lpBaseName, DWORD nSize
);
typedef DWORD (WINAPI *TFGetModuleFileNameEx)(
    HANDLE hProcess, HMODULE hModule, LPSTR lpFilename, DWORD nSize
);
typedef BOOL (WINAPI *TFGetModuleInformation)(
    HANDLE hProcess, HMODULE hModule, LPMODULEINFO lpmodinfo, DWORD cb
);

class TProcessStatusModule : public TDllModule {
private:
    TFEnumProcesses FEnumProcesses;
    TFEnumProcessModules FEnumProcessModules;
    TFGetModuleBaseName FGetModuleBaseName;
    TFGetModuleFileNameEx FGetModuleFileNameEx;
    TFGetModuleInformation FGetModuleInformation;

private:
    void initAll(void);

public:
    TProcessStatusModule();
    virtual ~TProcessStatusModule();

    virtual BOOL Create(void);
    virtual void Destroy(void);
    
    BOOL EnumProcesses(DWORD * lpidProcess, DWORD cb, DWORD * cbNeeded);
    BOOL EnumProcessModules(HANDLE hProcess,HMODULE *lphModule,DWORD cb,LPDWORD lpcbNeeded);
    DWORD GetModuleBaseName(HANDLE hProcess,HMODULE hModule,LPSTR lpBaseName,DWORD nSize);
    DWORD GetModuleFileNameEx(HANDLE hProcess,HMODULE hModule,LPSTR lpFilename,DWORD nSize);
    BOOL GetModuleInformation(HANDLE hProcess,HMODULE hModule,LPMODULEINFO lpmodinfo,DWORD cb);
};

/////////////////////////////////////////////////////////////////////////////
// CSampleDlg dialog

class CSampleDlg : public CDialog
{
// Construction
public:
	CSampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSampleDlg)
	enum { IDD = IDD_SAMPLE_DIALOG };
	CListCtrl	m_List;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSampleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSampleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnEnum();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SAMPLEDLG_H__CDDAAEA6_B78B_11D3_8F9F_0080AD4311B1__INCLUDED_)
