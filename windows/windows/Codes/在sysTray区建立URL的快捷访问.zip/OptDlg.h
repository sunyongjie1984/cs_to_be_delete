/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file defines the options dialog class.
*/

#if !defined(AFX_OPTDLG_H__47BA70E1_00C3_11D3_861D_00E02918D61A__INCLUDED_)
#define AFX_OPTDLG_H__47BA70E1_00C3_11D3_861D_00E02918D61A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CJTIOptDlg dialog

class CJTITreeView;

class CJTIOptDlg : public CDialog
{
protected:
	CJTITreeView *m_pTree;
	int m_nDefGroup;

// Construction
public:
	CJTIOptDlg(CWnd* pParent = NULL);   // standard constructor

// Operations
public:
	void SetTreePtr(CJTITreeView *pTree) { m_pTree = pTree; }
	void SetGroupInfo(int nDefGroup, BOOL bMonitor) {m_nDefGroup = nDefGroup; m_Monitor = bMonitor; };
	void GetGroupInfo(int& nDefGroup, BOOL& bMonitor) {nDefGroup = m_nDefGroup; bMonitor = m_Monitor; };

// Dialog Data
	//{{AFX_DATA(CJTIOptDlg)
	enum { IDD = IDD_OPTIONS };
	CComboBox	m_Groups;
	BOOL	m_Monitor;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJTIOptDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CJTIOptDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnHelpBtn();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTDLG_H__47BA70E1_00C3_11D3_861D_00E02918D61A__INCLUDED_)
