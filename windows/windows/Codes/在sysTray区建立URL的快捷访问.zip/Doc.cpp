/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file implements the document class which manages the data.
*/

#include "stdafx.h"
#include "jumptoit.h"

#include "Doc.h"
#include "treeview.h"
#include "listview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJTIDoc

IMPLEMENT_DYNCREATE(CJTIDoc, CDocument)

BEGIN_MESSAGE_MAP(CJTIDoc, CDocument)
	//{{AFX_MSG_MAP(CJTIDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJTIDoc construction/destruction

// Constructor
CJTIDoc::CJTIDoc()
{
	// Initialize default group and clipboard monitoring mode
	m_nDefGroup = 0;
	m_bMonitorMode = FALSE;
}

// Destructor
CJTIDoc::~CJTIDoc()
{
}

// Creates a new document
BOOL CJTIDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}

// Saves files that have been changed without prompting the user to save
// the file.  DoFileSave() calls the document's ::Serialize() method
BOOL CJTIDoc::SaveModified() 
{
	// Was the document changed??
	if(IsModified())
		return DoSave(m_strPathName);
	return(TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// CJTIDoc serialization

// Handles reading and writing of group and link data
void CJTIDoc::Serialize(CArchive& ar)
{
	POSITION pos = GetFirstViewPosition();
	CJTITreeView *pTreeView = (CJTITreeView *) GetNextView(pos);
	CJTIListView *pListView = (CJTIListView *) GetNextView(pos);

	int nFileVersion;
	int nDefaultGroup;

	// Writing data?
	if(ar.IsStoring())
	{
		nFileVersion = 0x0100;
	
		// Write the file version
		ar.Write(&nFileVersion,sizeof(nFileVersion));

		// Setup the group remapping table.  This helps us associate
		// items properly with groups that are re-arranged
		int anMap[500];
		memset(anMap,-1,sizeof(anMap));

		// Save the tree and list structures
		pTreeView->SaveTree(ar,anMap);
		pListView->SaveList(ar,anMap);

		// Write the clipboard monitoring flags (make sure the default group
		// number gets mapped back properly too -- we need this in cases
		// where we've rearranged the order of groups)
		nDefaultGroup = m_nDefGroup;
		for(int i = 0; i < 500; i++)
		{
			if(anMap[i] == m_nDefGroup)
				nDefaultGroup = i;
		}

		// Write the clipboard monitoring flags
		ar.Write(&nDefaultGroup,sizeof(nDefaultGroup));
		ar.Write(&m_bMonitorMode,sizeof(m_bMonitorMode));
	}
	else
	{
		// Read the file version
		ar.Read(&nFileVersion,sizeof(nFileVersion));

		// Load the tree and list structures
		int nGroupCount = pTreeView->LoadTree(ar);
		pListView->LoadList(ar);

		// Read the clipboard monitoring flags
		ar.Read(&m_nDefGroup,sizeof(m_nDefGroup));
		ar.Read(&m_bMonitorMode,sizeof(m_bMonitorMode));
	}
}

/////////////////////////////////////////////////////////////////////////////
// CJTIDoc diagnostics

#ifdef _DEBUG
void CJTIDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CJTIDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CJTIDoc commands

// Called when document is closed
void CJTIDoc::OnCloseDocument() 
{
	CDocument::OnCloseDocument();
}

// Called to open document
BOOL CJTIDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	
	SetModifiedFlag(FALSE);

	return TRUE;
}
