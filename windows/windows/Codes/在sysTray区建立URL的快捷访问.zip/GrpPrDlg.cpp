/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file implements the group properties dialog.
*/

#include "stdafx.h"
#include "jumptoit.h"
#include "GrpPrDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJTIGrpPropDlg dialog


// Constructor
CJTIGrpPropDlg::CJTIGrpPropDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CJTIGrpPropDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CJTIGrpPropDlg)
	m_Description = _T("");
	//}}AFX_DATA_INIT
}

// Handles field data exchange
void CJTIGrpPropDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CJTIGrpPropDlg)
	DDX_Text(pDX, IDC_DESCRIPTION, m_Description);
	DDV_MaxChars(pDX, m_Description, 500);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CJTIGrpPropDlg, CDialog)
	//{{AFX_MSG_MAP(CJTIGrpPropDlg)
	ON_BN_CLICKED(IDC_HELPBTN, OnHelpBtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJTIGrpPropDlg message handlers

// Handles WM_INITDIALOG -- sets proper title for properties dialog
BOOL CJTIGrpPropDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// Set by caller to reflect whether we're adding or modifying a group
	if(!m_strTitle.IsEmpty())
		SetWindowText(m_strTitle);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

// Handles the OK button
void CJTIGrpPropDlg::OnOK() 
{
	UpdateData(TRUE);

	// Retrieve the group's description
	m_Description.TrimRight();

	// Is it empty?
	if(m_Description.IsEmpty())
	{
		// Yes...complain to the user then get out
		AfxMessageBox(IDS_VALID_DESCRIPTION,MB_ICONWARNING|MB_OK);
		return;
	}

	CDialog::OnOK();
}


void CJTIGrpPropDlg::OnHelpBtn() 
{
	AfxGetApp()->WinHelp(100,HELP_CONTEXT);
}
