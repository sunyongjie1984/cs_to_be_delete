/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file implements the main frame window.
*/

#include "stdafx.h"
#include "jumptoit.h"

#include "MainFrm.h"
#include "TreeView.h"
#include "ListView.h"
#include "OptDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_WM_DESTROY()
	ON_COMMAND(ID_EXIT, OnExit)
	ON_COMMAND(ID_LINKS, OnLinks)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_OPTIONS, OnOptions)
	ON_COMMAND(ID_HELP_CONTENTS, OnHelpContents)
	//}}AFX_MSG_MAP
	ON_UPDATE_COMMAND_UI_RANGE(AFX_ID_VIEW_MINIMUM, AFX_ID_VIEW_MAXIMUM, OnUpdateViewStyles)
	ON_COMMAND_RANGE(AFX_ID_VIEW_MINIMUM, AFX_ID_VIEW_MAXIMUM, OnViewStyle)
	ON_MESSAGE(UM_TRAY,OnTrayMsg)
	ON_COMMAND_RANGE(IDM_LINK1,IDM_LINK30, OnLink)
	ON_COMMAND(ID_CLOSE, OnClose)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

// Constructor
CMainFrame::CMainFrame()
{
	m_bInMenu = FALSE;
	m_bExitOK = FALSE;
}

// Destructor
CMainFrame::~CMainFrame()
{
}

// Handles creation of frame window -- creates toolbar
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT,WS_CHILD|WS_VISIBLE|CBRS_TOP
		  |CBRS_GRIPPER|CBRS_TOOLTIPS|CBRS_FLYBY|CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);

	return 0;
}

// Handles creation of client area -- creates and sets up splitter window
BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT /*lpcs*/,
	CCreateContext* pContext)
{
	// create splitter window
	if (!m_wndSplitter.CreateStatic(this, 1, 2))
		return FALSE;

	// Get splitter size
	int nPaneSize = AfxGetApp()->GetProfileInt("Location","Pane Size",130);

	// Create the splitter views
	if (!m_wndSplitter.CreateView(0, 0, RUNTIME_CLASS(CJTITreeView), CSize(nPaneSize, 50), pContext) ||
		!m_wndSplitter.CreateView(0, 1, RUNTIME_CLASS(CJTIListView), CSize(100, 50), pContext))
	{
		m_wndSplitter.DestroyWindow();
		return FALSE;
	}

	return TRUE;
}

// Called before window is created -- removes document title and 
// minimize/maximize boxes
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;

	cs.style &= ~(FWS_ADDTOTITLE|WS_MINIMIZEBOX|WS_MAXIMIZEBOX);

	// This guarantees that the main window won't be seen
	// when the program first starts.  The "real" size of the
	// window is controlled by the user's settings anyway so
	// this data doesn't matter
	cs.y = 5000;
	cs.x = 5000;
	cs.cx = 0;
	cs.cy = 0;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

// Returns the right pane pointer
CJTIListView* CMainFrame::GetRightPane()
{
	CWnd* pWnd = m_wndSplitter.GetPane(0, 1);
	CJTIListView* pView = DYNAMIC_DOWNCAST(CJTIListView, pWnd);
	return pView;
}

// Called when view style changes
void CMainFrame::OnUpdateViewStyles(CCmdUI* pCmdUI)
{
	CJTIListView* pView = GetRightPane(); 

	// if the right-hand pane hasn't been created or isn't a view,
	// disable commands in our range
	if (pView == NULL)
		pCmdUI->Enable(FALSE);
	else
	{
		DWORD dwStyle = pView->GetStyle() & LVS_TYPEMASK;

		// if the command is ID_VIEW_LINEUP, only enable command
		// when we're in LVS_ICON or LVS_SMALLICON mode
		if (pCmdUI->m_nID == ID_VIEW_LINEUP)
		{
			if (dwStyle == LVS_ICON || dwStyle == LVS_SMALLICON)
				pCmdUI->Enable();
			else
				pCmdUI->Enable(FALSE);
		}
		else
		{
			// otherwise, use dots to reflect the style of the view
			pCmdUI->Enable();
			BOOL bChecked = FALSE;

			switch (pCmdUI->m_nID)
			{
			case ID_VIEW_LARGEICON:
				bChecked = (dwStyle == LVS_ICON);
				break;

			case ID_VIEW_LIST:
				bChecked = (dwStyle == LVS_REPORT);
				break;

			default:
				bChecked = FALSE;
				break;
			}

			pCmdUI->SetRadio(bChecked ? 1 : 0);
		}
	}
}

void CMainFrame::OnViewStyle(UINT nCommandID)
{
	CJTIListView* pView = GetRightPane();

	// if the right-hand pane has been created and is a CJTIListView,
	// process the menu commands...
	if (pView != NULL)
	{
		DWORD dwStyle = -1;

		switch (nCommandID)
		{
		case ID_VIEW_LINEUP:
			{
				// ask the list control to snap to grid
				CListCtrl& refListCtrl = pView->GetListCtrl();
				refListCtrl.Arrange(LVA_SNAPTOGRID);
			}
			break;

		// other commands change the style on the list control
		case ID_VIEW_DETAILS:
			dwStyle = LVS_REPORT;
			break;

		case ID_VIEW_SMALLICON:
			dwStyle = LVS_SMALLICON;
			break;

		case ID_VIEW_LARGEICON:
			dwStyle = LVS_ICON;
			break;

		case ID_VIEW_LIST:
			dwStyle = LVS_REPORT;
			break;
		}

		// change the style; window will repaint automatically
		if (dwStyle != -1)
			pView->ModifyStyle(LVS_TYPEMASK, dwStyle);

		if(dwStyle & LVS_REPORT)
			pView->ModifyStyle(0,LVS_NOCOLUMNHEADER);
	}
}

// Called when Exit or Close menu item is chosen
void CMainFrame::OnClose() 
{
	if(m_bExitOK)
	{
		CFrameWnd::OnClose();
	}
	else
	{
		m_bInMenu = FALSE;
		ShowWindow(SW_HIDE);
	}
}

// Called when the main window is destroyed
void CMainFrame::OnDestroy() 
{
	int nMin, nPaneSize;

	// Save splitter settings
	m_wndSplitter.GetColumnInfo(0,nPaneSize,nMin);
	AfxGetApp()->WriteProfileInt("Location","Pane Size",nPaneSize);

	CFrameWnd::OnDestroy();
}

LRESULT CMainFrame::OnTrayMsg(WPARAM wParam, LPARAM lParam)
{

	// Determine the tray message
	switch(lParam)
	{
		// Left mouse button release -- send it to the frame's normal message
		// handler
		case WM_LBUTTONDBLCLK:
			if(m_bInMenu)
			{
				BringWindowToTop();
				SetForegroundWindow();
			}
			else OnLinks();
			break;

		// Right mouse button release -- send it to the frame's normal message
		// handler
		case WM_RBUTTONUP:
			if(m_bInMenu)
			{
				BringWindowToTop();
				SetForegroundWindow();
			}
			else ShowContextMenu();
			break;
	}

	return(0);
}

// Displays JumpToIt's tray menu
void CMainFrame::ShowContextMenu()
{
	if(m_bInMenu) 
	{
		::MessageBeep(0);
		BringWindowToTop();
		SetForegroundWindow();
		return;
	}

	// Load the context menu
	CMenu menuMain;

	menuMain.LoadMenu(IDR_TRAYMENU);
	CMenu *pmenuContext = menuMain.GetSubMenu(0);

	// Make sure our window is activated
	SetForegroundWindow();

	int nItemCount = 0;

	// Setup the shortcut menu items
	CJTIDoc *pDoc = (CJTIDoc *) GetActiveDocument();
	GROUPS& arrGroups = pDoc->GetGroups();

	for(int i = 0; i < arrGroups.GetSize(); i++)
	{
		for(int j = 0; j < arrGroups[i].arrItems.GetSize(); j++)
		{
			CItem& item = arrGroups[i].arrItems.GetAt(j);

			// Is this item a shortcut menu type?
			if(!item.strDescription.IsEmpty() && item.byType >= 2)
			{
				// Yes...add it to the tray menu
				pmenuContext->InsertMenu(IDM_DUMMY,MF_BYCOMMAND,IDM_LINK1+nItemCount,
								item.strDescription);
				nItemCount++;
			}
		}
	}

	// Get rid of the placeholder
	pmenuContext->DeleteMenu(IDM_DUMMY,MF_BYCOMMAND);

	// Remove the separator if we have no shortcuts
	if(nItemCount == 0)
		pmenuContext->DeleteMenu(0,MF_BYPOSITION);

	SetMenuDefaultItem(pmenuContext->m_hMenu,ID_LINKS,MF_BYCOMMAND);

	// Display the context menu near the mouse cursor
	POINT pt;

	::GetCursorPos(&pt);
	pmenuContext->TrackPopupMenu(
               TPM_BOTTOMALIGN|TPM_LEFTBUTTON|TPM_RIGHTBUTTON,
               pt.x,pt.y,this,NULL);

	// We no longer need the menu so destroy it
	menuMain.DestroyMenu();

	// Works around Windows menu handling bug that occurs when no
	// selection was made on the context menu -- the basic bug is that
	// it takes 2 mouse clicks to re-activate the menu after this
	// situation.  Sending a dummy message gets around this
	PostMessage(WM_NULL);
}

// Called when Exit is chosen
void CMainFrame::OnExit() 
{
	m_bExitOK = TRUE;
	PostMessage(WM_CLOSE);
}

// Called when the Links tray menu item is chosen
void CMainFrame::OnLinks() 
{
	m_bInMenu = TRUE;
	ShowWindow(SW_SHOW);
	BringWindowToTop();
}

// Called when a shortcut menu item is chosen
void CMainFrame::OnLink(UINT nCommandID)
{
	// Setup the shortcut menu items
	CJTIDoc *pDoc = (CJTIDoc *) GetActiveDocument();
	GROUPS& arrGroups = pDoc->GetGroups();
	int nRow = nCommandID-IDM_LINK1;
	int nItemCount = 0;
	
	// Locate the selected item
	for(int i = 0; i < arrGroups.GetSize(); i++)
	{
		for(int j = 0; j < arrGroups[i].arrItems.GetSize(); j++)
		{
			CItem& item = arrGroups[i].arrItems.GetAt(j);

			if(!item.strDescription.IsEmpty() && item.byType >= 2)
			{
				if(nItemCount == nRow)
				{
					// Run the item
					((CJTIApp *) AfxGetApp())->RunApp(item.strURL);
					return;
				}

				nItemCount++;
			}
		}
	}
}

// Displays the About box
void CMainFrame::OnAppAbout() 
{
	m_bInMenu = TRUE;

	CAboutDlg aboutDlg;
	aboutDlg.DoModal();

	m_bInMenu = FALSE;
}

void CMainFrame::OnEditCopy() 
{
}

void CMainFrame::OnEditCut() 
{
}

void CMainFrame::OnEditPaste() 
{
}

// Displays the options dialog
void CMainFrame::OnOptions() 
{
	CJTIOptDlg dlgOpt;
	CJTIDoc *pDoc = (CJTIDoc *) GetActiveDocument();

	// Setup the tree's location
	dlgOpt.SetTreePtr(GetTree());
	dlgOpt.SetGroupInfo(pDoc->GetDefGroup(),pDoc->GetMonitorMode());

	// Display the dialog
	if(dlgOpt.DoModal() == IDOK)
	{
		int nDefGroup;
		BOOL bMonitorMode;

		// Get the chosen default group and clipboard monitoring option
		dlgOpt.GetGroupInfo(nDefGroup,bMonitorMode);
		pDoc->SetDefGroup(nDefGroup);
		pDoc->SetMonitorMode(bMonitorMode);
		pDoc->SetModifiedFlag(TRUE);
		pDoc->SaveModified();
	}
}

// Determines if another shortcut can be added to JumpToIt's tray menu
BOOL CMainFrame::CanAddShortcut()
{
	CJTIDoc *pDoc = (CJTIDoc *) GetActiveDocument();
	GROUPS& arrGroups = pDoc->GetGroups();
	int nItemCount = 0;

	// Count the current number of shortcut items
	for(int i = 0; i < arrGroups.GetSize(); i++)
	{
		for(int j = 0; j < arrGroups[i].arrItems.GetSize(); j++)
		{
			CItem& item = arrGroups[i].arrItems.GetAt(j);

			if(!item.strDescription.IsEmpty() && item.byType >= 2)
				nItemCount++;
		}
	}

	// Only 30 are allowed...
	return(nItemCount < 30);
}

// Returns a pointer to the group tree control
CTreeCtrl* CMainFrame::GetTreeCtrl() 
{ 
	return GetTree()->GetTreePtr(); 
}

// Called when the help menu item is chosen
void CMainFrame::OnHelpContents() 
{
	AfxGetApp()->WinHelp(0,HELP_FINDER);
}
