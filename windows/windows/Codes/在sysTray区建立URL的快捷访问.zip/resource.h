//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by jumptoit.rc
//
#define IDC_HELPBTN                     3
#define IDD_ABOUTBOX                    100
#define ID_VIEW_ARRANGE                 127
#define IDR_MAINFRAME                   128
#define IDR_JUMPTOTYPE                  129
#define IDB_GROUPS                      130
#define IDB_LIST                        131
#define IDD_PROPERTIES                  132
#define IDR_LISTMENU                    133
#define IDB_LOGO                        133
#define IDD_GROUP_PROPERTIES            133
#define IDR_TREEMENU                    134
#define IDR_TRAYMENU                    135
#define IDD_OPTIONS                     136
#define IDC_DRAG                        136
#define IDM_LINK1                       201
#define IDM_LINK2                       202
#define IDM_LINK3                       203
#define IDM_LINK4                       204
#define IDM_LINK5                       205
#define IDM_LINK6                       206
#define IDM_LINK7                       207
#define IDM_LINK8                       208
#define IDM_LINK9                       209
#define IDM_LINK10                      210
#define IDM_LINK11                      211
#define IDM_LINK12                      212
#define IDM_LINK13                      213
#define IDM_LINK14                      214
#define IDM_LINK15                      215
#define IDM_LINK16                      216
#define IDM_LINK17                      217
#define IDM_LINK18                      218
#define IDM_LINK19                      219
#define IDM_LINK20                      220
#define IDM_LINK21                      221
#define IDM_LINK22                      222
#define IDM_LINK23                      223
#define IDM_LINK24                      224
#define IDM_LINK25                      225
#define IDM_LINK26                      226
#define IDM_LINK27                      227
#define IDM_LINK28                      228
#define IDM_LINK29                      229
#define IDM_LINK30                      230
#define IDC_DESCRIPTION                 1000
#define IDC_URL                         1001
#define IDC_FILE                        1002
#define IDC_WEB                         1003
#define IDC_MENU                        1004
#define IDC_CHECK1                      1006
#define IDC_MONITOR                     1006
#define IDC_GROUPS                      1007
#define ID_ADD_ITEM                     32771
#define ID_DELETE_ITEM                  32772
#define ID_MODIFY_ITEM                  32773
#define ID_OPEN_ITEM                    32774
#define ID_EXIT                         32775
#define ID_LINKS                        32776
#define IDM_DUMMY                       32777
#define ID_DUMMY_ABOUT                  32778
#define ID_SHORTCUT                     32779
#define ID_ITEM_PROPERTIES              32781
#define ID_OPTIONS                      32782
#define ID_HELP_CONTENTS                32783
#define ID_CLOSE                        32784
#define ID_PASTE_DEFAULT                32785
#define IDS_DELETE_ITEM                 32786
#define IDS_DELETE_GROUP                32787
#define ID_MOVE_UP                      32788
#define ID_MOVE_DOWN                    32789
#define ID_MOVE_LEVEL                   32790
#define ID_ADD_GROUP                    32794
#define ID_DELETE_GROUP                 32795
#define ID_GROUP_PROPERTIES             32796
#define ID_TOOL_PROPERTIES              32797
#define ID_TOOL_ADD                     32798
#define ID_TOOL_DELETE                  32799
#define IDS_ALREADY_RUNNING             57346
#define IDS_BAD_FILE                    57347
#define IDS_BAD_PATH                    57348
#define IDS_BAD_APP                     57349
#define IDS_EXIT                        57350
#define IDS_VALID_DESCRIPTION           57351
#define IDS_TOO_MANY_SHORTCUTS          57352

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32800
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
