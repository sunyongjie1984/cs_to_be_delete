/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file implements the options dialog class.
*/

#include "stdafx.h"

#include "jumptoit.h"
#include "OptDlg.h"
#include "treeview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJTIOptDlg dialog

// Constructor
CJTIOptDlg::CJTIOptDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CJTIOptDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CJTIOptDlg)
	m_Monitor = FALSE;
	//}}AFX_DATA_INIT
}

// Field data exchange routine
void CJTIOptDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CJTIOptDlg)
	DDX_Control(pDX, IDC_GROUPS, m_Groups);
	DDX_Check(pDX, IDC_MONITOR, m_Monitor);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CJTIOptDlg, CDialog)
	//{{AFX_MSG_MAP(CJTIOptDlg)
	ON_BN_CLICKED(IDC_HELPBTN, OnHelpBtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJTIOptDlg message handlers

// Displays the tree when dialog is initialized
BOOL CJTIOptDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_pTree->DisplayTree(&m_Groups);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

// Handles OK button processing
void CJTIOptDlg::OnOK() 
{
	UpdateData(TRUE);

	CString strText;

	// Save the selected default group's name and number
	m_Groups.GetWindowText(strText);

	int nTab = strText.Find("\t",0);
	strText = strText.Mid(nTab+1);

	m_nDefGroup = atoi(strText);

	CDialog::OnOK();
}

void CJTIOptDlg::OnHelpBtn() 
{
	AfxGetApp()->WinHelp(102,HELP_CONTEXT);
}
