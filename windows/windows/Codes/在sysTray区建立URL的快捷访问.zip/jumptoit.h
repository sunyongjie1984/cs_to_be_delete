/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file defines the main application class.
*/

#if !defined(AFX_JUMPTOIT_H__203082E4_FF37_11D2_861D_00E02918D61A__INCLUDED_)
#define AFX_JUMPTOIT_H__203082E4_FF37_11D2_861D_00E02918D61A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CJTIApp:
// See jumptoit.cpp for the implementation of this class
//

typedef enum
{
	DRIVE	= 0x0001,
	PATH	= 0x0002,
	FNAME	= 0x0004,
	EXT		= 0x0008,
} SPLIT;


class CJTIApp : public CWinApp
{
protected:
	CZDTray m_Tray;
	BOOL m_bTrayAdded;

protected:
	BOOL AlreadyRunning();

public:
	CJTIApp();

// Operations
public:
	CString SplitFileName(LPCTSTR lpszPath, int nSplit);
	void RunApp(LPCTSTR lpszURL);


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJTIApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CJTIApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#define UM_TRAY	(WM_USER+1000)

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_JUMPTOIT_H__203082E4_FF37_11D2_861D_00E02918D61A__INCLUDED_)
