/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file implements main application class.
*/

#include "stdafx.h"

#include <io.h>

#include "jumptoit.h"

#include "MainFrm.h"
#include "Doc.h"
#include "TreeView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJTIApp

BEGIN_MESSAGE_MAP(CJTIApp, CWinApp)
	//{{AFX_MSG_MAP(CJTIApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
//	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJTIApp construction

// Constructor
CJTIApp::CJTIApp()
{
	m_bTrayAdded = FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CJTIApp object

CJTIApp theApp;


/////////////////////////////////////////////////////////////////////////////
// CJTIApp initialization

// Determine if JumpToIt is already running by using a Mutex object -- returns
// TRUE if already running, FALSE otherwise.  Note that a mutex is created
// with the name of the application
BOOL CJTIApp::AlreadyRunning()
{
	BOOL bFound = FALSE;

	// Try to create a mutex with the app's name
	HANDLE hMutexOneInstance = ::CreateMutex(NULL,TRUE,_T(AfxGetAppName()));

	// Already there...means that we are already running an instance
	if(::GetLastError() == ERROR_ALREADY_EXISTS)
		bFound = TRUE;

	// Release the mutex
	if(hMutexOneInstance)
		::ReleaseMutex(hMutexOneInstance);

	return(bFound);
}

// Initialize the instance of JumpToIt
BOOL CJTIApp::InitInstance()
{
	// Is it already running?
	if(AlreadyRunning())
	{
		// Yep...get out now
		AfxMessageBox(IDS_ALREADY_RUNNING,MB_ICONWARNING);
		return(FALSE);
	}

	// Initialize the COM layer
	OleInitialize(0);

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	char szTemp[MAX_PATH];

	// Setup the .ini file to use
	free((void*)m_pszProfileName);
	GetModuleFileName(NULL,szTemp,sizeof(szTemp));
	m_pszProfileName=_tcsdup(_T(SplitFileName(szTemp,DRIVE|PATH|FNAME)+".ini"));

	LoadStdProfileSettings(0);  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CJTIDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CJTITreeView));
	AddDocTemplate(pDocTemplate);

	// Enable DDE Execute open
	EnableShellOpen();
	RegisterShellFileTypes(TRUE);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// Setup the tray window
	m_Tray.SetNotifyWindow(m_pMainWnd->GetSafeHwnd(),UM_TRAY);
	m_Tray.Add(IDR_MAINFRAME,"JumpToIt");
	m_bTrayAdded = TRUE;

	BOOL bOpen = FALSE;

	// Was a link file specified?
	if(m_lpCmdLine[0] == '\0')   
	{
		// No...try to open the existing default links file
		if(access("links.jti",0) == 0)		
			OpenDocumentFile("links.jti");
		else
		{
			// There was no existing default links file so create a 
			// new one
			OnFileNew();

			CJTIDoc *pDoc = (CJTIDoc *) ((CMainFrame *) m_pMainWnd)->GetActiveDocument();
			pDoc->SetPathName("links.jti");

			bOpen = TRUE;
		}
	}
	else if(!stricmp(m_lpCmdLine,"-u") || !stricmp(m_lpCmdLine,"/u"))
	{
		// Clear JumpToIt's file association on an uninstall
		::RegDeleteKey(HKEY_CLASSES_ROOT,"JumpToIt.Document");
		::RegDeleteKey(HKEY_CLASSES_ROOT,".jti");

		return(FALSE);
	}
	else
	{
		// Open a file passed as the first command line parameter.
		OpenDocumentFile(m_lpCmdLine);
	}

	// Make sure the main window is hidden and updated
	m_pMainWnd->ShowWindow(SW_HIDE);
	m_pMainWnd->UpdateWindow();

	if(bOpen)
		m_pMainWnd->PostMessage(WM_COMMAND,ID_LINKS);

	// Set the last location of the main window
	CRect rc;

	rc.left = AfxGetApp()->GetProfileInt("Location","X",120);
	rc.top = AfxGetApp()->GetProfileInt("Location","Y",150);
	rc.right = AfxGetApp()->GetProfileInt("Location","CX",530);
	rc.bottom = AfxGetApp()->GetProfileInt("Location","CY",260);
	if(rc.left == 5000)
	{
		rc.left = 120;
		rc.top = 150;
		rc.right = 530;
		rc.bottom = 260;
	}

	m_pMainWnd->MoveWindow(rc.left,rc.top,rc.right,rc.bottom);

	return(TRUE);
}

// Handles instance exiting
int CJTIApp::ExitInstance() 
{
	// Remove JumpToIt's tray icon
	if(m_bTrayAdded)
		m_Tray.Delete(IDR_MAINFRAME);

	return CWinApp::ExitInstance();
}

/// About
CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CJTIApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

// Parses a filename into the specified parts and returns a CString that
// consists of the specified parts.
CString CJTIApp::SplitFileName(LPCTSTR lpszPath, int nSplit)
{
	CString strResult;

	char szPath[800],szDrive[800],szFileName[800],szExt[800];
	_splitpath(lpszPath,szDrive,szPath,szFileName,szExt);

	if(nSplit & DRIVE)
		strResult += szDrive;
	if(nSplit & PATH)
		strResult += szPath;
	if(nSplit & FNAME)
		strResult += szFileName;
	if(nSplit & EXT)
		strResult += szExt;

	return(strResult);
}

// Opens the specified application using the Windows shell execute 
// command.  NOTE: Filenames with embedded blanks must contain quote marks
// around the filename.  But the quotes SHOULD NOT include any paramaters.
void CJTIApp::RunApp(LPCTSTR lpszURL)
{
	CString strParams, strURL = lpszURL, strDir;

	if(strURL.Left(7).CompareNoCase("http://") != 0)
	{
		// Make sure filename isn't quoted before arguments
		int nStartQuote = strURL.Find("\"",0);
		int nEndQuote = 0;

		// Did we find a starting quote?
		if(nStartQuote >= 0)
		{
			// Yes...look for the ending quote
			nEndQuote = strURL.Find("\"",nStartQuote+1);
			if(nEndQuote)
			{
				// Seperate the URL and its parameters
				strParams = strURL.Mid(nEndQuote+1);
				strURL = strURL.Mid(nStartQuote+1,nEndQuote-1);
			}
		}
		else
		{
			int nBlank;

			// Look for a blank
			nBlank = strURL.Find(" ",0);

			// Find the ending blank
			if(nBlank > 0)
			{
				// Seperate the URL and its parameters
				strParams = strURL.Mid(nBlank+1);
				strURL = strURL.Left(nBlank);
			}
		}

		// Set the default directory location to be the same as the
		// file location
		strDir = ((CJTIApp *) AfxGetApp())->SplitFileName(strURL,DRIVE|PATH);
	}
	else strParams.Empty();

	// Run the program
	int nRet = (int) ShellExecute(NULL,"open",strURL,strParams,strDir,SW_SHOWNORMAL);

	// Did the execution fail?
	if(nRet <= 32)
	{
		int nID;

		// Yes...display an error
		if(nRet == ERROR_FILE_NOT_FOUND)
			nID = IDS_BAD_FILE;
		else if(nRet == ERROR_PATH_NOT_FOUND)
			nID = IDS_BAD_PATH;
		else nID = IDS_BAD_APP;

		AfxMessageBox(nID,MB_ICONWARNING);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CJTIApp message handlers



BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CenterWindow();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
