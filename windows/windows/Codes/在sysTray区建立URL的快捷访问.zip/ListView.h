/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file defines the list view class.
*/

#if !defined(AFX_LISTVIEW_H__203082EC_FF37_11D2_861D_00E02918D61A__INCLUDED_)
#define AFX_LISTVIEW_H__203082EC_FF37_11D2_861D_00E02918D61A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "doc.h"

class CJTIListView : public CListView
{
protected: // create from serialization only
	CJTIListView();
	DECLARE_DYNCREATE(CJTIListView)

protected:
	CImageList m_ImageList;
	CListCtrl *m_pList;
	int m_nActiveGroup;
	int m_nClipboardFormat;
	BOOL m_bMonitorClipboard;
	HWND m_hwndClipboard;
	BOOL m_bMonitoring;
	BOOL m_bCanPaste;
	BOOL m_bConfirm;
	int m_nDefGroup;
	int m_bAutoPaste;
	BOOL m_bDragging;
	HTREEITEM m_htreeDropItem;
	BOOL m_bCutMode;

protected:
	void SetClipboardMonitor();
	void ShowMenu(CPoint point);
	int GetSel();
	void DoSort();

	CString ResolveURL(LPCTSTR lpszItem);
	CString ResolveLnk(LPCTSTR lpszItem, CString& strDescription);


// Attributes
public:
	CJTIDoc* GetDocument();

// Operations
public:
	void LoadList(CArchive& ar);
	void SaveList(CArchive& ar, int *pMap);
	void ShowList(int nList);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJTIListView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CJTIListView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CJTIListView)
	afx_msg void OnDestroy();
	afx_msg void OnAddItem();
	afx_msg void OnItemProperties();
	afx_msg void OnUpdateItemProperties(CCmdUI* pCmdUI);
	afx_msg void OnDblClk(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRclick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnOpenItem();
	afx_msg void OnUpdateOpenItem(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDeleteItem(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAddItem(CCmdUI* pCmdUI);
	afx_msg void OnEditCopy();
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	afx_msg void OnEditCut();
	afx_msg void OnUpdateEditCut(CCmdUI* pCmdUI);
	afx_msg void OnEditPaste();
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	afx_msg void OnShortcut();
	afx_msg void OnUpdateShortcut(CCmdUI* pCmdUI);
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnDeleteItem();
	afx_msg void OnBeginDrag(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	afx_msg void OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpStyleStruct);
	afx_msg LRESULT OnGroupChanged(WPARAM wParam, LPARAM);
	afx_msg void OnChangeCbChain(HWND hWndRemove, HWND hWndAfter);
	afx_msg void OnDrawClipboard();

	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ListView.cpp
inline CJTIDoc* CJTIListView::GetDocument()
   { return (CJTIDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LISTVIEW_H__203082EC_FF37_11D2_861D_00E02918D61A__INCLUDED_)
