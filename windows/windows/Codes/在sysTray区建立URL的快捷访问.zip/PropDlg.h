/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file defines the link item property dialog class.
*/

#if !defined(AFX_PROPDLG_H__203082F8_FF37_11D2_861D_00E02918D61A__INCLUDED_)
#define AFX_PROPDLG_H__203082F8_FF37_11D2_861D_00E02918D61A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CJTIPropDlg dialog

class CJTIPropDlg : public CDialog
{
protected:
	CString m_strTitle;
	BOOL m_OrigMenu;
	
// Construction
public:
	CJTIPropDlg(CWnd* pParent = NULL);   // standard constructor

// Attributes
public:
	void SetTitle(LPCTSTR lpszTitle) { m_strTitle = lpszTitle; }

	void SetEntry(LPCTSTR lpszDescription, LPCTSTR lpszURL, BOOL bMenu, int nType)
	{
		m_Description = lpszDescription;
		m_URL = lpszURL;
		m_Menu = bMenu;
		m_Type = nType;
	}

	CString& GetDescription() { return m_Description; }
	CString& GetURL() { return m_URL; }
	BOOL GetMenuFlag() { return m_Menu; }
	int GetType() { return m_Type; }

// Dialog Data
	//{{AFX_DATA(CJTIPropDlg)
	enum { IDD = IDD_PROPERTIES };
	CString	m_Description;
	BOOL	m_Menu;
	CString	m_URL;
	int		m_Type;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJTIPropDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CJTIPropDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnHelpBtn();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPDLG_H__203082F8_FF37_11D2_861D_00E02918D61A__INCLUDED_)
