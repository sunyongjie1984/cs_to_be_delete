/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file defines the group properties dialog class.
*/

#if !defined(AFX_GRPPRDLG_H__47BA70E0_00C3_11D3_861D_00E02918D61A__INCLUDED_)
#define AFX_GRPPRDLG_H__47BA70E0_00C3_11D3_861D_00E02918D61A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GrpPrDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CJTIGrpPropDlg dialog

class CJTIGrpPropDlg : public CDialog
{
protected:
	CString m_strTitle;

// Construction
public:
	CJTIGrpPropDlg(CWnd* pParent = NULL);   // standard constructor

// Attributes
	void SetTitle(LPCTSTR lpszTitle) { m_strTitle = lpszTitle; }
	void SetDescription(LPCTSTR lpszDescription) { m_Description = lpszDescription; }
	CString& GetDescription() { return m_Description; }

// Dialog Data
	//{{AFX_DATA(CJTIGrpPropDlg)
	enum { IDD = IDD_GROUP_PROPERTIES };
	CString	m_Description;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJTIGrpPropDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CJTIGrpPropDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnHelpBtn();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GRPPRDLG_H__47BA70E0_00C3_11D3_861D_00E02918D61A__INCLUDED_)
