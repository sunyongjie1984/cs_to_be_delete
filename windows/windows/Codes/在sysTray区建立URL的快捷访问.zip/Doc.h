/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file defines the document data class.
*/

#if !defined(AFX_DOC_H__203082EA_FF37_11D2_861D_00E02918D61A__INCLUDED_)
#define AFX_DOC_H__203082EA_FF37_11D2_861D_00E02918D61A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// A particular group item
class CItem
{
public:
	CString strDescription;
	CString strURL;
	BYTE byType;

public:
	CItem() { byType = 0; }

	void Serialize(CArchive& ar)
	{
		if(ar.IsStoring())
		{
			BYTE byCount;

			byCount = strDescription.GetLength();
			ar.Write(&byCount,sizeof(byCount));
			ar.Write(strDescription,byCount);

			byCount = strURL.GetLength();
			ar.Write(&byCount,sizeof(byCount));
			ar.Write(strURL,byCount);

			ar.Write(&byType,sizeof(byType));
		}
		else
		{
			char szTemp[500];
			BYTE byCount;

			ar.Read(&byCount,sizeof(byCount));
			ar.Read(szTemp,byCount);
			szTemp[byCount] = 0;
			strDescription = szTemp;

			ar.Read(&byCount,sizeof(byCount));
			ar.Read(szTemp,byCount);
			szTemp[byCount] = 0;
			strURL = szTemp;

			ar.Read(&byType,sizeof(byType));
		}
	}
};

typedef CArray<CItem,CItem&> ITEMS;

// Each group's item
class CGroup
{
public:
	ITEMS arrItems;
	BYTE byCount;

public:
	CGroup() { arrItems.SetSize(0); byCount = 0; }
	CGroup& operator=(const CGroup &g)
    { 
		arrItems.SetSize(0);
		byCount = 0;
		for(int i = 0; i < g.arrItems.GetSize(); i++)
		{
			arrItems.Add(g.arrItems.GetAt(i)); 
			byCount++;
		}
		return *this; 
	}	

	void Serialize(CArchive& ar)
	{
		BYTE byItemCount;

		if(ar.IsStoring())
		{
			BYTE i;

			// Get the total item count by looking for non-blank
			// descriptions (i.e. descriptions not deleted)
			byItemCount = 0;
			for(i = 0; i < arrItems.GetSize(); i++)
			{
				CItem &item = arrItems[i];
				if(!item.strDescription.IsEmpty())
					byItemCount++;
			}

			// Write the item count
			ar.Write(&byItemCount,sizeof(byItemCount));

			// Iterate through each group item
			for(i = 0; i < arrItems.GetSize(); i++)
			{
				CItem &item = arrItems[i];
				if(!item.strDescription.IsEmpty())
					item.Serialize(ar);
			}
		}
		else
		{
			// Get and set the group's item count
			ar.Read(&byItemCount,sizeof(byItemCount));
			byCount = byItemCount;

			// Iterate through each group item
			arrItems.SetSize(0);
			for(BYTE i = 0; i < byItemCount; i++)
			{
				CItem Item;

				Item.Serialize(ar);
				arrItems.Add(Item);
			}
		}
	}
};

typedef CArray<CGroup,CGroup&> GROUPS;

class CJTIDoc : public CDocument
{
protected: // create from serialization only
	CJTIDoc();
	DECLARE_DYNCREATE(CJTIDoc)

protected:
	GROUPS m_arrGroups;
	BOOL m_bMonitorMode;
	int m_nDefGroup;


// Attributes
public:
	GROUPS& GetGroups() { return m_arrGroups; }
	int GetDefGroup() { return m_nDefGroup; }
	void SetDefGroup(int nDefGroup) { m_nDefGroup = nDefGroup; }
	BOOL GetMonitorMode() { return m_bMonitorMode; }
	void SetMonitorMode(BOOL bMonitorMode) { m_bMonitorMode = bMonitorMode; }

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJTIDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL SaveModified();
	virtual void OnCloseDocument();
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CJTIDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CJTIDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DOC_H__203082EA_FF37_11D2_861D_00E02918D61A__INCLUDED_)
