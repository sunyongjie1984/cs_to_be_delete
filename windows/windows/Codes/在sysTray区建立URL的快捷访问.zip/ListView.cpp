/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file implements the link list view.
*/

#include "stdafx.h"

#include <intshcut.h>

#include "jumptoit.h"

#include "mainfrm.h"
#include "Doc.h"
#include "ListView.h"
#include "propdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJTIListView

IMPLEMENT_DYNCREATE(CJTIListView, CListView)

BEGIN_MESSAGE_MAP(CJTIListView, CListView)
	//{{AFX_MSG_MAP(CJTIListView)
	ON_WM_DESTROY()
	ON_COMMAND(ID_ADD_ITEM, OnAddItem)
	ON_COMMAND(ID_DELETE_ITEM, OnDeleteItem)
	ON_COMMAND(ID_ITEM_PROPERTIES, OnItemProperties)
	ON_UPDATE_COMMAND_UI(ID_ADD_ITEM, OnUpdateAddItem)
	ON_UPDATE_COMMAND_UI(ID_DELETE_ITEM, OnUpdateDeleteItem)
	ON_UPDATE_COMMAND_UI(ID_ITEM_PROPERTIES, OnUpdateItemProperties)
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDblClk)
	ON_NOTIFY_REFLECT(NM_RCLICK, OnRclick)
	ON_COMMAND(ID_OPEN_ITEM, OnOpenItem)
	ON_UPDATE_COMMAND_UI(ID_OPEN_ITEM, OnUpdateOpenItem)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCut)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
	ON_COMMAND(ID_SHORTCUT, OnShortcut)
	ON_UPDATE_COMMAND_UI(ID_SHORTCUT, OnUpdateShortcut)
	ON_WM_DROPFILES()
	ON_NOTIFY_REFLECT(LVN_BEGINDRAG, OnBeginDrag)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
	ON_MESSAGE(UM_GROUP_CHANGED,OnGroupChanged)
	ON_WM_CHANGECBCHAIN()
	ON_WM_DRAWCLIPBOARD()
	ON_COMMAND(ID_TOOL_ADD, OnAddItem)
	ON_COMMAND(ID_TOOL_DELETE, OnDeleteItem)
	ON_COMMAND(ID_TOOL_PROPERTIES, OnItemProperties)
	ON_UPDATE_COMMAND_UI(ID_TOOL_ADD, OnUpdateAddItem)
	ON_UPDATE_COMMAND_UI(ID_TOOL_DELETE, OnUpdateDeleteItem)
	ON_UPDATE_COMMAND_UI(ID_TOOL_PROPERTIES, OnUpdateItemProperties)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJTIListView construction/destruction

// Constructor
CJTIListView::CJTIListView()
{
	CListCtrl& list = GetListCtrl();
	m_pList = &list;

	// Initialize the clipboard flags and drag/drop flags
	m_nActiveGroup = 0;
	m_nClipboardFormat = ::RegisterClipboardFormat("JumpToIt");
	m_hwndClipboard = NULL;
	m_bMonitoring = FALSE;
	m_bCanPaste = FALSE;
	m_bAutoPaste = FALSE;
	m_bDragging = FALSE;
	m_bCutMode = FALSE;
	m_bConfirm = TRUE;
}

// Destructor
CJTIListView::~CJTIListView()
{
}

// Called when window is created
BOOL CJTIListView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CListView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CJTIListView drawing

// Called to draw window background
void CJTIListView::OnDraw(CDC* pDC)
{
	CJTIDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
}

// Called when window is initialized
void CJTIListView::OnInitialUpdate()
{
	static bFirstTime = TRUE;

	CListView::OnInitialUpdate();

	// Set up the list control the first time the view is created
	if(bFirstTime)
	{
		// Change the style; window will repaint automatically
		DWORD dwStyle = AfxGetApp()->GetProfileInt("List","Style",LVS_REPORT);
		ModifyStyle(LVS_TYPEMASK,dwStyle);

		// Is the list a report-style list?
		if(dwStyle & LVS_REPORT)
		{
			// Yes...make sure we don't have a column header
			ModifyStyle(0,LVS_NOCOLUMNHEADER);
		}

		// Create the image list
		m_ImageList.Create(IDB_LIST,16,1,RGB(255,0,255));

		// Make sure the list always shows a selection
		m_pList->ModifyStyle(0,LVS_SHOWSELALWAYS);

		// Setup one column
		m_pList->DeleteColumn(0);
		m_pList->InsertColumn(0,"",LVCFMT_LEFT,800);

		// Tell Windows that the list can accept dropped files
		DragAcceptFiles(TRUE);

		// Setup clipboard monitoring
		SetClipboardMonitor();

		// Reset flag so we won't execute this code again
		bFirstTime = FALSE;
	}

	// Set the normal and small image list
	m_pList->SetImageList(&m_ImageList,LVSIL_NORMAL);
	m_pList->SetImageList(&m_ImageList,LVSIL_SMALL);
}

/////////////////////////////////////////////////////////////////////////////
// CJTIListView diagnostics

#ifdef _DEBUG
void CJTIListView::AssertValid() const
{
	CListView::AssertValid();
}

void CJTIListView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

CJTIDoc* CJTIListView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CJTIDoc)));
	return (CJTIDoc*)m_pDocument;
}
#endif //_DEBUG


// Comparsion function that's used to sort list items.  This routine receives
// the lParam value of each list item which it then uses to retrieve the 
// appropriate item and compare its description text.
static int CALLBACK CompareFunc(LPARAM lParam1, LPARAM lParam2, 
   LPARAM lParamSort)
{
	ITEMS *pItems= (ITEMS *) lParamSort;
	CItem& item1 = pItems->GetAt(lParam1);
	CItem& item2 = pItems->GetAt(lParam2);

	// Return the results of the description comparision
	return(stricmp(item1.strDescription,item2.strDescription));
}

// Performs the sort operation after getting the proper group pointer
void CJTIListView::DoSort()
{
	GROUPS& arrGroups = GetDocument()->GetGroups();

	m_pList->SortItems(CompareFunc,(LPARAM) &arrGroups[m_nActiveGroup].arrItems);
}

/////////////////////////////////////////////////////////////////////////////
// CJTIListView message handlers

// Called when the list style changes
void CJTIListView::OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpStyleStruct)
{
}

// Called when the view is being destroyed
void CJTIListView::OnDestroy() 
{
	CRect rc;

	// Save the window location
	GetParentFrame()->GetWindowRect(&rc);
	AfxGetApp()->WriteProfileInt("Location","X",rc.left);
	AfxGetApp()->WriteProfileInt("Location","Y",rc.top);
	AfxGetApp()->WriteProfileInt("Location","CX",rc.Width());
	AfxGetApp()->WriteProfileInt("Location","CY",rc.Height());

	// Save the list style
	DWORD dwStyle = (GetStyle() & LVS_TYPEMASK);
	AfxGetApp()->WriteProfileInt("List","Style",dwStyle);

	CListView::OnDestroy();

	// Stop clipboard monitoring (do this last so the clipboard change method
	// won't get called in the process)
	if(m_hwndClipboard)
		ChangeClipboardChain(m_hwndClipboard);
}

// Called to add a link item to the group
void CJTIListView::OnAddItem() 
{
	CJTIPropDlg dlgProp;

	// Set proper title for the dialog
	dlgProp.SetTitle("Add");

	// Display the dialog
	if(dlgProp.DoModal() == IDOK)
	{
		GROUPS& arrGroups = GetDocument()->GetGroups();
		CItem item;

		// Retrieve the user's selections and add an item
		item.strDescription = dlgProp.GetDescription();
		item.strURL = dlgProp.GetURL();
		item.byType = dlgProp.GetType()+(dlgProp.GetMenuFlag()?2:0);
		arrGroups[m_nActiveGroup].arrItems.Add(item);

		// Redisplay the list with the new item added
		ShowList(m_nActiveGroup);
		GetDocument()->SetModifiedFlag(TRUE);
		GetDocument()->SaveModified();
	}
}

// Handles enabling of Add links menu item
void CJTIListView::OnUpdateAddItem(CCmdUI* pCmdUI) 
{
	// Can only add when a group is selected
	pCmdUI->Enable(m_nActiveGroup > 0);
}

// Called to delete the selected items
void CJTIListView::OnDeleteItem() 
{
	// Confirm the user's choice
	if(!m_bConfirm || AfxMessageBox(IDS_DELETE_ITEM,MB_ICONQUESTION|MB_YESNOCANCEL) == IDYES)
	{
		int nSelCount = m_pList->GetSelectedCount();

		// Iterate through the list items
		for(int i = m_pList->GetItemCount()-1; nSelCount && i >= 0 ; i--)
		{
			GROUPS& arrGroups = GetDocument()->GetGroups();

			// Is this item selected?
			if(m_pList->GetItemState(i,LVIS_SELECTED))
			{
				// Yep...zap it
				int nItem = m_pList->GetItemData(i);
				CItem& item = arrGroups[m_nActiveGroup].arrItems.GetAt(nItem);

				item.strDescription.Empty();
				arrGroups[m_nActiveGroup].arrItems.SetAt(nItem,item);

				m_pList->DeleteItem(i);
				nSelCount--;
			}
		}

		// Redisplay the list to show the changes
		ShowList(m_nActiveGroup);
		GetDocument()->SetModifiedFlag(TRUE);
		GetDocument()->SaveModified();
	}

	m_bConfirm = TRUE;
}

// Handles enabling delete menu item
void CJTIListView::OnUpdateDeleteItem(CCmdUI* pCmdUI) 
{
	// Must be at least one selected item
	pCmdUI->Enable(m_pList->GetSelectedCount() > 0);
}

// Returns the selected item from the list
int CJTIListView::GetSel()
{
	int nRow = -1;

	// Iterate through the list 
	for(int i = 0; i < m_pList->GetItemCount(); i++)
	{
		// Is the current item selected?
		if(m_pList->GetItemState(i,LVIS_SELECTED))
		{
			// Yep...get out
			nRow = i;
			break;
		}
	}

	return(nRow);
}

// Called to modify the properties of the selected item
void CJTIListView::OnItemProperties() 
{
	GROUPS& arrGroups = GetDocument()->GetGroups();
	int nItem = m_pList->GetItemData(GetSel());
	CItem& item = arrGroups[m_nActiveGroup].arrItems.GetAt(nItem);
	CJTIPropDlg dlgProp;
	BYTE byType;
	BOOL bMenu;

	// Get the item's type -- 0 = Web, 1 = File, 2 = Web shortcut, 3 = File shortcut
	bMenu = (item.byType >= 2);
	byType = item.byType;
	if(byType >= 2)
		byType -= 2;

	// Set the property screen fields
	dlgProp.SetEntry(item.strDescription,item.strURL,bMenu,byType);

	// Display the dialog
	if(dlgProp.DoModal() == IDOK)
	{
		// Get the user's changes and save them to the link list
		item.strDescription = dlgProp.GetDescription();
		item.strURL = dlgProp.GetURL();
		item.byType = dlgProp.GetType()+(dlgProp.GetMenuFlag()?2:0);
		arrGroups[m_nActiveGroup].arrItems.SetAt(nItem,item);

		// Set the list item's data
		m_pList->SetItem(GetSel(),0,LVIF_TEXT|LVIF_IMAGE,
							item.strDescription,
							item.byType,0,0,0);

		// Redisplay the list to show the changes
		ShowList(m_nActiveGroup);
		GetDocument()->SetModifiedFlag(TRUE);
		GetDocument()->SaveModified();
	}
}

// Handles enabling the Item properties menu item
void CJTIListView::OnUpdateItemProperties(CCmdUI* pCmdUI) 
{
	// There can only be one item selected
	pCmdUI->Enable(m_pList->GetSelectedCount() == 1);
}

// Handles double-click -- treats it the same as opening (running) an item
void CJTIListView::OnDblClk(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// There must be only one selected item
	if(m_pList->GetSelectedCount() == 1)
		OnOpenItem();

	*pResult = 0;
}

// Displays the link list context menu
void CJTIListView::ShowMenu(CPoint point) 
{
	CMenu menu;
	int nSel = GetSel();
	GROUPS& arrGroups = GetDocument()->GetGroups();

	// Load the menu
	menu.LoadMenu(IDR_LISTMENU);
	CMenu *pPopup = menu.GetSubMenu(0);

	// do we have a valid selection?
	if(nSel >= 0)
	{
		int nItem = m_pList->GetItemData(GetSel());
		CItem& item = arrGroups[m_nActiveGroup].arrItems.GetAt(nItem);

		if(item.byType >= 2)
			pPopup->CheckMenuItem(ID_SHORTCUT,MF_BYCOMMAND|MF_CHECKED);
	}

	// Display the menu
	SetFocus();
	pPopup->TrackPopupMenu(TPM_LEFTALIGN|TPM_LEFTBUTTON|TPM_RIGHTBUTTON,
							point.x,point.y,GetParentFrame(),NULL);
}

// Handles the right-click button -- displays the context menu
void CJTIListView::OnRclick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CPoint pt;

	GetCursorPos(&pt);
	ShowMenu(pt);
	
	*pResult = 0;
}

// Handles opening (running) an item
void CJTIListView::OnOpenItem() 
{
	GROUPS& arrGroups = GetDocument()->GetGroups();
	int nItem = m_pList->GetItemData(GetSel());
	CItem& item = arrGroups[m_nActiveGroup].arrItems.GetAt(nItem);

	// Run the selected item
	((CJTIApp *) AfxGetApp())->RunApp(item.strURL);
}

// Handles enabling the Open menu item
void CJTIListView::OnUpdateOpenItem(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_pList->GetSelectedCount() == 1);
}

// Loads the link list for the current group
void CJTIListView::LoadList(CArchive& ar)
{
	GROUPS& arrGroups = GetDocument()->GetGroups();

	// Load each group's items
	for(int i = 0; i < arrGroups.GetSize(); i++)
		arrGroups[i].Serialize(ar);
}

// Saves the list to the specified archive object.  Also takes into account
// that the order of groups could have changed in the group tree by using
// the pMap array provided.
void CJTIListView::SaveList(CArchive& ar, int *pMap)
{
	GROUPS& arrGroups = GetDocument()->GetGroups();

	// Save each group's items
	for(int i = 0; i < arrGroups.GetSize(); i++)
	{
		int nEntry = pMap[i];

		if(nEntry >= 0)
			arrGroups[nEntry].Serialize(ar);
	}
}

// Clears the link list and redisplays it
void CJTIListView::ShowList(int nList)
{
	GROUPS& arrGroups = GetDocument()->GetGroups();

	m_nActiveGroup = nList;

	// Clear the list
	m_pList->DeleteAllItems();

	// Iterate through the specified group's items
	for(int i = 0; i < arrGroups[nList].arrItems.GetSize(); i++)
	{
		CItem& item = arrGroups[nList].arrItems.GetAt(i);

		// Add the group item
		if(!item.strDescription.IsEmpty())
			m_pList->InsertItem(LVIF_TEXT|LVIF_IMAGE|LVIF_PARAM,
								i,item.strDescription,
								0,0,item.byType,i);
	}

	// Sort the data
	DoSort();
}

// Called when the group selection changes in the group tree
LRESULT CJTIListView::OnGroupChanged(WPARAM wParam, LPARAM)
{
	// Display the list
	ShowList(wParam);

	return(0);
}

// Handles the clipboard copy operation by copying data from the selected items
// to the clipboard in a custom format.
void CJTIListView::OnEditCopy() 
{
	GROUPS& arrGroups = GetDocument()->GetGroups();
	CSharedFile mf(GMEM_ZEROINIT|GMEM_MOVEABLE|GMEM_DDESHARE);
	CArchive ar(&mf,CArchive::store);
	int nOperation = (m_bCutMode?ID_EDIT_CUT:ID_EDIT_COPY);
	HGLOBAL hMem;
	int nSelCount = m_pList->GetSelectedCount();

	// Write the operation we're performing	so we'll know how to treat
	// pasted data
	ar.Write(&nOperation,sizeof(nOperation));

	// Write the total number of items
	ar.Write(&nSelCount,sizeof(nSelCount));

	// Iterate through the list of links
	for(int i = 0; nSelCount && i < m_pList->GetItemCount(); i++)
	{
		// Serialize each selected item
		if(m_pList->GetItemState(i,LVIS_SELECTED))
		{
			int nItem = m_pList->GetItemData(i);
			CItem& item = arrGroups[m_nActiveGroup].arrItems.GetAt(nItem);

			// Save the item's data
			item.Serialize(ar);

			nSelCount--;
		}
	}

	// Close the archive object
	ar.Close();

	// Get a memory handle to the archive object
	hMem = mf.Detach();

	// Place the data on the clipboard
	OpenClipboard();
	EmptyClipboard();
	SetClipboardData(m_nClipboardFormat,hMem);
	CloseClipboard();

	m_bCutMode = FALSE;
}

// Handles enabling the copy menu item
void CJTIListView::OnUpdateEditCopy(CCmdUI* pCmdUI) 
{
	// There must be at least one selected item
	pCmdUI->Enable(m_pList->GetSelectedCount() > 0);
}

// Handles the Cut clipboard operation
void CJTIListView::OnEditCut() 
{
	m_bCutMode = TRUE;

	// Copy the selected items to the clipboard
	OnEditCopy();

	// Remove the selected items from the list
	m_bConfirm = FALSE;
	OnDeleteItem();

	// Make sure document is updated
	GetDocument()->SetModifiedFlag(TRUE);
	GetDocument()->SaveModified();
}

// Handles enabling the Cut menu item
void CJTIListView::OnUpdateEditCut(CCmdUI* pCmdUI) 
{
	// There must be at least one selected item
	pCmdUI->Enable(m_pList->GetSelectedCount() > 0);
}

// Handles the paste clipboard operation.  Allows pasting of both text URLS and
// custom data placed on the clipboard by JumpToIt.
void CJTIListView::OnEditPaste() 
{
	HGLOBAL hMem;
	GROUPS& arrGroups = GetDocument()->GetGroups();

	int nDefGroup = 0;

	// Is this an auto-paste operation?  If so get the default paste group
	if(m_bAutoPaste && !m_bDragging)
		nDefGroup = GetDocument()->GetDefGroup();

	// No group specified so use the active group
	if(nDefGroup == 0)
		nDefGroup = m_nActiveGroup;

	// Open the clipboard
	OpenClipboard();

	// Try to get data in JumpToIt's custom format first
	hMem = ::GetClipboardData(m_nClipboardFormat);

	// Was there some available?
	if(hMem)
	{
		CSharedFile mf;
		mf.SetHandle(hMem);
		CArchive ar(&mf,CArchive::load);
		int nSelCount, nOperation;

		// Get the operation
		ar.Read(&nOperation,sizeof(nOperation));

		// Get the total item count
		ar.Read(&nSelCount,sizeof(nSelCount));

		// Iterate through each item
		for(int i = 0; i < nSelCount; i++)
		{
			CItem item;

			item.Serialize(ar);

			// Don't allow menu shortcuts to be copied.  This prevents us
			// from having more than the maximum allowed
			if(nOperation == ID_EDIT_COPY && item.byType >= 2)
				item.byType -= 2;

			// Add the item to the specified group
			arrGroups[nDefGroup].arrItems.Add(item);
			arrGroups[nDefGroup].byCount++;
		}

		// Close the archive object and release the data
		ar.Close();
		mf.Detach();
	}
	else if(hMem = ::GetClipboardData(CF_TEXT))
	{
		LPTSTR lpszText = (LPTSTR) GlobalLock(hMem);
		CString strURL = lpszText;

		// Look for text URLs
		strURL = strURL.SpanExcluding("\r\n");

		// Make sure this is a valid URL
		if(strURL.Left(7).CompareNoCase("http://") == 0 ||
			strURL.Left(6).CompareNoCase("ftp://") == 0 ||
			strURL.Left(7).CompareNoCase("file://") == 0)
		{
			CItem item;

			// Get the description/URL
			item.strDescription = strURL;
			item.strURL = strURL;
			item.byType = (strURL.Left(7).CompareNoCase("http://")?1:0);

			// Add the new item to the specified group
			arrGroups[nDefGroup].arrItems.Add(item);
			arrGroups[nDefGroup].byCount++;
		}

		GlobalUnlock(hMem);
	}
	else if(hMem = ::GetClipboardData(::RegisterClipboardFormat("Filename")))
	{
		LPTSTR lpszText = (LPTSTR) GlobalLock(hMem);
		CString strURL = lpszText, strDescription;

		// Determine if this is a URL
		strURL = ResolveURL(lpszText);

		if(!strURL.IsEmpty())
		{
			char szTemp[_MAX_PATH+1];
			WIN32_FIND_DATA ff;

			// Try to get the long filename for the shortcut
			HANDLE hFile = FindFirstFile(lpszText,&ff);

			if(hFile)
			{
				// It worked...copy the filename
				strcpy(szTemp,ff.cFileName);
				FindClose(hFile);
			}
			else strcpy(szTemp,lpszText); 

			strDescription = ((CJTIApp *) AfxGetApp())->SplitFileName(szTemp,FNAME);


			// Add the new item to the list
			GROUPS& arrGroups = GetDocument()->GetGroups();
			CItem item;

			item.strDescription = strDescription;
			item.strURL = strURL;
			item.byType = 0;
			arrGroups[m_nActiveGroup].arrItems.Add(item);

			ShowList(m_nActiveGroup);
		}

		GlobalUnlock(hMem);
	}

	// Close the clipboard
	CloseClipboard();

	// Show the updated list
	if(!m_bAutoPaste)
		ShowList(m_nActiveGroup);

	// Make sure document is updated
	GetDocument()->SetModifiedFlag(TRUE);
	GetDocument()->SaveModified();

	m_bAutoPaste = FALSE;
}

// Handles enabling the Paste menu item
void CJTIListView::OnUpdateEditPaste(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_bCanPaste && m_nActiveGroup > 0);
}

// Handles the Menu Shortcut menu item on JumpToIt's context menu
void CJTIListView::OnShortcut() 
{
	GROUPS& arrGroups = GetDocument()->GetGroups();
	int nItem = m_pList->GetItemData(GetSel());
	CItem& item = arrGroups[m_nActiveGroup].arrItems.GetAt(nItem);

	// Was this item not previously a shortcut?
	if(item.byType < 2)
	{
		// That's correct, so make sure that adding it doesn't result
		// in too many shortcuts
		if(!((CMainFrame *) GetParentFrame())->CanAddShortcut())
		{
			AfxMessageBox(IDS_TOO_MANY_SHORTCUTS,MB_ICONWARNING|MB_OK);
			return;
		}

		// Make it a shortcut item
		item.byType += 2;
	}
	else item.byType -= 2;

	// Set the item's data
	arrGroups[m_nActiveGroup].arrItems.SetAt(nItem,item);
	m_pList->SetItem(GetSel(),0,LVIF_IMAGE,NULL,item.byType,0,0,0);

	// Make sure the document gets saved
	GetDocument()->SetModifiedFlag(TRUE);
	GetDocument()->SaveModified();
}

// Handles enabling the Menu Shortcut menu item
void CJTIListView::OnUpdateShortcut(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_pList->GetSelectedCount() == 1);
}

// Resolves a dropped URL shortcut
CString CJTIListView::ResolveURL(LPCTSTR lpszItem)
{
	CString strURL;
	IUniformResourceLocator *pIURL = NULL;
	IPersistFile *pIPF = NULL;
	WORD szWide[MAX_PATH];
	HRESULT hResult;
	LPSTR pszURL = NULL;

	// Instantiate a URL object
	hResult = ::CoCreateInstance(CLSID_InternetShortcut,
		NULL,CLSCTX_INPROC_SERVER,IID_IUniformResourceLocator,
					(void **) &pIURL);

	if(SUCCEEDED(hResult))
	{
		// Get pointer to the object's IPersistFile interface.
		hResult = pIURL->QueryInterface(IID_IPersistFile,(void **) &pIPF);
		if(!SUCCEEDED(hResult))
			pIURL->Release();
	}

	// Are both items valid?
	if(pIPF && pIURL)
	{
		MultiByteToWideChar(CP_ACP,0,lpszItem,-1,szWide,_MAX_PATH);

		if(pIPF->Load(szWide,STGM_READ) == S_OK)
		{
			if(pIURL->GetURL(&pszURL) == S_OK)
			{
				// Save the URL for return
				strURL = pszURL;

				// Free the URL's work buffer
				IMalloc* pMalloc;        
				hResult = SHGetMalloc(&pMalloc); 

				if(SUCCEEDED(hResult))
				{
					pMalloc->Free(pszURL);
					pMalloc->Release();
				}
			}
		}
	}

	if(pIPF)
		pIPF->Release();

	if(pIURL)
		pIURL->Release();

	return(strURL);
}

// Resolves a dropped shortcut link
CString CJTIListView::ResolveLnk(LPCTSTR lpszItem, CString& strDescription)
{
	CString strURL;
	IShellLink *pISL = NULL;
	IPersistFile *pIPF = NULL;
	WORD szWide[MAX_PATH];
	HRESULT hResult;

	// Instantiate a shortcut object
	hResult = CoCreateInstance (CLSID_ShellLink,NULL,CLSCTX_INPROC_SERVER,
						IID_IShellLink,(void **)&pISL);

	if(SUCCEEDED(hResult))
	{
		// Get pointer to the object's IPersistFile interface.
		hResult = pISL->QueryInterface(IID_IPersistFile,(void **)&pIPF);

		if(!SUCCEEDED(hResult))
			pISL->Release();
	}

	// Are both items valid?
	if(pIPF && SUCCEEDED(hResult))
	{
		if(SUCCEEDED(hResult))
		{
			MultiByteToWideChar(CP_ACP,0,lpszItem,-1,szWide,_MAX_PATH);

			// Load the shortcut.
			if(pIPF->Load(szWide,STGM_READ) == S_OK)
			{
				// Get the shortcut information
				hResult = pISL->Resolve(AfxGetMainWnd()->GetSafeHwnd(),SLR_ANY_MATCH);

				if(SUCCEEDED (hResult))
				{
					WIN32_FIND_DATA wfd;
					char szTemp[MAX_PATH];

					// Get the path
					hResult = pISL->GetPath(szTemp,MAX_PATH,(WIN32_FIND_DATA *)&wfd,SLGP_SHORTPATH);
					strURL = lpszItem;
					if(SUCCEEDED(hResult))
						strURL = szTemp;

					// Get the arguments
					hResult = pISL->GetArguments(szTemp,MAX_PATH);
					if(SUCCEEDED(hResult))
						strURL += CString(" ")+szTemp;

					// Get the description
					hResult = pISL->GetDescription(szTemp,MAX_PATH);
					if(SUCCEEDED(hResult))
						strDescription = szTemp;
				}
			}
		}
	}

	if(pIPF)
		pIPF->Release();

	if(pISL)
		pISL->Release();

	return(strURL);
}

// Handles files dropped by another window
void CJTIListView::OnDropFiles(HDROP hDropInfo) 
{
	int nEntries = DragQueryFile(hDropInfo,-1,NULL,0);
	CString strURL;
	CString strFileList; 
	CString strDescription;

	// Can't drop into group title
	if(m_nActiveGroup <= 0)
	{
		::MessageBeep(0);
		return;
	}

	for(int i = 0 ; i < nEntries; i++) 
	{
		// Get the size of the item
		int nSize = DragQueryFile(hDropInfo,i,NULL,0);
		BYTE byType = 0;

		// Allocate memory to contain the item
		LPTSTR lpszItem = (LPTSTR) LocalAlloc(LPTR,nSize+1);

		// Is this a valid item?
		if(lpszItem)
		{
			// Get the item's information
			DragQueryFile(hDropInfo,i,lpszItem,nSize+1);

			// Determine if this is a URL
			strURL = ResolveURL(lpszItem);

			if(!strURL.IsEmpty())
				strDescription = ((CJTIApp *) AfxGetApp())->SplitFileName(lpszItem,FNAME);
			else
			{				
				strURL = ResolveLnk(lpszItem,strDescription);
				if(strDescription.IsEmpty())
					strDescription = ((CJTIApp *) AfxGetApp())->SplitFileName(strURL,FNAME);
				byType = 1;
			}

			// Is it valid?
			if(!strURL.IsEmpty())
			{
				// Add the new item to the list
				GROUPS& arrGroups = GetDocument()->GetGroups();
				CItem item;

				item.strDescription = strDescription;
				item.strURL = strURL;
				item.byType = byType;
				arrGroups[m_nActiveGroup].arrItems.Add(item);

				ShowList(m_nActiveGroup);
			}

			// Free the local buffer now
			LocalFree(lpszItem);
		}
	}

	// Free the memory block containing the dropped-file information
	DragFinish(hDropInfo);
}

// Called when clipboard contents change
void CJTIListView::OnDrawClipboard() 
{
	CListView::OnDrawClipboard();

	static BOOL bFirstTime = TRUE;

	if(bFirstTime == TRUE)
	{
		bFirstTime = FALSE;
		return;
	}

	// Check the types of clipboard data available
	unsigned int nExplorer = ::RegisterClipboardFormat("Filename");
	unsigned int anFormats[] = {m_nClipboardFormat,CF_TEXT,nExplorer};
	unsigned int nFormat = GetPriorityClipboardFormat(anFormats,sizeof(anFormats));
	m_bCanPaste = FALSE;

	// Text data?
	if(nFormat == CF_TEXT)
	{
		HGLOBAL hMem;

		OpenClipboard();

		// Yes...check to see if the data is a valid URL
		if(hMem = ::GetClipboardData(CF_TEXT))
		{
			LPTSTR lpszText = (LPTSTR) GlobalLock(hMem);
			CString strURL = lpszText;

			strURL = strURL.SpanExcluding("\r\n");

			// Valid URL?
			if(strURL.Left(7).CompareNoCase("http://") == 0 ||
				strURL.Left(6).CompareNoCase("ftp://") == 0 ||
				strURL.Left(7).CompareNoCase("file://") == 0)
			{
				// Yes...set the paste enable flag
				m_bCanPaste = TRUE;
			}

			GlobalUnlock(hMem);
		}

		CloseClipboard();
	}
	else if(nFormat == (unsigned int) m_nClipboardFormat)
		m_bCanPaste = TRUE;
	else if(nFormat == nExplorer)
		m_bCanPaste = TRUE;

	CWnd *pOwner = GetClipboardOwner();
	DWORD dwCurrPID, dwOwnerPID;

	// Make sure that JumpToIt's edit control didn't place this
	// item on the clipboard.  This prevents auto-pasting of something that
	// the user manually copied
	if(pOwner)
	{	
		// Get process ids of this task and clipboard task
		GetWindowThreadProcessId(GetSafeHwnd(),&dwCurrPID);
		GetWindowThreadProcessId(pOwner->GetSafeHwnd(),&dwOwnerPID);

		// Came from this task so get out
		if(dwCurrPID == dwOwnerPID)
			return;
	}

	// Are we monitoring the clipboard?
	if(GetDocument()->GetMonitorMode())
	{
		m_bAutoPaste = TRUE;
		OnEditPaste();

		// Add the data an refresh the list
		ShowList(m_nActiveGroup);
	}
}

// Clipboard contents changed...
void CJTIListView::OnChangeCbChain(HWND hWndRemove, HWND hWndAfter) 
{
	CView::OnChangeCbChain(hWndRemove,hWndAfter);

	if(hWndRemove == m_hwndClipboard)
		m_hwndClipboard = hWndAfter;
}

// Install a monitor for the clipboard
void CJTIListView::SetClipboardMonitor()
{
	// Make sure we get notified when the clipboard contents 
	if(!m_bMonitoring)
	{
		m_hwndClipboard = SetClipboardViewer();
		m_bMonitoring = TRUE;
	}
	else
	{
		if(m_hwndClipboard && m_bMonitoring)
			ChangeClipboardChain(m_hwndClipboard);
		m_hwndClipboard = NULL;		
		m_bMonitoring = FALSE;
	}
}

// Handles keyboard support first list -- delete key to remove entries,
// insert key to add entries.
BOOL CJTIListView::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->message == WM_KEYUP)
	{
		switch(pMsg->wParam)
		{
			// Add an entry
			case VK_INSERT:
				OnAddItem();
				return(TRUE);

			// Delete an entry
			case VK_DELETE:
				// Anything selected?
				if(m_pList->GetSelectedCount() > 0)
					OnDeleteItem();
				return(TRUE);
		}
	}
	
	return CListView::PreTranslateMessage(pMsg);
}

// Handles drag operation initialization
void CJTIListView::OnBeginDrag(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	
	m_htreeDropItem = NULL;

	// Get the selected item's information
	if(m_pList->GetSelectedCount())
	{
		POSITION pos = m_pList->GetFirstSelectedItemPosition();
		int nItem = m_pList->GetNextSelectedItem(pos);

		if(nItem >= 0)
		{
			// Create drag image and begin dragging
			SetCapture();
			m_bDragging = TRUE;
		}
	}

	*pResult = 0;
}

// Handles mouse moves during dragging
void CJTIListView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if(m_bDragging)
	{
		CMainFrame *pFrame = (CMainFrame *) GetParentFrame();
		CTreeCtrl *pTree = pFrame->GetTreeCtrl();
		UINT nFlags;
		CPoint ptScreen(point);
		CPoint ptTree;

		// Find the item that we're currently dragging over
		ClientToScreen(&ptScreen);
		ptTree = ptScreen;
		pTree->ScreenToClient(&ptTree);

		m_htreeDropItem = pTree->HitTest(ptTree,&nFlags);

		// Set the cursor to drop or no-drop based on whether it's 
		// over a valid drop item
		if(m_htreeDropItem && m_htreeDropItem != pTree->GetRootItem())
			::SetCursor(AfxGetApp()->LoadCursor(IDC_DRAG));
		else
		{
			m_htreeDropItem = NULL;
			::SetCursor(::LoadCursor(NULL,IDC_NO));
		}
	}

	CListView::OnMouseMove(nFlags, point);
}

// Handles dropping of a dragged item
void CJTIListView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if(m_bDragging)
	{
		ReleaseCapture();

		// Valid drop item?
		if(m_htreeDropItem)
		{
			CMainFrame *pFrame = (CMainFrame *) GetParentFrame();
			CTreeCtrl *pTree = pFrame->GetTreeCtrl();

			// Get drop group
			int nNewGroup = pTree->GetItemData(m_htreeDropItem);

			// Is it different from the dragged group?
			if(nNewGroup != m_nActiveGroup)
			{
				int nOldGroup = m_nActiveGroup;

				// Cut the selected entries
				OnEditCut();

				// Paste the entries to the new group
				m_bAutoPaste = TRUE;
				m_nActiveGroup = nNewGroup;
				OnEditPaste();

				m_nActiveGroup = nOldGroup;
			}
		}

		m_bDragging = FALSE;
	}

	CListView::OnLButtonUp(nFlags, point);
}
