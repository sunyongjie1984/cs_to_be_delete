/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file implements the link item property dialog.
*/

#include "stdafx.h"
#include "jumptoit.h"
#include "mainfrm.h"
#include "PropDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJTIPropDlg dialog

// Constructor
CJTIPropDlg::CJTIPropDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CJTIPropDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CJTIPropDlg)
	m_Description = _T("");
	m_Menu = FALSE;
	m_URL = _T("");
	m_Type = 0;
	//}}AFX_DATA_INIT
}

// Field data exchange routine
void CJTIPropDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CJTIPropDlg)
	DDX_Text(pDX, IDC_DESCRIPTION, m_Description);
	DDV_MaxChars(pDX, m_Description, 500);
	DDX_Check(pDX, IDC_MENU, m_Menu);
	DDX_Text(pDX, IDC_URL, m_URL);
	DDV_MaxChars(pDX, m_URL, 500);
	DDX_Radio(pDX, IDC_WEB, m_Type);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CJTIPropDlg, CDialog)
	//{{AFX_MSG_MAP(CJTIPropDlg)
	ON_BN_CLICKED(IDC_HELPBTN, OnHelpBtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJTIPropDlg message handlers

// Sets the dialog title when it's initialized
BOOL CJTIPropDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	if(!m_strTitle.IsEmpty())
		SetWindowText(m_strTitle);

	m_OrigMenu = m_Menu;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

// Handles OK button processing
void CJTIPropDlg::OnOK() 
{
	UpdateData(TRUE);

	// Check for non-blank description
	m_Description.TrimRight();
	if(m_Description.IsEmpty())
	{
		// Ooops...descriptions can't be blank
		AfxMessageBox(IDS_VALID_DESCRIPTION,MB_ICONWARNING|MB_OK);
		return;
	}

	// Make sure we have room to add this item to the shortcut menu
	if(m_Menu && !m_OrigMenu)
	{
		if(!((CMainFrame *) GetParentFrame())->CanAddShortcut())
		{
			AfxMessageBox(IDS_TOO_MANY_SHORTCUTS,MB_ICONWARNING|MB_OK);
			return;
		}
	}
	
	CDialog::OnOK();
}

// Called when the help button is pressed
void CJTIPropDlg::OnHelpBtn() 
{
	AfxGetApp()->WinHelp(101,HELP_CONTEXT);
}
