/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file defines the main frame class.
*/

#if !defined(AFX_MAINFRM_H__203082E8_FF37_11D2_861D_00E02918D61A__INCLUDED_)
#define AFX_MAINFRM_H__203082E8_FF37_11D2_861D_00E02918D61A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CJTIListView;
class CJTITreeView;

#define UM_GROUP_CHANGED (WM_USER+100)

class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
protected:
	CSplitterWnd m_wndSplitter;
	BOOL m_bInMenu;
	BOOL m_bExitOK;

protected:
	void ShowContextMenu();

public:

// Operations
public:
	CJTIListView *GetList() { return (CJTIListView *) m_wndSplitter.GetPane(0,1); }
	CJTITreeView *GetTree() { return (CJTITreeView *) m_wndSplitter.GetPane(0,0); }
	CTreeCtrl *GetTreeCtrl();
	BOOL CanAddShortcut();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
	CJTIListView* GetRightPane();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
//	CReBar      m_wndReBar;
	CDialogBar      m_wndDlgBar;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg void OnDestroy();
	afx_msg void OnExit();
	afx_msg void OnLinks();
	afx_msg void OnEditCopy();
	afx_msg void OnEditCut();
	afx_msg void OnEditPaste();
	afx_msg void OnAppAbout();
	afx_msg void OnOptions();
	afx_msg void OnHelpContents();
	//}}AFX_MSG
	afx_msg void OnUpdateViewStyles(CCmdUI* pCmdUI);
	afx_msg void OnViewStyle(UINT nCommandID);
	afx_msg LRESULT OnTrayMsg(WPARAM wParam, LPARAM lParam);
	afx_msg void OnLink(UINT nCommandID);

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__203082E8_FF37_11D2_861D_00E02918D61A__INCLUDED_)
