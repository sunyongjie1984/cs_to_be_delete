/*
	JumpToIt - PC Magazine password utility

	Copyright (c) 1999 Ziff-Davis Publishing Company.  All rights reserved.
	First published in PC Magazine, US Edition.

	Written by Steven E. Sipe


	This file defines the link tree view class.
*/

#include "doc.h"

class CJTITreeView : public CTreeView
{
protected: 
	CJTITreeView();
	DECLARE_DYNCREATE(CJTITreeView)


protected:
	int m_nLevel;
	int m_nIndex;
	int m_nGroupCount;
	int *m_pMap;
	HTREEITEM m_htreeItemDrag;
	HTREEITEM m_htreeItemDrop;
	BOOL m_bDragging;
	TV_ITEM	m_tvItem;
	TCHAR m_szBuffer[500];
	CImageList m_ImageList;
	CImageList *m_pImageList;
	CTreeCtrl *m_pTree;
	CArchive *m_pArchive;
	CComboBox *m_pCombo;
	int m_nDefGroup;

	int m_cyTop;
	int m_cyBottom;

protected:
	int GetScrollType(CPoint pt);

	BOOL ArchiveItem();
	BOOL ShowItem();
	BOOL ClearItem();
	HTREEITEM MoveNode(HTREEITEM htreeItem, HTREEITEM htreeItemParent, HTREEITEM htreeItemSibling=NULL);
	BOOL RecurseItem(HTREEITEM hTreeItem, BOOL (CJTITreeView::*lpfnCallback)(void));
	BOOL IsChild(HTREEITEM htreeItemChild, HTREEITEM htreeItemParent);

	void ShowMenu(CPoint point);
	void ClearTree(HTREEITEM htreeItem);

// Attributes
public:
	CJTIDoc* GetDocument();
	CTreeCtrl *GetTreePtr() { return m_pTree; }

// Operations
public:
	void DisplayTree(CComboBox *pCombo);
	void SaveTree(CArchive& ar, int *pMap, HTREEITEM htreeStart = NULL);
	int LoadTree(CArchive& ar, BOOL bReset=TRUE);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJTITreeView)
	public:
	virtual void OnDraw(CDC* pDC);  
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void OnInitialUpdate(); 
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CJTITreeView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CJTITreeView)
	afx_msg void OnBeginDrag(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnAddItem();
	afx_msg void OnDeleteItem();
	afx_msg void OnRclick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemProperties();
	afx_msg void OnUpdateItemProperties(CCmdUI* pCmdUI);
	afx_msg void OnSelChanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnUpdateDeleteItem(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditCut(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	afx_msg void OnEditCopy();
	afx_msg void OnPasteDefault();
	afx_msg void OnUpdatePasteDefault(CCmdUI* pCmdUI);
	afx_msg void OnMoveDown();
	afx_msg void OnUpdateMoveDown(CCmdUI* pCmdUI);
	afx_msg void OnMoveUp();
	afx_msg void OnUpdateMoveUp(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  
inline CJTIDoc* CJTITreeView::GetDocument()
   { return (CJTIDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
