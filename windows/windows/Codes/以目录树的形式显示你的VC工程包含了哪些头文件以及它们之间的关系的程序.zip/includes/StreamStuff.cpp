#include "stdafx.h"
#include "StreamStuff.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//	The next two functions:
//	omanip<const char*> setformat(const char* fmt)
//	ostream& do_setformat(ostream& os, const char * fmt)
//	are taken from an article written by Cay S. Horstmann
//	http://www.horstmann.com/ccp/streams.txt

std::ostream& do_setformat(std::ostream& os, const char * fmt)
{
	int i = 0;

	while (fmt[i] != 0)
	{
		if (fmt[i] != '%')
		{
			os << fmt[i]; i++;
		}
		else
		{
			i++;
			if (fmt[i] == '%')
			{
				os << fmt[i]; i++;
			}
			else
			{
				bool ok = TRUE;
				int istart = i;
				bool more = TRUE;
				int width = 0;
				int precision = 6;
				long flags = 0;
				char fill = ' ';
				bool alternate = FALSE;
				while (more)
				{
					switch (fmt[i])
					{  
					case '+':
						flags |= std::ios::showpos;
						break;
					case '-':
						flags |= std::ios::left;
						break;
					case '0':
						flags |= std::ios::internal;
						fill = '0';
						break;
					case '#':
						alternate = TRUE;
						break;
					case ' ':
						break;
					default:
						more = FALSE;
						break;
					}
					if (more)
						i++;
				}
				if (isdigit(fmt[i])) 
				{
					width = atoi(fmt+i); 
					do
						i++;
					while (isdigit(fmt[i]));
				}
				if (fmt[i] == '.')
				{
					i++;
					precision = atoi(fmt+i); 
				while (isdigit(fmt[i])) i++;
				}
				switch (fmt[i])
				{  
				case 'd':
					flags |= std::ios::dec;
					break;
				case 'x':
					flags |= std::ios::hex;
					if (alternate) flags |= std::ios::showbase;
					break;
				case 'X':
					flags |= std::ios::hex | std::ios::uppercase;
					if (alternate) flags |= std::ios::showbase;
					break;
				case 'o':
					flags |= std::ios::hex;
					if (alternate) flags |= std::ios::showbase;
					break;
				case 'f':
					flags |= std::ios::fixed;
					if (alternate) flags |= std::ios::showpoint;
					break;
				case 'e':
					flags |= std::ios::scientific;
					if (alternate) flags |= std::ios::showpoint;
					break;
				case 'E':
					flags |= std::ios::scientific | std::ios::uppercase;
					if (alternate) flags |= std::ios::showpoint;
					break;
				case 'g':
					if (alternate) flags |= std::ios::showpoint;
					break;
				case 'G':
					flags |= std::ios::uppercase;
					if (alternate) flags |= std::ios::showpoint;
					break;
				default:
					ok = FALSE;
					break;
				}
				i++;
				if (fmt[i] != 0) ok = FALSE;
				if (ok)
				{
					os.unsetf(std::ios::adjustfield | std::ios::basefield | std::ios::floatfield);
					os.setf(flags);
					os.width(width);
					os.precision(precision);
					os.fill(fill);
				}
				else
					i = istart;
			}
		}
	}
	return os;
}

omanip<const char*> setformat( const char* fmt )
{
	return (omanip<const char*>(do_setformat, fmt));
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Util function used by the various Dump functions.

CString DottedString( int length )
{
	CString str( ' ', length*2 );
	for ( int i = 2; i < str.GetLength(); i += 4 )
		str.SetAt( i, '.' );
	return str;
}

