#if ! defined( __DLGSETPATH_H__ )
#define __DLGSETPATH_H__

#if _MSC_VER >= 1000
	#pragma once
#endif // _MSC_VER >= 1000

// DlgSetPath.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgSetPath dialog

class CDlgSetPath : public CDialog
{
// Construction
public:
	CDlgSetPath(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgSetPath)
	enum { IDD = IDD_SETPATH };
	CSpinButtonCtrl	m_Spin;
	CString	m_IncPath;
	int		m_Depth;
	CString	m_FilePath;
	CString	m_SysPath;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgSetPath)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgSetPath)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif //__DLGSETPATH_H__
