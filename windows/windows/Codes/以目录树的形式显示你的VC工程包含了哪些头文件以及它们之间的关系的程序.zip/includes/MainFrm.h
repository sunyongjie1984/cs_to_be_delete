#if ! defined( __MAINFRM_H__ )
#define __MAINFRM_H__

#if _MSC_VER >= 1000
	#pragma once
#endif // _MSC_VER >= 1000

// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#include "TopCaption.h"

#if _MSC_VER < 1200

typedef USHORT COLOR16;

typedef struct _TRIVERTEX
{
    LONG        x;
    LONG        y;
    COLOR16     Red;
    COLOR16     Green;
    COLOR16     Blue;
    COLOR16     Alpha;
}TRIVERTEX,*PTRIVERTEX,*LPTRIVERTEX;

typedef struct _GRADIENT_RECT
{
    ULONG UpperLeft;
    ULONG LowerRight;
}GRADIENT_RECT,*PGRADIENT_RECT,*LPGRADIENT_RECT;

#define GRADIENT_FILL_RECT_H    0x00000000

#endif

typedef BOOL (WINAPI* PFNGRADFILL) ( HDC hdc, CONST PTRIVERTEX pVertex, DWORD dwNumVertex, CONST PVOID pMesh, DWORD dwNumMesh, DWORD dwMode ); 

class CMainFrame : public CFrameWnd
{
	bool m_bFirstTime;
	HINSTANCE m_hLibrary;
	PFNGRADFILL m_pfnGradientFill;

protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

	// Stuff for painting custom title bar:
	CTopCaption m_capp;				// caption painter
	CFont		m_fontCaption;			// normal system font for active caption
	CFont		m_fontAcme;				// "ACME" company font (same active/inactive)

	// Overrides
	virtual void OnUpdateFrameTitle(BOOL bAddToTitle);
	void ShadeRect( CDC & dc, COLORREF colLeft, COLORREF colRight, const CRect & rc );

	// Helpers
	CString	GetDocTitle();
	void		CreateFonts();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void ActivateFrame(int nCmdShow = -1);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	BOOL Load(int & nCmdShow);
	BOOL Save();

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg LRESULT OnPaintMyCaption(WPARAM wp, LPARAM lp);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif //__MAINFRM_H__
