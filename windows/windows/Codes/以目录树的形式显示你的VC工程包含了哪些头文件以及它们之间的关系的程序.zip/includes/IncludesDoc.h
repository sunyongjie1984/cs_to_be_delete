#if ! defined( __INCLUDESDOC_H__ )
#define __INCLUDESDOC_H__

#if _MSC_VER >= 1000
	#pragma once
#endif // _MSC_VER >= 1000

// IncludesDoc.h : interface of the CIncludesDoc class
//
/////////////////////////////////////////////////////////////////////////////

#include "item.h"
#include "block.h"

typedef std::vector<std::string> StringVector;

class CFileList
{
public:
	CFileList() {}
	bool fileProcessed( const std::string & fname );

	void Empty();
protected:
	std::set<std::string> m_files;
};

typedef std::vector<CItem> CItemVector;

class CIncludesDoc : public CDocument
{
protected: // create from serialization only
	CIncludesDoc();
	DECLARE_DYNCREATE(CIncludesDoc)

// Attributes
public:
	const CItemVector & GetIncludes() const { return m_iaData; }
// Operations
public:
	typedef block<char, 1024> buffer_type;

	buffer_type & LineBuffer() { return m_buffer; }
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIncludesDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CIncludesDoc();
	void Scan( LPCTSTR lpszPathName );
	void Rescan();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	buffer_type m_buffer;

	void check_line( const char * p, int level );

private:
	void scan( const std::string & fname, int level );
	void prepareInc( const std::string & incFilePath, const std::string & incSysPath );
	std::string findFile( const std::string & name );

	static Regexp m_regexp;				// regexp to match the various #includes
	std::string m_fileName;				// the file that we are processing
	int m_incType;						// == 1 if we only want to process user includes
	BOOL m_once;						// == true if we only want to scan a file once

	StringVector m_inc;					// The merged include path that we are scanning across
	CFileList m_FileList;				// what files have we already scanned in this pass
	CItemVector m_iaData;				// the scan results (i.e. filenames and depths)

// Generated message map functions
protected:
	//{{AFX_MSG(CIncludesDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////


#endif //__INCLUDESDOC_H__
