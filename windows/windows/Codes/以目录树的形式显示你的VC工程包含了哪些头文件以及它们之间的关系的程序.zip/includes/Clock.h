#if ! defined( __CLOCK_H__ )
#define __CLOCK_H__

#if _MSC_VER >= 1000
	#pragma once
#endif // _MSC_VER >= 1000

#include <time.h>

class CClock
{
	clock_t m_start;
	clock_t m_finish;
	double m_difference;
public:
	CClock() : m_start( clock() ), m_finish(0), m_difference(0)
	{
	}

	double Stop()
	{
		m_finish = clock();
		return m_difference = (double)(m_finish - m_start) / CLOCKS_PER_SEC;
	}
	double Time() { return m_difference; }
};

#endif //__CLOCK_H__
