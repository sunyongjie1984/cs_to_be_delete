// IncludeView.cpp : implementation file
//

#include "stdafx.h"
#include "includes.h"
#include "IncludeView.h"
#include "IncludesDoc.h"
#include "FindDlg.h"

#include "DropHelpers.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIncludeView


/////////////////////////////////////////////////////////////////////////////
// CIncludeView

#define LIST_ID 0x100

const TCHAR szPosition[] = _T( "Position" );
const TCHAR szColWidth[] = _T( "ColWidth" );

IMPLEMENT_DYNCREATE(CIncludeView, CView)

CIncludeView::CIncludeView()
	: m_bMatchCase(false),
	m_pFindItem(0)
{
}

CIncludeView::~CIncludeView()
{
}

BEGIN_MESSAGE_MAP(CIncludeView, CView)
	//{{AFX_MSG_MAP(CIncludeView)
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_COMMAND(ID_EDIT_FIND, OnEditFind)
	ON_COMMAND(ID_EDIT_FIND_NEXT, OnEditFindNext)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND_NEXT, OnUpdateEditFindNext)
	ON_COMMAND(ID_EDIT_RESCAN, OnEditRescan)
	ON_WM_DROPFILES()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_LBUTTONUP_REFLECT, OnLButtonUpReflect)
	ON_MESSAGE(WM_BEGINDRAG_REFLECT, OnBeginDragReflect)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSuperVw drawing

void CIncludeView::OnDraw( CDC* /* pDC */)
{
}

/////////////////////////////////////////////////////////////////////////////
// CSuperVw diagnostics

#ifdef _DEBUG
void CIncludeView::AssertValid() const
{
	CView::AssertValid();
}

void CIncludeView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSuperVw message handlers

void CIncludeView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize( nType, cx, cy );
	if( m_List.GetSafeHwnd() )
	{
		m_List.SetColumnWidth( 1, cx - GetSystemMetrics( SM_CXVSCROLL ) - m_List.GetColumnWidth(0) );
		m_List.SetWindowPos( 0, 0, 0, cx, cy, SWP_SHOWWINDOW );
	}
}

int CIncludeView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	m_List.Create( WS_CHILD | WS_VISIBLE | LVS_REPORT | LVS_SINGLESEL | LVS_SHAREIMAGELISTS
		| LVS_OWNERDRAWFIXED | LVS_SHOWSELALWAYS, CRect( 0, 0, 0, 0 ), this, LIST_ID );	

	InitializeGrid();
	::DragAcceptFiles( GetSafeHwnd(), TRUE );
	return 0;
}

void CIncludeView::OnUpdate(CView* /*pSender */, LPARAM /* lHint */, CObject* /*pHint */) 
{
	m_pFindItem = 0;
	m_List.DeleteAllItems();

	CFileList list;
	const CItemVector & inc = GetDocument()->GetIncludes();

	if ( inc.size() )
	{
		std::vector<CSuperGridCtrl::CTreeItem*> itemArray;

		CItemInfo* lp = new CItemInfo;
		lp->SetItemText( inc[0].Name().c_str() );
		lp->AddSubItemText( inc[0].FullName().c_str() );

		//Create root item
		if( !m_List.CreateTreeCtrl( lp ) )
			return;

		CSuperGridCtrl::CTreeItem* pParent = m_List.GetRootItem();
		itemArray.push_back( pParent );

		int lastDepth = inc[0].Depth();	// == 0;

		for ( size_t i = 1; i < inc.size(); i++ )
		{
			if ( inc[i].Depth() > lastDepth )
			{
				itemArray.resize( inc[i].Depth() + 1, 0 );
				itemArray[inc[i].Depth()] = pParent;
			}

			lastDepth = inc[i].Depth();

			CItemInfo* lp = new CItemInfo;
			lp->SetItemText( inc[i].Name().c_str() );
			lp->AddSubItemText( inc[i].FullName().c_str() );

			pParent = m_List.InsertItem( itemArray[lastDepth], lp );
		}
		int id = 0;
		m_List.ExpandAll( m_List.GetRootItem(), id );
	}
}


void CIncludeView::InitializeGrid()
{
	VERIFY( m_List.SetGridImage( IDB_TREEBMP ) == 0 );

	LPTSTR lpszCols[] = { _T("File"),_T("Path"),0 };
	LV_COLUMN   lvColumn;
	//initialize the columns
	lvColumn.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	lvColumn.fmt = LVCFMT_LEFT;
	
	lvColumn.cx = AfxGetApp()->GetProfileInt( szPosition, szColWidth, 400);

	for( int x = 0; lpszCols[x]!=NULL; x++ )
    {
		if ( x )
			lvColumn.cx = 500;
		lvColumn.pszText = lpszCols[x];
		m_List.InsertColumn(x,&lvColumn);
    }
}

void CIncludeView::OnDestroy() 
{
	AfxGetApp()->WriteProfileInt( szPosition, szColWidth, m_List.GetColumnWidth(0) );
	CView::OnDestroy();
}

LRESULT CIncludeView::OnBeginDragReflect( WPARAM nItem, LPARAM lParam )
{
	if ( m_List.GetSelectedCount() > 0 )
	{
		SetCapture();

		CImageList* pDragImage=NULL;
		pDragImage = m_List.CreateDragImageEx( nItem );
		if(pDragImage)
		{
			pDragImage->BeginDrag(0, CPoint(10,10));
			CPoint pt( lParam );
			ClientToScreen( &pt );

			pDragImage->DragEnter( NULL, pt );
		}
		delete pDragImage;
	}
	return 0;
}

LRESULT CIncludeView::OnLButtonUpReflect( WPARAM nFlags, LPARAM lParam )
{
	CPoint pt( lParam );
	OnLButtonUp( nFlags, pt );
	return 0;
}

void CIncludeView::OnMouseMove(UINT nFlags, CPoint point) 
{
   if ( GetCapture() != this )
      return; 

	if( GetKeyState(VK_ESCAPE) < 0 )
	{
		EndDrag();
		return;
	}
		
	ClientToScreen( &point );
	CImageList::DragMove( point );

	 // Get cursor position and window under the cursor. 
	SetCursor( IsWindow( DFSrc_OkToDrop( NULL ) )
		? LoadCursor(NULL, IDC_ARROW )
		: LoadCursor(NULL, IDC_NO ) );

	CView::OnMouseMove(nFlags, point);
}

void CIncludeView::EndDrag()
{
	ReleaseCapture();
	CImageList::EndDrag();
}

void CIncludeView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// If we don't have capture, the user didn't initiate the drag-and-drop 
	// sequence � we have nothing to do here. 
	if ( GetCapture() != this )
		return;

	// End the drag-and-drop sequence. 
	EndDrag();

	// Get the HWND of the target window. 
	HWND hwndTarget = DFSrc_OkToDrop( NULL ); 

	if (!IsWindow(hwndTarget))
		return; 		// If the target window is invalid, we have nothing else to do. 

	// Get the client rectangle of the target window and convert the mouse 
	// position to the target's client coordinates so that we can tell if 
	// the mouse is in the target's client area when we call DFSrc_Create. 
	CRect rc;
	::GetClientRect(hwndTarget, &rc); 
	::ScreenToClient(hwndTarget, &point); 

	HDROP hdrop, hdropT; 

	// Create dropfile memory block and initialize it. 
#ifdef UNICODE 
	hdrop = DFSrc_Create(&point, !PtInRect(&rc, point), TRUE); 
#else 
	hdrop = DFSrc_Create(&point, !PtInRect(&rc, point), FALSE); 
#endif 

	if (hdrop == NULL)
	{ 
		TRACE0(_T("Insufficient memory to drop file(s).") ); 
		return; 
	} 

	// Append each path name to the dropfile memory block. 
	int idx = m_List.GetNextItem(-1, LVNI_SELECTED);
	while ( idx >= 0 )
	{
		CString item = m_List.GetItemText( idx, 1 );

		hdropT = DFSrc_AppendPathname(hdrop, (void*)((LPCSTR)item) );
		if (hdropT == NULL)
		{ 
			TRACE0(_T("Insufficient memory to drop file(s).")); 
			hdrop = (HDROP)GlobalFree(hdrop); 
			break;  // Terminates the 'for' loop. 
		}
		else
		{ 
			hdrop = hdropT; 
		} 
		idx = m_List.GetNextItem(idx, LVNI_SELECTED);
	}

	if (hdrop != NULL)
	{ 
		// All path names appended successfully; post the message to the  
		// dropfile target window. 
		::PostMessage( hwndTarget, WM_DROPFILES, (WPARAM)hdrop, 0 );

		// NOTE: We should not call GlobalFree passing in hdrop.  The system  
		// will free it for us after it creates a copy of it in the target  
		// process's address space.  The target process is responsible for  
		// freeing it's copy of the hdrop by calling DragFinish. 
	} 

	CView::OnLButtonUp(nFlags, point);
}

void CIncludeView::OnEditFind() 
{
	CFindDlg findDlg;
	findDlg.m_Find = m_FindStr;
	findDlg.m_MatchCase = m_bMatchCase;

	if ( findDlg.DoModal() == IDOK )
	{
		m_FindStr = findDlg.m_Find;
		m_bMatchCase = findDlg.m_MatchCase != 0;

		Regexp reg( m_FindStr, ! m_bMatchCase );	// regexp has an Ignore case flag rather than a match case one!

		m_pFindItem = m_List.SearchEx( m_List.GetRootItem(), reg );
		if ( m_pFindItem )
			m_List.SelectNode(m_pFindItem);
		else
			MessageBeep(-1);
	}
}

void CIncludeView::OnUpdateEditFindNext(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable( m_pFindItem != 0 );
}

void CIncludeView::OnEditFindNext() 
{
	ASSERT( m_pFindItem != 0 );
	Regexp reg( m_FindStr, ! m_bMatchCase );	// regexp has an Ignore case flag rather than a match case one!
	m_pFindItem = m_List.SearchEx( m_pFindItem, reg );
	if ( m_pFindItem )
		m_List.SelectNode(m_pFindItem);
	else
		MessageBeep(-1);
}

void CIncludeView::OnEditRescan() 
{
	GetDocument()->Rescan();
}

void CIncludeView::OnDropFiles(HDROP hDropInfo) 
{
	// Add each pathname to the list box
	UINT wNumFilesDropped = ::DragQueryFile( hDropInfo, (UINT)-1, NULL, 0 );
	if ( wNumFilesDropped != 1 )
	{
		MessageBeep( -1 );
	}
	// Get the number of bytes required by the file's full pathname
	UINT wPathnameSize = ::DragQueryFile( hDropInfo, 0, NULL, 0);

	// Copy the pathname into the buffer
	CString fName;
	char * buf = fName.GetBufferSetLength( wPathnameSize+1 );
	::DragQueryFile( hDropInfo, 0, buf, wPathnameSize + 1 );
	fName.ReleaseBuffer();

	GetDocument()->Scan( fName );
}
