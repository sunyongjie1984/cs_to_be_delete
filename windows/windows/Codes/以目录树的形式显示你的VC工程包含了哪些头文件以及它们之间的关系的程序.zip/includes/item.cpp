#include "stdafx.h"
#include "item.h"

void CItem::Dump( CDumpContext& dc ) const
{
	dc << Name().c_str() << "(" << FullName().c_str() << ")" << " - " << Depth() << "\n";
}

void AFXAPI DumpElements(CDumpContext& dc, const CItem * pElements, int nCount)
{
	ASSERT(nCount == 0 ||
		AfxIsValidAddress(pElements, nCount * sizeof(CItem)));

	for ( int i = 0; i < nCount; i++ )
		pElements[i].Dump( dc );
}

