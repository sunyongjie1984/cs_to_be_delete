#include "stdafx.h"
#include "DropHelpers.h"

// Written by: Jeffrey Richter 
// Notices: Copyright (c) 1995 Jeffrey Richter 

// Most of this was written by Jeffrey Richter for his book
// "Windows 95: A Developer's Guide", if it's broken - it probably my fault. - GGP

HDROP WINAPI DFSrc_Create( PPOINT ppt, BOOL fNC, BOOL fWide )
{
	HDROP hdrop; 
	LPDROPFILES pDropFiles; 

	// Allocate dynamic memory for the DFSRC data structure and for the extra 
	// zero character identifying that there are no path names in the block yet. 
	hdrop = (HDROP)GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT,  
		sizeof(DROPFILES) + (fWide ? sizeof(WCHAR) : sizeof(char))); 

	// If successful, lock block and initialize the data members. 
	if (hdrop != NULL)
	{ 
		pDropFiles = (LPDROPFILES) GlobalLock(hdrop); 
		pDropFiles->pFiles = sizeof(*pDropFiles); 
		pDropFiles->pt = *ppt; 
		pDropFiles->fNC = fNC; 
		pDropFiles->fWide = fWide; 
		GlobalUnlock(hdrop); 
	} 
	return(hdrop); 
} 
 
HDROP WINAPI DFSrc_AppendPathname( HDROP hdrop, PVOID pvPathname )
{ 
	LPDROPFILES pDropFiles = (LPDROPFILES)GlobalLock( hdrop );

	// Point to first path name in list. 
	PSTR  szPathA = (PSTR) pDropFiles + pDropFiles->pFiles; 
	PWSTR szPathW = (PWSTR) szPathA; 
	int nOffsetOfNewPathname, nPathSize; 

	if ( pDropFiles->fWide )
	{ 
		// Search for a path name where first character is a zero character 
		while ( *szPathW )     // While the first character is nonzero. 
		{
			while ( *szPathW )  // Find end of current path. 
				szPathW++; 
			szPathW++;          // Skip over the zero character. 
		}

		// Get the offset from the beginning of the block  
		// where the new path name should go. 
		nOffsetOfNewPathname = ( (PBYTE) szPathW - (PBYTE) pDropFiles); 

		// Get the number of bytes needed for the new path name, 
		// it's terminating zero character, and the zero-length  
		// path name that marks the end of the list of path names. 
		nPathSize = sizeof(WCHAR) * ( wcslen((PWSTR)pvPathname) + 2 );
	}
	else
	{ 
		// Search for a path name where first character is a zero character. 
		while ( *szPathA )   // While the first character is nonzero 
		{
			while ( *szPathA )// Find end of current path. 
				szPathA++; 
			szPathA++;        // Skip over the zero character. 
		} 

		// Get the offset from the beginning of the block  
		// where the new path name should go. 
		nOffsetOfNewPathname = ((PBYTE) szPathA - (PBYTE) pDropFiles); 

		// Get the number of bytes needed for the new path name, 
		// it's terminating zero character, and the zero-length  
		// path name that marks the end of the list of path names 
		nPathSize = sizeof(char) * (strlen((PSTR)pvPathname) + 2); 
	} 

	GlobalUnlock(hdrop); 

	// Increase block size to accommodate new path name. 
	hdrop = (HDROP)GlobalReAlloc(hdrop, nPathSize + nOffsetOfNewPathname,  
		GMEM_MOVEABLE | GMEM_ZEROINIT); 

	// If successful, append the path name to the end of the block. 
	if (hdrop != NULL)
	{ 
		pDropFiles = (LPDROPFILES) GlobalLock(hdrop); 

		if (pDropFiles->fWide) 
			wcscpy((PWSTR) ((PSTR) pDropFiles + nOffsetOfNewPathname), (PWSTR)pvPathname); 
		else 
			strcpy((PSTR)  ((PSTR) pDropFiles + nOffsetOfNewPathname), (PSTR)pvPathname); 

		GlobalUnlock(hdrop); 
	} 

	return(hdrop);                // Returns the new handle to the block. 
} 

HWND WINAPI DFSrc_OkToDrop (PPOINT ppt)
{ 
	POINT ptMousePos; 
	HWND hwndTarget; 

	if (ppt == NULL)
	{ 
		// If the caller passes NULL, assume that they want the mouse position 
		// at the time of the last-retrieved window message. 
		ptMousePos.x = LOWORD(GetMessagePos()); 
		ptMousePos.y = HIWORD(GetMessagePos()); 
	}
	else
		ptMousePos = *ppt;

	hwndTarget = WindowFromPoint(ptMousePos);
	// See if the target window or any of its parent windows are prepared to  
	// accept dropped files. 
	while ( IsWindow(hwndTarget) && !IsAcceptingFiles(hwndTarget) )
		hwndTarget = GetParent(hwndTarget); 

	// If it's OK to drop files, return the HWND of the target window or NULL  
	// if we do not have a target window accepting files. 
	return( (IsWindow(hwndTarget) && IsAcceptingFiles(hwndTarget) )
		? hwndTarget : NULL ); 
} 
 
