#if ! defined( __DROPHELPERS_H__ )
#define __DROPHELPERS_H__

#if _MSC_VER >= 1000
	#pragma once
#endif // _MSC_VER >= 1000

#include <ShlObj.h>

// Written by: Jeffrey Richter 
// Notices: Copyright (c) 1995 Jeffrey Richter 

// Most of this was written by Jeffrey Richter for his book
// "Windows 95: A Developer's Guide", if it's broken - it probably my fault. - GGP

HDROP WINAPI DFSrc_Create( PPOINT ppt, BOOL fNC, BOOL fWide );
HDROP WINAPI DFSrc_AppendPathname( HDROP hdrop, PVOID pvPathname );
HWND WINAPI DFSrc_OkToDrop( PPOINT ppt );

inline bool IsAcceptingFiles( HWND hwnd ) { return ( GetWindowLong( hwnd, GWL_EXSTYLE ) & WS_EX_ACCEPTFILES ) != 0; }

#endif //__DROPHELPERS_H__
