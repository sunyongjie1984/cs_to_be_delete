// TreeGridCtrl.h: interface for the CTreeGridCtrl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TREEGRIDCTRL_H__D149E047_AB1F_11D2_A7AF_00C04FA3325E__INCLUDED_)
#define AFX_TREEGRIDCTRL_H__D149E047_AB1F_11D2_A7AF_00C04FA3325E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "SuperGridCtrl.h"

class CTreeGridCtrl : public CSuperGridCtrl  
{
public:
	CTreeGridCtrl();
	virtual ~CTreeGridCtrl();

	virtual int GetIcon( const CTreeItem* pItem );
	CTreeItem* SearchEx( CTreeItem *pStartPosition, Regexp & regItem );

	virtual CImageList * CreateDragImageEx(int nItem);

	//{{AFX_MSG(CTreeGridCtrl)
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnBegindrag(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#define WM_LBUTTONUP_REFLECT WM_APP + 101
#define WM_BEGINDRAG_REFLECT WM_APP + 102

#endif // !defined(AFX_TREEGRIDCTRL_H__D149E047_AB1F_11D2_A7AF_00C04FA3325E__INCLUDED_)
