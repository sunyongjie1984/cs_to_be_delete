#if ! defined( __DEBUGSTREAM_H__ )
#define __DEBUGSTREAM_H__

#if _MSC_VER >= 1000
	#pragma once
#endif // _MSC_VER >= 1000

#include "StreamStuff.h"

//////////////////////////////////////////////////////////////////////

// implementation class

class CDebugStreambuf : public std::streambuf
{
public:
	CDebugStreambuf( unsigned int BufferSize = 1024 );

	~CDebugStreambuf();

	virtual int overflow( int ch );		// Called when the buffer is full and the stream wants to add more stuff
	virtual int sync();					// Called whenever the stream wants to be flushed

protected:
	void Flush();

	TCHAR * m_pBuffer;
	unsigned int m_BufferSize;
};

//////////////////////////////////////////////////////////////////////
// public interface

class CDebugStream : public std::basic_ostream<TCHAR>
{
public:
	CDebugStream( unsigned int BufferSize = 1024 )
		: m_buf( BufferSize ),
		std::basic_ostream<TCHAR>( &m_buf ) 
	{ }

	~CDebugStream() { m_buf.pubsync(); }
protected:
	CDebugStreambuf m_buf;
};


#endif //__DEBUGSTREAM_H__
