#if ! defined( __INCLUDEVIEW_H__ )
#define __INCLUDEVIEW_H__

#if _MSC_VER >= 1000
	#pragma once
#endif // _MSC_VER >= 1000

// IncludeView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIncludeView view

class CIncludesDoc ;
#include "TreeGridCtrl.h"

class CIncludeView : public CView
{
	CString m_FindStr;
	bool m_bMatchCase;

	CTreeGridCtrl::CTreeItem * m_pFindItem;

protected:
	CIncludeView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CIncludeView)

// Attributes
public:
	CTreeGridCtrl m_List;
// Operations
public:
	CIncludesDoc * GetDocument() const { return (CIncludesDoc*)CView::GetDocument(); }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIncludeView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CIncludeView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	void InitializeGrid();
	void EndDrag();

	// Generated message map functions
protected:
	//{{AFX_MSG(CIncludeView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnEditFind();
	afx_msg void OnEditFindNext();
	afx_msg void OnUpdateEditFindNext(CCmdUI* pCmdUI);
	afx_msg void OnEditRescan();
	afx_msg void OnDropFiles(HDROP hDropInfo);
	//}}AFX_MSG
	afx_msg LRESULT OnLButtonUpReflect( WPARAM nFlags, LPARAM lParam );
	afx_msg LRESULT OnBeginDragReflect( WPARAM nFlags, LPARAM lParam );
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

#endif //__INCLUDEVIEW_H__
