// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

// Oh the joys of the preprocessor :-)
#define __LINE_NO__(A,B)   A"("#B") : "
#define __LINE_NO2__(A,B) __LINE_NO__(A,B)
#define __FILEINFO__ __LINE_NO2__(__FILE__,__LINE__)
// This allows me to put 'reminder' messages in the code that the compiler can then spit
// out with file and lineno info, doing something like this
// #pragma message( __FILEINFO__ "Fix Me!!!" )

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxole.h>         // MFC OLE classes
#include <afxodlgs.h>       // MFC OLE dialog classes
#include <afxdisp.h>        // MFC OLE automation classes
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxcview.h>
#include <afxrich.h>		// MFC rich edit classes


// I'm sorry about all of these, unfortunately they are the price that you pay if you use the current MS supplied STL
// and want to try to use Warning level 4.

// The debugger can't handle symbols more than 255 characters long.
// STL often creates symbols longer than that.
#pragma warning(disable:4786) // When symbols are longer than 255 characters, the warning is disabled.
#include <xstddef>
#pragma warning(disable:4097) // typedef-name 'istream' used as synonym for class-name 'basic_istream<char,struct std::char_traits<char>>'
#pragma warning(disable:4018) // signed/unsigned mismatch
#pragma warning(disable:4100) // unreferenced formal parameter
#pragma warning(disable:4146) // unary minus operator applied to unsigned type, result still unsigned
#pragma warning(disable:4238) // nonstandard extension used : class rvalue used as lvalue
#pragma warning(disable:4244) // conversion from 'const int' to 'char', possible loss of data
#pragma warning(disable:4663) // C++ language change: to explicitly specialize class template 'char_traits' use the following syntax: template<> struct char_traits<unsigned short> ...
#pragma warning(disable:4511) // copy constructor could not be generated
#pragma warning(disable:4512) // assignment operator could not be generated
#pragma warning(disable:4245) // conversion from 'const int' to 'const unsigned int', signed/unsigned mismatch
#pragma warning(disable:4505) // unreferenced local function has been removed
#pragma warning(disable:4710) // function '...' not expanded
#pragma warning(disable:4804) // '<' : unsafe use of type 'bool' in operation

#pragma warning(disable:4711) // function selected for automatic inline expansion

#include <iostream>
#include <istream>
#include <string>
#include <fstream>
#include <functional>
#include <algorithm>
#include <vector>
#include <list>
#include <bitset>
#include <set>

#include "DebugStream.h"
#include "Regexp.h"
