#if ! defined( __SPLIT_STRING_H__ )
#define __SPLIT_STRING_H__

#if _MSC_VER >= 1000
	#pragma once
#endif // _MSC_VER >= 1000

template< class collection_type > 
	void splitstring( collection_type & vec, const collection_type::value_type & in, const collection_type::value_type & delims )
{
	if ( in.find_first_of( delims ) != std::string::npos )
	{
		const TCHAR * section = in.c_str();
		const TCHAR * start = section, * curpos = section;

		// kill any leading delimiter
		if ( delims.find( *curpos ) != std::string::npos )
			section = ++curpos;

		while( *curpos )
		{	
			while ( *curpos && ( delims.find( *curpos ) == std::string::npos ) )
				curpos++;
			vec.push_back( in.substr( section - start, curpos - section ) );
			if ( *curpos )
				section = ++curpos;
		}
	}
	else
		vec.push_back( in );
};

//template< class collection_type > 
//	void splitstring( collection_type & vec, const TCHAR * in, const TCHAR * delims )
//{
//	return splitstring( vec, std::string(in), std::string(delims) );
//};

template< class collection_type > 
class split_string : public collection_type
{
public:
	split_string( const collection_type::value_type & in, const collection_type::value_type & delims )
	{
		splitstring( *this, in, delims );
	}
};

#endif //__SPLIT_STRING_H__
