// TopCaption.h: interface for the CTopCaption class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TOPCAPTION_H__11DC5B57_A01F_11D2_A7AB_00C04FA3325E__INCLUDED_)
#define AFX_TOPCAPTION_H__11DC5B57_A01F_11D2_A7AB_00C04FA3325E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "PaintCap.h"

class CTopCaption : public CCaptionPainter  
{
	CRect m_rc;
	bool m_bButtonPushed;		// the actual bitmap state
	bool m_bDepressed;			// show the button depressed whilst the button is down

	CBitmap m_PinnedBitmap;
	CBitmap m_UnPinnedBitmap;

protected:
	void ReloadBitmaps();
	void LoadBitmaps();

	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);	
	void set_topmost_attribute( int want_topmost );

	bool ScreenPointOverButton( CPoint pt );
	bool PointOverButton( CPoint pt );
	void DrawDepressedButton( bool bDepressed );

	void OnNcLButtonDown(UINT nHitTest, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);

public:
	CTopCaption();
	virtual ~CTopCaption();

	const CRect & Rect() const { return m_rc; }
	void Invalidate();
	int DrawButtons(const PAINTCAP& pc);

	static int GetLuminosity(COLORREF color);
	static void PaintRect(CDC& dc, int x, int y, int w, int h, COLORREF color);

	bool ButtonPushed() const { return m_bButtonPushed; }
	void SetButtonPushed( bool b );
	void PushButton();
};

#endif // !defined(AFX_TOPCAPTION_H__11DC5B57_A01F_11D2_A7AB_00C04FA3325E__INCLUDED_)

