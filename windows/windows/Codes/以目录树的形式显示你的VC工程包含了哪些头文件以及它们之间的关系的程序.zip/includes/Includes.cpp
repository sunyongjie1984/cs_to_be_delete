// Includes.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Includes.h"

#include "MainFrm.h"
#include "IncludesDoc.h"
#include "IncludeView.h"
#include <dos.h>
#include <direct.h>
#include "DlgSetPath.h"
#include "HyperLink.h"
#include "RTFStream.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static char szSection[] = _T( "Main" );
static char szSysInc[] = _T( "SYS_INCLUDE" );
static char szFileInc[] = _T( "FILE_INCLUDE" );

/////////////////////////////////////////////////////////////////////////////
// CIncludesApp

BEGIN_MESSAGE_MAP(CIncludesApp, CWinApp)
	//{{AFX_MSG_MAP(CIncludesApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_INCLUDEPATH, OnFileIncludepath)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIncludesApp construction

CIncludesApp::CIncludesApp()
	: m_Depth(10)
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CIncludesApp object

CIncludesApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CIncludesApp initialization

BOOL CIncludesApp::InitInstance()
{
	// Initialize OLE libraries
	if (!AfxOleInit())
	{
//		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}
	AfxInitRichEdit(); 

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	AfxEnableControlContainer();
	SetRegistryKey(_T("Includes"));
	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CIncludesDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CIncludeView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	CString file, sys;
	file = GetProfileString( szSection, szFileInc );
	sys = GetProfileString( szSection, szSysInc );
	if ( sys.IsEmpty() )
		sys = getenv( "INCLUDE" );
	SetFilePath( (LPCSTR)file );
	SetSysPath( (LPCSTR)sys );

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CHyperLink	m_HyperLink;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_HYPERLINK, m_HyperLink);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CAboutDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_HyperLink.SetURL(_T("mailto:guy@wyrdrune.com"));
	m_HyperLink.SetUnderline(FALSE);

	CWnd * pWndRich = GetDlgItem( IDC_RICHEDIT );
	CRTFStream rtfStream( pWndRich->m_hWnd );

	rtfStream << 
		"To quote Sir Isaac Newton:\n"
		<< rtf::italic << "�If I have seen further it is by standing upon the shoulders of giants�.\n" << rtf::noitalic <<
		"\n" <<
		"This program was greatly assisted by the publications of a number of people, including:\n" <<
		"\n" <<
		"Henry Spencer for his excellent regular expression library.\n" <<
		"Jeffrey Richter for the Drop File Server code.\n" <<
		"Allan Nielsen for the SuperGrid class.\n" <<
		"Paul DiLascia for the Caption Painting classes.\n" <<
		"\n" <<
		"Zafir Anjum, Chris Maunder and all the other Code Gurus who by sharing their code make life a little easier for the rest of us.\n" <<
		"\n" <<
		"Thank you.\n" << std::endl;

	return TRUE;  // return TRUE  unless you set the focus to a control
}


// App command to run the dialog
void CIncludesApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CIncludesApp commands

void CIncludesApp::OnFileIncludepath() 
{
	CDlgSetPath dlg;
	dlg.m_FilePath = GetApp()->FileIncludePath().c_str();
	dlg.m_SysPath = GetApp()->SysIncludePath().c_str();
	dlg.m_Depth = Depth();
	if ( dlg.DoModal() == IDOK )
	{
		GetApp()->SetFilePath( (LPCSTR)(dlg.m_FilePath) );
		GetApp()->SetSysPath( (LPCSTR)(dlg.m_SysPath) );
		SetDepth( dlg.m_Depth );
	}
}

int CIncludesApp::ExitInstance() 
{
	WriteProfileString( szSection, szSysInc, m_SysPath.c_str() );
	WriteProfileString( szSection, szFileInc, m_FilePath.c_str() );
	return CWinApp::ExitInstance();
}
