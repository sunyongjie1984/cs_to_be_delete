#include "stdafx.h"
#include "DebugStream.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

using std::streambuf;

CDebugStreambuf::CDebugStreambuf( unsigned int BufferSize /* = 1024 */ )
	: m_BufferSize( BufferSize )
{
	m_pBuffer = new TCHAR[m_BufferSize + 1];
	setp( m_pBuffer, m_pBuffer + m_BufferSize );
}

CDebugStreambuf::~CDebugStreambuf()
{
	delete [] m_pBuffer;
}

int CDebugStreambuf::overflow( int ch )
{
	Flush();
	if (ch != EOF)
		if (pbase() == epptr())
			::OutputDebugString( CString( ch ) );
		else        
			sputc(ch); 
	return streambuf::overflow( ch );
}

int CDebugStreambuf::sync()
{
	ASSERT( this );
	Flush();
	return streambuf::sync();
}

void CDebugStreambuf::Flush()
{
	ASSERT( this );
	*pptr() = '\0';         // NULL terminate
	::OutputDebugString( m_pBuffer );
	setp( m_pBuffer, m_pBuffer + m_BufferSize );
	setg( 0, 0, 0);
}

