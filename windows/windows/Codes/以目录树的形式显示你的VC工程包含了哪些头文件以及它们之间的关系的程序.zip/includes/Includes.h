// Includes.h : main header file for the INCLUDES application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CIncludesApp:
// See Includes.cpp for the implementation of this class
//

class CIncludesApp : public CWinApp
{
	std::string m_FilePath;
	std::string m_SysPath;
	int m_Depth;
public:
	CIncludesApp();

	const std::string & FileIncludePath() const { return m_FilePath; }
	const std::string & SysIncludePath() const { return m_SysPath; }

	void SetFilePath( const std::string & s ) { m_FilePath = s; }
	void SetSysPath( const std::string & s ) { m_SysPath = s; }

	int Depth() const { return m_Depth; }
	void SetDepth( int i ) { m_Depth = i; }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIncludesApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CIncludesApp)
	afx_msg void OnAppAbout();
	afx_msg void OnFileIncludepath();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

inline CIncludesApp * GetApp() { return (CIncludesApp*)AfxGetApp(); }

