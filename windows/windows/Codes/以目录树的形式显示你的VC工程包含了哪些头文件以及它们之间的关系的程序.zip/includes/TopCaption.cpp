// TopCaption.cpp: implementation of the CTopCaption class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"
#include "TopCaption.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////
// Helper function to compute the luminosity for an RGB color.
// Measures how bright the color is. I use this so I can draw the caption
// text using the user's chosen color, unless it's too dark. See MSDN for
// definition of luminosity and how to compute it.
//
int CTopCaption::GetLuminosity(COLORREF color)
{
#define HLSMAX 240	// This is what Display Properties uses
#define RGBMAX 255	// max r/g/b value is 255
	int r = GetRValue(color);
	int g = GetGValue(color);
	int b = GetBValue(color);
	int rgbMax = max( max(r,g), b);
	int rgbMin = min( min(r,g), b);
	return (((rgbMax+rgbMin) * HLSMAX) + RGBMAX ) / (2*RGBMAX);
}

//////////////////
// Helper to paint rectangle with a color.
//
void CTopCaption::PaintRect(CDC& dc, int x, int y, int w, int h, COLORREF color)
{
	CBrush brush(color);
	CBrush* pOldBrush = dc.SelectObject(&brush);
	dc.PatBlt(x, y, w, h, PATCOPY);
	dc.SelectObject(pOldBrush);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTopCaption::CTopCaption()
	: m_bButtonPushed(false),
	m_bDepressed(false)
{
	LoadBitmaps();
}

CTopCaption::~CTopCaption()
{

}

void CTopCaption::ReloadBitmaps()
{
	//free the bitmap resources
	m_PinnedBitmap.DeleteObject();
	m_UnPinnedBitmap.DeleteObject();

	//Reload the bitmaps
	LoadBitmaps();
	Invalidate();
}

void CTopCaption::PushButton() 
{
	m_bDepressed = false;
	SetButtonPushed( !m_bButtonPushed );
	Invalidate();                      //and force a redraw
}

void CTopCaption::SetButtonPushed( bool b )
{
	m_bButtonPushed = b;
	set_topmost_attribute( m_bButtonPushed );
}

void CTopCaption::DrawDepressedButton( bool bDepressed )
{
	m_bDepressed = bDepressed;
	Invalidate();                      //and force a redraw
}

void CTopCaption::Invalidate()
{
	CCaptionPainter::Invalidate();
	PaintCaption();
}

void CTopCaption::LoadBitmaps()
{
	VERIFY( m_PinnedBitmap.Attach((HBITMAP) LoadImage(AfxGetResourceHandle(), MAKEINTRESOURCE(IDB_PINNED_BITMAP), 
			IMAGE_BITMAP, 0, 0, LR_LOADMAP3DCOLORS)));
	VERIFY( m_UnPinnedBitmap.Attach((HBITMAP) LoadImage(AfxGetResourceHandle(), MAKEINTRESOURCE(IDB_UNPINNED_BITMAP), 
			IMAGE_BITMAP, 0, 0, LR_LOADMAP3DCOLORS)));
}

int CTopCaption::DrawButtons(const PAINTCAP& pc)
{
	ASSERT(m_pWndHooked);
	CWnd& wnd = *m_pWndHooked;
	DWORD dwStyle = wnd.GetStyle();
	if (!(dwStyle & WS_CAPTION))
		return 0;

	int butWidth = CCaptionPainter::DrawButtons( pc );

	ASSERT(pc.m_pDC);
	CDC& dc = *pc.m_pDC;

	int cxIcon = GetSystemMetrics(SM_CXSIZE);
	int cyIcon = GetSystemMetrics(SM_CYSIZE);

	// Draw caption buttons. These are all drawn inside a rectangle
	// of dimensions SM_CXSIZE by SM_CYSIZE
	CRect rc(0, 0, cxIcon, cyIcon);
	rc += CPoint(pc.m_szCaption.cx-cxIcon, 0);	// move right
	// Close box has a 2 pixel border on all sides but left, which is zero
	rc.DeflateRect(0,2);
	rc.right -= 2;
	rc -= CPoint( butWidth, 0 );

	if ( m_bDepressed )
	{
		dc.DrawFrameControl(&rc, DFC_BUTTON, DFCS_BUTTONPUSH | DFCS_PUSHED );
		rc += CPoint( 1, 1 );
	}
	else
	{
		dc.DrawFrameControl(&rc, DFC_BUTTON, DFCS_BUTTONPUSH);
	}

	CDC dcMem;									// memory DC
	dcMem.CreateCompatibleDC(&dc);		// ...create it

	CBitmap* pOldBitmap = dcMem.SelectObject( 
		m_bButtonPushed ? &m_PinnedBitmap : &m_UnPinnedBitmap );	// select bitmap into memory DC
	
	m_rc = rc;							// allow for easy hit testing
	rc -= CRect( 1, 1, 2, 2 );		// shink to avoid the boarder
	// blast bits to screen
	dc.StretchBlt( rc.left, rc.top, rc.Width(), rc.Height(), &dcMem, 0, 0, 15, 15, SRCCOPY );
	dcMem.SelectObject(pOldBitmap); // restore DC

	return butWidth + CPoint(cxIcon-2,0).x;
}

LRESULT CTopCaption::WindowProc(UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_NCLBUTTONDOWN:
			{
				OnNcLButtonDown( (UINT)wParam, CPoint((DWORD)lParam) );
				return 0;
			}
		case WM_LBUTTONUP:
			{
				OnLButtonUp( (UINT)wParam, CPoint((DWORD)lParam) );
				return 0;
			}
		case WM_MOUSEMOVE:
			{
				OnMouseMove( (UINT)wParam, CPoint((DWORD)lParam) );
				return 0;
			}
		case WM_SYSCOLORCHANGE:
			{
				ReloadBitmaps();
				return 0;
			}
	}
	return CCaptionPainter::WindowProc(msg, wParam, lParam);
}

void CTopCaption::set_topmost_attribute( int want_topmost )
{
	ASSERT(m_pWndHooked);
	CWnd& wnd = *m_pWndHooked;
	ASSERT( ( want_topmost == 1 ) || ( want_topmost == 0 ) );
	wnd.SetWindowPos( want_topmost ? &CWnd::wndTopMost : &CWnd::wndNoTopMost, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE );
}

bool CTopCaption::ScreenPointOverButton( CPoint pt )
{
	ASSERT(m_pWndHooked);
	CWnd& wnd = *m_pWndHooked;

	CRect winRc;
	wnd.GetWindowRect( winRc );
	CRect rc( Rect() );
	rc += winRc.TopLeft();		// convert button rect to screen coords
	// Use the CaptionRect to figure out the width of whatever the current window boarder is.
	CCaptionRect cap(wnd);
	rc += cap.TopLeft();

	return rc.PtInRect( pt ) != 0;
}

bool CTopCaption::PointOverButton( CPoint pt )
{
	ASSERT(m_pWndHooked);
	CWnd& wnd = *m_pWndHooked;

	wnd.ClientToScreen( &pt );
	return ScreenPointOverButton( pt );
}

void CTopCaption::OnNcLButtonDown(UINT /* nHitTest */, CPoint point) 
{
	if ( ScreenPointOverButton( point ) )
	{
		ASSERT(m_pWndHooked);
		CWnd& wnd = *m_pWndHooked;
		wnd.SetCapture();
		DrawDepressedButton(true);
	}
	else
		Default();
}

void CTopCaption::OnLButtonUp(UINT /* nFlags */, CPoint point) 
{
	ASSERT(m_pWndHooked);
//	CWnd& wnd = *m_pWndHooked;
	ReleaseCapture();

	if ( PointOverButton( point ) )
		PushButton();
	else
		Default();
}

void CTopCaption::OnMouseMove(UINT /* nFlags */, CPoint point) 
{
	DrawDepressedButton( PointOverButton( point ) );
	Default();
}

