//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Includes.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_INCLUDTYPE                  129
#define IDD_SETPATH                     130
#define IDB_TREEBMP                     131
#define IDB_PINNED_BITMAP               132
#define IDB_UNPINNED_BITMAP             133
#define IDD_FIND                        133
#define IDC_PATH                        1001
#define IDC_SYSPATH                     1001
#define IDC_DEPTH                       1002
#define IDC_SPIN1                       1003
#define IDC_FILEPATH                    1004
#define IDC_HYPERLINK                   1004
#define IDC_EDIT                        1005
#define IDC_CHECK                       1006
#define IDC_RICHEDIT                    1007
#define ID_FILE_INCLUDEPATH             32771
#define ID_EDIT_FIND_NEXT               32773
#define ID_EDIT_RESCAN                  32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
