// DlgSetPath.cpp : implementation file
//

#include "stdafx.h"
#include "includes.h"
#include "DlgSetPath.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgSetPath dialog


CDlgSetPath::CDlgSetPath(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSetPath::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgSetPath)
	m_IncPath = _T("");
	m_Depth = 0;
	m_FilePath = _T("");
	m_SysPath = _T("");
	//}}AFX_DATA_INIT
}


void CDlgSetPath::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgSetPath)
	DDX_Control(pDX, IDC_SPIN1, m_Spin);
	DDX_Text(pDX, IDC_PATH, m_IncPath);
	DDX_Text(pDX, IDC_DEPTH, m_Depth);
	DDV_MinMaxInt(pDX, m_Depth, 1, 50);
	DDX_Text(pDX, IDC_FILEPATH, m_FilePath);
	DDX_Text(pDX, IDC_SYSPATH, m_SysPath);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSetPath, CDialog)
	//{{AFX_MSG_MAP(CDlgSetPath)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgSetPath message handlers


BOOL CDlgSetPath::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_Spin.SetRange(1, 50);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
