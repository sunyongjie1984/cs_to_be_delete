#ifndef __ITEM_H__
#define __ITEM_H__

#if _MSC_VER >= 1000
	#pragma once
#endif // _MSC_VER >= 1000

class CItem
{
	std::string name;
	std::string fullName;
	int depth;
public:
	CItem() : depth(0) {}
	CItem( const std::string & s, const std::string &f, int i ) : name(s), fullName(f), depth(i) {}
	CItem( const CItem & i ) : name(i.name), fullName(i.fullName), depth(i.depth) {}
	CItem & operator=( const CItem & i ) { name = i.name; fullName = i.fullName; depth = i.depth; return *this; }
	
	const std::string & Name() const { return name; }
	const std::string & FullName() const { return fullName; }
	const Depth() const { return depth; }
	virtual void Dump( CDumpContext& dc ) const;
};

void AFXAPI DumpElements(CDumpContext& dc, const CItem * pElements, int nCount);

#endif

