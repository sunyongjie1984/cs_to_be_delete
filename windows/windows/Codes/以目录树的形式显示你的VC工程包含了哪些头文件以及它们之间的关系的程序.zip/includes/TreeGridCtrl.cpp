// TreeGridCtrl.cpp: implementation of the CTreeGridCtrl class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "includes.h"
#include "TreeGridCtrl.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CTreeGridCtrl, CSuperGridCtrl)
	//{{AFX_MSG_MAP(CTreeGridCtrl)
	ON_WM_LBUTTONUP()
	ON_NOTIFY_REFLECT(LVN_BEGINDRAG, OnBegindrag)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CTreeGridCtrl::CTreeGridCtrl()
{

}

CTreeGridCtrl::~CTreeGridCtrl()
{

}

int CTreeGridCtrl::GetIcon(const CTreeItem* /* pItem */)
{
	return 2;
}

CTreeGridCtrl::CTreeItem* CTreeGridCtrl::SearchEx( CTreeItem *pStartPosition, Regexp & regItem )
{
	CItemInfo* lp = GetData(pStartPosition);
	CString strData = lp->GetItemText();
	if( regItem.Match( strData ) )
	{
		return pStartPosition;
	}

	POSITION pos = GetHeadPosition(pStartPosition);
	while (pos)
	{
		CTreeItem *pChild = GetNextChild(pStartPosition, pos);
		CItemInfo* lp = GetData(pChild);
		CString strData = lp->GetItemText();
		if( regItem.Match( strData ) )
		{
			return pChild;
		}

		pChild = SearchEx( pChild, regItem );
		if(pChild!=NULL)
			return pChild;
	}
	return NULL;
}

void CTreeGridCtrl::OnLButtonUp( UINT nFlags, CPoint point )
{
	GetParent()->SendMessage( WM_LBUTTONUP_REFLECT, (WPARAM)nFlags, POINTTOPOINTS(point) );
	CSuperGridCtrl::OnLButtonUp(nFlags, point);
}

void CTreeGridCtrl::OnBegindrag(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	if(pNMListView->iItem!=-1)
		GetParent()->SendMessage( WM_BEGINDRAG_REFLECT, (WPARAM)pNMListView->iItem, POINTTOPOINTS(pNMListView->ptAction) );

	*pResult = 0;
}

CImageList *CTreeGridCtrl::CreateDragImageEx( int nItem )
{
    CImageList *pList = new CImageList;          
	//get image index
	LV_ITEM lvItem;
	lvItem.mask =  LVIF_IMAGE;
	lvItem.iItem = nItem;
	lvItem.iSubItem = 0;
	GetItem(&lvItem);

	CRect rc;
	GetItemRect(nItem, &rc, LVIR_BOUNDS);         

	CString str;
	str=GetItemText(nItem, 0);
	CFont *pFont = GetFont();

	rc.OffsetRect(-rc.left, -rc.top);            
	rc.right = GetColumnWidth(0);                
	pList->Create(rc.Width(), rc.Height(),ILC_COLOR24| ILC_MASK , 1, 1);
	CDC *pDC = GetDC();                          
	if( pDC )
	{
		CDC dc;	      
		dc.CreateCompatibleDC(pDC);      
		CBitmap bmpMap;
		bmpMap.CreateCompatibleBitmap(pDC, rc.Width(), rc.Height());

		CBitmap *pOldBmp = dc.SelectObject(&bmpMap);
		CFont *pOldFont = dc.SelectObject(pFont);
		dc.FillSolidRect(rc, GetSysColor(COLOR_WINDOW));
		dc.TextOut(0, 0, str);
		dc.SelectObject(pOldFont);
		dc.SelectObject(pOldBmp);                 
		pList->Add(&bmpMap, RGB(255,255,255));
		ReleaseDC(pDC);   
	}   
	return pList;
}

