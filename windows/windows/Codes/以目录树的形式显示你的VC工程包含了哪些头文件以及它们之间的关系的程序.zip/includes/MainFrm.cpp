// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Includes.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifndef COLOR_GRADIENTACTIVECAPTION
#define COLOR_GRADIENTACTIVECAPTION     27
#define COLOR_GRADIENTINACTIVECAPTION   28
#endif

const UINT WM_PAINTMYCAPTION = WM_USER;

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_MESSAGE(WM_PAINTMYCAPTION, OnPaintMyCaption)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
	: m_bFirstTime(true),
	m_pfnGradientFill(0)
{
	// used to get at the GradientFill routine on Win2K & Win98
	m_hLibrary = LoadLibrary( "msimg32.dll" );
	if ( m_hLibrary )
	{
		m_pfnGradientFill = (PFNGRADFILL)GetProcAddress( m_hLibrary, "GradientFill" );
	}
}

CMainFrame::~CMainFrame()
{
	if ( m_hLibrary )
		FreeLibrary( m_hLibrary );
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	// Install caption painter
	m_capp.Install(this, WM_PAINTMYCAPTION);
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFrameWnd::PreCreateWindow(cs);
}

// Private MFC function only sets the title if it's different
//
extern void AFXAPI AfxSetWindowText(HWND, LPCTSTR);

//////////////////
// Override to change title--app name first, then doc name, which is
// the opposite of the normal MFC way.
//
void CMainFrame::OnUpdateFrameTitle(BOOL /* bAddToTitle */)
{
	AfxSetWindowText(m_hWnd, m_strTitle + " " + GetDocTitle());
}

//////////////////
// Get doc title: I use full path name or "untitled"
//
CString CMainFrame::GetDocTitle()
{
	CString s;
	CFrameWnd *pFrame = GetActiveFrame();
	ASSERT(pFrame);
	CDocument * pDoc = pFrame->GetActiveDocument();
	if (pDoc)
		s = pDoc->GetTitle();
	return s;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

const TCHAR szPosition[] = _T( "Position" );
const TCHAR szWindow[] = _T( "Window" );
const TCHAR szState[] = _T( "State" );
const TCHAR szPinned[] = _T( "Pinned" );

BOOL CMainFrame::Save()
{
	WINDOWPLACEMENT wndpl;
	wndpl.length = sizeof(WINDOWPLACEMENT);
	GetWindowPlacement(&wndpl);
	
	CString text, state;
	text.Format( _T( "%04d %04d %04d %04d" ), wndpl.rcNormalPosition.left, wndpl.rcNormalPosition.top,
		wndpl.rcNormalPosition.right, wndpl.rcNormalPosition.bottom);
	state.Format( _T( "%d" ), wndpl.showCmd  );

	if ( GetActiveView() && GetActiveView()->GetDocument() )
	{
		CString section( szWindow );
		AfxGetApp()->WriteProfileString( szPosition, section, text );
		AfxGetApp()->WriteProfileString( szPosition, section + szState, state );
		AfxGetApp()->WriteProfileInt( szPosition, section + szPinned, m_capp.ButtonPushed() );
	}
	return FALSE;
}

BOOL CMainFrame::Load(int & nCmdShow)
{
	if (m_bFirstTime)
	{
		m_bFirstTime = false;

		CString section( szWindow );
		CString text, state;
		text = AfxGetApp()->GetProfileString( szPosition, section );

		if (!text.IsEmpty())
		{
			CRect rect;
			rect.left = atoi((LPCTSTR) text);
			rect.top = atoi((LPCTSTR) text + 5);
			rect.right = atoi((LPCTSTR) text + 10);
			rect.bottom = atoi((LPCTSTR) text + 15);

			state = AfxGetApp()->GetProfileString( szPosition, section + szState );
			int pushed = AfxGetApp()->GetProfileInt( szPosition, section + szPinned, 0 );

			nCmdShow = SW_NORMAL;
			if ( state.GetLength() )
			{
				int show = atoi( (LPCSTR) state );
				if ( show == SW_MAXIMIZE )
					nCmdShow = show;
			}

			UINT            flags;
			WINDOWPLACEMENT wndpl;
			flags = 0;
			
			wndpl.length = sizeof(WINDOWPLACEMENT);
			wndpl.showCmd = nCmdShow;
			wndpl.flags = flags;
			wndpl.ptMinPosition = CPoint(0, 0);
			wndpl.ptMaxPosition = CPoint(-::GetSystemMetrics(SM_CXBORDER),
											-::GetSystemMetrics(SM_CYBORDER));
			wndpl.rcNormalPosition = rect;
			
			// sets window's position and iconized/maximized status
			/* BOOL bRet = */ SetWindowPlacement(&wndpl);

			m_capp.SetButtonPushed( pushed != 0 );
		}
	}
	return FALSE;
}

void CMainFrame::OnDestroy() 
{
	CFrameWnd::OnDestroy();
	Save();
}

void CMainFrame::ActivateFrame(int nCmdShow) 
{
	Load( nCmdShow );
	CFrameWnd::ActivateFrame(nCmdShow);
}

#define COLOR_WHITE RGB(255,255,255)
#define COLOR_BLACK RGB(0,0,0)
#define NCOLORSHADES 64		// this many shades in gradient

//////////////////
// Paint custom caption.
// This is the function that actually does the shading. It creates a
// bitmap that's used to paint the caption. It looks horrible, but it's
// just a lot of bit-twiddling GDI stuff.
//
LRESULT CMainFrame::OnPaintMyCaption(WPARAM bActive, LPARAM lParam)
{
	if (lParam == 0) {
		// lParam = 0 means system setting change: invalidate fonts.
		m_fontCaption.DeleteObject();
		m_fontAcme.DeleteObject();
		return 0;
	}

	const PAINTCAP& pc = *((PAINTCAP*)lParam);
	ASSERT(pc.m_pDC);
	CDC& dc = *pc.m_pDC;

	int cxCap = pc.m_szCaption.cx;
	int cyCap = pc.m_szCaption.cy;

	if (!bActive) {
		COLORREF clrRt = GetSysColor(COLOR_GRADIENTINACTIVECAPTION);	// rightmost background color
		if ( (DWORD)clrRt == 0 )
		{
			// Inactive caption: don't do shading, just fill w/bg color
			CTopCaption::PaintRect(dc, 0, 0, cxCap, cyCap, GetSysColor(COLOR_INACTIVECAPTION));
		}
		else
		{
			ShadeRect( dc, GetSysColor(COLOR_INACTIVECAPTION), clrRt, CRect( 0, 0, cxCap, cyCap ) );
		}

	} else {
		COLORREF clrRt = GetSysColor(COLOR_GRADIENTACTIVECAPTION);	// rightmost background color
		if ( (DWORD)clrRt == 0 )
		{
			// Active caption: do shading
			//
			COLORREF clrBG = GetSysColor(COLOR_ACTIVECAPTION); // background color
			int r = GetRValue(clrBG);				// red..
			int g = GetGValue(clrBG);				// ..green
			int b = GetBValue(clrBG);				// ..blue color vals
			int x = 5*cxCap/6;						// start 5/6 of the way right
			int w = x;									// width of area to shade
			int xDelta= 1;//max(w/NCOLORSHADES,1);	// width of one shade band

			// Paint far right 1/6 of caption the background color
			CTopCaption::PaintRect(dc, x, 0, cxCap-x, cyCap, clrBG);

			// Compute new color brush for each band from x to x + xDelta.
			// Excel uses a linear algorithm from black to normal, i.e.
			//
			//		color = CaptionColor * r
			//
			// where r is the ratio x/w, which ranges from 0 (x=0, left)
			// to 1 (x=w, right). This results in a mostly black title bar,
			// since we humans don't distinguish dark colors as well as light
			// ones. So instead, I use the formula
			//
			//		color = CaptionColor * [1-(1-r)^2]
			//
			// which still equals black when r=0 and CaptionColor when r=1,
			// but spends more time near CaptionColor. For example, when r=.5,
			// the multiplier is [1-(1-.5)^2] = .75, closer to 1 than .5.
			// I leave the algebra to the reader to verify that the above formula
			// is equivalent to
			//
			//		color = CaptionColor - (CaptionColor*(w-x)*(w-x))/(w*w)
			//
			// The computation looks horrendous, but it's only done once each
			// time the caption changes size; thereafter BitBlt'ed to the screen.
			//
			while (x > xDelta) {						// paint bands right to left
				x -= xDelta;							// next band
				int wmx2 = (w-x)*(w-x);				// w minus x squared
				int w2  = w*w;							// w squared
				CTopCaption::PaintRect(dc, x, 0, xDelta, cyCap,	
					RGB(r-(r*wmx2)/w2, g-(g*wmx2)/w2, b-(b*wmx2)/w2));
			}

			CTopCaption::PaintRect(dc,0,0,x,cyCap,COLOR_BLACK);  // whatever's left ==> black
		}
		else
			ShadeRect( dc, GetSysColor(COLOR_ACTIVECAPTION), clrRt, CRect( 0, 0, cxCap, cyCap ) );
	}

	// Use caption painter to draw icon and buttons
	int cxIcon  = m_capp.DrawIcon(pc);
	int cxButns = m_capp.DrawButtons(pc);

	// Now draw text. First Create fonts if needed
	//
	if (!m_fontCaption.m_hObject)
		CreateFonts();

	// Paint "ACME TEXT" using ACME font, always white
	CString s = m_strTitle + " ";				// app title
	CRect rc(CPoint(0,0), pc.m_szCaption); // text rectangle
	rc.left  += cxIcon+2;						// start after icon
	rc.right -= cxButns;							// don't draw past buttons
	dc.SetBkMode(TRANSPARENT);					// draw on top of our shading
	dc.SetTextColor(COLOR_WHITE);				// always white
	CFont* pOldFont = dc.SelectObject(&m_fontAcme);
	dc.DrawText(s, &rc, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);

	// Now paint window title (caption)
	rc.left += dc.GetTextExtent(s).cx;		// move past "ACME EDIT "
	if (rc.right > rc.left) {					// if still room:
		COLORREF clrText;							// text color
		if (bActive) {
			// Excel always uses white for title color, but I use the user's
			// selected color--unless it's too dark, then I use white.
			//
			clrText = GetSysColor(COLOR_CAPTIONTEXT);
			if (CTopCaption::GetLuminosity(clrText) < 90) // good from trial & error
				clrText = COLOR_WHITE;
		} else
			clrText = GetSysColor(COLOR_INACTIVECAPTIONTEXT);

		// Paint the text. Use DT_END_ELLIPSIS to draw ellipsis if text
		// won't fit. Win32 sure is friendly!
		//
		dc.SetTextColor(clrText);
		dc.SelectObject(&m_fontCaption);
		dc.DrawText(GetDocTitle(), &rc,
			DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);
	} 

	// Restore DC
	dc.SelectObject(pOldFont);
	return 0;
}

void CMainFrame::ShadeRect( CDC & dc, COLORREF colLeft, COLORREF colRight, const CRect & rc )
{
	if ( m_pfnGradientFill )		// on Win2K or Win98 only
	{
		TRIVERTEX        vert[2];
		GRADIENT_RECT    gRect;
		vert[0].x      = rc.left;
		vert[0].y      = rc.top;
		vert[0].Red    = GetRValue( colLeft ) << 8;
		vert[0].Green  = GetGValue( colLeft ) << 8;
		vert[0].Blue   = GetBValue( colLeft ) << 8;
		vert[0].Alpha  = 0x0000;

		vert[1].x      = rc.right;
		vert[1].y      = rc.bottom; 
		vert[1].Red    = GetRValue( colRight ) << 8;
		vert[1].Green  = GetGValue( colRight ) << 8;
		vert[1].Blue   = GetBValue( colRight ) << 8;
		vert[1].Alpha  = 0x0000;

		gRect.UpperLeft  = 0;
		gRect.LowerRight = 1;

		m_pfnGradientFill( dc, vert, 2, &gRect, 1, GRADIENT_FILL_RECT_H );
	}
	else
	{
		int width = rc.Width();
		double	r = GetRValue( colLeft ),
				g = GetGValue( colLeft ),
				b = GetBValue( colLeft ), 
				rd = double( GetRValue( colRight ) - r ) / double(width),
				gd = double( GetGValue( colRight ) - g ) / double(width), 
				bd = double( GetBValue( colRight ) - b ) / double(width);

		for ( int x=0; x<width; x++ )
		{
			CTopCaption::PaintRect( dc, x, rc.top, 1, rc.Height(), RGB(BYTE(r),BYTE(g),BYTE(b)) );
			r+=rd; g+=gd; b+=bd;
		}
	}
}

//////////////////
// Helper function to build the fonts I need.
//
void CMainFrame::CreateFonts()
{
	// Get current system caption font, just to get its size
	//
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(ncm);
	VERIFY(SystemParametersInfo(SPI_GETNONCLIENTMETRICS, 0, &ncm, 0));
	m_fontCaption.CreateFontIndirect(&ncm.lfCaptionFont);

	// Create "ACME" font same size as caption font, but use Book Antiqua
	//
	m_fontAcme.CreatePointFont(120, "Book Antiqua"); // 12 pt for now
	LOGFONT lf;
	m_fontAcme.GetLogFont(&lf);					// get font info
	m_fontAcme.DeleteObject();						// I don't really want 12 pt
	lf.lfWeight|=FW_BOLD;							// make bold
	lf.lfHeight = ncm.lfCaptionFont.lfHeight; // same height as caption font
	m_fontAcme.CreateFontIndirect(&lf);			// create font
}
