// IncludesDoc.cpp : implementation of the CIncludesDoc class
//

#include "stdafx.h"
#include <io.h>
#include "Includes.h"
#include "split_string.h"
#include <direct.h>

#include "IncludesDoc.h"

#if defined( _DEBUG )
	#define _TIME_IT 1
#endif //_DEBUG

#if defined( _TIME_IT )
	#include "Clock.h"
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

Regexp CIncludesDoc::m_regexp( "^[\t ]*#[\t ]*include[\t ]*([<\"])([^>\"]*)([>\"])" );

/////////////////////////////////////////////////////////////////////////////
// CIncludesDoc

IMPLEMENT_DYNCREATE(CIncludesDoc, CDocument)

BEGIN_MESSAGE_MAP(CIncludesDoc, CDocument)
	//{{AFX_MSG_MAP(CIncludesDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIncludesDoc construction/destruction

CIncludesDoc::CIncludesDoc()
	: m_incType(0), m_once(TRUE)
{
}

CIncludesDoc::~CIncludesDoc()
{
}

BOOL CIncludesDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CIncludesDoc diagnostics

#ifdef _DEBUG
void CIncludesDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CIncludesDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CIncludesDoc commands

BOOL CIncludesDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	if (IsModified())
		TRACE0("Warning: OnOpenDocument replaces an unsaved document.\n");

	DeleteContents();
	Scan( lpszPathName );

	return TRUE;
}

void CIncludesDoc::Rescan()
{
	Scan( m_fileName.c_str() );
}

void CIncludesDoc::Scan( LPCTSTR lpszPathName )
{
	prepareInc( GetApp()->FileIncludePath(), GetApp()->SysIncludePath() );
	m_iaData.clear();
	m_FileList.Empty();

	m_fileName = m_strPathName = lpszPathName;

	if ( m_fileName.length() )
	{
		std::string path = m_fileName.substr( 0, m_fileName.rfind('\\' )  );
		std::string name = m_fileName.substr( ( m_fileName.rfind('\\' ) + 1 ) );
		_chdir( path.c_str() );

#if defined( _TIME_IT )
		CClock Clock;
#endif
		scan( name, 0 );
#if defined( _TIME_IT )
		CDebugStream debug;
		debug << "Scanning\t" << name << "\t" << setformat( "%2.4f" ) << Clock.Stop()*1000 << "ms" << std::endl;
#endif
	}
	UpdateAllViews(0);
}

void CIncludesDoc::scan( const std::string & fname, int level )
{
	if ( level > GetApp()->Depth() )
		return;

	if ( m_once && m_FileList.fileProcessed( fname ) )
		return;

	std::string fullName( findFile( fname ) );

	m_iaData.push_back( CItem( fname, fullName, level ) );

	FILE *fp;

	if ( fullName.empty() || ( ( fp = fopen( fullName.c_str(), "r" ) ) == 0 ) )
		return;

	while( !feof( fp ) )
	{
		if ( fgets( LineBuffer().data, LineBuffer().size(), fp ) != LineBuffer().data )
			break;

		check_line( LineBuffer().data, level );
	}
	fclose( fp );
}

void CIncludesDoc::check_line( const char * p, int level )
{
	if ( m_regexp.Match( p ) && m_regexp.SubStrings() == 3 )
	{
		// m_incType allows for us to only process user includes as opposed to system includes
		// i.e. #include ".*" rather than #include <.*>
		// right now there is no GUI option to allow setting of this.
//		if ( m_regexp[1] == "<" && m_incType )
//			return;
		scan( (LPCTSTR)m_regexp[2], level + 1 );
	}
}

void CIncludesDoc::prepareInc( const std::string & incPath1, const std::string & incPath2 )
{
	m_inc.clear();
	m_inc.push_back( ".\\" );

	split_string<StringVector> array1( incPath1, ";," );
	split_string<StringVector> array2( incPath2, ";," );

	for( StringVector::const_iterator it = array1.begin(); it != array1.end(); it++ )
		m_inc.push_back( (*it).c_str() );

	for( it = array2.begin(); it != array2.end(); it++ )
		m_inc.push_back( (*it).c_str() );
}	

std::string CIncludesDoc::findFile( const std::string & name )
{
	for( StringVector::const_iterator it = m_inc.begin(); it != m_inc.end(); it++ )
	{
		std::string fullName( (*it) + "\\" + name );
		if ( _access( fullName.c_str(), 0 ) != -1 )
		{
			char full[_MAX_PATH];
			if( _fullpath( full, fullName.c_str(), _MAX_PATH ) != NULL )
				return full;
			else
				return fullName;
		}
	}
	return "";
}

void CFileList::Empty()
{
	m_files.clear();
}

bool CFileList::fileProcessed( const std::string & fname )
{
	std::set<std::string>::const_iterator it = m_files.find( fname );
	if( it != m_files.end() )
		return true;
	
	m_files.insert( fname );	// not found so add it
	return false;
}

