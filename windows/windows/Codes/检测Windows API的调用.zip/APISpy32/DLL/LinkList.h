#ifndef LINKLIST_H
#define LINKLIST_H

#include "APISpy32.h"

tagAPIInfo *AddItem();
void RemoveItem(tagAPIInfo *Item);

extern tagAPIInfo *Head;
extern tagAPIInfo *Tail;

#endif
