// SCBDemo2View.cpp : implementation of the CSCBDemo2View class
//

#include "stdafx.h"
#include "SCBDemo2.h"

#include "SCBDemo2Doc.h"
#include "SCBDemo2View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSCBDemo2View

IMPLEMENT_DYNCREATE(CSCBDemo2View, CEditView)

BEGIN_MESSAGE_MAP(CSCBDemo2View, CEditView)
	//{{AFX_MSG_MAP(CSCBDemo2View)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSCBDemo2View construction/destruction

CSCBDemo2View::CSCBDemo2View()
{
	// TODO: add construction code here

}

CSCBDemo2View::~CSCBDemo2View()
{
}

BOOL CSCBDemo2View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Enable word-wrapping

	return bPreCreated;
}

/////////////////////////////////////////////////////////////////////////////
// CSCBDemo2View drawing

void CSCBDemo2View::OnDraw(CDC* pDC)
{
	UNUSED_ALWAYS(pDC);
	
	CSCBDemo2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CSCBDemo2View diagnostics

#ifdef _DEBUG
void CSCBDemo2View::AssertValid() const
{
	CEditView::AssertValid();
}

void CSCBDemo2View::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CSCBDemo2Doc* CSCBDemo2View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSCBDemo2Doc)));
	return (CSCBDemo2Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSCBDemo2View message handlers
