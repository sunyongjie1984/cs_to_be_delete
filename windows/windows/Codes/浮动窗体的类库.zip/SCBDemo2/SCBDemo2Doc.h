// SCBDemo2Doc.h : interface of the CSCBDemo2Doc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCBDEMO2DOC_H__8FE8F4AA_D8B7_11D3_B1BA_0060520A86B9__INCLUDED_)
#define AFX_SCBDEMO2DOC_H__8FE8F4AA_D8B7_11D3_B1BA_0060520A86B9__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CSCBDemo2Doc : public CDocument
{
protected: // create from serialization only
	CSCBDemo2Doc();
	DECLARE_DYNCREATE(CSCBDemo2Doc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSCBDemo2Doc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSCBDemo2Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSCBDemo2Doc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCBDEMO2DOC_H__8FE8F4AA_D8B7_11D3_B1BA_0060520A86B9__INCLUDED_)
