// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__8FE8F4A6_D8B7_11D3_B1BA_0060520A86B9__INCLUDED_)
#define AFX_STDAFX_H__8FE8F4A6_D8B7_11D3_B1BA_0060520A86B9__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#define _SCB_REPLACE_MINIFRAME
//#define _SCB_MINIFRAME_CAPTION
#include "..\src\sizecbar.h"
#include "..\src\scbarg.h"
#include "..\src\scbarcf.h"
#define baseCMyBar CSizingControlBarCF

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__8FE8F4A6_D8B7_11D3_B1BA_0060520A86B9__INCLUDED_)
