// SCBDemo2Doc.cpp : implementation of the CSCBDemo2Doc class
//

#include "stdafx.h"
#include "SCBDemo2.h"

#include "SCBDemo2Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSCBDemo2Doc

IMPLEMENT_DYNCREATE(CSCBDemo2Doc, CDocument)

BEGIN_MESSAGE_MAP(CSCBDemo2Doc, CDocument)
	//{{AFX_MSG_MAP(CSCBDemo2Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSCBDemo2Doc construction/destruction

CSCBDemo2Doc::CSCBDemo2Doc()
{
	// TODO: add one-time construction code here

}

CSCBDemo2Doc::~CSCBDemo2Doc()
{
}

BOOL CSCBDemo2Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	((CEditView*)m_viewList.GetHead())->SetWindowText(NULL);

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CSCBDemo2Doc serialization

void CSCBDemo2Doc::Serialize(CArchive& ar)
{
	// CEditView contains an edit control which handles all serialization
	((CEditView*)m_viewList.GetHead())->SerializeRaw(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CSCBDemo2Doc diagnostics

#ifdef _DEBUG
void CSCBDemo2Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSCBDemo2Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSCBDemo2Doc commands
