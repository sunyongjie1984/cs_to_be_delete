// SCBDemo2View.h : interface of the CSCBDemo2View class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCBDEMO2VIEW_H__8FE8F4AC_D8B7_11D3_B1BA_0060520A86B9__INCLUDED_)
#define AFX_SCBDEMO2VIEW_H__8FE8F4AC_D8B7_11D3_B1BA_0060520A86B9__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CSCBDemo2View : public CEditView
{
protected: // create from serialization only
	CSCBDemo2View();
	DECLARE_DYNCREATE(CSCBDemo2View)

// Attributes
public:
	CSCBDemo2Doc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSCBDemo2View)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSCBDemo2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSCBDemo2View)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SCBDemo2View.cpp
inline CSCBDemo2Doc* CSCBDemo2View::GetDocument()
   { return (CSCBDemo2Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCBDEMO2VIEW_H__8FE8F4AC_D8B7_11D3_B1BA_0060520A86B9__INCLUDED_)
