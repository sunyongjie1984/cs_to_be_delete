//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ListBoxExDemo.rc
//
#define IDD_LISTBOXEXDEMO_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_LIST                        1000
#define IDC_EDITBUTTON                  1003
#define IDC_LISTBUDDY2                  1007
#define IDC_LISTBUDDY                   1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
