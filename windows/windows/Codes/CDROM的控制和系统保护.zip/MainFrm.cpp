// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "CDRom.h"

#include "MainFrm.h"
#include "PwdDlg.h"
#include "KeyDlg.h"

#define WM_TRAYNOTIFY WM_USER + 100

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_MESSAGE(WM_TRAYNOTIFY, OnTrayNotification)
	ON_MESSAGE(WM_HOTKEY,OnHotKey)
	ON_WM_DESTROY()
	ON_COMMAND(IDM_CDOUT, OnCdout)
	ON_COMMAND(IDM_CDIN, OnCdin)
	ON_COMMAND(IDM_LOCK, OnLock)
	ON_COMMAND(ID_SHUT_DOWN, OnShutDown)
	ON_COMMAND(ID_POWER_OFF, OnPowerOff)
	ON_COMMAND(ID_SET_KEY, OnSetKey)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_hIcon[0]=AfxGetApp()->LoadIcon(IDI_ICON1);
	m_hIcon[1]=AfxGetApp()->LoadIcon(IDI_ICON2);
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_TrayIcon.Create(this, 
				IDR_POPUP, 
				_T("�������Ƽ�ϵͳ�ӹ�"), 
				m_hIcon, 
				2, 
				300, 
				WM_TRAYNOTIFY))
	{
		AfxMessageBox(_T("���󣺴���ϵͳͼ��ʧ�ܣ�"), MB_OK | MB_ICONSTOP);
		return -1;
	}

	

	//ע���ȼ�
	RegisterHotKey(m_hWnd,2000,MOD_CONTROL ,VK_F8);
	RegisterHotKey(m_hWnd,2001,0,VK_F11);
	RegisterHotKey(m_hWnd,2002,0,VK_F12);
	

	//����.ini�ļ��Ƿ����
	char windir[256];
	::GetWindowsDirectory(windir,256);
	char *appdir;
	appdir=strcat(windir,"\\");
	appdir=strcat(windir,"cdrom.ini");
	//MessageBox(appdir);
	CFileFind ff;
	if(!ff.FindFile(appdir,0))
	{
		MessageBox("�������ǵ�һ�������ó��������ýӹ�����(������Ϊ��)��","��ӭʹ�øó���");
		CKeyDlg fdlg;
		if(fdlg.DoModal()==IDCANCEL)
			MessageBox("��û���������Ľӹ����룬��ǰ����Ϊ��");
	}
	
	//����ͨ������
	//���ڱ�д��......
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

LRESULT CMainFrame::OnTrayNotification(WPARAM wParam, LPARAM lParam)
{
  //Delegate all the work back to the default implementation in
  //CTrayNotifyIcon.
  return m_TrayIcon.OnTrayNotification(wParam, lParam);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

LRESULT CMainFrame::OnHotKey(WPARAM wParam,LPARAM lParam)
{
	if(wParam==2000)
	{
		CPwdDlg m_dlg;
		m_dlg.DoModal();
	}
	else if(wParam==2001)
	{
		if(mciSendString("set cdaudio door open",NULL,0,NULL)!=0)
			MessageBox("open error!");
	}
	else if(wParam==2002)
	{
		if(mciSendString("set cdaudio door closed",NULL,0,NULL)!=0)
			MessageBox("close error!");
	}
	
	return 0;
}

void CMainFrame::OnDestroy() 
{
	CFrameWnd::OnDestroy();
	
	// TODO: Add your message handler code here
	UnregisterHotKey(m_hWnd,2000);
	UnregisterHotKey(m_hWnd,2001);
	UnregisterHotKey(m_hWnd,2002);
	UnregisterHotKey(m_hWnd,2003);
}

void CMainFrame::OnCdout() 
{
	// TODO: Add your command handler code here
	OnHotKey(2001,0);
}

void CMainFrame::OnCdin() 
{
	// TODO: Add your command handler code here
	OnHotKey(2002,0);
}

void CMainFrame::OnLock() 
{
	// TODO: Add your command handler code here
	OnHotKey(2000,0);
}

void CMainFrame::OnShutDown() 
{
	// TODO: Add your command handler code here
	if(MessageBox("���Ƿ�ȷ��Ҫ�ر�Windowsϵͳ?","�ر�ϵͳ",
		                         MB_ICONWARNING | MB_OKCANCEL | MB_DEFBUTTON2)==IDOK)
								 ::ExitWindowsEx(EWX_SHUTDOWN,0);
}

void CMainFrame::OnPowerOff() 
{
	// TODO: Add your command handler code here
	if(MessageBox("���Ƿ�ȷ��Ҫע��?","�û�ע��",
		                         MB_ICONWARNING | MB_OKCANCEL | MB_DEFBUTTON2)==IDOK)
	{
		::ExitWindowsEx(EWX_POWEROFF,0);
		CMainFrame::DestroyWindow();
	}
}

void CMainFrame::OnSetKey() 
{
	// TODO: Add your command handler code here
	CKeyDlg keydlg;
	keydlg.DoModal();
}




