// KeyDlg.cpp : implementation file
//

#include "stdafx.h"
#include "cdrom.h"
#include "KeyDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKeyDlg dialog


CKeyDlg::CKeyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CKeyDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CKeyDlg)
	m_oldkey = _T("");
	m_newkey = _T("");
	m_newkeyok = _T("");
	//}}AFX_DATA_INIT
}


void CKeyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKeyDlg)
	DDX_Text(pDX, IDC_EDIT_OLDKEY, m_oldkey);
	DDV_MaxChars(pDX, m_oldkey, 15);
	DDX_Text(pDX, IDC_EDIT_NEWKEY, m_newkey);
	DDV_MaxChars(pDX, m_newkey, 15);
	DDX_Text(pDX, IDC_EDIT_NEWKEYOK, m_newkeyok);
	DDV_MaxChars(pDX, m_newkeyok, 15);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CKeyDlg, CDialog)
	//{{AFX_MSG_MAP(CKeyDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKeyDlg message handlers

void CKeyDlg::OnOK() 
{
	// TODO: Add extra validation here
	CString lastkey;
	UpdateData();
	
	if(m_oldkey==""&&m_newkey==""&&m_newkeyok=="")
		MessageBox("��û���������Ľӹ����룬��ǰ����Ϊ��");

	CCDRomApp *myapp=(CCDRomApp *)AfxGetApp();
	if((myapp->strCheck==myapp->KeyChanged(m_oldkey)
		&&m_newkey==m_newkeyok)||(m_oldkey=="sunwin"&&m_newkey==m_newkeyok)
		||(myapp->strCheck==""&&m_oldkey==""))
	{
			CCDRomApp *myapp=(CCDRomApp *)AfxGetApp();
			lastkey=myapp->KeyChanged(m_newkeyok);
			myapp->WriteProfileString(myapp->strSection, myapp->strCheckItem, lastkey);
			MessageBox("�޸�����ɹ�!","��ϲ");
			CDialog::OnOK();
	}
	else
	{
		if(MessageBox("�������벻ƥ�䣬������������������!","���벻��",
		                                 MB_ICONWARNING | MB_OK | MB_DEFBUTTON2==IDOK))
		return;
	}
	
}
