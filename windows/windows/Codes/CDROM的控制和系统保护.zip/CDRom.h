// CDRom.h : main header file for the CDROM application
//

#if !defined(AFX_CDROM_H__F54CB144_6384_11CE_A4A3_5254ABDD9375__INCLUDED_)
#define AFX_CDROM_H__F54CB144_6384_11CE_A4A3_5254ABDD9375__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCDRomApp:
// See CDRom.cpp for the implementation of this class
//

class CCDRomApp : public CWinApp
{
public:
	CCDRomApp();
	CString strCheck;
	CString strCheckItem;
	CString strSection;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCDRomApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

public:
	CString KeyChanged(CString keyin);
	
	//{{AFX_MSG(CCDRomApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CDROM_H__F54CB144_6384_11CE_A4A3_5254ABDD9375__INCLUDED_)
