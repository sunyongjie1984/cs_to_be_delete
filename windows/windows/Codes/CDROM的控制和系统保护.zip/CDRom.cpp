// CDRom.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "CDRom.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCDRomApp

BEGIN_MESSAGE_MAP(CCDRomApp, CWinApp)
	//{{AFX_MSG_MAP(CCDRomApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCDRomApp construction

CCDRomApp::CCDRomApp()
{
	// TODO: add construction code here,
	strSection="Check";
	strCheckItem="����Ȩ����";
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CCDRomApp object

CCDRomApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CCDRomApp initialization
BOOL CCDRomApp::InitInstance()
{

	Enable3dControls();
	
	CMainFrame* pFrame = new CMainFrame;
	m_pMainWnd = pFrame;

	if (!pFrame->Create(NULL, _T("Traytest")))
		return FALSE;

	pFrame->ShowWindow(SW_HIDE);
	pFrame->UpdateWindow();
	
	strCheck=GetProfileString(strSection,strCheckItem,"");

	return TRUE;
}


void CCDRomApp::OnAppAbout() 
{
	// TODO: Add your command handler code here
	::MessageBox(AfxGetMainWnd()->GetSafeHwnd(),"�˳���ֻ�����ںϷ����ϣ�Υ�ߺ���Ը�!!!","����",
		MB_ICONQUESTION);
	SetForegroundWindow(AfxGetMainWnd()->GetSafeHwnd());
}

//����ת������
CString CCDRomApp::KeyChanged(CString keyin)
{
	char keyCheck[50]="1130.0912";
	char tmpCheck[50]="";
	CString keyout;
	for(int i=0;i<(int)strlen(keyin);i++)
	{
		tmpCheck[i] = keyin[i] + keyCheck[i];
	}
	tmpCheck[i]='\0';
	keyout.Format("%s",tmpCheck);

	return keyout;

}
