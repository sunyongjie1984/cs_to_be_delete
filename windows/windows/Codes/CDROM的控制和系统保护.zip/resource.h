//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CDRom.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_POPUP                       128
#define IDI_ICON1                       132
#define IDI_ICON2                       133
#define IDD_PWDDLG                      134
#define IDI_LOCK                        136
#define IDD_KEYDLG                      137
#define IDC_EDIT1                       1003
#define IDC_REROOT                      1005
#define IDC_EDIT_NEWKEY                 1006
#define IDC_EDIT_NEWKEYOK               1007
#define IDC_EDIT_OLDKEY                 1008
#define IDM_OUTIN                       32772
#define IDM_CDOUT                       32773
#define IDM_CDIN                        32774
#define IDM_LOCK                        32775
#define ID_SHUT_DOWN                    32776
#define ID_POWER_OFF                    32778
#define ID_SET_KEY                      32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
