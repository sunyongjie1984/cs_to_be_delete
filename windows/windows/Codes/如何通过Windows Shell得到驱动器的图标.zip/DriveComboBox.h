#if !defined(AFX_DRIVECOMBOBOX_H__F4E7E5A1_DFFB_11D3_A999_9F82958B922F__INCLUDED_)
#define AFX_DRIVECOMBOBOX_H__F4E7E5A1_DFFB_11D3_A999_9F82958B922F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DriveComboBox.h : header file
//
#define DRIVES 0
/////////////////////////////////////////////////////////////////////////////
// CDriveComboBox window

class CDriveComboBox : public CComboBox
{
// Construction
public:
	CDriveComboBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDriveComboBox)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	//}}AFX_VIRTUAL

// Implementation
public:
	CWnd *m_cwndParent;
	UINT m_nMsg;
	BOOL InitBox(UINT res, CWnd *parent,UINT msg);
	CString GetCurDrive();
	virtual ~CDriveComboBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDriveComboBox)
	afx_msg void OnSelchange();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DRIVECOMBOBOX_H__F4E7E5A1_DFFB_11D3_A999_9F82958B922F__INCLUDED_)
