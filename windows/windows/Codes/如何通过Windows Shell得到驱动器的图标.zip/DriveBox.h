// DriveBox.h : main header file for the DRIVEBOX application
//

#if !defined(AFX_DRIVEBOX_H__F4E7E5A6_DFFB_11D3_A999_9F82958B922F__INCLUDED_)
#define AFX_DRIVEBOX_H__F4E7E5A6_DFFB_11D3_A999_9F82958B922F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CDriveBoxApp:
// See DriveBox.cpp for the implementation of this class
//

class CDriveBoxApp : public CWinApp
{
public:
	CDriveBoxApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDriveBoxApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDriveBoxApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DRIVEBOX_H__F4E7E5A6_DFFB_11D3_A999_9F82958B922F__INCLUDED_)
