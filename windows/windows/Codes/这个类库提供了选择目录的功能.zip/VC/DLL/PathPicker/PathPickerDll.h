/////////////////////////////////////////////////////////////////////////////
//FUNCTION
//	Header to define the DLL exports.
//CREATED
//	23-5-1999  19:41:45
//AUTHOR
//	John McTainsh (mctainsh@bit.net.au)
//	..drop me a line if you have any problems.
/////////////////////////////////////////////////////////////////////////////

  
#ifdef __cplusplus
extern "C" {
#endif
 
/////////////////////////////////////////////////////////////////////////////
//FUNCTION
//	Displays the Dialog
//CREATED
//	23-5-1999  19:44:48
//PARAMS
//	hWnd		HWND of parent window calling dialog
//	szTitle		String to appear in the title bar
//	szComment	String to help user (Appears just below titlebar).
//	szPath		Path selected by the dialog.
//	nSize		Max Size of string in Path (Including NULL).
//RETURNS
//	True if a path was selected.
BOOL WINAPI ShowDialog( long hWnd, LPCTSTR szTitle, LPCTSTR szComment, LPTSTR szPath, int nSize );


/////////////////////////////////////////////////////////////////////////////
//FUNCTION
//	Makes a Beep.
//	Always a handy function just to see if things are going well.
//CREATED
//	23-5-1999  19:45:10
//PARAMS
//	
//RETURNS
//
BOOL WINAPI BeepTest();

///////////////////////////////////////////////////////////////////////////////
//DESCRIPTION:
//	Return the Build number of this DLL. (With debug/release suffix)
//CREATED:
//	24-5-1999  15:51:26
//PARAMS:
//	
//RETURN:
//	"20XXX.d"
LPCTSTR WINAPI Build();

	
#ifdef __cplusplus
}
#endif
  