//
// PathPicker.h : main header file for the PATHPICKER DLL
//

#if !defined(AFX_PATHPICKER_H__EAC570A9_10D1_11D3_9FA5_00C0F019557F__INCLUDED_)
#define AFX_PATHPICKER_H__EAC570A9_10D1_11D3_9FA5_00C0F019557F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CPathPickerApp
// See PathPicker.cpp for the implementation of this class
//
class CPathPickerApp : public CWinApp
{
public:
	CPathPickerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPathPickerApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CPathPickerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PATHPICKER_H__EAC570A9_10D1_11D3_9FA5_00C0F019557F__INCLUDED_)
