//
// PathPicker.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "PathPicker.h"								//Defintion for main app and resources
#include "PathPickerDll.h"							//Defintion Exports for this DLL
#include "DlgGetPath.h"								//Definition to get path

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CPathPickerApp
BEGIN_MESSAGE_MAP(CPathPickerApp, CWinApp)
	//{{AFX_MSG_MAP(CPathPickerApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPathPickerApp construction
CPathPickerApp::CPathPickerApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CPathPickerApp object
CPathPickerApp theApp;


/////////////////////////////////////////////////////////////////////////////
//See Header for Help.
extern "C" BOOL WINAPI ShowDialog( long hWnd, LPCTSTR szTitle, LPCTSTR szComment, LPTSTR szPath, int nSize )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	TRACE( _T("ShowDialog( %ld, %s, %s, %p, %d )"),hWnd, szTitle, szComment, szPath, nSize );
	//Get a pointer to the parent window and
	//..Create the object and preset values
	CDlgGetPath dlg( CWnd::FromHandle( (HWND)hWnd ) );
	dlg.SetTitle( szTitle );
	dlg.m_sTopNote = szComment;
	szPath[0] = NULL;
	//Show the dialog and wait for a responce
	if( dlg.DoModal() != IDOK )
		return false;
	//OK pressed so return path (Up to the max charactor size)
	_tcscpy( szPath, dlg.GetPath().Left(nSize-1) );
	return true;
}



/////////////////////////////////////////////////////////////////////////////
//See Header for Help.
extern "C" BOOL WINAPI BeepTest()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	TRACE( _T("BeepTest()") );
	MessageBeep( MB_ICONASTERISK );
	return false;
}


/////////////////////////////////////////////////////////////////////////////
//See Header for Help.
extern "C" LPCTSTR WINAPI Build()
{
#ifdef _DEBUG
	return BUILD_NO _T(".d");
#else
	return BUILD_NO _T(".r");
#endif
}




