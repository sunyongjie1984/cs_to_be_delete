//
// Method2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Method2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////////////////
//Implement Path Picker
//Don't forget to add "PathPicker.Lib" to the Link librays.
#include "..\PathPicker\Release\PathPickerDll.h"							//Definition file

/////////////////////////////////////////////////////////////////////////////
// The one and only application object
CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	// initialize MFC and print and error on failure
	if(!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		return -1;
	}
	//Do the dialog thing
	TCHAR szPath[200];
	ShowDialog( NULL, "Blar.", "Blar blar...", szPath, 199 );
	AfxMessageBox( szPath );

	cerr << _T("So long and thanks for all the fish...");
	return 1;
}


