//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BtnTest.rc
//
#define IDD_BTNTEST_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDB_GLOBE_BUTTON                130
#define IDB_GLOBE_DISABLED              132
#define IDB_FREE_BUTTON                 134
#define IDB_FREE_DISABLED               135
#define IDB_FLAG_BUTTON                 136
#define IDC_HPOINT                      137
#define IDR_BALDIE                      139
#define IDC_PLANE_CURSOR                306
#define IDC_BUTTON1                     1000
#define IDC_GLOBE1                      1000
#define IDC_FREE                        1001
#define IDC_FLAG                        1002
#define IDC_GLOBE2                      1003
#define IDC_GLOBE3                      1004
#define IDC_GLOBE_ENABLE                1006
#define IDC_FREE_ENABLE                 1007
#define IDC_BUTTON2                     1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
