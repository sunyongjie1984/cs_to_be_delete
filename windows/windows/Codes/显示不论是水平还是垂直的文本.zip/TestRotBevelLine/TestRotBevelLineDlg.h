// TestRotBevelLineDlg.h : header file
//

#if !defined(AFX_TESTROTBEVELLINEDLG_H__131121CE_DB81_11D2_BF46_000000000000__INCLUDED_)
#define AFX_TESTROTBEVELLINEDLG_H__131121CE_DB81_11D2_BF46_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CTestRotBevelLineDlg dialog

#include	"../codex/cdxCRotBevelLine.h"

class CTestRotBevelLineDlg : public CDialog
{
// Construction
public:
	CTestRotBevelLineDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTestRotBevelLineDlg)
	enum { IDD = IDD_TESTROTBEVELLINE_DIALOG };
	CButton	m_wndDisable;
	cdxCRotBevelLine	m_bevel9;
	cdxCRotBevelLine	m_bevel8;
	cdxCRotBevelLine	m_bevel7;
	cdxCRotBevelLine	m_bevel6;
	cdxCRotBevelLine	m_bevel5;
	cdxCRotBevelLine	m_bevel4;
	cdxCRotBevelLine	m_bevel3;
	cdxCRotBevelLine	m_bevel2;
	cdxCRotBevelLine	m_bevel;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestRotBevelLineDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTestRotBevelLineDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDisable();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTROTBEVELLINEDLG_H__131121CE_DB81_11D2_BF46_000000000000__INCLUDED_)
