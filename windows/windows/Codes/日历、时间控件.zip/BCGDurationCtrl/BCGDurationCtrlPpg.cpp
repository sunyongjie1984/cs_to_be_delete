// BCGDurationCtrlPpg.cpp : Implementation of the CBCGDurationCtrlPropPage property page class.

#include "stdafx.h"
#include "BCGDurationCtrl.h"
#include "BCGDurationCtrlPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CBCGDurationCtrlPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CBCGDurationCtrlPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CBCGDurationCtrlPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CBCGDurationCtrlPropPage, "BCGDURATIONCTRL.BCGDurationCtrlPropPage.1",
	0xab09458a, 0x5af, 0x11d2, 0x8b, 0xd0, 0, 0xa0, 0xc9, 0xb0, 0x55, 0x90)


/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlPropPage::CBCGDurationCtrlPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CBCGDurationCtrlPropPage

BOOL CBCGDurationCtrlPropPage::CBCGDurationCtrlPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_BCGDURATIONCTRL_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlPropPage::CBCGDurationCtrlPropPage - Constructor

CBCGDurationCtrlPropPage::CBCGDurationCtrlPropPage() :
	COlePropertyPage(IDD, IDS_BCGDURATIONCTRL_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CBCGDurationCtrlPropPage)
	m_bShowDays = FALSE;
	m_bShowHoursMinutes = FALSE;
	m_bSpinButton = FALSE;
	m_strDaysLabel = _T("");
	m_strMinutesLabel = _T("");
	m_strHoursLabel = _T("");
	m_BEnabled = FALSE;
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlPropPage::DoDataExchange - Moves data between page and properties

void CBCGDurationCtrlPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CBCGDurationCtrlPropPage)
	DDP_Check(pDX, IDC_SHOW_DAYS, m_bShowDays, _T("ShowDays") );
	DDX_Check(pDX, IDC_SHOW_DAYS, m_bShowDays);
	DDP_Check(pDX, IDC_SHOW_HOURS_MINUTES, m_bShowHoursMinutes, _T("ShowHoursMinutes") );
	DDX_Check(pDX, IDC_SHOW_HOURS_MINUTES, m_bShowHoursMinutes);
	DDP_Check(pDX, IDC_SPIN_BUTTON, m_bSpinButton, _T("SpinButton") );
	DDX_Check(pDX, IDC_SPIN_BUTTON, m_bSpinButton);
	DDP_Text(pDX, IDC_DAYS_LABEL, m_strDaysLabel, _T("DaysLabel") );
	DDX_Text(pDX, IDC_DAYS_LABEL, m_strDaysLabel);
	DDP_Text(pDX, IDC_MINUTES_LABEL, m_strMinutesLabel, _T("MinutesLabel") );
	DDX_Text(pDX, IDC_MINUTES_LABEL, m_strMinutesLabel);
	DDP_Text(pDX, IDC_HOURS_LABEL, m_strHoursLabel, _T("HoursLabel") );
	DDX_Text(pDX, IDC_HOURS_LABEL, m_strHoursLabel);
	DDP_Check(pDX, IDC_ENABLED, m_BEnabled, _T("Enabled") );
	DDX_Check(pDX, IDC_ENABLED, m_BEnabled);
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlPropPage message handlers
