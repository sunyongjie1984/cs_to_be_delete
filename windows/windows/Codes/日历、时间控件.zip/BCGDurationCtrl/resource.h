//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BCGDurationCtrl.rc
//
#define IDS_BCGDURATIONCTRL             1
#define IDD_ABOUTBOX_BCGDURATIONCTRL    1
#define IDB_BCGDURATIONCTRL             1
#define IDI_ABOUTDLL                    1
#define IDS_BCGDURATIONCTRL_PPG         2
#define IDS_BCGDURATIONCTRL_PPG_CAPTION 200
#define IDD_PROPPAGE_BCGDURATIONCTRL    200
#define IDC_EDIT2                       202
#define IDC_SPIN_BUTTON                 202
#define IDC_SHOW_DAYS                   203
#define IDC_SHOW_HOURS_MINUTES          204
#define IDC_DAYS_LABEL                  205
#define IDC_HOURS_LABEL                 206
#define IDC_MINUTES_LABEL               207
#define IDC_ENABLED                     208

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         206
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
