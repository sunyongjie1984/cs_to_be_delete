#if !defined(AFX_STDAFX_H__AB09458D_05AF_11D2_8BD0_00A0C9B05590__INCLUDED_)
#define AFX_STDAFX_H__AB09458D_05AF_11D2_8BD0_00A0C9B05590__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// stdafx.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxctl.h>         // MFC support for ActiveX Controls
#include <afxcmn.h>

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__AB09458D_05AF_11D2_8BD0_00A0C9B05590__INCLUDED_)
