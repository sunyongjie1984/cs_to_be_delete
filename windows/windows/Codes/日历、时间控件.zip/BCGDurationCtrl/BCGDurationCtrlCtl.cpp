// BCGDurationCtrlCtl.cpp : Implementation of the CBCGDurationCtrlCtrl ActiveX Control class.

#include "stdafx.h"
#include "BCGDurationCtrl.h"
#include "BCGDurationCtrlCtl.h"
#include "BCGDurationCtrlPpg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static const int iSpinWidth = 15;
static const int iSpinID = 1;

IMPLEMENT_DYNCREATE(CBCGDurationCtrlCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CBCGDurationCtrlCtrl, COleControl)
	//{{AFX_MSG_MAP(CBCGDurationCtrlCtrl)
	ON_WM_CREATE()
	ON_WM_GETDLGCODE()
	ON_WM_LBUTTONDOWN()
	ON_WM_KEYDOWN()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CBCGDurationCtrlCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CBCGDurationCtrlCtrl)
	DISP_PROPERTY_NOTIFY(CBCGDurationCtrlCtrl, "SpinButton", m_spinButton, OnSpinButtonChanged, VT_BOOL)
	DISP_PROPERTY_NOTIFY(CBCGDurationCtrlCtrl, "DaysLabel", m_strDaysLabel, OnDaysLabelChanged, VT_BSTR)
	DISP_PROPERTY_NOTIFY(CBCGDurationCtrlCtrl, "HoursLabel", m_strHoursLabel, OnHoursLabelChanged, VT_BSTR)
	DISP_PROPERTY_NOTIFY(CBCGDurationCtrlCtrl, "MinutesLabel", m_strMinutesLabel, OnMinutesLabelChanged, VT_BSTR)
	DISP_PROPERTY_NOTIFY(CBCGDurationCtrlCtrl, "ShowDays", m_bShowDays, OnShowDaysChanged, VT_BOOL)
	DISP_PROPERTY_NOTIFY(CBCGDurationCtrlCtrl, "ShowHoursMinutes", m_bShowHoursMinutes, OnShowHoursMinutesChanged, VT_BOOL)
	DISP_PROPERTY_EX(CBCGDurationCtrlCtrl, "TotalSeconds", GetTotalSeconds, SetTotalSeconds, VT_I4)
	DISP_FUNCTION(CBCGDurationCtrlCtrl, "SizeToContent", SizeToContent, VT_EMPTY, VTS_NONE)
	DISP_DEFVALUE(CBCGDurationCtrlCtrl, "TotalSeconds")
	DISP_PROPERTY_NOTIFY_ID(CBCGDurationCtrlCtrl, "Enabled", DISPID_ENABLED, m_enabled, OnEnabledChanged, VT_BOOL)
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CBCGDurationCtrlCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CBCGDurationCtrlCtrl, COleControl)
	//{{AFX_EVENT_MAP(CBCGDurationCtrlCtrl)
	EVENT_CUSTOM("OnDurationChanged", FireOnDurationChanged, VTS_I4)
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CBCGDurationCtrlCtrl, 1)
	PROPPAGEID(CBCGDurationCtrlPropPage::guid)
END_PROPPAGEIDS(CBCGDurationCtrlCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CBCGDurationCtrlCtrl, "BCGDURATIONCTRL.BCGDurationCtrlCtrl.1",
	0xab094589, 0x5af, 0x11d2, 0x8b, 0xd0, 0, 0xa0, 0xc9, 0xb0, 0x55, 0x90)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CBCGDurationCtrlCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DBCGDurationCtrl =
		{ 0xab094587, 0x5af, 0x11d2, { 0x8b, 0xd0, 0, 0xa0, 0xc9, 0xb0, 0x55, 0x90 } };
const IID BASED_CODE IID_DBCGDurationCtrlEvents =
		{ 0xab094588, 0x5af, 0x11d2, { 0x8b, 0xd0, 0, 0xa0, 0xc9, 0xb0, 0x55, 0x90 } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwBCGDurationCtrlOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CBCGDurationCtrlCtrl, IDS_BCGDURATIONCTRL, _dwBCGDurationCtrlOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlCtrl::CBCGDurationCtrlCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CBCGDurationCtrlCtrl

BOOL CBCGDurationCtrlCtrl::CBCGDurationCtrlCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_BCGDURATIONCTRL,
			IDB_BCGDURATIONCTRL,
			afxRegApartmentThreading,
			_dwBCGDurationCtrlOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// Licensing strings

static const TCHAR BASED_CODE _szLicFileName[] = _T("BCGDurationCtrl.lic");

static const WCHAR BASED_CODE _szLicString[] =
	L"Copyright (c) 1998 IET - Intelligent Electronics Ltd.";


/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlCtrl::CBCGDurationCtrlCtrlFactory::VerifyUserLicense -
// Checks for existence of a user license

BOOL CBCGDurationCtrlCtrl::CBCGDurationCtrlCtrlFactory::VerifyUserLicense()
{
	return AfxVerifyLicFile(AfxGetInstanceHandle(), _szLicFileName,
		_szLicString);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlCtrl::CBCGDurationCtrlCtrlFactory::GetLicenseKey -
// Returns a runtime licensing key

BOOL CBCGDurationCtrlCtrl::CBCGDurationCtrlCtrlFactory::GetLicenseKey(DWORD dwReserved,
	BSTR FAR* pbstrKey)
{
	if (pbstrKey == NULL)
		return FALSE;

	*pbstrKey = SysAllocString(_szLicString);
	return (*pbstrKey != NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlCtrl::CBCGDurationCtrlCtrl - Constructor

CBCGDurationCtrlCtrl::CBCGDurationCtrlCtrl()
{
	InitializeIIDs(&IID_DBCGDurationCtrl, &IID_DBCGDurationCtrlEvents);
	
	m_spinButton = TRUE;
	m_lDays = 0;
	m_lHours = 0;
	m_lMinutes = 0;

	m_strDaysLabel = _T("Day(s) ");
	m_strHoursLabel = _T(":");
	m_strMinutesLabel = _T("");

	m_bShowDays = TRUE;
	m_bShowHoursMinutes = TRUE;

	m_iSelectedPart = UNDEFINED_PART;

	m_iPrevDigit = -1;
	m_enabled = TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlCtrl::~CBCGDurationCtrlCtrl - Destructor

CBCGDurationCtrlCtrl::~CBCGDurationCtrlCtrl()
{
	// TODO: Cleanup your control's instance data here.
}

/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlCtrl::OnDraw - Drawing function

void CBCGDurationCtrlCtrl::OnDraw(
			CDC* pDC, const CRect& rcBounds, const CRect& rcInvalid)
{
	CRect rectClient = rcBounds;

	pDC->FillSolidRect (&rectClient, ::GetSysColor (COLOR_WINDOW));

	// Draw 3-d border around the control:
	pDC->Draw3dRect (	&rectClient, 
					::GetSysColor (COLOR_3DDKSHADOW),
					::GetSysColor (COLOR_3DHILIGHT));
	
	rectClient.InflateRect (-1, -1);
	pDC->Draw3dRect (	&rectClient,
					::GetSysColor (COLOR_3DSHADOW),
					::GetSysColor (COLOR_3DLIGHT));

	pDC->SetBkMode (TRANSPARENT);
	pDC->SelectStockObject (DEFAULT_GUI_FONT);

	if (GetSafeHwnd () == NULL)	// Control doesn't created yet (e.g., AppStudio)
	{
		pDC->SetTextColor (	m_enabled ?
							::GetSysColor (COLOR_WINDOWTEXT) :
							::GetSysColor (COLOR_GRAYTEXT));

		CString strTitle = _T("DURATION");
		CRect rectTitle = rectClient;
		rectTitle.InflateRect (-3, -3);

		pDC->DrawText (strTitle, rectTitle, DT_SINGLELINE);
		return;
	}

	for (int i = 0; i < PARTS_NUM; i ++)
	{
		if (m_rectParts [i].Width () == 0)
		{
			continue;
		}

		CString strText;

		switch (i)
		{
		case DAYS:
			strText.Format (_T("%d"), m_lDays);
			break;

		case DAYS_LABEL:
			strText = m_strDaysLabel;
			break;

		case HOURS:
			strText.Format (_T("%02d"), m_lHours);
			break;

		case MINUTES:
			strText.Format (_T("%02d"), m_lMinutes);
			break;

		case HOURS_LABEL:
			strText = m_strHoursLabel;
			break;

		case MINUTES_LABEL:
			strText = m_strMinutesLabel;
			break;

		default:
			ASSERT (FALSE);
		}

		CRect rect = m_rectParts [i];

		if (m_enabled && GetFocus () == this && i == m_iSelectedPart)	// Selected part
		{
			pDC->FillSolidRect (rect, ::GetSysColor (COLOR_HIGHLIGHT));
			pDC->SetTextColor (::GetSysColor (COLOR_HIGHLIGHTTEXT));
		}
		else
		{
			pDC->SetTextColor (	m_enabled ?
								::GetSysColor (COLOR_WINDOWTEXT) :
								::GetSysColor (COLOR_GRAYTEXT));
		}

		pDC->DrawText (strText, rect, DT_SINGLELINE | DT_VCENTER | DT_RIGHT);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlCtrl::DoPropExchange - Persistence support

void CBCGDurationCtrlCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	PX_Bool		(pPX, _T("SpinButton"), m_spinButton);
	PX_String	(pPX, _T("DaysLabel"), m_strDaysLabel);
	PX_String	(pPX, _T("MinutesLabel"), m_strMinutesLabel);
	PX_String	(pPX, _T("HoursLabel"), m_strHoursLabel);
	PX_Bool		(pPX, _T("ShowDays"), m_bShowDays);
	PX_Bool		(pPX, _T("ShowHoursMinutes"), m_bShowHoursMinutes);
	PX_Bool		(pPX, _T("Enabled"), m_enabled);
}

/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlCtrl::OnResetState - Reset control to default state

void CBCGDurationCtrlCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	m_spinButton = TRUE;
	m_lDays = 0;
	m_lHours = 0;
	m_lMinutes = 0;

	m_strDaysLabel = _T("Day(s) ");
	m_strHoursLabel = _T(":");
	m_strMinutesLabel = _T("");

	m_bShowDays = TRUE;
	m_bShowHoursMinutes = TRUE;

	m_iSelectedPart = UNDEFINED_PART;

	m_iPrevDigit = -1;
	m_enabled = TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlCtrl::AboutBox - Display an "About" box to the user

void CBCGDurationCtrlCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_BCGDURATIONCTRL);
	dlgAbout.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlCtrl message handlers

int CBCGDurationCtrlCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (COleControl::OnCreate(lpCreateStruct) == -1)
		return -1;

	BOOL bRC;

	CRect rectSpin (0, 0, 1, 1);
	bRC = m_wndSpin.Create (WS_CHILD | WS_VISIBLE | UDS_ALIGNRIGHT | UDS_AUTOBUDDY,
						rectSpin, this, iSpinID);
	if (!bRC)
	{
		TRACE (_T ("CBCGDurationCtrlCtrl: Can't create spin button!\n"));
		return -1;
	}

	AdjustLayout ();
	return 0;
}
//**************************************************************************************
UINT CBCGDurationCtrlCtrl::OnGetDlgCode() 
{
	return DLGC_WANTARROWS | DLGC_WANTCHARS;
}
//**************************************************************************************
BOOL CBCGDurationCtrlCtrl::PreTranslateMessage(MSG* pMsg) 
{
	switch (pMsg->message)
	{
	case WM_KEYDOWN:
		switch (pMsg->wParam)
		{
		case VK_UP:
		case VK_DOWN:
		case VK_LEFT:
		case VK_RIGHT:
		case VK_HOME:
		case VK_END:
			SendMessage(pMsg->message, pMsg->wParam, pMsg->lParam);
            return TRUE;
		}
	}

	return COleControl::PreTranslateMessage(pMsg);
}
//**************************************************************************************
void CBCGDurationCtrlCtrl::OnSpinButtonChanged() 
{
	AdjustLayout ();
	SetModifiedFlag();
}
//**************************************************************************************
void CBCGDurationCtrlCtrl::AdjustLayout ()
{
	if (GetSafeHwnd () == NULL)
	{
		return;
	}

	CClientDC dc (this);

	CFont* pPrevFont = (CFont*) dc.SelectStockObject (DEFAULT_GUI_FONT);
	ASSERT (pPrevFont != NULL);

	TEXTMETRIC tm;
	dc.GetTextMetrics (&tm);

	m_iControlHeight = tm.tmHeight + 8;

	dc.SelectObject (pPrevFont);

	int x = 4;
	for (int i = 0; i < PARTS_NUM; i ++)
	{
		CSize size (0, 0);
		CString strText;

		switch (i)
		{
		case DAYS:
			if (m_bShowDays)
			{
				strText = _T("000");
			}
			break;

		case DAYS_LABEL:
			if (m_bShowDays)
			{
				strText = m_strDaysLabel;
			}
			break;

		case HOURS:
		case MINUTES:
			if (m_bShowHoursMinutes)
			{
				strText = _T("00");
			}
			break;

		case HOURS_LABEL:
			if (m_bShowHoursMinutes)
			{
				strText = m_strHoursLabel;
			}
			break;

		case MINUTES_LABEL:
			if (m_bShowHoursMinutes)
			{
				strText = m_strMinutesLabel;
			}
			break;

		default:
			ASSERT (FALSE);
		}

		GetPartSize (strText, size);

		m_rectParts [i] = CRect (x, 4,
								x + size.cx, m_iControlHeight - 4);
		if (size.cx > 0)
		{
			x += size.cx + 2;
		}
	}

	m_iControlWidth = m_rectParts [MINUTES_LABEL].right + iSpinWidth + 4;

	SetControlSize (m_iControlWidth, m_iControlHeight);
	SetInitialSize (m_iControlWidth, m_iControlHeight);

	CRect rectClient;
	GetClientRect (&rectClient);

	// Adjust spin button:
	if (m_spinButton)
	{
		m_wndSpin.SetWindowPos (NULL, 
				rectClient.right - iSpinWidth - 2, 2,
				iSpinWidth, rectClient.Height () - 4,
				SWP_NOZORDER | SWP_NOACTIVATE);
		m_wndSpin.ShowWindow (SW_SHOW);

		m_wndSpin.EnableWindow (m_enabled);
	}
	else
	{
		m_wndSpin.SetWindowPos (NULL, 
				0, 0,
				0, 0,
				SWP_NOZORDER | SWP_NOACTIVATE);
		m_wndSpin.ShowWindow (SW_HIDE);
	}
}
//**************************************************************************************
void CBCGDurationCtrlCtrl::OnDaysLabelChanged() 
{
	AdjustLayout ();
	SetModifiedFlag();
}
//**************************************************************************************
void CBCGDurationCtrlCtrl::OnHoursLabelChanged() 
{
	AdjustLayout ();
	SetModifiedFlag();
}
//**************************************************************************************
void CBCGDurationCtrlCtrl::OnMinutesLabelChanged() 
{
	AdjustLayout ();
	SetModifiedFlag();
}
//**************************************************************************************
void CBCGDurationCtrlCtrl::OnShowDaysChanged() 
{
	AdjustLayout ();
	SetModifiedFlag();
}
//**************************************************************************************
void CBCGDurationCtrlCtrl::OnShowHoursMinutesChanged() 
{
	AdjustLayout ();
	SetModifiedFlag();
}
//***************************************************************************************
void CBCGDurationCtrlCtrl::GetPartSize (const CString& strText, CSize& size)
{
	if (strText.IsEmpty ())
	{
		size = CSize (0, 0);
		return;
	}

	CClientDC dc (this);

	CRect rectClient;
	GetClientRect (&rectClient);

	CFont* pPrevFont = (CFont*) dc.SelectStockObject (DEFAULT_GUI_FONT);
	ASSERT (pPrevFont != NULL);

	dc.DrawText (strText, rectClient, DT_SINGLELINE | DT_VCENTER | DT_CALCRECT);

	dc.SelectObject (pPrevFont);
	size = rectClient.Size ();
}
//**************************************************************************************
void CBCGDurationCtrlCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	COleControl::OnLButtonDown(nFlags, point);

	if (!m_enabled)
	{
		MessageBeep ((UINT) -1);
		return;
	}

	SetFocus ();

	int iNewSel = UNDEFINED_PART;
	int iOldSel = m_iSelectedPart;

	for (int i = 0; i < PARTS_NUM; i ++)
	{
		if (m_rectParts [i].PtInRect (point))
		{
			iNewSel = i;
			break;
		}
	}

	SelectPart (iNewSel);
}
//**************************************************************************************
void CBCGDurationCtrlCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (!m_enabled)
	{
		MessageBeep ((UINT) -1);
		return;
	}

	if (isdigit (nChar))
	{
		PushDigit (nChar - '0');
		return;
	}

	if (nChar >= VK_NUMPAD0 && nChar <= VK_NUMPAD9)
	{
		PushDigit (nChar - VK_NUMPAD0);
		return;
	}

	m_iPrevDigit = -1;

	switch (nChar)
	{
	case VK_DOWN:
		ScrollCurrPart (-1);
		break;

	case VK_UP:
		ScrollCurrPart (1);
		break;

	case VK_RIGHT:
		SelectNext ();
		break;

	case VK_LEFT:
		SelectPrev ();
		break;

	case VK_HOME:
		SelectPart (m_bShowDays ? DAYS : HOURS);
		break;

	case VK_END:
		if (m_bShowHoursMinutes)
		{
			SelectPart (MINUTES);
		}
		break;
	}
	
	COleControl::OnKeyDown(nChar, nRepCnt, nFlags);
}
//*****************************************************************************************
void CBCGDurationCtrlCtrl::SelectNext ()
{
	int iNewSel = m_iSelectedPart;

	switch (m_iSelectedPart)
	{
	case DAYS:
		if (m_bShowHoursMinutes)
		{
			iNewSel = HOURS;
		}
		break;

	case HOURS:
		iNewSel = MINUTES;
		break;

	case MINUTES:
		iNewSel = m_bShowDays ? DAYS : HOURS;
		break;

	default:
		MessageBeep (-1);
	}

	SelectPart (iNewSel);
}
//*****************************************************************************************
void CBCGDurationCtrlCtrl::SelectPrev ()
{
	int iNewSel = m_iSelectedPart;

	switch (m_iSelectedPart)
	{
	case DAYS:
		if (m_bShowHoursMinutes)
		{
			iNewSel = MINUTES;
		}
		break;

	case HOURS:
		iNewSel = m_bShowDays ? DAYS : MINUTES;
		break;

	case MINUTES:
		iNewSel = HOURS;
		break;

	default:
		MessageBeep (-1);
	}

	SelectPart (iNewSel);
}
//**************************************************************************************
void CBCGDurationCtrlCtrl::OnSetFocus(CWnd* pOldWnd) 
{
	COleControl::OnSetFocus(pOldWnd);
	
	if (m_iSelectedPart == UNDEFINED_PART)
	{
		SelectPart (m_bShowDays ? DAYS : HOURS);
	}
	else
	{
		if (m_iSelectedPart != UNDEFINED_PART)
		{
			InvalidateControl (m_rectParts [m_iSelectedPart]);
		}
	}
}
//**************************************************************************************
void CBCGDurationCtrlCtrl::SelectPart (int iNewSel)
{
	if (GetSafeHwnd () == NULL)
	{
		return;
	}

	int iOldSel = m_iSelectedPart;

	switch (iNewSel)
	{
	case DAYS:
	case HOURS:
	case MINUTES:
		m_iSelectedPart = iNewSel;
		break;

	case DAYS_LABEL:
		m_iSelectedPart = DAYS;
		break;

	case HOURS_LABEL:
		m_iSelectedPart = HOURS;
		break;

	case MINUTES_LABEL:
		m_iSelectedPart = MINUTES;
		break;
	}

	if (m_iSelectedPart == iOldSel)
	{
		return;
	}

	if (iOldSel != UNDEFINED_PART)
	{
		InvalidateControl (m_rectParts [iOldSel]);
	}

	if (m_iSelectedPart != UNDEFINED_PART)
	{
		InvalidateControl (m_rectParts [m_iSelectedPart]);
	}
}
//***************************************************************************************
void CBCGDurationCtrlCtrl::OnKillFocus(CWnd* pNewWnd) 
{
	COleControl::OnKillFocus(pNewWnd);
	
	if (m_iSelectedPart != UNDEFINED_PART)
	{
		InvalidateControl (m_rectParts [m_iSelectedPart]);
	}
}
//*****************************************************************************************
void CBCGDurationCtrlCtrl::PushDigit (int iDigit)
{
	int iNumber;
	if (m_iPrevDigit == -1)
	{
		iNumber = iDigit;
	}
	else
	{
		iNumber = m_iPrevDigit * 10 + iDigit;
	}

	switch (m_iSelectedPart)
	{
	case DAYS:
		if (m_iPrevDigit == -1)
		{
			m_lDays = iDigit;
		}
		else
		{
			m_lDays = m_lDays * 10 + iDigit;
		}
		break;

	case HOURS:
		if (iNumber >= 24)
		{
			MessageBeep (-1);
			return;
		}

		m_lHours = iNumber;
		break;

	case MINUTES:
		if (iNumber >= 60)
		{
			MessageBeep (-1);
			return;
		}

		m_lMinutes = iNumber;
		break;

	default:
		MessageBeep (-1);
		return;
	}

	if (GetSafeHwnd () != NULL)
	{
		InvalidateControl (m_rectParts [m_iSelectedPart]);
	}

	if (m_iPrevDigit == -1)	// First push
	{
		m_iPrevDigit = iDigit;
	}
	else
	{
		if (m_iSelectedPart != DAYS || m_lDays >= 100)
		{
			m_iPrevDigit = -1;
		}

		if (m_iSelectedPart != MINUTES &&
			(m_iSelectedPart != DAYS || m_lDays >= 100))
		{
			SelectNext ();
		}
	}

	FireOnDurationChanged (GetTotalSeconds());
}
//***************************************************************************************
long CBCGDurationCtrlCtrl::GetTotalSeconds() 
{
	return ((m_lDays * 24 + m_lHours) * 60 + m_lMinutes) * 60;
}
//***************************************************************************************
void CBCGDurationCtrlCtrl::SetTotalSeconds(long nNewValue) 
{
	long lTotalSeconds = abs (nNewValue);

	m_lDays = lTotalSeconds / (24 * 60 * 60);
/*	if (m_lDays >= 100)
	{
		m_lDays = 99;
	}
*/
	lTotalSeconds = lTotalSeconds % (24 * 60 * 60);
	m_lHours = lTotalSeconds / (60 * 60);
	lTotalSeconds = lTotalSeconds % (60 * 60);
	m_lMinutes = lTotalSeconds / 60;

	if (GetSafeHwnd () != NULL)
	{
		InvalidateControl ();
	}
}
//***************************************************************************************
void CBCGDurationCtrlCtrl::SizeToContent() 
{
	if (GetSafeHwnd () == NULL)	// Control doesn't created yet (e.g., AppStudio)
	{
		return;
	}

	AdjustLayout ();
}
//**************************************************************************************
void CBCGDurationCtrlCtrl::ScrollCurrPart (int iDelta)
{
	switch (m_iSelectedPart)
	{
	case DAYS:
		if (m_lDays + iDelta < 0 || m_lDays + iDelta >= 1000)
		{
			MessageBeep (-1);
			return;
		}

		m_lDays += iDelta;
		break;

	case HOURS:
		m_lHours += iDelta;
		if (m_lHours < 0)
		{
			m_lHours = 23;
		}
		else if (m_lHours > 23)
		{
			m_lHours = 0;
		}
		break;

	case MINUTES:
		m_lMinutes += iDelta;
		if (m_lMinutes < 0)
		{
			m_lMinutes = 59;
		}
		else if (m_lMinutes > 59)
		{
			m_lMinutes = 0;
		}
		break;

	default:
		MessageBeep (-1);
		return;
	}

	if (GetSafeHwnd () != NULL)
	{
		InvalidateControl (m_rectParts [m_iSelectedPart]);
	}

	FireOnDurationChanged (GetTotalSeconds());
}
//**************************************************************************************
BOOL CBCGDurationCtrlCtrl::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
	if (wParam == iSpinID)
	{
		NM_UPDOWN* pNM = (NM_UPDOWN*) lParam;
		ASSERT (pNM != NULL);

		if (pNM->hdr.code == UDN_DELTAPOS)
		{
			ScrollCurrPart (pNM->iDelta < 0 ? 1 : -1);
		}

		SetFocus ();
	}
	
	return COleControl::OnNotify(wParam, lParam, pResult);
}
//***************************************************************************************
BOOL CBCGDurationCtrlCtrl::OnDoVerb(LONG iVerb, LPMSG lpMsg, HWND hWndParent, LPCRECT lpRect) 
{
	BOOL rc = COleControl::OnDoVerb(iVerb, lpMsg, hWndParent, lpRect);
	
	if (iVerb == OLEIVERB_UIACTIVATE)
	{
		SetControlSize (m_iControlWidth, m_iControlHeight);
		SetInitialSize (m_iControlWidth, m_iControlHeight);
	}

	return rc;
}
//****************************************************************************************
void CBCGDurationCtrlCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	COleControl::OnLButtonUp(nFlags, point);

	SetControlSize (m_iControlWidth, m_iControlHeight);
	SetInitialSize (m_iControlWidth, m_iControlHeight);
}
//***************************************************************************************
void CBCGDurationCtrlCtrl::OnEnabledChanged() 
{
	if (GetSafeHwnd () != NULL)
	{
		m_wndSpin.EnableWindow (m_enabled);
		InvalidateControl ();
	}

	SetModifiedFlag();
}
