#if !defined(AFX_BCGDURATIONCTRLCTL_H__AB094597_05AF_11D2_8BD0_00A0C9B05590__INCLUDED_)
#define AFX_BCGDURATIONCTRLCTL_H__AB094597_05AF_11D2_8BD0_00A0C9B05590__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// BCGDurationCtrlCtl.h : Declaration of the CBCGDurationCtrlCtrl ActiveX Control class.

#define PARTS_NUM	6

/////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlCtrl : See BCGDurationCtrlCtl.cpp for implementation.

class CBCGDurationCtrlCtrl : public COleControl
{
	DECLARE_DYNCREATE(CBCGDurationCtrlCtrl)

// Constructor
public:
	CBCGDurationCtrlCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBCGDurationCtrlCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnDoVerb(LONG iVerb, LPMSG lpMsg, HWND hWndParent, LPCRECT lpRect);
	protected:
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CBCGDurationCtrlCtrl();

	BEGIN_OLEFACTORY(CBCGDurationCtrlCtrl)        // Class factory and guid
		virtual BOOL VerifyUserLicense();
		virtual BOOL GetLicenseKey(DWORD, BSTR FAR*);
	END_OLEFACTORY(CBCGDurationCtrlCtrl)

	DECLARE_OLETYPELIB(CBCGDurationCtrlCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CBCGDurationCtrlCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CBCGDurationCtrlCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CBCGDurationCtrlCtrl)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg UINT OnGetDlgCode();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CBCGDurationCtrlCtrl)
	BOOL m_spinButton;
	afx_msg void OnSpinButtonChanged();
	CString m_strDaysLabel;
	afx_msg void OnDaysLabelChanged();
	CString m_strHoursLabel;
	afx_msg void OnHoursLabelChanged();
	CString m_strMinutesLabel;
	afx_msg void OnMinutesLabelChanged();
	BOOL m_bShowDays;
	afx_msg void OnShowDaysChanged();
	BOOL m_bShowHoursMinutes;
	afx_msg void OnShowHoursMinutesChanged();
	afx_msg long GetTotalSeconds();
	afx_msg void SetTotalSeconds(long nNewValue);
	afx_msg void SizeToContent();
	BOOL m_enabled;
	afx_msg void OnEnabledChanged();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CBCGDurationCtrlCtrl)
	void FireOnDurationChanged(long lTotalSeconds)
		{FireEvent(eventidOnDurationChanged,EVENT_PARAM(VTS_I4), lTotalSeconds);}
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CBCGDurationCtrlCtrl)
	dispidSpinButton = 1L,
	dispidDaysLabel = 2L,
	dispidHoursLabel = 3L,
	dispidMinutesLabel = 4L,
	dispidShowDays = 5L,
	dispidShowHoursMinutes = 6L,
	dispidTotalSeconds = 7L,
	dispidSizeToContent = 8L,
	eventidOnDurationChanged = 1L,
	//}}AFX_DISP_ID
	};

// Operations:
protected:
	void AdjustLayout ();
	void GetPartSize (const CString& strText, CSize& size);
	void SelectPart (int iNewSel);
	void SelectNext ();
	void SelectPrev ();
	void PushDigit (int iDigit);
	void ScrollCurrPart (int iDelta);

// Attributes:
//	CMaskEdit	m_wndMask;
//	CFont*		m_pFont;

protected:
	enum PART_TYPE
	{
		UNDEFINED_PART = -1,
		DAYS,
		DAYS_LABEL,
		HOURS,
		HOURS_LABEL,
		MINUTES,
		MINUTES_LABEL
	};

	PART_TYPE		m_CurrPartType;
	CString			m_strTimeSeparator;
	int				m_iPrevDigit;
	CSpinButtonCtrl	m_wndSpin;
	int				m_iSelectedPart;

	CRect			m_rectParts [PARTS_NUM];

	int				m_lDays;
	int				m_lHours;
	int				m_lMinutes;

	int				m_iControlWidth;
	int				m_iControlHeight;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BCGDURATIONCTRLCTL_H__AB094597_05AF_11D2_8BD0_00A0C9B05590__INCLUDED)
