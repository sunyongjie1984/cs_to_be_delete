#if !defined(AFX_BCGDURATIONCTRLPPG_H__AB094599_05AF_11D2_8BD0_00A0C9B05590__INCLUDED_)
#define AFX_BCGDURATIONCTRLPPG_H__AB094599_05AF_11D2_8BD0_00A0C9B05590__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// BCGDurationCtrlPpg.h : Declaration of the CBCGDurationCtrlPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CBCGDurationCtrlPropPage : See BCGDurationCtrlPpg.cpp.cpp for implementation.

class CBCGDurationCtrlPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CBCGDurationCtrlPropPage)
	DECLARE_OLECREATE_EX(CBCGDurationCtrlPropPage)

// Constructor
public:
	CBCGDurationCtrlPropPage();

// Dialog Data
	//{{AFX_DATA(CBCGDurationCtrlPropPage)
	enum { IDD = IDD_PROPPAGE_BCGDURATIONCTRL };
	BOOL	m_bShowDays;
	BOOL	m_bShowHoursMinutes;
	BOOL	m_bSpinButton;
	CString	m_strDaysLabel;
	CString	m_strMinutesLabel;
	CString	m_strHoursLabel;
	BOOL	m_BEnabled;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CBCGDurationCtrlPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BCGDURATIONCTRLPPG_H__AB094599_05AF_11D2_8BD0_00A0C9B05590__INCLUDED)
