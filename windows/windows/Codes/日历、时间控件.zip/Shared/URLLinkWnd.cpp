// URLLinkWnd.cpp : implementation file
//

#include "stdafx.h"
#include "URLLinkWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CURLLinkWnd

CURLLinkWnd::CURLLinkWnd() :
	m_clrLink (RGB (0, 0, 255)),
	m_clrHover (RGB (255, 0, 0)),
	m_hFont (NULL),
	m_hCursor (NULL),
	m_bIsHover (FALSE),
	m_bPressed (FALSE),
	m_bIsCaptured (FALSE),
	m_iTextLength (0)
{
	LOGFONT lf;
	memset (&lf, 0, sizeof (LOGFONT));

	_tcscpy (lf.lfFaceName, _T ("MS Sans Serif"));
	lf.lfHeight = - 8;
	lf.lfUnderline = TRUE;

	m_fontDefault.CreateFontIndirect (&lf);
}
//*****************************************************************************
CURLLinkWnd::~CURLLinkWnd()
{
}

BEGIN_MESSAGE_MAP(CURLLinkWnd, CButton)
	//{{AFX_MSG_MAP(CURLLinkWnd)
	ON_WM_SETCURSOR()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_KILLFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CURLLinkWnd message handlers

void CURLLinkWnd::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	CDC* pDC = CDC::FromHandle (lpDrawItemStruct->hDC);
	
	CFont* pOldFont = NULL;
	if (m_hFont == NULL)
	{
		pOldFont = (CFont*) pDC->SelectObject (&m_fontDefault);
	}
	else
	{
		CFont* pFont = CFont::FromHandle (m_hFont);
		pOldFont = (CFont*) pDC->SelectObject (pFont);
	}
	
	pDC->SetTextColor (m_bIsHover ? m_clrHover : m_clrLink);
	pDC->SetBkMode (TRANSPARENT);
	
	CString str;
	GetWindowText (str);

	CRect rect = lpDrawItemStruct->rcItem;
	pDC->DrawText (str, rect, DT_SINGLELINE | DT_VCENTER);

	m_iTextLength = pDC->GetTextExtent (str).cx;

	if (pOldFont != NULL)
	{
		pDC->SelectObject (pOldFont);
	}
}
//*****************************************************************************
BOOL CURLLinkWnd::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	if (m_hCursor != NULL)
	{
		CPoint ptCursor;
		::GetCursorPos (&ptCursor);
		ScreenToClient (&ptCursor);

		CRect rectClient;
		GetClientRect (rectClient);
		rectClient.right = m_iTextLength;

		if (rectClient.PtInRect (ptCursor))
		{
			::SetCursor (m_hCursor);
			return TRUE;
		}
	}
	
	return CButton::OnSetCursor (pWnd, nHitTest, message);
}
//*****************************************************************************
BOOL CURLLinkWnd::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}
//*****************************************************************************
void CURLLinkWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_bPressed = TRUE;
}
//****************************************************************************************
void CURLLinkWnd::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if (m_bIsCaptured)
	{
		ReleaseCapture ();
		m_bIsCaptured = FALSE;
	}

	CRect rectClient;
	GetClientRect (rectClient);
	rectClient.right = m_iTextLength;

	if (rectClient.PtInRect (point) && m_bPressed)
	{
		CWnd* pParent = GetParent ();
		if (pParent != NULL)
		{
			pParent->SendMessage (	WM_COMMAND,
									MAKEWPARAM (GetDlgCtrlID (), BN_CLICKED), 
									(LPARAM) m_hWnd);
		}
	}

	m_bPressed = FALSE;
}
//****************************************************************************************
void CURLLinkWnd::OnMouseMove(UINT nFlags, CPoint point) 
{
	BOOL bPrevHover = m_bIsHover;

	CRect rectClient;
	GetClientRect (rectClient);
	rectClient.right = m_iTextLength;

	m_bIsHover = rectClient.PtInRect (point);

	if (bPrevHover != m_bIsHover)
	{
		if (m_bIsHover)
		{
			SetCapture ();
			m_bIsCaptured = TRUE;
		}
		else if (m_bIsCaptured)
		{
			ReleaseCapture ();
			m_bIsCaptured = FALSE;
		}

		Invalidate ();
		UpdateWindow ();
	}
}
//****************************************************************************************
void CURLLinkWnd::OnKillFocus(CWnd* pNewWnd)
{
	if (m_bIsCaptured)
	{
		ReleaseCapture ();
		m_bIsCaptured = FALSE;
	}

	m_bPressed = FALSE;
	m_bIsHover = FALSE;

	Invalidate ();
	UpdateWindow ();
}
