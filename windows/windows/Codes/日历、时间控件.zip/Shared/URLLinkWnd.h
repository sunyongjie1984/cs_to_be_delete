#if !defined(AFX_URLLINKWND_H__6CD62A04_486E_11D1_8F32_00A0C93A70EC__INCLUDED_)
#define AFX_URLLINKWND_H__6CD62A04_486E_11D1_8F32_00A0C93A70EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// URLLinkWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CURLLinkWnd window

class CURLLinkWnd : public CButton
{
// Construction
public:
	CURLLinkWnd();

// Attributes
public:
	HCURSOR		m_hCursor;
	HFONT		m_hFont;
	COLORREF	m_clrLink;
	COLORREF	m_clrHover;

protected:
	BOOL		m_bIsHover;
	BOOL		m_bPressed;
	BOOL		m_bIsCaptured;
	CFont		m_fontDefault;
	int			m_iTextLength;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CURLLinkWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CURLLinkWnd();

	// Generated message map functions
protected:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);

	//{{AFX_MSG(CURLLinkWnd)
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_URLLINKWND_H__6CD62A04_486E_11D1_8F32_00A0C93A70EC__INCLUDED_)
