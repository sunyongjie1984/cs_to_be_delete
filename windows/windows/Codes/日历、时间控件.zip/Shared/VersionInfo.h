// VersionInfo.h: interface for the CVersionInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VERSIONINFO_H__EB554CF5_B26C_11D1_A63B_00A0C93A70EC__INCLUDED_)
#define AFX_VERSIONINFO_H__EB554CF5_B26C_11D1_A63B_00A0C93A70EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CVersionInfo  
{
public:
	CVersionInfo(HINSTANCE hInst = NULL);
	virtual ~CVersionInfo();

	BOOL GetVersion (CString& strOut) const;
	int GetMinorVersion () const;

protected:
	HINSTANCE m_hInst;
};

#endif // !defined(AFX_VERSIONINFO_H__EB554CF5_B26C_11D1_A63B_00A0C93A70EC__INCLUDED_)
