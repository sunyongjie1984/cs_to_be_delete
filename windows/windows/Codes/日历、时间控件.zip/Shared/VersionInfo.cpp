// VersionInfo.cpp: implementation of the CVersionInfo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "VersionInfo.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#pragma comment(lib,"Version.lib") 

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVersionInfo::CVersionInfo(HINSTANCE hInst) :
	m_hInst (hInst)
{
}
//***************************************************************************************
CVersionInfo::~CVersionInfo()
{
}
//***************************************************************************************
BOOL CVersionInfo::GetVersion (CString& strOut) const
{
	TCHAR szFullPath [_MAX_PATH];
	GetModuleFileName  (m_hInst == NULL ? ::AfxGetInstanceHandle () : m_hInst, 
						szFullPath, sizeof(szFullPath));

	DWORD dwVerHnd;
	DWORD dwVerInfoSize = ::GetFileVersionInfoSize (szFullPath, &dwVerHnd);

	if (dwVerInfoSize == 0)
	{
		return FALSE; 
	}

	// If we were able to get the information, process it:
	HANDLE  hMem;
	LPVOID  lpvMem;

	hMem = ::GlobalAlloc (GMEM_MOVEABLE, dwVerInfoSize);
	lpvMem = ::GlobalLock (hMem);
	::GetFileVersionInfo (szFullPath, dwVerHnd, dwVerInfoSize, lpvMem);

	BOOL  bRet;
	UINT  cchVer = 0;
	LPSTR lszVer = NULL;

	bRet = ::VerQueryValue (lpvMem, 
						TEXT("\\StringFileInfo\\040904B0\\ProductVersion"), 
						(LPVOID*) &lszVer, &cchVer);

	if (bRet && cchVer && lszVer)
	{ 
		strOut = lszVer;
	} 

	::GlobalUnlock(hMem);
	::GlobalFree(hMem);

	return bRet;
}
//***************************************************************************************
int CVersionInfo::GetMinorVersion () const
{
	CString strVer;
	if (!GetVersion (strVer))
	{
		return -1;	// Unknown version
	}

	int iIndex = strVer.ReverseFind (_T('.'));
	if (iIndex == -1 &&
		(iIndex = strVer.ReverseFind (_T(','))) == -1)
	{
		TRACE (_T("Invalid version string format!\n"));
		return -1;
	}

	CString strMinVer = strVer.Mid (iIndex + 1);
	int iMinVersion = _ttoi (strMinVer);

	return iMinVersion;
}
