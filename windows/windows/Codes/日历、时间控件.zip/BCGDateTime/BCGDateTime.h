#if !defined(AFX_BCGDATETIME_H__01B9AC63_A128_11D1_A637_00A0C93A70EC__INCLUDED_)
#define AFX_BCGDATETIME_H__01B9AC63_A128_11D1_A637_00A0C93A70EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// BCGDateTime.h : main header file for BCGDATETIME.DLL

#if !defined( __AFXCTL_H__ )
	#error include 'afxctl.h' before including this file
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimeApp : See BCGDateTime.cpp for implementation.

class CBCGDateTimeApp : public COleControlModule
{
public:
	BOOL InitInstance();
	int ExitInstance();

	int GetDaysInMonth (int iMonth, int iYear) const;
};

extern const GUID CDECL _tlid;
extern const WORD _wVerMajor;
extern const WORD _wVerMinor;

extern CBCGDateTimeApp theApp;

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BCGDATETIME_H__01B9AC63_A128_11D1_A637_00A0C93A70EC__INCLUDED)
