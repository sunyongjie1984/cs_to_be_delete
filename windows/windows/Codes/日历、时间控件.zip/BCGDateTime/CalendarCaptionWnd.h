#if !defined(AFX_CALENDARCAPTIONWND_H__E6E1F1B4_ACE6_11D1_A639_00A0C93A70EC__INCLUDED_)
#define AFX_CALENDARCAPTIONWND_H__E6E1F1B4_ACE6_11D1_A639_00A0C93A70EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CalendarCaptionWnd.h : header file
//

class CCalendarWnd;

#define DAYS_IN_WEEK 7

/////////////////////////////////////////////////////////////////////////////
// CCalendarCaptionWnd window

class CCalendarCaptionWnd : public CWnd
{
// Construction
public:
	CCalendarCaptionWnd();

// Attributes
public:
	BOOL			m_bEnabled;
	int				m_iFirstDayOfWeek;

protected:
	static CString	m_strClassName;

	CCalendarWnd*	m_pParentCalendar;

	int				m_iTrackedButton;
	int				m_iPressedButton;

	CRect			m_rectButtons [DAYS_IN_WEEK];
	CStringArray	m_arLabels;

	COleDateTime	m_Date;

// Operations
public:
	void SetDate (const COleDateTime& date);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCalendarCaptionWnd)
	public:
	virtual BOOL Create(const RECT& rect, CWnd* pParentWnd, UINT nID);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCalendarCaptionWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CCalendarCaptionWnd)
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	int HitTest (POINT pt) const;
	void OnClickButton (int iButton);
	void InvalidateDay (int iDay);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALENDARCAPTIONWND_H__E6E1F1B4_ACE6_11D1_A639_00A0C93A70EC__INCLUDED_)
