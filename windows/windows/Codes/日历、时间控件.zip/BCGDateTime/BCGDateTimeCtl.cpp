// BCGDateTimeCtl.cpp : Implementation of the CBCGDateTimeCtrl ActiveX Control class.

#include "stdafx.h"
#include "BCGDateTime.h"
#include "BCGDateTimeCtl.h"
#include "BCGDateTimePpg.h"
#include "CalendarWnd.h"
#include "DateTimeAboutDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CBCGDateTimeCtrl, COleControl)

static const int iSpinWidth = 15;
static const int iDropButtonWidth = 17;
static const int iSpinID = 1;
static const COLORREF clrTransparent = RGB (255, 0, 255);

static const int iFirstAllowedYear = 1990;
static const int iLastAllowedYear = 2090;

/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CBCGDateTimeCtrl, COleControl)
	//{{AFX_MSG_MAP(CBCGDateTimeCtrl)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_CREATE()
	ON_WM_GETDLGCODE()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_KEYDOWN()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CBCGDateTimeCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CBCGDateTimeCtrl)
	DISP_PROPERTY_NOTIFY(CBCGDateTimeCtrl, "WantReturn", m_wantReturn, OnWantReturnChanged, VT_BOOL)
	DISP_PROPERTY_NOTIFY(CBCGDateTimeCtrl, "CheckButton", m_checkButton, OnCheckButtonChanged, VT_BOOL)
	DISP_PROPERTY_NOTIFY(CBCGDateTimeCtrl, "DropCalendar", m_dropCalendar, OnDropCalendarChanged, VT_BOOL)
	DISP_PROPERTY_NOTIFY(CBCGDateTimeCtrl, "ShowDate", m_showDate, OnShowDateChanged, VT_BOOL)
	DISP_PROPERTY_NOTIFY(CBCGDateTimeCtrl, "ShowTime", m_showTime, OnShowTimeChanged, VT_BOOL)
	DISP_PROPERTY_NOTIFY(CBCGDateTimeCtrl, "SpinButton", m_spinButton, OnSpinButtonChanged, VT_BOOL)
	DISP_PROPERTY_EX(CBCGDateTimeCtrl, "Date", GetDate, SetDate, VT_DATE)
	DISP_PROPERTY_EX(CBCGDateTimeCtrl, "MinDate", GetMinDate, SetMinDate, VT_DATE)
	DISP_PROPERTY_EX(CBCGDateTimeCtrl, "MaxDate", GetMaxDate, SetMaxDate, VT_DATE)
	DISP_FUNCTION(CBCGDateTimeCtrl, "SizeToContent", SizeToContent, VT_EMPTY, VTS_NONE)
	DISP_DEFVALUE(CBCGDateTimeCtrl, "Date")
	DISP_PROPERTY_NOTIFY_ID(CBCGDateTimeCtrl, "Enabled", DISPID_ENABLED, m_enabled, OnEnabledChanged, VT_BOOL)
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CBCGDateTimeCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CBCGDateTimeCtrl, COleControl)
	//{{AFX_EVENT_MAP(CBCGDateTimeCtrl)
	EVENT_CUSTOM("OnDateChanged", FireOnDateChanged, VTS_NONE)
	EVENT_CUSTOM("OnKillFocus", FireOnKillFocus, VTS_I4)
	EVENT_CUSTOM("SetFocus", FireSetFocus, VTS_NONE)
	EVENT_CUSTOM("OnEnter", FireOnEnter, VTS_NONE)
	EVENT_CUSTOM("OnCancel", FireOnCancel, VTS_NONE)
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CBCGDateTimeCtrl, 1)
	PROPPAGEID(CBCGDateTimePropPage::guid)
END_PROPPAGEIDS(CBCGDateTimeCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CBCGDateTimeCtrl, "BCGDATETIME.BCGDateTimeCtrl.1",
	0x1b9ac59, 0xa128, 0x11d1, 0xa6, 0x37, 0, 0xa0, 0xc9, 0x3a, 0x70, 0xec)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CBCGDateTimeCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DBCGDateTime =
		{ 0x1b9ac57, 0xa128, 0x11d1, { 0xa6, 0x37, 0, 0xa0, 0xc9, 0x3a, 0x70, 0xec } };
const IID BASED_CODE IID_DBCGDateTimeEvents =
		{ 0x1b9ac58, 0xa128, 0x11d1, { 0xa6, 0x37, 0, 0xa0, 0xc9, 0x3a, 0x70, 0xec } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwBCGDateTimeOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CBCGDateTimeCtrl, IDS_BCGDATETIME, _dwBCGDateTimeOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimeCtrl::CBCGDateTimeCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CBCGDateTimeCtrl

BOOL CBCGDateTimeCtrl::CBCGDateTimeCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_BCGDATETIME,
			IDB_BCGDATETIME,
			afxRegApartmentThreading,
			_dwBCGDateTimeOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// Licensing strings

static const TCHAR BASED_CODE _szLicFileName[] = _T("BCGDateTime.lic");

static const WCHAR BASED_CODE _szLicString[] =
	L"Copyright (c) 1998 IET";


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimeCtrl::CBCGDateTimeCtrlFactory::VerifyUserLicense -
// Checks for existence of a user license

BOOL CBCGDateTimeCtrl::CBCGDateTimeCtrlFactory::VerifyUserLicense()
{
	return AfxVerifyLicFile(AfxGetInstanceHandle(), _szLicFileName,
		_szLicString);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimeCtrl::CBCGDateTimeCtrlFactory::GetLicenseKey -
// Returns a runtime licensing key

BOOL CBCGDateTimeCtrl::CBCGDateTimeCtrlFactory::GetLicenseKey(DWORD dwReserved,
	BSTR FAR* pbstrKey)
{
	if (pbstrKey == NULL)
		return FALSE;

	*pbstrKey = SysAllocString(_szLicString);
	return (*pbstrKey != NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimeCtrl::CBCGDateTimeCtrl - Constructor

CBCGDateTimeCtrl::CBCGDateTimeCtrl()
{
	InitializeIIDs(&IID_DBCGDateTime, &IID_DBCGDateTimeEvents);

	m_checkButton = TRUE;
	m_dropCalendar = TRUE;
	m_showDate = TRUE;
	m_showTime = TRUE;
	m_spinButton = TRUE;

	m_bCheckBoxIsAvailable = FALSE;
	m_iPartNum = 0;
	m_bIsChecked = TRUE;
	m_Date = COleDateTime::GetCurrentTime ();
	m_iPrevDigit = -1;

	m_bShowSelection = FALSE;
	m_bIsDateComboDropped = FALSE;

	m_pWndDrop = NULL;

	m_bDropButtonIsPressed = FALSE;
	m_bMouseOnDropButton = FALSE;

	m_enabled = TRUE;
	m_wantReturn = FALSE;
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimeCtrl::~CBCGDateTimeCtrl - Destructor

CBCGDateTimeCtrl::~CBCGDateTimeCtrl()
{
	// TODO: Cleanup your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimeCtrl::OnDraw - Drawing function

void CBCGDateTimeCtrl::OnDraw(
			CDC* pDC, const CRect& rcBounds, const CRect& rcInvalid)
{
	CRect rectClient = rcBounds;

	pDC->FillSolidRect (&rectClient, ::GetSysColor (COLOR_WINDOW));

	// Draw 3-d border around the control:
	pDC->Draw3dRect (	&rectClient, 
					::GetSysColor (COLOR_3DDKSHADOW),
					::GetSysColor (COLOR_3DHILIGHT));
	
	rectClient.InflateRect (-1, -1);
	pDC->Draw3dRect (	&rectClient,
					::GetSysColor (COLOR_3DSHADOW),
					::GetSysColor (COLOR_3DLIGHT));

	pDC->SetBkMode (TRANSPARENT);
//	SelectStockFont (pDC);
	pDC->SelectStockObject (DEFAULT_GUI_FONT);

	if (GetSafeHwnd () == NULL)	// Control doesn't created yet (e.g., AppStudio)
	{
		pDC->SetTextColor (	m_enabled ?
							::GetSysColor (COLOR_WINDOWTEXT) :
							::GetSysColor (COLOR_GRAYTEXT));

		CString strTitle = _T("DATE/TIME");
		CRect rectTitle = rectClient;
		rectTitle.InflateRect (-3, -3);

		pDC->DrawText (strTitle, rectTitle, DT_SINGLELINE);
		return;
	}

	// Draw check box:
	DrawCheckBox (pDC);

	// Draw "Drop Date combo" button:
	DrawDateDropButton (pDC);

	// Draw date/time parts:
	if (m_bIsChecked)
	{
		int iStart = m_bCheckBoxIsAvailable ? 1 : 0;
		int x = m_rectText.left;

		for (int i = iStart; i < m_iPartsNumber; i ++)
		{
			CString str = m_Date.Format (GetPartFormat (i));

			CRect rect = m_rectText;
			rect.left = x;

			if (m_bShowSelection && i == m_iPartNum)	// Selected part
			{
				CRect rectFill = rect;
				pDC->DrawText (str, rectFill, DT_SINGLELINE | DT_VCENTER | DT_CALCRECT);

				int iOffset = (m_rectText.Height () - rectFill.Height ()) / 2;

				rectFill.OffsetRect (0, iOffset);

				pDC->FillSolidRect (rectFill, ::GetSysColor (COLOR_HIGHLIGHT));
				pDC->SetTextColor (::GetSysColor (COLOR_HIGHLIGHTTEXT));
			}
			else
			{
				pDC->SetTextColor (::GetSysColor ((m_bIsChecked && m_enabled) ? 
									COLOR_WINDOWTEXT : 
									COLOR_GRAYTEXT));
			}

			pDC->DrawText (str, rect, DT_SINGLELINE | DT_VCENTER);

			CRect rectSep = rect;
			pDC->DrawText (str, rectSep, DT_SINGLELINE | DT_VCENTER | DT_CALCRECT);

			int iSepLeft = rectSep.right;

			CString strSeparator = " ";
			if (i < m_iPartsNumber - 1)
			{
				if (IsDatePart (i) && IsDatePart (i + 1))
				{
					strSeparator = m_strDateSeparator;
				}

				if (IsTimePart (i) && IsTimePart (i + 1))
				{
					strSeparator = m_strTimeSeparator;
				}
			}

			rect.left = iSepLeft;
			rect.right = m_rectText.right;

			pDC->SetTextColor (::GetSysColor (m_bIsChecked && m_enabled ? COLOR_WINDOWTEXT : COLOR_GRAYTEXT));
			pDC->DrawText (strSeparator, rect, DT_SINGLELINE | DT_VCENTER);

			str += strSeparator;
			pDC->DrawText (strSeparator, rect, DT_SINGLELINE | DT_VCENTER | DT_CALCRECT);
			x = rect.right;
		}
	}
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimeCtrl::DoPropExchange - Persistence support

void CBCGDateTimeCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	PX_Bool (pPX, _T("SpinButton"), m_spinButton);
	PX_Bool (pPX, _T("DropCalendar"), m_dropCalendar);
	PX_Bool (pPX, _T("CheckButton"), m_checkButton);
	PX_Bool (pPX, _T("ShowDate"), m_showDate);
	PX_Bool (pPX, _T("ShowTime"), m_showTime);
	PX_Bool (pPX, _T("Enabled"), m_enabled);
	PX_Bool (pPX, _T("WantReturn"), m_wantReturn);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimeCtrl::OnResetState - Reset control to default state

void CBCGDateTimeCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimeCtrl::AboutBox - Display an "About" box to the user

void CBCGDateTimeCtrl::AboutBox()
{
	CDateTimeAboutDlg dlgAbout;
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimeCtrl message handlers

void CBCGDateTimeCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if (!m_enabled)
	{
		MessageBeep ((UINT) -1);
		return;
	}

	m_iPrevDigit = -1;

	int iPrevPart = m_iPartNum;

	SetFocus ();

	if (m_rectDropButton.PtInRect (point))
	{
		if (m_dropCalendar && m_bIsChecked && m_showDate)
		{
			m_bDropButtonIsPressed = TRUE;
			m_bMouseOnDropButton = TRUE;

//			SetCapture ();
//			ReleaseCapture ();

			InvalidateControl (m_rectDropButton);

			ShowDropCalendar ();
		}

		return;
	}

	int iPartNum = GetPartFromPoint (point);
	if (iPartNum == -1)
	{
		m_CurrPartType = NO;
		return;
	}

	if (!m_bIsChecked &&
		m_arPartsOrder [iPartNum] != CHECK_BOX)
	{
		return;
	}

	m_iPartNum = iPartNum;
	m_CurrPartType = m_arPartsOrder [m_iPartNum];

	if (m_CurrPartType == CHECK_BOX)
	{
		ToggleCheck ();
	}

	if (iPrevPart != m_iPartNum)
	{
		CRect rectPart;

		GetPartRect (iPrevPart, rectPart);
		InvalidateControl (rectPart);

		GetPartRect (m_iPartNum, rectPart);
		InvalidateControl (rectPart);
	}
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if (m_bDropButtonIsPressed)
	{
		m_bDropButtonIsPressed = FALSE;
		InvalidateControl (m_rectDropButton);

//		ReleaseCapture ();

		ASSERT (m_pWndDrop != NULL);
		m_pWndDrop->SetFocus ();
//		m_pWndDrop->SetCapture ();
	}
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (m_bDropButtonIsPressed)
	{
		BOOL bMouseOnDropButtonPrev = m_bMouseOnDropButton;
		m_bMouseOnDropButton = m_rectDropButton.PtInRect (point);

		if (bMouseOnDropButtonPrev != m_bMouseOnDropButton)
		{
			InvalidateControl (m_rectDropButton);
		}
	}

	COleControl::OnMouseMove(nFlags, point);
}
//****************************************************************************************
int CBCGDateTimeCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	BOOL bRC;

	if (COleControl::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CRect rectSpin (0, 0, 1, 1);
	bRC = m_wndSpin.Create (WS_CHILD | WS_VISIBLE | UDS_ALIGNRIGHT | UDS_AUTOBUDDY,
						rectSpin, this, iSpinID);
	if (!bRC)
	{
		TRACE (_T ("IETDateTimeCtrl: Can't create spin button!\n"));
		return -1;
	}

	bRC = m_Images.Create (IDB_DATE_IMAGES, 10, 0, clrTransparent);
	if (!bRC)
	{
		TRACE (_T ("IETDateTimeCtrl: Can't load images list!\n"));
		return -1;
	}

	BuidWidestDate ();
	AdjustControl ();
	return 0;
}
//****************************************************************************************
UINT CBCGDateTimeCtrl::OnGetDlgCode() 
{
	return DLGC_WANTARROWS | DLGC_WANTCHARS;
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnRButtonDown(UINT nFlags, CPoint point) 
{
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnRButtonUp(UINT nFlags, CPoint point) 
{
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (!m_enabled)
	{
		MessageBeep ((UINT) -1);
		return;
	}

	if (isdigit (nChar))
	{
		PushDigit (nChar - '0');
		return;
	}

	if (nChar >= VK_NUMPAD0 && nChar <= VK_NUMPAD9)
	{
		PushDigit (nChar - VK_NUMPAD0);
		return;
	}

	if (isalpha (nChar))
	{
		switch (m_CurrPartType)
		{
		case MONTH:
			ChangeMonth (nChar);
			break;

		case AMPM:
			ChangeAmPm (nChar);
			break;

		default:
			MessageBeep ((UINT) -1);
		}

		return;
	}

	m_iPrevDigit = -1;

	switch (nChar)
	{
	case VK_DOWN:
		ScrollCurrPart (-1);
		break;

	case VK_UP:
		ScrollCurrPart (1);
		break;

	case VK_RIGHT:
		SelectNext ();
		break;

	case VK_LEFT:
		SelectPrev ();
		break;

	case VK_HOME:
		ScrollCurrPartToLimit (TRUE);
		break;

	case VK_END:
		ScrollCurrPartToLimit (FALSE);
		break;

	case VK_SPACE:
		if (m_CurrPartType == CHECK_BOX)
		{
			ToggleCheck ();
		}
		else if (m_CurrPartType == AMPM)
		{
			ScrollCurrPart (1);
		}
		break;
	}
	
	COleControl::OnKeyDown(nChar, nRepCnt, nFlags);
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnWantReturnChanged() 
{
	SetModifiedFlag();
}
//****************************************************************************************
DATE CBCGDateTimeCtrl::GetDate() 
{
	if (m_bIsChecked)
	{
		COleDateTime today = COleDateTime::GetCurrentTime ();

		COleDateTime date (	m_showDate ? m_Date.GetYear () : today.GetYear (), 
							m_showDate ? m_Date.GetMonth () : today.GetMonth (), 
							m_showDate ? m_Date.GetDay () :  today.GetDay (),
							m_showTime ? m_Date.GetHour () : 0,
							m_showTime ? m_Date.GetMinute () : 0,
							0);	// Always clear seconds
		return (DATE) date;
	}
	else
	{
		COleDateTime dateEmpty;
		return (DATE) dateEmpty;
	}
}
//****************************************************************************************
void CBCGDateTimeCtrl::SetDate(DATE newValue) 
{
	m_Date = COleDateTime (newValue);

	if (m_bCheckBoxIsAvailable)
	{
		COleDateTime dateEmpty;
		m_bIsChecked = (m_Date != dateEmpty);

		if (m_spinButton)
		{
			m_wndSpin.EnableWindow (m_bIsChecked);
		}
	}

	InvalidateControl ();
	SetModifiedFlag();
}
//****************************************************************************************
BOOL CBCGDateTimeCtrl::OnDoVerb(LONG iVerb, LPMSG lpMsg, HWND hWndParent, LPCRECT lpRect) 
{
	BOOL rc = COleControl::OnDoVerb(iVerb, lpMsg, hWndParent, lpRect);
	
	if (iVerb == OLEIVERB_UIACTIVATE)
	{
		SetControlSize (m_iControlWidth, m_iControlHeight);
		SetInitialSize (m_iControlWidth, m_iControlHeight);
	}

	return rc;
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnFontChanged() 
{
	AdjustControl ();
	SetModifiedFlag();
	
	COleControl::OnFontChanged();
}
//****************************************************************************************
DATE CBCGDateTimeCtrl::GetMinDate() 
{
	return (DATE) m_MinDate;
}
//****************************************************************************************
void CBCGDateTimeCtrl::SetMinDate(DATE newValue) 
{
	COleDateTime dateMin = newValue;
	COleDateTime dateEmpty;

	if (m_MaxDate > dateMin || m_MaxDate == dateEmpty)
	{
		m_MinDate = dateMin;

		if (m_Date < m_MinDate)
		{
			m_Date = m_MinDate;
			FireOnDateChanged ();
		}

		SetModifiedFlag();
		InvalidateControl ();
	}
}
//****************************************************************************************
DATE CBCGDateTimeCtrl::GetMaxDate() 
{
	return (DATE) m_MaxDate;
}
//****************************************************************************************
void CBCGDateTimeCtrl::SetMaxDate(DATE newValue) 
{
	COleDateTime dateMax = newValue;
	COleDateTime dateEmpty;

	if (m_MinDate < dateMax)
	{
		m_MaxDate = dateMax;

		if (m_MaxDate.GetHour () == 0 && m_MaxDate.GetMinute () == 0)
		{
			m_MaxDate -= COleDateTimeSpan (0, 0, 1, 0);	// 1 minute before
		}

		if (m_Date > m_MaxDate && m_MaxDate != dateEmpty)
		{
			m_Date = m_MaxDate;
			FireOnDateChanged ();
		}

		SetModifiedFlag();
		InvalidateControl ();
	}
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnEnabledChanged() 
{
	SetModifiedFlag();
	AdjustControl ();
}
//****************************************************************************************
HMENU CBCGDateTimeCtrl::OnGetInPlaceMenu() 
{
	return NULL;
}
//****************************************************************************************
BOOL CBCGDateTimeCtrl::PreTranslateMessage(MSG* pMsg) 
{
	switch (pMsg->message)
	{
	case WM_KEYDOWN:
		switch (pMsg->wParam)
		{
		case VK_UP:
		case VK_DOWN:
		case VK_LEFT:
		case VK_RIGHT:
		case VK_HOME:
		case VK_END:
			SendMessage(pMsg->message, pMsg->wParam, pMsg->lParam); 
            return TRUE;

		case VK_RETURN:
			if (m_wantReturn)
			{
				FireOnEnter ();
				return TRUE;
			}
			break;

		case VK_ESCAPE:
			if (m_wantReturn)
			{
				FireOnCancel ();
				return TRUE;
			}
			break;

		}
		break;
	}
	
	return COleControl::PreTranslateMessage(pMsg);
}
//************************************************************************************************
void CBCGDateTimeCtrl::AdjustControl ()
{
	if (m_WidestDate == COleDateTime ())
	{
		BuidWidestDate ();
	}

	SetPartsOrder ();
	m_CurrPartType = m_arPartsOrder [0];

	if (GetSafeHwnd () == NULL)	// Control doesn't created yet (e.g., AppStudio)
	{
		return;
	}

	CRect rectClient;
	GetClientRect (&rectClient);

	// Calculate text size:
	CClientDC dc (this);

//	CFont* pPrevFont = SelectStockFont (&dc);
	CFont* pPrevFont = (CFont*) dc.SelectStockObject (DEFAULT_GUI_FONT);
	ASSERT (pPrevFont != NULL);

	TEXTMETRIC tm;

	dc.GetTextMetrics (&tm);

	m_rectText = rectClient;
	m_rectText.InflateRect (-2, -2);

	m_iControlHeight = tm.tmHeight + 8;

	if (m_bCheckBoxIsAvailable)
	{
		IMAGEINFO imageInfo;
		m_Images.GetImageInfo (0, &imageInfo);

		CRect rectCheckImage = imageInfo.rcImage;
		int iCheckRectHeight = rectCheckImage.Height () + 8;
		int iCheckRectWidth = rectCheckImage.Width () + 8;

		if (iCheckRectHeight + 4 > m_iControlHeight)
		{
			m_iControlHeight = iCheckRectHeight + 4;
		}

		m_rectCheck = CRect (3,
							 (m_iControlHeight - iCheckRectHeight) / 2,
							 3 + iCheckRectWidth,
							 (m_iControlHeight + iCheckRectHeight) / 2);
		
		m_rectText.left = m_rectCheck.right + 2;
	}
	else
	{
		m_rectText.left = 5;
	}
	
	m_rectText.top = 2;
	m_rectText.bottom = m_iControlHeight - 2;

	// Adjust control size:
	CRect rectLastPart;
	GetPartRect (m_iPartsNumber - 1, rectLastPart, TRUE);

	m_rectText.right = rectLastPart.right;

	m_iControlWidth = rectLastPart.right + 3;
	if (m_spinButton)
	{
		m_iControlWidth += iSpinWidth;
	}

	if (m_dropCalendar && m_showDate)
	{
		m_iControlWidth += iDropButtonWidth;

		int iDropStart = m_iControlWidth - iDropButtonWidth - 3;
		if (m_spinButton)
		{
			iDropStart -= iSpinWidth - 1;
		}

		m_rectDropButton = CRect (	iDropStart,
									2,
									iDropStart + iDropButtonWidth,
									m_iControlHeight - 2);
	}

	//SetControlSize (m_iControlWidth, m_iControlHeight);
	SetWindowPos (NULL, -1, -1, m_iControlWidth, m_iControlHeight,
		SWP_NOZORDER | SWP_NOACTIVATE | SWP_NOMOVE);
	SetInitialSize (m_iControlWidth, m_iControlHeight);

	// Adjust spin button:
	if (m_spinButton)
	{
		m_wndSpin.SetWindowPos (NULL, 
				m_iControlWidth - iSpinWidth - 2, 2,
				iSpinWidth, m_iControlHeight - 4,
				SWP_NOZORDER);
		m_wndSpin.ShowWindow (SW_SHOW);

		m_wndSpin.EnableWindow (m_enabled && m_bIsChecked);
	}
	else
	{
		m_wndSpin.SetWindowPos (NULL, 
				0, 0,
				0, 0,
				SWP_NOZORDER);
		m_wndSpin.ShowWindow (SW_HIDE);
	}

	dc.SelectObject (pPrevFont);

	//-----------------------------
	// Adjust min./max date values:
	//-----------------------------
	COleDateTime minAllowedDate (iFirstAllowedYear, 1, 1, 0, 0, 0);
	COleDateTime maxAllowedDate (iLastAllowedYear, 12, 31, 23, 59, 59);
	COleDateTime emptyDate;

	m_MinDate = max (m_MinDate, minAllowedDate);

	if (m_MaxDate != emptyDate)
	{
		m_MaxDate = min (m_MaxDate, maxAllowedDate);
	}
	else
	{
		m_MaxDate = maxAllowedDate;
	}

	InvalidateControl ();
}
//*****************************************************************************************
void CBCGDateTimeCtrl::DrawCheckBox (CDC* pDC)
{
	if (!m_bCheckBoxIsAvailable)
	{
		return;
	}

	ASSERT_VALID (pDC);

	pDC->FillSolidRect (&m_rectCheck, ::GetSysColor (COLOR_WINDOW));

	if (m_bShowSelection && m_CurrPartType == CHECK_BOX)
	{
		pDC->DrawFocusRect (&m_rectCheck);
	}

	CRect rect = m_rectCheck;
	rect.InflateRect (-2, -2);

	pDC->Draw3dRect (&rect, 
					::GetSysColor (COLOR_3DDKSHADOW),
					::GetSysColor (COLOR_3DHILIGHT));
	
	rect.InflateRect (-1, -1);
	pDC->Draw3dRect (&rect,
					::GetSysColor (COLOR_3DSHADOW),
					::GetSysColor (COLOR_3DLIGHT));

	if (m_bIsChecked)
	{
		rect.InflateRect (-1, -1);
		m_Images.Draw (pDC, m_enabled ? 0 : 7, rect.TopLeft (), ILD_NORMAL);
	}
}
//*****************************************************************************************
void CBCGDateTimeCtrl::DrawDateDropButton (CDC* pDC)
{
	if (!m_dropCalendar || !m_showDate)
	{
		return;
	}

	BOOL bPressed = m_bDropButtonIsPressed && m_bMouseOnDropButton;

	pDC->FillSolidRect (&m_rectDropButton, 
						::GetSysColor (COLOR_3DFACE));

	CRect rect = m_rectDropButton;

	pDC->Draw3dRect (&rect, 
		bPressed ? 
			::GetSysColor (COLOR_3DDKSHADOW) :
			::GetSysColor (COLOR_3DLIGHT) ,
		bPressed ?
			::GetSysColor (COLOR_3DLIGHT) :
			::GetSysColor (COLOR_3DDKSHADOW));
	
	rect.InflateRect (-1, -1);
	pDC->Draw3dRect (&rect,
		bPressed ?
		::GetSysColor (COLOR_3DSHADOW) :
		::GetSysColor (COLOR_3DHILIGHT),
		bPressed ? 
			::GetSysColor (COLOR_3DHILIGHT) :
			::GetSysColor (COLOR_3DSHADOW));

	IMAGEINFO imageInfo;
	int iImage = (m_bIsChecked && m_enabled) ? 1 : 2;
	m_Images.GetImageInfo (iImage, &imageInfo);

	CRect rectImage = imageInfo.rcImage;
	CPoint pointImage (
		rect.left + (rect.Width () - rectImage.Width ()) / 2,
		rect.top + (rect.Height () - rectImage.Height ()) / 2);

	if (bPressed)
	{
		pointImage.Offset (1, 1);
	}

	m_Images.Draw (pDC, iImage, pointImage, ILD_NORMAL);
}
//*****************************************************************************************
void CBCGDateTimeCtrl::SelectNext ()
{
	if (m_iPartNum == -1 || !m_bIsChecked)
	{
		return;
	}

	int iPrevPart = m_iPartNum;

	if (m_iPartNum == m_iPartsNumber - 1)	// Last
	{
		m_iPartNum = 0;
	}
	else
	{
		m_iPartNum ++;
	}

	m_CurrPartType = m_arPartsOrder [m_iPartNum];

	CRect rectPart;

	GetPartRect (iPrevPart, rectPart);
	InvalidateControl (rectPart);

	GetPartRect (m_iPartNum, rectPart);
	InvalidateControl (rectPart);
}
//*****************************************************************************************
void CBCGDateTimeCtrl::SelectPrev ()
{
	if (m_iPartNum == -1 || !m_bIsChecked)
	{
		return;
	}

	int iPrevPart = m_iPartNum;

	if (m_iPartNum == 0)	// First
	{
		m_iPartNum = m_iPartsNumber - 1;
	}
	else
	{
		m_iPartNum --;
	}

	m_CurrPartType = m_arPartsOrder [m_iPartNum];

	CRect rectPart;

	GetPartRect (iPrevPart, rectPart);
	InvalidateControl (rectPart);

	GetPartRect (m_iPartNum, rectPart);
	InvalidateControl (rectPart);
}
//*****************************************************************************************
void CBCGDateTimeCtrl::SetPartsOrder ()
{
	int i = 0;

	if (m_checkButton)
	{
		m_arPartsOrder [i ++] = CHECK_BOX;
		m_bCheckBoxIsAvailable = TRUE;
	}
	else
	{
		m_bCheckBoxIsAvailable = FALSE;
	}

	TCHAR szLocaleData [100];
	
	GetLocaleInfo (LOCALE_USER_DEFAULT, LOCALE_SDATE, szLocaleData, 100);
	m_strDateSeparator = szLocaleData [0] == 0 ? _T ("") : szLocaleData;

	GetLocaleInfo (LOCALE_USER_DEFAULT, LOCALE_STIME, szLocaleData, 100);
	m_strTimeSeparator = szLocaleData [0] == 0 ? _T ("") : szLocaleData;

	if (m_showDate)
	{
		GetLocaleInfo (LOCALE_USER_DEFAULT, LOCALE_IDATE, szLocaleData, 100);
		switch (szLocaleData [0])
		{
		case '0':	// Month-Day-Year
		default:
			m_arPartsOrder [i ++] = MONTH;
			m_arPartsOrder [i ++] = DAY;
			m_arPartsOrder [i ++] = YEAR;
			break;

		case '1':	// Day-Month-Year
			m_arPartsOrder [i ++] = DAY;
			m_arPartsOrder [i ++] = MONTH;
			m_arPartsOrder [i ++] = YEAR;
			break;

		case '2':	// Year-Month-Day
			m_arPartsOrder [i ++] = YEAR;
			m_arPartsOrder [i ++] = MONTH;
			m_arPartsOrder [i ++] = DAY;
			break;
		}
	}

	if (m_showTime)
	{
		m_arPartsOrder [i ++] = HOUR;
		m_arPartsOrder [i ++] = MIN;

		GetLocaleInfo (LOCALE_USER_DEFAULT, LOCALE_ITIME, szLocaleData, 100);
		switch (szLocaleData [0])
		{
		case '0':	// AM/PM
		default:
			m_b24HoursFormat = FALSE;
			m_arPartsOrder [i ++] = AMPM;
			break;
		case '1':
			m_b24HoursFormat = TRUE;
			break;
		}
	}

	m_iPartsNumber = i;

	GetLocaleInfo (LOCALE_USER_DEFAULT, LOCALE_S1159, szLocaleData, 100);
	m_strAM = szLocaleData;
	m_strAM.MakeUpper ();
	GetLocaleInfo (LOCALE_USER_DEFAULT, LOCALE_S2359, szLocaleData, 100);
	m_strPM = szLocaleData;
	m_strPM.MakeUpper ();
}
//*****************************************************************************************
LPCTSTR CBCGDateTimeCtrl::GetPartFormat (int iPart) const
{
	switch (m_arPartsOrder [iPart])
	{
	case NO:
	case CHECK_BOX:
		return _T ("");
	case DAY:
		return _T ("%d");
	case MONTH:
		return _T ("%b");
	case YEAR:
		return _T ("%Y");
	case HOUR:
		return m_b24HoursFormat ? _T ("%H") : _T ("%I");
	case MIN:
		return _T ("%M");
	case AMPM:
		return _T ("%p");
	}

	return _T ("");
}
//*****************************************************************************************
int CBCGDateTimeCtrl::GetPartFromPoint (POINT point)
{
	for (int i = 0; i < m_iPartsNumber; i ++)
	{
		CRect rectPart;
		GetPartRect (i, rectPart);
				
		if (rectPart.PtInRect (point))
		{
			return i;
		}
	}

	return -1;
}
//*****************************************************************************************
BOOL CBCGDateTimeCtrl::GetPartRect (int iPart, CRect& rectOut, BOOL bWidest)
{
	if (iPart < 0 || iPart >= m_iPartsNumber)
	{
		return FALSE;
	}

	if (m_arPartsOrder [iPart] == CHECK_BOX)
	{
		rectOut = m_rectCheck;
		return TRUE;
	}

	CClientDC dc (this);

//	CFont* pPrevFont = SelectStockFont (&dc);
	CFont* pPrevFont = (CFont*) dc.SelectStockObject (DEFAULT_GUI_FONT);
	ASSERT (pPrevFont != NULL);

	int iStart = m_bCheckBoxIsAvailable ? 1 : 0;
	int x = m_rectText.left;

	int iPartLeft = 0;
	int iPartRight = 0;

	for (int i = iStart; i <= iPart; i ++)
	{
		iPartLeft = x;

		CString str = bWidest ? 
			m_WidestDate.Format (GetPartFormat (i)) :
			m_Date.Format (GetPartFormat (i));
		CString strSeparator = " ";
		if (i < m_iPartsNumber - 1)
		{
			if (IsDatePart (i) && IsDatePart (i + 1))
			{
				strSeparator = m_strDateSeparator;
			}

			if (IsTimePart (i) && IsTimePart (i + 1))
			{
				strSeparator = m_strTimeSeparator;
			}
		}
		str += strSeparator;

		CRect rect = m_rectText;
		rect.left = x;

		dc.DrawText (str, rect, DT_SINGLELINE | DT_VCENTER | DT_CALCRECT);

		x = rect.right;
		iPartRight = x;
	}

	rectOut = m_rectText;
	rectOut.left = iPartLeft;
	rectOut.right = iPartRight;

	dc.SelectObject (pPrevFont);
	return TRUE;
}
//*****************************************************************************************
void CBCGDateTimeCtrl::ScrollCurrPart (int iDir)
{
	int iDay = m_Date.GetDay ();
	int iMonth = m_Date.GetMonth ();
	int iYear = m_Date.GetYear ();
	int iHour = m_Date.GetHour ();
	int iMin = m_Date.GetMinute ();
	BOOL bLastDayInMonth = (iDay == theApp.GetDaysInMonth (iMonth, iYear));

	switch (m_CurrPartType)
	{
	case NO:
	case CHECK_BOX:
		return;

	case DAY:
		iDay += iDir;
		if (iDay <= 0)
		{
			iDay = theApp.GetDaysInMonth (iMonth, iYear);
		}

		if (iDay > theApp.GetDaysInMonth (iMonth, iYear))
		{
			iDay = 1;
		}
		break;

	case MONTH:
		iMonth += iDir;
		if (iMonth <= 0)
		{
			iMonth = 12;
		}

		if (iMonth > 12)
		{
			iMonth = 1;
		}
		
		if (bLastDayInMonth ||
			iDay > theApp.GetDaysInMonth (iMonth, iYear))
		{
			iDay = theApp.GetDaysInMonth (iMonth, iYear);
		}

		break;

	case YEAR:
		iYear += iDir;

		if (iDay > theApp.GetDaysInMonth (iMonth, iYear))
		{
			iDay = theApp.GetDaysInMonth (iMonth, iYear);
		}

		break;

	case HOUR:
		iHour += iDir;
		if (iHour < 0)
		{
			iHour = 23;
		}

		if (iHour > 23)
		{
			iHour = 0;
		}
		break;

	case MIN:
		iMin += iDir;
		if (iMin < 0)
		{
			iMin = 59;
		}

		if (iMin > 59)
		{
			iMin = 0;
		}
		break;

	case AMPM:
		if (iHour < 12)
		{
			iHour += 12;
		}
		else
		{
			iHour -= 12;
		}
	}

	COleDateTime date (iYear, iMonth, iDay, iHour, iMin, 0);

	if (iDir > 0 && date > m_MaxDate)
	{
		date = m_MaxDate;
	}

	if (iDir < 0 && date < m_MinDate)
	{
		date = m_MinDate;
	}

	if (m_Date == date || !IsDateValid (date))
	{
		MessageBeep (-1);
	}
	else
	{
		m_Date = date;
		InvalidateControl (m_rectText);

		FireOnDateChanged ();
	}
}
//*****************************************************************************************
void CBCGDateTimeCtrl::ScrollCurrPartToLimit (BOOL bTop)
{
	int iDay = m_Date.GetDay ();
	int iMonth = m_Date.GetMonth ();
	int iYear = m_Date.GetYear ();
	int iHour = m_Date.GetHour ();
	int iMin = m_Date.GetMinute ();

	switch (m_CurrPartType)
	{
	case NO:
	case CHECK_BOX:
	case AMPM:
	case YEAR:
		return;

	case DAY:
		if (bTop)
		{
			iDay = 1;
		}
		else
		{
			iDay = theApp.GetDaysInMonth (iMonth, iYear);
		}
		break;

	case MONTH:
		if (bTop)
		{
			iMonth = 1;
		}
		else
		{
			iMonth = 12;
		}
		break;

	case HOUR:
		if (bTop)
		{
			iHour = 0;
		}
		else
		{
			iHour = 23;
		}
		break;

	case MIN:
		if (bTop)
		{
			iMin = 0;
		}
		else
		{
			iMin = 59;
		}
		break;
	}

	COleDateTime date (iYear, iMonth, iDay, iHour, iMin, 0);
	if (!IsDateValid (date))
	{
		MessageBeep (-1);
	}
	else
	{
		if (m_Date != date)
		{
			m_Date = date;
			InvalidateControl (m_rectText);

			FireOnDateChanged ();
		}
	}
}
//*****************************************************************************************
void CBCGDateTimeCtrl::PushDigit (int iDigit)
{
	int iDay = m_Date.GetDay ();
	int iMonth = m_Date.GetMonth ();
	int iYear = m_Date.GetYear ();
	int iHour = m_Date.GetHour ();
	int iMin = m_Date.GetMinute ();

	int iNumber;
	if (m_iPrevDigit == -1)
	{
		iNumber = iDigit;
	}
	else
	{
		iNumber = m_iPrevDigit * 10 + iDigit;
	}

	switch (m_CurrPartType)
	{
	case NO:
	case CHECK_BOX:
	case MONTH:
	case AMPM:
		return;

	case DAY:
		iDay = iNumber;
		break;

	case HOUR:
		if (!m_b24HoursFormat)
		{
			BOOL bPM = (iHour >= 12);
			iHour = iNumber;

			if (iHour > 12)
			{
				iHour = iDigit;
			}

			if (bPM)
			{
				iHour += 12;
			}

			if (iHour == 24)
			{
				iHour = 0;
			}

			if (iDigit != 1)	// Only 10, 11 or 12 are allowed!
			{
				iDigit = -1;
			}
		}
		else	// Normal format
		{
			iHour = iNumber;
		}
		break;

	case MIN:
		iMin = iNumber;
		break;

	case YEAR:
		iYear = iYear / 100 * 100 + iNumber;

		//----------------------------------------
		// If the year is is less then 1950, jump
		// to the next century!
		//----------------------------------------
		if (iYear < iFirstAllowedYear)
		{
			iYear += 100;
		}

		if (iYear > iLastAllowedYear)
		{
			iYear -= 100;
		}
		break;
	}

	COleDateTime date (iYear, iMonth, iDay, iHour, iMin, 0);
	BOOL bValidDate = IsDateValid (date);
	
	if (!bValidDate)
	{
		MessageBeep (-1);
	}
	else
	{
		m_Date = date;
		InvalidateControl (m_rectText);

		FireOnDateChanged ();
	}

	if (m_iPrevDigit == -1)	// First push
	{
		m_iPrevDigit = iDigit;
	}
	else
	{
		if (bValidDate && m_iPartNum < m_iPartsNumber - 1)
		{
			SelectNext ();
		}

		m_iPrevDigit = -1;
	}
}
//*****************************************************************************************
void CBCGDateTimeCtrl::ChangeMonth (USHORT uiMonthLetter)
{
	int iDay = m_Date.GetDay ();
	int iMonth = m_Date.GetMonth ();
	int iYear = m_Date.GetYear ();
	int iHour = m_Date.GetHour ();
	int iMin = m_Date.GetMinute ();

	BOOL bLastDayInMonth = (iDay == theApp.GetDaysInMonth (iMonth, iYear));

	BOOL bFound = FALSE;
	for (int i = iMonth + 1; i != iMonth; i ++)
	{
		if (i > 12)
		{
			i = 1;
		}

		if (i == iMonth)
		{
			break;
		}

		//--------------------------------------------------
		// Compare manth 'i' first char with the typed char:
		//--------------------------------------------------
		CString strMonth = COleDateTime (iYear, i, 1, 0, 0, 0).Format (_T ("%b"));
		if (strMonth.GetLength () > 1 &&
			strMonth.GetAt (0) == (char) uiMonthLetter)
		{
			iMonth = i;
			bFound = TRUE;
			break;
		}
	}

	if (bFound)
	{
		if (bLastDayInMonth ||
			iDay > theApp.GetDaysInMonth (iMonth, iYear))
		{
			iDay = theApp.GetDaysInMonth (iMonth, iYear);
		}

		COleDateTime date (iYear, iMonth, iDay, iHour, iMin, 0);
		if (!IsDateValid (date))
		{
			MessageBeep (-1);
		}
		else
		{
			m_Date = date;
			InvalidateControl (m_rectText);

			FireOnDateChanged ();
		}
	}
	else
	{
		MessageBeep (-1);
	}
}
//*****************************************************************************************
void CBCGDateTimeCtrl::ChangeAmPm (USHORT uiAmPm)
{
	int iDay = m_Date.GetDay ();
	int iMonth = m_Date.GetMonth ();
	int iYear = m_Date.GetYear ();
	int iHour = m_Date.GetHour ();
	int iMin = m_Date.GetMinute ();

	CString str = (char) uiAmPm;
	str.MakeUpper ();

	if (str == m_strPM [0] && iHour < 12)
	{
		iHour += 12;
	}

	if (str == m_strAM [0] && iHour >= 12)
	{
		iHour -= 12;
	}

	COleDateTime date (iYear, iMonth, iDay, iHour, iMin, 0);
	if (!IsDateValid (date))
	{
		MessageBeep (-1);
	}
	else
	{
		if (m_Date != date)
		{
			m_Date = date;
			InvalidateControl (m_rectText);

			FireOnDateChanged ();
		}
	}
}
//*****************************************************************************************
void CBCGDateTimeCtrl::ToggleCheck ()
{
	m_bIsChecked = !m_bIsChecked;

	if (m_spinButton)
	{
		m_wndSpin.EnableWindow (m_bIsChecked);
	}

	COleDateTime emptyDate;
	if (m_bIsChecked && m_Date == emptyDate)
	{
		m_Date = COleDateTime::GetCurrentTime ();
		FireOnDateChanged ();
	}

	InvalidateControl ();
}
//*****************************************************************************************
BOOL CBCGDateTimeCtrl::IsDateValid (COleDateTime& date) const
{
	if (date.GetStatus () == COleDateTime::invalid)
	{
		return FALSE;
	}

	COleDateTime dateEmpty;

	if (m_MinDate != dateEmpty && date < m_MinDate)
	{
		return FALSE;
	}

	if (m_MaxDate != dateEmpty && date > m_MaxDate)
	{
		return FALSE;
	}

	return TRUE;
}
//*****************************************************************************************
BOOL CBCGDateTimeCtrl::IsDatePart (int iPart) const
{
	PART_TYPE type = m_arPartsOrder [iPart];
	return type == DAY || type == MONTH || type == YEAR;
}
//*****************************************************************************************
BOOL CBCGDateTimeCtrl::IsTimePart (int iPart) const
{
	PART_TYPE type = m_arPartsOrder [iPart];
	return type == HOUR || type == MIN;
}
//*****************************************************************************************
BOOL CBCGDateTimeCtrl::ShowDropCalendar ()
{
	if (!m_dropCalendar || !m_bIsChecked || !m_showDate)
	{
		return FALSE;
	}

	ASSERT (m_pWndDrop == NULL);

	m_pWndDrop = new CCalendarWnd;
	ASSERT (m_pWndDrop != NULL);

	m_pWndDrop->SetValidInterval (m_MinDate, m_MaxDate);
	m_pWndDrop->SetDate (m_Date);

	m_pWndDrop->m_clrBackColor = ::GetSysColor (COLOR_3DFACE);
	m_pWndDrop->m_clrSelBackColor = ::GetSysColor (COLOR_3DSHADOW);
	m_pWndDrop->m_clrSelTextColor = ::GetSysColor (COLOR_HIGHLIGHTTEXT);

	CRect rectClient;
	GetClientRect (&rectClient);

	CPoint pt (0, rectClient.bottom + 2);
	ClientToScreen (&pt);

	if (!m_pWndDrop->Create (WS_POPUP | WS_VISIBLE,
		pt.x, pt.y, this))
	{
		return FALSE;
	}

	m_bIsDateComboDropped = TRUE;

	m_pWndDrop->ShowWindow (SW_SHOW);
	m_pWndDrop->SetFocus ();

	return TRUE;
}
//*****************************************************************************************
BOOL CBCGDateTimeCtrl::HideDropCalendar (const COleDateTime* pDateNew)
{
	ASSERT (m_pWndDrop != NULL);

	if (pDateNew != NULL)
	{
		m_Date = *pDateNew;
	}

	m_pWndDrop->DestroyWindow ();
	delete m_pWndDrop;
	m_pWndDrop = NULL;

	m_bIsDateComboDropped = FALSE;

	if (pDateNew != NULL)
	{
		InvalidateControl ();
		FireOnDateChanged ();
	}

	return TRUE;
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnSetFocus(CWnd* pOldWnd) 
{
	COleControl::OnSetFocus(pOldWnd);

	if (m_iPartNum >= 0 && m_iPartNum < m_iPartsNumber)
	{
		m_CurrPartType = m_arPartsOrder [m_iPartNum];
	}

	m_bShowSelection = TRUE;
	InvalidateControl ();

	FireSetFocus ();
}
//****************************************************************************************
BOOL CBCGDateTimeCtrl::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
	if (wParam == iSpinID)
	{
		NM_UPDOWN* pNM = (NM_UPDOWN*) lParam;
		ASSERT (pNM != NULL);

		if (pNM->hdr.code == UDN_DELTAPOS)
		{
			ScrollCurrPart (pNM->iDelta < 0 ? 1 : -1);
		}

		SetFocus ();
	}
	
	return COleControl::OnNotify(wParam, lParam, pResult);
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnKillFocus(CWnd* pNewWnd) 
{
	m_bShowSelection = FALSE;
	m_iPrevDigit = -1;
	InvalidateControl ();

	if (m_pWndDrop == NULL)/* || pNewWnd == NULL ||
		m_pWndDrop->m_hWnd != pNewWnd->m_hWnd)*/
	{		
		FireOnKillFocus (pNewWnd == NULL ? 0 : (long) pNewWnd->GetSafeHwnd ());
	}

	COleControl::OnKillFocus(pNewWnd);
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnCheckButtonChanged() 
{
	AdjustControl ();
	SetModifiedFlag();
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnDropCalendarChanged() 
{
	AdjustControl ();
	SetModifiedFlag();
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnShowDateChanged() 
{
	AdjustControl ();
	SetModifiedFlag();
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnShowTimeChanged() 
{
	AdjustControl ();
	SetModifiedFlag();
}
//****************************************************************************************
void CBCGDateTimeCtrl::OnSpinButtonChanged() 
{
	AdjustControl ();
	SetModifiedFlag();
}
//*****************************************************************************************
void CBCGDateTimeCtrl::BuidWidestDate ()
{
	if (GetSafeHwnd () == NULL)	// Control doesn't created yet (e.g., AppStudio)
	{
		return;
	}

	CClientDC dc (this);
	CFont* pPrevFont = (CFont*) dc.SelectStockObject (DEFAULT_GUI_FONT);
	ASSERT (pPrevFont != NULL);

	//-----------------------
	// Find the widest month:
	//-----------------------
	int iMaxMonthWidth = 0;
	int iMaxMonth = 1;

	for (int iMonth = 1; iMonth <= 12; iMonth ++)
	{
		COleDateTime date (1998, iMonth, 1, 0, 0, 0);
		CString strMonth = date.Format (_T ("%b"));

		int iMonthWidth = dc.GetTextExtent (strMonth).cx;
		if (iMonthWidth > iMaxMonthWidth)
		{
			iMaxMonthWidth = iMonthWidth;
			iMaxMonth = iMonth;
		}
	}

	dc.SelectObject (pPrevFont);
	m_WidestDate = COleDateTime (2000, iMaxMonth, 20, 0, 0, 0);
}
//****************************************************************************************
void CBCGDateTimeCtrl::SizeToContent() 
{
	AdjustControl ();
}
