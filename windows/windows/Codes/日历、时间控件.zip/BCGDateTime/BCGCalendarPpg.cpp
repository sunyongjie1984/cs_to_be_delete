// BCGCalendarPpg.cpp : Implementation of the CBCGCalendarPropPage property page class.

#include "stdafx.h"
#include "BCGDateTime.h"
#include "BCGCalendarPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CBCGCalendarPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CBCGCalendarPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CBCGCalendarPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CBCGCalendarPropPage, "BCGDATETIME.BCGCalendarPropPage.1",
	0x1b9ac5e, 0xa128, 0x11d1, 0xa6, 0x37, 0, 0xa0, 0xc9, 0x3a, 0x70, 0xec)


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarPropPage::CBCGCalendarPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CBCGCalendarPropPage

BOOL CBCGCalendarPropPage::CBCGCalendarPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_BCGCALENDAR_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarPropPage::CBCGCalendarPropPage - Constructor

CBCGCalendarPropPage::CBCGCalendarPropPage() :
	COlePropertyPage(IDD, IDS_BCGCALENDAR_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CBCGCalendarPropPage)
	m_MultiplySelection = FALSE;
	m_AbsoluteSelectionMode = FALSE;
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarPropPage::DoDataExchange - Moves data between page and properties

void CBCGCalendarPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CBCGCalendarPropPage)
	DDP_Check(pDX, IDC_MULT_SELECTION, m_MultiplySelection, _T("MultiplySelection") );
	DDX_Check(pDX, IDC_MULT_SELECTION, m_MultiplySelection);
	DDP_Check(pDX, IDC_ABSOLUTE_SELECTION_MODE, m_AbsoluteSelectionMode, _T("AbsoluteSelectionMode") );
	DDX_Check(pDX, IDC_ABSOLUTE_SELECTION_MODE, m_AbsoluteSelectionMode);
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarPropPage message handlers
