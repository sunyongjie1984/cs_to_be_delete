// DateTimeAboutDlg.cpp : implementation file
//

#include "stdafx.h"
#include "bcgdatetime.h"
#include "DateTimeAboutDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDateTimeAboutDlg dialog


CDateTimeAboutDlg::CDateTimeAboutDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDateTimeAboutDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDateTimeAboutDlg)
	//}}AFX_DATA_INIT
}


void CDateTimeAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDateTimeAboutDlg)
	DDX_Control(pDX, IDC_WEB, m_btnWeb);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDateTimeAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CDateTimeAboutDlg)
	ON_BN_CLICKED(IDC_WEB, OnWeb)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDateTimeAboutDlg message handlers

void CDateTimeAboutDlg::OnWeb() 
{
	CString str;
	m_btnWeb.GetWindowText (str);

	BeginWaitCursor ();

	if (ShellExecute (NULL, NULL, str, NULL, NULL, NULL) < (HINSTANCE) 32)
	{
		MessageBox (_T("Can't open URL."));
	}

	EndWaitCursor ();
}
//***************************************************************************************
BOOL CDateTimeAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// Fill version information:
	CString strVer;
	if (GetVersion (strVer))
	{
		SetDlgItemText (IDC_VERSION, strVer);
	}

	m_hcurHand = theApp.LoadCursor (IDC_CURSOR);
	m_btnWeb.m_hCursor = m_hcurHand;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
//***************************************************************************************
BOOL CDateTimeAboutDlg::GetVersion (CString& strOut) const
{
	TCHAR szFullPath [_MAX_PATH];
	GetModuleFileName (AfxGetInstanceHandle (), szFullPath, sizeof(szFullPath));

	DWORD dwVerHnd;
	DWORD dwVerInfoSize = GetFileVersionInfoSize (szFullPath, &dwVerHnd);

	if (dwVerInfoSize == 0)
	{
		return FALSE; 
	}

	// If we were able to get the information, process it: 
	HANDLE  hMem;
	LPVOID  lpvMem;

	hMem = GlobalAlloc(GMEM_MOVEABLE, dwVerInfoSize);
	lpvMem = GlobalLock(hMem);
	GetFileVersionInfo(szFullPath, dwVerHnd, dwVerInfoSize, lpvMem);

	BOOL  bRet;
	UINT  cchVer = 0;
	LPSTR lszVer = NULL;

	bRet = VerQueryValue (lpvMem, 
						TEXT("\\StringFileInfo\\040904B0\\ProductVersion"), 
						(LPVOID*) &lszVer, &cchVer);

	if (bRet && cchVer && lszVer)
	{ 
		strOut = lszVer;
	} 

	GlobalUnlock(hMem);
	GlobalFree(hMem);

	return bRet;
}
//***************************************************************************************
void CDateTimeAboutDlg::OnDestroy() 
{
	DeleteObject (m_hcurHand);
	CDialog::OnDestroy();
}
