#if !defined(AFX_BCGCALENDARPPG_H__01B9AC72_A128_11D1_A637_00A0C93A70EC__INCLUDED_)
#define AFX_BCGCALENDARPPG_H__01B9AC72_A128_11D1_A637_00A0C93A70EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// BCGCalendarPpg.h : Declaration of the CBCGCalendarPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CBCGCalendarPropPage : See BCGCalendarPpg.cpp.cpp for implementation.

class CBCGCalendarPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CBCGCalendarPropPage)
	DECLARE_OLECREATE_EX(CBCGCalendarPropPage)

// Constructor
public:
	CBCGCalendarPropPage();

// Dialog Data
	//{{AFX_DATA(CBCGCalendarPropPage)
	enum { IDD = IDD_PROPPAGE_BCGCALENDAR };
	BOOL	m_MultiplySelection;
	BOOL	m_AbsoluteSelectionMode;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CBCGCalendarPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BCGCALENDARPPG_H__01B9AC72_A128_11D1_A637_00A0C93A70EC__INCLUDED)
