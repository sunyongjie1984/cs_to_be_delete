// CalendarToolBarWnd.cpp : implementation file
//

#include "stdafx.h"
#include "BCGDateTime.h"
#include "CalendarToolBarWnd.h"
#include "CalendarWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCalendarToolBarWnd

CString CCalendarToolBarWnd::m_strClassName = _T("");

static const COLORREF clrTransparent = RGB (255, 0, 255);
static const int iImageWidth = 10;
static const int iHorzOffset = 10;
static const int iIdClickButtonEvt = 1;

static const int iSlowTimerDuration = 300;
static const int iFastTimerDuration = 100;
static const int iNumberOfSlowTimes = 10;

CCalendarToolBarWnd::CCalendarToolBarWnd() :
	m_clrBackColor (::GetSysColor (COLOR_3DFACE)),
	m_clrLightColor (::GetSysColor (COLOR_3DHILIGHT)),
	m_clrShadowColor (::GetSysColor (COLOR_3DDKSHADOW)),
	m_pParentCalendar (NULL),
	m_iTrackedButton (-1),
	m_iPressedButton (-1),
	m_iWindowHeight (0),
	m_iButtonHeight (0)
{
}

CCalendarToolBarWnd::~CCalendarToolBarWnd()
{
}


BEGIN_MESSAGE_MAP(CCalendarToolBarWnd, CWnd)
	//{{AFX_MSG_MAP(CCalendarToolBarWnd)
	ON_WM_CREATE()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CCalendarToolBarWnd message handlers

BOOL CCalendarToolBarWnd::Create (const RECT& rect, CWnd* pParentWnd, UINT nID) 
{
	if (m_strClassName.IsEmpty ())
	{
		m_strClassName = ::AfxRegisterWndClass (0);
	}

	ASSERT_KINDOF (CCalendarWnd, pParentWnd);
	m_pParentCalendar = (CCalendarWnd*) pParentWnd;

	return CWnd::Create (m_strClassName, _T(""), WS_CHILD | WS_VISIBLE, rect, pParentWnd, nID);
}
//**************************************************************************************
int CCalendarToolBarWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
	{
		return -1;
	}

	//------------------	
	// Load images list:
	//------------------	
	BOOL bRC = m_Images.Create (IDB_CALENDAR_BUTTONS, iImageWidth, 0, clrTransparent);
	if (!bRC)
	{
		TRACE (_T ("CCalendarToolBarWnd: Can't load images list!\n"));
		return -1;
	}

	//--------------------
	// Define image size:
	//--------------------
	IMAGEINFO imageInfo;
	m_Images.GetImageInfo (0, &imageInfo);

	CRect rectImage = imageInfo.rcImage;
	m_ImageSize = rectImage.Size ();

	//----------------------
	// Define text height:
	//----------------------
	CClientDC dc (this);
	CFont* pOldFont = (CFont*) dc.SelectStockObject (DEFAULT_GUI_FONT);

	TEXTMETRIC tm;
	dc.GetTextMetrics (&tm);

	dc.SelectObject (pOldFont);

	//--------------------------
	// Calculate buttons height:
	//--------------------------
	m_iButtonHeight = max (m_ImageSize.cy * 2, tm.tmHeight);
	m_iWindowHeight = 3 * m_iButtonHeight / 2 + 2;

	//-------------------
	// Load "Today" text:
	//-------------------
	m_strTodayLabel.LoadString (IDS_TODAY);

	//---------------------------
	// Create and adjust tooltip:
	//---------------------------
	CRect rectEmpty (0, 0, 0, 0);	// Will be adjusted in "OnSize"

	if (m_ToolTip.Create (this, TTS_ALWAYSTIP) && 
		m_ToolTip.AddTool (this, IDS_PREV_YEAR, &rectEmpty, 1) &&
		m_ToolTip.AddTool (this, IDS_PREV_MONTH, &rectEmpty, 2) &&
		m_ToolTip.AddTool (this, IDS_NEXT_MONTH, &rectEmpty, 3) && 
		m_ToolTip.AddTool (this, IDS_NEXT_YEAR, &rectEmpty, 4))
	{
		m_ToolTip.SendMessage (TTM_SETMAXTIPWIDTH, 0, SHRT_MAX);
		m_ToolTip.SendMessage (TTM_SETDELAYTIME, TTDT_AUTOPOP, SHRT_MAX);
		m_ToolTip.SendMessage (TTM_SETDELAYTIME, TTDT_INITIAL, 500);
		m_ToolTip.SendMessage (TTM_SETDELAYTIME, TTDT_RESHOW, 500);
	}
	else
	{
		TRACE(_T ("CCalendarToolBarWnd: Error in creating ToolTip"));
	}

	return 0;
}
//**************************************************************************************
void CCalendarToolBarWnd::OnLButtonUp(UINT nFlags, CPoint point) 
{
	KillTimer (iIdClickButtonEvt);
	ReleaseCapture ();
	
	RelayEvent (WM_LBUTTONUP, 
		(WPARAM)nFlags, MAKELPARAM(LOWORD(point.x), LOWORD(point.y)));

	m_iTrackedButton = HitTest (point);
	if (m_iTrackedButton == m_iPressedButton &&
		m_iTrackedButton != -1)
	{
		OnClickButton (m_iTrackedButton);
	}

	int iRedraw1 = m_iPressedButton;
	int iRedraw2 = m_iTrackedButton;

	m_iPressedButton = -1;
	m_iTrackedButton = -1;

	if (iRedraw1 != -1)
	{
		InvalidateRect (m_rectButtons [iRedraw1]);
	}

	if (iRedraw2 != -1)
	{
		InvalidateRect (m_rectButtons [iRedraw2]);
	}

	UpdateWindow ();

	CWnd::OnLButtonUp(nFlags, point);
}
//**************************************************************************************
void CCalendarToolBarWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{
	ASSERT (m_pParentCalendar != NULL);
	m_pParentCalendar->SetFocus ();

	RelayEvent(WM_LBUTTONDOWN, (WPARAM)nFlags,
                MAKELPARAM(LOWORD(point.x), LOWORD(point.y)));

	m_iTrackedButton = m_iPressedButton = HitTest (point);
	if (m_iTrackedButton != -1)
	{
		InvalidateRect (m_rectButtons [m_iTrackedButton]);
		UpdateWindow ();

		if (m_iTrackedButton != TODAY)
		{
			m_bSlowTimerMode = TRUE;
			m_iSlowTimerCount = 0;
			SetTimer (iIdClickButtonEvt, iSlowTimerDuration, NULL);
		}
	}
	
	CWnd::OnLButtonDown(nFlags, point);
}
//**************************************************************************************
void CCalendarToolBarWnd::OnMouseMove(UINT nFlags, CPoint point) 
{
	RelayEvent(WM_MOUSEMOVE, (WPARAM)nFlags,
			MAKELPARAM(LOWORD(point.x), LOWORD(point.y)));

	int iPrevTrackButton = m_iTrackedButton;
	m_iTrackedButton = HitTest (point);

	if (m_iTrackedButton != iPrevTrackButton)
	{
		BOOL bNeedUpdate = FALSE;

		if ((m_iPressedButton == -1 || iPrevTrackButton == m_iPressedButton) &&
			iPrevTrackButton != -1)
		{
			InvalidateRect (m_rectButtons [iPrevTrackButton]);
			bNeedUpdate = TRUE;
		}

		if ((m_iPressedButton == -1 || m_iTrackedButton == m_iPressedButton) &&
			m_iTrackedButton != -1)
		{
			InvalidateRect (m_rectButtons [m_iTrackedButton]);
			bNeedUpdate = TRUE;
		}

		if (bNeedUpdate)
		{
			UpdateWindow ();
		}

		if (m_iTrackedButton != -1)
		{
			if (iPrevTrackButton == -1)
			{
				SetCapture ();
			}
		}
		else
		{
			if (m_iPressedButton == -1)
			{
				ReleaseCapture ();
			}
		}
	}

	CWnd::OnMouseMove(nFlags, point);
}
//**************************************************************************************
void CCalendarToolBarWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	CRect rectClient;
	GetClientRect (&rectClient);

	for (int i = 0; i < BUTTONS_NUM; i ++)
	{
		CRect rect = m_rectButtons [i];

		if (dc.RectVisible (rect))
		{
			BOOL bPressed = (i == m_iPressedButton);
			BOOL bTracked = (i == m_iTrackedButton);

			if (i == TODAY)
			{
				//----------------------------------------
				// Draw button text ("Today" button only):
				//----------------------------------------

				dc.SetBkMode (TRANSPARENT);
				dc.SelectStockObject (DEFAULT_GUI_FONT);
				dc.SetTextColor (bTracked ? 
					::GetSysColor (COLOR_HIGHLIGHT) : m_clrTextColor);

				CRect rectText = rect;
				if (bPressed && bTracked)
				{
					rectText.OffsetRect (1, 1);
				}

				dc.DrawText (m_strTodayLabel, rectText, 
							DT_SINGLELINE | DT_VCENTER | DT_CENTER);
			}
			else
			{
				//-------------------------------------------
				// Draw button image (except "Today" button):
				//-------------------------------------------
				CPoint pointImage (
					rect.left + (rect.Width () - m_ImageSize.cx) / 2,
					rect.top + (rect.Height () - m_ImageSize.cy) / 2);

				if (bPressed && bTracked)
				{
					pointImage.Offset (1, 1);
				}

				m_Images.Draw (&dc, bTracked ? i + BUTTONS_NUM : i, pointImage, ILD_NORMAL);
			}

			//----------------------------------------------------
			// Draw 3-d border for the tracked or pressed buttons:
			//----------------------------------------------------
			if (bTracked || bPressed)
			{
				dc.Draw3dRect (&rect,
					bPressed && bTracked ? 
						m_clrShadowColor :
						m_clrLightColor,
					bPressed && bTracked ?
						m_clrLightColor :
						m_clrShadowColor);
			}
		}
	}

	//-------------------------------------------
	// Draw horizontal line on the top of window:
	//-------------------------------------------
	CPen pen1 (PS_SOLID, 1, m_clrLightColor);
	CPen* pPenPrev = (CPen*) dc.SelectObject (&pen1);

	int y = rectClient.top + 1;

	int x1 = rectClient.left + iHorzOffset;
	int x2 = rectClient.right - iHorzOffset;

	dc.MoveTo (x1, y);
	dc.LineTo (x2, y);

	CPen pen2 (PS_SOLID, 1, m_clrShadowColor);
	dc.SelectObject (&pen2);

	dc.MoveTo (x1, y - 1);
	dc.LineTo (x2, y - 1);

	dc.SelectObject (pPenPrev);
}
//**************************************************************************************
BOOL CCalendarToolBarWnd::OnEraseBkgnd(CDC* pDC) 
{
	CRect rectClient;
	GetClientRect (&rectClient);

	pDC->FillSolidRect (&rectClient, m_clrBackColor);
	return TRUE;
}
//**************************************************************************************
void CCalendarToolBarWnd::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

	CRect rectClient;
	GetClientRect (&rectClient);
	rectClient.top += 2;	// Leave space for horiz.line

	int iBtnWidth = m_ImageSize.cy * 2;	// Expect TODAY button
	int yOffset = (rectClient.Height () - m_iButtonHeight) / 2;

	//-----------------------------
	// Calculate button rectangles:
	//-----------------------------
	for (int i = 0; i < BUTTONS_NUM; i ++)
	{
		m_rectButtons [i].top = rectClient.top + yOffset;
		m_rectButtons [i].bottom = m_rectButtons [i].top + m_iButtonHeight;
	}

	m_rectButtons [PREV_YEAR].left = rectClient.left + iHorzOffset;
	m_rectButtons [PREV_YEAR].right = m_rectButtons [PREV_YEAR].left + iBtnWidth;

	m_rectButtons [PREV_MONTH].left = m_rectButtons [PREV_YEAR].right + 1;
	m_rectButtons [PREV_MONTH].right = m_rectButtons [PREV_MONTH].left + iBtnWidth;

	m_rectButtons [NEXT_YEAR].right = rectClient.right - iHorzOffset;
	m_rectButtons [NEXT_YEAR].left = m_rectButtons [NEXT_YEAR].right - iBtnWidth;

	m_rectButtons [NEXT_MONTH].right = m_rectButtons [NEXT_YEAR].left - 1;
	m_rectButtons [NEXT_MONTH].left = m_rectButtons [NEXT_MONTH].right - iBtnWidth;

	m_rectButtons [TODAY].left = m_rectButtons [PREV_MONTH].right + 1;
	m_rectButtons [TODAY].right = m_rectButtons [NEXT_MONTH].left - 1;

	//---------------------------
	// Adjust tooltip rectangles:
	//---------------------------
	m_ToolTip.SetToolRect (this, 1, m_rectButtons [PREV_YEAR]);
	m_ToolTip.SetToolRect (this, 2, m_rectButtons [PREV_MONTH]);
	m_ToolTip.SetToolRect (this, 3, m_rectButtons [NEXT_MONTH]);
	m_ToolTip.SetToolRect (this, 4, m_rectButtons [NEXT_YEAR]);
}
//*************************************************************************************
int CCalendarToolBarWnd::HitTest (POINT pt) const
{
	for (int i = 0; i < BUTTONS_NUM; i ++)
	{
		if (m_rectButtons [i].PtInRect (pt))
		{
			return i;
		}
	}

	return -1;
}
//**************************************************************************************
void CCalendarToolBarWnd::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent != iIdClickButtonEvt)
	{
		return;
	}

	if (m_iTrackedButton == m_iPressedButton)
	{
		OnClickButton (m_iTrackedButton);

		if (m_bSlowTimerMode && m_iSlowTimerCount ++ >= iNumberOfSlowTimes)
		{
			m_bSlowTimerMode = FALSE;
			KillTimer (iIdClickButtonEvt);
			SetTimer (iIdClickButtonEvt, iFastTimerDuration, NULL);
		}
	}
}
//**************************************************************************************
void CCalendarToolBarWnd::OnClickButton (int iButton)
{
	ASSERT (m_pParentCalendar != NULL);
	m_pParentCalendar->OnToolbarNotifyClickButton ((BUTTON_ID)iButton);
}
//**************************************************************************************
void CCalendarToolBarWnd::AlignInParentClientArea (BOOL bBottom)
{
	ASSERT (m_pParentCalendar != NULL);
	
	if (m_pParentCalendar->m_hWnd == NULL)
	{
		return;
	}

	CRect rectParentClient;
	m_pParentCalendar->GetClientRect (&rectParentClient);

	int y = (bBottom) ? 
		rectParentClient.bottom - m_iWindowHeight - 2: 
		rectParentClient.top + 2;

	SetWindowPos (NULL, rectParentClient.left + 2, y,
						rectParentClient.Width () - 4, m_iWindowHeight,
						SWP_NOZORDER);
}
//****************************************************************************************
void CCalendarToolBarWnd::RelayEvent(UINT message, WPARAM wParam, LPARAM lParam) 
{ 
	if (m_ToolTip.m_hWnd != NULL)
	{
         MSG msg;

         msg.hwnd= m_hWnd;
         msg.message= message;
         msg.wParam= wParam;
         msg.lParam= lParam;
         msg.time= 0;
         msg.pt.x= LOWORD (lParam);
         msg.pt.y= HIWORD (lParam);

         m_ToolTip.RelayEvent(&msg);
     }
}
