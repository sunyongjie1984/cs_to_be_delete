// CalendarCaptionWnd.cpp : implementation file
//

#include "stdafx.h"
#include "BCGDateTime.h"
#include "CalendarCaptionWnd.h"
#include "CalendarWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCalendarCaptionWnd

CString CCalendarCaptionWnd::m_strClassName = _T("");

CCalendarCaptionWnd::CCalendarCaptionWnd() :
	m_pParentCalendar (NULL),
	m_iTrackedButton (0),
	m_iPressedButton (0),
	m_bEnabled (FALSE),
	m_iFirstDayOfWeek (0)
{
	m_arLabels.SetSize (DAYS_IN_WEEK);
	m_Date = COleDateTime::GetCurrentTime ();
}
//****************************************************************************************
CCalendarCaptionWnd::~CCalendarCaptionWnd()
{
}


BEGIN_MESSAGE_MAP(CCalendarCaptionWnd, CWnd)
	//{{AFX_MSG_MAP(CCalendarCaptionWnd)
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CCalendarCaptionWnd message handlers

BOOL CCalendarCaptionWnd::Create(const RECT& rect, CWnd* pParentWnd, UINT nID) 
{
	if (m_strClassName.IsEmpty ())
	{
		m_strClassName = ::AfxRegisterWndClass (0);
	}

	ASSERT_KINDOF (CCalendarWnd, pParentWnd);
	m_pParentCalendar = (CCalendarWnd*) pParentWnd;

	return CWnd::Create (m_strClassName, _T(""), WS_CHILD | WS_VISIBLE, rect, pParentWnd, nID);
}
//****************************************************************************************
void CCalendarCaptionWnd::OnLButtonUp(UINT nFlags, CPoint point) 
{
	ASSERT (m_pParentCalendar != NULL);

	ReleaseCapture ();
	
	m_iTrackedButton = HitTest (point);
	if (m_iTrackedButton == m_iPressedButton &&
		m_iTrackedButton != 0)
	{
		m_pParentCalendar->SelectDayInWeek (m_iTrackedButton, 
											(nFlags & MK_CONTROL) == 0);
	}

	int iRedraw1 = m_iPressedButton;
	int iRedraw2 = m_iTrackedButton;

	m_iPressedButton = 0;
	m_iTrackedButton = 0;

	if (iRedraw1 != 0)
	{
		InvalidateDay (iRedraw1);
	}

	if (iRedraw2 != 0)
	{
		InvalidateDay (iRedraw2);
	}

	UpdateWindow ();

	CWnd::OnLButtonUp(nFlags, point);
}
//****************************************************************************************
void CCalendarCaptionWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{
	ASSERT (m_pParentCalendar != NULL);
	m_pParentCalendar->SetFocus ();

	m_iTrackedButton = m_iPressedButton = HitTest (point);
	if (m_iTrackedButton != 0)
	{
		InvalidateDay (m_iTrackedButton);
		UpdateWindow ();
	}
}
//****************************************************************************************
void CCalendarCaptionWnd::OnMouseMove(UINT nFlags, CPoint point) 
{
	int iPrevTrackButton = m_iTrackedButton;
	m_iTrackedButton = HitTest (point);

	if (m_iTrackedButton != iPrevTrackButton)
	{
		BOOL bNeedUpdate = FALSE;

		if ((m_iPressedButton == 0 || iPrevTrackButton == m_iPressedButton) &&
			iPrevTrackButton != 0)
		{
			InvalidateDay (iPrevTrackButton);
			bNeedUpdate = TRUE;
		}

		if ((m_iPressedButton == 0 || m_iTrackedButton == m_iPressedButton) &&
			m_iTrackedButton != 0)
		{
			InvalidateDay (m_iTrackedButton);
			bNeedUpdate = TRUE;
		}

		if (bNeedUpdate)
		{
			UpdateWindow ();
		}

		if (m_iTrackedButton != 0)
		{
			if (iPrevTrackButton == 0)
			{
				SetCapture ();
			}
		}
		else
		{
			if (m_iPressedButton == 0)
			{
				ReleaseCapture ();
			}
		}
	}

	CWnd::OnMouseMove(nFlags, point);
}
//****************************************************************************************
void CCalendarCaptionWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	CRect rectClient;
	GetClientRect (&rectClient);

	dc.SetBkMode (TRANSPARENT);
	dc.SelectStockObject (DEFAULT_GUI_FONT);

	//-----------------------------------------
	// Draw title (calendar's highlighted month):
	//-----------------------------------------
	CRect rectTitle = rectClient;
	rectTitle.bottom = rectTitle.top + rectClient.Height () / 2;

	dc.FillSolidRect (&rectTitle, ::GetSysColor (COLOR_ACTIVECAPTION));
	dc.Draw3dRect (	&rectTitle,
					::GetSysColor (COLOR_3DHILIGHT),
					::GetSysColor (COLOR_3DDKSHADOW));

	CString strTitle = m_Date.Format (_T ("%B %Y"));
	dc.SetTextColor (::GetSysColor (COLOR_CAPTIONTEXT));
	dc.DrawText (strTitle, rectTitle, DT_SINGLELINE | DT_VCENTER | DT_CENTER);

	//--------------------
	// Draw week days row:
	//--------------------
	int iDayCaptionsHeight = rectClient.Height () / 2;

	CRect rectDays = rectClient;
	rectDays.top = rectTitle.bottom + 1;

	if (m_bEnabled)
	{
		dc.FillSolidRect (&rectDays, ::GetSysColor (COLOR_3DFACE));
		dc.SetTextColor (::GetSysColor (COLOR_BTNTEXT));
	}
	else
	{
		dc.FillSolidRect (&rectDays, ::GetSysColor (COLOR_INACTIVECAPTION));
		dc.SetTextColor (::GetSysColor (COLOR_INACTIVECAPTIONTEXT));
	}

	for (int iWeekDay = 1; iWeekDay <= DAYS_IN_WEEK; iWeekDay ++)
	{
		CRect rect  = m_rectButtons [iWeekDay - 1];
		BOOL bPressed = (iWeekDay == m_iPressedButton);
		BOOL bTracked = (iWeekDay == m_iTrackedButton);

		if (bPressed && bTracked)
		{
			rect.OffsetRect (1, 1);
		}

		if (dc.RectVisible (rect))
		{
			dc.DrawText (m_arLabels [iWeekDay - 1], rect, 
						DT_SINGLELINE | DT_VCENTER | DT_CENTER);

			if (m_bEnabled)
			{
				//----------------------------------------------------
				// Draw 3-d border for the tracked or pressed buttons:
				//----------------------------------------------------
				if (bTracked || bPressed)
				{
					rect.InflateRect (0, -1);
					dc.Draw3dRect (&rect,
						bPressed && bTracked ? 
							::GetSysColor (COLOR_3DDKSHADOW) :
							::GetSysColor (COLOR_3DHILIGHT) ,
						bPressed && bTracked ?
							::GetSysColor (COLOR_3DHILIGHT) :
							::GetSysColor (COLOR_3DDKSHADOW));
				}
			}
		}
	}
}
//****************************************************************************************
BOOL CCalendarCaptionWnd::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}
//****************************************************************************************
void CCalendarCaptionWnd::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);
	
	CRect rectClient;
	GetClientRect (&rectClient);

	int iDayWidth = (cx - 20) / DAYS_IN_WEEK;

	//-------------------------
	// Define button locations:
	//-------------------------
	for (int iWeekDay = 0; iWeekDay < DAYS_IN_WEEK; iWeekDay ++)
	{
		m_rectButtons [iWeekDay] = rectClient;

		m_rectButtons [iWeekDay].top += cy / 2 + 1;
		m_rectButtons [iWeekDay].bottom --;
		m_rectButtons [iWeekDay].left = rectClient.left + iDayWidth * iWeekDay + 10;
		m_rectButtons [iWeekDay].right = m_rectButtons [iWeekDay].left + iDayWidth;
	}

	m_rectButtons [0].left = rectClient.left;
	m_rectButtons [DAYS_IN_WEEK - 1].right = rectClient.right;

	//---------------
	// Define labels:
	//---------------
	CClientDC dc (this);
	dc.SelectStockObject (DEFAULT_GUI_FONT);

	COleDateTimeSpan day (1, 0, 0, 0);
	int iMaxTextLength = iDayWidth - 4;

	for (iWeekDay = 0; iWeekDay < DAYS_IN_WEEK; iWeekDay ++)
	{
		COleDateTime dateTmp = COleDateTime::GetCurrentTime ();
		int iDay = (iWeekDay + m_iFirstDayOfWeek) % DAYS_IN_WEEK;

		while (dateTmp.GetDayOfWeek () != iDay + 1)
		{
			dateTmp += day;
		}

		CString strWeekDayName = dateTmp.Format (_T ("%a"));
		
		while (strWeekDayName.GetLength () > 0 &&
			dc.GetTextExtent (strWeekDayName).cx > iMaxTextLength)
		{
			strWeekDayName = strWeekDayName.Left (strWeekDayName.GetLength () - 1);
		}

		m_arLabels.SetAt (iWeekDay, strWeekDayName);
	}
}
//*************************************************************************************
int CCalendarCaptionWnd::HitTest (POINT pt) const
{
	if (m_bEnabled)
	{
		for (int i = 0; i < DAYS_IN_WEEK; i ++)
		{
			if (m_rectButtons [i].PtInRect (pt))
			{
				return i + 1;
			}
		}
	}

	return 0;
}
//*************************************************************************************
void CCalendarCaptionWnd::InvalidateDay (int iDay)
{
	if (iDay < 1 || iDay > DAYS_IN_WEEK)
	{
		return;
	}

	CRect rect = m_rectButtons [iDay - 1];
	rect.InflateRect (2, 2);

	InvalidateRect (rect);
}
//*************************************************************************************
void CCalendarCaptionWnd::SetDate (const COleDateTime& date)
{
	m_Date = date;
	
	if (::IsWindow (m_hWnd))
	{
		Invalidate ();
		UpdateWindow ();
	}
}
