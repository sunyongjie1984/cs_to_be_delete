#if !defined(AFX_BCGCALENDARCTL_H__01B9AC70_A128_11D1_A637_00A0C93A70EC__INCLUDED_)
#define AFX_BCGCALENDARCTL_H__01B9AC70_A128_11D1_A637_00A0C93A70EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// BCGCalendarCtl.h : Declaration of the CBCGCalendarCtrl ActiveX Control class.

#include "CalendarWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarCtrl : See BCGCalendarCtl.cpp for implementation.

class CBCGCalendarCtrl : public COleControl
{
	DECLARE_DYNCREATE(CBCGCalendarCtrl)

// Constructor
public:
	CBCGCalendarCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBCGCalendarCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

	// Attributes:
protected:
	CCalendarWnd	m_wndCalendar;

// Implementation
protected:
	~CBCGCalendarCtrl();

	BEGIN_OLEFACTORY(CBCGCalendarCtrl)        // Class factory and guid
		virtual BOOL VerifyUserLicense();
		virtual BOOL GetLicenseKey(DWORD, BSTR FAR*);
	END_OLEFACTORY(CBCGCalendarCtrl)

	DECLARE_OLETYPELIB(CBCGCalendarCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CBCGCalendarCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CBCGCalendarCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CBCGCalendarCtrl)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CBCGCalendarCtrl)
	BOOL m_multiplySelection;
	afx_msg void OnMultiplySelectionChanged();
	BOOL m_absoluteSelectionMode;
	afx_msg void OnAbsoluteSelectionModeChanged();
	OLE_COLOR m_backgroundColor;
	afx_msg void OnBackgroundColorChanged();
	OLE_COLOR m_foregroundColor;
	afx_msg void OnForegroundColorChanged();
	OLE_COLOR m_selectionBackgroundColor;
	afx_msg void OnSelectionBackgroundColorChanged();
	OLE_COLOR m_selectionForegroundColor;
	afx_msg void OnSelectionForegroundColorChanged();
	OLE_COLOR m_lightColor;
	afx_msg void OnLightColorChanged();
	OLE_COLOR m_shadowColor;
	afx_msg void OnShadowColorChanged();
	afx_msg DATE GetDate();
	afx_msg void SetDate(DATE newValue);
	afx_msg void SetSelectedDay(short iDay);
	afx_msg void ClearAllSelections();
	afx_msg BOOL IsDaySelected(short iDay);
	afx_msg BOOL MarkDay(short iDayNum, BOOL bMarked);
	afx_msg void UnMarkAllDays();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

public:
// Event maps
	//{{AFX_EVENT(CBCGCalendarCtrl)
	void FireOnSelectionChanged()
		{FireEvent(eventidOnSelectionChanged,EVENT_PARAM(VTS_NONE));}
	void FireOnDateChanged()
		{FireEvent(eventidOnDateChanged,EVENT_PARAM(VTS_NONE));}
	void FireOnMonthChanged()
		{FireEvent(eventidOnMonthChanged,EVENT_PARAM(VTS_NONE));}
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CBCGCalendarCtrl)
	dispidMultiplySelection = 1L,
	dispidAbsoluteSelectionMode = 2L,
	dispidBackgroundColor = 3L,
	dispidForegroundColor = 4L,
	dispidSelectionBackgroundColor = 5L,
	dispidSelectionForegroundColor = 6L,
	dispidDate = 9L,
	dispidLightColor = 7L,
	dispidShadowColor = 8L,
	dispidSetSelectedDay = 10L,
	dispidClearAllSelections = 11L,
	dispidIsDaySelected = 12L,
	dispidMarkDay = 13L,
	dispidUnMarkAllDays = 14L,
	eventidOnSelectionChanged = 1L,
	eventidOnDateChanged = 2L,
	eventidOnMonthChanged = 3L,
	//}}AFX_DISP_ID
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BCGCALENDARCTL_H__01B9AC70_A128_11D1_A637_00A0C93A70EC__INCLUDED)
