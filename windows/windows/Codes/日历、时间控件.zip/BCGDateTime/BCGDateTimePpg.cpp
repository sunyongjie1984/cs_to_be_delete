// BCGDateTimePpg.cpp : Implementation of the CBCGDateTimePropPage property page class.

#include "stdafx.h"
#include "BCGDateTime.h"
#include "BCGDateTimePpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CBCGDateTimePropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CBCGDateTimePropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CBCGDateTimePropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CBCGDateTimePropPage, "BCGDATETIME.BCGDateTimePropPage.1",
	0x1b9ac5a, 0xa128, 0x11d1, 0xa6, 0x37, 0, 0xa0, 0xc9, 0x3a, 0x70, 0xec)


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimePropPage::CBCGDateTimePropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CBCGDateTimePropPage

BOOL CBCGDateTimePropPage::CBCGDateTimePropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_BCGDATETIME_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimePropPage::CBCGDateTimePropPage - Constructor

CBCGDateTimePropPage::CBCGDateTimePropPage() :
	COlePropertyPage(IDD, IDS_BCGDATETIME_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CBCGDateTimePropPage)
	m_bCheckButton = FALSE;
	m_bDropCalendar = FALSE;
	m_bShowDate = FALSE;
	m_bShowTime = FALSE;
	m_bSpinButton = FALSE;
	m_bWantReturn = FALSE;
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimePropPage::DoDataExchange - Moves data between page and properties

void CBCGDateTimePropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CBCGDateTimePropPage)
	DDP_Check(pDX, IDC_CHECK, m_bCheckButton, _T("CheckButton") );
	DDX_Check(pDX, IDC_CHECK, m_bCheckButton);
	DDP_Check(pDX, IDC_DROP_CALENDAR, m_bDropCalendar, _T("DropCalendar") );
	DDX_Check(pDX, IDC_DROP_CALENDAR, m_bDropCalendar);
	DDP_Check(pDX, IDC_SHOW_DATE, m_bShowDate, _T("ShowDate") );
	DDX_Check(pDX, IDC_SHOW_DATE, m_bShowDate);
	DDP_Check(pDX, IDC_SHOW_TIME, m_bShowTime, _T("ShowTime") );
	DDX_Check(pDX, IDC_SHOW_TIME, m_bShowTime);
	DDP_Check(pDX, IDC_SPIN, m_bSpinButton, _T("SpinButton") );
	DDX_Check(pDX, IDC_SPIN, m_bSpinButton);
	DDP_Check(pDX, IDC_WAQNT_RETURN, m_bWantReturn, _T("WantReturn") );
	DDX_Check(pDX, IDC_WAQNT_RETURN, m_bWantReturn);
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimePropPage message handlers
