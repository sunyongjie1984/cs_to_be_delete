#if !defined(AFX_BCGDATETIMECTL_H__01B9AC6B_A128_11D1_A637_00A0C93A70EC__INCLUDED_)
#define AFX_BCGDATETIMECTL_H__01B9AC6B_A128_11D1_A637_00A0C93A70EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// BCGDateTimeCtl.h : Declaration of the CBCGDateTimeCtrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CBCGDateTimeCtrl : See BCGDateTimeCtl.cpp for implementation.

#define MAX_PARTS	7

class CCalendarWnd;

class CBCGDateTimeCtrl : public COleControl
{
	friend class CCalendarWnd;

	DECLARE_DYNCREATE(CBCGDateTimeCtrl)

// Constructor
public:
	CBCGDateTimeCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBCGDateTimeCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	virtual BOOL OnDoVerb(LONG iVerb, LPMSG lpMsg, HWND hWndParent, LPCRECT lpRect);
	virtual void OnFontChanged();
	virtual HMENU OnGetInPlaceMenu();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CBCGDateTimeCtrl();

	BEGIN_OLEFACTORY(CBCGDateTimeCtrl)        // Class factory and guid
		virtual BOOL VerifyUserLicense();
		virtual BOOL GetLicenseKey(DWORD, BSTR FAR*);
	END_OLEFACTORY(CBCGDateTimeCtrl)

	DECLARE_OLETYPELIB(CBCGDateTimeCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CBCGDateTimeCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CBCGDateTimeCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CBCGDateTimeCtrl)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg UINT OnGetDlgCode();
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CBCGDateTimeCtrl)
	BOOL m_wantReturn;
	afx_msg void OnWantReturnChanged();
	BOOL m_checkButton;
	afx_msg void OnCheckButtonChanged();
	BOOL m_dropCalendar;
	afx_msg void OnDropCalendarChanged();
	BOOL m_showDate;
	afx_msg void OnShowDateChanged();
	BOOL m_showTime;
	afx_msg void OnShowTimeChanged();
	BOOL m_spinButton;
	afx_msg void OnSpinButtonChanged();
	afx_msg DATE GetDate();
	afx_msg void SetDate(DATE newValue);
	afx_msg DATE GetMinDate();
	afx_msg void SetMinDate(DATE newValue);
	afx_msg DATE GetMaxDate();
	afx_msg void SetMaxDate(DATE newValue);
	afx_msg void SizeToContent();
	BOOL m_enabled;
	afx_msg void OnEnabledChanged();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CBCGDateTimeCtrl)
	void FireOnDateChanged()
		{FireEvent(eventidOnDateChanged,EVENT_PARAM(VTS_NONE));}
	void FireOnKillFocus(long hWnd)
		{FireEvent(eventidOnKillFocus,EVENT_PARAM(VTS_I4), hWnd);}
	void FireSetFocus()
		{FireEvent(eventidSetFocus,EVENT_PARAM(VTS_NONE));}
	void FireOnEnter()
		{FireEvent(eventidOnEnter,EVENT_PARAM(VTS_NONE));}
	void FireOnCancel()
		{FireEvent(eventidOnCancel,EVENT_PARAM(VTS_NONE));}
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CBCGDateTimeCtrl)
	dispidWantReturn = 1L,
	dispidDate = 7L,
	dispidMinDate = 8L,
	dispidMaxDate = 9L,
	dispidCheckButton = 2L,
	dispidDropCalendar = 3L,
	dispidShowDate = 4L,
	dispidShowTime = 5L,
	dispidSpinButton = 6L,
	dispidSizeToContent = 10L,
	eventidOnDateChanged = 1L,
	eventidOnKillFocus = 2L,
	eventidSetFocus = 3L,
	eventidOnEnter = 4L,
	eventidOnCancel = 5L,
	//}}AFX_DISP_ID
	};

// Attributes

protected:
	enum PART_TYPE
	{
		NO,
		CHECK_BOX,
		DAY,
		MONTH,
		YEAR,
		HOUR,
		MIN,
		AMPM
	};

	CButton					m_wndCheckBox;
	CRect					m_rectCheck;
	CRect					m_rectDropButton;
	CRect					m_rectText;
	COleDateTime			m_Date;
	COleDateTime			m_MinDate;
	COleDateTime			m_MaxDate;
	PART_TYPE				m_CurrPartType;
	int						m_iPartNum;
	BOOL					m_bCheckBoxIsAvailable;
	BOOL					m_bIsChecked;
	CImageList				m_Images;
	PART_TYPE				m_arPartsOrder [MAX_PARTS];
	int						m_iPartsNumber;
	BOOL					m_b24HoursFormat;
	BOOL					m_bShowSelection;
	CString					m_strDateSeparator;
	CString					m_strTimeSeparator;
	int						m_iPrevDigit;
	CSpinButtonCtrl			m_wndSpin;
	BOOL					m_bIsDateComboDropped;
	CCalendarWnd*			m_pWndDrop;
	BOOL					m_bDropButtonIsPressed;
	BOOL					m_bMouseOnDropButton;
	int						m_iControlWidth;
	int						m_iControlHeight;
	CString					m_strAM;
	CString					m_strPM;
	COleDateTime			m_WidestDate;

// Operations
protected:
	void AdjustControl ();
	void DrawCheckBox (CDC* pDC);
	void DrawDateDropButton (CDC* pDC);
	void SelectNext ();
	void SelectPrev ();
	void SetPartsOrder ();
	LPCTSTR GetPartFormat (int iPart) const;
	int GetPartFromPoint (POINT point);
	BOOL GetPartRect (int iPart, CRect& rect, BOOL bWidest = FALSE);
	void ScrollCurrPart (int iDir);
	void ScrollCurrPartToLimit (BOOL bTop);
	void PushDigit (int iDigit);
	void ChangeMonth (USHORT uiMonth);
	void ChangeAmPm (USHORT uiAmPm);
	void ToggleCheck ();

	BOOL IsDateValid (COleDateTime& date) const;

	BOOL IsDatePart (int iPart) const;
	BOOL IsTimePart (int iPart) const;

	BOOL ShowDropCalendar ();
	BOOL HideDropCalendar (const COleDateTime* pDateNew = NULL);
	
	void BuidWidestDate ();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BCGDATETIMECTL_H__01B9AC6B_A128_11D1_A637_00A0C93A70EC__INCLUDED)
