//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BCGDateTime.rc
//
#define IDS_BCGDATETIME                 1
#define IDD_ABOUTBOX_BCGDATETIME        1
#define IDB_BCGDATETIME                 1
#define IDI_ABOUTDLL                    1
#define IDS_BCGDATETIME_PPG             2
#define IDD_ABOUTBOX_BCGCALENDAR        2
#define IDB_BCGCALENDAR                 2
#define IDS_BCGCALENDAR                 3
#define IDS_BCGCALENDAR_PPG             4
#define IDS_IETDATETIME                 5
#define IDS_IETDATETIME_PPG             6
#define IDS_TODAY                       7
#define IDS_BCGDATETIME_PPG_CAPTION     200
#define IDD_PROPPAGE_BCGDATETIME        200
#define IDS_BCGCALENDAR_PPG_CAPTION     201
#define IDD_PROPPAGE_BCGCALENDAR        201
#define IDB_DATE_IMAGES                 201
#define IDC_MULT_SELECTION              201
#define IDS_IETDATETIME_PPG_CAPTION     202
#define IDB_CALENDAR_BUTTONS            202
#define IDC_CURSOR                      202
#define IDC_ABSOLUTE_SELECTION_MODE     202
#define IDS_PREV_YEAR                   203
#define IDB_SEL_BACK                    203
#define IDS_PREV_MONTH                  204
#define IDC_DROP_CALENDAR               204
#define IDS_NEXT_YEAR                   205
#define IDC_SPIN                        205
#define IDS_NEXT_MONTH                  206
#define IDC_CHECK                       206
#define IDC_SHOW_DATE                   207
#define IDC_SHOW_TIME                   208
#define IDC_WAQNT_RETURN                209
#define IDC_VERSION                     1021
#define IDC_WEB                         1096

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
