// BCGCalendarCtl.cpp : Implementation of the CBCGCalendarCtrl ActiveX Control class.

#include "stdafx.h"
#include "BCGDateTime.h"
#include "BCGCalendarCtl.h"
#include "BCGCalendarPpg.h"
#include "DateTimeAboutDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CBCGCalendarCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CBCGCalendarCtrl, COleControl)
	//{{AFX_MSG_MAP(CBCGCalendarCtrl)
	ON_WM_SIZE()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CBCGCalendarCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CBCGCalendarCtrl)
	DISP_PROPERTY_NOTIFY(CBCGCalendarCtrl, "MultiplySelection", m_multiplySelection, OnMultiplySelectionChanged, VT_BOOL)
	DISP_PROPERTY_NOTIFY(CBCGCalendarCtrl, "AbsoluteSelectionMode", m_absoluteSelectionMode, OnAbsoluteSelectionModeChanged, VT_BOOL)
	DISP_PROPERTY_NOTIFY(CBCGCalendarCtrl, "BackgroundColor", m_backgroundColor, OnBackgroundColorChanged, VT_COLOR)
	DISP_PROPERTY_NOTIFY(CBCGCalendarCtrl, "ForegroundColor", m_foregroundColor, OnForegroundColorChanged, VT_COLOR)
	DISP_PROPERTY_NOTIFY(CBCGCalendarCtrl, "SelectionBackgroundColor", m_selectionBackgroundColor, OnSelectionBackgroundColorChanged, VT_COLOR)
	DISP_PROPERTY_NOTIFY(CBCGCalendarCtrl, "SelectionForegroundColor", m_selectionForegroundColor, OnSelectionForegroundColorChanged, VT_COLOR)
	DISP_PROPERTY_NOTIFY(CBCGCalendarCtrl, "LightColor", m_lightColor, OnLightColorChanged, VT_COLOR)
	DISP_PROPERTY_NOTIFY(CBCGCalendarCtrl, "ShadowColor", m_shadowColor, OnShadowColorChanged, VT_COLOR)
	DISP_PROPERTY_EX(CBCGCalendarCtrl, "Date", GetDate, SetDate, VT_DATE)
	DISP_FUNCTION(CBCGCalendarCtrl, "SetSelectedDay", SetSelectedDay, VT_EMPTY, VTS_I2)
	DISP_FUNCTION(CBCGCalendarCtrl, "ClearAllSelections", ClearAllSelections, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CBCGCalendarCtrl, "IsDaySelected", IsDaySelected, VT_BOOL, VTS_I2)
	DISP_FUNCTION(CBCGCalendarCtrl, "MarkDay", MarkDay, VT_BOOL, VTS_I2 VTS_BOOL)
	DISP_FUNCTION(CBCGCalendarCtrl, "UnMarkAllDays", UnMarkAllDays, VT_EMPTY, VTS_NONE)
	DISP_DEFVALUE(CBCGCalendarCtrl, "Date")
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CBCGCalendarCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CBCGCalendarCtrl, COleControl)
	//{{AFX_EVENT_MAP(CBCGCalendarCtrl)
	EVENT_CUSTOM("OnSelectionChanged", FireOnSelectionChanged, VTS_NONE)
	EVENT_CUSTOM("OnDateChanged", FireOnDateChanged, VTS_NONE)
	EVENT_CUSTOM("OnMonthChanged", FireOnMonthChanged, VTS_NONE)
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CBCGCalendarCtrl, 2)
	PROPPAGEID(CBCGCalendarPropPage::guid)
	PROPPAGEID(CLSID_CColorPropPage)
END_PROPPAGEIDS(CBCGCalendarCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CBCGCalendarCtrl, "BCGDATETIME.BCGCalendarCtrl.1",
	0x1b9ac5d, 0xa128, 0x11d1, 0xa6, 0x37, 0, 0xa0, 0xc9, 0x3a, 0x70, 0xec)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CBCGCalendarCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DBCGCalendar =
		{ 0x1b9ac5b, 0xa128, 0x11d1, { 0xa6, 0x37, 0, 0xa0, 0xc9, 0x3a, 0x70, 0xec } };
const IID BASED_CODE IID_DBCGCalendarEvents =
		{ 0x1b9ac5c, 0xa128, 0x11d1, { 0xa6, 0x37, 0, 0xa0, 0xc9, 0x3a, 0x70, 0xec } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwBCGCalendarOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CBCGCalendarCtrl, IDS_BCGCALENDAR, _dwBCGCalendarOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarCtrl::CBCGCalendarCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CBCGCalendarCtrl

BOOL CBCGCalendarCtrl::CBCGCalendarCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_BCGCALENDAR,
			IDB_BCGCALENDAR,
			afxRegApartmentThreading,
			_dwBCGCalendarOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// Licensing strings

static const TCHAR BASED_CODE _szLicFileName[] = _T("BCGDateTime.lic");

static const WCHAR BASED_CODE _szLicString[] =
	L"Copyright (c) 1998 IET";


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarCtrl::CBCGCalendarCtrlFactory::VerifyUserLicense -
// Checks for existence of a user license

BOOL CBCGCalendarCtrl::CBCGCalendarCtrlFactory::VerifyUserLicense()
{
	return AfxVerifyLicFile(AfxGetInstanceHandle(), _szLicFileName,
		_szLicString);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarCtrl::CBCGCalendarCtrlFactory::GetLicenseKey -
// Returns a runtime licensing key

BOOL CBCGCalendarCtrl::CBCGCalendarCtrlFactory::GetLicenseKey(DWORD dwReserved,
	BSTR FAR* pbstrKey)
{
	if (pbstrKey == NULL)
		return FALSE;

	*pbstrKey = SysAllocString(_szLicString);
	return (*pbstrKey != NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarCtrl::CBCGCalendarCtrl - Constructor

CBCGCalendarCtrl::CBCGCalendarCtrl()
{
	InitializeIIDs(&IID_DBCGCalendar, &IID_DBCGCalendarEvents);

	m_multiplySelection = FALSE;
	m_absoluteSelectionMode = FALSE;
	m_backgroundColor = ::GetSysColor (COLOR_WINDOW);
	m_foregroundColor = ::GetSysColor (COLOR_WINDOWTEXT);
	m_selectionBackgroundColor = ::GetSysColor (COLOR_3DFACE);
	m_selectionForegroundColor = ::GetSysColor (COLOR_BTNTEXT);
	m_shadowColor = ::GetSysColor (COLOR_3DDKSHADOW);
	m_lightColor = ::GetSysColor (COLOR_3DLIGHT);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarCtrl::~CBCGCalendarCtrl - Destructor

CBCGCalendarCtrl::~CBCGCalendarCtrl()
{
	// TODO: Cleanup your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarCtrl::OnDraw - Drawing function

void CBCGCalendarCtrl::OnDraw(
			CDC* pDC, const CRect& rcBounds, const CRect& rcInvalid)
{
	if (GetSafeHwnd () == NULL)	// Control doesn't created yet (e.g., AppStudio)
	{
		CRect rectClient = rcBounds;

		pDC->FillSolidRect (&rectClient, ::GetSysColor (COLOR_WINDOW));

		// Draw 3-d border around the control:
		pDC->Draw3dRect (	&rectClient, 
						::GetSysColor (COLOR_3DDKSHADOW),
						::GetSysColor (COLOR_3DHILIGHT));
		
		rectClient.InflateRect (-1, -1);
		pDC->Draw3dRect (	&rectClient,
						::GetSysColor (COLOR_3DSHADOW),
						::GetSysColor (COLOR_3DLIGHT));

		pDC->SetTextColor (::GetSysColor (COLOR_WINDOWTEXT));

		CString strTitle = _T("CALENDAR");

		pDC->SetBkMode (TRANSPARENT);
		pDC->SelectStockObject (DEFAULT_GUI_FONT);

		CRect rectTitle = rectClient;
		rectTitle.InflateRect (-3, -3);

		pDC->DrawText (strTitle, rectTitle, DT_SINGLELINE);
	}
}


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarCtrl::DoPropExchange - Persistence support

void CBCGCalendarCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	PX_Bool (pPX, _T("MultiplySelection"), m_multiplySelection);
	PX_Bool (pPX, _T("AbsoluteSelectionMode"), m_absoluteSelectionMode);
	PX_Color (pPX, _T("BackgroundColor"), m_backgroundColor);
	PX_Color (pPX, _T("ForegroundColor"), m_foregroundColor);
	PX_Color (pPX, _T("SelectionBackgroundColor"), m_selectionBackgroundColor);
	PX_Color (pPX, _T("SelectionForegroundColor"), m_selectionForegroundColor);
	PX_Color (pPX, _T("LightColor"), m_lightColor);
	PX_Color (pPX, _T("ShadowColor"), m_shadowColor);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarCtrl::OnResetState - Reset control to default state

void CBCGCalendarCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange
}


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarCtrl::AboutBox - Display an "About" box to the user

void CBCGCalendarCtrl::AboutBox()
{
	CDateTimeAboutDlg dlgAbout;
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CBCGCalendarCtrl message handlers

void CBCGCalendarCtrl::OnSize(UINT nType, int cx, int cy) 
{
	COleControl::OnSize(nType, cx, cy);
	
	m_wndCalendar.SetWindowPos (NULL, 0, 0, cx, cy,
								SWP_NOMOVE | SWP_NOZORDER);
}

int CBCGCalendarCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (COleControl::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_wndCalendar.Create (WS_CHILD | WS_VISIBLE, 0, 0, this);
	
	m_wndCalendar.EnableMultipleSelection (m_multiplySelection);
	m_wndCalendar.EnableAbsoluteSelection (m_absoluteSelectionMode);
	m_wndCalendar.m_clrBackColor = TranslateColor (m_backgroundColor);
	m_wndCalendar.m_clrTextColor = TranslateColor (m_foregroundColor);
	m_wndCalendar.m_clrSelTextColor = TranslateColor (m_selectionForegroundColor);
	m_wndCalendar.m_clrSelBackColor = TranslateColor (m_selectionBackgroundColor);
	m_wndCalendar.m_clrLightColor = TranslateColor (m_lightColor);
	m_wndCalendar.m_clrShadowColor = TranslateColor (m_shadowColor);

	m_wndCalendar.UpdateColors ();

	return 0;
}

void CBCGCalendarCtrl::OnMultiplySelectionChanged() 
{
	m_wndCalendar.EnableMultipleSelection (m_multiplySelection);
	SetModifiedFlag();
}

void CBCGCalendarCtrl::OnAbsoluteSelectionModeChanged() 
{
	m_wndCalendar.EnableAbsoluteSelection (m_absoluteSelectionMode);
	SetModifiedFlag();
}

void CBCGCalendarCtrl::OnBackgroundColorChanged() 
{
	m_wndCalendar.m_clrBackColor = TranslateColor (m_backgroundColor);
	m_wndCalendar.UpdateColors ();

	SetModifiedFlag();
}

void CBCGCalendarCtrl::OnForegroundColorChanged() 
{
	m_wndCalendar.m_clrTextColor = TranslateColor (m_foregroundColor);
	m_wndCalendar.UpdateColors ();

	SetModifiedFlag();
}

void CBCGCalendarCtrl::OnSelectionBackgroundColorChanged() 
{
	m_wndCalendar.m_clrSelBackColor = TranslateColor (m_selectionBackgroundColor);
	m_wndCalendar.UpdateColors ();

	SetModifiedFlag();
}

void CBCGCalendarCtrl::OnSelectionForegroundColorChanged() 
{
	m_wndCalendar.m_clrSelTextColor = TranslateColor (m_selectionForegroundColor);
	m_wndCalendar.UpdateColors ();

	SetModifiedFlag();
}

void CBCGCalendarCtrl::SetSelectedDay(short iDay) 
{
	m_wndCalendar.AddSelectedDay (iDay);
	m_wndCalendar.Invalidate ();
	m_wndCalendar.UpdateWindow ();
}

void CBCGCalendarCtrl::ClearAllSelections() 
{
	m_wndCalendar.ClearSelectedDays ();
	m_wndCalendar.Invalidate ();
	m_wndCalendar.UpdateWindow ();
}

BOOL CBCGCalendarCtrl::IsDaySelected(short iDay) 
{
	return m_wndCalendar.IsDaySelected (iDay);
}

DATE CBCGCalendarCtrl::GetDate() 
{
	return (DATE) m_wndCalendar.GetDate ();
}

void CBCGCalendarCtrl::SetDate(DATE newValue) 
{
	m_wndCalendar.SetDate (newValue);
	SetModifiedFlag();
}

void CBCGCalendarCtrl::OnLightColorChanged() 
{
	m_wndCalendar.m_clrLightColor = TranslateColor (m_lightColor);
	m_wndCalendar.UpdateColors ();

	SetModifiedFlag();
}

void CBCGCalendarCtrl::OnShadowColorChanged() 
{
	m_wndCalendar.m_clrShadowColor = TranslateColor (m_shadowColor);
	m_wndCalendar.UpdateColors ();

	SetModifiedFlag();
}

BOOL CBCGCalendarCtrl::MarkDay(short iDayNum, BOOL bMarked) 
{
	return m_wndCalendar.MarkDay (iDayNum, bMarked);
}

void CBCGCalendarCtrl::UnMarkAllDays() 
{
	m_wndCalendar.UnMarkAllDays ();
}
