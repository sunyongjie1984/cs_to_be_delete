#if !defined(AFX_DATETIMEABOUTDLG_H__2B6545E4_ADCB_11D1_A63A_00A0C93A70EC__INCLUDED_)
#define AFX_DATETIMEABOUTDLG_H__2B6545E4_ADCB_11D1_A63A_00A0C93A70EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DateTimeAboutDlg.h : header file
//

#include "URLLinkWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CDateTimeAboutDlg dialog

class CDateTimeAboutDlg : public CDialog
{
// Construction
public:
	CDateTimeAboutDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDateTimeAboutDlg)
	enum { IDD = IDD_ABOUTBOX_BCGDATETIME };
	CURLLinkWnd	m_btnWeb;
	//}}AFX_DATA

	BOOL GetVersion (CString& strOut) const;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDateTimeAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDateTimeAboutDlg)
	afx_msg void OnWeb();
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	HCURSOR	m_hcurHand;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATETIMEABOUTDLG_H__2B6545E4_ADCB_11D1_A63A_00A0C93A70EC__INCLUDED_)
