#if !defined(AFX_CALENDARTOOLBARWND_H__3A304324_A446_11D1_A637_00A0C93A70EC__INCLUDED_)
#define AFX_CALENDARTOOLBARWND_H__3A304324_A446_11D1_A637_00A0C93A70EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CalendarToolBarWnd.h : header file
//

class CCalendarWnd;

/////////////////////////////////////////////////////////////////////////////
// CCalendarToolBarWnd window

#define BUTTONS_NUM	5

class CCalendarToolBarWnd : public CWnd
{
// Construction
public:
	CCalendarToolBarWnd();

// Attributes
public:
	COLORREF		m_clrBackColor;
	COLORREF		m_clrLightColor;
	COLORREF		m_clrShadowColor;
	COLORREF		m_clrTextColor;
	CString			m_strTodayLabel;

	enum BUTTON_ID
	{
		PREV_YEAR,
		PREV_MONTH,
		TODAY,
		NEXT_MONTH,
		NEXT_YEAR,
	};

protected:
	static CString	m_strClassName;

	CImageList		m_Images;
	CSize			m_ImageSize;

	CCalendarWnd*	m_pParentCalendar;

	CRect			m_rectButtons [BUTTONS_NUM];
	int				m_iTrackedButton;
	int				m_iPressedButton;

	int				m_iButtonHeight;
	int				m_iWindowHeight;

	CToolTipCtrl	m_ToolTip;

	BOOL			m_bSlowTimerMode;
	int				m_iSlowTimerCount;

// Operations
public:
	void AlignInParentClientArea (BOOL bBottom = TRUE);
	int GetHeight () const
	{
		return m_iWindowHeight;
	}

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCalendarToolBarWnd)
	public:
	virtual BOOL Create (const RECT& rect, CWnd* pParentWnd, UINT nID);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCalendarToolBarWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CCalendarToolBarWnd)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	int HitTest (POINT pt) const;
	void OnClickButton (int iButton);
	void RelayEvent(UINT message, WPARAM wParam, LPARAM lParam);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALENDARTOOLBARWND_H__3A304324_A446_11D1_A637_00A0C93A70EC__INCLUDED_)
