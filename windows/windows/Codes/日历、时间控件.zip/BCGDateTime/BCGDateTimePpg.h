#if !defined(AFX_BCGDATETIMEPPG_H__01B9AC6D_A128_11D1_A637_00A0C93A70EC__INCLUDED_)
#define AFX_BCGDATETIMEPPG_H__01B9AC6D_A128_11D1_A637_00A0C93A70EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// BCGDateTimePpg.h : Declaration of the CBCGDateTimePropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CBCGDateTimePropPage : See BCGDateTimePpg.cpp.cpp for implementation.

class CBCGDateTimePropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CBCGDateTimePropPage)
	DECLARE_OLECREATE_EX(CBCGDateTimePropPage)

// Constructor
public:
	CBCGDateTimePropPage();

// Dialog Data
	//{{AFX_DATA(CBCGDateTimePropPage)
	enum { IDD = IDD_PROPPAGE_BCGDATETIME };
	BOOL	m_bCheckButton;
	BOOL	m_bDropCalendar;
	BOOL	m_bShowDate;
	BOOL	m_bShowTime;
	BOOL	m_bSpinButton;
	BOOL	m_bWantReturn;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CBCGDateTimePropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BCGDATETIMEPPG_H__01B9AC6D_A128_11D1_A637_00A0C93A70EC__INCLUDED)
