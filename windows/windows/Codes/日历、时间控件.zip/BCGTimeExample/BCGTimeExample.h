// BCGTimeExample.h : main header file for the BCGTIMEEXAMPLE application
//

#if !defined(AFX_BCGTIMEEXAMPLE_H__16DEE5C8_DB86_11D2_A70A_0090273722D3__INCLUDED_)
#define AFX_BCGTIMEEXAMPLE_H__16DEE5C8_DB86_11D2_A70A_0090273722D3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CBCGTimeExampleApp:
// See BCGTimeExample.cpp for the implementation of this class
//

class CBCGTimeExampleApp : public CWinApp
{
public:
	CBCGTimeExampleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBCGTimeExampleApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CBCGTimeExampleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BCGTIMEEXAMPLE_H__16DEE5C8_DB86_11D2_A70A_0090273722D3__INCLUDED_)
