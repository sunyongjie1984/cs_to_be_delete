#if !defined(AFX_BCGTIMEINTERVALSPPG_H__39A85999_AE7E_11D1_A63A_00A0C93A70EC__INCLUDED_)
#define AFX_BCGTIMEINTERVALSPPG_H__39A85999_AE7E_11D1_A63A_00A0C93A70EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// BCGTimeIntervalsPpg.h : Declaration of the CBCGTimeIntervalsPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsPropPage : See BCGTimeIntervalsPpg.cpp.cpp for implementation.

class CBCGTimeIntervalsPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CBCGTimeIntervalsPropPage)
	DECLARE_OLECREATE_EX(CBCGTimeIntervalsPropPage)

// Constructor
public:
	CBCGTimeIntervalsPropPage();

// Dialog Data
	//{{AFX_DATA(CBCGTimeIntervalsPropPage)
	enum { IDD = IDD_PROPPAGE_BCGTIMEINTERVALS };
	BOOL	m_MergingIsAllowed;
	BOOL	m_MultiplySelection;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CBCGTimeIntervalsPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BCGTIMEINTERVALSPPG_H__39A85999_AE7E_11D1_A63A_00A0C93A70EC__INCLUDED)
