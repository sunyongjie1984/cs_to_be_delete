#if !defined(AFX_BCGTIMEINTERVALSCTL_H__39A85997_AE7E_11D1_A63A_00A0C93A70EC__INCLUDED_)
#define AFX_BCGTIMEINTERVALSCTL_H__39A85997_AE7E_11D1_A63A_00A0C93A70EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXTEMPL_H__
	#include "afxtempl.h"
#endif

#include "bubble.h"

// BCGTimeIntervalsCtl.h : Declaration of the CBCGTimeIntervalsCtrl ActiveX Control class.

class CTimeInterval : public CObject
{
public:
	CTimeInterval () 
	{
		m_iStatus = -1;
	}

	CTimeInterval (const CTimeInterval& src)
	{
		m_From = src.m_From;
		m_To = src.m_To;
		m_iStatus = src.m_iStatus;
	}

	COleDateTime	m_From;
	COleDateTime	m_To;
	int				m_iStatus;

	const BOOL operator == (const CTimeInterval& other)
	{
		return other.m_From == m_From && other.m_To == m_To &&
				other.m_iStatus == m_iStatus;
	}

	const BOOL operator != (const CTimeInterval& other)
	{
		return !(*this == other);
	}

	const CTimeInterval& operator=(const CTimeInterval& src)
	{
		m_From = src.m_From;
		m_To = src.m_To;
		m_iStatus = src.m_iStatus;

		return *this;
	}
};

/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsCtrl : See BCGTimeIntervalsCtl.cpp for implementation.

class CBCGTimeIntervalsCtrl : public COleControl
{
	DECLARE_DYNCREATE(CBCGTimeIntervalsCtrl)

// Constructor
public:
	CBCGTimeIntervalsCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBCGTimeIntervalsCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CBCGTimeIntervalsCtrl();

	BEGIN_OLEFACTORY(CBCGTimeIntervalsCtrl)        // Class factory and guid
		virtual BOOL VerifyUserLicense();
		virtual BOOL GetLicenseKey(DWORD, BSTR FAR*);
	END_OLEFACTORY(CBCGTimeIntervalsCtrl)

	DECLARE_OLETYPELIB(CBCGTimeIntervalsCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CBCGTimeIntervalsCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CBCGTimeIntervalsCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CBCGTimeIntervalsCtrl)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg UINT OnGetDlgCode();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CBCGTimeIntervalsCtrl)
	BOOL m_mergingIsAllowed;
	afx_msg void OnMergingIsAllowedChanged();
	BOOL m_multiplySelection;
	afx_msg void OnMultiplySelectionChanged();
	OLE_COLOR m_intervalColor;
	afx_msg void OnIntervalColorChanged();
	OLE_COLOR m_intervalTextColor;
	afx_msg void OnIntervalTextColorChanged();
	OLE_COLOR m_backgroundColor;
	afx_msg void OnBackgroundColorChanged();
	OLE_COLOR m_foregroundColor;
	afx_msg void OnForegroundColorChanged();
	afx_msg short GetIntervalsCount();
	afx_msg BOOL RemoveInterval(short index);
	afx_msg void RemoveAllIntervals();
	afx_msg short GetCurSel();
	afx_msg BOOL SetCurSel(short index);
	afx_msg BOOL AddInterval(DATE dateFrom, DATE dateTo, short iStatus);
	afx_msg BOOL ChangeInterval(short iIndex, DATE dateFrom, DATE dateTo, short iStatus);
	afx_msg BOOL GetInterval(short iIndex, DATE FAR* dateFrom, DATE FAR* dateTo, short FAR* iStatus);
	afx_msg BOOL SetIntervalStatus(short iIndex, short iStatus);
	afx_msg void SetStatusColor(short iStatus, OLE_COLOR color);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CBCGTimeIntervalsCtrl)
	void FireOnAddInterval(short index, DATE FromTime, DATE ToTime)
		{FireEvent(eventidOnAddInterval,EVENT_PARAM(VTS_I2  VTS_DATE  VTS_DATE), index, FromTime, ToTime);}
	void FireOnRemoveInterval(DATE FromTime, DATE ToTime)
		{FireEvent(eventidOnRemoveInterval,EVENT_PARAM(VTS_DATE  VTS_DATE), FromTime, ToTime);}
	void FireOnChangeInterval(short index, DATE FromTime, DATE ToTime)
		{FireEvent(eventidOnChangeInterval,EVENT_PARAM(VTS_I2  VTS_DATE  VTS_DATE), index, FromTime, ToTime);}
	void FireOnSelectionChanged(short index)
		{FireEvent(eventidOnSelectionChanged,EVENT_PARAM(VTS_I2), index);}
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CBCGTimeIntervalsCtrl)
	dispidMergingIsAllowed = 1L,
	dispidMultiplySelection = 2L,
	dispidIntervalColor = 3L,
	dispidIntervalTextColor = 4L,
	dispidBackgroundColor = 5L,
	dispidForegroundColor = 6L,
	dispidGetIntervalsCount = 7L,
	dispidRemoveInterval = 8L,
	dispidRemoveAllIntervals = 9L,
	dispidGetCurSel = 10L,
	dispidSetCurSel = 11L,
	dispidAddInterval = 12L,
	dispidChangeInterval = 13L,
	dispidGetInterval = 14L,
	dispidSetIntervalStatus = 15L,
	dispidSetStatusColor = 16L,
	eventidOnAddInterval = 1L,
	eventidOnRemoveInterval = 2L,
	eventidOnChangeInterval = 3L,
	eventidOnSelectionChanged = 4L,
	//}}AFX_DISP_ID
	};

// Attributes:
	CObList			m_Intervals;
	int				m_nTimeLabelsWidth;
	int				m_nHourHeight;
	int				m_nHourAlignment;
	BOOL			m_bFocused;
	CBrush			m_brIntervalBrush;
	CFont			m_fntSmall;
	CFont			m_fntLabels;
	HCURSOR			m_hCursorUp;
	HCURSOR			m_hCursorDown;
	HCURSOR			m_hCursorDelete;
	HCURSOR			m_hCursorArrow;	// Standard Windows cursor
	CBubble			m_wndInfo;

	enum HIT_TEST
	{
		STRETCH_UP,
		STRETCH_DOWN,
		MOVE,
		REMOVE,
		NONE
	};

	enum OVERLAPPING_TYPE
	{
		NO_OVERLAPPING,
		FULL_OVERLAPPING,
		TOP_OVERLAPPING,
		BOTTOM_OVERLAPPING
	};

	enum MOVE_TYPE
	{
		MOVE_TO_TOP,
		MOVE_TO_BOTTOM,
		RELATIVE_MOVE
	};

	HIT_TEST		m_CurrDragMode;
	CTimeInterval*	m_pDraggedInterval;
	CTimeInterval	m_SavedDragInterval;
	COleDateTime	m_PrevDragTime;

	CTimeInterval*	m_pNewInterval;

	int				m_iYear;
	int				m_iMonth;
	int				m_iDay;

	CTimeInterval*	m_pFirstMergedInterval;
	CTimeInterval*	m_pSecondMergedInterval;

	CTimeInterval*	m_pTTInterval;
	CRect			m_rectTT;
	int				m_iMinFullLegenedHeight;

	CTimeInterval*	m_pSelectedInterval;
	int				m_iMouseDownY;
	CString			m_strTimeFormat;
	CString			m_strTimeTooltipFormat;
	CString			m_strHourFormat;

	BOOL			m_bNewItervalFirstTimeDrag;

	CMap<short,short, HBRUSH, HBRUSH>	m_IntervalBrushes;

// Operations
public:

protected:
	void CleanUp ();

	void AdjustSize (int cx, int cy);
	void InvalidateFrame ();

	BOOL PointToTime (const CPoint& point, COleDateTime& time, BOOL bExact = FALSE) const;
	int GetTimeY (const COleDateTime& time) const;

	void DrawTimeInterval (CDC* pDC, const CRect& rect,
							const COleDateTime& from, const COleDateTime& to,
							BOOL bSelected);

	CTimeInterval* HitTest (const CPoint& point,
			CBCGTimeIntervalsCtrl::HIT_TEST& hit) const;

	void GetIntervalRect (const CTimeInterval* pTI, CRect& rectTI) const;

	CTimeInterval* GetIntervalOverlapped (CTimeInterval* pTICheck, CBCGTimeIntervalsCtrl::OVERLAPPING_TYPE& type) const;
	void ChangeCursor (CBCGTimeIntervalsCtrl::HIT_TEST hit) const;

	int InsertTimeInterval (CTimeInterval* pTI);
	int ChangeTimeInterval (CTimeInterval* pTI);
	BOOL RemoveTimeInterval (CTimeInterval* pTI);

	void SetInfoWindow (const CPoint& point);
	void ChangeSelection (CTimeInterval* pTI);

	BOOL MoveSelectedInterval (	
			int iDeltaMinutes, 
			BOOL bShift,
			CBCGTimeIntervalsCtrl::MOVE_TYPE moveType = RELATIVE_MOVE);
	BOOL DeleteSelectedInterval ();

	void BuildTooltipText (const CTimeInterval* pInterval, BOOL bShowTime,
							CString& strText) const;
	void CancelCurrentMode ();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BCGTIMEINTERVALSCTL_H__39A85997_AE7E_11D1_A63A_00A0C93A70EC__INCLUDED)
