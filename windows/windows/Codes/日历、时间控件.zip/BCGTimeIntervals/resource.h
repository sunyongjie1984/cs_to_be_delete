//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BCGTimeIntervals.rc
//
#define IDS_BCGTIMEINTERVALS            1
#define IDD_ABOUTBOX_BCGTIMEINTERVALS   1
#define IDB_BCGTIMEINTERVALS            1
#define IDI_ABOUTDLL                    1
#define IDS_BCGTIMEINTERVALS_PPG        2
#define IDC_UP                          129
#define IDC_DOWN                        130
#define IDC_MOVE                        132
#define IDC_DELETE                      133
#define IDS_BCGTIMEINTERVALS_PPG_CAPTION 200
#define IDD_PROPPAGE_BCGTIMEINTERVALS   200
#define IDC_ALLOWMERGE                  201
#define IDC_CURSOR                      201
#define IDC_ALLOWMULTIPLY               202
#define IDC_VERSION                     1021
#define IDC_WEB                         1096

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
