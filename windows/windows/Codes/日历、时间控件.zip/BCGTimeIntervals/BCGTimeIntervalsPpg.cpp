// BCGTimeIntervalsPpg.cpp : Implementation of the CBCGTimeIntervalsPropPage property page class.

#include "stdafx.h"
#include "BCGTimeIntervals.h"
#include "BCGTimeIntervalsPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CBCGTimeIntervalsPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CBCGTimeIntervalsPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CBCGTimeIntervalsPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CBCGTimeIntervalsPropPage, "BCGTIMEINTERVALS.BCGTimeIntervalsPropPage.1",
	0x39a8598a, 0xae7e, 0x11d1, 0xa6, 0x3a, 0, 0xa0, 0xc9, 0x3a, 0x70, 0xec)


/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsPropPage::CBCGTimeIntervalsPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CBCGTimeIntervalsPropPage

BOOL CBCGTimeIntervalsPropPage::CBCGTimeIntervalsPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_BCGTIMEINTERVALS_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsPropPage::CBCGTimeIntervalsPropPage - Constructor

CBCGTimeIntervalsPropPage::CBCGTimeIntervalsPropPage() :
	COlePropertyPage(IDD, IDS_BCGTIMEINTERVALS_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CBCGTimeIntervalsPropPage)
	m_MergingIsAllowed = FALSE;
	m_MultiplySelection = FALSE;
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsPropPage::DoDataExchange - Moves data between page and properties

void CBCGTimeIntervalsPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CBCGTimeIntervalsPropPage)
	DDP_Check(pDX, IDC_ALLOWMERGE, m_MergingIsAllowed, _T("MergingIsAllowed") );
	DDX_Check(pDX, IDC_ALLOWMERGE, m_MergingIsAllowed);
	DDP_Check(pDX, IDC_ALLOWMULTIPLY, m_MultiplySelection, _T("MultiplySelection") );
	DDX_Check(pDX, IDC_ALLOWMULTIPLY, m_MultiplySelection);
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsPropPage message handlers
