// AboutDlg.cpp : implementation file
//

#include "stdafx.h"
#include "BCGTimeIntervals.h"
#include "VersionInfo.h"
#include "AboutDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog


CAboutDlg::CAboutDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAboutDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAboutDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_WEB, m_btnWeb);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_BN_CLICKED(IDC_WEB, OnWeb)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg message handlers

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CDialog::OnInitDialog();
	
	// Fill version information:
	CVersionInfo version;
	CString strVer;
	if (version.GetVersion (strVer))
	{
		SetDlgItemText (IDC_VERSION, strVer);
	}

	m_hcurHand = theApp.LoadCursor (IDC_CURSOR);
	m_btnWeb.m_hCursor = m_hcurHand;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAboutDlg::OnWeb() 
{
	CString str;
	m_btnWeb.GetWindowText (str);

	BeginWaitCursor ();

	if (ShellExecute (NULL, NULL, str, NULL, NULL, NULL) < (HINSTANCE) 32)
	{
		MessageBox (_T("Can't open URL."));
	}

	EndWaitCursor ();
}

void CAboutDlg::OnDestroy() 
{
	DeleteObject (m_hcurHand);
	CDialog::OnDestroy();
}
