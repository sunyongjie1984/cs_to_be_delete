// BCGTimeIntervalsCtl.cpp : Implementation of the CBCGTimeIntervalsCtrl ActiveX Control class.

#include "stdafx.h"
#include "BCGTimeIntervals.h"
#include "BCGTimeIntervalsCtl.h"
#include "BCGTimeIntervalsPpg.h"
#include "AboutDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CBCGTimeIntervalsCtrl, COleControl)


static const int iHoursInDay = 24;
static const int iMinutesInHour = 60;
static const int iVertOffset = 10;
static const int iHorzOffset = 10;

static const int iMinuteAlignment = 15;

static const UINT uiMergeEventId = 1;
static const int iMergeEventDelay = 500;

static const UINT uiToolTipEventId = 2;
static const int iToolTipEventDelay = 1000;

static const COLORREF colorIntervalBrush = RGB (255, 255, 128);
static const COleDateTimeSpan minute = COleDateTimeSpan (0, 0, 1, 0);

static const int iSmallestMoveDelta = 2;


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CBCGTimeIntervalsCtrl, COleControl)
	//{{AFX_MSG_MAP(CBCGTimeIntervalsCtrl)
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_ERASEBKGND()
	ON_WM_SETCURSOR()
	ON_WM_KEYDOWN()
	ON_WM_GETDLGCODE()
	ON_WM_TIMER()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CBCGTimeIntervalsCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CBCGTimeIntervalsCtrl)
	DISP_PROPERTY_NOTIFY(CBCGTimeIntervalsCtrl, "MergingIsAllowed", m_mergingIsAllowed, OnMergingIsAllowedChanged, VT_BOOL)
	DISP_PROPERTY_NOTIFY(CBCGTimeIntervalsCtrl, "MultiplySelection", m_multiplySelection, OnMultiplySelectionChanged, VT_BOOL)
	DISP_PROPERTY_NOTIFY(CBCGTimeIntervalsCtrl, "IntervalColor", m_intervalColor, OnIntervalColorChanged, VT_COLOR)
	DISP_PROPERTY_NOTIFY(CBCGTimeIntervalsCtrl, "IntervalTextColor", m_intervalTextColor, OnIntervalTextColorChanged, VT_COLOR)
	DISP_PROPERTY_NOTIFY(CBCGTimeIntervalsCtrl, "BackgroundColor", m_backgroundColor, OnBackgroundColorChanged, VT_COLOR)
	DISP_PROPERTY_NOTIFY(CBCGTimeIntervalsCtrl, "ForegroundColor", m_foregroundColor, OnForegroundColorChanged, VT_COLOR)
	DISP_FUNCTION(CBCGTimeIntervalsCtrl, "GetIntervalsCount", GetIntervalsCount, VT_I2, VTS_NONE)
	DISP_FUNCTION(CBCGTimeIntervalsCtrl, "RemoveInterval", RemoveInterval, VT_BOOL, VTS_I2)
	DISP_FUNCTION(CBCGTimeIntervalsCtrl, "RemoveAllIntervals", RemoveAllIntervals, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CBCGTimeIntervalsCtrl, "GetCurSel", GetCurSel, VT_I2, VTS_NONE)
	DISP_FUNCTION(CBCGTimeIntervalsCtrl, "SetCurSel", SetCurSel, VT_BOOL, VTS_I2)
	DISP_FUNCTION(CBCGTimeIntervalsCtrl, "AddInterval", AddInterval, VT_BOOL, VTS_DATE VTS_DATE VTS_I2)
	DISP_FUNCTION(CBCGTimeIntervalsCtrl, "ChangeInterval", ChangeInterval, VT_BOOL, VTS_I2 VTS_DATE VTS_DATE VTS_I2)
	DISP_FUNCTION(CBCGTimeIntervalsCtrl, "GetInterval", GetInterval, VT_BOOL, VTS_I2 VTS_PDATE VTS_PDATE VTS_PI2)
	DISP_FUNCTION(CBCGTimeIntervalsCtrl, "SetIntervalStatus", SetIntervalStatus, VT_BOOL, VTS_I2 VTS_I2)
	DISP_FUNCTION(CBCGTimeIntervalsCtrl, "SetStatusColor", SetStatusColor, VT_EMPTY, VTS_I2 VTS_COLOR)
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CBCGTimeIntervalsCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CBCGTimeIntervalsCtrl, COleControl)
	//{{AFX_EVENT_MAP(CBCGTimeIntervalsCtrl)
	EVENT_CUSTOM("OnAddInterval", FireOnAddInterval, VTS_I2 VTS_DATE  VTS_DATE)
	EVENT_CUSTOM("OnRemoveInterval", FireOnRemoveInterval, VTS_DATE  VTS_DATE)
	EVENT_CUSTOM("OnChangeInterval", FireOnChangeInterval, VTS_I2 VTS_DATE  VTS_DATE)
	EVENT_CUSTOM("OnSelectionChanged", FireOnSelectionChanged, VTS_I2)
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CBCGTimeIntervalsCtrl, 2)
	PROPPAGEID(CBCGTimeIntervalsPropPage::guid)
	PROPPAGEID(CLSID_CColorPropPage)
END_PROPPAGEIDS(CBCGTimeIntervalsCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CBCGTimeIntervalsCtrl, "BCGTIMEINTERVALS.BCGTimeIntervalsCtrl.1",
	0x39a85989, 0xae7e, 0x11d1, 0xa6, 0x3a, 0, 0xa0, 0xc9, 0x3a, 0x70, 0xec)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CBCGTimeIntervalsCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DBCGTimeIntervals =
		{ 0x39a85987, 0xae7e, 0x11d1, { 0xa6, 0x3a, 0, 0xa0, 0xc9, 0x3a, 0x70, 0xec } };
const IID BASED_CODE IID_DBCGTimeIntervalsEvents =
		{ 0x39a85988, 0xae7e, 0x11d1, { 0xa6, 0x3a, 0, 0xa0, 0xc9, 0x3a, 0x70, 0xec } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwBCGTimeIntervalsOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CBCGTimeIntervalsCtrl, IDS_BCGTIMEINTERVALS, _dwBCGTimeIntervalsOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsCtrl::CBCGTimeIntervalsCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CBCGTimeIntervalsCtrl

BOOL CBCGTimeIntervalsCtrl::CBCGTimeIntervalsCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_BCGTIMEINTERVALS,
			IDB_BCGTIMEINTERVALS,
			afxRegApartmentThreading,
			_dwBCGTimeIntervalsOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// Licensing strings

static const TCHAR BASED_CODE _szLicFileName[] = _T("BCGTimeIntervals.lic");

static const WCHAR BASED_CODE _szLicString[] =
	L"Copyright (c) 1998 IET";


/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsCtrl::CBCGTimeIntervalsCtrlFactory::VerifyUserLicense -
// Checks for existence of a user license

BOOL CBCGTimeIntervalsCtrl::CBCGTimeIntervalsCtrlFactory::VerifyUserLicense()
{
	return AfxVerifyLicFile(AfxGetInstanceHandle(), _szLicFileName,
		_szLicString);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsCtrl::CBCGTimeIntervalsCtrlFactory::GetLicenseKey -
// Returns a runtime licensing key

BOOL CBCGTimeIntervalsCtrl::CBCGTimeIntervalsCtrlFactory::GetLicenseKey(DWORD dwReserved,
	BSTR FAR* pbstrKey)
{
	if (pbstrKey == NULL)
		return FALSE;

	*pbstrKey = SysAllocString(_szLicString);
	return (*pbstrKey != NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsCtrl::CBCGTimeIntervalsCtrl - Constructor

CBCGTimeIntervalsCtrl::CBCGTimeIntervalsCtrl() :
	m_nTimeLabelsWidth (0),
	m_nHourHeight (0),
	m_nHourAlignment (1),
	m_bFocused (FALSE),
	m_CurrDragMode (NONE),
	m_pDraggedInterval (NULL),
	m_pNewInterval (NULL),
	m_pFirstMergedInterval (NULL),
	m_pSecondMergedInterval (NULL),
	m_pTTInterval (NULL),
	m_iMinFullLegenedHeight (0),
	m_pSelectedInterval (NULL)
{
	InitializeIIDs(&IID_DBCGTimeIntervals, &IID_DBCGTimeIntervalsEvents);

	COleDateTime today = COleDateTime::GetCurrentTime ();
	m_iYear = today.GetYear ();
	m_iMonth = today.GetMonth ();
	m_iDay = today.GetDay ();

	m_mergingIsAllowed = TRUE;
	m_intervalColor = colorIntervalBrush;
	m_intervalTextColor = ::GetSysColor (COLOR_BTNTEXT);
	m_backgroundColor = ::GetSysColor (COLOR_3DFACE);
	m_foregroundColor = ::GetSysColor (COLOR_BTNTEXT);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsCtrl::~CBCGTimeIntervalsCtrl - Destructor

CBCGTimeIntervalsCtrl::~CBCGTimeIntervalsCtrl()
{
    m_wndInfo.DestroyWindow();

	CleanUp ();

	DestroyCursor (m_hCursorUp);
	DestroyCursor (m_hCursorDown);
	DestroyCursor (m_hCursorDelete);

	POSITION pos = m_IntervalBrushes.GetStartPosition();
	
	while (pos != NULL)
	{
		HBRUSH hbrStatus;    
		short iStatus;
		
		m_IntervalBrushes.GetNextAssoc (pos, iStatus, hbrStatus);
		::DeleteObject (hbrStatus);
	}
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::CleanUp ()
{
	while (!m_Intervals.IsEmpty ())
	{
		delete m_Intervals.RemoveHead ();
	}

	m_pDraggedInterval = NULL;
	m_pNewInterval = NULL;
	m_pFirstMergedInterval = NULL;
	m_pSecondMergedInterval = NULL;
	m_pTTInterval = NULL;
	m_pSelectedInterval = NULL;
}

/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsCtrl::OnDraw - Drawing function

void CBCGTimeIntervalsCtrl::OnDraw(
			CDC* pDCPaint, const CRect& rcBounds, const CRect& rcInvalid)
{
	if (GetSafeHwnd () == NULL)	// Control doesn't created yet (e.g., AppStudio)
	{
		CRect rectClient = rcBounds;

		pDCPaint->FillSolidRect (&rectClient, ::GetSysColor (COLOR_WINDOW));

		// Draw 3-d border around the control:
		pDCPaint->Draw3dRect (	&rectClient, 
						::GetSysColor (COLOR_3DDKSHADOW),
						::GetSysColor (COLOR_3DHILIGHT));
		
		rectClient.InflateRect (-1, -1);
		pDCPaint->Draw3dRect (	&rectClient,
						::GetSysColor (COLOR_3DSHADOW),
						::GetSysColor (COLOR_3DLIGHT));

		pDCPaint->SetTextColor (::GetSysColor (COLOR_WINDOWTEXT));

		CString strTitle = _T("TimeIntervals");

		pDCPaint->SetBkMode (TRANSPARENT);
		pDCPaint->SelectStockObject (DEFAULT_GUI_FONT);

		CRect rectTitle = rectClient;
		rectTitle.InflateRect (-3, -3);

		pDCPaint->DrawText (strTitle, rectTitle, DT_SINGLELINE);
		return;
	}

	CRect rect = rcBounds;

	CDC*		pDC = pDCPaint;
	BOOL		m_bMemDC = FALSE;
	CDC			dcMem;
	CBitmap		bmp;
	CBitmap*	pOldBmp = NULL;

	if (dcMem.CreateCompatibleDC (pDCPaint) &&
		bmp.CreateCompatibleBitmap (pDCPaint, rect.Width (),
								  rect.Height ()))
	{
		//-------------------------------------------------------------
		// Off-screen DC successfully created. Better paint to it then!
		//-------------------------------------------------------------
		m_bMemDC = TRUE;
		pOldBmp = dcMem.SelectObject (&bmp);
		pDC = &dcMem;
	}

	CPen penLight (PS_SOLID, 1, ::GetSysColor (COLOR_3DLIGHT));
	CPen penDark (PS_SOLID, 1, ::GetSysColor (COLOR_3DDKSHADOW));
	CPen penShadow (PS_SOLID, 1, ::GetSysColor (COLOR_3DSHADOW));

	CPen* pOldPen = (CPen*) pDC->SelectStockObject (NULL_PEN);

	//------------------------------------------
	// Fill control's backgound and draw border:
	//------------------------------------------
	pDC->FillSolidRect (rect, TranslateColor (m_backgroundColor));
	if (m_bFocused)
	{
		pDC->Draw3dRect (rect,
						::GetSysColor (COLOR_3DSHADOW), 
						::GetSysColor (COLOR_3DDKSHADOW));
	}
	rect.InflateRect (-1, -1);

	pDC->Draw3dRect (rect,
					::GetSysColor (COLOR_3DLIGHT), 
					::GetSysColor (COLOR_3DDKSHADOW));
	rect.InflateRect (-1, -1);

	pDC->Draw3dRect (rect, 
					::GetSysColor (COLOR_3DHILIGHT), 
					::GetSysColor (COLOR_3DSHADOW));
	rect.InflateRect (-iHorzOffset, -iVertOffset);

	//---------------------
	// Set text properties:
	//---------------------
	pDC->SetBkMode (TRANSPARENT);
	pDC->SetTextColor (TranslateColor (m_foregroundColor));
	CFont* pOldFont = (CFont*) pDC->SelectObject (&m_fntLabels);

	//------------------
	// Draw time labels:
	//------------------
	CRect rectTimeLabels = rect;
	rectTimeLabels.right = rectTimeLabels.left + m_nTimeLabelsWidth;

	int iLeftTimeMarker = rectTimeLabels.right;
	int iRightTimeMarker = rect.right;
	int iTextHeight = m_nHourHeight * m_nHourAlignment;

	COleDateTime time (m_iYear, m_iMonth, m_iDay, 0, 0, 0);
	for (int iHour = 0; iHour <= iHoursInDay; iHour ++)
	{
		int y = rectTimeLabels.top + iHour * m_nHourHeight + m_nHourHeight / 2;
		BOOL bDrawText = (m_nHourAlignment > 0 && (iHour % m_nHourAlignment) == 0);

		if (bDrawText)
		{
			CString strHour = time.Format (m_strHourFormat);

			CRect rectText = rectTimeLabels;
			rectText.right -= iHorzOffset / 2;
			rectText.top = y - iTextHeight / 2;
			rectText.bottom = y + iTextHeight / 2;

			pDC->DrawText (strHour, rectText,
							DT_SINGLELINE | DT_VCENTER | DT_RIGHT);
		}

		pDC->SelectObject (&penShadow);
		pDC->MoveTo (iLeftTimeMarker, y);
		pDC->LineTo (iRightTimeMarker, y);

		pDC->SelectObject (&penLight);
		pDC->MoveTo (iLeftTimeMarker, y + 1);
		pDC->LineTo (iRightTimeMarker, y + 1);

		time += COleDateTimeSpan (0, 1, 0, 0);
	}

	//-----------
	// Draw cave:
	//-----------
	CRect rectCave = rect;

	rectCave.InflateRect (-iHorzOffset, 0);
	rectCave.left += m_nTimeLabelsWidth;
	rectCave.InflateRect (-rectCave.Width () / 2 + 1, 0);

	pDC->FillSolidRect (rectCave, ::GetSysColor (COLOR_3DFACE));

	pDC->Draw3dRect (rectCave,	::GetSysColor (COLOR_3DSHADOW),
								::GetSysColor (COLOR_3DLIGHT));

	rectCave.InflateRect (0, -1);
	rectCave.left ++;

	pDC->Draw3dRect (rectCave,	::GetSysColor (COLOR_3DDKSHADOW),
								::GetSysColor (COLOR_3DHILIGHT));

	//---------------------
	// Draw time intervals:
	//---------------------
	pDC->SelectStockObject (NULL_PEN);
	CBrush* pOldBrush = (CBrush*) pDC->SelectObject (&m_brIntervalBrush);
	HBRUSH hbrCurr = (HBRUSH) m_brIntervalBrush;

	pDC->SelectObject (&m_fntSmall);
	pDC->SetTextColor (TranslateColor (m_intervalTextColor));

	for (POSITION pos = m_Intervals.GetHeadPosition (); pos != NULL;)
	{
		CTimeInterval* pTI = (CTimeInterval*) m_Intervals.GetNext (pos);
		ASSERT (pTI != NULL);

		const COleDateTime& from = pTI->m_From;
		const COleDateTime& to = pTI->m_To;

		CRect rectTI;
		GetIntervalRect (pTI, rectTI);

		if (pDCPaint->RectVisible (rectTI))
		{
			HBRUSH hbrStatus;
			if (!m_IntervalBrushes.Lookup (pTI->m_iStatus, hbrStatus))
			{
				hbrStatus = (HBRUSH) m_brIntervalBrush;
			}

			if (hbrCurr != hbrStatus)
			{
				pDC->SelectObject (hbrStatus);
				hbrCurr = hbrStatus;
			}

			DrawTimeInterval (pDC, rectTI, from, to, pTI == m_pSelectedInterval);
		}
	}

	//------------------------
	// Draw new time interval:
	//------------------------
	if (m_pNewInterval != NULL)
	{
		const COleDateTime& from = m_pNewInterval->m_From;
		const COleDateTime& to = m_pNewInterval->m_To;

		CRect rectTI;
		GetIntervalRect (m_pNewInterval, rectTI);

		if (pDCPaint->RectVisible (rectTI))
		{
			HBRUSH hbrStatus;
			if (!m_IntervalBrushes.Lookup (m_pNewInterval->m_iStatus, hbrStatus))
			{
				hbrStatus = (HBRUSH) m_brIntervalBrush;
			}

			if (hbrCurr != hbrStatus)
			{
				pDC->SelectObject (hbrStatus);
				hbrCurr = hbrStatus;
			}

			DrawTimeInterval (pDC, rectTI, from, to, TRUE);
		}
	}

	//---------------------
	// Restore DC settings:
	//---------------------
	pDC->SelectObject (pOldPen);
	pDC->SelectObject (pOldFont);
	pDC->SelectObject (pOldBrush);

	if (m_bMemDC)
	{
		//--------------------------------------
		// Copy the results to the on-screen DC:
		//-------------------------------------- 
		CRect rect;
		pDCPaint->GetClipBox (rect);
		pDCPaint->BitBlt (rect.left, rect.top, rect.Width(), rect.Height(),
					   &dcMem, rect.left, rect.top, SRCCOPY);

		dcMem.SelectObject(pOldBmp);
	}
}


/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsCtrl::DoPropExchange - Persistence support

void CBCGTimeIntervalsCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	PX_Bool (pPX, _T("MergingIsAllowed"), m_mergingIsAllowed);
	PX_Bool (pPX, _T("MultiplySelection"), m_multiplySelection);
	PX_Color (pPX, _T("IntervalColor"), m_intervalColor);
	PX_Color (pPX, _T("IntervalTextColor"), m_intervalTextColor);
	PX_Color (pPX, _T("BackgroundColor"), m_backgroundColor);
	PX_Color (pPX, _T("ForegroundColor"), m_foregroundColor);
}


/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsCtrl::OnResetState - Reset control to default state

void CBCGTimeIntervalsCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsCtrl::AboutBox - Display an "About" box to the user

void CBCGTimeIntervalsCtrl::AboutBox()
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CBCGTimeIntervalsCtrl message handlers

void CBCGTimeIntervalsCtrl::OnSize(UINT nType, int cx, int cy) 
{
	COleControl::OnSize(nType, cx, cy);
	AdjustSize (cx, cy);
}
//***************************************************************************************
void CBCGTimeIntervalsCtrl::OnSetFocus(CWnd* pOldWnd) 
{
	COleControl::OnSetFocus(pOldWnd);
	
	m_bFocused = TRUE;
	InvalidateFrame ();
}
//***************************************************************************************
void CBCGTimeIntervalsCtrl::OnKillFocus(CWnd* pNewWnd) 
{
	COleControl::OnKillFocus(pNewWnd);
	
	CancelCurrentMode ();

	m_bFocused = FALSE;
	InvalidateFrame ();
}
//***************************************************************************************
void CBCGTimeIntervalsCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	SetFocus ();

	m_wndInfo.Hide ();
	::SetCursor (m_hCursorArrow);

	if (m_mergingIsAllowed)
	{
		KillTimer (uiMergeEventId);
		m_pFirstMergedInterval = NULL;
		m_pSecondMergedInterval = NULL;
	}

	if (m_pDraggedInterval != NULL)
	{
		ReleaseCapture ();
	}

	CRect rect;
	GetClientRect (&rect);

	//-------------------
	// Ignore small move:
	//-------------------
	if (m_pDraggedInterval != NULL &&
		rect.PtInRect (point) &&
		m_pNewInterval == NULL &&
		abs (m_iMouseDownY - point.y) < iSmallestMoveDelta)
	{
		*m_pDraggedInterval = m_SavedDragInterval;

		CRect rectInterval;
		GetIntervalRect (m_pDraggedInterval, rectInterval);

		InvalidateControl (rectInterval);
	}
	else
	{
		if (m_CurrDragMode == MOVE && (point.x < rect.left || point.x > rect.right))
		{
			if (m_multiplySelection)
			{
				COleDateTime from = m_pDraggedInterval->m_From;
				COleDateTime to = m_pDraggedInterval->m_To;

				if (!RemoveTimeInterval (m_pDraggedInterval))
				{
					ASSERT (FALSE);
				}

				if (m_pNewInterval != NULL)
				{
					ChangeSelection (NULL);
					delete m_pNewInterval;
					m_pNewInterval = NULL;
				}

				FireOnRemoveInterval (from, to);
				m_pDraggedInterval = NULL;
			}
		}

		if (m_pNewInterval != NULL)
		{
			COleDateTime from = m_pNewInterval->m_From;
			COleDateTime to = m_pNewInterval->m_To;

			CRect rectNew;
			rectNew.SetRectEmpty ();

			if (to > from/* && to - from >= COleDateTimeSpan (0, 0, iMinuteAlignment, 0)*/)
			{
				int iIndex = InsertTimeInterval (m_pNewInterval);
				ChangeSelection (m_pNewInterval);
				m_pNewInterval = NULL;
				FireOnAddInterval (iIndex, from, to);
			}
			else
			{
				GetIntervalRect (m_pNewInterval, rectNew);
				rectNew.InflateRect (0, 10);

				ChangeSelection (NULL);
				delete m_pNewInterval;
				m_pNewInterval = NULL;
			}

			InvalidateControl (rectNew);
		}
		else if (m_pDraggedInterval != NULL)
		{
			int iIndex = ChangeTimeInterval (m_pDraggedInterval);

			if (m_SavedDragInterval != *m_pDraggedInterval)
			{
				FireOnChangeInterval (iIndex,
									m_pDraggedInterval->m_From, 
									m_pDraggedInterval->m_To);
			}
		}
	}
		
	m_pNewInterval = NULL;
	m_pDraggedInterval = NULL;
	m_CurrDragMode = NONE;

	COleControl::OnLButtonUp(nFlags, point);
}
//***************************************************************************************
void CBCGTimeIntervalsCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	COleDateTime time;

	m_wndInfo.Hide ();
	m_rectTT.SetRectEmpty ();
	KillTimer (uiToolTipEventId);

	m_iMouseDownY = point.y;

	if (PointToTime (point, time, TRUE))
	{
		m_pDraggedInterval = HitTest (point, m_CurrDragMode);

		if (m_pDraggedInterval == NULL && m_multiplySelection)	// New interval!
		{
			COleDateTime to = time + COleDateTimeSpan (0, 0, iMinuteAlignment, 0);
			
			m_pNewInterval = new CTimeInterval;
				
			m_pNewInterval->m_From = time;
			m_pNewInterval->m_To = time;

			m_pDraggedInterval = m_pNewInterval;
			m_bNewItervalFirstTimeDrag = TRUE;
		}
		else
		{
			ChangeSelection (m_pDraggedInterval);
		}

		m_PrevDragTime = time;
		SetCapture ();
	}
	else
	{
		ChangeSelection (NULL);
	}

	if (m_pDraggedInterval != NULL)
	{
		m_SavedDragInterval = *m_pDraggedInterval;

		CRect rect;
		GetClientRect (&rect);
		ClientToScreen (&rect);

		CString strText;
		BuildTooltipText (m_pDraggedInterval, TRUE, strText);

		m_wndInfo.Track (CPoint (rect.right + 5, rect.top + rect.Height () / 2), strText);
	}

	COleControl::OnLButtonDown(nFlags, point);
}
//***************************************************************************************
void CBCGTimeIntervalsCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
	COleControl::OnMouseMove(nFlags, point);

	HIT_TEST hit;
	HitTest (point, hit);

	if (m_pDraggedInterval == NULL)
	{
		//----------------------------------------------------
		// No dragged interval, just adjust  cursor according
		// to position:
		//----------------------------------------------------
		ChangeCursor (hit);
		SetInfoWindow (point);
		return;
	}

	//---------------------------------------------
	// If cursor leaved client area, assume remove:
	//---------------------------------------------
	if (m_CurrDragMode == MOVE && hit == REMOVE)
	{
		m_wndInfo.Hide ();
		::SetCursor (m_hCursorDelete);
		return;
	}

	//---------------------------------------------------------------
	// If we start to drag a new time interval, then direction is
	// undefined! Define direction by difference between the current
	// cursor position and place were mouse was clicked down:
	//---------------------------------------------------------------
	if (m_pNewInterval != NULL && m_bNewItervalFirstTimeDrag)
	{
		if (point.y == m_iMouseDownY)
		{
			return;
		}

		m_CurrDragMode = (point.y > m_iMouseDownY) ? STRETCH_DOWN : STRETCH_UP;
		m_bNewItervalFirstTimeDrag = FALSE;
	}

	//-----------------------------------
	// Remeber dragged interval settings:
	//-----------------------------------
	CTimeInterval savedInterval (*m_pDraggedInterval);

	COleDateTime from = m_pDraggedInterval->m_From;
	COleDateTime to = m_pDraggedInterval->m_To;
	COleDateTimeSpan duration = to - from;

	CRect rectTIOld;
	GetIntervalRect (m_pDraggedInterval, rectTIOld);

	//------------------------
	// Mouse prition ==> time:
	//------------------------
	COleDateTime timeMouse;
	if (!PointToTime (point, timeMouse))
	{
		m_wndInfo.Hide ();
		return;
	}

	ChangeCursor (m_CurrDragMode);

	COleDateTimeSpan minDuration (0, 0, iMinuteAlignment, 0);

	switch (m_CurrDragMode)
	{
	case STRETCH_UP:
		from = timeMouse;
		if (to - from < minDuration)
		{
			from = to - minDuration;
		}
		break;

	case STRETCH_DOWN:
		to = timeMouse;
		if (to - from < minDuration)
		{
			to = from + minDuration;
		}
		break;

	case MOVE:
		{
			COleDateTimeSpan timeDelta = timeMouse - m_PrevDragTime;

			from += timeDelta;
			to += timeDelta;

			if (to.GetDay () != m_iDay)
			{
				to = COleDateTime (m_iYear, m_iMonth, m_iDay,
							23, 59, 0) + minute;
				from = to - duration;
			}
				
			if (from.GetDay () != m_iDay)
			{
				from = COleDateTime (m_iYear, m_iMonth, m_iDay,
							0, 0, 0);
				to = from + duration;
			}
		}
		break;

	default:
		ASSERT (FALSE);
		return;
	}

	//----------------------
	// Update time interval:
	//----------------------
	m_pDraggedInterval->m_From = from;
	m_pDraggedInterval->m_To = to;

	//------------------------------------------------------------------
	// Maybe new interval location is overlapped with another interval?
	//------------------------------------------------------------------
	OVERLAPPING_TYPE type;
	CTimeInterval* pOverInterval = GetIntervalOverlapped (m_pDraggedInterval, type);

	BOOL bWaitForMerge = FALSE;

	if (pOverInterval != NULL)
	{
		switch (type)
		{
		case FULL_OVERLAPPING:
			*m_pDraggedInterval = savedInterval;

			InvalidateRect (rectTIOld);
			UpdateWindow ();
			return;

		case BOTTOM_OVERLAPPING:
			m_pDraggedInterval->m_From = pOverInterval->m_To;
			if (m_CurrDragMode == MOVE)
			{
				m_pDraggedInterval->m_To = m_pDraggedInterval->m_From + duration;
			}

			if (m_mergingIsAllowed && m_pNewInterval == NULL)
			{
				SetTimer (uiMergeEventId, iMergeEventDelay, NULL);
				bWaitForMerge = TRUE;
				m_pFirstMergedInterval = pOverInterval;
				m_pSecondMergedInterval = m_pDraggedInterval;
			}
			break;

		case TOP_OVERLAPPING:
			m_pDraggedInterval->m_To = pOverInterval->m_From;
			if (m_CurrDragMode == MOVE)
			{
				m_pDraggedInterval->m_From = m_pDraggedInterval->m_To - duration;
			}
			
			if (m_mergingIsAllowed && m_pNewInterval == NULL)
			{
				SetTimer (uiMergeEventId, iMergeEventDelay, NULL);
				bWaitForMerge = TRUE;

				m_pFirstMergedInterval = m_pDraggedInterval;
				m_pSecondMergedInterval = pOverInterval;
			}
			break;
		}
	}

	COleDateTimeSpan diff = m_pDraggedInterval->m_To - m_pDraggedInterval->m_From;

	//------------------------------------
	// Calculate a new interval rectangle:
	//------------------------------------
	CRect rectTINew;
	GetIntervalRect (m_pDraggedInterval, rectTINew);

	if (rectTINew != rectTIOld)
	{
		//-----------------------------------------
		// Interval was changed, update screen now:
		//-----------------------------------------
		InvalidateRect (rectTIOld);
		InvalidateRect (rectTINew);

		UpdateWindow ();

		SetInfoWindow (point);
	}
	else
	{
		//------------------------------------------------
		// Rectangle wasn't move, continue wait for merge:
		//------------------------------------------------
		bWaitForMerge = TRUE;
	}

	if (!bWaitForMerge)
	{
		KillTimer (uiMergeEventId);
		m_pFirstMergedInterval = NULL;
		m_pSecondMergedInterval = NULL;
	}

	m_PrevDragTime = timeMouse;
}
//***************************************************************************************
BOOL CBCGTimeIntervalsCtrl::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::InvalidateFrame ()
{
	const int iFrameWidth = 2;

	CRect rectClient;
	GetClientRect (&rectClient);

	CRect rect;

	rect = rectClient;
	rect.bottom = rect.top + iFrameWidth;
	InvalidateRect (rect);

	rect = rectClient;
	rect.top = rect.bottom - iFrameWidth;
	InvalidateRect (rect);

	rect = rectClient;
	rect.right = rect.left + iFrameWidth;
	InvalidateRect (rect);

	rect = rectClient;
	rect.left = rect.right - iFrameWidth;
	InvalidateRect (rect);

	UpdateWindow ();
}
//****************************************************************************************
BOOL CBCGTimeIntervalsCtrl::PointToTime (const CPoint& point, COleDateTime& time,
										BOOL bExact) const
{
	CRect rect;
	GetClientRect (&rect);

	rect.InflateRect (0, -iVertOffset - 2);
	
	if (bExact)
	{
		rect.InflateRect (-iHorzOffset - 2, 0);
		rect.left += m_nTimeLabelsWidth;

		if (!rect.PtInRect (point))
		{
			return FALSE;
		}
	}

	int iOffset = point.y - rect.top - m_nHourHeight / 2;
	if (iOffset < 0)
	{
		iOffset = 0;
	}

	int iHour = iOffset / m_nHourHeight;
	int iMinute = (iOffset % m_nHourHeight) * iMinutesInHour / m_nHourHeight;

	iMinute = iMinute / iMinuteAlignment * iMinuteAlignment;
	
	if (iMinute == iMinutesInHour)
	{
		iMinute = 0;
		iHour ++;
	}

	if (bExact && (iHour < 0 || iHour >= iHoursInDay))
	{
		if (iHour != iHoursInDay || iMinute != 0)
		{
			return FALSE;
		}
	}

	iHour = max (iHour, 0);
	if (iHour >= iHoursInDay)
	{
		time = COleDateTime (m_iYear, m_iMonth, m_iDay, 23, 59, 0) + minute;
	}
	else
	{
		time = COleDateTime (m_iYear, m_iMonth, m_iDay, iHour, iMinute, 0);
	}
	return TRUE;
}
//****************************************************************************************
int CBCGTimeIntervalsCtrl::GetTimeY (const COleDateTime& time) const
{
	CRect rect;
	GetClientRect (&rect);

	rect.InflateRect (-iHorzOffset - 2, -iVertOffset - 2);
	rect.left += m_nTimeLabelsWidth;

	int iHour = time.GetHour ();
	int iMinute = time.GetMinute ();

	if (time.GetDay () != m_iDay)	// Assume 00:00 next day
	{
		iHour = iHoursInDay;
		iMinute = 0;
	}

	return rect.top + m_nHourHeight * iHour + iMinute * m_nHourHeight / iMinutesInHour + 
			m_nHourHeight / 2;
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::DrawTimeInterval (CDC* pDC, const CRect& rect, 
										const COleDateTime& from, const COleDateTime& to,
										BOOL bSelected)
{
	CString strFrom = from.Format (m_strTimeFormat);
	CString strTo = to.Format (m_strTimeFormat);

	const int iMiddleOffset = rect.Width () / 3;

	TEXTMETRIC tm;
	pDC->GetTextMetrics (&tm);
	int nTextHeight = tm.tmHeight + 2;

	//-------------------------------------------------------
	// If interval height is too low, don't ptint text, just
	// draw rectangle:
	//-------------------------------------------------------
	if (rect.Height () < nTextHeight + 2)
	{
		pDC->Rectangle (&rect);

		CRect rectFrame = rect;

		if (bSelected)
		{
			pDC->Draw3dRect (rectFrame,
							::GetSysColor (COLOR_3DDKSHADOW),
							::GetSysColor (COLOR_3DDKSHADOW));
			rectFrame.InflateRect (-1, -1);
		}

		pDC->Draw3dRect (rectFrame,
						::GetSysColor (COLOR_3DHILIGHT), 
						::GetSysColor (COLOR_3DSHADOW));
		return;
	}

	//------------------------------------------
	// Define top, bottom and middle rectangles:
	//------------------------------------------
	CRect rectFrom = rect;
	rectFrom.bottom = rectFrom.top + nTextHeight;

	CRect rectTo = rect;
	rectTo.top = rectTo.bottom - nTextHeight;

	CRect rectMiddle = rect;

	rectMiddle.InflateRect (- iMiddleOffset, 0);
	rectMiddle.top = rectFrom.bottom - 1;
	rectMiddle.bottom = rectTo.top + 1;

	//-----------------------
	// Draw bottom rectangle:
	//-----------------------
	pDC->Rectangle (&rectTo);
	if (bSelected)
	{
		pDC->Draw3dRect (rectTo,
						::GetSysColor (COLOR_3DDKSHADOW),
						::GetSysColor (COLOR_3DDKSHADOW));
		rectTo.InflateRect (-1, -1);
	}

	pDC->Draw3dRect (rectTo,
					::GetSysColor (COLOR_3DHILIGHT), 
					::GetSysColor (COLOR_3DSHADOW));
	pDC->DrawText (strTo, rectTo, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

	//--------------------
	// Draw top rectangle:
	//--------------------
	pDC->Rectangle (&rectFrom);
	if (bSelected)
	{
		pDC->Draw3dRect (rectFrom,
						::GetSysColor (COLOR_3DDKSHADOW),
						::GetSysColor (COLOR_3DDKSHADOW));
		rectFrom.InflateRect (-1, -1);
	}
	pDC->Draw3dRect (rectFrom,
					::GetSysColor (COLOR_3DHILIGHT), 
					::GetSysColor (COLOR_3DSHADOW));
	pDC->DrawText (strFrom, rectFrom, DT_CENTER | DT_VCENTER | DT_SINGLELINE);


	//-----------------------
	// Draw middle rectangle:
	//-----------------------
	if (rectMiddle.Height () > 1)
	{
		CRect rectMiddleFill = rectMiddle;
		rectMiddleFill.InflateRect (0, 3);
		pDC->Rectangle (&rectMiddleFill);

		CPen penDkShadow (PS_SOLID, 1, ::GetSysColor (COLOR_3DDKSHADOW));
		CPen penShadow (PS_SOLID, 1, ::GetSysColor (COLOR_3DSHADOW));
		CPen penLight (PS_SOLID, 1, ::GetSysColor (COLOR_3DHILIGHT));

		CPen* pOldPen = (CPen*) pDC->SelectStockObject (NULL_PEN);

		if (bSelected)
		{
			pDC->SelectObject (&penDkShadow);

			pDC->MoveTo (rectMiddle.left, rectMiddle.top);
			pDC->LineTo (rectMiddle.left, rectMiddle.bottom);

			pDC->MoveTo (rectMiddle.right - 1, rectMiddle.top);
			pDC->LineTo (rectMiddle.right - 1, rectMiddle.bottom);

			rectMiddle.InflateRect (-1, 0);
		}

		pDC->SelectObject (&penLight);

		pDC->MoveTo (rectMiddle.left, rectMiddle.top);
		pDC->LineTo (rectMiddle.left, rectMiddle.bottom);

		pDC->SelectObject (&penShadow);

		pDC->MoveTo (rectMiddle.right - 1, rectMiddle.top);
		pDC->LineTo (rectMiddle.right - 1, rectMiddle.bottom);

		pDC->SelectObject (pOldPen);
	}

}
//****************************************************************************************
CTimeInterval* CBCGTimeIntervalsCtrl::HitTest (const CPoint& point,
			CBCGTimeIntervalsCtrl::HIT_TEST& hit) const
{
	hit = NONE;

	CRect rectClient;
	GetClientRect (&rectClient);

	if (m_multiplySelection &&
		(point.x < rectClient.left || point.x > rectClient.right))
	{
		hit = REMOVE;
		return NULL;
	}

	for (POSITION pos = m_Intervals.GetHeadPosition (); pos != NULL;)
	{
		CTimeInterval* pTI = (CTimeInterval*) m_Intervals.GetNext (pos);
		ASSERT (pTI != NULL);

		CRect rect;
		GetIntervalRect (pTI, rect);

		if (abs (rect.top - point.y) < iSmallestMoveDelta)
		{
			hit = STRETCH_UP;
			return pTI;
		}

		if (abs (rect.bottom - point.y - 1) < iSmallestMoveDelta)
		{
			hit = STRETCH_DOWN;
			return pTI;
		}

		if (point.y >= rect.top && point.y <= rect.bottom)
		{
			hit = MOVE;
			return pTI;
		}
	}

	return NULL;
}
//****************************************************************************************
BOOL CBCGTimeIntervalsCtrl::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	CPoint ptCursor;
	::GetCursorPos (&ptCursor);
	ScreenToClient (&ptCursor);

	HIT_TEST hit;
	HitTest (ptCursor, hit);

	ChangeCursor (hit);
	return TRUE;
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::ChangeCursor (CBCGTimeIntervalsCtrl::HIT_TEST hit) const
{
	switch (hit)
	{
	case STRETCH_UP:
		::SetCursor (m_hCursorUp);
		break;

	case STRETCH_DOWN:
		::SetCursor (m_hCursorDown);
		break;

/*	case MOVE:
		::SetCursor (m_hCursorMove);
		break;
*/
	case REMOVE:
		::SetCursor (m_hCursorDelete);
		break;

	default:
		::SetCursor (m_hCursorArrow);
		break;
	}
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::GetIntervalRect (const CTimeInterval* pTI, CRect& rectTI) const
{
	const COleDateTime& from = pTI->m_From;
	const COleDateTime& to = pTI->m_To;

	GetClientRect (&rectTI);
	rectTI.InflateRect (-iHorzOffset - 2, 0);

	rectTI.left += m_nTimeLabelsWidth;
	rectTI.top = GetTimeY (from);
	rectTI.bottom = GetTimeY (to);
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::AdjustSize (int cx, int cy)
{
	static int nHourAlignments [] =
	{
		1, 2, 3, 4, 6, 8, 12, 0
	};

	m_nHourHeight = (cy - iVertOffset * 3) / iHoursInDay;

	//---------------------
	// Set text properties:
	//---------------------
	CClientDC dc (this);
	CFont* pOldFont = (CFont*) dc.SelectObject (&m_fntLabels);

	TEXTMETRIC tm;
	dc.GetTextMetrics (&tm);

	int nTextRowHeight = tm.tmHeight * 3 / 2;
	int nTextTotalHeight = cy - iVertOffset * 2;

	//---------------------------------
	// Calculate max. hour label width:
	//---------------------------------
	m_nTimeLabelsWidth = 0;
	COleDateTime time (m_iYear, m_iMonth, m_iDay, 0, 0, 0);
	for (int iHour = 0; iHour <= iHoursInDay; iHour ++)
	{
		CString strHourLabel = time.Format (m_strHourFormat);
		int iLabelWidth = dc.GetTextExtent (strHourLabel).cx;

		if (iLabelWidth > m_nTimeLabelsWidth)
		{
			m_nTimeLabelsWidth = iLabelWidth;
		}

		time += COleDateTimeSpan (0, 1, 0, 0);
	}
	m_nTimeLabelsWidth += iHorzOffset / 2;

	//----------------------------
	// Calculate hours allignment:
	//----------------------------
	m_nHourAlignment = 1;
	for (int i = 0; m_nHourAlignment != 0; i ++)
	{
		m_nHourAlignment = nHourAlignments [i];
		if (nTextRowHeight < nTextTotalHeight * m_nHourAlignment / 
			(iHoursInDay + 1))
		{
			break;
		}
	}

	dc.SelectObject (&m_fntSmall);

	m_iMinFullLegenedHeight = tm.tmHeight * 2 + 4;
	dc.SelectObject (pOldFont);
}
//****************************************************************************************
CTimeInterval* CBCGTimeIntervalsCtrl::GetIntervalOverlapped (CTimeInterval* pTICheck, 
									CBCGTimeIntervalsCtrl::OVERLAPPING_TYPE& type) const
{
	ASSERT (pTICheck != NULL);

	type = NO_OVERLAPPING;

	const COleDateTime& from1 = pTICheck->m_From;
	const COleDateTime& to1 = pTICheck->m_To;

	for (POSITION pos = m_Intervals.GetHeadPosition (); pos != NULL;)
	{
		CTimeInterval* pTI = (CTimeInterval*) m_Intervals.GetNext (pos);
		ASSERT (pTI != NULL);

		if (pTI != pTICheck)
		{
			const COleDateTime& from2 = pTI->m_From;
			const COleDateTime& to2 = pTI->m_To;

			if (to1 <= from2 || to2 <= from1)
			{
				continue;
			}

			if ((from1 > from2 && to1 < to2) ||
				(from2 > from1 && to2 < to1))
			{
				type = FULL_OVERLAPPING;
				return pTI;
			}

			if (to1 > from2 && from1 < from2)
			{
				type = TOP_OVERLAPPING;
				return pTI;
			}

			if (from1 < to2 && to1 > to2)
			{
				type = BOTTOM_OVERLAPPING;
				return pTI;
			}
		}
	}

	return NULL;
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	m_wndInfo.Hide ();

	BOOL bShift = (GetKeyState(VK_SHIFT) < 0);

	switch (nChar)
	{
	case VK_DOWN:
		MoveSelectedInterval (iMinuteAlignment, bShift);
		break;

	case VK_UP:
		MoveSelectedInterval (-iMinuteAlignment, bShift);
		break;

	case VK_DELETE:
		DeleteSelectedInterval ();
		break;

	case VK_HOME:
		MoveSelectedInterval (0, bShift, MOVE_TO_TOP);
		break;

	case VK_END:
		MoveSelectedInterval (0, bShift, MOVE_TO_BOTTOM);
		break;

	case VK_ESCAPE:
		CancelCurrentMode ();
		break;
	}

	COleControl::OnKeyDown(nChar, nRepCnt, nFlags);
}
//*****************************************************************************************
UINT CBCGTimeIntervalsCtrl::OnGetDlgCode() 
{
	return DLGC_WANTARROWS | DLGC_WANTCHARS;
}
//****************************************************************************************
int CBCGTimeIntervalsCtrl::InsertTimeInterval (CTimeInterval* pTINew)
{
	BOOL bInserted = FALSE;

	int iIndex = -1;
	int i = 0;
	for (POSITION pos = m_Intervals.GetHeadPosition (); pos != NULL && !bInserted;
		i ++)
	{
		POSITION posSave = pos;

		CTimeInterval* pTI = (CTimeInterval*) m_Intervals.GetNext (pos);
		ASSERT (pTI != NULL);

		if (pTI->m_From >= pTINew->m_From)
		{
			m_Intervals.InsertBefore (posSave, pTINew);
			iIndex = i;
			bInserted = TRUE;
		}
	}

	if (!bInserted)
	{
		m_Intervals.AddTail (pTINew);
		iIndex = m_Intervals.GetCount () - 1;
	}

	return iIndex;
}
//****************************************************************************************
int CBCGTimeIntervalsCtrl::ChangeTimeInterval (CTimeInterval* pTIChanged)
{
	for (POSITION pos = m_Intervals.GetHeadPosition (); pos != NULL;)
	{
		POSITION posSave = pos;

		CTimeInterval* pTI = (CTimeInterval*) m_Intervals.GetNext (pos);
		ASSERT (pTI != NULL);

		if (pTI == pTIChanged)
		{
			m_Intervals.RemoveAt (posSave);
		}
	}

	return InsertTimeInterval (pTIChanged);
}
//****************************************************************************************
BOOL CBCGTimeIntervalsCtrl::RemoveTimeInterval (CTimeInterval* pTIRemoved)
{
	ASSERT (pTIRemoved != NULL);

	if (pTIRemoved == m_pSelectedInterval)
	{
		ChangeSelection (NULL);
	}

	CRect rectTI;
	GetIntervalRect (pTIRemoved, rectTI);

	for (POSITION pos = m_Intervals.GetHeadPosition (); pos != NULL;)
	{
		POSITION posSave = pos;

		CTimeInterval* pTI = (CTimeInterval*) m_Intervals.GetNext (pos);
		ASSERT (pTI != NULL);

		if (pTI == pTIRemoved)
		{
			m_Intervals.RemoveAt (posSave);
			delete pTIRemoved;

			InvalidateControl (rectTI);
			return TRUE;
		}
	}

	return FALSE;
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent == uiMergeEventId)
	{
		if (m_pFirstMergedInterval != NULL &&
			m_pSecondMergedInterval != NULL)
		{
			COleDateTime fromRemoved = m_pSecondMergedInterval->m_From;
			COleDateTime toRemoved = m_pSecondMergedInterval->m_To;

			m_pFirstMergedInterval->m_To = m_pSecondMergedInterval->m_To;

			COleDateTime fromMerged = m_pFirstMergedInterval->m_From;
			COleDateTime toMerged = m_pFirstMergedInterval->m_To;

			if (m_pDraggedInterval == m_pSecondMergedInterval)
			{
				m_pDraggedInterval = m_pFirstMergedInterval;
			}

			if (!RemoveTimeInterval (m_pSecondMergedInterval))
			{
				ASSERT (FALSE);
			}

			int iIndex = ChangeTimeInterval (m_pFirstMergedInterval);

			CRect rectTI;
			GetIntervalRect (m_pFirstMergedInterval, rectTI);

			FireOnRemoveInterval (fromRemoved, toRemoved);
			FireOnChangeInterval (iIndex, fromMerged, toMerged);

			InvalidateControl (rectTI);
		}

		KillTimer (uiMergeEventId);
		m_pFirstMergedInterval = NULL;
		m_pSecondMergedInterval = NULL;
	}

	if (nIDEvent == uiToolTipEventId)
	{
		if (m_pTTInterval != NULL)
		{
			CString strText;
			BuildTooltipText (m_pTTInterval, m_rectTT.Height () < m_iMinFullLegenedHeight,
							strText);

			CPoint ptCursor;
			::GetCursorPos (&ptCursor);

			ptCursor += CPoint (
						GetSystemMetrics (SM_CXCURSOR) / 2, 
						GetSystemMetrics (SM_CYCURSOR) / 2);
			m_wndInfo.Track (ptCursor, strText);

			SetCapture ();
		}
		else
		{
			m_wndInfo.Hide ();
			m_rectTT.SetRectEmpty ();
		}

		KillTimer (uiToolTipEventId);
	}
	
	COleControl::OnTimer(nIDEvent);
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::OnMergingIsAllowedChanged() 
{
	SetModifiedFlag();
}
//****************************************************************************************
int CBCGTimeIntervalsCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (COleControl::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_brIntervalBrush.CreateSolidBrush (m_intervalColor);

	LOGFONT lf;
	memset (&lf, 0, sizeof (LOGFONT));
	_tcscpy (lf.lfFaceName, _T ("Arial"));
	lf.lfHeight = 12;

	m_fntSmall.CreateFontIndirect (&lf);

	lf.lfHeight = 13;
	m_fntLabels.CreateFontIndirect (&lf);

	m_hCursorUp = theApp.LoadCursor (IDC_UP);
	m_hCursorDown = theApp.LoadCursor (IDC_DOWN);
	m_hCursorDelete = theApp.LoadCursor (IDC_DELETE);

	m_hCursorArrow = ::LoadCursor (NULL, IDC_ARROW);

	m_wndInfo.Create (this, TRUE /* Shadow */);
	m_wndInfo.SetOwner (this);
	m_wndInfo.Hide ();

	m_rectTT.SetRectEmpty ();

	if (!m_multiplySelection)
	{
		CTimeInterval* pTI = new CTimeInterval;
		
		pTI->m_From = COleDateTime (m_iYear, m_iMonth, m_iDay, 8, 0, 0);
		pTI->m_To = COleDateTime (m_iYear, m_iMonth, m_iDay, 17, 0, 0);

		InsertTimeInterval (pTI);
	}

	//------------------------------------------------
	// Check locale settings (for 12/24 hours format):
	//------------------------------------------------
	TCHAR szLocaleData [100];

	GetLocaleInfo (LOCALE_USER_DEFAULT, LOCALE_STIME, szLocaleData, 100);
	CString strTimeSeparator = szLocaleData [0] == 0 ? _T ("") : szLocaleData;

	GetLocaleInfo (LOCALE_USER_DEFAULT, LOCALE_ITLZERO, szLocaleData, 100);
	BOOL bLeadingZero = (szLocaleData [0] == '1');

	GetLocaleInfo (LOCALE_USER_DEFAULT, LOCALE_ITIME, szLocaleData, 100);
	BOOL bIs24HoursFormat = (szLocaleData [0] == '1');
	
	if (bIs24HoursFormat)
	{
		m_strHourFormat = bLeadingZero ? _T("%H") : _T("%#H");
		m_strTimeFormat = m_strHourFormat;
		m_strTimeFormat += strTimeSeparator;
		m_strTimeFormat += _T("%M");
		m_strTimeTooltipFormat = m_strTimeFormat;
	}
	else
	{
		m_strHourFormat = _T("%#I %p");
		m_strTimeFormat = _T("%#I");
		m_strTimeFormat += strTimeSeparator;
		m_strTimeFormat += _T("%M");
		m_strTimeTooltipFormat = m_strTimeFormat + _T(" %p");
	}
	
	return 0;
}
//****************************************************************************************
BOOL CBCGTimeIntervalsCtrl::PreTranslateMessage(MSG* pMsg) 
{
   	switch (pMsg->message)
    {
	// If we get a keyboard or mouse message, 
	// hide the toolyip screen.
	case WM_SYSKEYDOWN:
	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
	case WM_MBUTTONDOWN:
	case WM_NCLBUTTONDOWN:
	case WM_NCRBUTTONDOWN:
	case WM_NCMBUTTONDOWN:
	case WM_KEYUP:
		m_wndInfo.Hide ();
		m_rectTT.SetRectEmpty ();
		KillTimer (uiToolTipEventId);
		break;

	case WM_KEYDOWN:
		switch (pMsg->wParam)
		{
		case VK_UP:
		case VK_DOWN:
		case VK_HOME:
		case VK_END:
			SendMessage(pMsg->message, pMsg->wParam, pMsg->lParam);
            return TRUE;

		case VK_ESCAPE:
			CancelCurrentMode ();
			return TRUE;
		}

		m_wndInfo.Hide ();
		m_rectTT.SetRectEmpty ();
		KillTimer (uiToolTipEventId);
		break;
	}

	return COleControl::PreTranslateMessage(pMsg);
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::SetInfoWindow (const CPoint& point)
{
	if (m_pDraggedInterval != NULL)
	{
		CString strText;
		BuildTooltipText (m_pDraggedInterval, TRUE, strText);
		m_wndInfo.SetWindowText (strText);
		m_wndInfo.ShowWindow(SW_SHOWNOACTIVATE);
		m_wndInfo.Invalidate ();
		m_wndInfo.UpdateWindow ();
		return;
	}

	if (m_rectTT.PtInRect (point))
	{
		return;
	}

	HIT_TEST		hit;
	CTimeInterval*	pTI;
	BOOL			bShowInfo = TRUE;
	CRect			rectTI;

	rectTI.SetRectEmpty ();

	if ((pTI = HitTest (point, hit)) == NULL)
	{
		bShowInfo = FALSE;
	}
	else
	{
		GetIntervalRect (pTI, rectTI);
		bShowInfo = rectTI.PtInRect (point);
	}

	if (!bShowInfo)
	{
		ReleaseCapture ();
		m_wndInfo.Hide ();

		KillTimer (uiToolTipEventId);
		rectTI.SetRectEmpty ();
	}
	else
	{
		SetTimer (uiToolTipEventId, iToolTipEventDelay, NULL);
	}

	m_pTTInterval = pTI;
	m_rectTT = rectTI;
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::ChangeSelection (CTimeInterval* pTI)
{
	if (!m_multiplySelection || m_pSelectedInterval == pTI)
	{
		return;
	}

	CRect rectOld;
	rectOld.SetRectEmpty ();

	if (m_pSelectedInterval != NULL)
	{
		GetIntervalRect (m_pSelectedInterval, rectOld);
	}

	CRect rectNew;
	rectNew.SetRectEmpty ();

	if (pTI != NULL)
	{
		GetIntervalRect (pTI, rectNew);
	}

	m_pSelectedInterval = pTI;

	InvalidateControl (rectOld);
	InvalidateControl (rectNew);

	UpdateWindow ();

	FireOnSelectionChanged (GetCurSel ());
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::OnMultiplySelectionChanged() 
{
	if (!m_multiplySelection && m_Intervals.GetCount () != 1)
	{
		CleanUp ();

		CTimeInterval* pTI = new CTimeInterval;
		
		pTI->m_From = COleDateTime (m_iYear, m_iMonth, m_iDay, 8, 0, 0);
		pTI->m_To = COleDateTime (m_iYear, m_iMonth, m_iDay, 17, 0, 0);

		InsertTimeInterval (pTI);
		InvalidateControl ();
	}

	SetModifiedFlag();
}
//****************************************************************************************
short CBCGTimeIntervalsCtrl::GetIntervalsCount() 
{
	return m_Intervals.GetCount ();
}
//****************************************************************************************
BOOL CBCGTimeIntervalsCtrl::GetInterval(short iIndex, DATE FAR* From, DATE FAR* To, short FAR* iStatus) 
{
	POSITION pos = m_Intervals.FindIndex (iIndex);
	if (pos == NULL)
	{
		return FALSE;
	}

	CTimeInterval* pInterval = (CTimeInterval*) m_Intervals.GetAt (pos);
	ASSERT (pInterval != NULL);

	*From = pInterval->m_From;
	*To = pInterval->m_To;

	*iStatus = pInterval->m_iStatus;

	return TRUE;
}
//****************************************************************************************
BOOL CBCGTimeIntervalsCtrl::RemoveInterval(short index) 
{
	if (!m_multiplySelection)
	{
		return FALSE;
	}

	POSITION pos = m_Intervals.FindIndex (index);
	if (pos == NULL)
	{
		return FALSE;
	}

	CTimeInterval* pInterval = (CTimeInterval*) m_Intervals.GetAt (pos);
	ASSERT (pInterval != NULL);

	COleDateTime fromRemoved = pInterval->m_From;
	COleDateTime toRemoved = pInterval->m_To;

	if (!RemoveTimeInterval (pInterval))
	{
		return FALSE;
	}

//	FireOnRemoveInterval (fromRemoved, toRemoved);
	return TRUE;
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::RemoveAllIntervals() 
{
	if (!m_multiplySelection)
	{
		return;
	}

	CleanUp ();
	InvalidateControl ();
}
//****************************************************************************************
BOOL CBCGTimeIntervalsCtrl::AddInterval(DATE dateFrom, DATE dateTo, short iStatus) 
{
	if (!m_multiplySelection)
	{
		return FALSE;
	}

	COleDateTime from (dateFrom);
	COleDateTime to (dateTo);

	COleDateTime duration = to - from;

	CTimeInterval* pInterval = new CTimeInterval;

	pInterval->m_From = COleDateTime (m_iYear, m_iMonth, m_iDay, 
									from.GetHour (), from.GetMinute (), 0);
	pInterval->m_To = pInterval->m_From + duration;
	pInterval->m_iStatus = iStatus;

	OVERLAPPING_TYPE type;
	if (GetIntervalOverlapped (pInterval, type) != NULL)
	{
		delete pInterval;
		return FALSE;
	}

	int iIndex = InsertTimeInterval (pInterval);

	CRect rect;
	GetIntervalRect (pInterval, rect);

	InvalidateControl (rect);
	UpdateWindow ();

//	FireOnAddInterval (iIndex, pInterval->m_From, pInterval->m_To);
	return TRUE;
}
//****************************************************************************************
BOOL CBCGTimeIntervalsCtrl::ChangeInterval(short index, DATE dateFrom, DATE dateTo, short iStatus) 
{
	POSITION pos = m_Intervals.FindIndex (index);
	if (pos == NULL)
	{
		return FALSE;
	}

	CTimeInterval* pOldInterval = (CTimeInterval*) m_Intervals.GetAt (pos);
	ASSERT (pOldInterval != NULL);

	CTimeInterval savedInterval (*pOldInterval);
	if (!RemoveTimeInterval (pOldInterval))
	{
		return FALSE;
	}

	if (!AddInterval (dateFrom, dateTo, iStatus))
	{
		// Restore old...
		AddInterval (savedInterval.m_From, savedInterval.m_To, savedInterval.m_iStatus);
		return FALSE;
	}

	return TRUE;
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::OnIntervalColorChanged() 
{
	HBRUSH hbr = (HBRUSH) m_brIntervalBrush.Detach ();

	if (hbr != NULL)
	{
		::DeleteObject (hbr);
	}

	m_brIntervalBrush.CreateSolidBrush (TranslateColor (m_intervalColor));

	if (GetSafeHwnd () != NULL)
	{
		InvalidateControl ();
	}

	SetModifiedFlag();
}
//****************************************************************************************
short CBCGTimeIntervalsCtrl::GetCurSel() 
{
	if (m_pSelectedInterval == NULL)
	{
		return -1;
	}

	short index = 0;
	for (POSITION pos = m_Intervals.GetHeadPosition (); pos != NULL; index ++)
	{
		CTimeInterval* pTI = (CTimeInterval*) m_Intervals.GetNext (pos);
		ASSERT (pTI != NULL);

		if (pTI == m_pSelectedInterval)
		{
			return index;
		}
	}

	return -1;
}
//****************************************************************************************
BOOL CBCGTimeIntervalsCtrl::SetCurSel(short index) 
{
	POSITION pos = m_Intervals.FindIndex (index);
	if (pos == NULL)
	{
		return FALSE;
	}

	CTimeInterval* pInterval = (CTimeInterval*) m_Intervals.GetAt (pos);
	ASSERT (pInterval != NULL);

	ChangeSelection (pInterval);
	return TRUE;
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::OnIntervalTextColorChanged() 
{
	if (GetSafeHwnd () != NULL)
	{
		InvalidateControl ();
	}

	SetModifiedFlag();
}
//****************************************************************************************
BOOL CBCGTimeIntervalsCtrl::MoveSelectedInterval (
			int iDeltaMinutes,
			BOOL bShift,
			CBCGTimeIntervalsCtrl::MOVE_TYPE moveType)
{
	CTimeInterval* pTI = (m_multiplySelection) ? 
		m_pSelectedInterval :
		(CTimeInterval*) m_Intervals.GetHead ();
	
	if (pTI == NULL)
	{
		return FALSE;
	}

	//--------------------------------
	// Remember old time and location:
	//--------------------------------
	CTimeInterval savedInterval (*pTI);
	COleDateTime duration = pTI->m_To - pTI->m_From;

	CRect rectOld;
	GetIntervalRect (pTI, rectOld);

	//-----------------------
	// Calculate time offset:
	//-----------------------
	switch (moveType)
	{
	case MOVE_TO_TOP:
		pTI->m_From = COleDateTime (m_iYear, m_iMonth, m_iDay, 0, 0, 0);
		if (!bShift)
		{
			pTI->m_To = pTI->m_From + duration;
		}
		break;

	case MOVE_TO_BOTTOM:
		pTI->m_To = COleDateTime (m_iYear, m_iMonth, m_iDay, 23, 59, 0) + minute;
		if (!bShift)
		{
			pTI->m_From = pTI->m_To - duration;
		}
		break;

	case RELATIVE_MOVE:
		{
			COleDateTimeSpan delta (0, iDeltaMinutes / iMinutesInHour,
									iDeltaMinutes % iMinutesInHour, 0);

			if (!bShift)
			{
				pTI->m_From += delta;
			}

			pTI->m_To += delta;
		}
		break;
	}

	//------------------------------
	// Check for the day boundaries:
	//------------------------------
	if (pTI->m_To - pTI->m_From < COleDateTimeSpan (0, iMinuteAlignment / iMinutesInHour, iMinuteAlignment % iMinutesInHour, 0) ||
		pTI->m_From.GetDay () != m_iDay ||
		(pTI->m_To.GetDay () != m_iDay && (pTI->m_To.GetHour () != 0 || pTI->m_To.GetMinute () != 0)))
	{
		*pTI = savedInterval;
		return FALSE;
	}

	//-----------------------
	// Check for overlapping:
	//-----------------------
	OVERLAPPING_TYPE type;
	if (GetIntervalOverlapped (pTI, type) != NULL)
	{
		*pTI = savedInterval;
		return FALSE;
	}

	//---------------
	// Update screen:
	//---------------
	CRect rectNew;
	GetIntervalRect (pTI, rectNew);

	if (rectOld != rectNew)
	{
		InvalidateControl (rectOld);
		InvalidateControl (rectNew);

		UpdateWindow ();
	}

	int iIndex = ChangeTimeInterval (pTI);
	if (savedInterval != *pTI)
	{
		FireOnChangeInterval (iIndex, pTI->m_From, pTI->m_To);
	}

	return TRUE;
}
//****************************************************************************************
BOOL CBCGTimeIntervalsCtrl::DeleteSelectedInterval ()
{
	CTimeInterval* pTI = (m_multiplySelection) ? 
		m_pSelectedInterval :
		(CTimeInterval*) m_Intervals.GetHead ();
	
	if (pTI == NULL)
	{
		return FALSE;
	}

	COleDateTime from = pTI->m_From;
	COleDateTime to = pTI->m_To;

	if (!RemoveTimeInterval (pTI))
	{
		return FALSE;
	}

	FireOnRemoveInterval (from, to);
	return TRUE;
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::BuildTooltipText (const CTimeInterval* pInterval, BOOL bShowTime,
						CString& strText) const
{
	ASSERT (pInterval != NULL);

	strText = _T("");

	if (bShowTime)
	{
		strText.Format (_T("%s - %s\n"),
			pInterval->m_From.Format (m_strTimeTooltipFormat),
			pInterval->m_To.Format (m_strTimeTooltipFormat));
	}

	COleDateTimeSpan duration = pInterval->m_To - pInterval->m_From;
	if (duration.GetSeconds () > 30)
	{
		duration += minute;
	}

	int iHours = duration.GetHours ();
	int iMinutes = duration.GetMinutes ();
	int iDays = duration.GetDays ();

	if (iHours == 0 && iMinutes == 0 && iDays == 1)
	{
		iHours = iHoursInDay;
	}

	CString strTmp;
	if (iHours != 0)
	{
		strTmp.Format (_T("%d h"), iHours);
		strText += strTmp;
	}

	if (iMinutes != 0)
	{
		strTmp.Format (_T(" %d m"), iMinutes);
		strText += strTmp;
	}
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::CancelCurrentMode ()
{
	//---------------------------------------------
	// Cancel all current actions such as tooltips,
	// timers, e.t.c:
	//---------------------------------------------

	m_wndInfo.Hide ();
	m_rectTT.SetRectEmpty ();
	KillTimer (uiToolTipEventId);

	if (m_pNewInterval != NULL)
	{
		delete m_pNewInterval;
		m_pNewInterval = NULL;

		InvalidateControl ();
	}

	if (m_pDraggedInterval != NULL)
	{
		m_pDraggedInterval = NULL;
	}

	if (m_mergingIsAllowed)
	{
		KillTimer (uiMergeEventId);
		m_pFirstMergedInterval = NULL;
		m_pSecondMergedInterval = NULL;
	}

	m_CurrDragMode = NONE;
	ChangeCursor (NONE);
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::OnBackgroundColorChanged() 
{
	if (GetSafeHwnd () != NULL)
	{
		InvalidateControl ();
	}

	SetModifiedFlag();
}
//****************************************************************************************
void CBCGTimeIntervalsCtrl::OnForegroundColorChanged() 
{
	if (GetSafeHwnd () != NULL)
	{
		InvalidateControl ();
	}

	SetModifiedFlag();
}
//************************************************************************************
BOOL CBCGTimeIntervalsCtrl::SetIntervalStatus(short iIndex, short iStatus) 
{
	POSITION pos = m_Intervals.FindIndex (iIndex);
	if (pos == NULL)
	{
		return FALSE;
	}

	CTimeInterval* pInterval = (CTimeInterval*) m_Intervals.GetAt (pos);
	ASSERT (pInterval != NULL);

	pInterval->m_iStatus = iStatus;
	return TRUE;
}
//************************************************************************************
void CBCGTimeIntervalsCtrl::SetStatusColor(short iStatus, OLE_COLOR color) 
{
	HBRUSH hbrStatus;

	if (m_IntervalBrushes.Lookup (iStatus, hbrStatus))
	{
		::DeleteObject (hbrStatus);
	}

	hbrStatus = ::CreateSolidBrush (TranslateColor (color));
	ASSERT (hbrStatus != NULL);

	m_IntervalBrushes.SetAt (iStatus, hbrStatus);
}
