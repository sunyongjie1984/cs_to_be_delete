// DriveSpace.cpp : implementation file
//

#include "stdafx.h"
#include "DriveSpace.h"
#include <dos.h>
#include <direct.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDriveSpace

CDriveSpace::CDriveSpace()
{
    // Create font
    CreateTextFont();

    // Fill data members
    m_nDriveNum = 3;
    m_color = RGB(0, 0, 255);
    UpdateDriveData();
}

CDriveSpace::CDriveSpace(int n, COLORREF c)
{
    // Create font
    CreateTextFont();

    // Fill data members
    m_nDriveNum = n;
    m_color = c;
    UpdateDriveData();
}

CDriveSpace::~CDriveSpace()
{
}


BEGIN_MESSAGE_MAP(CDriveSpace, CStatic)
	//{{AFX_MSG_MAP(CDriveSpace)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CDriveSpace::CreateTextFont()
{
    // Create font
    m_font.CreateFont(8, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
        OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY,
        DEFAULT_PITCH | FF_DONTCARE, _T("MS Sans Serif"));
}

void CDriveSpace::UpdateDriveData()
{
    // Get total & free drive space
    struct _diskfree_t diskfree;
    if (_getdiskfree(m_nDriveNum, &diskfree) == 0)
	{
        m_fTotalSpace = (float) (diskfree.total_clusters *
                                 diskfree.sectors_per_cluster *
                                 diskfree.bytes_per_sector /
                                 1024.0 / 1024.0);

        m_fFreeSpace  = (float) (diskfree.avail_clusters *
            		             diskfree.sectors_per_cluster *
			                     diskfree.bytes_per_sector / 
                                 1024.0 / 1024.0);
        
        m_nPercentFree = (int) ((diskfree.avail_clusters * 100) /
                                 diskfree.total_clusters);
    }
    else
    {
        m_fFreeSpace = (float) 0.0;
    }

    // If the windows object exists, repaint
    if (m_hWnd)
    {
        Invalidate();
    }
}

/////////////////////////////////////////////////////////////////////////////
// CDriveSpace message handlers
void CDriveSpace::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

    CRect rect;
    GetWindowRect(&rect);
    ScreenToClient(&rect);

    // Set transparent mode
    int nOldBkMode = dc.SetBkMode(TRANSPARENT);

    // Draw border--this function should resize rect not to include border!
    DrawBorder(&dc, &rect);

    // Fill the gauge
    FillGauge(&dc, &rect);

    // Draw tics
    DrawTics(&dc, &rect);

    // Draw "free" text
    DrawFreeText(&dc, &rect);

    // Clean up
    dc.SetBkMode(nOldBkMode);
}

void CDriveSpace::DrawBorder(CPaintDC* pDc, CRect* pRect)
{
    // Get pens
    CPen p1(PS_SOLID, 1, ::GetSysColor(COLOR_BTNHILIGHT)),
         p2(PS_SOLID, 1, ::GetSysColor(COLOR_BTNSHADOW)),
         *pOldPen;

    // Get a null brush and select it into the dc
    CBrush* pOldBrush = (CBrush*) pDc->
        SelectObject(::GetStockObject(NULL_BRUSH));

    // Draw the raised border
    pOldPen = (CPen*) pDc->SelectObject(&p1);
    pDc->Rectangle(pRect);

    pDc->SelectObject(&p2);
    pDc->MoveTo(pRect->left + 1, pRect->bottom - 2);
    pDc->LineTo(pRect->left + 1, pRect->top + 1);
    pDc->LineTo(pRect->right - 1, pRect->top + 1);

    pDc->MoveTo(pRect->left, pRect->bottom);
    pDc->LineTo(pRect->right, pRect->bottom);
    pDc->LineTo(pRect->right, pRect->top);

    // Clean up
    pDc->SelectObject(pOldPen);
}

void CDriveSpace::FillGauge(CPaintDC* pDc, CRect* pRect)
{
    pRect->InflateRect(-2, -2);
    CBrush b1(::GetSysColor(COLOR_BTNFACE)),
           b2(m_color);

    int nHeight = (int) ((100.0 - (float) m_nPercentFree) / 
        (100.0 / (float) pRect->Height()));

    pDc->FillRect(CRect(pRect->left, pRect->top, pRect->right + 1, 
        pRect->top + nHeight - 1), &b1);
    pDc->FillRect(CRect(pRect->left, pRect->top + nHeight,
        pRect->right + 1, pRect->bottom + 1), &b2);

    pRect->InflateRect(2, 2);
}

void CDriveSpace::DrawTics(CPaintDC* pDc, CRect* pRect)
{
    // Get pens
    CPen p1(PS_SOLID, 1, ::GetSysColor(COLOR_BTNHILIGHT)),
         p2(PS_SOLID, 1, ::GetSysColor(COLOR_BTNSHADOW)),
         *pOldPen;

    pOldPen = (CPen*) pDc->SelectObject(&p1);

    // Draw tics at 75, 50, & 25%
    pDc->MoveTo(pRect->left + 2,  pRect->top + (pRect->Height() / 4));
    pDc->LineTo(pRect->left + 4,  pRect->top + (pRect->Height() / 4));
    pDc->MoveTo(pRect->right - 2, pRect->top + (pRect->Height() / 4));
    pDc->LineTo(pRect->right - 4, pRect->top + (pRect->Height() / 4));

    pDc->MoveTo(pRect->left + 2,  pRect->top + (pRect->Height() / 2));
    pDc->LineTo(pRect->left + 6,  pRect->top + (pRect->Height() / 2));
    pDc->MoveTo(pRect->right - 2, pRect->top + (pRect->Height() / 2));
    pDc->LineTo(pRect->right - 6, pRect->top + (pRect->Height() / 2));

    pDc->MoveTo(pRect->left + 2,  pRect->top + 3 * (pRect->Height() / 4));
    pDc->LineTo(pRect->left + 4,  pRect->top + 3 * (pRect->Height() / 4));
    pDc->MoveTo(pRect->right - 2, pRect->top + 3 * (pRect->Height() / 4));
    pDc->LineTo(pRect->right - 4, pRect->top + 3 * (pRect->Height() / 4));

    pDc->SelectObject(&p2);
    pDc->MoveTo(pRect->left + 2,  pRect->top + (pRect->Height() / 4) + 1);
    pDc->LineTo(pRect->left + 4,  pRect->top + (pRect->Height() / 4) + 1);
    pDc->MoveTo(pRect->right - 2, pRect->top + (pRect->Height() / 4) + 1);
    pDc->LineTo(pRect->right - 4, pRect->top + (pRect->Height() / 4) + 1);

    pDc->MoveTo(pRect->left + 2,  pRect->top + (pRect->Height() / 2) + 1);
    pDc->LineTo(pRect->left + 6,  pRect->top + (pRect->Height() / 2) + 1);
    pDc->MoveTo(pRect->right - 2, pRect->top + (pRect->Height() / 2) + 1);
    pDc->LineTo(pRect->right - 6, pRect->top + (pRect->Height() / 2) + 1);

    pDc->MoveTo(pRect->left + 2,  pRect->top + 3 * (pRect->Height() / 4) + 1);
    pDc->LineTo(pRect->left + 4,  pRect->top + 3 * (pRect->Height() / 4) + 1);
    pDc->MoveTo(pRect->right - 2, pRect->top + 3 * (pRect->Height() / 4) + 1);
    pDc->LineTo(pRect->right - 4, pRect->top + 3 * (pRect->Height() / 4) + 1);

    // Clean up
    pDc->SelectObject(pOldPen);
}

void CDriveSpace::DrawFreeText(CPaintDC* pDc, CRect* pRect)
{
    // Get font
    CFont* pOldFont = (CFont*) pDc->SelectObject(&m_font);

    // Format text and draw it
    CString str;
    CSize size;

    str.Format("%c:", m_nDriveNum  - 1 + _T('A'));
    size = pDc->GetTextExtent(str);
    if (pRect->top + 3 + size.cy < pRect->bottom - 1)
    {
        if (size.cx < pRect->Width())
        {
            pDc->TextOut(pRect->left + ((pRect->Width() - size.cx) / 2),
                pRect->top + 3, str);
        }
        int n = 6 + size.cy;

        str.Format("%0.1f MB", m_fFreeSpace);
        size = pDc->GetTextExtent(str);
        if (pRect->top + n + size.cy < pRect->bottom - 1)
        {
            if (size.cx < pRect->Width())
            {
                pDc->TextOut(pRect->left + ((pRect->Width() - size.cx) / 2),
                    pRect->top + n, str);
            }
            n +=  3 + size.cy;

            str.Format("%d%%", m_nPercentFree);
            size = pDc->GetTextExtent(str);
            if (pRect->top + n + size.cy < pRect->bottom - 1)
            {
                if (size.cx < pRect->Width())
                {
                    pDc->TextOut(pRect->left + ((pRect->Width() - size.cx) / 2), 
                        pRect->top + n, str);
                }
            }
        }
    }
    pDc->SelectObject(pOldFont);
}
