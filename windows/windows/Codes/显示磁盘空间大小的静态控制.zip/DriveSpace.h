// DriveSpace.h : header file
//

#ifndef _INC_DRIVESPACE
#define _INC_DRIVESPACE

// CDriveSpace
// Written 1996 by Rob Warner
// rhwarner@southeast.net
// http://users.southeast.net/~rhwarner
// Distribute freely, modify to your heart's content <g>
// Let me know if you find it useful, or if you've improved it <vbg>

/////////////////////////////////////////////////////////////////////////////
// CDriveSpace window

class CDriveSpace : public CStatic
{
// Construction
public:
    CDriveSpace();
    CDriveSpace(int, COLORREF c = RGB(255, 255, 0));
	void UpdateDriveData();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDriveSpace)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDriveSpace();
    void SetDriveNum(int n)   { m_nDriveNum = n; UpdateDriveData(); }
    void SetColor(COLORREF c) { m_color = c; }

	// Generated message map functions
protected:
	COLORREF m_color;
	virtual void CreateTextFont();
	virtual void DrawFreeText(CPaintDC*, CRect*);
	virtual void DrawTics(CPaintDC*, CRect*);
	virtual void FillGauge(CPaintDC*, CRect*);
	virtual void DrawBorder(CPaintDC*, CRect*);
	CFont m_font;
	float m_fTotalSpace, m_fFreeSpace;
    int m_nPercentFree, m_nDriveNum;
	//{{AFX_MSG(CDriveSpace)
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif