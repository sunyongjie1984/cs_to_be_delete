//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mymenu.rc
//
#define IDM_SYSMENU_ABOUT               16
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MYMENUTYPE                  129
#define IDR_RIGHT_CLICK                 130
#define IDR_MYTYPE                      131
#define IDR_CUSTOMMENU                  132
#define IDI_ICON1                       133
#define IDB_NET                         133
#define IDI_ICON2                       134
#define IDB_BITMAP1                     137
#define IDB_BITMAP2                     138
#define IDB_FILE_SAVE                   138
#define IDB_BITMAP3                     139
#define IDB_BITMAP4                     141
#define IDB_CHECKS                      141
#define IDB_BITMAP5                     142
#define IDB_CHECKU                      142
#define IDB_BLANK                       144
#define IDB_BITMAP6                     145
#define IDB_BITMAP7                     146
#define IDB_BITMAP8                     147
#define IDB_FILE_NEW                    148
#define IDB_FILE_OPEN                   149
#define IDB_EDIT_CUT                    150
#define IDB_EDIT_COPY                   151
#define IDB_EDIT_PASTE                  152
#define IDB_WINDOW_NEW                  153
#define IDB_ZOOM                        154
#define IDB_FILE_PRINT                  155
#define IDB_APP_ABOUT                   156
#define IDB_WINDOW_TILE                 157
#define IDR_TOOLBAR                     158
#define IDR_JUNK                        160
#define ID_ZOOM                         32771
#define ID_WINDOW_NEW2                  32777
#define ID_DEFAULT                      32778
#define ID_HOMEPAGE                     32779
#define ID_JUNK                         32781
#define ID_DISABLE                      32783
#define ID_ENABLE                       32784
#define ID_ADD_MENU_OPTIONS             32785
#define ID_REMOVE_ZOOM                  32786
#define ID_MENU2                        32787
#define ID_NET                          32788
#define ID_ZOOMS                        32789
#define ID_NEW                          32790
#define ID_TILE                         32791
#define ID_NEW_DOC_TEMPLATE             32795

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        161
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
