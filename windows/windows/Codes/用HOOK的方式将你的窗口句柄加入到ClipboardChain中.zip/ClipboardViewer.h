#pragma once
#include "Subclass.h"
/////////////////////////////////////////////////////////////////////////////
// CClipboardViewer class version 1.01
//		is antithesis to copy-paste programming style.
//
// version history
//		1.01 : changed a little
//		1.00 : released
//					written by MB <mb2@geocities.co.jp> December 15, 1999
/////////////////////////////////////////////////////////////////////////////
class CClipboardViewer : public CSubclassWnd  
{
// Constructions
public:
	CClipboardViewer();

// Operations
	void Install(CWnd*, AFX_PMSGW pfnOnUpdate, BOOL bInitialUpdate = FALSE);
	void UnInstall();

// Overrides
protected:
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);

// Implementation
public:
	virtual ~CClipboardViewer();

protected:
	AFX_PMSGW	m_pfnOnUpdate;
	HWND		m_hWndNext;
	BOOL		m_bFirst;
	BOOL		m_bInitialUpdate;

	// Implementation helpers
	void OnDrawClipboard();
	void OnChangeCbChain(HWND hWndRemove, HWND hWndAfter);
	void OnDestroy();
};
//////////////////////////////////////////////////////////////////////
