// CClipboardViewer : version 1.01
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ClipboardViewer.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#ifdef _DEBUG
const BOOL bTraceOn = FALSE;
#define LTRACE if (bTraceOn) TRACE
#else
#define LTRACE
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
CClipboardViewer::CClipboardViewer()
{
	m_hWndNext			= NULL;
	m_bFirst			= TRUE;
	m_bInitialUpdate	= FALSE;
	m_pfnOnUpdate		= NULL;
}

CClipboardViewer::~CClipboardViewer()
{
}

void CClipboardViewer::Install(CWnd* pWnd, AFX_PMSGW pfnOnUpdate, BOOL bInitialUpdate)
{
	m_bInitialUpdate = bInitialUpdate;
	m_pfnOnUpdate = pfnOnUpdate;
	HookWindow(pWnd);// install message hook
	m_hWndNext = pWnd->SetClipboardViewer();// WM_DRAWCLIPBOARD sent
}

void CClipboardViewer::UnInstall()
{
	m_hWndNext			= NULL;
	m_bFirst			= TRUE;
	m_bInitialUpdate	= FALSE;
	m_pfnOnUpdate		= NULL;
	::ChangeClipboardChain(m_hWnd, m_hWndNext);
	Unhook();
}
//////////////////////////////////////////////////////////////////////
// CClipboardViewer message handlers
LRESULT CClipboardViewer::WindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) {
	case WM_DRAWCLIPBOARD:
		OnDrawClipboard();
		break;
	case WM_CHANGECBCHAIN:
		OnChangeCbChain((HWND)wParam, (HWND)lParam);
		break;
	case WM_DESTROY:
		CSubclassWnd::WindowProc(message, wParam, lParam);// be care
		OnDestroy();
		return 0;
	}

	return CSubclassWnd::WindowProc(message, wParam, lParam);
}

void CClipboardViewer::OnDrawClipboard()
{
	LTRACE(_T("CClipboardViewer::OnDrawClipboard\n"));
	ASSERT(m_pfnOnUpdate != NULL);
	CWnd* pWndHooked = CWnd::FromHandle(m_hWnd);

	if (m_bFirst) {				// first time
		LTRACE(_T("    this is first time\n"));
		if (m_bInitialUpdate) {	// callback
			LTRACE(_T("    initial update\n"));
			(pWndHooked->*m_pfnOnUpdate)();
			m_bInitialUpdate = FALSE;
		}
		m_bFirst = FALSE;
	}
	else {
		(pWndHooked->*m_pfnOnUpdate)();
	}

	if (m_hWndNext)
		::PostMessage(m_hWndNext, WM_DRAWCLIPBOARD, 0, 0);//!!Post!?
}

void CClipboardViewer::OnChangeCbChain(HWND hWndRemove, HWND hWndAfter)
{
	LTRACE(_T("CClipboardViewer::OnChangeCbChain\n"));
	if (m_hWndNext == hWndRemove)
		m_hWndNext = hWndAfter;
	else if (m_hWndNext != NULL)// SendMessage if I'm not last
		::SendMessage(m_hWndNext, WM_CHANGECBCHAIN, (WPARAM)hWndRemove, (LPARAM)hWndAfter);
}

void CClipboardViewer::OnDestroy()
{
	LTRACE(_T("CClipboardViewer::OnDestroy\n"));
	UnInstall();
}
