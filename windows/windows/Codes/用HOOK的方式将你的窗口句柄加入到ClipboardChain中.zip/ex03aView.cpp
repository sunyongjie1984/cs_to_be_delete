// ex03aView.cpp : implementation of the CEx03aView class
//

#include "stdafx.h"
#include "ex03a.h"

#include "ex03aDoc.h"
#include "ex03aView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEx03aView

IMPLEMENT_DYNCREATE(CEx03aView, CView)

BEGIN_MESSAGE_MAP(CEx03aView, CView)
	//{{AFX_MSG_MAP(CEx03aView)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEx03aView construction/destruction

CEx03aView::CEx03aView()
{
	// TODO: add construction code here
	m_crText = RGB(255, 0, 0);
}

CEx03aView::~CEx03aView()
{
}

BOOL CEx03aView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CEx03aView drawing

void CEx03aView::OnDraw(CDC* pDC)
{
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(m_crText);
	pDC->TextOut(0, 0, _T("clipboard updated!"));
}

/////////////////////////////////////////////////////////////////////////////
// CEx03aView printing

BOOL CEx03aView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CEx03aView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CEx03aView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CEx03aView diagnostics

#ifdef _DEBUG
void CEx03aView::AssertValid() const
{
	CView::AssertValid();
}

void CEx03aView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CEx03aDoc* CEx03aView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CEx03aDoc)));
	return (CEx03aDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CEx03aView message handlers

int CEx03aView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_clpViewer.Install(this, (AFX_PMSGW)OnUpdateClipboard);
	
	return 0;
}

void CEx03aView::OnUpdateClipboard()
{
	TRACE("CEx03aView::OnUpdateClipboard\n");
	srand((unsigned)time(NULL));
	int r = rand()%255;
	int g = rand()%255;
	int b = rand()%255;
	m_crText = RGB(r, g, b);
	Invalidate();
}