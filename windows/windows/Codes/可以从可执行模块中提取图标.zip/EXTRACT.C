// EXTRACT.C
// Stefano Maruzzi 1996

// LIST09-08
// Extracting icons from an executable module


#define STRICT
// include files
#include <windows.h>
#include <shellapi.h>
#include <win32bk.h>
#include <string.h>
#include "resource.h"


// function prototypes
LRESULT WINAPI ClientWndProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) ;
BOOL DrawBitmap( HDC hdc, HBITMAP hbm, int x, int y, int cx, int cy) ;


int WINAPI WinMain(	HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					LPSTR lpszCmdLine,
					int nCmdShow)
{
	HWND hwnd ;
	MSG msg ;
	char szClassName[ 20] ;
	char szWindowTitle[ 20] ;
	WNDCLASSEX wcex ;

	// loading the class name
	LoadString( hInstance, ST_CLASSNAME, szClassName, sizeof( szClassName)) ;
	// loading the window title
	LoadString( hInstance, ST_WINDOWTITLE, szWindowTitle, sizeof( szWindowTitle)) ;

	// registering the main class
	wcex.cbSize = sizeof( WNDCLASSEX) ;
	wcex.style = CS_VREDRAW | CS_HREDRAW ;
	wcex.lpfnWndProc = ClientWndProc ;
	wcex.cbClsExtra	= 0 ;
	wcex.cbWndExtra	= 0 ;
	wcex.hInstance = hInstance ;
	wcex.hIcon = LoadIcon( hInstance, "extract") ;
	wcex.hIconSm = LoadIcon( hInstance, "extract") ;
	wcex.hCursor = LoadCursor( NULL, IDC_ARROW) ;
	wcex.hbrBackground = GetStockObject( WHITE_BRUSH) ;
	wcex.lpszMenuName = NULL ;
	wcex.lpszClassName = szClassName ;

	if( !RegisterClassEx( &wcex))
	{
		MessageBeep( 0) ;
		return FALSE ;
	}

	// creating the main window
	hwnd = CreateWindowEx(	WS_EX_CLIENTEDGE | WS_EX_WINDOWEDGE,
							szClassName,
							szWindowTitle,
							WS_OVERLAPPEDWINDOW,
							CW_USEDEFAULT, 0,
							CW_USEDEFAULT, 0,
							NULL,
							LoadMenu( hInstance, "mainmenu"),
							hInstance,
							NULL) ;

	ShowWindow( hwnd, SW_SHOWNORMAL) ;

	// message loop
	while( GetMessage(	&msg, NULL, 0, 0))
	{
		TranslateMessage( &msg) ;
		DispatchMessage( &msg) ;
	}

	return FALSE ;
}

LRESULT WINAPI ClientWndProc(	HWND hwnd,
								UINT msg,
								WPARAM wParam,
								LPARAM lParam)
{
	static HINSTANCE hInstance ;
	static UINT cx ;
	static HLOCAL hmem ;
	static PHANDLE pmem ;
	static int nIcons, iIcon ;
	static char szFileName[ 260] ;

	switch( msg)
	{
		case WM_CREATE:
		{
			HMENU hpopup ;
			MENUITEMINFO mii ;

			// loading the popup menu
			hpopup = LoadMenu( hInstance, "popup") ;
			hpopup = GetSubMenu( hpopup, 0) ;
			// set the MFS_OWNERDRAW flag
			mii.cbSize = sizeof( mii) ;
			mii.fMask = MIIM_TYPE ;
			mii.fType = MFT_OWNERDRAW ;
			SetMenuItemInfo( hpopup, MN_COPY, FALSE, &mii) ;

			// store the popup menu in the GWL_USERDATA area
			SetWindowLong( hwnd, GWL_USERDATA, (long)hpopup) ;

			hInstance = ((LPCREATESTRUCT)lParam) -> hInstance ; 

			pmem = VirtualAlloc( NULL, 4096 * 10, MEM_RESERVE, PAGE_READWRITE) ;			      
		}			
			break ;

		case WM_COMMAND:
			switch( LOWORD( wParam))
			{
				case MN_COPY:
				{
					HBITMAP hbmpold, hbmpnew ;
					HDC hdc ;
					HICON hicon ;
					ICONINFO ii ;

					HDC hdcdst, hdcsrc ;

					if( !OpenClipboard( hwnd))
						break ;

					EmptyClipboard() ;

					// load the selected icon
					hicon = ExtractIcon( hInstance, szFileName, iIcon) ;
					GetIconInfo( hicon, &ii) ;
					 
					hdc = GetDC( hwnd) ;
		            hdcdst = CreateCompatibleDC( hdc) ;
		            hdcsrc = CreateCompatibleDC( hdc) ;
             		hbmpold = SelectObject( hdcdst, ii.hbmColor) ;
				    hbmpold = SelectObject( hdcsrc, ii.hbmMask) ;

            		BitBlt( hdcdst, 0, 0, SYS( SM_CXICON), SYS( SM_CYICON), hdcsrc, 0, 0, SRCPAINT);
					
					// retrieve the new bitmap
					hbmpnew = SelectObject( hdcdst, hbmpold) ;
					
					// pass the bitmap to the Clipboard
					SetClipboardData( CF_BITMAP, hbmpnew) ;
					// close the Clipboard
					CloseClipboard() ;
					
					DrawBitmap( hdc, hbmpnew, 0, 0, SYS( SM_CXICON), SYS( SM_CYICON)) ;
				    ReleaseDC( hwnd, hdc) ;
		            DeleteDC( hdcsrc) ;
		            DeleteDC( hdcdst) ;
				}
					break ;

				case MN_OPEN:
				{
					OPENFILENAME ofn ;
					int i = 0 ;
					HICON hicon ;
					char szText[ 100] ;
					char szFilter[] = "Executables (*.EXE)\0*.EXE\0DLLs (*.DLL)\0*.DLL\0" ;
					char szFile[ 200] = { '\0'} ;
					char szFileTitle[ 100] = { '\0'} ;

					// reset the nIcons counter to 0
					nIcons = 0 ;

				    ofn.lStructSize = sizeof( OPENFILENAME) ;
				    ofn.hwndOwner = hwnd ;
				    ofn.lpstrFilter = szFilter ;
				    ofn.lpstrCustomFilter = NULL ;
				    ofn.nMaxCustFilter = 0 ;
				    ofn.nFilterIndex = 1L ;
				    ofn.lpstrFile= szFile ;
				    ofn.nMaxFile = sizeof( szFile) ;
				    ofn.lpstrFileTitle = szFileTitle ;
				    ofn.nMaxFileTitle = sizeof( szFileTitle) ;
				    ofn.lpstrInitialDir = NULL ;
				    ofn.lpstrTitle = (LPSTR) NULL ;
				    ofn.Flags = OFN_SHOWHELP | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
				    ofn.nFileOffset = 0 ;
				    ofn.nFileExtension = 0 ;
				    ofn.lCustData = 0 ;
				    ofn.lpstrDefExt = "*.EXE" ;

				    if( !GetOpenFileName( &ofn))
				    {
				    	break ;
				    }
					// erase the client area background
					InvalidateRect( hwnd, NULL, TRUE) ;
					UpdateWindow( hwnd) ;

					// release delle pagine del blocco
					VirtualFree( pmem, 4096 * 10, MEM_DECOMMIT) ;

					// determing the number of icons stored in that file
					nIcons = (UINT)ExtractIcon( hInstance, ofn.lpstrFileTitle, (UINT)-1) ;

					// allocating some pages to store all the icons
					VirtualAlloc( pmem, sizeof( HICON) * nIcons, MEM_COMMIT, PAGE_READWRITE) ;			      
			        
					// change the app title
					wsprintf( szText, "Extractor %u", nIcons) ;
					SetWindowText( hwnd, szText) ;
					
					// copy the file name
					strcpy( szFileName, ofn.lpstrFileTitle) ;			           
					
					// extracting the icons
					while( i < nIcons)
					{
						hicon = ExtractIcon( hInstance, ofn.lpstrFileTitle, i) ;  
						*( pmem + i++) = hicon ;
					}     
						                    
					// aggiornare l'output
					InvalidateRect( hwnd, NULL, FALSE) ;
					UpdateWindow( hwnd) ;
				}
					break ;

				case MN_EXIT:
				{
					PostQuitMessage( 0) ;
				}
					break ;
			}
			break ;

		case WM_SIZE:
			cx = LOWORD( lParam) / SYS( SM_CXICON) * SYS( SM_CXICON) ; 
			break ;

		case WM_CONTEXTMENU:
		{
			HMENU hpopup ;
			int j = 0 ;
			POINT pt ;
			int x, y, iPos ;

			// lets skip it if there is no icon
			if( !nIcons)
				break ;

			// storing the mouse position on the client area
			pt.x = MAKEPOINTS( lParam).x ;
			pt.y = MAKEPOINTS( lParam).y ;
			// convert the point in client coordinates
			ScreenToClient( hwnd, &pt) ;

			x = pt.x / SYS( SM_CXICON) ;
			y = pt.y / SYS( SM_CYICON) ;

			iPos = iIcon = y * cx / SYS( SM_CXICON) + x ;

			// skip it if we clicked in a blank location
			if( iPos >= nIcons)
				break ;

			// retrieve the popup menu handle
			hpopup = (HMENU)GetWindowLong( hwnd, GWL_USERDATA) ;

			TrackPopupMenu(	hpopup,
							TPM_TOPALIGN,
							LOWORD( lParam),
							HIWORD( lParam),
							0,
							hwnd,
							NULL) ;
		}
			break ;

		case WM_DRAWITEM:
		{
			LPDRAWITEMSTRUCT lpdis = (LPDRAWITEMSTRUCT)lParam ;
			HDC hdc ;
			RECT rc ;
			HICON hicon ;

			hdc = lpdis -> hDC ;
			rc = lpdis -> rcItem ;

			// load the selected icon
			hicon = ExtractIcon( hInstance, szFileName, iIcon) ;
			SetBkColor( hdc, GetSysColor( COLOR_HIGHLIGHT)) ;
			// display the background rectangle
			FillRect( hdc, &rc, CreateSolidBrush( GetSysColor( COLOR_HIGHLIGHT))) ; 

/*
			switch( lpdis -> itemState)
			{
				case ODS_SELECTED:
				{
					MessageBeep( 0) ;
					SelectObject( lpdis -> hDC, CreateSolidBrush( COLOR_HIGHLIGHT)) ;
					Rectangle( lpdis -> hDC, rc.left, rc.top, rc.right, rc.bottom) ;
				}
					break ;

			}
*/
			// display the icon
			DrawIconEx(	lpdis -> hDC,
						0, 0,
						hicon,
						SYS( SM_CXSMICON),
						SYS( SM_CYSMICON),
						0,
						NULL,
						DI_NORMAL) ;

			// set the text background and foreground colors
			//SetTextColor( hdc, GetSysColor( COLOR_HIGHLIGHTTEXT)) ;

			// display the text
			TextOut( lpdis -> hDC, SYS( SM_CXSMICON) + 2, 0, "Copy", 4) ;
		}
			return TRUE ;

		case WM_MEASUREITEM:
		{
			LPMEASUREITEMSTRUCT lpmi = (LPMEASUREITEMSTRUCT)lParam ;
			lpmi -> itemWidth = 80 ;
			lpmi -> itemHeight = SYS( SM_CYSMICON) + 2 ;
		}
			return TRUE ;

		case WM_PAINT:
		{
			HDC hdc ;
			PAINTSTRUCT ps ;
			UINT const l = SYS( SM_CXICON) ;
			UINT j = 0, i = 0, y = 0 ; 
			
			hdc = BeginPaint( hwnd, &ps) ;
			while( nIcons - j)
			{
				if( ( ( i + 1) * l) > cx)
				{
					y += SYS( SM_CYICON) ;
					i = 0 ;
				}
				DrawIconEx(	hdc,
							i * l,
							y,
							(HICON)*( pmem + j),
							SYS( SM_CXICON),
							SYS( SM_CYICON),
							0,
							NULL, //GetStockObject( HOLLOW_BRUSH),
							DI_NORMAL) ;  
				j++ ;      
				i++ ;
			}
			EndPaint( hwnd, &ps) ;
		}
			break ;

		case WM_CLOSE:              
			// distruzione del blocco di memoria
			VirtualFree( pmem, 0, MEM_RELEASE) ;
		                       
			// terminare l'applicazione		                       
			PostMessage( hwnd, WM_QUIT, 0, 0L) ;
			break ;

		default:
			break ;
	}
	return DefWindowProc( hwnd, msg, wParam, lParam) ;
}



BOOL DrawBitmap(	HDC hdc,
					HBITMAP hbm,
					int x,
					int y,
					int cx,
					int cy)
{
	HBITMAP hbmpOld ;
	BITMAP bm ;
	HDC hdcMem ;

	// dc compatibile
	hdcMem = CreateCompatibleDC( hdc) ;
	GetObject( hbm, sizeof( BITMAP), (LPSTR)&bm) ;

	hbmpOld = SelectObject( hdcMem, hbm) ;

	//BitBlt( hdc, x, y, cx, cy, hdcMem, 0, 0, SRCCOPY) ;
	StretchBlt( hdc, 100, 100, cx, cy, hdcMem, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY) ; 
	SelectObject( hdc, hbmpOld) ;
	return DeleteDC( hdcMem) ;
}
