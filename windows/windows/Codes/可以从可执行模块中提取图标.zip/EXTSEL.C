// EXTSEL.C
// STEFANO MARUZZI 1995

// LIST09-06
// owner-draw & extended sel listbox

#include <windows.h>
#include <windowsx.h>
#include <string.h>
#include <win32bk.h>
#include "resource.h"


#define CT_LIST	1
#define OFFSET 40
#define MAXSTRING	10


// function prototypes
int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow) ;
LRESULT WINAPI ClientWndProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void HandleSelState( LPDRAWITEMSTRUCT lpdis) ;
void DrawEntireItem( LPDRAWITEMSTRUCT lpdis) ;
void HandleFocusState( LPDRAWITEMSTRUCT lpdis) ;


int WINAPI WinMain(	HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					LPSTR lpszCmdLine,
					int nCmdShow)
{
	MSG msg ;
	HWND hwnd ;
	char szClassName[ 30] ;
	char szWindowTitle[ 30] ;
	WNDCLASSEX wc ;

	LoadString( hInstance, ST_CLASSNAME, szClassName, sizeof( szClassName)) ;
	LoadString( hInstance, ST_WINDOWTITLE, szWindowTitle, sizeof( szWindowTitle)) ;

	wc.cbSize = sizeof( wc) ;
	wc.style = CS_HREDRAW | CS_VREDRAW ;
	wc.lpfnWndProc = ClientWndProc ;
	wc.cbClsExtra = 0 ;
	wc.cbWndExtra = sizeof( HICON) * 2 ;
	wc.hInstance = hInstance ;
	wc.hIcon = LoadIcon( hInstance, szClassName) ;
	wc.hIconSm = LoadIcon( hInstance, szClassName) ;
	wc.hCursor = LoadCursor( NULL, IDC_ARROW) ;
	wc.hbrBackground = GetStockObject( WHITE_BRUSH) ;
	wc.lpszMenuName	= NULL ;
	wc.lpszClassName = szClassName ;

	if( ! RegisterClassEx( &wc))
		return FALSE ;

	hwnd = CreateWindowEx(	WS_EX_CLIENTEDGE | WS_EX_WINDOWEDGE,
							szClassName,
							szWindowTitle,
							WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
							CW_USEDEFAULT, 0,
							CW_USEDEFAULT, 0,
							NULL,
							LoadMenu( hInstance, "mainmenu"),
							hInstance,
							NULL) ;

	ShowWindow( hwnd, SW_SHOWNORMAL) ;

	while( GetMessage( &msg, NULL, 0, 0))
	{
		TranslateMessage( &msg) ;
		DispatchMessage( &msg) ;
	}

	return msg.wParam ;

}

LRESULT WINAPI ClientWndProc(	HWND hwnd,
								UINT msg,
								WPARAM wParam,
								LPARAM lParam)
{
	static HINSTANCE hInstance ;
	static HWND hwndList ;

	switch( msg)
	{
		case WM_CREATE:
		{
			HICON hicon ;
			WORD sPos, i ;
			char szString[ 70] ;

			hInstance = ((LPCREATESTRUCT)lParam) -> hInstance ;

			hicon = LoadIcon( hInstance, "one") ;
			// store the two hicon handles in the extra memory
			SetWindowLong( hwnd, 0, (long)hicon) ;
			hicon = LoadIcon( hInstance, "two") ;
			// store the two hicon handles in the extra memory
			SetWindowLong( hwnd, sizeof( HICON), (long)hicon) ;

			hwndList = CreateWindow(	"LISTBOX",
										NULL,
										WS_CHILD | LBS_STANDARD |
										LBS_HASSTRINGS | LBS_EXTENDEDSEL |
										LBS_OWNERDRAWFIXED | WS_VISIBLE |
										LBS_NOINTEGRALHEIGHT,
										0, 0, 0, 0,
										hwnd,
										(HMENU)CT_LIST,
										hInstance,
										NULL) ;

			// inserting MAXSTRING strings in the listbox
			for( i = 0; i < MAXSTRING; i++)
			{
				wsprintf( szString, "Drawer #%02d is open.", i) ;
				sPos = ListBox_AddString( hwndList, szString) ;
				ListBox_SetItemData( hwndList, sPos, (LPARAM)0) ;
			}
		}
			break ;

		case WM_SIZE:
		{
			SetWindowPos(	hwndList, HWND_TOP,
							0, 0,
							LOWORD( lParam) + 2,
							HIWORD( lParam) + 2,
							SWP_NOMOVE) ;
		}
			break ;

		case WM_CLOSE:
			PostQuitMessage( 0) ;
			break ;

		case WM_COMMAND:
			switch( LOWORD( wParam))
			{
				case MN_EXIT:
				{
					SendMessage( hwnd, WM_SYSCOMMAND, (WPARAM)SC_CLOSE, 0) ;
				}
					break ;
			}
			break ;

		case WM_MEASUREITEM:
			// item height
			((LPMEASUREITEMSTRUCT)lParam) -> itemHeight = SYS( SM_CYICON) ;
			return 0L ;

		case WM_DRAWITEM:
		{
			LPDRAWITEMSTRUCT lpdis ;
			POINT pt ;

			lpdis = (LPDRAWITEMSTRUCT)lParam ;

            // drawing the first time
			if( lpdis -> itemID == -1)
				HandleFocusState( lpdis) ;
			else
			{
				switch( lpdis -> itemAction)
				{
					case ODA_DRAWENTIRE:
					{
						DrawEntireItem( lpdis) ;
					}
						return 0L ;

					case ODA_SELECT:
					{
						// mouse position
						GetCursorPos( &pt) ;
						// listbox coordinates
						ScreenToClient( lpdis -> hwndItem, &pt) ;

						// il punto ricade nell'area dell'icona?
						if( pt.x < OFFSET && ( lpdis -> itemState & ODS_SELECTED))
						{
							int iIcon ;
							char *szText[] = { "Drawer is open.", "Picking up a document."} ;
							RECT rc = lpdis -> rcItem ;

							MessageBeep( 0) ;
							// icon handles
							iIcon = ListBox_GetItemData( lpdis -> hwndItem,	lpdis -> itemID) ;

							// get the other icon
							iIcon = !iIcon ;
							// inverting the two handles
							ListBox_SetItemData( lpdis -> hwndItem, lpdis -> itemID, (LPARAM)iIcon) ;

							// drawing the new icon
							DrawIconEx(	lpdis -> hDC,
										lpdis -> rcItem.left,
										lpdis -> rcItem.top,
										(HICON)GetWindowLong( hwnd, iIcon * sizeof( HICON)),
										32, 32, 0, GetStockObject( WHITE_BRUSH), DI_DEFAULTSIZE) ;

							rc.left += OFFSET ;
							FillRect( lpdis -> hDC, &rc, CreateSolidBrush( RGB( 255, 255, 255))) ;
							DrawText( lpdis -> hDC, szText[ iIcon], strlen( szText[ iIcon]), &rc, DT_LEFT) ;
						}
						// focus
						HandleSelState( lpdis) ;
					}
						break ;

					case ODA_FOCUS:
						HandleFocusState( lpdis) ;
						return 0L ;
				}
			}
		}
			break ;

		case WM_SYSCOMMAND:
			switch( wParam)
			{
				case SC_CLOSE:
				{
					MSGBOXPARAMS msgbox ;
					char szText[] = "Do you really want to terminate?" ;
					char szCaption[] = "Tool" ;

					msgbox.cbSize = sizeof( msgbox) ;
					msgbox.hwndOwner = HWND_DESKTOP ;
					msgbox.hInstance = hInstance ;
					msgbox.lpszText = szText ;
					msgbox.lpszCaption = szCaption ;
					msgbox.dwStyle = MB_YESNO | MB_USERICON ;
					msgbox.lpszIcon = "extsel" ;
					msgbox.dwContextHelpId = 1 ;
					msgbox.lpfnMsgBoxCallback = NULL ;
					msgbox.dwLanguageId = MAKELANGID( LANG_NEUTRAL, SUBLANG_NEUTRAL) ; 

					if( MessageBoxIndirect( &msgbox) == IDNO)
						return FALSE ;
				}
					break ;

				default:
					break ;
			}
			break ;

		default:
			break;
	}
	return DefWindowProc( hwnd, msg, wParam, lParam) ;
}

void HandleSelState( LPDRAWITEMSTRUCT lpdis)
{
	RECT rc ;
	HBRUSH hbr ;

    // output rectangle
	CopyRect( (LPRECT)&rc, (LPRECT)&lpdis -> rcItem) ;
	rc.left += OFFSET ;

	if( lpdis -> itemState & ODS_SELECTED)
	{
		InflateRect( &rc, -1, -1) ;
		InvertRect( lpdis -> hDC, &rc) ;
	}
	else
	{
		hbr = GetStockObject( BLACK_BRUSH) ;
		FrameRect( lpdis -> hDC, (LPRECT)&rc, hbr) ;
		InvertRect( lpdis -> hDC, &rc) ;
	}
}

void HandleFocusState( LPDRAWITEMSTRUCT lpdis)
{
	RECT rc ;
	HBRUSH hbr ;

    // output rectangle
	CopyRect( (LPRECT)&rc, (LPRECT)&lpdis->rcItem) ;
	rc.left += OFFSET ;

	if( lpdis -> itemState & ODS_FOCUS)
		DrawFocusRect( lpdis->hDC, (LPRECT)&rc) ;
	else
	{
		hbr = GetStockObject( WHITE_BRUSH) ;
		FrameRect( lpdis -> hDC, (LPRECT)&rc, hbr) ;
	}
}

void DrawEntireItem( LPDRAWITEMSTRUCT lpdis)
{
	RECT rc ;
	HBRUSH hbr ;
	char szString[40] ;
	int iIcon ;

	CopyRect( (LPRECT)&rc, (LPRECT)&lpdis -> rcItem);

	// retrieving the inserted text
	ListBox_GetText( lpdis -> hwndItem, lpdis -> itemID, szString) ;
	// two icons
	iIcon = ListBox_GetItemData( lpdis -> hwndItem, lpdis -> itemID) ;
	// drawing the icon
	DrawIcon( lpdis -> hDC, rc.left, rc.top, (HICON)GetWindowLong( PAPA( lpdis -> hwndItem), iIcon * sizeof( HICON))) ;
	// text
	TextOut( lpdis -> hDC, rc.left + OFFSET, rc.top, szString, lstrlen( szString)) ;

	// offset from the left border
	rc.left += OFFSET ;
	// output
	if( lpdis -> itemState & ODS_SELECTED)
	{
		InflateRect( &rc, -1, -1);
		InvertRect( lpdis -> hDC, &rc) ;
	}
	if( lpdis -> itemState & ODS_FOCUS)
	{
		hbr = GetStockObject( BLACK_BRUSH) ;
		FrameRect( lpdis-> hDC, (LPRECT)&rc, hbr) ;
	}
}
