// HelpTestView.cpp : implementation of the CHelpTestView class
//

#include "stdafx.h"
#include "HelpTest.h"

#include "HelpTestDoc.h"
#include "HelpTestView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHelpTestView

IMPLEMENT_DYNCREATE(CHelpTestView, CView)

BEGIN_MESSAGE_MAP(CHelpTestView, CView)
	//{{AFX_MSG_MAP(CHelpTestView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHelpTestView construction/destruction

CHelpTestView::CHelpTestView()
{
	// TODO: add construction code here

}

CHelpTestView::~CHelpTestView()
{
}

BOOL CHelpTestView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CHelpTestView drawing

void CHelpTestView::OnDraw(CDC* pDC)
{
	CHelpTestDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CHelpTestView printing

BOOL CHelpTestView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CHelpTestView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CHelpTestView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CHelpTestView diagnostics

#ifdef _DEBUG
void CHelpTestView::AssertValid() const
{
	CView::AssertValid();
}

void CHelpTestView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CHelpTestDoc* CHelpTestView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CHelpTestDoc)));
	return (CHelpTestDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHelpTestView message handlers
