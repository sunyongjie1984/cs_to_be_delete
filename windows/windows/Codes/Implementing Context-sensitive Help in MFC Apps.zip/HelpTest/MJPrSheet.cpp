// MJPrSheet.cpp : implementation file
//

#include "stdafx.h"
#include "HelpTest.h"
#include "MJPrSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMJPrSheet

IMPLEMENT_DYNAMIC(CMJPrSheet, CHelpPrSheet)

CMJPrSheet::CMJPrSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CHelpPrSheet(nIDCaption, pParentWnd, iSelectPage)
{
	ConstructorHelper();
}

CMJPrSheet::CMJPrSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CHelpPrSheet(pszCaption, pParentWnd, iSelectPage)
{
	ConstructorHelper();
}

CMJPrSheet::~CMJPrSheet()
{
}

void CMJPrSheet::ConstructorHelper()
{
	AddPage(&m_MumboPg);
	AddPage(&m_JumboPg);
}


BEGIN_MESSAGE_MAP(CMJPrSheet, CHelpPrSheet)
	//{{AFX_MSG_MAP(CMJPrSheet)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMJPrSheet message handlers
