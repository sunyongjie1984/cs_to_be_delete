//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HelpTest.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_MJ_MUMBO                    106
#define IDR_MAINFRAME                   128
#define IDR_HELPTETYPE                  129
#define IDD_DIALOG1                     130
#define IDD_MJ_JUMBO                    131
#define IDC_CHECKME                     1000
#define IDC_CHECKMUMBO                  1002
#define IDC_CHECKJUMBO                  1003
#define ID_EDIT_DIALOG                  32771
#define ID_EDIT_TESTPRSHEET             32772
#define ID_EDIT_PRSHEET                 32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
