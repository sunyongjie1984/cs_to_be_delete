#if !defined(AFX_MJMUMBOPRPG_H__9AEF72E3_830E_11D3_9343_00105AE2D16E__INCLUDED_)
#define AFX_MJMUMBOPRPG_H__9AEF72E3_830E_11D3_9343_00105AE2D16E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MJMumboPrPg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMJMumboPrPg dialog

class CMJMumboPrPg : public CPropertyPage
{
	DECLARE_DYNCREATE(CMJMumboPrPg)

// Construction
public:
	CMJMumboPrPg();
	~CMJMumboPrPg();

// Dialog Data
	//{{AFX_DATA(CMJMumboPrPg)
	enum { IDD = IDD_MJ_MUMBO };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CMJMumboPrPg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CMJMumboPrPg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MJMUMBOPRPG_H__9AEF72E3_830E_11D3_9343_00105AE2D16E__INCLUDED_)
