#if !defined(AFX_MJPRSHEET_H__9AEF72E5_830E_11D3_9343_00105AE2D16E__INCLUDED_)
#define AFX_MJPRSHEET_H__9AEF72E5_830E_11D3_9343_00105AE2D16E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MJPrSheet.h : header file
//

#include "HelpPrSheet.h"
#include "MJMumboPrPg.h"
#include "MJJumboPrPg.h"

/////////////////////////////////////////////////////////////////////////////
// CMJPrSheet

class CMJPrSheet : public CHelpPrSheet
{
	DECLARE_DYNAMIC(CMJPrSheet)

// Construction
public:
	CMJPrSheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CMJPrSheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMJPrSheet)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMJPrSheet();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMJPrSheet)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	CMJMumboPrPg				m_MumboPg;
	CMJJumboPrPg				m_JumboPg;

private:
	void							ConstructorHelper();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MJPRSHEET_H__9AEF72E5_830E_11D3_9343_00105AE2D16E__INCLUDED_)
