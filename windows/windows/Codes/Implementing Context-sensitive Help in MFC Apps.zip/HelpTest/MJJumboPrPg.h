#if !defined(AFX_MJJUMBOPRPG_H__9AEF72E4_830E_11D3_9343_00105AE2D16E__INCLUDED_)
#define AFX_MJJUMBOPRPG_H__9AEF72E4_830E_11D3_9343_00105AE2D16E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MJJumboPrPg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMJJumboPrPg dialog

class CMJJumboPrPg : public CPropertyPage
{
	DECLARE_DYNCREATE(CMJJumboPrPg)

// Construction
public:
	CMJJumboPrPg();
	~CMJJumboPrPg();

// Dialog Data
	//{{AFX_DATA(CMJJumboPrPg)
	enum { IDD = IDD_MJ_JUMBO };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CMJJumboPrPg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CMJJumboPrPg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MJJUMBOPRPG_H__9AEF72E4_830E_11D3_9343_00105AE2D16E__INCLUDED_)
