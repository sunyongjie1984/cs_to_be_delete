// TestClipboard.h : main header file for the TESTCLIPBOARD application
//

#if !defined(AFX_TESTCLIPBOARD_H__8435E9BA_3C7D_11D2_AA45_00805FC73D05__INCLUDED_)
#define AFX_TESTCLIPBOARD_H__8435E9BA_3C7D_11D2_AA45_00805FC73D05__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTestClipboardApp:
// See TestClipboard.cpp for the implementation of this class
//

class CTestClipboardApp : public CWinApp
{
public:
	CTestClipboardApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestClipboardApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	COleTemplateServer m_server;
		// Server object for document creation

	//{{AFX_MSG(CTestClipboardApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTCLIPBOARD_H__8435E9BA_3C7D_11D2_AA45_00805FC73D05__INCLUDED_)
