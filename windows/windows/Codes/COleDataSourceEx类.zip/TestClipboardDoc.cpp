// TestClipboardDoc.cpp : implementation of the CTestClipboardDoc class
//

#include "stdafx.h"
#include "TestClipboard.h"

#include "TestClipboardDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestClipboardDoc

IMPLEMENT_DYNCREATE(CTestClipboardDoc, CDocument)

BEGIN_MESSAGE_MAP(CTestClipboardDoc, CDocument)
	//{{AFX_MSG_MAP(CTestClipboardDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CTestClipboardDoc, CDocument)
	//{{AFX_DISPATCH_MAP(CTestClipboardDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//      DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_ITestClipboard to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {8435E9B7-3C7D-11D2-AA45-00805FC73D05}
static const IID IID_ITestClipboard =
{ 0x8435e9b7, 0x3c7d, 0x11d2, { 0xaa, 0x45, 0x0, 0x80, 0x5f, 0xc7, 0x3d, 0x5 } };

BEGIN_INTERFACE_MAP(CTestClipboardDoc, CDocument)
	INTERFACE_PART(CTestClipboardDoc, IID_ITestClipboard, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestClipboardDoc construction/destruction

CTestClipboardDoc::CTestClipboardDoc()
{
	// TODO: add one-time construction code here

	EnableAutomation();

	AfxOleLockApp();
}

CTestClipboardDoc::~CTestClipboardDoc()
{
	AfxOleUnlockApp();
}

BOOL CTestClipboardDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTestClipboardDoc serialization

void CTestClipboardDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTestClipboardDoc diagnostics

#ifdef _DEBUG
void CTestClipboardDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTestClipboardDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestClipboardDoc commands
