// TestClipboardView.h : interface of the CTestClipboardView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TESTCLIPBOARDVIEW_H__8435E9C3_3C7D_11D2_AA45_00805FC73D05__INCLUDED_)
#define AFX_TESTCLIPBOARDVIEW_H__8435E9C3_3C7D_11D2_AA45_00805FC73D05__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CTestClipboardView : public CView, public COleDataSourceView
{
protected: // create from serialization only
	CTestClipboardView();
	DECLARE_DYNCREATE(CTestClipboardView)

// Attributes
public:
	CTestClipboardDoc* GetDocument();

// Operations
public:

	CView* GetView()										{return this;}
	void DoDraw(CDC* pDC)									{OnDraw(pDC);}
	void DoPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL)	{OnPrepareDC(pDC, pInfo);}
	BOOL WriteCsvFormat(CFile* pFile)						{pFile->Write("Hello,World", 11); return TRUE;}
	BOOL WriteRtfFormat(CFile* pFile)						{pFile->Write("{\\rtf1 {{\\b\\i Hello World}}}", 28); return TRUE;}
	BOOL WriteTextFormat(CFile* pFile)						{pFile->Write("Hello\tWorld", 11); return TRUE;}
	BOOL WriteCustomFormat(LPFORMATETC lpFormat, CFile* file) {return FALSE;}



// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestClipboardView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTestClipboardView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTestClipboardView)
	afx_msg void OnEditCopy();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnEditClipboard();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL m_mouseDown;
};

#ifndef _DEBUG  // debug version in TestClipboardView.cpp
inline CTestClipboardDoc* CTestClipboardView::GetDocument()
   { return (CTestClipboardDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTCLIPBOARDVIEW_H__8435E9C3_3C7D_11D2_AA45_00805FC73D05__INCLUDED_)
