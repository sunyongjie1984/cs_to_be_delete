// TestClipboardView.cpp : implementation of the CTestClipboardView class
//

#include "stdafx.h"
#include "TestClipboard.h"

#include "TestClipboardDoc.h"
#include "TestClipboardView.h"
#include "ClipboardDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestClipboardView

IMPLEMENT_DYNCREATE(CTestClipboardView, CView)

BEGIN_MESSAGE_MAP(CTestClipboardView, CView)
	//{{AFX_MSG_MAP(CTestClipboardView)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_COMMAND(ID_EDIT_CLIPBOARD, OnEditClipboard)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestClipboardView construction/destruction

CTestClipboardView::CTestClipboardView()
{
	EnableTextFormat(FORMAT_EDITABLE | FORMAT_SET);
	EnableCsvFormat(FORMAT_EDITABLE);
	EnableDIBFormat(FORMAT_EDITABLE);
	EnableRtfFormat(0);

	m_mouseDown = FALSE;
}

CTestClipboardView::~CTestClipboardView()
{
}

BOOL CTestClipboardView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTestClipboardView drawing

void CTestClipboardView::OnDraw(CDC* pDC)
{
	CTestClipboardDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CRect clientRect;

	GetClientRect(&clientRect);

	// TODO: add draw code for native data here

	pDC->DrawText(_T("Hello World"), 11, &clientRect, DT_CENTER | DT_VCENTER);
}

/////////////////////////////////////////////////////////////////////////////
// CTestClipboardView printing

BOOL CTestClipboardView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTestClipboardView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTestClipboardView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTestClipboardView diagnostics

#ifdef _DEBUG
void CTestClipboardView::AssertValid() const
{
	CView::AssertValid();
}

void CTestClipboardView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTestClipboardDoc* CTestClipboardView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestClipboardDoc)));
	return (CTestClipboardDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestClipboardView message handlers

void CTestClipboardView::OnEditCopy() 
{
	COleDataSourceEx*	data = new COleDataSourceEx(this, FALSE);
	data->SetClipboard();	
}

void CTestClipboardView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (m_mouseDown) {
		COleDataSourceEx data(this, TRUE);
		data.DoDragDrop();
	}
	
	CView::OnMouseMove(nFlags, point);
}

void CTestClipboardView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_mouseDown = TRUE;
	SetCapture();
	
	CView::OnLButtonDown(nFlags, point);
}

void CTestClipboardView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	ReleaseCapture();
	m_mouseDown = FALSE;
	
	CView::OnLButtonUp(nFlags, point);
}

void CTestClipboardView::OnEditClipboard() 
{
	CClipboardDlg dlg(this);

	dlg.DoModal();
}
