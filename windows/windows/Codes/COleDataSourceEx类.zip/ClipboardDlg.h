#if !defined(AFX_CLIPBOARDDLG_H__7C168EC4_3D8A_11D2_9D91_00000E007824__INCLUDED_)
#define AFX_CLIPBOARDDLG_H__7C168EC4_3D8A_11D2_9D91_00000E007824__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ClipboardDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CClipboardDlg dialog

class CClipboardDlg : public CDialog
{
// Construction
public:

	COleDataSourceView*	m_pView;

	CClipboardDlg(COleDataSourceView* pView, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CClipboardDlg)
	enum { IDD = IDD_CLIPBOARD };
	CButton	m_text;
	CButton	m_rtf;
	CButton	m_dib;
	CButton	m_csv;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClipboardDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CClipboardDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIPBOARDDLG_H__7C168EC4_3D8A_11D2_9D91_00000E007824__INCLUDED_)
