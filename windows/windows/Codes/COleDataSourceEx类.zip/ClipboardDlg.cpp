// ClipboardDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestClipboard.h"
#include "ClipboardDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClipboardDlg dialog


CClipboardDlg::CClipboardDlg(COleDataSourceView* pView, CWnd* pParent /*=NULL*/)
	: CDialog(CClipboardDlg::IDD, pParent), m_pView(pView)
{
	//{{AFX_DATA_INIT(CClipboardDlg)
	//}}AFX_DATA_INIT
}


void CClipboardDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClipboardDlg)
	DDX_Control(pDX, IDC_TEXT, m_text);
	DDX_Control(pDX, IDC_RTF, m_rtf);
	DDX_Control(pDX, IDC_DIB, m_dib);
	DDX_Control(pDX, IDC_CSV, m_csv);
	//}}AFX_DATA_MAP

	if (!pDX->m_bSaveAndValidate) {
		m_csv.SetCheck((m_pView->CsvStatus() & FORMAT_SET) != 0);
		m_csv.EnableWindow((m_pView->CsvStatus() & FORMAT_EDITABLE) != 0);

		m_rtf.SetCheck((m_pView->RtfStatus() & FORMAT_SET) != 0);
		m_rtf.EnableWindow((m_pView->RtfStatus() & FORMAT_EDITABLE) != 0);
		
		m_text.SetCheck((m_pView->TextStatus() & FORMAT_SET) != 0);
		m_text.EnableWindow((m_pView->TextStatus() & FORMAT_EDITABLE) != 0);
		
		m_dib.SetCheck((m_pView->DIBStatus() & FORMAT_SET) != 0);
		m_dib.EnableWindow((m_pView->DIBStatus() & FORMAT_EDITABLE) != 0);
	} else {
		if (m_csv.GetCheck()) {
			m_pView->EnableCsvFormat(m_pView->CsvStatus() | FORMAT_SET);
		} else {
			m_pView->EnableCsvFormat(m_pView->CsvStatus() & ~FORMAT_SET);
		}

		if (m_rtf.GetCheck()) {
			m_pView->EnableRtfFormat(m_pView->RtfStatus() | FORMAT_SET);
		} else {
			m_pView->EnableRtfFormat(m_pView->RtfStatus() & ~FORMAT_SET);
		}

		if (m_text.GetCheck()) {
			m_pView->EnableTextFormat(m_pView->TextStatus() | FORMAT_SET);
		} else {
			m_pView->EnableTextFormat(m_pView->TextStatus() & ~FORMAT_SET);
		}

		if (m_dib.GetCheck()) {
			m_pView->EnableDIBFormat(m_pView->DIBStatus() | FORMAT_SET);
		} else {
			m_pView->EnableDIBFormat(m_pView->DIBStatus() & ~FORMAT_SET);
		}
	}
}


BEGIN_MESSAGE_MAP(CClipboardDlg, CDialog)
	//{{AFX_MSG_MAP(CClipboardDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClipboardDlg message handlers
