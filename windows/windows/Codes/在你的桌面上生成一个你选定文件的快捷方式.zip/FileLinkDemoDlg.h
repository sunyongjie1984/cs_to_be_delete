// FileLinkDemoDlg.h : Header-Datei
//

#if !defined(AFX_FILELINKDEMODLG_H__FAA7AD77_2CF6_11D2_8BCA_40000039493B__INCLUDED_)
#define AFX_FILELINKDEMODLG_H__FAA7AD77_2CF6_11D2_8BCA_40000039493B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CFileLinkDemoDlg Dialogfeld

class CFileLinkDemoDlg : public CDialog
{
// Konstruktion
public:
	BOOL FileLink(const CString strPathObj,const CString strPathLink);
	CFileLinkDemoDlg(CWnd* pParent = NULL);	// Standard-Konstruktor

// Dialogfelddaten
	//{{AFX_DATA(CFileLinkDemoDlg)
	enum { IDD = IDD_FILELINKDEMO_DIALOG };
		// HINWEIS: der Klassenassistent f�gt an dieser Stelle Datenelemente (Members) ein
	//}}AFX_DATA

	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CFileLinkDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	HICON m_hIcon;

	// Generierte Message-Map-Funktionen
	//{{AFX_MSG(CFileLinkDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio f�gt zus�tzliche Deklarationen unmittelbar vor der vorhergehenden Zeile ein.

#endif // !defined(AFX_FILELINKDEMODLG_H__FAA7AD77_2CF6_11D2_8BCA_40000039493B__INCLUDED_)
