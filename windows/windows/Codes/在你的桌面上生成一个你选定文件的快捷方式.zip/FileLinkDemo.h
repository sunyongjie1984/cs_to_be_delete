// FileLinkDemo.h : Haupt-Header-Datei f�r die Anwendung FILELINKDEMO
//

#if !defined(AFX_FILELINKDEMO_H__FAA7AD75_2CF6_11D2_8BCA_40000039493B__INCLUDED_)
#define AFX_FILELINKDEMO_H__FAA7AD75_2CF6_11D2_8BCA_40000039493B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// Hauptsymbole

/////////////////////////////////////////////////////////////////////////////
// CFileLinkDemoApp:
// Siehe FileLinkDemo.cpp f�r die Implementierung dieser Klasse
//

class CFileLinkDemoApp : public CWinApp
{
public:
	CFileLinkDemoApp();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CFileLinkDemoApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementierung

	//{{AFX_MSG(CFileLinkDemoApp)
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio f�gt zus�tzliche Deklarationen unmittelbar vor der vorhergehenden Zeile ein.

#endif // !defined(AFX_FILELINKDEMO_H__FAA7AD75_2CF6_11D2_8BCA_40000039493B__INCLUDED_)
