// CustControl.h : main header file for the CUSTCONTROL application
//

#if !defined(AFX_CUSTCONTROL_H__4E436D92_D7E4_11D3_98A1_0050045C444A__INCLUDED_)
#define AFX_CUSTCONTROL_H__4E436D92_D7E4_11D3_98A1_0050045C444A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCustControlApp:
// See CustControl.cpp for the implementation of this class
//

class CCustControlApp : public CWinApp
{
public:
	CCustControlApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCustControlApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCustControlApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CUSTCONTROL_H__4E436D92_D7E4_11D3_98A1_0050045C444A__INCLUDED_)
