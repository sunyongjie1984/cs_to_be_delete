#include "stdafx.h"
#include "RulerSlider.h"

#define SPLITSIZE 1
#define TRACKSIZE 3

IMPLEMENT_DYNAMIC(CRulerSlider, CProgressCtrl)


BEGIN_MESSAGE_MAP(CRulerSlider, CProgressCtrl)
    //{{AFX_MSG_MAP(CRulerSlider)
    ON_WM_LBUTTONDOWN()
    ON_WM_LBUTTONUP()
    ON_WM_MOUSEMOVE()
    ON_WM_PAINT()
    ON_WM_ERASEBKGND()
    ON_WM_SIZE()
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

CRulerSlider::CRulerSlider()
{
    m_bCaptured = FALSE;
    m_logbrush.lbStyle = BS_SOLID;
    m_logbrush.lbColor = GetSysColor(COLOR_3DFACE);
    m_logbrush.lbHatch = HS_HORIZONTAL;
    m_bRightSlider = FALSE;
    m_bLeftSlider = FALSE;
    m_penColor = ::GetSysColor(COLOR_WINDOWTEXT);
}

CRulerSlider::~CRulerSlider()
{
}

void CRulerSlider::Init(const CRect rect)
{
    m_ptRightPos.x = rect.right;
    m_ptRightPos.y = rect.top;
    m_ptLeftPos.x = rect.left;
    m_ptLeftPos.y = rect.top;
    m_rcLeftSlider.right = m_ptLeftPos.x;
    m_rcRightSlider.left = m_ptRightPos.x;
}

int CRulerSlider::GetLeftPos()
{
	if (!IsWindow(m_hWnd))
		return 0;

	return m_ptLeftPos.x;
}

int CRulerSlider::GetRightPos()
{
	if (!IsWindow(m_hWnd))
		return 0;

	CRect rect;
	GetClientRect(rect);
	return rect.right - m_ptRightPos.x;
}


void CRulerSlider::OnLButtonDown(UINT nFlags, CPoint point)
{
    SetCapture();
    m_bCaptured = TRUE;

    CRect rcClient;
    GetClientRect(&rcClient);
    CDC* pDC = GetDC();
    pDC->DPtoLP(&point);

    if((point.x >= m_ptRightPos.x-SPLITSIZE-TRACKSIZE && point.x <= m_ptRightPos.x+SPLITSIZE+TRACKSIZE))
    {
        SetCursor(LoadCursor(NULL, IDC_SIZEWE));
        m_bRightSlider = TRUE;
    }
    if((point.x >= m_ptLeftPos.x-SPLITSIZE-TRACKSIZE && point.x <= m_ptLeftPos.x+SPLITSIZE+TRACKSIZE))
    {
        SetCursor(LoadCursor(NULL, IDC_SIZEWE));
        m_bLeftSlider = TRUE;
    }
    ReleaseDC(pDC);
}

void CRulerSlider::OnLButtonUp(UINT nFlags, CPoint point)
{
    if(m_bCaptured)
    {
        m_bCaptured = FALSE;
        m_bRightSlider = FALSE;
        m_bLeftSlider = FALSE;
        m_penColor = ::GetSysColor(COLOR_WINDOWTEXT);
        Invalidate(TRUE);
        ReleaseCapture();
    }
}

void CRulerSlider::OnMouseMove(UINT nFlags, CPoint point)
{
    CDC* pDC = GetDC();
    if(m_bCaptured)
    {
        CRect rcClient;
        GetClientRect(&rcClient);
        pDC->DPtoLP(&rcClient);
        pDC->DPtoLP(&point);

        if(m_bRightSlider && 
            point.x > m_ptLeftPos.x && 
            point.x >= rcClient.left && 
            point.x <= rcClient.right)
        {
            m_ptRightPos = point;
            m_rcRightSlider.left = m_ptRightPos.x;
            m_rcRightSlider.right = rcClient.right;
        }
        if(m_bLeftSlider && 
            point.x < m_ptRightPos.x && 
            point.x < rcClient.right && 
            point.x >= rcClient.left)
        {
            m_ptLeftPos = point;
            m_rcLeftSlider.right = m_ptLeftPos.x;
            m_rcLeftSlider.left = rcClient.left;
        }
        //only invalidate if mouse drag something
        if(m_bRightSlider || m_bLeftSlider)
            Invalidate(TRUE);

		TRACE("Right: %d, Left: %d\n", GetRightPos(), GetLeftPos());
    }

    if((point.x >= m_ptRightPos.x-SPLITSIZE-TRACKSIZE && point.x <= m_ptRightPos.x+SPLITSIZE+TRACKSIZE)||
        (point.x >= m_ptLeftPos.x-SPLITSIZE-TRACKSIZE && point.x <= m_ptLeftPos.x+SPLITSIZE+TRACKSIZE))
    {
        SetCursor(LoadCursor(NULL, IDC_SIZEWE));
    }

    ReleaseDC(pDC);
}

void CRulerSlider::OnPaint()
{
    CPaintDC dc(this);
    CRect rcClient;
    GetClientRect(&rcClient);
    dc.DPtoLP(&rcClient);    

    CBrush brush;
    brush.CreateBrushIndirect(&m_logbrush);
    CBrush* pOldBrush = (CBrush*)dc.SelectObject(&m_logbrush);

    //left slider
    m_rcLeftSlider.top = rcClient.top;
    m_rcLeftSlider.bottom = rcClient.bottom;
    dc.FillRect(&m_rcLeftSlider, &brush);
    dc.Draw3dRect(&m_rcLeftSlider, ::GetSysColor(COLOR_3DHILIGHT), ::GetSysColor(COLOR_3DSHADOW));

    //right slider
    m_rcRightSlider.top = rcClient.top;
    m_rcRightSlider.bottom = rcClient.bottom;
    dc.FillRect(&m_rcRightSlider, &brush);
    dc.Draw3dRect(&m_rcRightSlider, ::GetSysColor(COLOR_3DHILIGHT), ::GetSysColor(COLOR_3DSHADOW));

    CRect rcWite;
    rcWite.left = m_rcLeftSlider.right;
    rcWite.top = m_rcLeftSlider.top;
    rcWite.right = m_rcRightSlider.left;
    rcWite.bottom = m_rcRightSlider.bottom;
    dc.FillSolidRect(rcWite, ::GetSysColor(COLOR_WINDOW));
    
    //draw big and small ticks
    DrawTicks(&dc);

    TEXTMETRIC tm;
    dc.GetTextMetrics(&tm);
    
    CFont hFont;
    hFont.CreateFont(12, 0, 000, 000, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, 
        OUT_TT_PRECIS, CLIP_TT_ALWAYS, PROOF_QUALITY, VARIABLE_PITCH|FF_ROMAN, "Times New Roman");
    CFont* pOldFont= dc.SelectObject(&hFont);
    
    int x;
    CString str;
    CSize size = dc.GetTextExtent(str);
    //draw arrow and text inicating number of ticks passed by
    if(m_bRightSlider)
    {
        dc.MoveTo(rcClient.right, rcClient.Height()/2);
        dc.LineTo(m_rcRightSlider.left, rcClient.Height()/2); 
        //dc.SetBkMode(TRANSPARENT);
        str.Format("%d", rcClient.right - m_rcRightSlider.left);
        if(size.cx < m_rcRightSlider.Width())
            x = m_rcRightSlider.left+((m_rcRightSlider.Width()-4)/2) - 2;
        else
            x = rcClient.right+4;
            dc.TextOut(x , rcClient.Height()/2-6, str); 
    }
    if(m_bLeftSlider)
    {
        dc.MoveTo(rcClient.left, rcClient.Height()/2);
        dc.LineTo(m_rcLeftSlider.right, rcClient.Height()/2);
        //dc.SetBkMode(TRANSPARENT);
        str.Format("%d", m_rcLeftSlider.right - rcClient.left);
        if(size.cx < m_rcLeftSlider.Width())
            x = (m_rcLeftSlider.Width()-4)/2 - 2;
        else
            x = rcClient.left - size.cx;
        dc.TextOut(x, rcClient.Height()/2-6, str); 
    }

    dc.SelectObject(pOldFont);
    dc.SelectObject(pOldBrush);
}

BOOL CRulerSlider::Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID) 
{
	Init(rect);
 
    return CProgressCtrl::Create(dwStyle, rect, pParentWnd, nID);
}

void CRulerSlider::OnSize(UINT nType, int cx, int cy) 
{
    CProgressCtrl::OnSize(nType, cx, cy);

	Init(CRect(0,0,cx,0));
}

void CRulerSlider::DrawTicks(CDC* pDC)
{
    CRect rcClient;
    GetClientRect(&rcClient);
    pDC->DPtoLP(&rcClient);
    
    CPen aPen;
    if(m_bCaptured)
        m_penColor = RGB(128,128,128);

    aPen.CreatePen(PS_SOLID, 0, m_penColor);

    CPen* pOldPen = pDC->SelectObject(&aPen);
    // draw big ticks 
    int tickBig=(int)(100.0);
    int tickSmall=(int)(10.0);
    int tickSmallHeight = rcClient.Height()/3;
    int tickBigHeight = rcClient.Height()/2;

    for (int i=1; i<=rcClient.Width()/50; i++)
    {
        pDC->MoveTo(tickBig*i, rcClient.bottom);
        pDC->LineTo(tickBig*i, rcClient.bottom-tickBigHeight);
    }

    // draw small ticks 
    for (int j=1; j<=rcClient.Width()/10; j++)
    {
        pDC->MoveTo(tickSmall*j, rcClient.bottom);
        pDC->LineTo(tickSmall*j, rcClient.bottom-tickSmallHeight);
    }
    
    pDC->SelectObject(pOldPen);
}

BOOL CRulerSlider::OnEraseBkgnd(CDC* pDC) 
{
    return TRUE;
}


void CRulerSlider::PreSubclassWindow() 
{
	if (IsWindow(m_hWnd))
	{
		CRect rect;
		GetClientRect(rect);
		Init(rect);
	}

	CProgressCtrl::PreSubclassWindow();
}
