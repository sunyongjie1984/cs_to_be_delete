//header file CRulerSlider
//
#if !defined(AFX_RULERSLIDER_H__4E436D92_D7E4_11D3_98A1_0050045C444A__INCLUDED_)
#define AFX_RULERSLIDER_H__4E436D92_D7E4_11D3_98A1_0050045C444A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CRulerSlider : public CProgressCtrl
{
    DECLARE_DYNAMIC(CRulerSlider)

// Constructors
public:
    CRulerSlider();

// Methods
public:
	int GetLeftPos();
	int GetRightPos();

// Attributes
private:
    BOOL m_bCaptured;
    CPoint m_ptOld;
    LOGBRUSH m_logbrush;
    BOOL m_bRightSlider;
    BOOL m_bLeftSlider;
    CRect m_rcLeftSlider;
    CRect m_rcRightSlider;
    CPoint m_ptRightPos;
    CPoint m_ptLeftPos;
    COLORREF m_penColor;

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CRulerSlider)
	public:
    virtual BOOL Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
    virtual ~CRulerSlider();
protected:
    void Init(const CRect rect);
    void DrawTicks(CDC* pDC);

    // Generated message map functions
    //{{AFX_MSG(CRulerSlider)
    afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
    afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
    afx_msg void OnMouseMove(UINT nFlags, CPoint point);
    afx_msg void OnPaint();
    afx_msg BOOL OnEraseBkgnd(CDC* pDC);
    afx_msg void OnSize(UINT nType, int cx, int cy);
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()

};




#endif // !defined(AFX_RULERSLIDER_H__4E436D92_D7E4_11D3_98A1_0050045C444A__INCLUDED_)

