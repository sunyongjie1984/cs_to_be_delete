// DemoTBarC.h : main header file for the DEMOTBARC application
//

#if !defined(AFX_DEMOTBARC_H__1C587866_9927_11D2_ABA4_B4FFFFC00000__INCLUDED_)
#define AFX_DEMOTBARC_H__1C587866_9927_11D2_ABA4_B4FFFFC00000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDemoTBarCApp:
// See DemoTBarC.cpp for the implementation of this class
//

class CDemoTBarCApp : public CWinApp
{
public:
	CDemoTBarCApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDemoTBarCApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CDemoTBarCApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEMOTBARC_H__1C587866_9927_11D2_ABA4_B4FFFFC00000__INCLUDED_)
