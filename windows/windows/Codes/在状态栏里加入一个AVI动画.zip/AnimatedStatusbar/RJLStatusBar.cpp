// RJLStatusBar.cpp : implementation file
//

#include "stdafx.h"
#include "AnimatedStatusbar.h"
#include "RJLStatusBar.h"
#include "StatusbarAnimate.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRJLStatusBar

CRJLStatusBar::CRJLStatusBar()
{
}

CRJLStatusBar::~CRJLStatusBar()
{
}


BEGIN_MESSAGE_MAP(CRJLStatusBar, CStatusBar)
	//{{AFX_MSG_MAP(CRJLStatusBar)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CRJLStatusBar message handlers

HBRUSH CRJLStatusBar::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	if (pWnd->IsKindOf(RUNTIME_CLASS(CStatusbarAnimate))) {
		HBRUSH hbr = CStatusBar::OnCtlColor(pDC, pWnd, nCtlColor);
		return hbr;
		}
	
	return (HBRUSH)GetStockObject(NULL_BRUSH);
}
