#if !defined(AFX_RJLSTATUSBAR_H__6E6FB2C8_268B_11D3_842C_00A0C9422E56__INCLUDED_)
#define AFX_RJLSTATUSBAR_H__6E6FB2C8_268B_11D3_842C_00A0C9422E56__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RJLStatusBar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRJLStatusBar window

class CRJLStatusBar : public CStatusBar
{
// Construction
public:
	CRJLStatusBar();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRJLStatusBar)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CRJLStatusBar();

	// Generated message map functions
protected:
	//{{AFX_MSG(CRJLStatusBar)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RJLSTATUSBAR_H__6E6FB2C8_268B_11D3_842C_00A0C9422E56__INCLUDED_)
