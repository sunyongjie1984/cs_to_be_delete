// AnimatedStatusbarDoc.h : interface of the CAnimatedStatusbarDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_AnimatedStatusbarDOC_H__6D425C8C_266E_11D3_842C_00A0C9422E56__INCLUDED_)
#define AFX_AnimatedStatusbarDOC_H__6D425C8C_266E_11D3_842C_00A0C9422E56__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CAnimatedStatusbarDoc : public CDocument
{
protected: // create from serialization only
	CAnimatedStatusbarDoc();
	DECLARE_DYNCREATE(CAnimatedStatusbarDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnimatedStatusbarDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CAnimatedStatusbarDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CAnimatedStatusbarDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AnimatedStatusbarDOC_H__6D425C8C_266E_11D3_842C_00A0C9422E56__INCLUDED_)
