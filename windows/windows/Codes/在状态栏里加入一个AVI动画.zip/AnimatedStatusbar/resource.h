//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AnimatedStatusbar.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_ANIMATTYPE                  129
#define IDR_EXTRA                       130
#define IDR_AVITEST                     134
#define IDC_ANIMATE2                    1001
#define ID_ANIMATE                      32771
#define ID_VIEW_ANIMATION               32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
