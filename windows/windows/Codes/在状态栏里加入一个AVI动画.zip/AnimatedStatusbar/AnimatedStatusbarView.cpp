// AnimatedStatusbarView.cpp : implementation of the CAnimatedStatusbarView class
//

#include "stdafx.h"
#include "AnimatedStatusbar.h"

#include "AnimatedStatusbarDoc.h"
#include "AnimatedStatusbarView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAnimatedStatusbarView

IMPLEMENT_DYNCREATE(CAnimatedStatusbarView, CView)

BEGIN_MESSAGE_MAP(CAnimatedStatusbarView, CView)
	//{{AFX_MSG_MAP(CAnimatedStatusbarView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAnimatedStatusbarView construction/destruction

CAnimatedStatusbarView::CAnimatedStatusbarView()
{
	// TODO: add construction code here

}

CAnimatedStatusbarView::~CAnimatedStatusbarView()
{
}

BOOL CAnimatedStatusbarView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CAnimatedStatusbarView drawing

void CAnimatedStatusbarView::OnDraw(CDC* pDC)
{
	CAnimatedStatusbarDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CAnimatedStatusbarView printing

BOOL CAnimatedStatusbarView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CAnimatedStatusbarView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CAnimatedStatusbarView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CAnimatedStatusbarView diagnostics

#ifdef _DEBUG
void CAnimatedStatusbarView::AssertValid() const
{
	CView::AssertValid();
}

void CAnimatedStatusbarView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CAnimatedStatusbarDoc* CAnimatedStatusbarView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAnimatedStatusbarDoc)));
	return (CAnimatedStatusbarDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAnimatedStatusbarView message handlers
