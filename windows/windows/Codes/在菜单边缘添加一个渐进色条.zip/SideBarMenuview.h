// SideBarMenuView.h : interface of the CSideBarMenuView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIDEBARMENUVIEW_H__70188CB9_4D96_40FE_995C_748ACE8B712F__INCLUDED_)
#define AFX_SIDEBARMENUVIEW_H__70188CB9_4D96_40FE_995C_748ACE8B712F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CSideBarMenuView : public CWindowImpl<CSideBarMenuView>
{
public:
	DECLARE_WND_CLASS(NULL)

	BOOL PreTranslateMessage(MSG* pMsg)
	{
		pMsg;
		return FALSE;
	}

	BEGIN_MSG_MAP(CSideBarMenuView)
		MESSAGE_HANDLER(WM_PAINT, OnPaint)
	END_MSG_MAP()

	LRESULT OnPaint(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CPaintDC dc(m_hWnd);

		//TODO: Add your drawing code here

		return 0;
	}
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIDEBARMENUVIEW_H__70188CB9_4D96_40FE_995C_748ACE8B712F__INCLUDED_)
