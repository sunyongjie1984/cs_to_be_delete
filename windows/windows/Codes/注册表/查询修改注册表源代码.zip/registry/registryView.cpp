// registryView.cpp : implementation of the CRegistryView class
//

#include "stdafx.h"
#include "registry.h"

#include "registryDoc.h"
#include "registryView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRegistryView

IMPLEMENT_DYNCREATE(CRegistryView, CFormView)

BEGIN_MESSAGE_MAP(CRegistryView, CFormView)
	//{{AFX_MSG_MAP(CRegistryView)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRegistryView construction/destruction

CRegistryView::CRegistryView()
	: CFormView(CRegistryView::IDD)
{
	//{{AFX_DATA_INIT(CRegistryView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CRegistryView::~CRegistryView()
{
}

void CRegistryView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRegistryView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BOOL CRegistryView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CRegistryView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

/////////////////////////////////////////////////////////////////////////////
// CRegistryView printing

BOOL CRegistryView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CRegistryView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CRegistryView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CRegistryView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: add customized printing code here
}

/////////////////////////////////////////////////////////////////////////////
// CRegistryView diagnostics

#ifdef _DEBUG
void CRegistryView::AssertValid() const
{
	CFormView::AssertValid();
}

void CRegistryView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CRegistryDoc* CRegistryView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CRegistryDoc)));
	return (CRegistryDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CRegistryView message handlers

void CRegistryView::OnButton1() 
{
	// TODO: Add your control notification handler code here
	HKEY hKEY;
	LPCTSTR path="Software\\Microsoft\\MS Setup (ACME)\\User Info";

	long ret=::RegOpenKeyEx(HKEY_CURRENT_USER,path, 0, KEY_READ,&hKEY);
/*		LPVOID lpMsgBuf;
FormatMessage( 
    FORMAT_MESSAGE_ALLOCATE_BUFFER | 
    FORMAT_MESSAGE_FROM_SYSTEM | 
    FORMAT_MESSAGE_IGNORE_INSERTS,
    NULL,
    ret,
    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    (LPTSTR) &lpMsgBuf,
    0,
    NULL 
);
// Process any inserts in lpMsgBuf.
// ...
// Display the string.
MessageBox( NULL, (LPCTSTR)lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION );
// Free the buffer.
LocalFree( lpMsgBuf );
*/
	if(ret!=ERROR_SUCCESS) //����޷���hKEY������ֹ�����ִ��
	{
		MessageBox("����: ��ѯ�޷����йص�hKEY!");
		return;
	}

	unsigned char tmp[256]="\0";
	DWORD type=REG_SZ;
	DWORD size=80;
	ret=::RegQueryValueEx(hKEY,"DefName", NULL,&type,tmp,&size);
	if(ret!=ERROR_SUCCESS)
	{
		MessageBox("����:�޷���ѯ�й�ע�����Ϣ!");
		return;
	}
	CString tmpstring=CString(tmp);
	AfxMessageBox(tmpstring);
	::RegCloseKey(hKEY);
}

void CRegistryView::OnButton2() 
{
	// TODO: Add your control notification handler code here
	unsigned char tmp[256];
	sprintf((char *)tmp,"%s","hello");
	CString tmpstring=tmp;

	HKEY hKEY;
	DWORD type=REG_SZ;
	DWORD size=tmpstring.GetLength()+1;
	LPCTSTR path="Software\\Microsoft\\MS Setup (ACME)\\User Info" ;

	long ret=::RegOpenKeyEx(HKEY_CURRENT_USER,path,0,KEY_WRITE, &hKEY);
	if(ret!=ERROR_SUCCESS)
	{ 
		MessageBox("����: �޸��޷����йص�hKEY!");
		return; 
	}
	ret=::RegSetValueEx(hKEY,"DefName",NULL,type,tmp,size);
	if(ret!=ERROR_SUCCESS)
	{ 
		MessageBox("����: �޷��޸��й�ע�����Ϣ!");
		return;
	}
	::RegCloseKey(hKEY);
}
