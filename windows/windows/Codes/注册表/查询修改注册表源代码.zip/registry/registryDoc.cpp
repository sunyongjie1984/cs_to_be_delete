// registryDoc.cpp : implementation of the CRegistryDoc class
//

#include "stdafx.h"
#include "registry.h"

#include "registryDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRegistryDoc

IMPLEMENT_DYNCREATE(CRegistryDoc, CDocument)

BEGIN_MESSAGE_MAP(CRegistryDoc, CDocument)
	//{{AFX_MSG_MAP(CRegistryDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRegistryDoc construction/destruction

CRegistryDoc::CRegistryDoc()
{
	// TODO: add one-time construction code here

}

CRegistryDoc::~CRegistryDoc()
{
}

BOOL CRegistryDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CRegistryDoc serialization

void CRegistryDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CRegistryDoc diagnostics

#ifdef _DEBUG
void CRegistryDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CRegistryDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CRegistryDoc commands
