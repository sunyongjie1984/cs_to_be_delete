#ifndef __GUIDLL_H
#define __GUIDLL_H

#include <windows.h>

BOOL WINAPI //PASCAL 
MyExtTextOutA(HDC hdc, int nXStart, int nYStart, UINT fuOptions,
			  const RECT FAR *lprc, LPCSTR lpszString,
			  UINT cbString,
			  int FAR *lpDx) ;

BOOL WINAPI //PASCAL
MyTextOutA(HDC, int ,int , LPCSTR ,int );

BOOL WINAPI //PASCAL 
MyExtTextOutW(HDC hdc, int nXStart, int nYStart, UINT fuOptions,
			  const RECT FAR *lprc, LPCSTR lpszString,
			  UINT cbString,
			  int FAR *lpDx) ;

BOOL WINAPI //PASCAL
MyTextOutW(HDC, int ,int , LPCSTR ,int );

BOOL 
InstallProbes(void) ;

BOOL
UninstallProbes(void);

LRESULT CALLBACK
MyMouseProc(int code, WPARAM wParam, LPARAM lParam);

BOOL 
InstallMouseHook(HINSTANCE) ;

BOOL 
UninstallMouseHook(void);

LRESULT CALLBACK
MouseWndProc( HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam );

#endif