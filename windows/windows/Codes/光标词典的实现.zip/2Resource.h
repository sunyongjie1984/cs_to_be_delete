#ifndef RESOURCE_H
#define RESOURCE_H
#define IDC_COMMAND	101
#define IDC_IGNORE1	104
#define IDC_IGNORE2	105
#define IDC_COMMAND2	106
#define IDC_MOUSEXY	107
#define IDC_TEXTOUT	103
#define IDC_EXTTEXTOUT	102

#endif
