/*************************************************
*  Copyrights , 1997 ,CompTech , TaoChen
*  Email : tchen@Venus.sui.ustc.edu.cn
*************************************************/

#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <ctl3d.h>
#include "texthook.h"
#include "resource.h"
#include "guidll.h"
static BOOL bCanEnd = FALSE ;

char AppName[]      = "TEXTHOOKNT";
HANDLE HInstance;
char ERROR_CAPTION[] = "Problem!!!";
static BOOL bCleared  = TRUE;

BOOL
RegisterMousePointWindow(void);
BOOL CALLBACK
TextHookDialogProc(HWND hDlg, UINT message,
					WPARAM wParam, LPARAM lParam);



void TextHookError(char *msg)
{
	 char buffer[128];

	 wsprintf(buffer, "TextHook %s", msg);

	 MessageBox(NULL, buffer, ERROR_CAPTION, MB_OK);
}



BOOL CALLBACK TextHookDialogProc(HWND hDlg, UINT message,
WPARAM wParam, LPARAM lParam)
{
	char buffer[128];
//	POINT FAR *pt;
	static HANDLE hMapObject= NULL;
	static PTShareData pData=NULL;
	HMODULE hModGDI ;
	switch ( message ){
	case WM_INITDIALOG:
			hMapObject = CreateFileMapping( 
                (HANDLE) 0xFFFFFFFF, // use paging file
                NULL,                // no security attributes
                PAGE_READWRITE,      // read/write access
                0,                   // size: high 32-bits
                SHMEMSIZE,           // size: low 32-bits
                MAPFILENAME);        // name of map object
            
			if (hMapObject == NULL){
				TextHookError("Can not init. share memory !");
                EndDialog(hDlg , FALSE );
				return FALSE; 
			}
 
            // Get a pointer to the file-mapped shared memory.
 
            pData = (PTShareData)MapViewOfFile( 
                hMapObject,     // object to map view of
                FILE_MAP_WRITE, // read/write access
                0,              // high offset:  map from
                0,              // low offset:   beginning
                0);             // default: map entire file

            if (pData == NULL){
				TextHookError("Can not init. share memory !");
                EndDialog(hDlg , FALSE );
				return FALSE; 
			}
 
            // Initialize memory .
            
            memset(pData, '\0', SHMEMSIZE); 
			
			pData->hCurTask = GetCurrentTask();
			pData->HTextHookWnd = hDlg ;
			pData->DLLRef = 1;
			
			hModGDI = GetModuleHandle ( "GDI32");
			if ( hModGDI == NULL ){
				TextHookError("What about your windows nt ?");
                EndDialog(hDlg , FALSE );
				return FALSE;
			}
			
			pData->ExtTextOutA = (__ExtTextOut)GetProcAddress(hModGDI , "ExtTextOutA");
			if (pData->ExtTextOutA == NULL ){
				TextHookError("Failed to get API entry !");
                EndDialog(hDlg , FALSE );
				return FALSE;
			}	
			
			memcpy(pData->OldCodeExtTextOutA , pData->ExtTextOutA , 10 );

			pData->TextOutA = (__TextOut)GetProcAddress(hModGDI , "TextOutA");
						
			if (pData->TextOutA == NULL ){
				TextHookError("Failed to get API entry !");
                EndDialog(hDlg , FALSE );
				return FALSE;
			}
			memcpy(pData->OldCodeTextOutA , pData->TextOutA , 10 );

			pData->ExtTextOutW = (__ExtTextOut)GetProcAddress(hModGDI , "ExtTextOutW");
			if (pData->ExtTextOutW == NULL ){
				TextHookError("Failed to get API entry !");
                EndDialog(hDlg , FALSE );
				return FALSE;
			}	
			memcpy(pData->OldCodeExtTextOutW , pData->ExtTextOutW , 10 );

			pData->TextOutW = (__TextOut)GetProcAddress(hModGDI , "TextOutW");
						
			if (pData->TextOutW == NULL ){
				TextHookError("Failed to get API entry !");
                EndDialog(hDlg , FALSE );
				return FALSE;
			}
			memcpy(pData->OldCodeTextOutW , pData->TextOutW , 10 );
			
			return TRUE ;
		  case WM_SHUTDOWN :
			  if(bCanEnd==TRUE){
				  UnmapViewOfFile(pData); 
				  CloseHandle(hMapObject);
				  EndDialog(hDlg,TRUE);
				}
			  break ;

		  case WM_COMMAND:
				switch ( wParam ){
					case IDOK :
						SetWindowText(hDlg , "Unloading ... ... please wait ... ...");
						if(	pData->DLLRef == 1){
							EndDialog(hDlg,TRUE);
						}else{
							pData->bIntercept = FALSE;
							UninstallMouseHook();
						}
						EnableWindow(hDlg,FALSE);
						//Sleep(1000);
						bCanEnd= TRUE ;
				
						return TRUE;
					case  IDHELP :
						WinExec("WinHlp32.exe GUIHOKNT.HLP" , SW_SHOW);
						return 0 ;

					case IDC_COMMAND :
						GetDlgItemText(hDlg , IDC_COMMAND ,buffer ,128 );
						if ( lstrcmpi( buffer , "Start !") == 0){
							MessageBox(NULL , "Start!" ,"Demo" , MB_OK );
							SetDlgItemText(hDlg , IDC_COMMAND ,"Stop !" );
							pData->bIntercept = TRUE;
							InstallMouseHook(HInstance);
						}else{
							SetDlgItemText(hDlg , IDC_COMMAND ,"Start !" );
							pData->bIntercept = FALSE;
							UninstallMouseHook();
						}
						
						return 0;

					case IDC_COMMAND2 :
						GetDlgItemText(hDlg , IDC_COMMAND2 ,buffer ,128 );
						if ( lstrcmpi( buffer , "Start !") == 0){
							MessageBox(NULL , "Start" ,"demo" , MB_OK );
							SetDlgItemText(hDlg , IDC_COMMAND2 ,"Stop !" );
							pData->bReadyToGetText = TRUE ;
							FlushViewOfFile(pData , 0);
						}else{
							SetDlgItemText(hDlg , IDC_COMMAND2 ,"Start !" );
							pData->bReadyToGetText = FALSE ;
						}
						return 0;

					case IDC_IGNORE1 :
						if( BST_UNCHECKED != IsDlgButtonChecked(hDlg ,IDC_IGNORE1 )){
							CheckDlgButton(hDlg ,IDC_IGNORE1,TRUE);
							pData->bIgrExtTextOutA = TRUE ;
						}else{
							CheckDlgButton(hDlg ,IDC_IGNORE1,FALSE);
							pData->bIgrExtTextOutA = FALSE;
						}
						FlushViewOfFile(pData , 0);
						break;
					case IDC_IGNORE2 :
						if( BST_UNCHECKED != IsDlgButtonChecked(hDlg ,IDC_IGNORE2 )){
							CheckDlgButton(hDlg ,IDC_IGNORE2,TRUE);
							pData->bIgrTextOutA = TRUE ;
						}else{
							CheckDlgButton(hDlg ,IDC_IGNORE2,FALSE);
							pData->bIgrTextOutA = FALSE ;
						}

						break;
					case IDC_IGNORE3 :
						if( BST_UNCHECKED != IsDlgButtonChecked(hDlg ,IDC_IGNORE3 )){
							CheckDlgButton(hDlg ,IDC_IGNORE3,TRUE);
							pData->bIgrExtTextOutW = TRUE;
						}else{
							CheckDlgButton(hDlg ,IDC_IGNORE3,FALSE);
							pData->bIgrExtTextOutW = FALSE;
						}
						FlushViewOfFile(pData , 0);
						break;
					case IDC_IGNORE4 :
						if( BST_UNCHECKED != IsDlgButtonChecked(hDlg ,IDC_IGNORE4 )){
							CheckDlgButton(hDlg ,IDC_IGNORE4,TRUE);
							pData->bIgrTextOutW = TRUE;
				 		}else{
							CheckDlgButton(hDlg ,IDC_IGNORE4,FALSE);
							pData->bIgrTextOutW = FALSE;
						}
						FlushViewOfFile(pData , 0);
						break;

					default :
						break ;
				}
				break;
		  case WM_EXTTEXTOUTA:
			  if(wParam == CMD_USE2)
				  SetDlgItemText( hDlg , IDC_EXTTEXTOUTA , pData->sBufExtTextOutA2) ;
			  else
				  SetDlgItemText( hDlg , IDC_EXTTEXTOUTA , pData->sBufExtTextOutA) ;
				break ;
		  case WM_TEXTOUTA:
			  if(wParam == CMD_USE2)
				  SetDlgItemText( hDlg , IDC_TEXTOUTA , pData->sBufTextOutA2) ;
			  else
				  SetDlgItemText( hDlg , IDC_TEXTOUTA , pData->sBufTextOutA) ;
				break ;
		  case WM_EXTTEXTOUTW :
			  if(wParam == CMD_USE2)
				  SetDlgItemText( hDlg , IDC_EXTTEXTOUTW , pData->sBufExtTextOutW2) ;
			  else
				  SetDlgItemText( hDlg , IDC_EXTTEXTOUTW , pData->sBufExtTextOutW) ;
				break ;
		  case WM_TEXTOUTW:
			  if(wParam == CMD_USE2)
				  SetDlgItemText( hDlg , IDC_TEXTOUTW , pData->sBufTextOutW2) ;
			  else
				  SetDlgItemText( hDlg , IDC_TEXTOUTW , pData->sBufTextOutW) ;

				break ;

		  case WM_MOUSEPT:
				wsprintf(buffer , "Mouse point : X=%3d,Y=%3d" , pData->tMouseP.x , pData->tMouseP.y);
				SetDlgItemText( hDlg , IDC_MOUSEXY , buffer ) ;
				break ;
	}
	return FALSE ;	 
}

BOOL
RegisterMousePointWindow(void)
{
	 WNDCLASS wc;

	 // prepare to register the class for the main window
	 wc.style         = 0 ; //CS_HREDRAW | CS_VREDRAW;
	 wc.lpfnWndProc   = (WNDPROC)MouseWndProc;
	 wc.cbClsExtra    = 0;
	 wc.cbWndExtra    = 0;
	 wc.hInstance     = HInstance;
	 wc.hIcon         = NULL ;
	 wc.hCursor       = NULL ;
	 wc.hbrBackground = NULL ; //(HBRUSH)GetStockObject(WHITE_BRUSH);
	 wc.lpszMenuName  = NULL;
	 wc.lpszClassName = szMousePointWindowName;

	 // register the class for the main window
	 if( ! RegisterClass( &wc ) )
		  return FALSE;

	 return TRUE;
}

int PASCAL WinMain( HANDLE hInstance,  HANDLE hPrevInstance,
						  LPSTR lpszCmdLine, int nCmdShow)

{

	 HInstance = hInstance;
	 if ( hPrevInstance ){
		  TextHookError("can only be run once");
		  return 0;
	 }
	 if ( !RegisterMousePointWindow()){
		 return 0;
	 }

	 Ctl3dRegister(hInstance);
	 Ctl3dAutoSubclass(hInstance);
	 DialogBox( HInstance, MAKEINTRESOURCE(TEXTHOOK), NULL, TextHookDialogProc);
	 Ctl3dUnregister(hInstance);
	 UnregisterClass(szMousePointWindowName,hInstance);
	 return 0;
}
