#ifndef __TEXT_HOOK_H
#define __TEXT_HOOK_H

#define     MAX_PATH_LENGTH             144

#define WM_TEXTHOOK_EXCEPTION        WM_USER + 0x201

#define WM_EXTTEXTOUTA WM_USER + 0x202
#define WM_EXTTEXTOUTW WM_USER + 0x203
#define WM_TEXTOUTA WM_USER + 0x204
#define WM_TEXTOUTW WM_USER + 0x205
#define WM_MOUSEPT WM_USER + 0x206
#define WM_SHUTDOWN WM_USER + 0x209

#define CMD_USE2 2
#define CMD_USE1 1

#define MAPFILENAME "GUIHOOKNT.SHARE"

typedef BOOL(WINAPI *__TextOut)(HDC, int , int , LPCSTR,int);
typedef BOOL(WINAPI *__ExtTextOut)(HDC , int, int , UINT ,const RECT *, LPCSTR , UINT , int*);

typedef struct __long_jmp {
	ULONG JmpOp ;
	LPVOID Addr ;
} TLongJmp ;

#define JMPMYCODESIZE  sizeof(TLongJmp)

#define TEXT_BUF_SIZE 128
typedef struct {
	UINT DLLRef ;	
	// For old API address :
	__TextOut TextOutA;
	__TextOut TextOutW;	
	__ExtTextOut ExtTextOutA;
	__ExtTextOut ExtTextOutW;
	//For Hook handle
	HHOOK hMouseHook;
	HHOOK hCBTHook;
	DWORD hCurTask ;	
	HWND HTextHookWnd;

	//For timer
	int wTimePassed;

	// For finger process
	BOOL bReadyToGetText;
	BOOL bIntercept ;
	// If bTraceMouse is true , then , i will catch the
	// text under the mouse point .
	// Refered by MyExtTextOut , MyTextOut
	BOOL bTraceMouse ;

	HWND hWndMouse;

	//For the mouse point
	POINT tMouseP;
	POINT tDnyPt ;
	
	char FAR  OldCodeExtTextOutA [10] ;
	char FAR  OldCodeExtTextOutW [10] ;
	char FAR  OldCodeTextOutA [10] ;
	char FAR  OldCodeTextOutW [10] ;


	char sBufTextOutA[TEXT_BUF_SIZE];
	char sBufExtTextOutA[TEXT_BUF_SIZE];
	char sBufTextOutW[TEXT_BUF_SIZE];
	char sBufExtTextOutW[TEXT_BUF_SIZE];

	char sBufTextOutA2[TEXT_BUF_SIZE];
	char sBufExtTextOutA2[TEXT_BUF_SIZE];
	char sBufTextOutW2[TEXT_BUF_SIZE];
	char sBufExtTextOutW2[TEXT_BUF_SIZE];

	BOOL bIgrExtTextOutA;
	BOOL bIgrTextOutA ;
	BOOL bIgrExtTextOutW;
	BOOL bIgrTextOutW ;

} TShareData , *PTShareData ;
#define szMousePointWindowName  "MOUSEPOINT"
#define SHMEMSIZE sizeof(TShareData)
#define SHAREMEMSIZE SHMEMSIZE
#define ShutdownInterruptHandler()
#define GetCurrentTask GetCurrentProcessId

#define FUNC_EXTTEXTOUTA 1
#define FUNC_TEXTOUTA 2
#define FUNC_EXTTEXTOUTW 3
#define FUNC_TEXTOUTW 4

#endif

