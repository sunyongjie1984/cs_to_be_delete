//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GUIHOOKNT.rc
//
#define TEXTHOOK                        101
#define IDC_IGNORE1                     1001
#define IDC_EXTTEXTOUT                  1002
#define IDC_EXTTEXTOUTA                 1002
#define IDC_IGNORE2                     1003
#define IDC_TEXTOUT                     1004
#define IDC_TEXTOUTA                    1004
#define IDC_IGNORE3                     1005
#define IDC_COMMAND                     1006
#define IDC_COMMAND2                    1007
#define IDC_MOUSEXY                     1008
#define IDC_EXTTEXTOUTW                 1009
#define IDC_IGNORE4                     1010
#define IDC_TEXTOUTW                    1011
#define IDC_EMAIL                       1012
#define IDC_WWW                         1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
