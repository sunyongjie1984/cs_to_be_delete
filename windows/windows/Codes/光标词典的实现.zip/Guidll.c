/*************************************************
* 	Copyrights , 1997 ,CompTech , TaoChen
*  Email : tchen@Venus.sui.ustc.edu.cn
*************************************************/
#include <windows.h>
#include <string.h>
#include "texthook.h"
#include "resource.h"
#include "guidll.h"

/*
Nop			| 90
Nop			| 90
Nop			| 90
Jmp XXXX    | E9 XXXXXXXX
*/

//For Hook handle
#pragma data_seg(".shdata")
static HHOOK hMouseHook= NULL;
static HWND hWndMouse = NULL;
#pragma data_seg()

#define JMPOPCODE 0xE9909090L 

#define GetShareMem(lpMem) {\
	hMapFile = OpenFileMapping(FILE_MAP_WRITE , FALSE , MAPFILENAME); \
	if ( hMapFile == NULL){ \
		Say("Can not open file mapping!"); \
		lpMem = NULL ; \
	}else{ \
		lpMem = (PTShareData)MapViewOfFile(hMapFile , FILE_MAP_WRITE , 0, 0 ,SHAREMEMSIZE); \
		if ( lpMem==NULL){\
			Say("Failed to get share memory !");\
		}\
	}\
	}
#define FreeShareMem(lpMem) { \
	if ( hMapFile == NULL ){ \
		Say("Bug found !");\
	}else{\
		UnmapViewOfFile(lpMem); \
		CloseHandle(hMapFile);\
		lpMem = NULL ;\
	}}


#define AdjustSize(nBytes) (nBytes>TEXT_BUF_SIZE?TEXT_BUF_SIZE:nBytes)
BOOL
InstallProbeTextOutA(void);
BOOL
UninstallProbeTextOutA(void);
BOOL
InstallProbeTextOutW(void);
BOOL
UninstallProbeTextOutW(void);
BOOL
InstallProbeExtTextOutA(void);
BOOL
UninstallProbeExtTextOutA(void);
BOOL
InstallProbeExtTextOutW(void);
BOOL
UninstallProbeExtTextOutW(void);

void CALLBACK
MyTimerProc(HWND hWnd,UINT msg, UINT idTimer, DWORD dwTime) ;

#define	Say(msg) 
//MessageBox(NULL , msg , "What" ,MB_OK)
#define	Say2(msg) MessageBox(NULL , msg , "Error unloading !" ,MB_OK)
 
BOOL APIENTRY DllMain( HANDLE hModule, 
                        DWORD ul_reason_for_call, 
                        LPVOID lpReserved )
{
PTShareData pData=NULL;
HANDLE hMapFile =NULL;
char sRef[32];
char sTmp[256];

	switch( ul_reason_for_call ) {
		case DLL_PROCESS_ATTACH:
			GetShareMem(pData);
			if(pData==NULL){
				// OS load this , by pass .
			}else{
				pData->DLLRef++;
				FreeShareMem(pData);
			}
			break;

		case DLL_PROCESS_DETACH:

		
			GetShareMem(pData);
			if( pData!=NULL){
				pData->DLLRef--;
				if(!UninstallProbes()){
					GetModuleFileName(NULL,sTmp,256);
					Say2(sTmp);
					ExitProcess(0);
				}
				/*GetModuleFileName(NULL,sTmp,256);
				wsprintf(sRef ,"%d" , pData->DLLRef);
				lstrcat(sTmp,sRef);
				Say2(sTmp);
				*/
				if(pData->DLLRef ==1)
					PostMessage(pData->HTextHookWnd , WM_SHUTDOWN , 0 ,0);
				FreeShareMem(pData);
			}
			break;
	}
    return TRUE;
}

BOOL WINAPI
MyTextOutA(HDC hdc, int nXStart, int nYStart, LPCSTR lpszString,int cbString)
{
	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;

	BOOL bRet ;
	POINT hdcPt2 ;
	POINT tMouseP , tTmpP;
	int nBytes ;
	SIZE tSize;
	nBytes = AdjustSize(cbString);
	//MessageBeep(0);
	
	// Restore the old code first
	UninstallProbeTextOutA() ;

	GetShareMem(pData);

	if( pData == NULL ){
		goto __DIRECT_SHOW;
	}
	// Show text in dialog box
	// Bypass if current task is TextHook
	if ( GetCurrentTask () != pData->hCurTask ){
		lstrcpyn(pData->sBufTextOutA ,lpszString,nBytes);
		pData->sBufTextOutA[nBytes]= 0;

	if ( pData->bTraceMouse == TRUE ) {
		if ( pData->bReadyToGetText == TRUE ) {
			int x1 , x2 , y1 , y2 ;

			GetDCOrgEx(hdc , &tTmpP);

			hdcPt2.x = nXStart;
			hdcPt2.y = nYStart;

			LPtoDP(hdc,(POINT FAR *)&hdcPt2,1);

			GetCursorPos(&tMouseP);

			x1 = tMouseP.x ;
			y1 = tMouseP.y ;

			x2 = hdcPt2.x+ tTmpP.x ;
			y2 = hdcPt2.y+ tTmpP.y ;

			GetCurrentPositionEx(hdc ,&tTmpP);

			if ( GetTextAlign(hdc ) & TA_UPDATECP ){
					GetCurrentPositionEx(hdc ,&tTmpP );
					x2 += tTmpP.x;
					y2 += tTmpP.y;
				}
				GetTextExtentPoint(hdc,lpszString, cbString,&tSize ) ;

				if((x1 >= x2)&&(x1<= x2 +tSize.cx) &&
					(y1 >= y2)&&(y1<= y2+ tSize.cy)){
					pData->wTimePassed = -1;
					pData->bReadyToGetText = FALSE;
					lstrcpyn(pData->sBufTextOutA2 ,lpszString,nBytes);
					pData->sBufTextOutA2[nBytes]= 0;
					PostMessage(pData->HTextHookWnd, WM_TEXTOUTA, CMD_USE2 , 0 );
				}
			}
		}else{
			PostMessage(pData->HTextHookWnd, WM_TEXTOUTA , CMD_USE1 , 0);
		}
	}
	
// Then call old TextOutA to show text
	if ((pData->bIgrTextOutA == FALSE ) || ( GetCurrentTask () == pData->hCurTask ) ){
		if (pData->TextOutA!=NULL)
			bRet = pData->TextOutA(hdc, nXStart, nYStart, lpszString, cbString);
	}else{
		bRet = TRUE ;
	}
	FreeShareMem(pData);
// intercept TextOutA again
	__DIRECT_SHOW:
	InstallProbeTextOutA() ;
	

//return
	return bRet;
}

BOOL WINAPI
MyTextOutW(HDC hdc, int nXStart, int nYStart, LPCSTR lpszString,int cbString)
{
	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;

	BOOL bRet ;
	POINT hdcPt2 ;
	//DWORD dwExtent;
	POINT tMouseP , tTmpP;
	int nBytes ;
	SIZE tSize;
	nBytes = AdjustSize(cbString);
	//MessageBeep(0);	
	// Restore the old code first
	UninstallProbeTextOutW() ;
	
	GetShareMem(pData);
	if( pData == NULL ){
		//???
		goto __DIRECT_RETURN;
	}
	// Show text in dialog box
	// Bypass if current task is TextHook
	if ( GetCurrentTask() != pData->hCurTask ){
	WideCharToMultiByte(CP_ACP ,0,lpszString,nBytes,
    pData->sBufTextOutW,nBytes,NULL,NULL); 
	//	wcstombs(pData->sBufTextOutW  ,lpszString, nBytes );
		pData->sBufTextOutW[nBytes]= 0;

	if ( pData->bTraceMouse == TRUE ) {
		if ( pData->bReadyToGetText == TRUE ) {
			int x1 , x2 , y1 , y2 ;

			GetDCOrgEx(hdc , &tTmpP);

			hdcPt2.x = nXStart;
			hdcPt2.y = nYStart;

			LPtoDP(hdc,(POINT FAR *)&hdcPt2,1);

			GetCursorPos(&tMouseP);

			x1 = tMouseP.x ;
			y1 = tMouseP.y ;

			x2 = hdcPt2.x+ tTmpP.x ;
			y2 = hdcPt2.y+ tTmpP.y ;

			GetCurrentPositionEx(hdc ,&tTmpP);

			if ( GetTextAlign(hdc ) & TA_UPDATECP ){
					GetCurrentPositionEx(hdc ,&tTmpP );
					x2 += tTmpP.x;
					y2 += tTmpP.y;
				}
				GetTextExtentPoint(hdc,lpszString, cbString,&tSize ) ;

				if((x1 >= x2)&&(x1<= x2 +tSize.cx) &&
					(y1 >= y2)&&(y1<= y2+ tSize.cy)){
					pData->wTimePassed = -1;
					pData->bReadyToGetText = FALSE;
					WideCharToMultiByte(CP_ACP ,0,lpszString,nBytes,
						pData->sBufTextOutW2,nBytes,NULL,NULL); 

					//wcstombs(pData->sBufTextOutW2  ,lpszString, nBytes );
					//lstrcpyn(pData->sBufTextOutW2 ,lpszString,nBytes);
					pData->sBufTextOutW2[nBytes]= 0;
					PostMessage(pData->HTextHookWnd, WM_TEXTOUTW, CMD_USE2 , 0 );
				}
			}
		}else{
			PostMessage(pData->HTextHookWnd, WM_TEXTOUTW , CMD_USE1 , 0);
		}
	}
	


// Then call old TextOutW to show text
	if ((pData->bIgrTextOutW == FALSE ) || ( GetCurrentTask() == pData->hCurTask ) ){
		if (pData->TextOutW!=NULL)
			bRet = pData->TextOutW(hdc, nXStart, nYStart, lpszString, cbString);
	}else{
		bRet = TRUE ;
	}

	FreeShareMem(pData);
__DIRECT_RETURN:

// intercept TextOutW again
	InstallProbeTextOutW() ;

//return
	return bRet;
}

BOOL WINAPI
MyExtTextOutW(HDC hdc, int nXStart, int nYStart, UINT fuOptions,
			  const RECT FAR *lprc, LPCSTR lpszString,
			  UINT cbString,
			  int FAR *lpDx)

{
	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;
	BOOL bRet ;
	POINT hdcPt2 ;
	POINT tMouseP , tTmpP;
	int nBytes ;
	SIZE tSize;
	nBytes = AdjustSize(cbString);
	
	// Restore the old code first
	UninstallProbeExtTextOutW() ;
	
	GetShareMem(pData);
	if( pData == NULL ){
		//???
		goto __DIRECT_RETURN;
	}
	// Show text in dialog box
	// Bypass if current task is TextHook
	if ( GetCurrentTask() != pData->hCurTask ){
		WideCharToMultiByte(CP_ACP ,0,lpszString,nBytes,
				pData->sBufExtTextOutW,nBytes,NULL,NULL); 
		pData->sBufExtTextOutW[nBytes]= 0;

	if ( pData->bTraceMouse == TRUE ) {
		if ( pData->bReadyToGetText == TRUE ) {
			int x1 , x2 , y1 , y2 ;

			GetDCOrgEx(hdc , &tTmpP);

			hdcPt2.x = nXStart;
			hdcPt2.y = nYStart;

			LPtoDP(hdc,(POINT FAR *)&hdcPt2,1);

			GetCursorPos(&tMouseP);

			x1 = tMouseP.x ;
			y1 = tMouseP.y ;

			x2 = hdcPt2.x+ tTmpP.x ;
			y2 = hdcPt2.y+ tTmpP.y ;

			GetCurrentPositionEx(hdc ,&tTmpP);

			if ( GetTextAlign(hdc ) & TA_UPDATECP ){
					GetCurrentPositionEx(hdc ,&tTmpP );
					x2 += tTmpP.x;
					y2 += tTmpP.y;
				}
				GetTextExtentPoint(hdc,lpszString, cbString,&tSize ) ;

				if((x1 >= x2)&&(x1<= x2 +tSize.cx) &&
					(y1 >= y2)&&(y1<= y2+ tSize.cy)){
					pData->wTimePassed = -1;
					pData->bReadyToGetText = FALSE;
					WideCharToMultiByte(CP_ACP ,0,lpszString,nBytes,
							pData->sBufExtTextOutW2,nBytes,NULL,NULL); 
					pData->sBufExtTextOutW2[nBytes]= 0;	
					PostMessage(pData->HTextHookWnd, WM_EXTTEXTOUTW, CMD_USE2 , 0 );
				}
			}
		}else{
			PostMessage(pData->HTextHookWnd, WM_EXTTEXTOUTW , CMD_USE1 , 0);
		}
	}
	


// Then call old ExtTextOutA to show text
	if ((pData->bIgrExtTextOutW == FALSE ) || ( GetCurrentTask() == pData->hCurTask ) ){
		if (pData->ExtTextOutW!=NULL)
			bRet = pData->ExtTextOutW(hdc, nXStart, nYStart, fuOptions , lprc , lpszString, cbString ,lpDx );
	}else{
		bRet = TRUE ;
	}

	FreeShareMem(pData);
__DIRECT_RETURN:

// intercept ExtTextOutW again
	InstallProbeExtTextOutW() ;

//return
	return bRet;

}

BOOL WINAPI
MyExtTextOutA(HDC hdc, int nXStart, int nYStart, UINT fuOptions,
			  const RECT FAR *lprc, LPCSTR lpszString,
			  UINT cbString,
			  int FAR *lpDx)

{
	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;
	BOOL bRet ;
	POINT hdcPt2 ;
	POINT tMouseP , tTmpP;
	int nBytes ;
	SIZE tSize;
	nBytes = AdjustSize(cbString);
	
	// Restore the old code first
	UninstallProbeExtTextOutA() ;
	
	GetShareMem(pData);
	if( pData == NULL ){
		//???
		goto __DIRECT_RETURN;
	}
	// Show text in dialog box
	// Bypass if current task is TextHook
	if ( GetCurrentTask() != pData->hCurTask ){
		lstrcpyn(pData->sBufExtTextOutA,lpszString , nBytes);
		pData->sBufExtTextOutA[nBytes]= 0;

	if ( pData->bTraceMouse == TRUE ) {
		if ( pData->bReadyToGetText == TRUE ) {
			int x1 , x2 , y1 , y2 ;

			GetDCOrgEx(hdc , &tTmpP);

			hdcPt2.x = nXStart;
			hdcPt2.y = nYStart;

			LPtoDP(hdc,(POINT FAR *)&hdcPt2,1);

			GetCursorPos(&tMouseP);

			x1 = tMouseP.x ;
			y1 = tMouseP.y ;

			x2 = hdcPt2.x+ tTmpP.x ;
			y2 = hdcPt2.y+ tTmpP.y ;

			GetCurrentPositionEx(hdc ,&tTmpP);

			if ( GetTextAlign(hdc ) & TA_UPDATECP ){
					GetCurrentPositionEx(hdc ,&tTmpP );
					x2 += tTmpP.x;
					y2 += tTmpP.y;
				}
				GetTextExtentPoint(hdc,lpszString, cbString,&tSize ) ;

				if((x1 >= x2)&&(x1<= x2 +tSize.cx) &&
					(y1 >= y2)&&(y1<= y2+ tSize.cy)){
					pData->wTimePassed = -1;
					pData->bReadyToGetText = FALSE;
					lstrcpyn(pData->sBufExtTextOutA2,lpszString , nBytes+1);
					pData->sBufExtTextOutA2[nBytes+1]= 0;	
					PostMessage(pData->HTextHookWnd, WM_EXTTEXTOUTA, CMD_USE2 , 0 );
				}
			}
		}else{
			PostMessage(pData->HTextHookWnd, WM_EXTTEXTOUTA , CMD_USE1 , 0);
		}
	}
	


// Then call old ExtTextOutA to show text
	if ((pData->bIgrExtTextOutA == FALSE ) || ( GetCurrentTask() == pData->hCurTask ) ){
		if (pData->ExtTextOutA!=NULL)
			bRet = pData->ExtTextOutA(hdc, nXStart, nYStart, fuOptions , lprc , lpszString, cbString ,lpDx );
	}else{
		bRet = TRUE ;
	}

	FreeShareMem(pData);
__DIRECT_RETURN:

// intercept ExtTextOutA again
	InstallProbeExtTextOutA() ;

//return
	return bRet;

}

BOOL
InstallProbes(void)
{
 
	if ( !InstallProbeExtTextOutA())
		return FALSE ;

	if ( !InstallProbeExtTextOutW())
		return FALSE ;

	if ( !InstallProbeTextOutA())
		return FALSE ;
	if ( !InstallProbeTextOutW())
		return FALSE ;
	return TRUE;
}

BOOL
UninstallProbes(void)
{
	if(!UninstallProbeExtTextOutA())
		return FALSE ;
	
	if(!UninstallProbeExtTextOutW())
		return FALSE;
	
	if(!UninstallProbeTextOutA())
		return FALSE ;
	
	if(!UninstallProbeTextOutW())
		return FALSE;
	return TRUE;
}

BOOL
InstallProbeTextOutA(void)
{
	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;
	TLongJmp Jmp2Me ;
	DWORD dwPro ;
	DWORD nWriten;
	MEMORY_BASIC_INFORMATION memInfo ;
	DWORD dwOldProtect;
	DWORD dwOldProtect2;
	
	GetShareMem(pData);

	if ( pData==NULL){
		return FALSE;
	}
	
	memset ( &memInfo , 0 , sizeof(MEMORY_BASIC_INFORMATION));

	dwPro = VirtualQuery(pData->TextOutA , &memInfo ,sizeof(MEMORY_BASIC_INFORMATION) );
	
	if ( dwPro != sizeof(MEMORY_BASIC_INFORMATION) ){
		return FALSE ;
	}

	if (!VirtualProtect(pData->TextOutA , JMPMYCODESIZE , PAGE_EXECUTE_WRITECOPY , &dwOldProtect )){
		Say("Can not change the memory RW flag!");
		return FALSE ;
	}
	
	Jmp2Me.JmpOp = JMPOPCODE ;
	Jmp2Me.Addr  = (LPVOID)( (LONG)MyTextOutA - (LONG)pData->TextOutA -JMPMYCODESIZE) ;

	if(!WriteProcessMemory(GetCurrentProcess(),pData->TextOutA, &Jmp2Me , JMPMYCODESIZE ,&nWriten)){
		FreeShareMem(pData);
		//Say("Write failed!");
		return FALSE;
	}

	VirtualProtect(pData->TextOutA , JMPMYCODESIZE , dwOldProtect , &dwOldProtect2  );
	FreeShareMem(pData);
	return TRUE;
}

BOOL
UninstallProbeTextOutA(void)
{

	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;
	DWORD dwPro ;
	DWORD nWriten;
	MEMORY_BASIC_INFORMATION memInfo ;
	DWORD dwOldProtect;
	DWORD dwOldProtect2;

	GetShareMem(pData);

	if ( pData==NULL){
		return FALSE;
	}
	
	memset ( &memInfo , 0 , sizeof(MEMORY_BASIC_INFORMATION));

	dwPro = VirtualQuery(pData->TextOutA , &memInfo ,sizeof(MEMORY_BASIC_INFORMATION) );
	
	if ( dwPro != sizeof(MEMORY_BASIC_INFORMATION) ){
		return FALSE ;
	}

	if (!VirtualProtect(pData->TextOutA , JMPMYCODESIZE , PAGE_EXECUTE_WRITECOPY , &dwOldProtect )){
		Say("Can not change the memory RW flag!");
		return FALSE ;
	}
	
	if(!WriteProcessMemory(GetCurrentProcess(),pData->TextOutA,pData->OldCodeTextOutA, JMPMYCODESIZE ,&nWriten)){
		FreeShareMem(pData);
		//Say("Write failed!");
		return FALSE;
	}

	VirtualProtect(pData->TextOutA , JMPMYCODESIZE , dwOldProtect , &dwOldProtect2  );
	FreeShareMem(pData);
	return TRUE;
}


BOOL
InstallProbeTextOutW(void)
{
	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;
	TLongJmp Jmp2Me ;
	DWORD dwPro ;
	DWORD nWriten;
	MEMORY_BASIC_INFORMATION memInfo ;
	DWORD dwOldProtect;
	DWORD dwOldProtect2;

	GetShareMem(pData);

	if ( pData==NULL){
		return FALSE;
	}
	
	memset ( &memInfo , 0 , sizeof(MEMORY_BASIC_INFORMATION));

	dwPro = VirtualQuery(pData->TextOutW , &memInfo ,sizeof(MEMORY_BASIC_INFORMATION) );
	
	if ( dwPro != sizeof(MEMORY_BASIC_INFORMATION) ){
		return FALSE ;
	}

	if (!VirtualProtect(pData->TextOutW , JMPMYCODESIZE , PAGE_EXECUTE_WRITECOPY , &dwOldProtect )){
		Say("Can not change the memory RW flag!");
		return FALSE ;
	}
	
	Jmp2Me.JmpOp = JMPOPCODE ;
	Jmp2Me.Addr = (LPVOID)((LONG)MyTextOutW - (LONG)pData->TextOutW - JMPMYCODESIZE) ;

	if(!WriteProcessMemory(GetCurrentProcess(),pData->TextOutW, &Jmp2Me , JMPMYCODESIZE ,&nWriten)){
		FreeShareMem(pData);
		//Say("Write failed!");
		return FALSE;
	}

	VirtualProtect(pData->TextOutW , JMPMYCODESIZE , dwOldProtect , &dwOldProtect2  );
	FreeShareMem(pData);
	return TRUE;
}

BOOL
UninstallProbeTextOutW(void)
{

	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;
	DWORD dwPro ;
	DWORD nWriten;
	MEMORY_BASIC_INFORMATION memInfo ;
	DWORD dwOldProtect;
	DWORD dwOldProtect2;

	GetShareMem(pData);

	if ( pData==NULL){
		return FALSE;
	}
	
	memset ( &memInfo , 0 , sizeof(MEMORY_BASIC_INFORMATION));

	dwPro = VirtualQuery(pData->TextOutW , &memInfo ,sizeof(MEMORY_BASIC_INFORMATION) );
	
	if ( dwPro != sizeof(MEMORY_BASIC_INFORMATION) ){
		return FALSE ;
	}

	if (!VirtualProtect(pData->TextOutW , JMPMYCODESIZE , PAGE_EXECUTE_WRITECOPY , &dwOldProtect )){
		Say("Can not change the memory RW flag!");
		return FALSE ;
	}
	
	if(!WriteProcessMemory(GetCurrentProcess(),pData->TextOutW,pData->OldCodeTextOutW, JMPMYCODESIZE ,&nWriten)){
		FreeShareMem(pData);
		//Say("Write failed!");
		return FALSE;
	}

	VirtualProtect(pData->TextOutW , JMPMYCODESIZE , dwOldProtect , &dwOldProtect2  );
	FreeShareMem(pData);
	return TRUE;
}

BOOL
InstallProbeExtTextOutW(void)
{
	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;
	TLongJmp Jmp2Me ;
	DWORD dwPro ;
	DWORD nWriten;
	MEMORY_BASIC_INFORMATION memInfo ;
	DWORD dwOldProtect;
	DWORD dwOldProtect2;

	GetShareMem(pData);

	if ( pData==NULL){
		return FALSE;
	}
	
	memset ( &memInfo , 0 , sizeof(MEMORY_BASIC_INFORMATION));

	dwPro = VirtualQuery(pData->ExtTextOutW , &memInfo ,sizeof(MEMORY_BASIC_INFORMATION) );
	
	if ( dwPro != sizeof(MEMORY_BASIC_INFORMATION) ){
		return FALSE ;
	}

	if (!VirtualProtect(pData->ExtTextOutW , JMPMYCODESIZE , PAGE_EXECUTE_WRITECOPY , &dwOldProtect )){
		Say("Can not change the memory RW flag!");
		return FALSE ;
	}
	
	Jmp2Me.JmpOp = JMPOPCODE ;
	Jmp2Me.Addr = (LPVOID)((LONG)MyExtTextOutW - (LONG)pData->ExtTextOutW - JMPMYCODESIZE) ;

	if(!WriteProcessMemory(GetCurrentProcess(),pData->ExtTextOutW, &Jmp2Me , JMPMYCODESIZE ,&nWriten)){
		FreeShareMem(pData);
		//Say("Write failed!");
		return FALSE;
	}

	VirtualProtect(pData->ExtTextOutW , JMPMYCODESIZE , dwOldProtect , &dwOldProtect2  );
	FreeShareMem(pData);
	return TRUE;
}

BOOL
UninstallProbeExtTextOutW(void)
{

	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;
	DWORD dwPro ;
	DWORD nWriten;
	MEMORY_BASIC_INFORMATION memInfo ;
	DWORD dwOldProtect;
	DWORD dwOldProtect2;

	GetShareMem(pData);

	if ( pData==NULL){
		return FALSE;
	}
	
	memset ( &memInfo , 0 , sizeof(MEMORY_BASIC_INFORMATION));

	dwPro = VirtualQuery(pData->ExtTextOutW , &memInfo ,sizeof(MEMORY_BASIC_INFORMATION) );
	
	if ( dwPro != sizeof(MEMORY_BASIC_INFORMATION) ){
		return FALSE ;
	}

	if (!VirtualProtect(pData->ExtTextOutW , JMPMYCODESIZE , PAGE_EXECUTE_WRITECOPY , &dwOldProtect )){
		Say("Can not change the memory RW flag!");
		return FALSE ;
	}
	
	if(!WriteProcessMemory(GetCurrentProcess(),pData->ExtTextOutW,pData->OldCodeExtTextOutW, JMPMYCODESIZE ,&nWriten)){
		FreeShareMem(pData);
		//Say("Write failed!");
		return FALSE;
	}

	VirtualProtect(pData->ExtTextOutW , JMPMYCODESIZE , dwOldProtect , &dwOldProtect2  );
	FreeShareMem(pData);
	return TRUE;
}

BOOL
InstallProbeExtTextOutA(void)
{
	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;
	TLongJmp Jmp2Me ;
	DWORD dwPro ;
	DWORD nWriten;
	MEMORY_BASIC_INFORMATION memInfo ;
	DWORD dwOldProtect;
	DWORD dwOldProtect2;

	GetShareMem(pData);

	if ( pData==NULL){
		return FALSE;
	}
	
	memset ( &memInfo , 0 , sizeof(MEMORY_BASIC_INFORMATION));

	dwPro = VirtualQuery(pData->ExtTextOutA , &memInfo ,sizeof(MEMORY_BASIC_INFORMATION) );
	
	if ( dwPro != sizeof(MEMORY_BASIC_INFORMATION) ){
		return FALSE ;
	}

	if (!VirtualProtect(pData->ExtTextOutA , JMPMYCODESIZE , PAGE_EXECUTE_WRITECOPY , &dwOldProtect )){
		Say("Can not change the memory RW flag!");
		return FALSE ;
	}
	
	Jmp2Me.JmpOp = JMPOPCODE ;
	Jmp2Me.Addr = (LPVOID)((LONG)MyExtTextOutA - (LONG)pData->ExtTextOutA - JMPMYCODESIZE) ;

	if(!WriteProcessMemory(GetCurrentProcess(),pData->ExtTextOutA, &Jmp2Me , JMPMYCODESIZE ,&nWriten)){
		FreeShareMem(pData);
		//Say("Write failed!");
		return FALSE;
	}

	VirtualProtect(pData->ExtTextOutA , JMPMYCODESIZE , dwOldProtect , &dwOldProtect2  );
	FreeShareMem(pData);
	return TRUE;
}

BOOL
UninstallProbeExtTextOutA(void)
{

	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;
	DWORD dwPro ;
	DWORD nWriten;
	MEMORY_BASIC_INFORMATION memInfo ;
	DWORD dwOldProtect;
	DWORD dwOldProtect2;

	GetShareMem(pData);

	if ( pData==NULL){
		return FALSE;
	}
	
	memset ( &memInfo , 0 , sizeof(MEMORY_BASIC_INFORMATION));

	dwPro = VirtualQuery(pData->ExtTextOutA , &memInfo ,sizeof(MEMORY_BASIC_INFORMATION) );
	
	if ( dwPro != sizeof(MEMORY_BASIC_INFORMATION) ){
		return FALSE ;
	}

	if (!VirtualProtect(pData->ExtTextOutA , JMPMYCODESIZE , PAGE_EXECUTE_WRITECOPY , &dwOldProtect )){
		Say("Can not change the memory RW flag!");
		return FALSE ;
	}
	
	if(!WriteProcessMemory(GetCurrentProcess(),pData->ExtTextOutA,pData->OldCodeExtTextOutA, JMPMYCODESIZE ,&nWriten)){
		FreeShareMem(pData);
		//Say("Write failed!");
		return FALSE;
	}

	VirtualProtect(pData->ExtTextOutA , JMPMYCODESIZE , dwOldProtect , &dwOldProtect2  );
	FreeShareMem(pData);
	return TRUE;
}

BOOL
InstallMouseHook(HINSTANCE hInst)
{
	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;
	// Install the windows hook
	GetShareMem(pData);
	if ( pData==NULL){
		return FALSE;
	}

	hMouseHook = SetWindowsHookEx( WH_MOUSE , (HOOKPROC)MyMouseProc , GetModuleHandle("GUIDLLNT.DLL") , 0 );

	if ( hMouseHook == NULL){
		return FALSE;
	}

	 // create the main window
	 pData->hWndMouse = CreateWindowEx(
		  WS_EX_TOPMOST ,
		  szMousePointWindowName,
		  szMousePointWindowName,
		  WS_CLIPSIBLINGS | WS_POPUP ,
		  0, 0,1,8,
		  NULL,
		  NULL,
		  hInst,
		  NULL );

	 if( pData->hWndMouse == NULL )
		  return FALSE;

	 SetTimer(NULL, 1, 10 , MyTimerProc);

	 // display the mouse window
	 ShowWindow( pData->hWndMouse, SW_HIDE);
	 UpdateWindow(pData->hWndMouse);
	 pData->bTraceMouse = TRUE ;
	 FreeShareMem(pData);
	 return TRUE ;

}

BOOL 
UninstallMouseHook()
{
	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;

	GetShareMem(pData);
	if ( pData==NULL){
		UnhookWindowsHookEx( hMouseHook);
		return FALSE;
	}

	// Unregister Windows hook .
	pData->bTraceMouse= FALSE ;
	KillTimer(NULL,1);
	DestroyWindow(pData->hWndMouse);
	FreeShareMem(pData);

	return UnhookWindowsHookEx( hMouseHook);
}

LRESULT CALLBACK
MyMouseProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	LPMOUSEHOOKSTRUCT lpMouseHookStruct;
	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;
	char *szTmp ;
	GetShareMem(pData);
	if ( pData==NULL){
		return CallNextHookEx(hMouseHook, nCode,	wParam, lParam);
	}

	szTmp =(char*)pData->TextOutA;
	if(szTmp[0]!=0x90){
		InstallProbes();
	}
	 pData->wTimePassed = 0;

	 if (nCode < 0)  // do not process the message 
		  return CallNextHookEx(hMouseHook, nCode,	wParam, lParam);
	 
 	 if ( wParam == WM_MOUSEMOVE ) {
		pData->wTimePassed = 0;
		lpMouseHookStruct = (LPMOUSEHOOKSTRUCT)lParam;
		GetVersion();
      	if ((pData->tMouseP.x !=lpMouseHookStruct->pt.x)||
			 (pData->tMouseP.y !=lpMouseHookStruct->pt.y )){

			pData->tMouseP.x =lpMouseHookStruct->pt.x ;
			pData->tMouseP.y =lpMouseHookStruct->pt.y ;
			//SetWindowPos(hWndMouse, HWND_TOPMOST , tMouseP.x , tMouseP.y , 1, 1, SWP_NOACTIVATE  );
			//MessageBeep(0);
			
			PostMessage(pData->HTextHookWnd, WM_MOUSEPT, 0 , 0 );
		}
	 }

	 FreeShareMem(pData);
	 return CallNextHookEx(hMouseHook, nCode, wParam,
		  lParam);

}

LRESULT CALLBACK
MouseWndProc( HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam )
{
	 switch( Message )
	 {
		  case WM_CLOSE:
				DestroyWindow( hWnd );
				PostQuitMessage( 0 );
		  break;
 
		  default:
				return DefWindowProc( hWnd, Message, wParam, lParam );
	 }
	 return 0L;
}

void CALLBACK
MyTimerProc(HWND hWnd,UINT msg, UINT idTimer, DWORD dwTime)
{
	PTShareData pData=NULL;
	HANDLE hMapFile =NULL;

	GetShareMem(pData);
	if ( pData==NULL){
		return ;
	}

	if (pData->wTimePassed == -1 ){
		FreeShareMem(pData);
		return ;
	}

	pData->wTimePassed ++ ;
	if ( pData->wTimePassed > 21 ){
		pData->wTimePassed  = 21 ;
		//bReadyToGetText = FALSE ;
		FreeShareMem(pData);
		return ;
	}
	if ( pData->wTimePassed > 20 ){
		// wTimePassed = 0;
		// Can i sure the hWndMouse is always valid ? ;-(
		pData->bReadyToGetText = TRUE ;
		SetWindowPos(pData->hWndMouse, HWND_TOPMOST , pData->tMouseP.x , pData->tMouseP.y , 1, 8, SWP_NOACTIVATE | SWP_SHOWWINDOW);
		ShowWindow(pData->hWndMouse , 0 );
	}
	FreeShareMem(pData);

}
/*

LRESULT CALLBACK 
MyCBTProc(int nCode, WPARAM wParam, LPARAM lParam)
{

    if (nCode < 0)  
        return CallNextHookEx( hCBTHook , nCode, wParam,lParam);

    return CallNextHookEx(hCBTHook, nCode, wParam,
        lParam);
}

*/