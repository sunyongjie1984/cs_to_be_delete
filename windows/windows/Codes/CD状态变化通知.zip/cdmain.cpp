// cdmain.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#include <windowsx.h>
#include <dbt.h>		// Device Management Events


// Finds the first valid drive letter from a mask of drive letters.
// The mask must be in the format bit 0 = A, bit 1 = B, bit 3 = C, etc.
// A valid drive letter is defined when the corresponding bit
// is set to 1. Returns the drive letter that was first found.
//
char chFirstDriveFromMask (ULONG unitmask)
{
	char i;
	for (i = 0; i < 26; ++i)
	{
		if (unitmask & 0x1)
            break;
		unitmask = unitmask >> 1;
	}
    return (i + 'A');
}


// An application-defined callback function aka message pump.
// It processes messages sent to a modal or modeless dialog box.
//
BOOL WINAPI DlgProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	BOOL fRet = TRUE;	// return value.
	// A standard structure for information related to a device
	// event reported through the WM_DEVICECHANGE message.
	//
	PDEV_BROADCAST_HDR lpdb = (PDEV_BROADCAST_HDR)lParam;

	switch (uMsg)
	{

		case WM_INITDIALOG:
				fRet = TRUE; 
				break;

		// WM_DEVICECHANGE notifies an application or device driver of
		// a change to the hardware configuration of a device or the computer.
		//
		case WM_DEVICECHANGE:
				char szMsg[80];	// display message

				switch (wParam)
				{
					// The system broadcasts the DBT_DEVICEARRIVAL device event
					// when a device has been inserted and becomes available.
					//
					case DBT_DEVICEARRIVAL:
							// See if a CD-ROM was inserted into a drive.
							if (lpdb -> dbch_devicetype == DBT_DEVTYP_VOLUME)	// Logical volume
							{
								// A standard structure, contains information about a logical volume.
								//
								PDEV_BROADCAST_VOLUME lpdbv = (PDEV_BROADCAST_VOLUME)lpdb;
								if (lpdbv -> dbcv_flags & DBTF_MEDIA)
								{
									// Display message
									//
									wsprintf (szMsg, "Drive %c: arrived\n", chFirstDriveFromMask(lpdbv ->dbcv_unitmask));
									MessageBox (hwnd, szMsg, "WM_DEVICECHANGE", MB_OK | MB_ICONINFORMATION);
								}
							}
					break;

					// The system broadcasts the DBT_DEVICEREMOVECOMPLETE device event
					// when a device has been removed and becomes unavailable.
					//
					case DBT_DEVICEREMOVECOMPLETE:
							// See if a CD-ROM has been removed from a drive.
							//
							if (lpdb -> dbch_devicetype == DBT_DEVTYP_VOLUME)	// Logical volume
							{	
								// A standard structure, contains information about a logical volume.
								//
								PDEV_BROADCAST_VOLUME lpdbv = (PDEV_BROADCAST_VOLUME)lpdb;
								if (lpdbv -> dbcv_flags & DBTF_MEDIA)
								{
									// Display message
									//
									wsprintf (szMsg, "Drive %c: was removed\n", chFirstDriveFromMask(lpdbv ->dbcv_unitmask));
									MessageBox (hwnd, szMsg, "WM_DEVICECHANGE", MB_OK | MB_ICONINFORMATION);
								}
							}
					break;
				}

		case WM_COMMAND:
			int wmId, wmEvent;

			wmId    = LOWORD(wParam);
			wmEvent = HIWORD(wParam);

			switch (wmId)
			{
				// Button OK selected
				//
				case IDOK:
					EndDialog(hwnd, 0);
					break;
			}

		default:
			fRet = FALSE;
			break;
	}

	// Suppressing AutoPlay
	//
	static UINT uMsgQueryCancelAutoPlay = RegisterWindowMessage("QueryCancelAutoPlay");

	if (uMsg==uMsgQueryCancelAutoPlay)
	{
		int n = MessageBox(hwnd, "Do you wish to cancel AutoPlay?", NULL, MB_YESNO | MB_ICONQUESTION);
		// return 1 to cancel AutoPlay
		// return 0 to allow AutoPlay 
		//
		SetDlgMsgResult(hwnd, uMsg, (n == IDYES) ? 1 : 0);
		fRet = (n == IDYES) ? 1 : 0;
	}

	return(fRet);
}


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	// Create a modal dialog box from a dialog box template resource.
	//
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DlgProc);
	return 0;
}
