// dbarView.cpp : implementation of the CDockbarsView class
//

#include "stdafx.h"
#include "dockbars.h"

#include "dbarDoc.h"
#include "dbarView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////////
// CDockbarsView

IMPLEMENT_DYNCREATE(CDockbarsView, CView)

BEGIN_MESSAGE_MAP(CDockbarsView, CView)
    //{{AFX_MSG_MAP(CDockbarsView)
        // NOTE - the ClassWizard will add and remove mapping macros
        //    DO NOT EDIT what you see in these blocks of generated 
    //}}AFX_MSG_MAP
    // Standard printing commands
    ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
    ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
    ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

////////////////////////////////////////////////////////////////////
// CDockbarsView construction/destruction

CDockbarsView::CDockbarsView()
{
    // TODO: add construction code here

}

CDockbarsView::~CDockbarsView()
{
}

BOOL CDockbarsView::PreCreateWindow(CREATESTRUCT& cs)
{
    // TODO: Modify the Window class or styles here by modifying
    //  the CREATESTRUCT cs

    return CView::PreCreateWindow(cs);
}

////////////////////////////////////////////////////////////////////
// CDockbarsView drawing

void CDockbarsView::OnDraw(CDC* pDC)
{
    CDockbarsDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    // TODO: add draw code for native data here
}

////////////////////////////////////////////////////////////////////
// CDockbarsView printing

BOOL CDockbarsView::OnPreparePrinting(CPrintInfo* pInfo)
{
    // default preparation
    return DoPreparePrinting(pInfo);
}

void CDockbarsView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* )
{
    // TODO: add extra initialization before printing
}

void CDockbarsView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* )
{
    // TODO: add cleanup after printing
}

////////////////////////////////////////////////////////////////////
// CDockbarsView diagnostics

#ifdef _DEBUG
void CDockbarsView::AssertValid() const
{
    CView::AssertValid();
}

void CDockbarsView::Dump(CDumpContext& dc) const
{
    CView::Dump(dc);
}

CDockbarsDoc* CDockbarsView::GetDocument() // non-debug version is i
{
    ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDockbarsDoc)));
    return (CDockbarsDoc*)m_pDocument;
}
#endif //_DEBUG

////////////////////////////////////////////////////////////////////
// CDockbarsView message handlers
