#if !defined AFX_COOLDBAR_H
#define AFX_COOLDBAR_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CoolDockBar.h : header file
//
#include <afxpriv.h>

////////////////////////////////////////////////////////////////////
// CCoolDockBar window

class CCoolDockBar : public CDockBar
{
// Construction
public:
    CCoolDockBar(UINT idb);

// Attributes
public:
    CBitmap m_bitmap;
    CSize m_size;

// Operations
public:

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CCoolDockBar)
    //}}AFX_VIRTUAL
    CSize CalcDynamicLayout(int nLength, DWORD nMode);

// Implementation
public:
    virtual ~CCoolDockBar();

    // Generated message map functions
protected:
    //{{AFX_MSG(CCoolDockBar)
    afx_msg BOOL OnEraseBkgnd(CDC* pDC);
    afx_msg void OnSize(UINT nType, int cx, int cy);
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediat

#endif
