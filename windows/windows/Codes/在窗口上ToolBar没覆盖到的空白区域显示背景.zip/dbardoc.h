// dbarDoc.h : interface of the CDockbarsDoc class
//
////////////////////////////////////////////////////////////////////

#if !defined AFX_DBARDOC_H
#define AFX_DBARDOC_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CDockbarsDoc : public CDocument
{
protected: // create from serialization only
    CDockbarsDoc();
    DECLARE_DYNCREATE(CDockbarsDoc)

// Attributes
public:

// Operations
public:

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CDockbarsDoc)
    public:
    virtual BOOL OnNewDocument();
    virtual void Serialize(CArchive& ar);
    //}}AFX_VIRTUAL

// Implementation
public:
    virtual ~CDockbarsDoc();
#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
    //{{AFX_MSG(CDockbarsDoc)
        // NOTE - the ClassWizard will add and remove member functio
        //    DO NOT EDIT what you see in these blocks of generated 
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediat

#endif
