// CoolDBar.cpp : implementation file
//

#include "stdafx.h"
#include "dockbars.h"
#include "CoolDBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////////
// CCoolDockBar

CCoolDockBar::CCoolDockBar(UINT idb)
{
    // load bitmap
    m_bitmap.LoadBitmap(idb);

    // get height and width of bitmap
    BITMAP bm;
    m_bitmap.GetObject( sizeof(BITMAP), &bm );
    m_size=CSize(bm.bmWidth, bm.bmHeight);
}

CCoolDockBar::~CCoolDockBar()
{
}


BEGIN_MESSAGE_MAP(CCoolDockBar, CDockBar)
    //{{AFX_MSG_MAP(CCoolDockBar)
    ON_WM_ERASEBKGND()
    ON_WM_SIZE()
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()


////////////////////////////////////////////////////////////////////
// CCoolDockBar message handlers

BOOL CCoolDockBar::OnEraseBkgnd(CDC* pDC) 
{
    // get current size of docking bar
    CRect rect;
    CDC dcBitmap;
    GetClientRect(&rect);

    // stretch bitmap to fill docking bar
    dcBitmap.CreateCompatibleDC(pDC);
    CBitmap *pBitmap=dcBitmap.SelectObject(&m_bitmap);
    pDC->SetStretchBltMode(COLORONCOLOR);
    BOOL b=pDC->StretchBlt( 0, 0, rect.Width(),rect.Height(), 
            &dcBitmap, 0, 0, m_size.cx, m_size.cy, SRCCOPY );
    dcBitmap.DeleteDC();
    return TRUE;
}

CSize CCoolDockBar::CalcDynamicLayout(int nLength, DWORD nMode)
{
    CSize sz=CControlBar::CalcDynamicLayout(nLength,nMode);

    // keep top docking bar from ever closing up--even if there
    // is nothing docked inside
    if (GetStyle()&CBRS_TOP)
    {
        if (sz.cy<32) sz.cy=32;
    }

    return sz;
}

void CCoolDockBar::OnSize(UINT nType, int cx, int cy) 
{
    CDockBar::OnSize(nType, cx, cy);

    // because we are stretching the same bitmap, we
    // must make sure the entire bitmap is redrawn every
    // time the docking bar is resized    
    Invalidate();    
}
