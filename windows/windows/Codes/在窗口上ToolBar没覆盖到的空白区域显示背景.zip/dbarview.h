// dbarView.h : interface of the CDockbarsView class
//
////////////////////////////////////////////////////////////////////

#if !defined AFX_DBARVIEW_H
#define AFX_DBARVIEW_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CDockbarsView : public CView
{
protected: // create from serialization only
    CDockbarsView();
    DECLARE_DYNCREATE(CDockbarsView)

// Attributes
public:
    CDockbarsDoc* GetDocument();

// Operations
public:

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CDockbarsView)
    public:
    virtual void OnDraw(CDC* pDC);  // overridden to draw this view
    virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
    protected:
    virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
    virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
    virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
    //}}AFX_VIRTUAL

// Implementation
public:
    virtual ~CDockbarsView();
#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
    //{{AFX_MSG(CDockbarsView)
        // NOTE - the ClassWizard will add and remove member functio
        //    DO NOT EDIT what you see in these blocks of generated 
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in dockbarsView.cpp
inline CDockbarsDoc* CDockbarsView::GetDocument()
   { return (CDockbarsDoc*)m_pDocument; }
#endif

////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediat

#endif
