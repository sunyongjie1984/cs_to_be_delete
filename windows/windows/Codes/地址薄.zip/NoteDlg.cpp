// NoteDlg.cpp : implementation file
//

#include "stdafx.h"
#include "pagerdemo.h"
#include "NoteDlg.h"
#include "PagerDemoDoc.h"
#include "NewNoteDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNoteDlg dialog


CNoteDlg::CNoteDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNoteDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNoteDlg)
	m_strNote = _T("");
	m_EditNote = _T("");
	//}}AFX_DATA_INIT
}


void CNoteDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNoteDlg)
	DDX_Control(pDX, IDC_COMBO_DATE, m_ComboDate);
	DDX_CBString(pDX, IDC_COMBO_DATE, m_strNote);
	DDX_Text(pDX, IDC_EDIT_CALNOTE, m_EditNote);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNoteDlg, CDialog)
	//{{AFX_MSG_MAP(CNoteDlg)
	ON_BN_CLICKED(ID_BUTTON_NEWNOTE, OnButtonNewnote)
	ON_BN_CLICKED(ID_BUTTON_GETNOTE, OnButtonGetnote)
	ON_CBN_SELCHANGE(IDC_COMBO_DATE, OnSelchangeComboDate)
	ON_CBN_DROPDOWN(IDC_COMBO_DATE, OnDropdownComboDate)
	ON_CBN_EDITCHANGE(IDC_COMBO_DATE, OnEditchangeComboDate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNoteDlg message handlers

BOOL CNoteDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	if (!m_wndAnimate.Create(WS_CHILD | WS_VISIBLE | ACS_AUTOPLAY,
		CRect(371, 16, 0, 0), this, 0) ||
		!m_wndAnimate.Open(IDR_VC))
	{
		TRACE0("Failed to create animation control.\n");
		return -1;      // fail to create
	}
	CString sql;
	pRS->GetDefaultSQL();
	int i;
	if (pRS) {
		for (i = 0; i < pRS->GetRecordCount(); i++) {
			m_ComboDate.AddString(pRS->m_ID);
			pRS->MoveNext();
		}
	}
	delete pRS;

	GetDlgItem(ID_BUTTON_GETNOTE)->EnableWindow(FALSE);
	return TRUE;  
}


void CNoteDlg::OnButtonNewnote() 
{
	CNewNoteDlg dlg;
	dlg.DoModal();	
}

void CNoteDlg::OnButtonGetnote() 
{
	CDaoRecordsetNote *pRS;
	pRS = CPagerDemoDoc::g_pDoc->GetRecSetNote();

	UpdateData(TRUE);
	
	CString str = m_strNote;
	CString sql(_T("[ID] = "));
	sql += "'";
	sql += str;
	sql += "'";
	pRS->m_strFilter = sql;
	// requery the database 
	pRS->Requery();
	m_EditNote = pRS->m_Note;
	UpdateData(FALSE);
}

void CNoteDlg::OnSelchangeComboDate() 
{
	GetDlgItem(ID_BUTTON_GETNOTE)->EnableWindow(TRUE);
}

void CNoteDlg::OnDropdownComboDate() 
{
	GetDlgItem(ID_BUTTON_GETNOTE)->EnableWindow(FALSE);
	UpdateData(FALSE);
}

void CNoteDlg::OnEditchangeComboDate() 
{
	GetDlgItem(ID_BUTTON_GETNOTE)->EnableWindow(TRUE);	
}
