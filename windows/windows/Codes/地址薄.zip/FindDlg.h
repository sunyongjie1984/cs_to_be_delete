#if !defined(AFX_FINDDLG_H__AB259C81_605E_11D3_A6A0_00C04F796AE5__INCLUDED_)
#define AFX_FINDDLG_H__AB259C81_605E_11D3_A6A0_00C04F796AE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FindDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFindDlg dialog

class CFindDlg : public CDialog
{
// Construction
public:
	CFindDlg(CWnd* pParent = NULL);   // standard constructor

protected:
	enum
	{
		COL_NAME  	= 0,
		COL_ADDRESS = 1,
		COL_EMAIL  	= 2,
		COL_WPHONE	= 3,
		COL_MPHONE  = 4,
		COL_HPHONE  = 5,
		COL_NOTE  	= 6,
		NUM_COLUMNS = 7
	};

	static UINT	m_ColumnLabelID [NUM_COLUMNS];	// list view control header IDs, loaded from resource
	static int	m_ColumnFormat  [NUM_COLUMNS];	// list view column format
	int			m_ColumnWidth   [NUM_COLUMNS];	
// Dialog Data
	//{{AFX_DATA(CFindDlg)
	enum { IDD = IDD_DIALOG_FIND };
	CComboBox	m_ComboFind;
	CListCtrl	m_ListCtrlFind;
	CAnimateCtrl            m_wndAnimate;
	CString	m_EditFind;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFindDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFindDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnFind();
	afx_msg void OnClear();
	afx_msg void OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FINDDLG_H__AB259C81_605E_11D3_A6A0_00C04F796AE5__INCLUDED_)
