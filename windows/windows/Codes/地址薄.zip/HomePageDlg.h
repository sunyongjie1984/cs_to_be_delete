#if !defined(AFX_HOMEPAGEDLG_H__B2E1FECE_66C3_11D3_A6A5_00C04F796AE5__INCLUDED_)
#define AFX_HOMEPAGEDLG_H__B2E1FECE_66C3_11D3_A6A5_00C04F796AE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HomePageDlg.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CHomePageDlg dialog

class CHomePageDlg : public CDialog
{
// Construction
public:
	CHomePageDlg(CWnd* pParent = NULL);   // standard constructor
	CAnimateCtrl            m_wndAnimate;
// Dialog Data
	//{{AFX_DATA(CHomePageDlg)
	enum { IDD = IDD_DIALOG_WEB };
	CString	m_Path;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHomePageDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CHomePageDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HOMEPAGEDLG_H__B2E1FECE_66C3_11D3_A6A5_00C04F796AE5__INCLUDED_)
