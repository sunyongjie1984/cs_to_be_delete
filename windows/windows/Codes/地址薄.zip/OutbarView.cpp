// OutbarView.cpp : implementation file
//

#include "stdafx.h"
#include "PagerDemo.h"
#include "OutbarView.h"
#include "PagerDemoDoc.h"
#include "hints.h"
#include "HyperLink.h"
#include "CalendarDlg.h"
#include "HomePageDlg.h"
#include "tapi.h"
#include <afxconv.h>           // For LPTSTR -> LPSTR macros

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static LPCTSTR lpszTreeItems[] =
{
	_T("Database"),
	_T("Calendar"),
	_T("Home Page"),
	_T("Phone Dialer"),
	_T("Send E-Mail"),
	_T("MS Outlook"),
};

//:>28 Jul fas -- ContentInfo declared as static.  This is consistent with
//:>its usage and causes Genitor Surveyor to associate it with
//:>this file.

// Menu Information for the Content Bar with the COutbarView defined in
static CContentItems ContentInfo[] =
{
	CContentItems ( 0, lpszTreeItems[ 0]),
	CContentItems ( 1, lpszTreeItems[ 1]),
	CContentItems ( 2, lpszTreeItems[ 2]),
	CContentItems ( 3, lpszTreeItems[ 3]),
	CContentItems ( 4, lpszTreeItems[ 4]),
	CContentItems ( 5, lpszTreeItems[ 5]),
};

static UINT nImages[] =
{
	IDI_ICON_OUTLOOK,
	IDI_ICON_CALENDAR,
	IDI_ICON_CONTACTS,
	IDI_ICON_TASKS,
	IDI_ICON_NOTES,
	IDI_ICON_PUBLIC,
};

/////////////////////////////////////////////////////////////////////////////
// COutbarView

IMPLEMENT_DYNCREATE(COutbarView, CView)

COutbarView::COutbarView()
{
}

COutbarView::~COutbarView()
{
}


BEGIN_MESSAGE_MAP(COutbarView, CView)
	//{{AFX_MSG_MAP(COutbarView)
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_COMMAND(ID_FILE_WEB, OnFileWebChange)
	//}}AFX_MSG_MAP
	ON_MESSAGE( OBN_SELENDOK,  OnSelEndOK )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COutbarView drawing

void COutbarView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// COutbarView diagnostics

#ifdef _DEBUG
void COutbarView::AssertValid() const
{
	CView::AssertValid();
}

void COutbarView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COutbarView message handlers

void COutbarView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	if(m_Pager.GetSafeHwnd())
	{
		m_Pager.MoveWindow(0,0,cx,cy-2);
	}
}

int COutbarView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// Create the pager control and set its parent to 'this'
	if (!m_Pager.Create(WS_CHILD|WS_VISIBLE|PGS_VERT,
		CRect(0,0,0,0), this, IDC_STATIC ))
	{
		TRACE0("Failed to create CPagerCtrl...\n");
		return -1;
	}

	// Define the style to use with the COutlookBar.
	DWORD dwStyle = WS_CHILD | WS_VISIBLE | LBS_OWNERDRAWVARIABLE | 
		LBS_NOINTEGRALHEIGHT | WS_TABSTOP;

	// Create the COutlookBar, and set its parent to CPagerCtrl.
	if (!m_OutlookBar.Create( dwStyle, CRect(0,0,0,0),
		&m_Pager, IDC_OUTBAR ))
	{
		TRACE0("Failed to create COutlookBar...\n");
		return -1;
	}
	
	int nArraySize = sizeof(nImages)/sizeof(nImages[0]);

	// Set the CWnd object you want messages sent to.
	m_OutlookBar.SetOwner (this);

	// Set the cx and cy scroll area for pager, since this is a
	// vertical pager, we are only interested in cy.
	m_Pager.SetScrollArea(NULL, nArraySize*OB_CYBUTTON);

	// Set the child HWND to COutlookBar, and button size to 15.
	m_Pager.SetChild(m_OutlookBar.GetSafeHwnd());
	m_Pager.SetButtonSize(15);
	
	// Create the image list to be used by the Outbar control.
	m_ImageList.Create (32, 32, TRUE, 2, 1);
	for (int i =0; i < nArraySize; ++i) {
		m_ImageList.Add(AfxGetApp()->LoadIcon (nImages[i]));
	}

	// Set the image list for the menu control
	m_OutlookBar.SetImageLists(&m_ImageList, &m_ImageList);
	m_OutlookBar.SetItems(ContentInfo, nArraySize);
	
	return 0;
}

void COutbarView::OnSelEndOK(UINT lParam, LONG wParam)
{
	UINT uIndex = lParam; // button index.

	if (uIndex == 0) {
		CFileDialog dlg(TRUE,
		".mdb",
		"Address Book.mdb",
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		0,
		this);
		if (dlg.DoModal() == IDOK) {
			CPagerDemoDoc::g_pDoc->OnNewDocument();
			CPagerDemoDoc::g_pDoc->m_pRegSettings.SetDatabasePath(dlg.GetPathName());
			CPagerDemoDoc::g_pDoc->OnOpenDocument(dlg.GetPathName());
			if (CPagerDemoDoc::g_pDoc->m_bFileOpen) 
				CPagerDemoDoc::g_pDoc->UpdateAllViews(NULL, HINT_DB_OPENED, NULL);
		}
			
	}
	if (uIndex == 1) {
		CCalendarDlg Dlg;
		Dlg.DoModal();
	}
	if (uIndex == 2)  {
		if (CPagerDemoDoc::g_pDoc->m_pRegSettings.GetHPPath() == _T(""))
			AfxMessageBox(_T("To set URL, go to file menu - 'Change Home Page address'"), MB_OK | MB_ICONEXCLAMATION);
		else
			CHyperLink::GotoURL(CPagerDemoDoc::g_pDoc->m_pRegSettings.GetHPPath(), SW_SHOWNORMAL);
	}

	if (uIndex == 5) 
		CHyperLink::GotoURL("Outlook", SW_SHOWNORMAL);

	if (uIndex == 4) 
		CHyperLink::GotoURL("mailto:" + CPagerDemoDoc::g_pDoc->m_pSet->m_EmailAddress, SW_SHOWNORMAL);
	
	if (uIndex == 3)  
		tapiRequestMakeCall("Enter Number","Address", 0, "Phone Number");
		
}

void COutbarView::OnFileWebChange() 
{
	CHomePageDlg dlg;
	dlg.DoModal();
}
