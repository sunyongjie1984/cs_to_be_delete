#if !defined(AFX_DAORECORDSETACCESS_H__8F4EE38B_5EDF_11D3_A69F_00C04F796AE5__INCLUDED_)
#define AFX_DAORECORDSETACCESS_H__8F4EE38B_5EDF_11D3_A69F_00C04F796AE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoRecordsetAccess.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoRecordsetAccess DAO recordset

class CDaoRecordsetAccess : public CDaoRecordset
{
public:
	CDaoRecordsetAccess(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoRecordsetAccess)

// Field/Param Data
	//{{AFX_FIELD(CDaoRecordsetAccess, CDaoRecordset)
	long	m_AddressID;
	CString	m_Name;
	CString	m_Address;
	CString	m_EmailAddress;
	CString	m_WorkPhone;
	CString	m_MobilePhone;
	CString	m_HomePhone;
	CString	m_Notes;
	COleDateTime	m_ID;
	CString	m_Note;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoRecordsetAccess)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAORECORDSETACCESS_H__8F4EE38B_5EDF_11D3_A69F_00C04F796AE5__INCLUDED_)
