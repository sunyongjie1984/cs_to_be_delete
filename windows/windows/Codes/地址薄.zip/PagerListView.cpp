// PagerListView.cpp : implementation file
//

#include "stdafx.h"
#include "pagerdemo.h"
#include "PagerListView.h"
#include "PagerDemoDoc.h"
#include "Homepagedlg.h"
#include "hints.h"
#include "UpdateDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// list view control header IDs, loaded from resource
UINT CPagerListView::m_ColumnLabelID [NUM_COLUMNS] = 
{
	IDS_TABLE_HEAD_NAME,
	IDS_TABLE_HEAD_WPHONE,
	IDS_TABLE_HEAD_MPHONE,
	IDS_TABLE_HEAD_HPHONE,
	IDS_TABLE_HEAD_NOTE,
};


// list view column format
int CPagerListView::m_ColumnFormat [NUM_COLUMNS] = 
{
	LVCFMT_LEFT, LVCFMT_LEFT, LVCFMT_LEFT, LVCFMT_LEFT
};

/////////////////////////////////////////////////////////////////////////////
// CPagerListView

IMPLEMENT_DYNCREATE(CPagerListView, CListView)

CPagerListView::CPagerListView()
{
    nSortedCol		= -1; 
    bSortAscending	= TRUE;
}

CPagerListView::~CPagerListView()
{
}


BEGIN_MESSAGE_MAP(CPagerListView, CListView)
	//{{AFX_MSG_MAP(CPagerListView)
	ON_COMMAND(ID_FILE_MOVEFIRST, OnFileMovefirst)
	ON_COMMAND(ID_FILE_MOVELAST, OnFileMovelast)
	ON_COMMAND(ID_FILE_MOVENEXT, OnFileMovenext)
	ON_COMMAND(ID_FILE_MOVEPREV, OnFileMoveprev)
	ON_WM_LBUTTONDBLCLK()
	ON_NOTIFY_REFLECT(LVN_COLUMNCLICK, OnColumnclick)
	ON_WM_RBUTTONDOWN()
	ON_UPDATE_COMMAND_UI(ID_FILE_MOVEFIRST, OnUpdateFileMovefirst)
	ON_UPDATE_COMMAND_UI(ID_FILE_MOVELAST, OnUpdateFileMovelast)
	ON_UPDATE_COMMAND_UI(ID_FILE_MOVENEXT, OnUpdateFileMovenext)
	ON_UPDATE_COMMAND_UI(ID_FILE_MOVEPREV, OnUpdateFileMoveprev)
	ON_COMMAND(ID_POPMENU_DEL, OnPopmenuDel)
	ON_COMMAND(ID_POPMENU_UPDATE, OnPopmenuUpdate)
	ON_COMMAND(ID_POPMENU_REFRESH, OnPopmenuRefresh)
	ON_UPDATE_COMMAND_UI(ID_POPMENU_REFRESH, OnUpdatePopmenuRefresh)
	ON_COMMAND(ID_POPMENU_NEW, OnPopmenuNewRecord)
	ON_COMMAND(ID_TOOL_NEWRECORD, OnToolNewrecord)
	ON_COMMAND(ID_TOOL_DELRECORD, OnToolDelrecord)
	ON_COMMAND(ID_TOOL_REFRESH, OnToolRefresh)
	ON_COMMAND(ID_TOOL_UPDATERECORD, OnToolUpdaterecord)
	ON_UPDATE_COMMAND_UI(ID_TOOL_UPDATERECORD, OnUpdateToolUpdaterecord)
	ON_UPDATE_COMMAND_UI(ID_TOOL_DELRECORD, OnUpdateToolDelrecord)
	ON_NOTIFY_REFLECT(NM_CLICK, OnClick)
	ON_COMMAND(ID_FILE_WEB, OnFileWeb)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPagerListView drawing

void CPagerListView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

BOOL CPagerListView::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style |= LVS_REPORT     |
			 LVS_SINGLESEL     |
			 LVS_SHOWSELALWAYS |
			 LVS_ICON          ;
	
	return CListView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPagerListView diagnostics

#ifdef _DEBUG
void CPagerListView::AssertValid() const
{
	CListView::AssertValid();
}

void CPagerListView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPagerListView message handlers

void CPagerListView::OnInitialUpdate() 
{
	CListView::OnInitialUpdate();

	CListCtrl	&lc	= GetListCtrl();
	int Column;
	LV_COLUMN		LVColumn;		// column info of one column in list control

	CPagerDemoDoc	*pDoc = (CPagerDemoDoc*) GetDocument();
	
	DWORD dwStyle = ListView_GetExtendedListViewStyle(GetListCtrl());
	//Add the full row select and grid line style to the existing extended styles
	 dwStyle |= LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES;
	ListView_SetExtendedListViewStyle (GetListCtrl(),dwStyle);

	lc.DeleteAllItems ();// regular cleanup
	
	//initialize the columns (insert columns)
	m_ColumnWidth [COL_NAME      ] = 150;
	m_ColumnWidth [COL_WPHONE    ] = 100;
	m_ColumnWidth [COL_MPHONE    ] = 100;
	m_ColumnWidth [COL_HPHONE    ] = 100;
	m_ColumnWidth [COL_NOTE      ] = 200;

	// set header and format for all visible columns
	LVColumn.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	if (!pDoc->m_pSet) {
		for (Column = 0; (Column < NUM_COLUMNS); Column++)
		{
			CString		HeaderString;
		
			// fill header data
			HeaderString.LoadString (m_ColumnLabelID [Column]);

			LVColumn.iSubItem	= Column;
			LVColumn.pszText	= (LPTSTR) (LPCTSTR) HeaderString;
			LVColumn.cx			= m_ColumnWidth [Column];
			LVColumn.fmt		= m_ColumnFormat [Column];
			lc.InsertColumn (Column, &LVColumn);
		}
	}

	CString DBPath = pDoc->m_pRegSettings.GetDatabasePath();
	if (!DBPath.IsEmpty()) {
		CPagerDemoDoc::g_pDoc->OnNewDocument();
		CPagerDemoDoc::g_pDoc->OnOpenDocument(DBPath);
	}
	else {
		AfxMessageBox(_T("Please specify new database location"), MB_OK | MB_ICONEXCLAMATION);
		CFileDialog dlg(TRUE,
		".mdb",
		"Address Book.mdb",
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		0,
		this);
		if (dlg.DoModal() == IDOK) {
			CPagerDemoDoc::g_pDoc->OnNewDocument();
			pDoc->m_pRegSettings.SetDatabasePath(dlg.GetPathName());
			CPagerDemoDoc::g_pDoc->OnOpenDocument(dlg.GetPathName());
			if (CPagerDemoDoc::g_pDoc->m_bFileOpen) 
				CPagerDemoDoc::g_pDoc->UpdateAllViews(NULL, HINT_DB_OPENED, NULL);
		}
	}
	SetFocus ();
	GetParentFrame ()->SetActiveView (this, TRUE);
	lc.SetItem (0, 0, LVIF_STATE, NULL, 0, LVIS_FOCUSED , LVIS_FOCUSED, 0);
}



void CPagerListView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	CListCtrl&		lc	  = GetListCtrl ();
	CPagerDemoDoc	*pDoc = (CPagerDemoDoc*) GetDocument();
	CDaoRecordsetAccess *pRS;
	pRS = new CDaoRecordsetAccess(pDoc->m_pDB);
	int i = 0;

	if (lHint ==  HINT_DB_OPENED) {
		if (pRS) {
			lc.DeleteAllItems();
			pRS->Open(dbOpenDynaset, pRS->GetDefaultSQL(), 0);
			pRS->MoveFirst();
			while (!pRS->IsEOF()) {
				int ItemIndex;
				int SubitemIndex = 1;
				ItemIndex = lc.InsertItem (LVIF_TEXT | LVIF_PARAM, i, pRS->m_Name, 0, 0, 0, 0);
				lc.SetItem (ItemIndex, SubitemIndex++, LVIF_TEXT, pRS->m_WorkPhone,   0, 0, 0, 0);
				lc.SetItem (ItemIndex, SubitemIndex++, LVIF_TEXT, pRS->m_MobilePhone,     0, 0, 0, 0);
				lc.SetItem (ItemIndex, SubitemIndex++, LVIF_TEXT, pRS->m_HomePhone, 0, 0, 0, 0);
				lc.SetItem (ItemIndex, SubitemIndex++, LVIF_TEXT, pRS->m_Notes, 0, 0, 0, 0);
				pRS->MoveNext();
			}

		}
	}
	if (lHint == HINT_NEW_RECORD) {
		CUpdateDlg dlg;
		CDaoRecordsetAccess *pRS;

		pRS = new CDaoRecordsetAccess(pDoc->m_pDB);
		ASSERT(pRS != NULL);
		try
		{
			pRS->Open();
			long numRec = pRS->GetRecordCount();
		}
		catch (CDaoException* e)
		{
			delete pRS;
			pRS = NULL;

			TCHAR szCause[255];
			CString strFormatted = _T("The data file could not be opened because of this error: \n");
			e->GetErrorMessage(szCause, 255);
			strFormatted += szCause;
			AfxMessageBox(strFormatted, MB_OK | MB_ICONEXCLAMATION);
			e->Delete();
			return ;
		}
		dlg.m_StaticEMail = _T("Please specify E-Mail address");
		if (dlg.DoModal() == IDOK) {

			// add a new record to the database with user-supplied SSN
			pRS->AddNew();
			
			if (dlg.m_Name.IsEmpty()) {
				AfxMessageBox(_T("You must type persons name!"), MB_OK | MB_ICONEXCLAMATION);
			return;
			}
			pRS->m_Name         = dlg.m_Name;
			pRS->m_Address      = dlg.m_Address;
			pRS->m_WorkPhone    = dlg.m_WPhone;
			pRS->m_MobilePhone  = dlg.m_CPhone;
			pRS->m_HomePhone    = dlg.m_HPhone;
			pRS->m_EmailAddress = dlg.m_MailAddress;
			pRS->m_Notes        = dlg.m_Note;
			pRS->Update();
			// allow editing of database fields
			pRS->Edit();
			// if user clicks OK button, update the database
			pRS->Update();
			CPagerDemoDoc::g_pDoc->UpdateAllViews(NULL, HINT_DB_OPENED, NULL);
		}
		delete 	pRS;
	}
	if (lHint ==  HINT_DB_CLOSED)
		lc.DeleteAllItems();
	if (lHint ==  HINT_UPDATE_RECORD)
		OnPopmenuUpdate();
	if (lHint ==  HINT_DEL_RECORD)
		OnPopmenuDel();
	delete pRS;	
	
}


void CPagerListView::OnFileMovefirst() 
{

}

void CPagerListView::OnFileMovelast() 
{
}

void CPagerListView::OnFileMovenext() 
{
}

void CPagerListView::OnFileMoveprev() 
{
	CListCtrl&		lc	  = GetListCtrl ();
	CPagerDemoDoc::g_pDoc->m_pSet->MoveNext();
	SetListSelection();
	
}

void CPagerListView::SetListSelection()
{
	CListCtrl&	lc = GetListCtrl ();
	int			nItem;

	// finding and selecting version by version name.
	// calling this f-n to retrieve focused item
	if (!CPagerDemoDoc::g_pDoc->m_pSet->m_Name.IsEmpty ())
	{
		LV_FINDINFO FindInfo;
		
		FindInfo.flags	= LVFI_STRING;
		FindInfo.psz	= (LPTSTR) (LPCTSTR) CPagerDemoDoc::g_pDoc->m_pSet->m_Name;
		nItem = lc.FindItem (&FindInfo, -1);
		if (nItem == -1)
			return;
		lc.SetItem (nItem, 0, LVIF_STATE, NULL, 0, LVIS_FOCUSED | LVIS_SELECTED, LVIS_FOCUSED | LVIS_SELECTED, 0);
	}
	else
	{
		// view active and something selected?
		if ((GetFocus () == this) && (lc.GetNextItem (-1, LVNI_ALL | LVNI_SELECTED) == -1))
		{
			// then select the top line
			lc.SetItem (0, 0, LVIF_STATE, NULL, 0, LVIS_FOCUSED | LVIS_SELECTED, LVIS_FOCUSED | LVIS_SELECTED, 0);
			nItem = 0;
		}
		else
			nItem = lc.GetNextItem (-1, LVNI_SELECTED);
	}
	
	if (nItem != -1)
		lc.EnsureVisible (nItem, FALSE);
}

void CPagerListView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	CListCtrl&	lc		= GetListCtrl();
	int nItem = lc.GetNextItem (-1, LVNI_SELECTED);
	if (nItem != -1) OnPopmenuUpdate();	
	CListView::OnLButtonDblClk(nFlags, point);
}

void CPagerListView::OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	HD_NOTIFY *phdn = (HD_NOTIFY *) pNMHDR;
	bSortAscending = !bSortAscending;
	SortTextItems(phdn->iButton , bSortAscending, 0, -1 );
	*pResult = 0;
}

void CPagerListView::ShowContextMenu(int index, CPoint point)
{
	CListCtrl&	lc		= GetListCtrl();

	CMenu		PopMenu;	// popup menu
	CMenu*		pMenu;

	// load correct menu ressource
    PopMenu.LoadMenu (IDR_POPMENU);

	// translate position to screen position
	ClientToScreen (&point);

	// show the menu (returns, when menu is closed again!)
	pMenu = PopMenu.GetSubMenu (0);
	pMenu->TrackPopupMenu (TPM_LEFTALIGN | TPM_RIGHTBUTTON,	point.x, point.y, GetParentFrame ());
}

void CPagerListView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	
	CListCtrl&	lc	= GetListCtrl ();

	int			nItem;	// selected line
	int			index;
	UINT		Flag;
	
	if (CPagerDemoDoc::g_pDoc->m_pSet) {
		nItem = lc.GetNextItem (-1, LVNI_ALL | LVNI_SELECTED);

		// Using HitTest function to set popup menu to selected item:
		index = lc.HitTest (point, &Flag);
   

		// did we hit a line in the control?
		if ((index != -1) && (Flag & LVHT_ONITEM) != 0)
		{
			// select the line
			lc.SetItemState (index, LVIS_FOCUSED | LVIS_SELECTED, LVIS_FOCUSED | LVIS_SELECTED);

			// show the menu
			ShowContextMenu (index, point);
		}
	}
}

void CPagerListView::OnUpdateFileMovefirst(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(CPagerDemoDoc::g_pDoc->m_bFileOpen);
	
}

void CPagerListView::OnUpdateFileMovelast(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(CPagerDemoDoc::g_pDoc->m_bFileOpen);
	
}

void CPagerListView::OnUpdateFileMovenext(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(CPagerDemoDoc::g_pDoc->m_bFileOpen);
	
}

void CPagerListView::OnUpdateFileMoveprev(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(CPagerDemoDoc::g_pDoc->m_bFileOpen);
	
}

void CPagerListView::OnPopmenuDel() 
{
	CListCtrl&	lc = GetListCtrl ();
	CDaoRecordsetAccess *pRS;

	int nItem = lc.GetNextItem (-1, LVNI_SELECTED);

	pRS = CPagerDemoDoc::g_pDoc->GetRecSet();
	// Verify deleting record with current Name
	CString str = lc.GetItemText(nItem, 0);
	if ( (AfxMessageBox("Delete the record with the following Name:  " +
		str, MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2)) == IDYES ) {
		CString sql(_T("[Name] = "));
		sql += "'";
		sql += str;
		sql += "'";
		pRS->m_strFilter = sql;
		// requery the database
		pRS->Requery();
		// delete the returned record
		pRS->Delete();

		lc.DeleteItem(nItem);
	//	CPagerDemoDoc::g_pDoc->UpdateAllViews(NULL, HINT_DB_OPENED, NULL);
	}
}

void CPagerListView::OnPopmenuUpdate() 
{
	CListCtrl&	lc		= GetListCtrl();
	CDaoRecordsetAccess *pRS;
	CUpdateDlg dlg;
	pRS = CPagerDemoDoc::g_pDoc->GetRecSet();

	int nItem = lc.GetNextItem (-1, LVNI_SELECTED);
	CString str = lc.GetItemText(nItem, 0);

	if (pRS) {
		CString sql(_T("[Name] = "));
		sql += "'";
		sql += str;
		sql += "'";
		pRS->m_strFilter = sql;
		// requery the database 
		pRS->Requery();
		// allow editing of database fields
		pRS->Edit();
		
		dlg.m_Name            = pRS->m_Name;
		dlg.m_Address         = pRS->m_Address;
		dlg.m_WPhone          = pRS->m_WorkPhone;
		dlg.m_CPhone          = pRS->m_MobilePhone;
		dlg.m_HPhone		  = pRS->m_HomePhone;
		dlg.m_MailAddress     = pRS->m_EmailAddress;
		dlg.m_Note            = pRS->m_Notes;
		dlg.m_StaticEMail     = pRS->m_EmailAddress;

		// if user edited data, update the database
		if (dlg.DoModal() == IDOK) {
			// allow editing of database fields
			pRS->Edit();
			if (!dlg.m_Name.IsEmpty())
				pRS->m_Name         = dlg.m_Name;
			else
				pRS->m_Name = _T(" ");

			if (!dlg.m_Address.IsEmpty())
				pRS->m_Address      = dlg.m_Address;
			else
				pRS->m_Address = _T(" ");

			if (!dlg.m_WPhone.IsEmpty())
				pRS->m_WorkPhone    = dlg.m_WPhone;
			else
				pRS->m_WorkPhone = _T(" ");

			if (!dlg.m_CPhone.IsEmpty())
				pRS->m_MobilePhone  = dlg.m_CPhone;
			else
				pRS->m_MobilePhone = _T(" ");

			if (!dlg.m_HPhone.IsEmpty())
				pRS->m_HomePhone    = dlg.m_HPhone;
			else
				pRS->m_HomePhone = _T(" ");

			if (!dlg.m_MailAddress.IsEmpty())
				pRS->m_EmailAddress = dlg.m_MailAddress;
			else
				pRS->m_EmailAddress = _T(" ");

			if (!dlg.m_Note.IsEmpty())
				pRS->m_Notes        = dlg.m_Note;
			else
				pRS->m_Notes = _T(" ");
			pRS->Update();
		}
		SetListSelection();
	}	
}

void CPagerListView::OnPopmenuRefresh() 
{
	CPagerDemoDoc::g_pDoc->UpdateAllViews(NULL, HINT_DB_OPENED, NULL);
}

void CPagerListView::OnUpdatePopmenuRefresh(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(CPagerDemoDoc::g_pDoc->m_bFileOpen);
	
}

void CPagerListView::OnPopmenuNewRecord() 
{
	if (CPagerDemoDoc::g_pDoc->m_bFileOpen) 
		CPagerDemoDoc::g_pDoc->UpdateAllViews(NULL, HINT_NEW_RECORD, NULL);
	else
		AfxMessageBox("Please specify new database location", MB_ICONEXCLAMATION);
}

void CPagerListView::OnToolNewrecord() 
{
	if (CPagerDemoDoc::g_pDoc->m_bFileOpen) 
		CPagerDemoDoc::g_pDoc->UpdateAllViews(NULL, HINT_NEW_RECORD, NULL);
	else
		AfxMessageBox("Please specify new database location", MB_ICONEXCLAMATION);
}

void CPagerListView::OnToolDelrecord() 
{
	OnPopmenuDel();
}

void CPagerListView::OnToolRefresh() 
{
	CPagerDemoDoc::g_pDoc->UpdateAllViews(NULL, HINT_DB_OPENED, NULL);
}

void CPagerListView::OnToolUpdaterecord() 
{
	OnPopmenuUpdate();
}


void CPagerListView::OnUpdateToolUpdaterecord(CCmdUI* pCmdUI) 
{
	CListCtrl&	lc		= GetListCtrl();
	int nItem = lc.GetNextItem (-1, LVNI_SELECTED);
	if (nItem == -1) pCmdUI->Enable(0);
	
}

void CPagerListView::OnUpdateToolDelrecord(CCmdUI* pCmdUI) 
{
	OnUpdateToolUpdaterecord(pCmdUI);
	
}

BOOL CPagerListView::SortTextItems(int nCol, BOOL bAscending, int low, int high) {

	CListCtrl &lc = GetListCtrl();
	if( nCol >= ((CHeaderCtrl*)GetDlgItem(0))->GetItemCount() )
		return FALSE;

		if( high == -1 ) high = lc.GetItemCount() - 1;

		int lo = low;
		int hi = high;
		CString midItem;

		if( hi <= lo ) return FALSE;

		midItem = lc.GetItemText( (lo+hi)/2, nCol );

		// loop through the list until indices cross
		while( lo <= hi )
		{
			// rowText will hold all column text for one row
			CStringArray rowText;

			// find the first element that is greater than or equal to�
			// the partition element starting from the left Index.
			if( bAscending )
				while( ( lo < high ) && ( lc.GetItemText(lo, nCol) < midItem ) )
					++lo;
			else
				while( ( lo < high ) && ( lc.GetItemText(lo, nCol) > midItem ) )
					++lo;

			// find an element that is smaller than or equal to�
			// the partition element starting from the right Index.
			if( bAscending )
				while( ( hi > low ) && ( lc.GetItemText(hi, nCol) > midItem ) )
					--hi;
			else
				while( ( hi > low ) && ( lc.GetItemText(hi, nCol) < midItem ) )
					--hi;

			// if the indexes have not crossed, swap
			// and if the items are not equal
			if( lo <= hi )
			{
				// swap only if the items are not equal
				if( lc.GetItemText(lo, nCol) != lc.GetItemText(hi, nCol))
				{
					// swap the rows
					LV_ITEM lvitemlo, lvitemhi;
					int nColCount =
						((CHeaderCtrl*)GetDlgItem(0))->GetItemCount();
					rowText.SetSize( nColCount );
					int i;
					for( i=0; i<nColCount; i++)
						rowText[i] = lc.GetItemText(lo, i);
					lvitemlo.mask = LVIF_IMAGE | LVIF_PARAM | LVIF_STATE;
					lvitemlo.iItem = lo;
					lvitemlo.iSubItem = 0;
					lvitemlo.stateMask = LVIS_CUT | LVIS_DROPHILITED |
							LVIS_FOCUSED | LVIS_SELECTED |
							LVIS_OVERLAYMASK | LVIS_STATEIMAGEMASK;

					lvitemhi = lvitemlo;
					lvitemhi.iItem = hi;

					lc.GetItem( &lvitemlo );
					lc.GetItem( &lvitemhi );

					for( i=0; i<nColCount; i++)
						lc.SetItemText(lo, i, lc.GetItemText(hi, i));

					lvitemhi.iItem = lo;
					lc.SetItem( &lvitemhi );

					for( i=0; i<nColCount; i++)
						lc.SetItemText(hi, i, rowText[i]);

					lvitemlo.iItem = hi;
					lc.SetItem( &lvitemlo );
				}

				++lo;
				--hi;
			}
		}

		// If the right index has not reached the left side of array
		// must now sort the left partition.
		if( low < hi )
			SortTextItems( nCol, bAscending , low, hi);

		// If the left index has not reached the right side of array
		// must now sort the right partition.
		if( lo < high )
			SortTextItems( nCol, bAscending , lo, high );

		return TRUE;
}

void CPagerListView::PreSubclassWindow() 
{
	CListView::PreSubclassWindow();
}

BOOL CPagerListView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
}


BOOL CPagerListView::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CListView::OnCommand(wParam, lParam);
}

void CPagerListView::OnClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
		CListCtrl&	lc		= GetListCtrl();
	int nItem = lc.GetNextItem (-1, LVNI_FOCUSED | LVNI_SELECTED);

	CString str = lc.GetItemText(nItem, 0);
	CPagerDemoDoc::g_pDoc->GetListName(str);

	if (nItem != -1) {
		CListCtrl&	lc		= GetListCtrl();
		CDaoRecordsetAccess *pRS;
		CUpdateDlg dlg;
		pRS = CPagerDemoDoc::g_pDoc->GetRecSet();

		int nItem = lc.GetNextItem (-1, LVNI_SELECTED);
		CString str = lc.GetItemText(nItem, 0);
		CPagerDemoDoc::g_pDoc->GetListName(str);

		if (pRS) {
			CString sql(_T("[Name] = "));
			sql += "'";
			sql += str;
			sql += "'";
			pRS->m_strFilter = sql;
			// requery the database 
			pRS->Requery();
		}
	}
	
	*pResult = 0;
}

void CPagerListView::OnFileWeb() 
{
	CHomePageDlg dlg;
	dlg.DoModal();

}
