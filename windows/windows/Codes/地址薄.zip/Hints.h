const int HINT_DB_OPENED        	    = 1;
const int HINT_DB_CLOSED                = 2;
const int HINT_NEW_RECORD               = 3;
const int HINT_UPDATE_RECORD            = 4;
const int HINT_DEL_RECORD               = 5;

//Registry Settings:

// main frame settings
const CString KEY_MAINFRAME				= _T("MFSettings");
const CString ENTRY_STATUS				= _T("Status");
const CString ENTRY_TOP					= _T("Top");
const CString ENTRY_LEFT				= _T("Left");
const CString ENTRY_BOTTOM				= _T("Bottom");
const CString ENTRY_RIGHT				= _T("Right");

// views
const CString KEY_VIEWS					= _T("Views");
const CString ENTRY_TREEWIDTH			= _T("TreeWidth");

//db path
const CString KEY_DB				    = _T("Database");
const CString ENTRY_DBPATH				= _T("DBPath");

//hp path
const CString KEY_HP				    = _T("HomePage");
const CString ENTRY_HPPATH  			= _T("HPPath");

