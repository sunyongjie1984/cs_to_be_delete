// RegSettings.cpp: implementation of the CRegSettings class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pagerdemo.h"
#include "RegSettings.h"
#include "hints.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRegSettings::CRegSettings()
{

}

CRegSettings::~CRegSettings()
{

}

void CRegSettings::SetMainFrameStatus(int Status)
{
	if (m_pApp = AfxGetApp())
		m_pApp->WriteProfileInt (KEY_MAINFRAME, ENTRY_STATUS, Status);
	return;
}

void CRegSettings::SetMainFrameTop(int Top)
{
	if (m_pApp = AfxGetApp())
		m_pApp->WriteProfileInt (KEY_MAINFRAME, ENTRY_TOP, Top);
	return;
}

void CRegSettings::SetMainFrameLeft(int Left)
{
	if (m_pApp = AfxGetApp())
		m_pApp->WriteProfileInt (KEY_MAINFRAME, ENTRY_LEFT, Left);
	return;
}

void CRegSettings::SetMainFrameBottom(int Bottom)
{
	if (m_pApp = AfxGetApp())
		m_pApp->WriteProfileInt (KEY_MAINFRAME, ENTRY_BOTTOM, Bottom);
	return;
}

void CRegSettings::SetMainFrameRight(int Right)
{
	if (m_pApp = AfxGetApp())
		m_pApp->WriteProfileInt (KEY_MAINFRAME, ENTRY_RIGHT, Right);
	return;
}

void CRegSettings::SetTreeViewWidth(int TreeWidth)
{
	if (m_pApp = AfxGetApp())
		m_pApp->WriteProfileInt (KEY_VIEWS, ENTRY_TREEWIDTH, TreeWidth);
	return;
}


int CRegSettings::GetMainFrameStatus()
{
	int Status;
	if (m_pApp = AfxGetApp())
		Status = m_pApp->GetProfileInt (KEY_MAINFRAME, ENTRY_STATUS, 1);
	return Status;
}

int CRegSettings::GetMainFrameTop()
{
	int Top;
		if (m_pApp = AfxGetApp())
		Top = m_pApp->GetProfileInt (KEY_MAINFRAME, ENTRY_TOP,
		GetSystemMetrics(SM_CXICON));
	return Top;
}

int CRegSettings::GetMainFrameLeft()
{
	int Left;
	if (m_pApp = AfxGetApp())
		Left = m_pApp->GetProfileInt (KEY_MAINFRAME, ENTRY_LEFT,
		GetSystemMetrics(SM_CYICON));
	return Left;
}

int CRegSettings::GetMainFrameBottom()
{
	int Bottom;
	if (m_pApp = AfxGetApp())
		Bottom = m_pApp->GetProfileInt (KEY_MAINFRAME, ENTRY_BOTTOM,
		GetSystemMetrics(SM_CYMAXIMIZED) - GetSystemMetrics(SM_CYICON));
	return Bottom;
}

int CRegSettings::GetMainFrameRight()
{
	int Right;
	if (m_pApp = AfxGetApp())
		Right = m_pApp->GetProfileInt (KEY_MAINFRAME, ENTRY_RIGHT,
		GetSystemMetrics(SM_CXMAXIMIZED) - GetSystemMetrics(SM_CYICON));
	return Right;
}

int CRegSettings::GetTreeViewWidth()
{
	int TreeWidth;
	if (m_pApp = AfxGetApp())
		TreeWidth = m_pApp->GetProfileInt (KEY_VIEWS, ENTRY_TREEWIDTH, 150);
	return TreeWidth;
}


CString CRegSettings::GetDatabasePath()
{
	CString DBPath;
	if (m_pApp = AfxGetApp())
		DBPath = m_pApp->GetProfileString (KEY_DB, ENTRY_DBPATH, _T(""));
	return DBPath;
}

void CRegSettings::SetDatabasePath(CString DBPath)
{
	if (m_pApp = AfxGetApp())
		m_pApp->WriteProfileString (KEY_DB, ENTRY_DBPATH, DBPath);
	return;
}

CString CRegSettings::GetHPPath()
{
	CString HPPath;
	if (m_pApp = AfxGetApp())
		HPPath = m_pApp->GetProfileString (KEY_HP, ENTRY_HPPATH, _T(""));
	return HPPath;
}

void CRegSettings::SetHPPath(CString HPPath)
{
	if (m_pApp = AfxGetApp())
		m_pApp->WriteProfileString (KEY_HP, ENTRY_HPPATH, HPPath);
	return;
}

