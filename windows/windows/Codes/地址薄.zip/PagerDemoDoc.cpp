// PagerDemoDoc.cpp : implementation of the CPagerDemoDoc class
//

#include "stdafx.h"
#include "PagerDemo.h"
#include "PagerDemoDoc.h"
#include "hints.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoDoc

IMPLEMENT_DYNCREATE(CPagerDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CPagerDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CPagerDemoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoDoc construction/destruction

CPagerDemoDoc* CPagerDemoDoc::g_pDoc = NULL;

CPagerDemoDoc::CPagerDemoDoc()
{
	ASSERT(!g_pDoc);
	g_pDoc = this;

	// initialize the member variables
	m_pDB = NULL;
	m_pSet = NULL;
	m_RecordCount = 0;
	m_Enable = TRUE;

}

CPagerDemoDoc::~CPagerDemoDoc()
{
	if (m_pSet) delete m_pSet;
}

BOOL CPagerDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	if (m_pSet != NULL)  // Close recordset if open
	{
		m_pSet->Close();
		delete m_pSet;
		m_pSet = NULL;
	}
	if (m_pDB != NULL)   // Close database if open
	{
		m_pDB->Close();
		delete m_pDB;
		m_pDB = NULL;
	}

	m_bFileOpen = FALSE; // Database file is not open

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CPagerDemoDoc serialization

void CPagerDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoDoc diagnostics

#ifdef _DEBUG
void CPagerDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPagerDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoDoc commands

BOOL CPagerDemoDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;

	// If user selected a file then try to open it as a database
	m_pDB = new CDaoDatabase;
	ASSERT(m_pDB != NULL);
	try
	{
		m_pDB->Open(lpszPathName);
	}
	catch (CDaoException* e)
	{
		delete m_pDB;
		m_pDB = NULL;

		TCHAR szCause[255];
		CString strFormatted = _T("The data file could not be opened because of this error: \n");
		e->GetErrorMessage(szCause, 255);
		strFormatted += szCause;
		AfxMessageBox(strFormatted, MB_OK | MB_ICONEXCLAMATION);
		e->Delete();
		m_bFileOpen = FALSE;
		return FALSE;
	}

	// If database successfully opened then open EMPLOYEES recordset
	m_pSet = new CDaoRecordsetAccess(m_pDB);
	ASSERT(m_pSet != NULL);
	try
	{
		m_pSet->Open();
		long numRec = m_pSet->GetRecordCount();
	}
	catch (CDaoException* e)
	{
		delete m_pSet;
		m_pSet = NULL;

		TCHAR szCause[255];
		CString strFormatted = _T("The data file could not be opened because of this error: \n");
		e->GetErrorMessage(szCause, 255);
		strFormatted += szCause;
		AfxMessageBox(strFormatted, MB_OK | MB_ICONEXCLAMATION);
		e->Delete();
		m_bFileOpen = FALSE;
		return FALSE;
	}
	// boolean variable to indicate database is open
	m_bFileOpen = TRUE;

	if (m_bFileOpen) {
		UpdateAllViews(NULL, HINT_DB_OPENED, NULL);
	}
	return TRUE;
}

CString CPagerDemoDoc::GetListName(CString m_Name)
{
	if (m_pSet) {
		CString sql(_T("[Name] = "));
		sql += "'";
		sql += m_Name;
		sql += "'";
		m_pSet->m_strFilter = sql;
		// requery the database 
		m_pSet->Requery();
	}
	return m_Name;
}
