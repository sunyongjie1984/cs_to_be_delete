// PagerDemo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "PagerDemo.h"

#include "MainFrm.h"
#include "PagerDemoDoc.h"
#include "PagerDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoApp

BEGIN_MESSAGE_MAP(CPagerDemoApp, CWinApp)
	//{{AFX_MSG_MAP(CPagerDemoApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_TOOL_ABOUT, OnToolAbout)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoApp construction

CPagerDemoApp::CPagerDemoApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CPagerDemoApp object

CPagerDemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoApp initialization

BOOL CPagerDemoApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif
	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("AddressBook"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CPagerDemoDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CPagerDemoView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The one and only window has been initialized, so show and update it.
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	return TRUE;
}

char* CPagerDemoApp::SetToday(char* str)
{
	time_t osBinaryTime;  // C run-time time (defined in <time.h>)
	time(&osBinaryTime ) ;  // Get the current time  
	struct tm* ptr = localtime(&osBinaryTime ); 
	sprintf(str,"%02d/%02d/%0004d", ptr->tm_mon+1, ptr->tm_mday ,ptr->tm_year +1900);	
	return str;	
}
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	void UpdateFont();
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CCJHyperLink	m_staticEmail;
	CStatic     	m_staticDisclaimer;
	CString			m_editDisclaimer;
	CAnimateCtrl m_wndAnimate;
	//}}AFX_DATA

	CFont	m_Font;
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	m_editDisclaimer = _T("");
	//}}AFX_DATA_INIT

	m_editDisclaimer.LoadString(IDS_DISCLAIMER);
	UpdateFont();
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_STATIC_MAILME, m_staticEmail);
	DDX_Control(pDX, IDC_STATIC_DISCLAIMER, m_staticDisclaimer);
	DDX_Text(pDX, IDC_EDIT_DISCLAIMER, m_editDisclaimer);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CAboutDlg::UpdateFont()
{
	NONCLIENTMETRICS ncm;
	memset(&ncm, 0, sizeof(NONCLIENTMETRICS));
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	VERIFY(::SystemParametersInfo(SPI_GETNONCLIENTMETRICS,
		sizeof(NONCLIENTMETRICS), &ncm, 0));
	ncm.lfMessageFont.lfWeight = 700;
	m_Font.CreateFontIndirect(&ncm.lfMessageFont);
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// set the hyperlinks and static font.
	m_staticEmail.SetURL(_T("mailto:DmitriyOk@aol.com"));
	m_staticDisclaimer.SetFont(&m_Font);

	if (!m_wndAnimate.Create(WS_CHILD | WS_VISIBLE | ACS_AUTOPLAY,
		CRect(385, 25, 0, 100), this, 0) ||
		!m_wndAnimate.Open(IDR_VC))
	{
		TRACE0("Failed to create animation control.\n");
		return -1;      // fail to create
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////
// App command to run the dialog
void CPagerDemoApp::OnAppAbout()
{
}

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoApp message handlers


void CPagerDemoApp::OnToolAbout() 
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();	
}
