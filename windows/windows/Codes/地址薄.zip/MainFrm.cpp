// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "PagerDemo.h"

#include "MainFrm.h"
#include "PagerDemoDoc.h"
#include "FindDlg.h"
#include "hints.h"
#include "HomePageDlg.h"

#include "PagerDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_COMMAND(ID_TOOL_FINDRECORD, OnToolFindrecord)
	ON_COMMAND(ID_TOOL_NEWRECORD, OnToolNewrecord)
	ON_COMMAND(ID_FILE_WEB, OnFileWeb)
	ON_COMMAND(ID_FILE_OPENDB, OnFileOpendb)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndMenuBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndMenuBar.LoadMenu(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndMenuBar);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;

	cs.style = WS_OVERLAPPED|WS_CAPTION|WS_THICKFRAME|WS_SYSMENU|
		WS_MINIMIZEBOX|WS_MAXIMIZEBOX|WS_MAXIMIZE;

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

// setting window caption
void CMainFrame::OnUpdateFrameTitle(BOOL bAddToTitle)
{
	CString str;
	str = _T("Address Book");
	SetWindowText(str);
}
/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers



BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
	CWinApp* pApp = AfxGetApp();
	CRect rect;
	int status;

	// if user closed window in MAX state it still remembers
	// the normal window settings 
	status		= CPagerDemoDoc::g_pDoc->m_pRegSettings.GetMainFrameStatus();
	rect.top	= CPagerDemoDoc::g_pDoc->m_pRegSettings.GetMainFrameTop(); 
	rect.left	= CPagerDemoDoc::g_pDoc->m_pRegSettings.GetMainFrameLeft(); 
	rect.bottom	= CPagerDemoDoc::g_pDoc->m_pRegSettings.GetMainFrameBottom();
	rect.right	= CPagerDemoDoc::g_pDoc->m_pRegSettings.GetMainFrameRight();

	// if window status was MINIMIZED - restore to normal window
	if (status == SW_SHOWMINIMIZED) status = SW_SHOWNORMAL;
	if (pApp) pApp->m_nCmdShow = status;

	MoveWindow (&rect, TRUE);
	return CFrameWnd::OnCreateClient(lpcs, pContext);
}

void CMainFrame::OnDestroy() 
{
	CFrameWnd::OnDestroy();
	
	CWinApp* pApp = AfxGetApp();
	WINDOWPLACEMENT wp;
	wp.length = sizeof(WINDOWPLACEMENT);
    
	CFrameWnd::OnDestroy();

	if (pApp && GetWindowPlacement (&wp))
	{
		CPagerDemoDoc::g_pDoc->m_pRegSettings.SetMainFrameStatus (wp.showCmd);
		CPagerDemoDoc::g_pDoc->m_pRegSettings.SetMainFrameTop    (wp.rcNormalPosition.top);
		CPagerDemoDoc::g_pDoc->m_pRegSettings.SetMainFrameLeft   (wp.rcNormalPosition.left);
		CPagerDemoDoc::g_pDoc->m_pRegSettings.SetMainFrameBottom (wp.rcNormalPosition.bottom);
		CPagerDemoDoc::g_pDoc->m_pRegSettings.SetMainFrameRight  (wp.rcNormalPosition.right);
	}
}

void CMainFrame::OnToolFindrecord() 
{
	CFindDlg dlg;
	dlg.DoModal();
	
}


void CMainFrame::OnToolNewrecord() 
{
	if (CPagerDemoDoc::g_pDoc->m_bFileOpen) 
		CPagerDemoDoc::g_pDoc->UpdateAllViews(NULL, HINT_NEW_RECORD, NULL);
	else
		AfxMessageBox("Please specify new database location", MB_ICONEXCLAMATION);	
}

void CMainFrame::OnFileWeb() 
{

}

void CMainFrame::OnFileOpendb() 
{
	CFileDialog dlg(TRUE,
		".mdb",
		"Address Book.mdb",
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		0,
		this);
		if (dlg.DoModal() == IDOK) {
			CPagerDemoDoc::g_pDoc->OnNewDocument();
			CPagerDemoDoc::g_pDoc->m_pRegSettings.SetDatabasePath(dlg.GetPathName());
			CPagerDemoDoc::g_pDoc->OnOpenDocument(dlg.GetPathName());
			if (CPagerDemoDoc::g_pDoc->m_bFileOpen) 
				CPagerDemoDoc::g_pDoc->UpdateAllViews(NULL, HINT_DB_OPENED, NULL);
		}
	
}
