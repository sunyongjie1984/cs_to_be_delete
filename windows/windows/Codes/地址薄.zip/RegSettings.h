// RegSettings.h: interface for the CRegSettings class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_REGSETTINGS_H__D3F3013C_5F7E_11D3_A69F_00C04F796AE5__INCLUDED_)
#define AFX_REGSETTINGS_H__D3F3013C_5F7E_11D3_A69F_00C04F796AE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRegSettings  
{
public:
	void SetDatabasePath(CString DBPath);
	CString GetDatabasePath();
	void SetHPPath(CString HPPath);
	CString GetHPPath();
	int GetTreeViewWidth();
	int GetMainFrameRight();
	int GetMainFrameBottom();
	int GetMainFrameLeft();
	int GetMainFrameTop();
	int GetMainFrameStatus();
	void SetTreeViewWidth(int TreeWidth);
	void SetMainFrameRight(int Right);
	void SetMainFrameBottom(int Bottom);
	void SetMainFrameLeft(int Left);
	void SetMainFrameTop(int Top);
	void SetMainFrameStatus(int Status);
	CRegSettings();
	virtual ~CRegSettings();

private:
	CWinApp* m_pApp;

};

#endif // !defined(AFX_REGSETTINGS_H__D3F3013C_5F7E_11D3_A69F_00C04F796AE5__INCLUDED_)
