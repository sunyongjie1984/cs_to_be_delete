#if !defined(AFX_UPDATEDLG_H__D3F30139_5F7E_11D3_A69F_00C04F796AE5__INCLUDED_)
#define AFX_UPDATEDLG_H__D3F30139_5F7E_11D3_A69F_00C04F796AE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UpdateDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CUpdateDlg dialog

class CUpdateDlg : public CDialog
{
// Construction
public:
	CUpdateDlg(CWnd* pParent = NULL);   // standard constructor
	void CUpdateDlg::UpdateFont();

// Dialog Data
	//{{AFX_DATA(CUpdateDlg)
	enum { IDD = IDD_DIALOG1 };
	CEdit	m_EditEMail;
	CString	m_Address;
	CString	m_CPhone;
	CString	m_HPhone;
	CString	m_Name;
	CString	m_Note;
	CString	m_WPhone;
	CCJHyperLink	m_staticEmail;
	CFont	m_Font;
	CString	m_EMailAddress;
	CString	m_MailAddress;
	CString	m_StaticEMail;
	CAnimateCtrl     m_wndAnimate;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUpdateDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUpdateDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UPDATEDLG_H__D3F30139_5F7E_11D3_A69F_00C04F796AE5__INCLUDED_)
