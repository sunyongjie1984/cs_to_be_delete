// FindDlg.cpp : implementation file
//

#include "stdafx.h"
#include "pagerdemo.h"
#include "FindDlg.h"
#include "PagerDemoDoc.h"
#include "HyperLink.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// list view control header IDs, loaded from resource
UINT CFindDlg::m_ColumnLabelID [NUM_COLUMNS] = 
{
	IDS_TABLE_HEAD_NAME,
	IDS_TABLE_HEAD_ADDRESS,
	IDS_TABLE_HEAD_EMAIL,
	IDS_TABLE_HEAD_WPHONE,
	IDS_TABLE_HEAD_MPHONE,
	IDS_TABLE_HEAD_HPHONE,
	IDS_TABLE_HEAD_NOTE,
};


// list view column format
int CFindDlg::m_ColumnFormat [NUM_COLUMNS] = 
{
	LVCFMT_LEFT, LVCFMT_LEFT, LVCFMT_LEFT, LVCFMT_LEFT, LVCFMT_LEFT, LVCFMT_LEFT, LVCFMT_LEFT
};
/////////////////////////////////////////////////////////////////////////////
// CFindDlg dialog


CFindDlg::CFindDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFindDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFindDlg)
	m_EditFind = _T("");
	//}}AFX_DATA_INIT
}


void CFindDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFindDlg)
	DDX_Control(pDX, IDC_EDIT_FIND, m_ComboFind);
	DDX_Control(pDX, IDC_LIST1, m_ListCtrlFind);
	DDX_Text(pDX, IDC_EDIT_FIND, m_EditFind);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFindDlg, CDialog)
	//{{AFX_MSG_MAP(CFindDlg)
	ON_BN_CLICKED(ID_FIND, OnFind)
	ON_BN_CLICKED(IDCLEAR, OnClear)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST1, OnDblclkList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFindDlg message handlers

BOOL CFindDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if (!m_wndAnimate.Create(WS_CHILD | WS_VISIBLE | ACS_AUTOPLAY,
		CRect(841, 25, 0, 100), this, 0) ||
		!m_wndAnimate.Open(IDR_VC))
	{
		TRACE0("Failed to create animation control.\n");
		return -1;      // fail to create
	}

	int Column;
	LV_COLUMN		LVColumn;		// column info of one column in list control
	
	DWORD dwStyle = ListView_GetExtendedListViewStyle(m_ListCtrlFind);
	//Add the full row select and grid line style to the existing extended styles
	 dwStyle |= LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES;
	ListView_SetExtendedListViewStyle (m_ListCtrlFind, dwStyle);

	m_ListCtrlFind.DeleteAllItems ();// regular cleanup
	
	//initialize the columns (insert columns)
	m_ColumnWidth [COL_NAME      ] = 150;
	m_ColumnWidth [COL_WPHONE    ] = 100;
	m_ColumnWidth [COL_MPHONE    ] = 100;
	m_ColumnWidth [COL_HPHONE    ] = 100;
	m_ColumnWidth [COL_ADDRESS   ] = 170;
	m_ColumnWidth [COL_EMAIL     ] = 130;
	m_ColumnWidth [COL_NOTE      ] = 200;

	// set header and format for all visible columns
	LVColumn.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	if (CPagerDemoDoc::g_pDoc->m_pSet) {
		for (Column = 0; (Column < NUM_COLUMNS); Column++)
		{
			CString		HeaderString;
		
			// fill header data
			HeaderString.LoadString (m_ColumnLabelID [Column]);

			LVColumn.iSubItem	= Column;
			LVColumn.pszText	= (LPTSTR) (LPCTSTR) HeaderString;
			LVColumn.cx			= m_ColumnWidth [Column];
			LVColumn.fmt		= m_ColumnFormat [Column];
			m_ListCtrlFind.InsertColumn (Column, &LVColumn);
		}
	}
	CDaoRecordsetAccess *pRS;
	pRS = new CDaoRecordsetAccess(CPagerDemoDoc::g_pDoc->m_pDB);
	ASSERT(pRS != NULL);
	try
	{
		pRS->Open();
		long numRec = pRS->GetRecordCount();
	}
	catch (CDaoException* e)
	{
		delete pRS;
		pRS = NULL;

		TCHAR szCause[255];
		CString strFormatted = _T("The data file could not be opened because of this error: \n");
		e->GetErrorMessage(szCause, 255);
		strFormatted += szCause;
		AfxMessageBox(strFormatted, MB_OK | MB_ICONEXCLAMATION);
		e->Delete();
		return FALSE;
	}
	CString sql;
	pRS->GetDefaultSQL();
	int i;
	if (pRS) {
		for (i = 0; i < pRS->GetRecordCount(); i++) {
			m_ComboFind.AddString(pRS->m_Name);
			pRS->MoveNext();
		}
	}
	delete pRS;
	return TRUE;  
}

void CFindDlg::OnFind() 
{
	m_ListCtrlFind.DeleteAllItems();
	CDaoRecordsetAccess *pRS;
	pRS = new CDaoRecordsetAccess(CPagerDemoDoc::g_pDoc->m_pDB);
	ASSERT(pRS != NULL);
	try
	{
		pRS->Open();
		long numRec = pRS->GetRecordCount();
	}
	catch (CDaoException* e)
	{
		delete pRS;
		pRS = NULL;

		TCHAR szCause[255];
		CString strFormatted = _T("The data file could not be opened because of this error: \n");
		e->GetErrorMessage(szCause, 255);
		strFormatted += szCause;
		AfxMessageBox(strFormatted, MB_OK | MB_ICONEXCLAMATION);
		e->Delete();
		return ;
	}
	pRS->GetDefaultSQL();
	int i = 0;
	
	UpdateData(TRUE);
	

	if (m_EditFind ==_T("")) {
		AfxMessageBox(_T("Please enter person's name!"), MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	else {
		CString str = m_EditFind;
		CString sql(_T("[Name] = "));
		sql += "'";
		sql += str;
		sql += "'";
		pRS->m_strFilter = sql;
		// requery the database
		pRS->Requery();
		if (pRS->m_Name != _T("")) {
			while (!pRS->IsEOF()) {
				int ItemIndex;
				int SubitemIndex = 1;
				ItemIndex = m_ListCtrlFind.InsertItem (LVIF_TEXT | LVIF_PARAM, i, pRS->m_Name,       0, 0, 0, 0);
				m_ListCtrlFind.SetItem (ItemIndex, SubitemIndex++, LVIF_TEXT, pRS->m_Address,        0, 0, 0, 0);
				m_ListCtrlFind.SetItem (ItemIndex, SubitemIndex++, LVIF_TEXT, pRS->m_EmailAddress,   0, 0, 0, 0);
				m_ListCtrlFind.SetItem (ItemIndex, SubitemIndex++, LVIF_TEXT, pRS->m_WorkPhone,      0, 0, 0, 0);
				m_ListCtrlFind.SetItem (ItemIndex, SubitemIndex++, LVIF_TEXT, pRS->m_MobilePhone,    0, 0, 0, 0);
				m_ListCtrlFind.SetItem (ItemIndex, SubitemIndex++, LVIF_TEXT, pRS->m_HomePhone,      0, 0, 0, 0);
				m_ListCtrlFind.SetItem (ItemIndex, SubitemIndex++, LVIF_TEXT, pRS->m_Notes,          0, 0, 0, 0);
				pRS->MoveNext();
			}
		}
		else
			AfxMessageBox(_T("Record not found in this collection!"), MB_OK | MB_ICONEXCLAMATION);	
	}
	delete pRS;
}

void CFindDlg::OnClear()
{
	m_ListCtrlFind.DeleteAllItems();
}

void CFindDlg::OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CDaoRecordsetAccess *pRS;
	pRS = new CDaoRecordsetAccess(CPagerDemoDoc::g_pDoc->m_pDB);
	ASSERT(pRS != NULL);
	try
	{
		pRS->Open();
		long numRec = pRS->GetRecordCount();
	}
	catch (CDaoException* e)
	{
		delete pRS;
		pRS = NULL;

		TCHAR szCause[255];
		CString strFormatted = _T("The data file could not be opened because of this error: \n");
		e->GetErrorMessage(szCause, 255);
		strFormatted += szCause;
		AfxMessageBox(strFormatted, MB_OK | MB_ICONEXCLAMATION);
		e->Delete();
		return ;
	}
	pRS->GetDefaultSQL();
	if (m_EditFind ==_T("")) {
		AfxMessageBox(_T("Please enter person's name!"), MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	else {
		CString str = m_EditFind;
		CString sql(_T("[Name] = "));
		sql += "'";
		sql += str;
		sql += "'";
		pRS->m_strFilter = sql;
		// requery the database
		pRS->Requery();
	}

	CHyperLink::GotoURL("mailto:" + pRS->m_EmailAddress, SW_SHOWNORMAL);
	delete pRS;
	*pResult = 0;
}
