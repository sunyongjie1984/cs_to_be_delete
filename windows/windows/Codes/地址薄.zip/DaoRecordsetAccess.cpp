// DaoRecordsetAccess.cpp : implementation file
//

#include "stdafx.h"
#include "pagerdemo.h"
#include "DaoRecordsetAccess.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoRecordsetAccess

IMPLEMENT_DYNAMIC(CDaoRecordsetAccess, CDaoRecordset)

CDaoRecordsetAccess::CDaoRecordsetAccess(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoRecordsetAccess)
	m_AddressID = 0;
	m_Name = _T("");
	m_Address = _T("");
	m_EmailAddress = _T("");
	m_WorkPhone = _T("");
	m_MobilePhone = _T("");
	m_HomePhone = _T("");
	m_Notes = _T("");
	m_nFields = 8;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoRecordsetAccess::GetDefaultDBName()
{
	return _T("D:\\CJDLLLibrary\\Examples\\AddressBook\\Address Book.mdb");
}

CString CDaoRecordsetAccess::GetDefaultSQL()
{
	return _T("[Data]");
}

void CDaoRecordsetAccess::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoRecordsetAccess)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[AddressID]"), m_AddressID);
	DFX_Text(pFX, _T("[Name]"), m_Name);
	DFX_Text(pFX, _T("[Address]"), m_Address);
	DFX_Text(pFX, _T("[EmailAddress]"), m_EmailAddress);
	DFX_Text(pFX, _T("[WorkPhone]"), m_WorkPhone);
	DFX_Text(pFX, _T("[MobilePhone]"), m_MobilePhone);
	DFX_Text(pFX, _T("[HomePhone]"), m_HomePhone);
	DFX_Text(pFX, _T("[Notes]"), m_Notes);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoRecordsetAccess diagnostics

#ifdef _DEBUG
void CDaoRecordsetAccess::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoRecordsetAccess::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
