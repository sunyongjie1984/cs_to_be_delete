// UpdateDlg.cpp : implementation file
//

#include "stdafx.h"
#include "pagerdemo.h"
#include "UpdateDlg.h"
#include "PagerDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUpdateDlg dialog


CUpdateDlg::CUpdateDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUpdateDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUpdateDlg)
	m_Address = _T("");
	m_CPhone = _T("");
	m_HPhone = _T("");
	m_Name = _T("");
	m_Note = _T("");
	m_WPhone = _T("");
	m_EMailAddress = _T("");
	m_MailAddress = _T("");
	m_StaticEMail = _T("");
	//}}AFX_DATA_INIT
}


void CUpdateDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUpdateDlg)
	DDX_Control(pDX, IDC_EDIT_MAILME, m_EditEMail);
	DDX_Text(pDX, IDC_EDIT_ADDRESS, m_Address);
	DDX_Text(pDX, IDC_EDIT_CPHONE, m_CPhone);
	DDX_Text(pDX, IDC_EDIT_HPHONE, m_HPhone);
	DDX_Text(pDX, IDC_EDIT_NAME, m_Name);
	DDX_Text(pDX, IDC_EDIT_NOTE, m_Note);
	DDX_Text(pDX, IDC_EDIT_WPHONE, m_WPhone);
	DDX_Control(pDX, IDC_STATIC_MAILME1, m_staticEmail);
	DDX_Text(pDX, IDC_EDIT_MAILME, m_MailAddress);
	DDX_Text(pDX, IDC_STATIC_MAILME1, m_StaticEMail);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUpdateDlg, CDialog)
	//{{AFX_MSG_MAP(CUpdateDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUpdateDlg message handlers

BOOL CUpdateDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CDaoRecordsetAccess *pRS;
	pRS = CPagerDemoDoc::g_pDoc->GetRecSet();

	m_staticEmail.SetURL(_T("mailto:" + pRS->m_EmailAddress));

	if (!m_wndAnimate.Create(WS_CHILD | WS_VISIBLE | ACS_AUTOPLAY,
		CRect(580, 25, 0, 100), this, 0) ||
		!m_wndAnimate.Open(IDR_VC))
	{
		TRACE0("Failed to create animation control.\n");
		return -1;      // fail to create
	}

	return TRUE; 
}

void CUpdateDlg::UpdateFont()
{
	NONCLIENTMETRICS ncm;
	memset(&ncm, 0, sizeof(NONCLIENTMETRICS));
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	VERIFY(::SystemParametersInfo(SPI_GETNONCLIENTMETRICS,
		sizeof(NONCLIENTMETRICS), &ncm, 0));
	ncm.lfMessageFont.lfWeight = 700;
	m_Font.CreateFontIndirect(&ncm.lfMessageFont);
}
