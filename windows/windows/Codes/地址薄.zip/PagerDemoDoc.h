// PagerDemoDoc.h : interface of the CPagerDemoDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PAGERDEMODOC_H__790EB20A_2913_11D3_ABAE_94F400C10000__INCLUDED_)
#define AFX_PAGERDEMODOC_H__790EB20A_2913_11D3_ABAE_94F400C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "RegSettings.h"
#include "DaoRecordsetAccess.h"

class CPagerDemoDoc : public CDocument
{
protected: // create from serialization only
	CPagerDemoDoc();
	DECLARE_DYNCREATE(CPagerDemoDoc)

// Attributes
public:

	CDaoDatabase			*m_pDB;
	CDaoRecordsetAccess		*m_pSet;
	BOOL m_Enable;
	BOOL m_bFileOpen;
	long                    m_RecordCount;
	CRegSettings            m_pRegSettings;
	CString                 m_Name;
public:
	static CPagerDemoDoc*	g_pDoc;		// global pointer to the document

// Operations
public:
	CDaoRecordsetAccess * GetRecSet() {return m_pSet;}
	BOOL IsFileOpen() {return m_bFileOpen;}
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPagerDemoDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	CString GetListName(CString m_Name);
	virtual ~CPagerDemoDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	
// Generated message map functions
protected:
	//{{AFX_MSG(CPagerDemoDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGERDEMODOC_H__790EB20A_2913_11D3_ABAE_94F400C10000__INCLUDED_)
