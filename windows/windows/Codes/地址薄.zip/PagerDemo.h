// PagerDemo.h : main header file for the PAGERDEMO application
//

#if !defined(AFX_PAGERDEMO_H__790EB204_2913_11D3_ABAE_94F400C10000__INCLUDED_)
#define AFX_PAGERDEMO_H__790EB204_2913_11D3_ABAE_94F400C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoApp:
// See PagerDemo.cpp for the implementation of this class
//

class CPagerDemoApp : public CWinApp
{
public:
	CPagerDemoApp();

protected:

char* SetToday(char* str);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPagerDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CPagerDemoApp)
	afx_msg void OnAppAbout();
	afx_msg void OnToolAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGERDEMO_H__790EB204_2913_11D3_ABAE_94F400C10000__INCLUDED_)
