// HomePageDlg.cpp : implementation file
//

#include "stdafx.h"
#include "pagerdemo.h"
#include "HomePageDlg.h"
#include "PagerDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHomePageDlg dialog


CHomePageDlg::CHomePageDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHomePageDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHomePageDlg)
	m_Path = _T("");
	//}}AFX_DATA_INIT
}


void CHomePageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHomePageDlg)
	DDX_Text(pDX, IDC_EDIT1, m_Path);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CHomePageDlg, CDialog)
	//{{AFX_MSG_MAP(CHomePageDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHomePageDlg message handlers

BOOL CHomePageDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	if (!m_wndAnimate.Create(WS_CHILD | WS_VISIBLE | ACS_AUTOPLAY,
		CRect(420, 15, 0, 100), this, 0) ||
		!m_wndAnimate.Open(IDR_VC))
	{
		TRACE0("Failed to create animation control.\n");
		return -1;      // fail to create
	}
	m_Path = CPagerDemoDoc::g_pDoc->m_pRegSettings.GetHPPath();
	UpdateData(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CHomePageDlg::OnOK() 
{
	UpdateData(TRUE);
	if (m_Path != CPagerDemoDoc::g_pDoc->m_pRegSettings.GetHPPath()) 
		CPagerDemoDoc::g_pDoc->m_pRegSettings.SetHPPath(m_Path);
		
	CDialog::OnOK();
}
