// TransParentDlg.h : header file
//

#if !defined(AFX_TRANSPARENTDLG_H__45F46707_E198_11D3_A999_9E9231505A2F__INCLUDED_)
#define AFX_TRANSPARENTDLG_H__45F46707_E198_11D3_A999_9E9231505A2F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TransParentButton.h"

/////////////////////////////////////////////////////////////////////////////
// CTransParentDlg dialog

class CTransParentDlg : public CDialog
{
// Construction
public:
	CTransParentDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTransParentDlg)
	enum { IDD = IDD_TRANSPARENT_DIALOG };
	CTransParentButton	m_btnExit;
	CTransParentButton	m_btn6;
	CTransParentButton	m_btn5;
	CTransParentButton	m_btn4;
	CTransParentButton	m_btn3;
	CTransParentButton	m_btn2;
	CTransParentButton	m_btn1;
	CTransParentButton	m_btntransparent;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTransParentDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTransParentDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRANSPARENTDLG_H__45F46707_E198_11D3_A999_9E9231505A2F__INCLUDED_)
