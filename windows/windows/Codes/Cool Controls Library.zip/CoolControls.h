
/******************************************************************

$Archive: /CoolControls/CoolControls.h $
$Workfile: CoolControls.h $
$Author: Bogdan Ledwig $
$Date: 98-10-26 23:32 $
$Revision: 1 $

*******************************************************************/

#if !defined (__CoolControls_h)
#define __CoolControls_h

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCoolControlsApp:
// See CoolControls.cpp for the implementation of this class
//

class CCoolControlsApp : public CWinApp
{
public:
   CCoolControlsApp();

// Overrides
	// ClassWizard generated virtual function overrides
   //{{AFX_VIRTUAL(CCoolControlsApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

   //{{AFX_MSG(CCoolControlsApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // __CoolControls_h
