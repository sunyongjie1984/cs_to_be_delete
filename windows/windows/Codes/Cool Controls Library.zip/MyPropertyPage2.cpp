
/******************************************************************

$Archive: $
$Workfile: $
$Author: $
$Date: $
$Revision: $

*******************************************************************/

#include "StdAfx.h"
#include "resource.h"
#include "MyPropertyPage2.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMyPropertyPage2, CPropertyPage)

/////////////////////////////////////////////////////////////////////////////
// CMyPropertyPage2 property page

CMyPropertyPage2::CMyPropertyPage2() : CPropertyPage(CMyPropertyPage2::IDD)
{
	//{{AFX_DATA_INIT(CMyPropertyPage2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CMyPropertyPage2::~CMyPropertyPage2()
{
}
                                       
void CMyPropertyPage2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyPropertyPage2)
	DDX_Control(pDX, IDC_COMBOBOXEX1, m_ctlComboEx);
   DDX_Control(pDX, IDC_TREE1, m_ctlTree1);
   DDX_Control(pDX, IDC_LIST1, m_ctlList1);		
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyPropertyPage2, CPropertyPage)
	//{{AFX_MSG_MAP(CMyPropertyPage2)	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CMyPropertyPage2::OnInitDialog()
{
   CPropertyPage::OnInitDialog();

   m_imgList.Create( IDB_BITMAP1, 16, 1, RGB( 0, 128, 128 ) );

   // Init the combobox
   {
      m_ctlComboEx.SetImageList( &m_imgList );

      COMBOBOXEXITEM ci;
      for ( int i = 0; i < 4; i++ )
      {
         ci.mask = CBEIF_IMAGE | CBEIF_SELECTEDIMAGE;
         ci.iItem = i;
         ci.iImage = i;
         ci.iSelectedImage = i;
         m_ctlComboEx.SetItem( &ci );
      }
      m_ctlComboEx.SetCurSel( 0 );
   }

   m_ctlList1.SetImageList( &m_imgList, LVSIL_SMALL );
   m_ctlList1.SetExtendedStyle( LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP );

   // Now fill the list control
   {
      TCHAR szBuf[20];
      LV_COLUMN lvc;

      int i;
      for ( i = 0; i < 6; i++ )
      {
         wsprintf( szBuf, _T( "Col %d" ), i );
         lvc.mask     = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
         lvc.fmt      = LVCFMT_LEFT;
         lvc.pszText  = szBuf;
         lvc.iSubItem = i;         
         lvc.cx       = 50;
         m_ctlList1.InsertColumn( i, &lvc );
      }

      // Will now insert the items and subitems into the list view.
      LV_ITEM lvItem;

      for ( int j = 0; j < 6; j++ )      
         for ( i = 0; i < 60; i++ )      
         {
            wsprintf( szBuf, _T( "%d, %d" ), i, j );
            UINT nItem = 0;
            lvItem.mask = LVIF_TEXT | LVIF_IMAGE;
            lvItem.iItem = i;      
            lvItem.iSubItem = j;
            lvItem.iImage   = 3;
            lvItem.pszText = szBuf; 
            if ( !j )
               m_ctlList1.InsertItem( &lvItem );
            else
               m_ctlList1.SetItem( &lvItem );            
         }
   }

   // Fill the tree view
   {
      TCHAR szBuf[30];
      HTREEITEM hi1, hi2;

      m_ctlTree1.SetImageList( &m_imgList, TVSIL_NORMAL );

      m_hi = m_ctlTree1.InsertItem( _T( "Root" ), 0, 0 );
      for ( int i = 0; i < 5; i++ )
      {
         wsprintf( szBuf, _T( "Item %d" ), i );
         hi1 = m_ctlTree1.InsertItem( szBuf, 1, 2, m_hi );
         for ( int j = 0; j < 5; j++ )
         {
            wsprintf( szBuf, _T( "Subitem %d" ), j );
            hi2 = m_ctlTree1.InsertItem( szBuf, 3, 3, hi1 );
         }         
      }      
   }
   m_ctlTree1.Expand( m_hi, TVE_EXPAND );
   return TRUE;
}
