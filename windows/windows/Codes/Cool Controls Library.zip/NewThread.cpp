
/******************************************************************

$Archive: $
$Workfile: $
$Author: $
$Date: $
$Revision: $

*******************************************************************/

#include "StdAfx.h"
#include "CoolControls.h"
#include "NewThread.h"

#include "MyDialog.h"
#include "CoolControlsManager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewThread

IMPLEMENT_DYNCREATE(CNewThread, CWinThread)

CNewThread::CNewThread()
{
}

CNewThread::~CNewThread()
{
}

BOOL CNewThread::InitInstance()
{
   GetCtrlManager().InstallHook();

	CMyDialog dlg;
   dlg.DoModal();
   
	return FALSE;
}

int CNewThread::ExitInstance()
{	
   GetCtrlManager().UninstallHook();
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CNewThread, CWinThread)
	//{{AFX_MSG_MAP(CNewThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewThread message handlers
