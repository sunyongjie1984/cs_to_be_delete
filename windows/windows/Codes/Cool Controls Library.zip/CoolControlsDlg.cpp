
/******************************************************************

$Archive: /CoolControls/CoolControlsDlg.cpp $
$Workfile: CoolControlsDlg.cpp $
$Author: Bogdan Ledwig $
$Date: 98-10-26 23:32 $
$Revision: 1 $

*******************************************************************/

#include "StdAfx.h"
#include "CoolControls.h"
#include "CoolControlsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCoolControlsDlg dialog

CCoolControlsDlg::CCoolControlsDlg(CWnd* pParent /*=NULL*/)
   : CDialog(CCoolControlsDlg::IDD, pParent)
{
   //{{AFX_DATA_INIT(CCoolControlsDlg)
	m_nCombo1 = 0;
	m_nCombo3 = 0;
	m_nEditMulti = _T("001\r\n002\r\n003\r\n004\r\n005\r\n006\r\n007\r\n008\r\n009");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCoolControlsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
   //{{AFX_DATA_MAP(CCoolControlsDlg)
	DDX_Control(pDX, IDC_TREE1, m_ctlTree1);
	DDX_Control(pDX, IDC_SCROLLBAR1, m_ctlVScroll);
	DDX_Control(pDX, IDC_SCROLLBAR2, m_ctlHScroll);
	DDX_Control(pDX, IDC_SPIN11, m_ctlSpin2);
	DDX_Control(pDX, IDC_SPIN10, m_ctlSpin1);
	DDX_Control(pDX, IDC_COMBO2, m_ctlCombo2);
	DDX_Control(pDX, IDC_COMBO4, m_ctlCombo4);
   DDX_Control(pDX, IDC_LIST1, m_ctlList1);
	DDX_CBIndex(pDX, IDC_COMBO1, m_nCombo1);
	DDX_CBIndex(pDX, IDC_COMBO3, m_nCombo3);
	DDX_Text(pDX, IDC_EDIT4, m_nEditMulti);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCoolControlsDlg, CDialog)
   //{{AFX_MSG_MAP(CCoolControlsDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_CHECK5, OnCheck5)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCoolControlsDlg message handlers

BOOL CCoolControlsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

   m_ctlCombo2.SetCurSel( 0 );
   m_ctlCombo4.SetCurSel( 0 );

   m_ctlSpin1.SetRange( 0, 100 );
   m_ctlSpin2.SetRange( 0, 100 );

   SCROLLINFO si;
   si.cbSize = sizeof( SCROLLINFO );
   si.fMask = SIF_RANGE | SIF_PAGE;
   si.nMin = 0;
   si.nMax = 100;
   si.nPage = 20;
   
   m_ctlHScroll.SetScrollInfo( &si );
   m_ctlVScroll.SetScrollInfo( &si );

   m_imgList.Create( IDB_BITMAP1, 16, 1, RGB( 0, 128, 128 ) );

   m_ctlList1.SetImageList( &m_imgList, LVSIL_SMALL );

   // Now fill the list control
   {
      TCHAR szBuf[20];
      LV_COLUMN lvc;

      int i;
      for ( i = 0; i < 6; i++ )
      {
         wsprintf( szBuf, "Col %d", i );
         lvc.mask     = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
         lvc.fmt      = LVCFMT_LEFT;
         lvc.pszText  = szBuf;
         lvc.iSubItem = i;         
         lvc.cx       = 50;
         m_ctlList1.InsertColumn( i, &lvc );
      }

      // Will now insert the items and subitems into the list view.
      LV_ITEM lvItem;

      for ( int j = 0; j < 6; j++ )      
         for ( i = 0; i < 60; i++ )      
         {
            wsprintf( szBuf, "%d, %d", i, j );
            UINT nItem = 0;
            lvItem.mask = LVIF_TEXT | LVIF_IMAGE;
            lvItem.iItem = i;      
            lvItem.iSubItem = j;
            lvItem.iImage   = 3;
            lvItem.pszText = szBuf; 
            if ( !j )
               m_ctlList1.InsertItem( &lvItem );
            else
               m_ctlList1.SetItem( &lvItem );            
         }
   }

   // Fill the tree view
   {
      TCHAR szBuf[30];
      HTREEITEM hi1, hi2;

      m_ctlTree1.SetImageList( &m_imgList, TVSIL_NORMAL );

      m_hi = m_ctlTree1.InsertItem( "Root", 0, 0 );
      for ( int i = 0; i < 5; i++ )
      {
         wsprintf( szBuf, "Item %d", i );
         hi1 = m_ctlTree1.InsertItem( szBuf, 1, 2, m_hi );
         for ( int j = 0; j < 5; j++ )
         {
            wsprintf( szBuf, "Subitem %d", j );
            hi2 = m_ctlTree1.InsertItem( szBuf, 3, 3, hi1 );            
         }         
      }      
   }

   //m_ctlEdit.setMask( "##-###" );
   
	// CG: The following block was added by the ToolTips component.
   {	
		// Create the ToolTip control.
		m_tooltip.Create(this);
		m_tooltip.Activate(TRUE);

		// TODO: Use one of the following forms to add controls:
		m_tooltip.AddTool(GetDlgItem(IDC_COMBO1), IDS_COMBO1);
      m_tooltip.AddTool(GetDlgItem(IDC_COMBO2), IDS_COMBO2);
      m_tooltip.AddTool(GetDlgItem(IDC_COMBO3), IDS_COMBO3);
      m_tooltip.AddTool(GetDlgItem(IDC_COMBO4), IDS_COMBO4);

      m_tooltip.AddTool(GetDlgItem(IDC_EDIT1), IDS_EDIT1);
      m_tooltip.AddTool(GetDlgItem(IDC_EDIT2), IDS_EDIT2);
      m_tooltip.AddTool(GetDlgItem(IDC_EDIT3), IDS_EDIT3);
      m_tooltip.AddTool(GetDlgItem(IDC_EDIT4), IDS_EDIT4);

      m_tooltip.AddTool(GetDlgItem(IDC_DATETIMEPICKER1), IDS_DATETIMEPICKER1);
      m_tooltip.AddTool(GetDlgItem(IDC_DATETIMEPICKER2), IDS_DATETIMEPICKER2);
      m_tooltip.AddTool(GetDlgItem(IDC_DATETIMEPICKER3), IDS_DATETIMEPICKER3);

      m_tooltip.AddTool(GetDlgItem(IDC_RADIO1), IDS_RADIO1);
      m_tooltip.AddTool(GetDlgItem(IDC_RADIO2), IDS_RADIO2);

      m_tooltip.AddTool(GetDlgItem(IDC_CHECK1), IDS_CHECK1);
      m_tooltip.AddTool(GetDlgItem(IDC_CHECK2), IDS_CHECK2);
      m_tooltip.AddTool(GetDlgItem(IDC_CHECK3), IDS_CHECK3);

      m_tooltip.AddTool(GetDlgItem(IDC_SCROLLBAR1), IDS_SCROLLBAR1);
      m_tooltip.AddTool(GetDlgItem(IDC_SCROLLBAR2), IDS_SCROLLBAR2);      

      m_tooltip.AddTool(GetDlgItem(IDC_HOTKEY1), IDS_HOTKEY1);      
      m_tooltip.AddTool(GetDlgItem(IDC_LIST1), IDS_LIST1);      
      m_tooltip.AddTool(GetDlgItem(IDC_TREE1), IDS_TREE1);      
      m_tooltip.AddTool(GetDlgItem(IDC_IPADDRESS1), IDS_IPADDRESS1);      
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCoolControlsDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCoolControlsDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCoolControlsDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCoolControlsDlg::OnButton1()
{
   CCoolControlsDlg dlg;
   dlg.DoModal();
}

void CCoolControlsDlg::OnButton2()
{
   AfxMessageBox( "Hello!", MB_YESNOCANCEL | MB_ICONWARNING );
}

BOOL CCoolControlsDlg::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following block was added by the ToolTips component.
	{
		// Let the ToolTip process this message.
		m_tooltip.RelayEvent(pMsg);
	}
	return CDialog::PreTranslateMessage(pMsg);	// CG: This was added by the ToolTips component.
}

void CCoolControlsDlg::OnHScroll(UINT nSBCode, UINT nPo, CScrollBar* pScrollBar) 
{
   static nPos;

   if ( nSBCode == SB_LINELEFT )
      nPos--;
   else if ( nSBCode == SB_LINERIGHT )   
      nPos++;

   if ( nPos < 0 )
      nPos = 0;
   else if ( nPos == 100 )
      nPos--;   

   m_ctlHScroll.SetScrollPos( nPos );

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CCoolControlsDlg::OnVScroll(UINT nSBCode, UINT nPo, CScrollBar* pScrollBar) 
{
   static nPos;

   if ( nSBCode == SB_LINEUP )
      nPos--;
   else if ( nSBCode == SB_LINEDOWN )   
      nPos++;
   else
      nPos = 50;

   if ( nPos < 0 )
      nPos = 0;
   else if ( nPos > 100 )
      nPos = 100;

   m_ctlVScroll.SetScrollPos( nPos );
	
	CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CCoolControlsDlg::OnCheck5() 
{
   m_ctlTree1.Expand( m_hi, TVE_EXPAND );
}
