
/******************************************************************

$Archive: $
$Workfile: $
$Author: $
$Date: $
$Revision: $

*******************************************************************/

#include "StdAfx.h"
#include "resource.h"
#include "MyPropertyPage3.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyPropertyPage3 property page

IMPLEMENT_DYNCREATE(CMyPropertyPage3, CPropertyPage)

CMyPropertyPage3::CMyPropertyPage3() : CPropertyPage(CMyPropertyPage3::IDD)
{
	//{{AFX_DATA_INIT(CMyPropertyPage3)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CMyPropertyPage3::~CMyPropertyPage3()
{
}

void CMyPropertyPage3::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyPropertyPage3)
	DDX_Control(pDX, IDC_TAB4, m_ctlTab4);
	DDX_Control(pDX, IDC_TAB3, m_ctlTab3);
	DDX_Control(pDX, IDC_TAB2, m_ctlTab2);
	DDX_Control(pDX, IDC_TAB1, m_ctlTab1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyPropertyPage3, CPropertyPage)
	//{{AFX_MSG_MAP(CMyPropertyPage3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyPropertyPage3 message handlers


BOOL CMyPropertyPage3::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
   CString str;
   for ( int i = 0; i < 8; i++ )
   {
      str.Format( "Tab %d", i );
      m_ctlTab1.InsertItem( i, str );
      m_ctlTab2.InsertItem( i, str );
      m_ctlTab3.InsertItem( i, str );
      m_ctlTab4.InsertItem( i, str );
   }
   
   m_ctlTab1.ModifyStyle( 0, WS_CLIPCHILDREN );
   m_ctlTab2.ModifyStyle( 0, WS_CLIPCHILDREN );
   	
	return TRUE;
}
