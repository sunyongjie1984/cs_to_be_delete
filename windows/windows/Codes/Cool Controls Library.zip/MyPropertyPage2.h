
/******************************************************************

$Archive: $
$Workfile: $
$Author: $
$Date: $
$Revision: $

*******************************************************************/

#if !defined (__MyPropertyPage2_h)
#define __MyPropertyPage2_h

/////////////////////////////////////////////////////////////////////////////
// CMyPropertyPage2 dialog

class CMyPropertyPage2 : public CPropertyPage
{
	DECLARE_DYNCREATE(CMyPropertyPage2)

// Construction
public:
	CMyPropertyPage2();
	~CMyPropertyPage2();

// Dialog Data
	//{{AFX_DATA(CMyPropertyPage2)
	enum { IDD = IDD_PROPPAGE2 };
	CComboBoxEx	m_ctlComboEx;
   CTreeCtrl	m_ctlTree1;	
	CListCtrl	m_ctlList1;	
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CMyPropertyPage2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CMyPropertyPage2)	
   afx_msg BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

   CImageList m_imgList;
   HTREEITEM m_hi;
};

#endif // __MyPropertyPage2_h
