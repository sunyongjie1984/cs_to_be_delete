
/******************************************************************

$Archive: $
$Workfile: $
$Author: $
$Date: $
$Revision: $

*******************************************************************/

#include "StdAfx.h"
#include "resource.h"
#include "MyPropertyPage1.h"
#include "NewThread.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMyPropertyPage1, CPropertyPage)

/////////////////////////////////////////////////////////////////////////////
// CMyPropertyPage1 property page

CMyPropertyPage1::CMyPropertyPage1() : CPropertyPage(CMyPropertyPage1::IDD)
{
	//{{AFX_DATA_INIT(CMyPropertyPage1)
	m_nCombo1 = 0;
	m_nCombo3 = 0;
	m_nEditMulti = _T("001\r\n002\r\n003\r\n004\r\n005\r\n006\r\n007\r\n008\r\n009");
	m_strRichText = _T("001\r\n002\r\n003\r\n004\r\n005\r\n006\r\n007\r\n008\r\n009");
	//}}AFX_DATA_INIT
}

CMyPropertyPage1::~CMyPropertyPage1()
{
}

void CMyPropertyPage1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyPropertyPage1)
	DDX_Control(pDX, IDC_SCROLLBAR1, m_ctlVScroll);
	DDX_Control(pDX, IDC_SCROLLBAR2, m_ctlHScroll);
   DDX_Control(pDX, IDC_SCROLLBAR3, m_ctlHScroll1);
	DDX_Control(pDX, IDC_COMBO2, m_ctlCombo2);
	DDX_Control(pDX, IDC_COMBO4, m_ctlCombo4);
	DDX_CBIndex(pDX, IDC_COMBO1, m_nCombo1);
	DDX_CBIndex(pDX, IDC_COMBO3, m_nCombo3);
	DDX_Text(pDX, IDC_EDIT4, m_nEditMulti);
	DDX_Control(pDX, IDC_SPIN11, m_ctlSpin2);
	DDX_Control(pDX, IDC_SPIN10, m_ctlSpin1);
	DDX_Text(pDX, IDC_RICHEDIT1, m_strRichText);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyPropertyPage1, CPropertyPage)
	//{{AFX_MSG_MAP(CMyPropertyPage1)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CMyPropertyPage1::OnInitDialog()
{
   CPropertyPage::OnInitDialog();

   m_ctlCombo2.SetCurSel( 0 );
   m_ctlCombo4.SetCurSel( 0 );

   SCROLLINFO si;
   si.cbSize = sizeof( SCROLLINFO );
   si.fMask = SIF_RANGE | SIF_PAGE;
   si.nMin = 0;
   si.nMax = 100;
   si.nPage = 20;
   
   m_ctlHScroll.SetScrollInfo( &si );
   m_ctlVScroll.SetScrollInfo( &si );
   m_ctlHScroll1.SetScrollInfo( &si );

   m_ctlSpin1.SetRange( 0, 100 );
   m_ctlSpin2.SetRange( 0, 100 );

   return TRUE;
}

void CMyPropertyPage1::OnButton1() 
{
	CColorDialog dlg;    
   dlg.m_cc.Flags |= CC_SHOWHELP;
	dlg.DoModal();
}

void CMyPropertyPage1::OnButton3() 
{
	CFontDialog dlg;
   dlg.m_cf.Flags |= CF_SHOWHELP;
   dlg.DoModal();
}

void CMyPropertyPage1::OnButton4() 
{
	CFileDialog dlg( TRUE );
   dlg.m_ofn.Flags |= OFN_SHOWHELP;
   dlg.DoModal();	
}

void CMyPropertyPage1::OnButton5() 
{
   CPageSetupDialog dlg;
   dlg.m_psd.Flags |= PSD_SHOWHELP;
   dlg.DoModal();		
}

void CMyPropertyPage1::OnButton6() 
{
   CPrintDialog dlg( FALSE );
   dlg.m_pd.Flags |= PD_SHOWHELP;
   dlg.DoModal();		
}

void CMyPropertyPage1::OnButton2() 
{
   CWinThread* pThread = AfxBeginThread( RUNTIME_CLASS( CNewThread ) );
   if ( !pThread )
      AfxMessageBox( _T( "Thread creation failed!" ), MB_YESNOCANCEL | MB_ICONWARNING );   
}
