
/******************************************************************

$Archive: /CoolControls/CoolControlsDlg.h $
$Workfile: CoolControlsDlg.h $
$Author: Bogdan Ledwig $
$Date: 98-10-26 23:32 $
$Revision: 1 $

*******************************************************************/

#if !defined (__CoolControlsDlg_h)
#define __CoolControlsDlg_h

/////////////////////////////////////////////////////////////////////////////
// CCoolControlsDlg dialog

class CCoolControlsDlg : public CDialog
{
// Construction
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
   CCoolControlsDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
   //{{AFX_DATA(CCoolControlsDlg)
	enum { IDD = IDD_DEMO_DIALOG };
	CTreeCtrl	m_ctlTree1;
	CScrollBar	m_ctlVScroll;
	CScrollBar	m_ctlHScroll;
	CSpinButtonCtrl	m_ctlSpin2;
	CSpinButtonCtrl	m_ctlSpin1;
	CComboBox	m_ctlCombo2;
	CComboBox	m_ctlCombo4;
	CListCtrl	m_ctlList1;
	int		m_nCombo1;
	int		m_nCombo3;
	CString	m_nEditMulti;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
   //{{AFX_VIRTUAL(CCoolControlsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CToolTipCtrl m_tooltip;
	HICON m_hIcon;

	// Generated message map functions
   //{{AFX_MSG(CCoolControlsDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnCheck5();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

   CImageList m_imgList;
   HTREEITEM m_hi;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // __CoolControlsDlg_h
