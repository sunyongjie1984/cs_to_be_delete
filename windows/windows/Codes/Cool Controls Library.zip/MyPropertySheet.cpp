
/******************************************************************

$Archive: $
$Workfile: $
$Author: $
$Date: $
$Revision: $

*******************************************************************/

#include "StdAfx.h"
#include "resource.h"
#include "MyPropertySheet.h"
#include "AboutBox.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyPropertySheet

IMPLEMENT_DYNAMIC( CMyPropertySheet, CPropertySheet )

CMyPropertySheet::CMyPropertySheet( CWnd* pWndParent ) :
	 CPropertySheet( IDS_PROPSHT_CAPTION, pWndParent )
{
	AddPage( &m_Page1 );
	AddPage( &m_Page2 );
   AddPage( &m_Page3 );
}

CMyPropertySheet::~CMyPropertySheet()
{
}

BEGIN_MESSAGE_MAP( CMyPropertySheet, CPropertySheet )
	//{{AFX_MSG_MAP(CMyPropertySheet)	
   ON_WM_SYSCOMMAND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CMyPropertySheet message handlers

BOOL CMyPropertySheet::OnInitDialog()
{
   CPropertySheet::OnInitDialog();

   // Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT( (IDM_ABOUTBOX & 0xFFF0 ) == IDM_ABOUTBOX );
	ASSERT( IDM_ABOUTBOX < 0xF000 );

	CMenu* pSysMenu = GetSystemMenu( FALSE );
	if ( pSysMenu != NULL )
	{
		CString strAboutMenu;
		strAboutMenu.LoadString( IDS_ABOUTBOX );
		if ( !strAboutMenu.IsEmpty() )
		{
			pSysMenu->AppendMenu( MF_SEPARATOR );
			pSysMenu->AppendMenu( MF_STRING, IDM_ABOUTBOX, strAboutMenu );
		}
	}

   SetIcon( AfxGetApp()->LoadIcon( IDR_MAINFRAME ), TRUE );
   return TRUE;
}

void CMyPropertySheet::OnSysCommand( UINT nID, LPARAM lParam )
{
	if ( (nID & 0xFFF0) == IDM_ABOUTBOX )
	{
		CAboutBox dlgAbout;      
		dlgAbout.DoModal();
	}
	else
	{
		CPropertySheet::OnSysCommand( nID, lParam );
	}
}
