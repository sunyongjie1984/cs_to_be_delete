//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CoolControls.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DEMODIALOG                  102
#define IDS_COMBO1                      102
#define IDS_COMBO2                      103
#define IDS_COMBO3                      104
#define IDS_COMBO4                      105
#define IDS_EDIT1                       106
#define IDS_EDIT2                       107
#define IDS_EDIT3                       108
#define IDS_EDIT4                       109
#define IDS_DATETIMEPICKER1             110
#define IDS_DATETIMEPICKER2             111
#define IDS_DATETIMEPICKER3             112
#define IDS_DATETIMEPICKER4             113
#define IDS_CHECK1                      114
#define IDS_CHECK2                      115
#define IDS_CHECK3                      116
#define IDS_RADIO1                      117
#define IDS_RADIO2                      118
#define IDS_RADIO3                      119
#define IDS_LIST1                       120
#define IDS_TREE1                       121
#define IDS_HOTKEY1                     122
#define IDS_IPADDRESS1                  123
#define IDS_SPIN1                       124
#define IDS_SPIN2                       125
#define IDS_SCROLLBAR1                  126
#define IDS_SCROLLBAR2                  127
#define IDR_MAINFRAME                   128
#define IDS_PROPSHT_CAPTION             129
#define IDD_DEMO_DIALOG                 130
#define IDD_PROPPAGE1                   131
#define IDD_PROPPAGE2                   132
#define IDB_BITMAP1                     134
#define IDD_DIALOG1                     139
#define IDD_DIALOG2                     143
#define IDD_PROPPAGE3                   151
#define IDD_DIALOG3                     152
#define IDC_COMBO1                      1000
#define IDC_COMBO2                      1001
#define IDC_COMBO3                      1002
#define IDC_EDIT1                       1003
#define IDC_EDIT2                       1004
#define IDC_EDIT0                       1004
#define IDC_DATETIMEPICKER1             1006
#define IDC_CHECK1                      1007
#define IDC_CHECK2                      1008
#define IDC_DATETIMEPICKER5             1008
#define IDC_RADIO1                      1009
#define IDC_RADIO2                      1010
#define IDC_CHECK3                      1011
#define IDC_RADIO3                      1012
#define IDC_DATETIMEPICKER3             1013
#define IDC_BUTTON1                     1014
#define IDC_BUTTON3                     1015
#define IDC_BUTTON4                     1016
#define IDC_EDIT4                       1017
#define IDC_BUTTON5                     1019
#define IDC_BUTTON6                     1020
#define IDC_DATETIMEPICKER2             1023
#define IDC_DATETIMEPICKER4             1024
#define IDC_EDIT3                       1025
#define IDC_EDIT                        1025
#define IDC_SPIN1                       1026
#define IDC_SPIN10                      1027
#define IDC_SPIN7                       1027
#define IDC_SPIN11                      1028
#define IDC_SPIN8                       1028
#define IDC_SPIN9                       1029
#define IDC_SPIN12                      1030
#define IDC_LIST1                       1032
#define IDC_BUTTON2                     1033
#define IDC_SPIN2                       1034
#define IDC_SPIN5                       1035
#define IDC_COMBO4                      1037
#define IDC_SPIN3                       1039
#define IDC_SPIN4                       1040
#define IDC_SPIN6                       1041
#define IDC_SCROLLBAR1                  1042
#define IDC_SCROLLBAR2                  1043
#define IDC_TREE1                       1044
#define IDC_SCROLLBAR3                  1044
#define IDC_HOTKEY1                     1046
#define IDC_IPADDRESS1                  1047
#define IDC_CHECK4                      1049
#define IDC_SLIDER1                     1050
#define IDC_SLIDER2                     1051
#define IDC_SLIDER3                     1052
#define IDC_CHECK5                      1053
#define IDC_TAB1                        1054
#define IDC_SLIDER4                     1054
#define IDC_TAB2                        1055
#define IDC_SLIDER5                     1055
#define IDC_TAB3                        1056
#define IDC_COMBOBOXEX1                 1057
#define IDC_TAB4                        1057
#define IDC_RICHEDIT1                   1058
#define IDC_MONTHCALENDAR1              1059

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1060
#define _APS_NEXT_SYMED_VALUE           133
#endif
#endif
