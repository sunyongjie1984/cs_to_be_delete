///////////////////////////////////////////////////////////////////////////////
//
// File           : $Workfile:   example.cpp  $
// Version        : $Revision:   1.0  $
// Function       : 
//
// Author         : $Author:   Len  $
// Date           : $Date:   Dec 28 1997 12:16:00  $
//
// Notes          : 
//
// Modifications  :
//
// $Log:   D:/Documents/Len/Sources/Stuff/TaskBarApplet/PVCS/example.cpv  $
// 
//    Rev 1.0   Dec 28 1997 12:16:00   Len
// Initial revision.
// 
///////////////////////////////////////////////////////////////////////////////
//
// Copyright 1997 JetByte Limited.
//
// JetByte Limited grants you ("Licensee") a non-exclusive, royalty free, 
// licence to use, modify and redistribute this software in source and binary 
// code form, provided that i) this copyright notice and licence appear on all 
// copies of the software; and ii) Licensee does not utilize the software in a 
// manner which is disparaging to JetByte Limited.
//
// This software is provided "AS IS," without a warranty of any kind. ALL
// EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING 
// ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
// OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. JETBYTE LIMITED AND ITS LICENSORS 
// SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF 
// USING, MODIFYING OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO 
// EVENT WILL JETBYTE LIMITED BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, 
// OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE 
// DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING 
// OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN IF JETBYTE LIMITED 
// HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//
// This software is not designed or intended for use in on-line control of
// aircraft, air traffic, aircraft navigation or aircraft communications; or in
// the design, construction, operation or maintenance of any nuclear
// facility. Licensee represents and warrants that it will not use or
// redistribute the Software for such purposes.
//
///////////////////////////////////////////////////////////////////////////////

#include "windows.h"
#include "TaskBarApplet.hpp"
#include "TaskBarAppletMain.hpp"
#include "CPlAppletClient.hpp"

#include <assert.h>

using namespace JetByteTools;

///////////////////////////////////////////////////////////////////////////////
// ControlPanelApplet
///////////////////////////////////////////////////////////////////////////////

class ControlPanelApplet : public CJBTaskBarApplet
{

   public :

      // Construction and destruction

      ControlPanelApplet(
         const char *szCPlAppletName, 
         const int nAppIndex =0 );

   protected :

      // Required Functionality overrides

      virtual const char *GetTrayTip();
      virtual HICON GetIcon();

      // Menu handling overrides

      virtual HMENU GetMenu();
      virtual void ReleaseMenu(HMENU hMenu);

   private :

      // Applet functionality

      virtual bool InitInstance(LPSTR lpCmdLine);

      virtual void OnLeftDoubleClick();

      virtual void HandleMenuCommand(int command);

      // Our control panel applet

      CPlAppletClient m_applet;

      enum MenuIDs { ID_CLOSE, ID_ABOUT, ID_OPEN };
};

// Global instances of our task tray applet
// These assume the presence of the following cpl files
// if you don't have these, change the strings to ones you have...

ControlPanelApplet theApp("ControlApplet.cpl");
ControlPanelApplet theApp2("Desk.cpl");

///////////////////////////////////////////////////////////////////////////////
// Construction and destruction
///////////////////////////////////////////////////////////////////////////////

ControlPanelApplet::ControlPanelApplet(
   const char *szCPlAppletName, 
   const int nAppIndex /* = 0 */)
   :  CJBTaskBarApplet(),
      m_applet(szCPlAppletName, nAppIndex)
{
   // All work done in initialiser list
}

///////////////////////////////////////////////////////////////////////////////
// Required functionality
///////////////////////////////////////////////////////////////////////////////

const char *ControlPanelApplet::GetTrayTip()
{
   return m_applet.GetAppName();
}

HICON ControlPanelApplet::GetIcon()
{
   return m_applet.GetIcon();
}

///////////////////////////////////////////////////////////////////////////////
// Menu handling overrides
///////////////////////////////////////////////////////////////////////////////

HMENU ControlPanelApplet::GetMenu()
{
   HMENU hMenu = CreatePopupMenu();

   MENUITEMINFO item;

   memset(&item, 0, sizeof(MENUITEMINFO));

   item.cbSize = sizeof(MENUITEMINFO);

   item.fMask = MIIM_TYPE | MIIM_ID | MIIM_STATE;

   item.wID = ID_OPEN;

   item.fType = MFT_STRING;

   item.dwTypeData = "&Open";

   item.fState = MFS_DEFAULT;

   InsertMenuItem(hMenu, 1, TRUE, &item);

   item.fMask = MIIM_TYPE | MIIM_ID;

   item.wID = ID_ABOUT;

   item.fType = MFT_STRING;

   item.dwTypeData = "&About";

   InsertMenuItem(hMenu, 1, TRUE, &item);

   item.fType =  MFT_SEPARATOR;

   InsertMenuItem(hMenu, 2, TRUE, &item);

   item.wID = ID_CLOSE;

   item.fType = MFT_STRING;

   item.dwTypeData = "&Close";

   InsertMenuItem(hMenu, 3, TRUE, &item);

   return hMenu;
}

void ControlPanelApplet::HandleMenuCommand(int command)
{
   switch (command)
   {
      case ID_CLOSE :
      
         CloseApplet();

      break;

      case ID_ABOUT :

         char aboutTitle[50];

         wsprintf(aboutTitle, "About %s...", m_applet.GetAppName());

         MessageBox(NULL, m_applet.GetInfo(), aboutTitle, MB_ICONINFORMATION);

      break;

      case ID_OPEN :

         m_applet.RunApplet(NULL);

      break;
   }

}

void ControlPanelApplet::ReleaseMenu(HMENU hMenu)
{
   DestroyMenu(hMenu);
}

///////////////////////////////////////////////////////////////////////////////
// Applet functionality
///////////////////////////////////////////////////////////////////////////////

bool ControlPanelApplet::InitInstance(LPSTR /*lpCmdLine*/)
{
   return m_applet.LoadApplet(s_hWnd);
}

void ControlPanelApplet::OnLeftDoubleClick()
{
   m_applet.RunApplet(NULL);
}

///////////////////////////////////////////////////////////////////////////////
// End of file..
///////////////////////////////////////////////////////////////////////////////
