///////////////////////////////////////////////////////////////////////////////
//
// File           : $Workfile:   CPlAppletClient.cpp  $
// Version        : $Revision:   1.0  $
// Function       : 
//
// Author         : $Author:   Len  $
// Date           : $Date:   Dec 28 1997 12:16:00  $
//
// Notes          : 
//
// Modifications  :
//
// $Log:   D:/Documents/Len/Sources/Stuff/TaskBarApplet/PVCS/CPlAppletClient.cpv  $
// 
//    Rev 1.0   Dec 28 1997 12:16:00   Len
// Initial revision.
// 
///////////////////////////////////////////////////////////////////////////////
//
// Copyright 1997 JetByte Limited.
//
// JetByte Limited grants you ("Licensee") a non-exclusive, royalty free, 
// licence to use, modify and redistribute this software in source and binary 
// code form, provided that i) this copyright notice and licence appear on all 
// copies of the software; and ii) Licensee does not utilize the software in a 
// manner which is disparaging to JetByte Limited.
//
// This software is provided "AS IS," without a warranty of any kind. ALL
// EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING 
// ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
// OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. JETBYTE LIMITED AND ITS LICENSORS 
// SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF 
// USING, MODIFYING OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO 
// EVENT WILL JETBYTE LIMITED BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, 
// OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE 
// DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING 
// OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN IF JETBYTE LIMITED 
// HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//
// This software is not designed or intended for use in on-line control of
// aircraft, air traffic, aircraft navigation or aircraft communications; or in
// the design, construction, operation or maintenance of any nuclear
// facility. Licensee represents and warrants that it will not use or
// redistribute the Software for such purposes.
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Include files
///////////////////////////////////////////////////////////////////////////////

#include "CPlAppletClient.hpp"

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools
///////////////////////////////////////////////////////////////////////////////

namespace JetByteTools {

///////////////////////////////////////////////////////////////////////////////
// CPlAppletClient
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Construction and destruction
///////////////////////////////////////////////////////////////////////////////

CPlAppletClient::CPlAppletClient(
   const char *szCPlAppletName, 
   const int nAppIndex /*= 0*/)
   :  m_hLibInstance(0), 
      m_szCPlAppletName(szCPlAppletName),
      m_nAppIndex(nAppIndex),
      m_hIcon(0),
      m_pAppletProc(0)
{
   // All work done in initialiser list
}


CPlAppletClient::~CPlAppletClient()
{
   if (m_hLibInstance)
   {
      UnloadApplet(0);
   }
}

///////////////////////////////////////////////////////////////////////////////
// Applet manipulation
///////////////////////////////////////////////////////////////////////////////

bool CPlAppletClient::LoadApplet(HWND hWnd)
{
   bool ok = false;

   m_hLibInstance = LoadLibrary(m_szCPlAppletName);

   if (m_hLibInstance)
   {
      m_pAppletProc = (APPLET_PROC)GetProcAddress(m_hLibInstance, "CPlApplet");

      if (m_pAppletProc)
      {
         if (0 != m_pAppletProc(hWnd, CPL_INIT, 0, 0))
         {
            long numApps = m_pAppletProc(hWnd, CPL_GETCOUNT, 0, 0);

            if (m_nAppIndex <= numApps)
            {
               ok = GetCPlInfo(hWnd);
            }
            else
            {
               ok = false;
            }
         }
         else
         {
            MessageBox(hWnd, "Call to CPL_INIT failed", "Error", MB_ICONSTOP);
         }
      }
      else
      {
         MessageBox(hWnd, "Failed to locate CPlApplet entry point", "Error", MB_ICONSTOP);
      }
   }

   return ok;
}

bool CPlAppletClient::RunApplet(HWND hWnd)
{
   return (0 == m_pAppletProc(hWnd, CPL_DBLCLK, m_nAppIndex, (LPARAM)m_lData));
}

bool CPlAppletClient::UnloadApplet(HWND hWnd)
{
   if (0 != m_pAppletProc(hWnd, CPL_STOP, m_nAppIndex, (LPARAM)m_lData))
   {
      MessageBox(hWnd, "Call to CPL_STOP failed", "Error", MB_ICONSTOP);
   }

   if (0 != m_pAppletProc(hWnd, CPL_EXIT, 0, 0))
   {
      MessageBox(hWnd, "Call to CPL_EXIT failed", "Error", MB_ICONSTOP);
   }

   m_pAppletProc = 0;

   bool ok = (0 != FreeLibrary(m_hLibInstance));

   m_hLibInstance = 0;

   return ok;
}

HICON CPlAppletClient::GetIcon()
{
   return m_hIcon;
}

char *CPlAppletClient::GetAppName()
{
   return m_szAppName;
}

char *CPlAppletClient::GetInfo()
{
   return m_szAppInfo;
}

///////////////////////////////////////////////////////////////////////////////
// Private member functions
///////////////////////////////////////////////////////////////////////////////

bool CPlAppletClient::GetCPlInfo(HWND hWnd)
{
   bool ok = false;

   memset(&m_CplInfo, 0, sizeof(CPLINFO));

   if (0 == m_pAppletProc(hWnd, CPL_INQUIRE, m_nAppIndex, (LPARAM)&m_CplInfo))
   {
      m_bNewCpl = false;
      m_lData = m_CplInfo.lData;
      m_hIcon = LoadIcon(m_hLibInstance, MAKEINTRESOURCE(m_CplInfo.idIcon));

      int numBytes = LoadString(m_hLibInstance, m_CplInfo.idName, m_szAppName, sizeof(m_szAppName));

      assert(numBytes < sizeof(m_szAppName));

      if (0 != numBytes)
      {
         ok = true;
      }

      numBytes = LoadString(m_hLibInstance, m_CplInfo.idInfo, m_szAppInfo, sizeof(m_szAppInfo));

      assert(numBytes < sizeof(m_szAppInfo));

      if (0 != numBytes)
      {
         ok = true;
      }
   }
   else
   {
      memset(&m_NewCplInfo, 0, sizeof(NEWCPLINFO));

      m_NewCplInfo.dwSize = sizeof(NEWCPLINFO);
      
      if (0 == m_pAppletProc(hWnd, CPL_NEWINQUIRE, m_nAppIndex, (LPARAM)&m_NewCplInfo))
      {
         ok = true;
         m_bNewCpl = true;
         m_lData = m_NewCplInfo.lData;
         m_hIcon = m_NewCplInfo.hIcon;    

         memcpy(m_szAppName, m_NewCplInfo.szName, sizeof(m_szAppName));
         memcpy(m_szAppInfo, m_NewCplInfo.szInfo, sizeof(m_szAppInfo));
      }
   }

   return ok;
}

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools
///////////////////////////////////////////////////////////////////////////////

} // End of namespace JetByteTools 

///////////////////////////////////////////////////////////////////////////////
// End of file
///////////////////////////////////////////////////////////////////////////////
