#ifndef __CPL_APPLET_CLIENT__
#define __CPL_APPLET_CLIENT__
///////////////////////////////////////////////////////////////////////////////
//
// File           : $Workfile:   CPlAppletClient.hpp  $
// Version        : $Revision:   1.0  $
// Function       : 
//
// Author         : $Author:   Len  $
// Date           : $Date:   Dec 28 1997 12:16:02  $
//
// Notes          : 
//
// Modifications  :
//
// $Log:   D:/Documents/Len/Sources/Stuff/TaskBarApplet/PVCS/CPlAppletClient.hpv  $
// 
//    Rev 1.0   Dec 28 1997 12:16:02   Len
// Initial revision.
// 
///////////////////////////////////////////////////////////////////////////////
//
// Copyright 1997 JetByte Limited.
//
// JetByte Limited grants you ("Licensee") a non-exclusive, royalty free, 
// licence to use, modify and redistribute this software in source and binary 
// code form, provided that i) this copyright notice and licence appear on all 
// copies of the software; and ii) Licensee does not utilize the software in a 
// manner which is disparaging to JetByte Limited.
//
// This software is provided "AS IS," without a warranty of any kind. ALL
// EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING 
// ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
// OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. JETBYTE LIMITED AND ITS LICENSORS 
// SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF 
// USING, MODIFYING OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO 
// EVENT WILL JETBYTE LIMITED BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, 
// OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE 
// DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING 
// OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN IF JETBYTE LIMITED 
// HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//
// This software is not designed or intended for use in on-line control of
// aircraft, air traffic, aircraft navigation or aircraft communications; or in
// the design, construction, operation or maintenance of any nuclear
// facility. Licensee represents and warrants that it will not use or
// redistribute the Software for such purposes.
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Include files
///////////////////////////////////////////////////////////////////////////////

#include "windows.h"
#include "cpl.h"

#include <assert.h>

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools
///////////////////////////////////////////////////////////////////////////////

namespace JetByteTools {

///////////////////////////////////////////////////////////////////////////////
// Classes defined in this file
///////////////////////////////////////////////////////////////////////////////

class CPlAppletClient;

///////////////////////////////////////////////////////////////////////////////
// CPlAppletClient
///////////////////////////////////////////////////////////////////////////////

class CPlAppletClient 
{
   public :

      // Construction and destruction

      CPlAppletClient(const char *szCPlAppletName, const int nAppIndex = 0);
      ~CPlAppletClient();

      // Applet manipulation

      bool LoadApplet(HWND hWnd);

      bool RunApplet(HWND hWnd);

      bool UnloadApplet(HWND hWnd);

      HICON GetIcon();

      char *GetAppName();

      char *GetInfo();

   private :

      bool GetCPlInfo(HWND hWnd);

      HINSTANCE m_hLibInstance;
      const char *m_szCPlAppletName;
      const int m_nAppIndex;

      HICON m_hIcon;

      APPLET_PROC m_pAppletProc;
      long m_lData;

      char m_szAppName[32];
      char m_szAppInfo[64];

      CPLINFO m_CplInfo;
      NEWCPLINFO m_NewCplInfo;

      bool m_bNewCpl;
};

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools
///////////////////////////////////////////////////////////////////////////////

} // End of namespace JetByteTools 

#endif // __CPL_APPLET_CLIENT__

///////////////////////////////////////////////////////////////////////////////
// End of file
///////////////////////////////////////////////////////////////////////////////
