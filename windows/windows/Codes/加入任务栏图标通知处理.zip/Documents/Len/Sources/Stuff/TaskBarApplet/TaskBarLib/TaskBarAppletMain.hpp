#ifndef __TASK_BAR_APPLET_MAIN__
#define __TASK_BAR_APPLET_MAIN__
///////////////////////////////////////////////////////////////////////////////
//
// File           : $Workfile:   TaskBarAppletMain.hpp  $
// Version        : $Revision:   1.0  $
// Function       : 
//
// Author         : $Author:   Len  $
// Date           : $Date:   Dec 28 1997 12:16:10  $
//
// Notes          : 
//
// Modifications  :
//
// $Log:   D:/Documents/Len/Sources/Stuff/TaskBarApplet/TaskBarLib/PVCS/TaskBarAppletMain.hpv  $
// 
//    Rev 1.0   Dec 28 1997 12:16:10   Len
// Initial revision.
// 
///////////////////////////////////////////////////////////////////////////////
//
// Copyright 1997 JetByte Limited.
//
///////////////////////////////////////////////////////////////////////////////

using namespace JetByteTools;

///////////////////////////////////////////////////////////////////////////////
// WinMain
///////////////////////////////////////////////////////////////////////////////
#ifndef _MFC_TASKBAR_APPLET

int APIENTRY WinMain(
    HINSTANCE hInstance,
    HINSTANCE /*hPrevInstance*/,
    LPSTR lpCmdLine,
    int /*nCmdShow*/)
{
   return CJBTaskBarApplet::Run(hInstance, lpCmdLine);
}

#else

int APIENTRY WinMain(
    HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    LPSTR lpCmdLine,
    int nCmdShow)
{
   CWinApp theApp;

   int ok = AfxWinInit(hInstance, hPrevInstance, lpCmdLine, nCmdShow);

   if (ok)
   {
      ok = CJBTaskBarApplet::Run(hInstance, lpCmdLine);
   }

   return ok;
}

#endif

#endif // __TASK_BAR_APPLET_MAIN__

///////////////////////////////////////////////////////////////////////////////
// End of file
///////////////////////////////////////////////////////////////////////////////
