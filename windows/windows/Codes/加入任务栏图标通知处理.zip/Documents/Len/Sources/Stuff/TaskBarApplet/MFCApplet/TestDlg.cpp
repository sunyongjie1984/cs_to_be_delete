// TestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"		// main symbols
#include "TestDlg.h"
#include "TaskBarApplet.hpp"

#define _MFC_TASKBAR_APPLET
#include "TaskBarAppletMain.hpp"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



class MFCApplet : public CJBTaskBarApplet
{

   public :

      //MFCApplet();

   private :

      virtual void OnLeftDoubleClick();

      virtual const char *GetTrayTip();
      virtual HICON GetIcon();
};

MFCApplet mfcApp;
MFCApplet mfcApp2;

void MFCApplet::OnLeftDoubleClick()
{
   TestDlg dlg;

   dlg.DoModal();
}

const char *MFCApplet::GetTrayTip()
{
   return "MFCApplet";
}

HICON MFCApplet::GetIcon()
{
   return ::LoadIcon(NULL, IDI_QUESTION);
}


/////////////////////////////////////////////////////////////////////////////
// TestDlg dialog


TestDlg::TestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(TestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(TestDlg)
	m_check = FALSE;
	//}}AFX_DATA_INIT
}


void TestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(TestDlg)
	DDX_Check(pDX, IDC_CHECK1, m_check);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(TestDlg, CDialog)
	//{{AFX_MSG_MAP(TestDlg)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// TestDlg message handlers



void TestDlg::OnButton3() 
{
	// TODO: Add your control notification handler code here
	
}

void TestDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	
}

void TestDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	
}
