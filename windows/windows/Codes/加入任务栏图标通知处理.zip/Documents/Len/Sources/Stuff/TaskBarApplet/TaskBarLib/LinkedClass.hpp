#ifndef __LINKED_CLASS__
#define __LINKED_CLASS__
///////////////////////////////////////////////////////////////////////////////
//
// File           : $Workfile:   LinkedClass.hpp  $
// Version        : $Revision:   1.0  $
// Function       : 
//
// Author         : $Author:   Len  $
// Date           : $Date:   Dec 28 1997 12:16:10  $
//
// Notes          : A template base class for classes whos instances are all 
//                  linked into a list that can be used to affect all of them
//                  at run time.
//
// Modifications  :
//
// $Log:   D:/Documents/Len/Sources/Stuff/TaskBarApplet/TaskBarLib/PVCS/LinkedClass.hpv  $
// 
//    Rev 1.0   Dec 28 1997 12:16:10   Len
// Initial revision.
// 
///////////////////////////////////////////////////////////////////////////////
//
// Copyright 1997 JetByte Limited.
//
// JetByte Limited grants you ("Licensee") a non-exclusive, royalty free, 
// licence to use, modify and redistribute this software in source and binary 
// code form, provided that i) this copyright notice and licence appear on all 
// copies of the software; and ii) Licensee does not utilize the software in a 
// manner which is disparaging to JetByte Limited.
//
// This software is provided "AS IS," without a warranty of any kind. ALL
// EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING 
// ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
// OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. JETBYTE LIMITED AND ITS LICENSORS 
// SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF 
// USING, MODIFYING OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO 
// EVENT WILL JETBYTE LIMITED BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, 
// OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE 
// DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING 
// OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN IF JETBYTE LIMITED 
// HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//
// This software is not designed or intended for use in on-line control of
// aircraft, air traffic, aircraft navigation or aircraft communications; or in
// the design, construction, operation or maintenance of any nuclear
// facility. Licensee represents and warrants that it will not use or
// redistribute the Software for such purposes.
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools
///////////////////////////////////////////////////////////////////////////////

namespace JetByteTools {

///////////////////////////////////////////////////////////////////////////////
// Templates defined in this file...
///////////////////////////////////////////////////////////////////////////////

template <class T> class TLinkedClass;

template <class T> class TLinkedClassIterator;

///////////////////////////////////////////////////////////////////////////////
// TLinkedClass
///////////////////////////////////////////////////////////////////////////////

template <class T> class TLinkedClass
{
   public :

      friend class TLinkedClassIterator<T>;     // So we can access GetNext()
  
      // Exceptions we throw...

      class BadIndex {};
            
      // Construction and destruction

      TLinkedClass();
      virtual ~TLinkedClass();

   protected :

      // Iteration
         
      typedef TLinkedClassIterator<T> Iterator;

      static Iterator Begin();
      static Iterator End();

      // Iterator interface

      T *GetNext() const;

      // Derived class interface

      const int m_nObjectIndex;

      static int GetObjectCount();
      
      static T *GetObjectByIndex(const int nIndex);

   private :

      TLinkedClass<T> *m_pNext;

      static TLinkedClass<T> *s_pListHead; // Head of the list of all objects

      static int s_nObjectCount;   // How many objects in existance

      // It's just not right to copy these around...
      // Don't implement them!

      TLinkedClass(const TLinkedClass<T> &rhs);
      TLinkedClass<T> operator=(const TLinkedClass<T> &rhs);
};

///////////////////////////////////////////////////////////////////////////////
// Static variables
///////////////////////////////////////////////////////////////////////////////

template <class T> TLinkedClass<T> *TLinkedClass<T>::s_pListHead = 0;
template <class T> int TLinkedClass<T>::s_nObjectCount = 0;

///////////////////////////////////////////////////////////////////////////////
// Construction and destruction
///////////////////////////////////////////////////////////////////////////////

template <class T> TLinkedClass<T>::TLinkedClass()
: m_nObjectIndex(s_nObjectCount++)
{
   m_pNext = s_pListHead;    // Add ourselves to the static list of all 
   s_pListHead = this;       // CTaskBarApplet derived objects.
}

template <class T> TLinkedClass<T>::~TLinkedClass()
{
   TLinkedClass<T> *pObject = s_pListHead;
   TLinkedClass<T> **ppLastLink = &s_pListHead;

   while (pObject)
   {
      if (pObject == this)
      {
         *ppLastLink = m_pNext;
         pObject = 0;
      }
   }
}

///////////////////////////////////////////////////////////////////////////////
// Iteration
///////////////////////////////////////////////////////////////////////////////

template <class T> TLinkedClass<T>::Iterator TLinkedClass<T>::Begin()
{
   return Iterator(s_pListHead);
}

template <class T> TLinkedClass<T>::Iterator TLinkedClass<T>::End()
{
   return Iterator(0);
}

///////////////////////////////////////////////////////////////////////////////
// Iterator interface
///////////////////////////////////////////////////////////////////////////////

template <class T> T *TLinkedClass<T>::GetNext() const
{
   return (T*)m_pNext;
}

///////////////////////////////////////////////////////////////////////////////
// Derived class interface
///////////////////////////////////////////////////////////////////////////////

template <class T> int TLinkedClass<T>::GetObjectCount()
{ 
   return s_nObjectCount;
}

template <class T> T *TLinkedClass<T>::GetObjectByIndex(int nIndex)
{
   bool found = false;

   Iterator it = Begin(); 

   while (!found && it != End())
   {
      if (it->m_nObjectIndex != nIndex)
      {
         it++;
      }
      else
      {
         found = true;
      }
   }
   
   if (!found)
   {
      throw BadIndex();
   }

   return &it;
}

///////////////////////////////////////////////////////////////////////////////
// TLinkedClassIterator
///////////////////////////////////////////////////////////////////////////////

template <class T> class TLinkedClassIterator
{
   public :

      // Exceptions we throw...

      class NullIterator {};

      // Construction and destruction

      TLinkedClassIterator(TLinkedClass<T> *pLink);
      ~TLinkedClassIterator();

      // Operators

      TLinkedClassIterator &operator++();
      TLinkedClassIterator operator++(int);

      T* operator->();
      
      T* operator&();

      bool operator!=(const TLinkedClassIterator<T> &rhs);
      bool operator==(const TLinkedClassIterator<T> &rhs);

   private :

      // Helper function used by operator++

      void Advance();

      TLinkedClass<T> *m_pLink;
};

///////////////////////////////////////////////////////////////////////////////
// Construction and destruction
///////////////////////////////////////////////////////////////////////////////

template <class T> 
TLinkedClassIterator<T>::TLinkedClassIterator(TLinkedClass<T> *pLink)
   : m_pLink(pLink)
{
}

template <class T> TLinkedClassIterator<T>::~TLinkedClassIterator()
{
   m_pLink = 0;
}

///////////////////////////////////////////////////////////////////////////////
// Operators
///////////////////////////////////////////////////////////////////////////////

// Prefix ++:  ++it

template <class T> 
TLinkedClassIterator<T> &TLinkedClassIterator<T>::operator++()
{
   Advance();

   return *this;
}

// Postfix ++:  it++

template <class T> 
TLinkedClassIterator<T> TLinkedClassIterator<T>::operator++(int)
{
   TLinkedClassIterator<T> oldThis = *this;

   Advance();

   return oldThis;
}

template <class T> 
T* TLinkedClassIterator<T>::operator->()
{
   // Defer the work to operator&

   return &(*this);
}

template <class T> 
T* TLinkedClassIterator<T>::operator&()
{
   if (!m_pLink)
   {
      throw NullIterator();
   }

   return (T*)m_pLink;
}

template <class T> 
bool TLinkedClassIterator<T>::operator!=(const TLinkedClassIterator<T> &rhs)
{
   return !(*this == rhs);
}

template <class T> 
bool TLinkedClassIterator<T>::operator==(const TLinkedClassIterator<T> &rhs)
{
   return (m_pLink == rhs.m_pLink);
}

///////////////////////////////////////////////////////////////////////////////
// Helper function for operator ++
///////////////////////////////////////////////////////////////////////////////

template <class T> 
void TLinkedClassIterator<T>::Advance()
{
   if (m_pLink)
   {
      m_pLink = m_pLink->GetNext();
   }
}

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools
///////////////////////////////////////////////////////////////////////////////

} // End of namespace JetByteTools 

#endif // __LINKED_CLASS__

///////////////////////////////////////////////////////////////////////////////
// End of file
///////////////////////////////////////////////////////////////////////////////
