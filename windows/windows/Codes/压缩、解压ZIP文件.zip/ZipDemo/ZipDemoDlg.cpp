// ZipDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ZipDemo.h"
#include "ZipDemoDlg.h"
#include "..\ZipFun\ZipFile.h"
#include "..\ZipFun\unzipFile.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define BUF_SIZE  2048
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZipDemoDlg dialog

CZipDemoDlg::CZipDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CZipDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CZipDemoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CZipDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CZipDemoDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CZipDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CZipDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZipDemoDlg message handlers

BOOL CZipDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CZipDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CZipDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CZipDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CZipDemoDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	// getting the file to zip
	CFileDialog fd(TRUE,NULL,NULL,OFN_ALLOWMULTISELECT | 
		                  OFN_EXPLORER | OFN_HIDEREADONLY);
	if (fd.DoModal() != IDOK)
		return;
	POSITION   positon = fd.GetStartPosition();
//    CString filepathname = fd.GetPathName();
//	int pos = filepathname.Find('.');
//	filepathname = filepathname.Left(pos);
	CString  filepathname;
	CString  filepathtitle;
	CString  filename;
	while(positon!=NULL)
	{
		// First get the selected file's path and name.
		filepathname = fd.GetNextPathName(positon);
		// Now get the selected file's path and title.
		int pos = filepathname.Find('.');
		filepathtitle = filepathname.Left(pos);
		// Now get the selected file's name.
		int length = filepathname.GetLength();
		int div = filepathname.ReverseFind('\\');
		filename = filepathname.Right(length-div-1);
//		MessageBox(filename);
		// adding extension
		CZipFile zf(filepathtitle + ".zip", 0);
		char buf[BUF_SIZE];

		CFile f(filepathname, CFile::modeRead);

		zip_fileinfo zi;
		// getting information about the date and the attributes
		// (this is new in ZipFunc)
		zf.UpdateZipInfo(zi, f);

		zf.OpenNewFileInZip(filename, zi, Z_BEST_COMPRESSION);

		int size_read;
		do
		{
			size_read = f.Read(buf, BUF_SIZE);
			if (size_read)
				zf.WriteInFileInZip(buf, size_read);
		
		}
		while (size_read == BUF_SIZE);

		// cannot be called by the destructor because it may throw an exception
		// (it is not good to throw an exception when another one may be progress)
		zf.Close();
	}
	MessageBox("Add to zip finished.");
}

void CZipDemoDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	// getting the file to unzip 
	CFileDialog fd(TRUE);
	if (fd.DoModal() != IDOK)
		return;
	CUnzipFile uf(fd.GetPathName());
	uf.GoToFirstFile();
	unz_file_info ui;

	// 	getting the information about the file 
	// (date, attributes, the size of the filename)
	uf.GetCurrentFileInfo(&ui);

	int iNameSize = ui.size_filename + 1;
	char* pName = new char [iNameSize];

	// get the name of the file
	uf.GetCurrentFileInfo(NULL, pName, iNameSize);

	TCHAR szDir[_MAX_DIR];
	TCHAR szDrive[_MAX_DRIVE];
	_tsplitpath(fd.GetPathName(), szDrive, szDir,NULL, NULL);
	CString szPath = CString(szDrive) + szDir;
	CFile f( szPath + pName, CFile::modeWrite | CFile::modeCreate);

	delete[] pName;
	uf.OpenCurrentFile();
	char buf[BUF_SIZE];


	int size_read;
	do
	{
		size_read = uf.ReadCurrentFile(buf, BUF_SIZE);
		if (size_read > 0)
			f.Write(buf, size_read);
		
	}
	while (size_read == BUF_SIZE);

	// set the original date stamp and attributes to the unpacked file
	// (this function closes the file "f" which is needed to apply
	// the attributes)
	uf.UpdateFileStatus(f, ui);

	// cannot be called by the destructor 
	uf.Close();	
}
