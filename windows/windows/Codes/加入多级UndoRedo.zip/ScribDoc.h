// ScribDoc.h : interface of the CScribbleDoc class
//
// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (C) 1992-1997 Microsoft Corporation
// All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.
/////////////////////////////////////////////////////////////////////////////


// @@ added forward reference
class CCommand;

/////////////////////////////////////////////////////////////////////////////
// class CStroke
//
// A stroke is a series of connected points in the scribble drawing.
// A scribble document may have multiple strokes.

class CStroke : public CRefObject			// @@ changed base from CObject to CRefObject
{
public:
	CStroke(UINT nPenWidth);

protected:
	CStroke();
	DECLARE_SERIAL(CStroke)

// Attributes
protected:
	UINT                   m_nPenWidth;    // one pen width applies to entire stroke
public:
	CArray<CPoint,CPoint>  m_pointArray;   // series of connected points

// Operations
public:
	BOOL DrawStroke(CDC* pDC);
	CRect GetBoundingRect() const;			// @@ added member declaration

public:
	virtual void Serialize(CArchive& ar);
};

typedef CTypedRefObList<CStroke*> CStrokeList;		// @@ added typedef


// @@ added class
class ICustomCommandHistory : public ICommandHistory
{
public:
	virtual void OnStatusChange();
	virtual void OnCommandExecute(const CCommand* pCmd);
};


class CScribbleDoc : public CDocument, public ICustomCommandHistory	// @@ added ICommandHistory base
{
protected: // create from serialization only
	CScribbleDoc();
	DECLARE_DYNCREATE(CScribbleDoc)

// Attributes
protected:
	// The document keeps track of the current pen width on
	// behalf of all views. We'd like the user interface of
	// Scribble to be such that if the user chooses the Draw
	// Thick Line command, it will apply to all views, not just
	// the view that currently has the focus.

	UINT            m_nPenWidth;        // current user-selected pen width
	BOOL            m_bThickPen;        // TRUE if current pen is thick
	UINT            m_nThinWidth;
	UINT            m_nThickWidth;
	CPen            m_penCur;           // pen created according to
										// user-selected pen style (width)

	CString m_strTitleOrg;								// @@ added member
public:
	CStrokeList m_strokeList;	// @@ changed type from CTypedPtrList<CObList,CStroke*> to CTypedRefObList<CStroke*>
	CPen*           GetCurrentPen() { return &m_penCur; }
	UINT GetPenWidth() const { return m_nPenWidth; }	// @@ added member

// Operations
public:
//	CStroke* NewStroke();								// @@ deleted member
	BOOL AddStroke(CStroke* pStrokeItem);			// @@ added member
	BOOL AddStrokes(const CStrokeList& list);		// @@ added member
	BOOL RemoveStroke(CStroke* pStrokeItem);		// @@ added member
	BOOL RemoveStrokes(const CStrokeList& list);	// @@ added member

	void UpdateTitle();									// @@ added member

// Overrides
public:
	//{{AFX_VIRTUAL(CScribbleDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual void DeleteContents();
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);		// @@ added override
	virtual void SetTitle(LPCTSTR lpszTitle);					// @@ added override
	virtual void SetModifiedFlag(BOOL bModified = TRUE);	// @@ added override
	virtual BOOL IsModified();										// @@ added override
	//}}AFX_VIRTUAL

// Implementation
protected:
	void ReplacePen();

public:
	virtual ~CScribbleDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	void            InitDocument();

// Generated message map functions
protected:
	//{{AFX_MSG(CScribbleDoc)
	afx_msg void OnEditClearAll();
	afx_msg void OnPenThickOrThin();
	afx_msg void OnUpdateEditClearAll(CCmdUI* pCmdUI);
	afx_msg void OnUpdatePenThickOrThin(CCmdUI* pCmdUI);
	afx_msg void OnPenWidths();
	afx_msg void OnUpdateEditUndo(CCmdUI* pCmdUI);
	afx_msg void OnEditUndo();
	afx_msg void OnUpdateEditRedo(CCmdUI* pCmdUI);
	afx_msg void OnEditRedo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

