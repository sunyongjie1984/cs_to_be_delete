/*
Module : RESSWITCH.CPP
Purpose: Provides the WinMain function for the QRes program
Created: PJN / 25-09-1997
History: None

Copyright (c) 1997 by PJ Naughter.  
All rights reserved.

*/

/////////////////////////////////  Includes  //////////////////////////////////

#include "stdafx.h"
#include "videomod.h"
#include <windows.h>



///////////////////////////////// Defines /////////////////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



//////////////////////////////// Implementation ///////////////////////////////


int WINAPI _tWinMain(HINSTANCE /*hInstance*/,	HINSTANCE /*hPrevInstance*/, LPTSTR /*lpCmdLine*/,	int /*nCmdShow*/)
{
  TCHAR sCaption[] = _T("ResSwitch");
  if (__argc == 5)
  {
    int Width = atoi(__argv[1]);
    int Height = atoi(__argv[2]);
    int BitsPerPixel = atoi(__argv[3]);
    int Frequency = atoi(__argv[4]);

    CVideoMode mode(BitsPerPixel, Width, Height, Frequency);
    LONG lError = CVideoModes::ChangeVideoModeTemporarily(mode);
    switch (lError)
    {
      case DISP_CHANGE_SUCCESSFUL: /* Don't bother displaying a message box if successful */ break;
      case DISP_CHANGE_RESTART:	   MessageBox(NULL, _T("The computer must be restarted in order for this graphics mode to work"), sCaption, MB_OK | MB_ICONEXCLAMATION); break;
      case DISP_CHANGE_BADFLAGS:	 MessageBox(NULL, _T("An invalid set of flags was passed in"), sCaption, MB_OK | MB_ICONEXCLAMATION); break;
      case DISP_CHANGE_FAILED:	   MessageBox(NULL, _T("The display driver failed the specified graphics mode"), sCaption, MB_OK | MB_ICONEXCLAMATION); break;
      case DISP_CHANGE_BADMODE:	   MessageBox(NULL, _T("The graphics mode is not supported"), sCaption, MB_OK | MB_ICONEXCLAMATION); break;
      case DISP_CHANGE_NOTUPDATED: MessageBox(NULL, _T("Unable to write settings to the registry"), sCaption, MB_OK | MB_ICONEXCLAMATION); break;
      default:                     MessageBox(NULL, _T("Unexpected error value"), sCaption, MB_OK | MB_ICONEXCLAMATION); break;
    }
  }
  else
    MessageBox(NULL, _T("The program requires 4 command line parameters namely: Width Height BitsPerPixel Frequency"), sCaption, MB_OK | MB_ICONEXCLAMATION);

  return 0;
}
