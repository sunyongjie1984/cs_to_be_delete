/*
Module : QList.CPP
Purpose: Provides the Main function for the QList program
Created: PJN / 25-09-1997
History: None

Copyright (c) 1997 by PJ Naughter.  
All rights reserved.

*/

/////////////////////////////////  Includes  //////////////////////////////////
#include "stdafx.h"
#include "videomod.h"
#include <stdio.h>

              
///////////////////////////////// Defines /////////////////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



//////////////////////////////// Implementation ///////////////////////////////

void main()
{
  CVideoMode CurrentMode;
  if (CVideoModes::GetCurrentVideoMode(CurrentMode))
  {
    _tprintf(_T("Current video mode is\n"));
    _tprintf(_T("Width, Height, Depth, Frequency\n"));
    _tprintf(_T("%d,%d,%d,%d\n"), CurrentMode.m_dwWidth, CurrentMode.m_dwHeight, 
             CurrentMode.m_dwBitsPerPixel, CurrentMode.m_dwFrequency);
  }
  else
    _tprintf(_T("An error occured while trying to get the current video mode\n"));


  //Display the available video modes
  CAvailableVideoModes modes; 
  if (CVideoModes::GetAvailableVideoModes(modes))
  {
    _tprintf(_T("\nAvailable video modes are\n"));
    _tprintf(_T("Width, Height, Depth, Frequency\n"));

    for (int i=0; i<modes.GetSize(); i++)
    {
      CVideoMode mode = modes.GetAt(i);
      _tprintf(_T("%d,%d,%d,%d\n"), mode.m_dwWidth, mode.m_dwHeight, mode.m_dwBitsPerPixel, mode.m_dwFrequency);
    }
  }
  else
    _tprintf(_T("An error occured while trying to get the available video modes\n"));

  _tprintf(_T("\nThanks for using ResList!\n"));
}
