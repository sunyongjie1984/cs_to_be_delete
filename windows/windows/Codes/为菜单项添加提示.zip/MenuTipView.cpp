// MenuTipView.cpp : Implementierung der Klasse CMenuTipView
//

#include "stdafx.h"
#include "MenuTip.h"

#include "MenuTipDoc.h"
#include "MenuTipView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMenuTipView

IMPLEMENT_DYNCREATE(CMenuTipView, CView)

BEGIN_MESSAGE_MAP(CMenuTipView, CView)
	//{{AFX_MSG_MAP(CMenuTipView)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
	// Standard-Druckbefehle
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMenuTipView Konstruktion/Destruktion

CMenuTipView::CMenuTipView()
{
	// ZU ERLEDIGEN: Hier Code zur Konstruktion einf�gen,

}

CMenuTipView::~CMenuTipView()
{
}

BOOL CMenuTipView::PreCreateWindow(CREATESTRUCT& cs)
{
	// ZU ERLEDIGEN: �ndern Sie hier die Fensterklasse oder das Erscheinungsbild, indem Sie
	//  CREATESTRUCT cs modifizieren.

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMenuTipView Zeichnen

void CMenuTipView::OnDraw(CDC* pDC)
{
	CMenuTipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// ZU ERLEDIGEN: Hier Code zum Zeichnen der urspr�nglichen Daten hinzuf�gen
}

/////////////////////////////////////////////////////////////////////////////
// CMenuTipView Drucken

BOOL CMenuTipView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// Standardvorbereitung
	return DoPreparePrinting(pInfo);
}

void CMenuTipView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// ZU ERLEDIGEN: Zus�tzliche Initialisierung vor dem Drucken hier einf�gen
}

void CMenuTipView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// ZU ERLEDIGEN: Hier Bereinigungsarbeiten nach dem Drucken einf�gen
}

/////////////////////////////////////////////////////////////////////////////
// CMenuTipView Diagnose

#ifdef _DEBUG
void CMenuTipView::AssertValid() const
{
	CView::AssertValid();
}

void CMenuTipView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMenuTipDoc* CMenuTipView::GetDocument() // Die endg�ltige (nicht zur Fehlersuche kompilierte) Version ist Inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMenuTipDoc)));
	return (CMenuTipDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMenuTipView Nachrichten-Handler
