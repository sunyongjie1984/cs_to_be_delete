// MenuTipView.h : Schnittstelle der Klasse CMenuTipView
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MENUTIPVIEW_H__673D4021_775C_462F_A375_3D22CAB48B97__INCLUDED_)
#define AFX_MENUTIPVIEW_H__673D4021_775C_462F_A375_3D22CAB48B97__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMenuTipView : public CView
{
protected: // Nur aus Serialisierung erzeugen
	CMenuTipView();
	DECLARE_DYNCREATE(CMenuTipView)

// Attribute
public:
	CMenuTipDoc* GetDocument();

// Operationen
public:

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CMenuTipView)
	public:
	virtual void OnDraw(CDC* pDC);  // �berladen zum Zeichnen dieser Ansicht
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementierung
public:
	virtual ~CMenuTipView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generierte Message-Map-Funktionen
protected:
	//{{AFX_MSG(CMenuTipView)
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // Testversion in MenuTipView.cpp
inline CMenuTipDoc* CMenuTipView::GetDocument()
   { return (CMenuTipDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_MENUTIPVIEW_H__673D4021_775C_462F_A375_3D22CAB48B97__INCLUDED_)
