// MenuTipDoc.cpp : Implementierung der Klasse CMenuTipDoc
//

#include "stdafx.h"
#include "MenuTip.h"

#include "MenuTipDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMenuTipDoc

IMPLEMENT_DYNCREATE(CMenuTipDoc, CDocument)

BEGIN_MESSAGE_MAP(CMenuTipDoc, CDocument)
	//{{AFX_MSG_MAP(CMenuTipDoc)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMenuTipDoc Konstruktion/Destruktion

CMenuTipDoc::CMenuTipDoc()
{
	// ZU ERLEDIGEN: Hier Code f�r One-Time-Konstruktion einf�gen

}

CMenuTipDoc::~CMenuTipDoc()
{
}

BOOL CMenuTipDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// ZU ERLEDIGEN: Hier Code zur Reinitialisierung einf�gen
	// (SDI-Dokumente verwenden dieses Dokument)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMenuTipDoc Serialisierung

void CMenuTipDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// ZU ERLEDIGEN: Hier Code zum Speichern einf�gen
	}
	else
	{
		// ZU ERLEDIGEN: Hier Code zum Laden einf�gen
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMenuTipDoc Diagnose

#ifdef _DEBUG
void CMenuTipDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMenuTipDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMenuTipDoc Befehle
