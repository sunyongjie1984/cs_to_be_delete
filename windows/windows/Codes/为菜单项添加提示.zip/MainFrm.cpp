// MainFrm.cpp : Implementierung der Klasse CMainFrame
//

#include "stdafx.h"
#include "MenuTip.h"

#include "MainFrm.h"
#include <..\MFC\SRC\afximpl.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_MENUSELECT()
	ON_WM_ENTERIDLE()
//	ON_WM_INITMENU()
	ON_WM_ENTERMENULOOP()
	ON_WM_EXITMENULOOP()
	//}}AFX_MSG_MAP
	ON_NOTIFY_EX_RANGE(TTN_NEEDTEXTW, 0, 0xFFFF, OnToolTipText)
	ON_NOTIFY_EX_RANGE(TTN_NEEDTEXTA, 0, 0xFFFF, OnToolTipText)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // Statusleistenanzeige
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame Konstruktion/Zerst�rung

CMainFrame::CMainFrame()
{
	// ZU ERLEDIGEN: Hier Code zur Member-Initialisierung einf�gen
	m_bMenuLooping=FALSE;
	m_nIDSelCommand=NULL;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Symbolleiste konnte nicht erstellt werden\n");
		return -1;      // Fehler bei Erstellung
	}
	if (!m_wndDlgBar.Create(this, IDR_MAINFRAME, 
		CBRS_ALIGN_TOP, AFX_IDW_DIALOGBAR))
	{
		TRACE0("Dialogleiste konnte nicht erstellt werden\n");
		return -1;		// Fehler bei Erstellung
	}

	if (!m_wndReBar.Create(this) ||
		!m_wndReBar.AddBar(&m_wndToolBar) ||
		!m_wndReBar.AddBar(&m_wndDlgBar))
	{
		TRACE0("Infoleiste konnte nicht erstellt werden\n");
		return -1;      // Fehler bei Erstellung
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Statusleiste konnte nicht erstellt werden\n");
		return -1;      // Fehler bei Erstellung
	}

	// ZU ERLEDIGEN: Entfernen, wenn Sie keine QuickInfos w�nschen
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// ZU ERLEDIGEN: �ndern Sie hier die Fensterklasse oder das Erscheinungsbild, indem Sie
	//  CREATESTRUCT cs modifizieren.

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame Diagnose

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame Nachrichten-Handler


void CMainFrame::OnMenuSelect(UINT nItemID, UINT nFlags, HMENU hSysMenu) 
{
	//we need to remember which command was highlighted
	m_nIDSelCommand=nItemID;
	// TODO: Code f�r die Behandlungsroutine f�r Nachrichten hier einf�gen
	CMDIFrameWnd::OnMenuSelect(nItemID, nFlags, hSysMenu);
}

void CMainFrame::OnEnterIdle(UINT nWhy, CWnd* pWho) 
{
	//well, crappy, but works.
	//MFC-apps enter idle-mode when menus are activated
	//a simple way to track the mousecursor is to retrieve the
	//cursor-pos during this idle-time-processing.
	//This is what I did.
	//I got the cursor-pos, make up a new "message" (which was
	//really sent), and pass this "message" to the mainframe�s
	//tooltip.

	CMDIFrameWnd::OnEnterIdle(nWhy, pWho);
	
	MSG msg;
	POINT pt;
	GetCursorPos(&pt);
	msg.hwnd=m_hWnd;	//Mainframe is to handle the next messages
	msg.lParam=MAKELPARAM(pt.x,pt.y);			//for this tooltip
	msg.wParam=0;
	msg.message=WM_MOUSEMOVE;	//my "pseudo-mousemove-message"
	msg.pt=pt;
	FilterToolTipMessage(&msg);	//inform the tooltip
								//but we actually have to make up
								//our own FilterToolTipMessage
}

//copied from MFC, one change:
//I don�t let the tooltip set the hwnd but use the mainframe�s hwnd
AFX_STATIC void AFXAPI _MyAfxRelayToolTipMessage(CToolTipCtrl* pToolTip, MSG* pMsg)
{
	// transate the message based on TTM_WINDOWFROMPOINT
	MSG msg = *pMsg;
	msg.hwnd = (HWND)AfxGetMainWnd()->m_hWnd;//pToolTip->SendMessage(TTM_WINDOWFROMPOINT, 0, (LPARAM)&msg.pt);
	CPoint pt = pMsg->pt;
	if (msg.message >= WM_MOUSEFIRST && msg.message <= WM_MOUSELAST)
		::ScreenToClient(msg.hwnd, &pt);
	msg.lParam = MAKELONG(pt.x, pt.y);

	// relay mouse event before deleting old tool
	pToolTip->SendMessage(TTM_RELAYEVENT, 0, (LPARAM)&msg);
}

//this is called by the tooltip, I only fill in something
//if a menu is shown
int CMainFrame::OnToolHitTest(CPoint pt,TOOLINFO* pTI) const
{
	if(m_bMenuLooping)
	{	//ok, menuloop
		if(m_nIDSelCommand)
		{
			pTI->hwnd=m_hWnd;
			pTI->uId=m_nIDSelCommand;
			pTI->lpszText=LPSTR_TEXTCALLBACK;
			return 0*m_nIDSelCommand;
		}
		else
			return -1;
	}
	else	//let MFC do defaults, if no menu present
		return CMDIFrameWnd::OnToolHitTest(pt,pTI);
}

BOOL CMainFrame::OnToolTipText(UINT nID,NMHDR* pNMHDR,LRESULT* pResult)
{
	// need to handle both ANSI and UNICODE versions of the message
	TOOLTIPTEXTA* pTTTA=(TOOLTIPTEXTA*)pNMHDR;
	TOOLTIPTEXTW* pTTTW=(TOOLTIPTEXTW*)pNMHDR;
	if(m_bMenuLooping)
	{	//only do this when menu is present
		_AFX_THREAD_STATE* pThreadState=AfxGetThreadState();
		CToolTipCtrl* pToolTip=pThreadState->m_pToolTip;
		if(pToolTip)
		{
			ASSERT_VALID(pToolTip);
			pToolTip->SetMaxTipWidth(200);	//linefeed possible
		}
		CString strTipText;

		//the same text as in the status bar is used.
		//Feel free to modify
		strTipText.LoadString(m_nIDSelCommand);
		int nRet=strTipText.Find("\n");
		if(nRet>=0)
			strTipText=strTipText.Left(nRet);

	#ifndef _UNICODE
		if (pNMHDR->code==TTN_NEEDTEXTA)
			lstrcpyn(pTTTA->szText,strTipText,80);
		else
			_mbstowcsz(pTTTW->szText,strTipText,80);
	#else
		if (pNMHDR->code==TTN_NEEDTEXTA)
			_wcstombsz(pTTTA->szText,strTipText,80);
		else
			lstrcpyn(pTTTW->szText,strTipText,80);
	#endif
		*pResult=0;

		return TRUE;	// message was handled
	}
	else
	{
		//well, no menu present
		if(nID==NULL)
		{	//the mouse didn�t really hit a control, so we have
			//to do a little work-around, because MFC otherwise
			//thinks we actually HIT one and shows random
			//tooltip messages (looks nice though ;-)
			if(pNMHDR->code==TTN_NEEDTEXTA)
				pTTTA->uFlags=0;
			else
				pTTTW->uFlags=0;
		}
		return CFrameWnd::OnToolTipText(nID,pNMHDR,pResult);
	}
}

void CMainFrame::OnEnterMenuLoop(BOOL bIsTrackPopupMenu) 
{
	//menu is about to pop up
	EnableTrackingToolTips();	//switch ON the tracking tool tips
	CMDIFrameWnd::OnEnterMenuLoop(bIsTrackPopupMenu);
	m_bMenuLooping=TRUE;
}

void CMainFrame::OnExitMenuLoop(BOOL bIsTrackPopupMenu) 
{
	//menus were cancelled
	CMDIFrameWnd::OnExitMenuLoop(bIsTrackPopupMenu);
	m_bMenuLooping=FALSE;
	EnableTrackingToolTips(FALSE);	//switch OFF the tracking tool tips
}

void CMainFrame::FilterToolTipMessage(MSG *pMsg)
{
	//mostly copied from MFC
	//just changed the ThreadState-statements (didn�t compile otherwise)
	//and changed _AfxRelayToolTipMessage to _MyAfx...
	//IMPORTANT: the ToolTip here is HWND_TOPMOST instead of HWND_TOP !
	//(SetWindowPos in Line 380)
	//otherwise the tip is hidden by the menu

	//if no menus present do MFC-defaults
	if(!m_bMenuLooping)
	{
		CMDIFrameWnd::FilterToolTipMessage(pMsg);
		return;
	}

	//do our little changes
	// this CWnd has tooltips enabled
	UINT message = pMsg->message;
	if ((message == WM_MOUSEMOVE || message == WM_NCMOUSEMOVE ||
		 message == WM_LBUTTONUP || message == WM_RBUTTONUP ||
		 message == WM_MBUTTONUP) &&
		(GetKeyState(VK_LBUTTON) >= 0 && GetKeyState(VK_RBUTTON) >= 0 &&
		 GetKeyState(VK_MBUTTON) >= 0))
	{
		// make sure that tooltips are not already being handled
		CWnd* pWnd = CWnd::FromHandle(pMsg->hwnd);
		while (pWnd != NULL && !(pWnd->m_nFlags & (WF_TOOLTIPS|WF_TRACKINGTOOLTIPS)))
		{
			pWnd = pWnd->GetParent();
		}
		if (pWnd != this)
		{
			if (pWnd == NULL)
			{
				// tooltips not enabled on this CWnd, clear last state data
				_AFX_THREAD_STATE* pThreadState = AfxGetThreadState();
				pThreadState->m_pLastHit = NULL;
				pThreadState->m_nLastHit = -1;
			}
			return;
		}

		_AFX_THREAD_STATE* pThreadState = AfxGetThreadState();
		CToolTipCtrl* pToolTip = pThreadState->m_pToolTip;
		CWnd* pOwner = GetParentOwner();
		if (pToolTip != NULL && pToolTip->GetOwner() != pOwner)
		{
			pToolTip->DestroyWindow();
			delete pToolTip;
			pThreadState->m_pToolTip = NULL;
			pToolTip = NULL;
		}
		if (pToolTip == NULL)
		{
			pToolTip = new CToolTipCtrl;
			if (!pToolTip->Create(pOwner, TTS_ALWAYSTIP))
			{
				delete pToolTip;
				return;
			}
			pToolTip->SendMessage(TTM_ACTIVATE, FALSE);
			pThreadState->m_pToolTip = pToolTip;
		}

		ASSERT_VALID(pToolTip);
		ASSERT(::IsWindow(pToolTip->m_hWnd));

		// add a "dead-area" tool for areas between toolbar buttons
		TOOLINFO ti; memset(&ti, 0, sizeof(TOOLINFO));
		ti.cbSize = sizeof(AFX_OLDTOOLINFO);
		ti.uFlags = TTF_IDISHWND;
		ti.hwnd = m_hWnd;
		ti.uId = (UINT)m_hWnd;
		if (!pToolTip->SendMessage(TTM_GETTOOLINFO, 0, (LPARAM)&ti))
		{
			ASSERT(ti.uFlags == TTF_IDISHWND);
			ASSERT(ti.hwnd == m_hWnd);
			ASSERT(ti.uId == (UINT)m_hWnd);
			VERIFY(pToolTip->SendMessage(TTM_ADDTOOL, 0, (LPARAM)&ti));
		}

		// determine which tool was hit
		CPoint point = pMsg->pt;
		::ScreenToClient(m_hWnd, &point);
		TOOLINFO tiHit; memset(&tiHit, 0, sizeof(TOOLINFO));
		tiHit.cbSize = sizeof(AFX_OLDTOOLINFO);
		int nHit = OnToolHitTest(point, &tiHit);

		// build new toolinfo and if different than current, register it
		CWnd* pHitWnd = nHit == -1 ? NULL : this;
		if (pThreadState->m_nLastHit != nHit || pThreadState->m_pLastHit != pHitWnd)
		{
			if (nHit != -1)
			{
				// add new tool and activate the tip
				ti = tiHit;
				ti.uFlags &= ~(TTF_NOTBUTTON|TTF_ALWAYSTIP);
				if (m_nFlags & WF_TRACKINGTOOLTIPS)
					ti.uFlags |= TTF_TRACK;
				VERIFY(pToolTip->SendMessage(TTM_ADDTOOL, 0, (LPARAM)&ti));
				if ((tiHit.uFlags & TTF_ALWAYSTIP) || IsTopParentActive())
				{
					// allow the tooltip to popup when it should
					pToolTip->SendMessage(TTM_ACTIVATE, TRUE);
					if (m_nFlags & WF_TRACKINGTOOLTIPS)
						pToolTip->SendMessage(TTM_TRACKACTIVATE, TRUE, (LPARAM)&ti);

					// bring the tooltip window above other popup windows
					::SetWindowPos(pToolTip->m_hWnd, HWND_TOPMOST, 0, 0, 0, 0,
						SWP_NOACTIVATE|SWP_NOSIZE|SWP_NOMOVE|SWP_NOOWNERZORDER);
				}
			}
			else
			{
				pToolTip->SendMessage(TTM_ACTIVATE, FALSE);
			}

			// relay mouse event before deleting old tool
			_MyAfxRelayToolTipMessage(pToolTip, pMsg);

			// now safe to delete the old tool
			if (pThreadState->m_lastInfo.cbSize >= sizeof(AFX_OLDTOOLINFO))
				pToolTip->SendMessage(TTM_DELTOOL, 0, (LPARAM)&pThreadState->m_lastInfo);

			pThreadState->m_pLastHit = pHitWnd;
			pThreadState->m_nLastHit = nHit;
			pThreadState->m_lastInfo = tiHit;
		}
		else
		{
			if (m_nFlags & WF_TRACKINGTOOLTIPS)
			{
				POINT pt;

				::GetCursorPos( &pt );
				pt.x+=30;pt.y+=20;
				pToolTip->SendMessage(TTM_TRACKPOSITION, 0, MAKELPARAM(pt.x, pt.y));
			}
			else
			{
				// relay mouse events through the tooltip
				if (nHit != -1)
					_MyAfxRelayToolTipMessage(pToolTip, pMsg);
			}
		}

		if ((tiHit.lpszText != LPSTR_TEXTCALLBACK) && (tiHit.hinst == 0))
			free(tiHit.lpszText);
	}
	else if (m_nFlags & (WF_TOOLTIPS|WF_TRACKINGTOOLTIPS))
	{
		// make sure that tooltips are not already being handled
		CWnd* pWnd = CWnd::FromHandle(pMsg->hwnd);
		while (pWnd != NULL && pWnd != this && !(pWnd->m_nFlags & (WF_TOOLTIPS|WF_TRACKINGTOOLTIPS)))
			pWnd = pWnd->GetParent();
		if (pWnd != this)
			return;

		BOOL bKeys = (message >= WM_KEYFIRST && message <= WM_KEYLAST) ||
			(message >= WM_KEYFIRST && message <= WM_KEYLAST);
		if ((m_nFlags & WF_TRACKINGTOOLTIPS) == 0 &&
			(bKeys ||
			 (message == WM_LBUTTONDOWN || message == WM_LBUTTONDBLCLK) ||
			 (message == WM_RBUTTONDOWN || message == WM_RBUTTONDBLCLK) ||
			 (message == WM_MBUTTONDOWN || message == WM_MBUTTONDBLCLK) ||
			 (message == WM_NCLBUTTONDOWN || message == WM_NCLBUTTONDBLCLK) ||
			 (message == WM_NCRBUTTONDOWN || message == WM_NCRBUTTONDBLCLK) ||
			 (message == WM_NCMBUTTONDOWN || message == WM_NCMBUTTONDBLCLK)))
		{
			CWnd::CancelToolTips(bKeys);
		}
	}
}
