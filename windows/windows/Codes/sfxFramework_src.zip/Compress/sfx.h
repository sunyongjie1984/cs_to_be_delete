// Self Extracting File Framework
// ==============================
//
// Copyright � 2000 Rui Godinho Lopes <ruiglopes@yahoo.com>
// All rights reserved.
//
// This source file(s) may be redistributed unmodified by any means
// PROVIDING they are not sold for profit without the authors expressed
// written consent, and providing that this notice and the authors name
// and all copyright notices remain intact.
//
// Any use of the software in source or binary forms, with or without
// modification, must include, in the user documentation ("About" box and
// printed documentation) and internal comments to the code, notices to
// the end user as follows:
//
// "Portions Copyright � 2000 Rui Godinho Lopes"
//
// An email letting me know that you are using it would be nice as well.
// That's not much to ask considering the amount of work that went into
// this.
//
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED. USE IT AT YOUT OWN RISK. THE AUTHOR ACCEPTS NO
// LIABILITY FOR ANY DATA DAMAGE/LOSS THAT THIS PRODUCT MAY CAUSE.
//
// =======================================================================
// REVISION HISTORY
// =======================================================================
// 1.00 14July2000
//   first public version
//
//////////////////////////////////////////////////////////////////////////

#ifndef SFX_H_INC
#define SFX_H_INC

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


//////////////////////////////////////////
// This class provides the base support
// for creating a SelfExtractingFile (sfx)
//////////////////////////////////////////
class CSFXFileCreator
{
public:
	//Error codes
	enum
	{
		SFX_FALSE= -99,

		SFX_OK= 0
	};


	CSFXFileCreator();
	virtual ~CSFXFileCreator();

	/**
	 * Creates a fresh new sfx
	 */
	LRESULT Create(LPCTSTR pFileName);

	
	/**
	 * Closes and validates the sfx
	 */	
	LRESULT Close();

protected:
 /**
	 * This creates a file name (pFileName)
	 * with a copy of the loader (sfxLoader.exe)
	 *
	 * Return Values
	 * This returns SFX_OK on success, or SFX_FALSE if
	 * the copy fails
	 *
	 * Remarks
	 * This default implementation copies the file
	 * 'sfxLoader.e32' that is on the same path that
	 * the current process
	 *
	 * The pFileName is allways created, even if a file
	 * with the same name exists on destination
	 */
	virtual LRESULT CopyLoader(LPCTSTR pFileName);


	/**
	 * This must append a compressed version of your
	 * start module in this file (sfx)
	 *
	 * Return Values
	 * This returns SFX_OK on success, or SFX_FALSE if
	 * the append fails
	 */
	virtual LRESULT AppendStartModule()= 0;


 /**
	 * This must append the user data
	 *
	 * Return Values
	 * This returns SFX_OK on success, or SFX_FALSE if
	 * the append fails
	 */
	virtual LRESULT AppendUserData()= 0;


protected:
	HANDLE m_hFile;						//sfx Handle (file with read/write permition)
	DWORD m_dwStartModuleChecksum; //checksum of the start module

private:
	DWORD dwStartModulePos;		//offset of Start Module
	DWORD dwStartModuleSize;	//size of Start Module

	/**
	 * Writes the header
	 */
	LRESULT WriteHeader();
};


#endif