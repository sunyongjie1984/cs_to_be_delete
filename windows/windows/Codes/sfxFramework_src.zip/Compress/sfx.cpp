// Self Extracting File Framework
// ==============================
//
// Copyright � 2000 Rui Godinho Lopes <ruiglopes@yahoo.com>
// All rights reserved.
//
// This source file(s) may be redistributed unmodified by any means
// PROVIDING they are not sold for profit without the authors expressed
// written consent, and providing that this notice and the authors name
// and all copyright notices remain intact.
//
// Any use of the software in source or binary forms, with or without
// modification, must include, in the user documentation ("About" box and
// printed documentation) and internal comments to the code, notices to
// the end user as follows:
//
// "Portions Copyright � 2000 Rui Godinho Lopes"
//
// An email letting me know that you are using it would be nice as well.
// That's not much to ask considering the amount of work that went into
// this.
//
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED. USE IT AT YOUT OWN RISK. THE AUTHOR ACCEPTS NO
// LIABILITY FOR ANY DATA DAMAGE/LOSS THAT THIS PRODUCT MAY CAUSE.
//
// =======================================================================
// REVISION HISTORY
// =======================================================================
// 1.00 14July2000
//   first public version
//
//////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "sfx.h"

#include "../Loader/ILoader.h"
#include "../Loader/LoaderPriv.h"

//simple macro to get the current file pointer of a file
#define GetFilePointer(hFile) SetFilePointer(hFile, 0, NULL, FILE_CURRENT)

//******************************************************************************
CSFXFileCreator::CSFXFileCreator()
{
	dwStartModulePos= dwStartModuleSize= m_dwStartModuleChecksum= 0;
	m_hFile= INVALID_HANDLE_VALUE;
}
//******************************************************************************
CSFXFileCreator::~CSFXFileCreator()
{
	CloseHandle(m_hFile); //just in case something went wrong...
}
//******************************************************************************
LRESULT CSFXFileCreator::WriteHeader()
{
	LOADERHEADER Header;

	Header.dwMagicID= LOADERHEADER::MAGICID;
	Header.dwStartModulePos= dwStartModulePos;
	Header.dwStartModuleSize= dwStartModuleSize;
	Header.dwStartModuleChecksum= m_dwStartModuleChecksum;
	
	SetFilePointer(m_hFile, sfx_dwHeaderPos, NULL, FILE_BEGIN);

	ULONG ul;
	return WriteFile(m_hFile, &Header, sizeof(LOADERHEADER), &ul, NULL)? SFX_OK : SFX_FALSE;
}
//******************************************************************************
LRESULT CSFXFileCreator::Create(LPCTSTR pFileName)
{
	LRESULT lResult;

	//---------------------------------------------
	// Copy the sfxLoader.e32 to sfx file pFileName
	//---------------------------------------------
	if ((lResult= CopyLoader(pFileName))!=SFX_OK)
		return lResult;

	//-------------
	// Open the sfx
	//-------------
	if ((m_hFile= CreateFile(pFileName, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL))==INVALID_HANDLE_VALUE)
		return SFX_FALSE;


	//------------------------
	// append the Start Module
	//------------------------

	//move to eof
	dwStartModulePos= SetFilePointer(m_hFile, 0, NULL, FILE_END);

	if ((lResult= AppendStartModule())!=SFX_OK)
		return lResult;

	//set the Start Module Size
	dwStartModuleSize= GetFilePointer(m_hFile) - dwStartModulePos;

	//-----------------
	// append User Data
	//-----------------
	return AppendUserData();
}
//******************************************************************************
LRESULT CSFXFileCreator::Close()
{
	LRESULT lResult;

	//-----------------------------------------------
	// Write the Header now that we have all the info
	//-----------------------------------------------
	if ((lResult= WriteHeader())!=SFX_OK)
		return lResult;

	//all done! pack and go home...
	CloseHandle(m_hFile);
	m_hFile= INVALID_HANDLE_VALUE;

	return lResult;
}
//******************************************************************************
LRESULT CSFXFileCreator::CopyLoader(LPCTSTR pFileName)
{
	return CopyFile(_T("sfxLoader.e32"), pFileName, TRUE)? SFX_OK : SFX_FALSE;
}
//******************************************************************************
