// Compress.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "sfx.h"
#include "sfx_helpers.h"
#include "../loader/loader.h"
#include <stdio.h>

class CMySFXFileCreator: public CSFXFileCreator
{
protected:
	virtual LRESULT AppendStartModule();
	virtual LRESULT AppendUserData() { return SFX_OK; } //this does............... nothing!
};

LRESULT CMySFXFileCreator::AppendStartModule()
{
	COMPRESSIONINFO Info;
#ifdef _STARTMODULE_IS_EXE
	LPCTSTR pStartupModule= _T("StartModule.exe");
#else
	LPCTSTR pStartupModule= _T("StartModule.dll");
#endif
	

	BOOL bCompressOk= sfxAppendCompressFile(pStartupModule, m_hFile, Info, Z_BEST_COMPRESSION);

	m_dwStartModuleChecksum= Info.dwChecksum;

	return bCompressOk? SFX_OK : SFX_FALSE;
}



void CreateDemoSFX()
{
	printf("Making a demo SFX file....\n");

	LPCTSTR pSFXPath= _T("MySFXFile.exe");

	DeleteFile(pSFXPath); //first delete the file, or else CMySFXFileCreator::Create will fail it this file exists...

	CMySFXFileCreator sfxFile;
	if (sfxFile.Create(pSFXPath)!=CSFXFileCreator::SFX_OK)
	{
		printf("Unable to create SFX :(\n");
		return;
	}

	//-------------------------
	// Closes&Validates the SFX
	//-------------------------
	if (sfxFile.Close()==CSFXFileCreator::SFX_FALSE)
	{
		printf("SFX corrupted :(\n");
		return;
	}

	printf("The Self Extracting File (%s) has been succefully created!\n", pSFXPath);
}

void main()
{
	//Create our demo SFX...
	CreateDemoSFX();

	//TextCompressStream();
}


//--------------------------------------------------------
// Here is a sample code to compress one file to another
// For the expander part look at the StartModule.cpp under
// the folder startmodule
// NOTE: You have to change the pInFile/pOutFile ;)
//--------------------------------------------------------
void TextCompressStream()
{
	LPCTSTR pInFile= _T("compress.pdb");
	LPCTSTR pOutFile= _T("compress.pdb_");
	const int iCompressionLevel= Z_DEFAULT_COMPRESSION;
	//const int iCompressionLevel= Z_BEST_COMPRESSION;


	CWin32FileCompress FileCompress;

	//Init stream handles
	AutoFreeHandle hFileIn= (FileCompress.m_Reader.m_hFile= CreateFile(pInFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL));
	AutoFreeHandle hFileOut= (FileCompress.m_Writer.m_hFile= CreateFile(pOutFile, GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL));


	DWORD dwCountStart= GetTickCount();

	if (FileCompress.Init(iCompressionLevel))
		return;

	FileCompress.Compress();

	DWORD dwCountEnd= GetTickCount();

	COMPRESSIONINFO Info;
	FileCompress.GetInfo(Info);

	printf("Compression Status:\ntime: %dms\nOriginalSize: %d\nCompressedSize: %d\nRatio: %d%%\nChecksum: 0x%x\n", dwCountEnd-dwCountStart, Info.dwSize, Info.dwCompressedSize, 100-Info.dwCompressedSize*100/Info.dwSize, Info.dwChecksum);
}
