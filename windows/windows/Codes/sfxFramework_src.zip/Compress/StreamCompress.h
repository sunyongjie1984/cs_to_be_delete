// StreamCompress.h: interface for the CStreamCompress class.
//
//////////////////////////////////////////////////////////////////////
// Self Extracting File Framework
// ==============================
//
// Copyright � 2000 Rui Godinho Lopes <ruiglopes@yahoo.com>
// All rights reserved.
//
// This source file(s) may be redistributed unmodified by any means
// PROVIDING they are not sold for profit without the authors expressed
// written consent, and providing that this notice and the authors name
// and all copyright notices remain intact.
//
// Any use of the software in source or binary forms, with or without
// modification, must include, in the user documentation ("About" box and
// printed documentation) and internal comments to the code, notices to
// the end user as follows:
//
// "Portions Copyright � 2000 Rui Godinho Lopes"
//
// An email letting me know that you are using it would be nice as well.
// That's not much to ask considering the amount of work that went into
// this.
//
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED. USE IT AT YOUT OWN RISK. THE AUTHOR ACCEPTS NO
// LIABILITY FOR ANY DATA DAMAGE/LOSS THAT THIS PRODUCT MAY CAUSE.
//
// =======================================================================
// REVISION HISTORY
// =======================================================================
// 1.00 14July2000
//   first public version
//
//////////////////////////////////////////////////////////////////////////

#if !defined(AFX_STREAMCOMPRESS_H__13C9539E_3EEB_11D4_AAF5_000000000000__INCLUDED_)
#define AFX_STREAMCOMPRESS_H__13C9539E_3EEB_11D4_AAF5_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "stdafx.h"

struct COMPRESSIONINFO
{
	DWORD dwChecksum;					//data checksum
	DWORD dwSize;							//size of uncompressed data
	DWORD dwCompressedSize;		//size of compressed data
};

class CStreamVoidStatus
{
public:
	void OnStatus(ULONG /*ulBytesDone*/) {}
};

template <typename TReader, typename TWriter, typename TStatus= CStreamVoidStatus>
class CStreamCompress
{
public:
	CStreamCompress()
		{
			m_pInBuffer= m_pOutBuffer= NULL;

			m_z.zalloc= NULL;
			m_z.zfree= NULL;
			m_z.opaque= NULL;
		}

	
	virtual ~CStreamCompress()
		{
			::deflateEnd(&m_z);
			FreeBuffers();
		}
	

	LRESULT Init(int iCompressionLevel= Z_DEFAULT_COMPRESSION, int iBufferSize= 4096)
		{
			int iResult= ::deflateInit(&m_z, iCompressionLevel);
			if (iResult!=Z_OK)
				return -1;

			m_iBufferSize= iBufferSize;
			m_pInBuffer= new Byte[iBufferSize];
			m_pOutBuffer= new Byte[iBufferSize];

			m_z.avail_in= 0;
			m_z.next_out= m_pOutBuffer;
			m_z.avail_out= iBufferSize;

			return m_pOutBuffer==NULL;
		}


	LRESULT Compress()
		{
			if (!m_pOutBuffer)
				return -2;

			m_bContinue= TRUE;
			int iStatus;
			int iCount;
			ULONG ul;

			while (m_bContinue)
			{
				if (!m_z.avail_in) //if the compressor allready consumed all bytes, we have to give him more!
				{
					m_z.next_in= m_pInBuffer;					
					LRESULT lRes;
					if ((lRes= m_Reader.Read(m_pInBuffer, m_iBufferSize, &ul))!=S_OK)
						return S_FALSE;

					if (!(m_z.avail_in= ul))
					{
						//since there is no more data left in the m_Reader just
						//write the data that may be in compressor to the m_Writer
						do
						{
							iStatus= ::deflate(&m_z, Z_FINISH);
							iCount= m_iBufferSize - m_z.avail_out;
							if (m_Writer.Write(m_pOutBuffer, iCount, &ul)!=S_OK)
								return S_FALSE;

							m_Status.OnStatus(m_z.total_out);

							m_z.next_out= m_pOutBuffer;
							m_z.avail_out= m_iBufferSize;
						}	while (iStatus==Z_OK); //repeat until all data is written to m_Writer
						return iStatus==Z_STREAM_END? S_OK : S_FALSE;
					}
				}

				if (::deflate(&m_z, Z_NO_FLUSH)!=Z_OK)
					return S_FALSE;

				if (iCount= m_iBufferSize-m_z.avail_out)
				{
					if (m_Writer.Write(m_pOutBuffer, iCount, &ul)!=S_OK)
						return S_FALSE;

					m_Status.OnStatus(m_z.total_out);

					m_z.next_out= m_pOutBuffer;
					m_z.avail_out= m_iBufferSize;
				}
			}

			return S_OK;
		}

	BOOL GetInfo(COMPRESSIONINFO &Info) const
		{
			Info.dwChecksum= m_z.adler;
			Info.dwSize= m_z.total_in;
			Info.dwCompressedSize= m_z.total_out;
			return TRUE;
		}

public:
	TReader m_Reader;
	TWriter m_Writer;
	TStatus m_Status;

private:
	z_stream m_z;
	Byte *m_pInBuffer;
	Byte *m_pOutBuffer;
	int m_iBufferSize;
	BOOL m_bContinue;

	void FreeBuffers()
		{
			delete [] m_pInBuffer;
			delete [] m_pOutBuffer;
			m_pInBuffer= m_pOutBuffer= NULL;
		}
};

#endif // !defined(AFX_STREAMCOMPRESS_H__13C9539E_3EEB_11D4_AAF5_000000000000__INCLUDED_)
