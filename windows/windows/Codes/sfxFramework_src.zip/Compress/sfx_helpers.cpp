// Self Extracting File Framework
// ==============================
//
// Copyright � 2000 Rui Godinho Lopes <ruiglopes@yahoo.com>
// All rights reserved.
//
// This source file(s) may be redistributed unmodified by any means
// PROVIDING they are not sold for profit without the authors expressed
// written consent, and providing that this notice and the authors name
// and all copyright notices remain intact.
//
// Any use of the software in source or binary forms, with or without
// modification, must include, in the user documentation ("About" box and
// printed documentation) and internal comments to the code, notices to
// the end user as follows:
//
// "Portions Copyright � 2000 Rui Godinho Lopes"
//
// An email letting me know that you are using it would be nice as well.
// That's not much to ask considering the amount of work that went into
// this.
//
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED. USE IT AT YOUT OWN RISK. THE AUTHOR ACCEPTS NO
// LIABILITY FOR ANY DATA DAMAGE/LOSS THAT THIS PRODUCT MAY CAUSE.
//
// =======================================================================
// REVISION HISTORY
// =======================================================================
// 1.00 14July2000
//   first public version
//
//////////////////////////////////////////////////////////////////////////

#include "sfx_helpers.h"


//This function will append (at current file position) and compress
//a file (pInFile) into a output file (hOutFile) and will return
//a compression information (Info)
BOOL sfxAppendCompressFile(LPCTSTR /*in*/pInFile, HANDLE /*in*/hOutFile, COMPRESSIONINFO /*out*/&Info, int /*in*/iCompressionLevel/*= Z_DEFAULT_COMPRESSION*/)
{
	CWin32FileCompress FileCompress;

	//Init stream handles
	AutoFreeHandle hFileIn= (FileCompress.m_Reader.m_hFile= CreateFile(pInFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL));
	FileCompress.m_Writer.m_hFile= hOutFile;

	if (FileCompress.Init(iCompressionLevel))
		return FALSE;

	if (FileCompress.Compress())
		return FALSE;

	return FileCompress.GetInfo(Info);
}
