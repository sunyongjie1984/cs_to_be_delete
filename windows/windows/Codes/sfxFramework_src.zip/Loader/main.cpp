// Loader.cpp : Defines the entry point for the application.
//
//////////////////////////////////////////////////////////////////////////
// Self Extracting File Framework
// ==============================
//
// Copyright � 2000 Rui Godinho Lopes <ruiglopes@yahoo.com>
// All rights reserved.
//
// This source file(s) may be redistributed unmodified by any means
// PROVIDING they are not sold for profit without the authors expressed
// written consent, and providing that this notice and the authors name
// and all copyright notices remain intact.
//
// Any use of the software in source or binary forms, with or without
// modification, must include, in the user documentation ("About" box and
// printed documentation) and internal comments to the code, notices to
// the end user as follows:
//
// "Portions Copyright � 2000 Rui Godinho Lopes"
//
// An email letting me know that you are using it would be nice as well.
// That's not much to ask considering the amount of work that went into
// this.
//
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED. USE IT AT YOUT OWN RISK. THE AUTHOR ACCEPTS NO
// LIABILITY FOR ANY DATA DAMAGE/LOSS THAT THIS PRODUCT MAY CAUSE.
//
// =======================================================================
// REVISION HISTORY
// =======================================================================
// 1.00 14July2000
//   first public version
//
//////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Loader.h"
#include "LoaderPriv.h"
#include <stdlib.h> //for _itot (itoa)

int APIENTRY WinMain(HINSTANCE /*hInstance*/, HINSTANCE /*hPrevInstance*/, LPSTR /*lpCmdLine*/, int /*nCmdShow*/)
{
	int iResult;

	if (iResult= g_Loader.Init())
	{
		//Simple error dump, no need for more....
		TCHAR buf[30]= "Error: "; _itot(iResult, &buf[7], 10);
		MessageBox(NULL, _T("Failed to initialize.\nPlease get a new copy of this program."), buf, MB_ICONERROR);
		return iResult;
	}

	//NOTE: the others errors should be displayed be the StartModule
	if ((iResult= g_Loader.Run())==SFX_CANNOTRUNSTARTMODULE)
		MessageBox(NULL, _T("Failed to run.\nPlease get a new copy of this program."), NULL, MB_ICONERROR);

	return iResult;
}



