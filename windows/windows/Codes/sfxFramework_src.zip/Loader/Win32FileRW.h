// Self Extracting File Framework
// ==============================
//
// Copyright � 2000 Rui Godinho Lopes <ruiglopes@yahoo.com>
// All rights reserved.
//
// This source file(s) may be redistributed unmodified by any means
// PROVIDING they are not sold for profit without the authors expressed
// written consent, and providing that this notice and the authors name
// and all copyright notices remain intact.
//
// Any use of the software in source or binary forms, with or without
// modification, must include, in the user documentation ("About" box and
// printed documentation) and internal comments to the code, notices to
// the end user as follows:
//
// "Portions Copyright � 2000 Rui Godinho Lopes"
//
// An email letting me know that you are using it would be nice as well.
// That's not much to ask considering the amount of work that went into
// this.
//
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED. USE IT AT YOUT OWN RISK. THE AUTHOR ACCEPTS NO
// LIABILITY FOR ANY DATA DAMAGE/LOSS THAT THIS PRODUCT MAY CAUSE.
//
// =======================================================================
// REVISION HISTORY
// =======================================================================
// 1.00 14July2000
//   first public version
//
//////////////////////////////////////////////////////////////////////////

#ifndef Win32FileRW_H_INC
#define Win32FileRW_H_INC

class CWin32FileReader
{
public:
	LRESULT Read(
		void *pv,				//Pointer to buffer into which the stream is read
		ULONG cb,				//Specifies the number of bytes to read
		ULONG *pcbRead	//Pointer to location that contains actual number of bytes read
	)	{ return ReadFile(m_hFile, pv, cb, pcbRead, NULL)? S_OK : S_FALSE; }

	HANDLE m_hFile;
};


class CWin32FileWriter
{
public:
	LRESULT Write(
		void const *pv,		//Address of buffer from which stream is written
		ULONG cb,					//Specifies the number of bytes to write
		ULONG *pcbWritten	//Specifies the actual number of bytes written
		) { return WriteFile(m_hFile, pv, cb, pcbWritten, NULL)? S_OK : S_FALSE; }

	HANDLE m_hFile;
};

#endif