//********************************
// Code for running the DLL Module
//********************************
#include "stdafx.h"

#ifndef _STARTMODULE_IS_EXE
#include "LoaderTypes.h"
#include "LoaderPriv.h"

int CLoader::Run()
{
	if (m_hStartModule= LoadLibrary(m_pStartModuleName))
	{
		SFX_MainPROC sfx_main;
		sfx_main= (SFX_MainPROC)GetProcAddress(m_hStartModule, _T("sfx_main"));
		return sfx_main(this); //Handle control to Dll
	}
	return SFX_CANNOTRUNSTARTMODULE;
}

#endif