// Self Extracting File Framework
// ==============================
//
// Copyright � 2000 Rui Godinho Lopes <ruiglopes@yahoo.com>
// All rights reserved.
//
// This source file(s) may be redistributed unmodified by any means
// PROVIDING they are not sold for profit without the authors expressed
// written consent, and providing that this notice and the authors name
// and all copyright notices remain intact.
//
// Any use of the software in source or binary forms, with or without
// modification, must include, in the user documentation ("About" box and
// printed documentation) and internal comments to the code, notices to
// the end user as follows:
//
// "Portions Copyright � 2000 Rui Godinho Lopes"
//
// An email letting me know that you are using it would be nice as well.
// That's not much to ask considering the amount of work that went into
// this.
//
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED. USE IT AT YOUT OWN RISK. THE AUTHOR ACCEPTS NO
// LIABILITY FOR ANY DATA DAMAGE/LOSS THAT THIS PRODUCT MAY CAUSE.
//
// =======================================================================
// REVISION HISTORY
// =======================================================================
// 1.00 14July2000
//   first public version
//
//////////////////////////////////////////////////////////////////////////

#ifndef _ILOADER_H_INC_
#define _ILOADER_H_INC_

#include "LoaderTypes.h"

/*
 * this interface is to be used with DLL Start Modules
 */
class ILoader
{
public:
	/*
	 * this will return the sfxLoader version
	 */
	virtual DWORD GetVersion()= 0;

	/*
	 * this will return the system temp path
	 */
	virtual LPCTSTR GetTempPath()= 0;

	/*
	 * this will return the sfxLoader file name with full path
	 */
	virtual LPCTSTR GetModuleName()= 0;

	/*
	 * this will expand a stream of compressed data
	 */
	virtual LRESULT ExpandStream(STREAMINFO /*[in]*/ *pStreamInfo)= 0;
};

#endif