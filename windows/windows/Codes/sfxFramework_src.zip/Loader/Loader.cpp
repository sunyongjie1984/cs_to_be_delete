// Self Extracting File Framework
// ==============================
//
// Copyright � 2000 Rui Godinho Lopes <ruiglopes@yahoo.com>
// All rights reserved.
//
// This source file(s) may be redistributed unmodified by any means
// PROVIDING they are not sold for profit without the authors expressed
// written consent, and providing that this notice and the authors name
// and all copyright notices remain intact.
//
// Any use of the software in source or binary forms, with or without
// modification, must include, in the user documentation ("About" box and
// printed documentation) and internal comments to the code, notices to
// the end user as follows:
//
// "Portions Copyright � 2000 Rui Godinho Lopes"
//
// An email letting me know that you are using it would be nice as well.
// That's not much to ask considering the amount of work that went into
// this.
//
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED. USE IT AT YOUT OWN RISK. THE AUTHOR ACCEPTS NO
// LIABILITY FOR ANY DATA DAMAGE/LOSS THAT THIS PRODUCT MAY CAUSE.
//
// =======================================================================
// REVISION HISTORY
// =======================================================================
// 1.00 14July2000
//   first public version
//
//////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Loader.h"
#include "LoaderPriv.h"
#include "StreamDecompress.h"
#include "Win32FileRW.h"
#include <malloc.h>

CLoader g_Loader;

//You should leave this copyright notice here!
static char *loader_copyright= "sfxLoader � Rui Godinho Lopes";
//sfxLoader � 2000 Rui Godinho Lopes <ruiglopes@yahoo.com>

LRESULT WINAPI NULLCallback(const STREAMSTATUS *) { return FALSE; }

class CStreamSimpleCallback
{
public:
	void OnStatus(ULONG ulBytesDone)
	{
		m_Status.dwDone= ulBytesDone;
		m_pCallback(&m_Status);
	}
	STREAMSTATUS m_Status;
	STREAMCALLBACK m_pCallback;
};


CLoader::CLoader()
{
	/*m_pTempPath= m_pModuleName= NULL;
	m_hSetupDll= NULL;*/
	//NOTE: Since this will be a global variable this will be initialized
	//with NULL
}

CLoader::~CLoader()
{
	delete [] m_pTempPath;
	free(m_pModuleName); //delete [] m_pModuleName;

#ifdef _STARTMODULE_IS_EXE
	CloseHandle(m_hStartModule);
#else
	BOOL bFreed= FreeLibrary(m_hStartModule);
#endif

#ifndef _DEBUG
	//Sleep(1500); //I don't know if it's safe to delete the file right the way, or waiting a little bit....
	//remove the start module from disk, now that the job is done...
	BOOL bDeleted= DeleteFile(m_pStartModuleName);
#endif

	free(m_pStartModuleName);
}

UINT CLoader::CreateTemporaryFile(LPTSTR pTemporaryFileName)
{
	return ::GetTempFileName(m_pTempPath, _T("@"), 0, pTemporaryFileName);
}

LRESULT CLoader::ExpandStream(STREAMINFO *pStreamInfo)
{
	typedef CStreamDecompress<CWin32FileReader, CWin32FileWriter, CStreamSimpleCallback> CWin32FileDecompress;

	CWin32FileDecompress expandStream;
	expandStream.m_Reader.m_hFile= pStreamInfo->hFileIn;
	expandStream.m_Writer.m_hFile= pStreamInfo->hFileOut;
	expandStream.m_Status.m_pCallback= pStreamInfo->pCallback;
	expandStream.m_Status.m_Status.lParam= pStreamInfo->lParam;
	expandStream.m_Status.m_Status.dwSize= pStreamInfo->dwSize;

	if (expandStream.Init(pStreamInfo->dwBufferSize))
	{
		LRESULT lResult= expandStream.Decompress();

		COMPRESSIONINFO Info;
		expandStream.GetInfo(Info);
		pStreamInfo->dwChecksum= Info.dwChecksum;
		return lResult==S_OK? SFX_OK : SFX_CORRUPTSTREAM;
	}

	return SFX_CORRUPTSTREAM;
}

int CLoader::InitStartModule()
{
	//-----------------------------------------------
	// Open the EXE file where we are, the Loader.Exe
	//-----------------------------------------------
	TCHAR TempFileName[MAX_PATH];
	GetModuleFileName(GetModuleHandle(NULL), TempFileName, MAX_PATH-1);

#ifdef _DEBUG
//****************************************************
// On debug do not try do expand anything from our EXE
// instead open our 'MySFXFile.exe' sample file
//****************************************************
{
	_tcscpy(TempFileName, _T("MySFXFile.exe"));
}
#endif

	m_pModuleName= _tcsdup(TempFileName);

	HANDLE hLoaderFile= CreateFile(TempFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	LOADERHEADER LoaderHeader;

	//-----------------------------------
	// Get the LoadHeader & validate file
	//-----------------------------------
	SetFilePointer(hLoaderFile, sfx_dwHeaderPos, NULL, FILE_BEGIN);

	DWORD dwBytesRead;
	ReadFile(hLoaderFile, &LoaderHeader, sizeof(LOADERHEADER), &dwBytesRead, NULL);
	if (LoaderHeader.dwMagicID!=LOADERHEADER::MAGICID)
	{
		CloseHandle(hLoaderFile);
		return SFX_INVALIDFILE;
	}

	//Set the file pointer in the start of the StartModule
	SetFilePointer(hLoaderFile, LoaderHeader.dwStartModulePos, NULL, FILE_BEGIN);

	//----------------------------------------------------
	// creates a unique temporary file for the StartModule
	//----------------------------------------------------
	CreateTemporaryFile(TempFileName);
	m_pStartModuleName= _tcsdup(TempFileName);

	//------------------------------
	// Creates the Start Module File
	//------------------------------
	HANDLE hStartModule= CreateFile(TempFileName, GENERIC_WRITE, FILE_SHARE_READ, NULL, TRUNCATE_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	//-------------------------------
	// Expand & load the Start Module
	//-------------------------------

	// Init Stream Info
	STREAMINFO StreamInfo;
	StreamInfo.dwBufferSize= 4096;
	StreamInfo.hFileIn= hLoaderFile;
	StreamInfo.hFileOut= hStartModule;
	StreamInfo.pCallback= NULLCallback;
	//no need for this: StreamInfo.dwSize= LoaderHeader.dwStartModuleSize;

	LRESULT lResult= ExpandStream(&StreamInfo);

	BOOL bClosed;
	bClosed= CloseHandle(hLoaderFile);
	bClosed= CloseHandle(hStartModule);

	return ((lResult!=S_OK) || (StreamInfo.dwChecksum!=LoaderHeader.dwStartModuleChecksum))
				? SFX_CORRUPTSTARTMODULE : SFX_OK;
}

int CLoader::Init()
{
	DWORD nBufLen= ::GetTempPath(0, NULL);
	m_pTempPath= new TCHAR[nBufLen+1];
	::GetTempPath(nBufLen, m_pTempPath);

	return InitStartModule();
}
