// Self Extracting File Framework
// ==============================
//
// Copyright � 2000 Rui Godinho Lopes <ruiglopes@yahoo.com>
// All rights reserved.
//
// This source file(s) may be redistributed unmodified by any means
// PROVIDING they are not sold for profit without the authors expressed
// written consent, and providing that this notice and the authors name
// and all copyright notices remain intact.
//
// Any use of the software in source or binary forms, with or without
// modification, must include, in the user documentation ("About" box and
// printed documentation) and internal comments to the code, notices to
// the end user as follows:
//
// "Portions Copyright � 2000 Rui Godinho Lopes"
//
// An email letting me know that you are using it would be nice as well.
// That's not much to ask considering the amount of work that went into
// this.
//
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED. USE IT AT YOUT OWN RISK. THE AUTHOR ACCEPTS NO
// LIABILITY FOR ANY DATA DAMAGE/LOSS THAT THIS PRODUCT MAY CAUSE.
//
// =======================================================================
// REVISION HISTORY
// =======================================================================
// 1.00 14July2000
//   first public version
//
//////////////////////////////////////////////////////////////////////////

#ifndef LOADERPRIV_H_INC_
#define LOADERPRIV_H_INC_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


//Return Errors:
enum
{
	SFX_RESERVED_ERRORSSTART= -100,


	SFX_INVALIDFILE,						//the SFX file is invalid/corrupted
	SFX_CORRUPTSTARTMODULE,			//Start module is corrupted
	SFX_CANNOTRUNSTARTMODULE,		//the start module failed to run
	SFX_CORRUPTSTREAM,					//the ExpandStream failed

	SFX_OK= 0	//all ok
};


/*
SelfExtractingFile Structure
============================
---------------------------------
| +--------------------------+  |\
| | <sfxStub.exe FILE MS-DOS>|  | \
| +- - - - - - - - - - - - - +  |  \
| |<sfxLoader.exe FILE Win32>|  |   > This is the sfxLoader.e32 file
| +- - - - - - - - - - - - - +  |  /  (automatic generated from VS,
| |        LOADERHEADER      |  | /    we only have to change the
| +--------------------------+  |/     LOADERHEADER part)
+-------------------------------+
|                               |
|  startmodule compressed file  |
|                               |
+-------------------------------+
|                               |
:                               :
:           user data           :
:                               :
|                               |
---------------------------------

NOTE1:
Since the MZ executable file format has 32 free bytes
(well there are unused bytes) they start at 0x1c and
end at 0x3b so I put the LOADERHEADER there, this way
I save some bytes on data and code!

NOTE2:
If we use sfxStub.exe (we should use it!) when
linking the sfxLoader.exe we have some more extra
storage space (107 bytes) that the startmodule can use!
(read the sfxStub.asm)

NOTE3:
We can gain some more extra bytes by removing
extra align/padding data (null filled) from the end of
the sfxLoader.e32, but make sure that you know what
you are doing!

NOTE4:
We can also make some more savings changing
the icon resource (Loader.ico):
+----------+-------+-------+---------------+
| option   | 16x16 | 32x32 |  bytes saved  |
+----------+-------+-------+---------------+
| option 1*|   X   |   X   |       0       |
| option 2 |   X   |       |     1324      |
| option 3 |no icon linked |     2048      |
+----------+-------+-------+---------------+
*/


//Byte size: 16bytes (we have more 16 bytes to play in future!)
struct LOADERHEADER
{
	enum { MAGICID= 0x58465372 };
	DWORD dwMagicID;
	DWORD dwStartModulePos;
	DWORD dwStartModuleSize;
	DWORD dwStartModuleChecksum;
};

const DWORD sfx_dwHeaderPos= 0x0000001c; //The LOADERHEADER is in this offset

#endif
