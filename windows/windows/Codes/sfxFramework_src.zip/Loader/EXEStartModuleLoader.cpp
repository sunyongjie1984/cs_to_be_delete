//********************************
// Code for running the EXE Module
//********************************

#include "stdafx.h"

#ifdef _STARTMODULE_IS_EXE
#include "LoaderPriv.h"

int CLoader::Run()
{
	{
		PROCESS_INFORMATION pi;
		STARTUPINFO si= {0};
		si.cb						= sizeof(STARTUPINFO);
		/*si.dwFlags			= STARTF_USESHOWWINDOW;
		si.wShowWindow	= SW_HIDE;*/

		size_t lenStartModule= _tcsclen(m_pStartModuleName);
		size_t lenModule= _tcsclen(m_pModuleName);

		LPTSTR pCmdLine= new TCHAR[lenStartModule+lenModule+5+1];
		*pCmdLine= _T('"');
		_tcscpy(&pCmdLine[1], m_pStartModuleName);
		_tcscpy(&pCmdLine[lenStartModule+1], _T("\" \""));
		_tcscpy(&pCmdLine[lenStartModule+4], m_pModuleName);
		_tcscpy(&pCmdLine[lenStartModule+4+lenModule], _T("\""));

		if (!CreateProcess(NULL, pCmdLine, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
		{
			delete [] pCmdLine;
			return SFX_CANNOTRUNSTARTMODULE;
		}
		delete [] pCmdLine;
		CloseHandle(pi.hThread); //close this, we do not need it.
		m_hStartModule= pi.hProcess;
	}

	WaitForSingleObject(m_hStartModule, INFINITE); //waits for module end

	DWORD dwExitCode;
	GetExitCodeProcess(m_hStartModule, &dwExitCode);

	return dwExitCode;
}

#endif