// Self Extracting File Framework
// ==============================
//
// Copyright � 2000 Rui Godinho Lopes <ruiglopes@yahoo.com>
// All rights reserved.
//
// This source file(s) may be redistributed unmodified by any means
// PROVIDING they are not sold for profit without the authors expressed
// written consent, and providing that this notice and the authors name
// and all copyright notices remain intact.
//
// Any use of the software in source or binary forms, with or without
// modification, must include, in the user documentation ("About" box and
// printed documentation) and internal comments to the code, notices to
// the end user as follows:
//
// "Portions Copyright � 2000 Rui Godinho Lopes"
//
// An email letting me know that you are using it would be nice as well.
// That's not much to ask considering the amount of work that went into
// this.
//
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED. USE IT AT YOUT OWN RISK. THE AUTHOR ACCEPTS NO
// LIABILITY FOR ANY DATA DAMAGE/LOSS THAT THIS PRODUCT MAY CAUSE.
//
// =======================================================================
// REVISION HISTORY
// =======================================================================
// 1.00 14July2000
//   first public version
//
//////////////////////////////////////////////////////////////////////////

#ifndef LOADER_H_INC_
#define LOADER_H_INC_

//  define '_STARTMODULE_IS_EXE' if the StartModule is a EXE
//undefine '_STARTMODULE_IS_EXE' if the StartModule is a DLL
//#define _STARTMODULE_IS_EXE

#include "ILoader.h"

const LOADERVERSION= 0x00010000; //1.0

class CLoader
#ifndef _STARTMODULE_IS_EXE
: public ILoader
#endif
{
public:
	CLoader();
	~CLoader();

	int Init();
	int Run();

public:
	LPCTSTR GetTempPath() { return m_pTempPath; }
	LPCTSTR GetModuleName() { return m_pModuleName; }
	DWORD GetVersion() { return LOADERVERSION; }
	LRESULT ExpandStream(STREAMINFO *pStreamInfo);


//private functions:
private:
	int InitStartModule();
	UINT CreateTemporaryFile(LPTSTR pTemporaryFileName);
//private data:
private:
	LPTSTR m_pTempPath;
	LPTSTR m_pModuleName;				//The loader.exe file
	LPTSTR m_pStartModuleName;	//Temporary StartModule file name

#ifdef _STARTMODULE_IS_EXE
	HANDLE m_hStartModule;			//handle to the StartModule
#else
	HINSTANCE m_hStartModule;		//handle to the StartModule
#endif
};

extern CLoader g_Loader;

#endif
