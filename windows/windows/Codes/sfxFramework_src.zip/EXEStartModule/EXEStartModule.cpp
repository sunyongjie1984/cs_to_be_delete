// EXEStartModule.cpp : Defines the entry point for the application.
//

//
// NOTES
// =====
//
// For using this demo you have to build the sfxLoader with
// '_STARTMODULE_IS_EXE' defined take a look at the 'Loader.h'
//
#include "stdafx.h"


LPTSTR FindNextParameter(LPTSTR lpStr)
{
	if (lpStr)
	{
		lpStr= strchr(++lpStr, *lpStr=='"'? '"' : ' ');
		if (lpStr)
		{
			++lpStr;
			while (*lpStr && *lpStr==' ') ++lpStr;
			if (*lpStr)	return lpStr;
		}
	}

	return NULL;
}



int APIENTRY WinMain(HINSTANCE /*hInstance*/,
                     HINSTANCE /*hPrevInstance*/,
                     LPSTR     /*lpCmdLine*/,
                     int       /*nCmdShow*/)
{
	LPTSTR pCmdLine= GetCommandLine();

	//NOTE: The second parameter of pCmdLine is the full path
	//to the sfx file where the UserData is
	//NOTE: the sfx path name is always quoted.

	LPTSTR pSFXFile;
	pSFXFile= FindNextParameter(pCmdLine);
	PathUnquoteSpaces(pSFXFile); //remove quotes

	HANDLE hSFX= CreateFile(pSFXFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hSFX==INVALID_HANDLE_VALUE)
	{
		MessageBox(NULL, _T("Failed to Open the SFX!?"), NULL, MB_OK|MB_ICONERROR);
		return -200;
	}

	//From here you can do anything you want with the SFX file.


	MessageBox(NULL, pSFXFile, _T("Hello World!"), MB_OK|MB_ICONINFORMATION);


	CloseHandle(hSFX);
	return 0;
}
