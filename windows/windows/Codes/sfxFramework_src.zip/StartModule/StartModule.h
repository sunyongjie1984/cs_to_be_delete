
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the STARTMODULE_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// STARTMODULE_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef STARTMODULE_EXPORTS
#define STARTMODULE_API __declspec(dllexport)
#else
#define STARTMODULE_API __declspec(dllimport)
#endif

#include "../Loader/ILoader.h" //if your module is an dll you must include this!

STARTMODULE_API LONG WINAPI sfx_main(ILoader *);
