// StartModule.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "StartModule.h"

//if you dont need this, comment or remove!
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

LRESULT WINAPI NULLCallback(const STREAMSTATUS *pStatus)
{
	return 0;
}


void TestExpandStream(ILoader *pLoader);

STARTMODULE_API LONG WINAPI sfx_main(ILoader *pLoader)
{
 	DWORD dwVersion= pLoader->GetVersion();


	//TestExpandStream(pLoader);


	MessageBox(NULL, _T("Hello World!"), _T("StartModule.dll"), MB_OK);

	return TRUE;
}


//-----------------------------------------------------
// Here is a sample code to expand a compressed file to
// another
// NOTE: You have to change the pInFile/pOutFile ;)
//-----------------------------------------------------
void TestExpandStream(ILoader *pLoader)
{
	const LPCTSTR InFile= _T("compress.pdb_");
	const LPCTSTR OutFile= _T("compress1.pdb");

	HANDLE hCompressedFile= CreateFile(InFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	HANDLE hExpandedFile= CreateFile(OutFile, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	// Init Stream Info
	STREAMINFO StreamInfo;
	StreamInfo.dwBufferSize= 4096;
	StreamInfo.hFileIn= hCompressedFile;
	StreamInfo.hFileOut= hExpandedFile;
	StreamInfo.pCallback= NULLCallback;

	if (pLoader->ExpandStream(&StreamInfo)==S_OK)
	{
		MessageBox(NULL, _T("Everything good!"), _T("Expand Stream"), MB_OK);
	}

	CloseHandle(hCompressedFile);
	CloseHandle(hExpandedFile);
}
