// Wizard97PropertyPage.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "Wizard97PropertyPage.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CWizard97PropertyPage1, CPropertyPageEx)
IMPLEMENT_DYNCREATE(CWizard97PropertyPage2, CPropertyPageEx)
IMPLEMENT_DYNCREATE(CWizard97PropertyPage3, CPropertyPageEx)


/////////////////////////////////////////////////////////////////////////////
// CWizard97PropertyPage1 property page

CWizard97PropertyPage1::CWizard97PropertyPage1() : CPropertyPageEx(CWizard97PropertyPage1::IDD)
{
	//{{AFX_DATA_INIT(CWizard97PropertyPage1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	//First Welcome Page having only WaterMark
	m_psp.dwFlags |= PSP_HIDEHEADER;
}

CWizard97PropertyPage1::~CWizard97PropertyPage1()
{
}

void CWizard97PropertyPage1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPageEx::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWizard97PropertyPage1)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWizard97PropertyPage1, CPropertyPageEx)
	//{{AFX_MSG_MAP(CWizard97PropertyPage1)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CWizard97PropertyPage2 property page

CWizard97PropertyPage2::CWizard97PropertyPage2() : CPropertyPageEx(CWizard97PropertyPage2::IDD)
{
	//{{AFX_DATA_INIT(CWizard97PropertyPage2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CWizard97PropertyPage2::~CWizard97PropertyPage2()
{
}

void CWizard97PropertyPage2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPageEx::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWizard97PropertyPage2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWizard97PropertyPage2, CPropertyPageEx)
	//{{AFX_MSG_MAP(CWizard97PropertyPage2)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CWizard97PropertyPage3 property page

CWizard97PropertyPage3::CWizard97PropertyPage3() : CPropertyPageEx(CWizard97PropertyPage3::IDD)
{
	//{{AFX_DATA_INIT(CWizard97PropertyPage3)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_psp.dwFlags &= ~(PSH_HASHELP);
}

CWizard97PropertyPage3::~CWizard97PropertyPage3()
{
}

void CWizard97PropertyPage3::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPageEx::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWizard97PropertyPage3)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWizard97PropertyPage3, CPropertyPageEx)
	//{{AFX_MSG_MAP(CWizard97PropertyPage3)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


