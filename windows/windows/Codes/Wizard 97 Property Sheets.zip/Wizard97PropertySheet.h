// Wizard97PropertySheet.h : header file
//
// This class defines custom modal property sheet 
// CWizard97PropertySheet.
 
#ifndef __MYPROPERTYSHEET_H__
#define __MYPROPERTYSHEET_H__

#include "Wizard97PropertyPage.h"

/////////////////////////////////////////////////////////////////////////////
// CWizard97PropertySheet
//Modify the base class from CPropertySheet to CPropertySheetEx

class CWizard97PropertySheet : public CPropertySheetEx
{
	DECLARE_DYNAMIC(CWizard97PropertySheet)

// Construction
public:
	//Extended Property Sheet constructors require the
	//watermark and the header bitmap
	CWizard97PropertySheet(CWnd* pParentWnd = NULL,
			UINT iSelectPage = 0, HBITMAP hWatermark = NULL,
			HPALETTE hpalWatermark = NULL, HBITMAP hHeader = NULL);
	//CWizard97PropertySheet(CWnd* pWndParent = NULL);

// Attributes
public:
	CWizard97PropertyPage1 m_Page1;
	CWizard97PropertyPage2 m_Page2;
	CWizard97PropertyPage3 m_Page3;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWizard97PropertySheet)
	public:
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	virtual BOOL OnInitDialog();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CWizard97PropertySheet();

// Generated message map functions
protected:
	//{{AFX_MSG(CWizard97PropertySheet)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// __MYPROPERTYSHEET_H__
