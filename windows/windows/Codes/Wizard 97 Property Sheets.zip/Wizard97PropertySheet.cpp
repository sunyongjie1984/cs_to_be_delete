// Wizard97PropertySheet.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "Wizard97PropertySheet.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

//Finish back and next id's

#define FINISH	12325
#define NEXT	12324
#define BACK	12323

/////////////////////////////////////////////////////////////////////////////
// CWizard97PropertySheet

IMPLEMENT_DYNAMIC(CWizard97PropertySheet, CPropertySheetEx)

CWizard97PropertySheet::CWizard97PropertySheet(CWnd* pParentWnd,
	UINT iSelectPage, HBITMAP hWatermark, HPALETTE hpalWatermark,
	HBITMAP hHeader)
: CPropertySheetEx(IDS_PROPSHT_CAPTION, pParentWnd, iSelectPage,
				  hWatermark, hpalWatermark, hHeader)
{
	// Add all of the property pages here.  Note that
	// the order that they appear in here will be
	// the order they appear in on screen.  By default,
	// the first page of the set is the active one.
	// One way to make a different property page the 
	// active one is to call SetActivePage().

	AddPage(&m_Page1);
	AddPage(&m_Page2);
	AddPage(&m_Page3);

	//Set the Wizard 97 Style for the Property Sheet
	m_psh.dwFlags |= PSH_WIZARD97;
}

CWizard97PropertySheet::~CWizard97PropertySheet()
{
}


BEGIN_MESSAGE_MAP(CWizard97PropertySheet, CPropertySheetEx)
	//{{AFX_MSG_MAP(CWizard97PropertySheet)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CWizard97PropertySheet message handlers



BOOL CWizard97PropertySheet::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo) 
{
	//Handle the Property Sheets back next and finish button settings

	int iPage = GetActiveIndex( );
	if(((iPage == 0) && (nID == NEXT)) || ((iPage == 2) && (nID == BACK)) )
	{
		SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
	}
	else if(iPage == 1)
	{
		if (nID == NEXT)
			SetWizardButtons(PSWIZB_BACK | PSWIZB_FINISH);
		else if (nID == BACK)
			SetWizardButtons(PSWIZB_NEXT);
	}
	return CPropertySheetEx::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

BOOL CWizard97PropertySheet::OnInitDialog() 
{
	BOOL bResult = CPropertySheetEx::OnInitDialog();
	
	//We need only the next button
	SetWizardButtons(PSWIZB_NEXT);
	
	return bResult;
}
