// Wizard97PropertyPage.h : header file
//

#ifndef __MYPROPERTYPAGE1_H__
#define __MYPROPERTYPAGE1_H__

/////////////////////////////////////////////////////////////////////////////
// CWizard97PropertyPage1 dialog
//Modify the base class from CPropertyPage to CPropertyPageEx
class CWizard97PropertyPage1 : public CPropertyPageEx
{
	DECLARE_DYNCREATE(CWizard97PropertyPage1)

// Construction
public:
	CWizard97PropertyPage1();
	~CWizard97PropertyPage1();

// Dialog Data
	//{{AFX_DATA(CWizard97PropertyPage1)
	enum { IDD = IDD_PROPPAGE1 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CWizard97PropertyPage1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CWizard97PropertyPage1)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};


/////////////////////////////////////////////////////////////////////////////
// CWizard97PropertyPage2 dialog

class CWizard97PropertyPage2 : public CPropertyPageEx
{
	DECLARE_DYNCREATE(CWizard97PropertyPage2)

// Construction
public:
	CWizard97PropertyPage2();
	~CWizard97PropertyPage2();

// Dialog Data
	//{{AFX_DATA(CWizard97PropertyPage2)
	enum { IDD = IDD_PROPPAGE2 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CWizard97PropertyPage2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CWizard97PropertyPage2)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};


/////////////////////////////////////////////////////////////////////////////
// CWizard97PropertyPage3 dialog

class CWizard97PropertyPage3 : public CPropertyPageEx
{
	DECLARE_DYNCREATE(CWizard97PropertyPage3)

// Construction
public:
	CWizard97PropertyPage3();
	~CWizard97PropertyPage3();

// Dialog Data
	//{{AFX_DATA(CWizard97PropertyPage3)
	enum { IDD = IDD_PROPPAGE3 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CWizard97PropertyPage3)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CWizard97PropertyPage3)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};



#endif // __MYPROPERTYPAGE1_H__
