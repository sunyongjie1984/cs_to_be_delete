#include "think_error.h"
#include "think_utility.h"
#include "think_gl.h"
#include "think_route.h"

THINK_ROUTE *think_routelogin(const char *addr,unsigned int id)
{
	THINK_ROUTE *route;
	THINK_NET *net;
	char msgbuf[1024],respcode[3],resptext[128];
	int msglen;
	char ip[16],port[6];

	/* connect to router */
	think_strgetfield(addr,':',0,ip,sizeof(ip));
	think_strgetfield(addr,':',1,port,sizeof(port));
	if((net=think_netconnect(ip,atol(port)))==NULL){
		think_errorerror();
		return NULL;
	}

	/* login */
	msglen=0;
	msglen+=think_gl_put(msgbuf,sizeof(msgbuf)-msglen,1,'C',2,"10",2);
	msglen+=think_gl_put(msgbuf,sizeof(msgbuf)-msglen,2,'I',0,&id,sizeof(id));
	if(think_netsendmsg(net,msgbuf,msglen)<0){
		think_errorerror();
		think_netclose(net);
		return NULL;
	}
	if((msglen=think_netrecvmsg(net,msgbuf,sizeof(msgbuf)))<0){
		think_errorerror();
		think_netclose(net);
		return NULL;
	}
	bzero(respcode,sizeof(respcode));
	if(think_gl_get(msgbuf,msglen,125,'C',2,respcode,sizeof(respcode))<0){
		think_errorerror();
		think_netclose(net);
		return NULL;
	}
	if(think_gl_get(msgbuf,msglen,126,'C',127,resptext,sizeof(resptext))<0){
		think_errorerror();
		think_netclose(net);
		return NULL;
	}
	if(strcmp(respcode,"00")!=0){
		think_error(0,"[%s]:login failed.[%s:%s]",__func__,respcode,resptext);
		think_netclose(net);
		return NULL;
	}
	if((route=malloc(sizeof(THINK_ROUTE)))==NULL){
		think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		think_netclose(net);
		return NULL;
	}
	bzero(route,sizeof(THINK_ROUTE));
	route->net=net;
	snprintf(route->addr,sizeof(route->addr),"%s",addr);
	route->id=id;

	return route;
}

int think_routesend(THINK_ROUTE *route,unsigned int id,const void *buf,unsigned int len,int flags)
{
	char msgbuf[1024];
	int msglen;

	msglen=0;
	msglen+=think_gl_put(msgbuf,sizeof(msgbuf)-msglen,1,'C',2,"20",2);
	msglen+=think_gl_put(msgbuf,sizeof(msgbuf)-msglen,4,'I',0,&id,sizeof(id));
	msglen+=think_gl_put(msgbuf,sizeof(msgbuf)-msglen,5,'I',0,&len,sizeof(len));
	if(think_netsendmsg(route->net,msgbuf,msglen)<0){
		think_errorerror();
		return -1;
	}
	if(think_netsend(route->net,buf,len,THINK_NET_WAIT)<0){
		think_errorerror();
		return -1;
	}

	return 0;
}
int think_routerecv(THINK_ROUTE *route,unsigned int *id,void *buf,unsigned int siz,int flags)
{
	char msgbuf[1024],msgtype[3];
	int msglen,len;

	msglen=0;
	if((msglen=think_netrecvmsg(route->net,msgbuf,sizeof(msgbuf)))<0){
		think_errorerror();
		return -1;
	}
	bzero(msgtype,sizeof(msgtype));
	think_gl_get(msgbuf,msglen,1,'C',2,msgtype,sizeof(msgtype));
	if(strcmp(msgtype,"20")!=0){
		think_error(0,"[%s]:msgtype illegal.[%s]",__func__,msgtype);
		return -1;
	}
	think_gl_get(msgbuf,msglen,3,'I',0,id,sizeof(int));
	think_gl_get(msgbuf,msglen,5,'I',0,&len,sizeof(len));
	if(len>siz){
		think_error(0,"[%s]:message too long.[%d>%d]",__func__,len,siz);
		return -1;
	}
	if(think_netrecv(route->net,buf,len,THINK_NET_WAIT)<0){
		think_errorerror();
		return -1;
	}

	return len;
}
int think_routelogout(THINK_ROUTE *route)
{
	think_netclose(route->net);
	free(route);

	return 0;
}
