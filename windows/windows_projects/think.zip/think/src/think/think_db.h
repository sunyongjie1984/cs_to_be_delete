/*
 * think_db.h: Think DB Interface
 * version: 1.0
 * OS: AIX,HP-UX,Solaris,FreeBSD,Linux,Mac OS X,Windows
 * author: luojian(enigma1983@qq.com)
 * history:
 * 2008-11-07	1.0 released
 *
 */

#ifndef __THINK_DB_H__
#define __THINK_DB_H__

#include "think_os.h"
#include "think_file.h"

/* C++ */
#ifdef __cplusplus
extern "C" {
#endif

/* open flags */
#define THINK_DB_CREAT 		0x01		/* creat */
#define THINK_DB_EXCL 		0x02		/* excl */
#define THINK_DB_TRUNC 		0x04		/* trunc */
#define THINK_DB_RDONLY 	0x08		/* read only */
#define THINK_DB_WRONLY 	0x10		/* write only */
#define THINK_DB_RDWR 		0x20		/* read & write */
#define THINK_DB_APPEND 	0x40		/* append */
#define THINK_DB_SYNC		0x80		/* sync */

/* seek */
#define THINK_DB_SEEK_SET	0		/* from first record */
#define THINK_DB_SEEK_CUR	1		/* from current record */
#define THINK_DB_SEEK_END	2		/* from last record */

/* field type */
#define THINK_DB_CHAR		'C'		/* 1 bytes */
#define THINK_DB_SHORT		'S'		/* 2 bytes */
#define THINK_DB_INT		'I'		/* 4 bytes */
#define THINK_DB_LONG		'L'		/* 8 bytes */
#define THINK_DB_FLOAT		'F'		/* 4 bytes */
#define THINK_DB_DOUBLE		'D'		/* 8 bytes */
#define THINK_DB_MASK_TYPE	0xFF		/* field type mask */

/* flags */
#define THINK_DB_NOT_EMPTY	0x0100		/* field value not empty */

#define THINK_DB_EOF		-1		/* eof */

/* db field */
struct __think_db_field {
	char name[11];				/* field name */
	char type;				/* field type */
	unsigned int length;			/* field length */
	unsigned int offset;			/* field offset */
};
typedef struct __think_db_field THINK_DB_FIELD;

/* db handle */
struct __think_db {
	THINK_FILE *file;			/* db file */
	int flags;				/* open flags */
	int cursor;				/* cursor */
	char *buffer;				/* buffer */

	char last_modify_date[11];		/* last modify date: yyyy-mm-dd */
	unsigned int record_count;		/* record count */
	unsigned short head_length;		/* head length */
	unsigned short record_length;		/* record length */
	unsigned int field_count;		/* field count */
	THINK_DB_FIELD *field_array;		/* field array */
};
typedef struct __think_db THINK_DB;

/* think_db_open */
THINK_DB *think_db_open(const char *pathname,int flags,THINK_DB_FIELD *fieldarray,unsigned int fieldcount);
THINK_DB *think_db_openx(const char *pathname,int flags,const char *conffile);

/* think_db_fetch */
int think_db_fetch(THINK_DB *db);

/* think_db_getfield */
int think_db_getfield(THINK_DB *db,unsigned int no,void *value,unsigned int size,int flags);

/* think_db_getfieldbyname */
int think_db_getfieldbyname(THINK_DB *db,const char *name,void *value,unsigned int size,int flags);

/* think_db_new */
void think_db_new(THINK_DB *db);

/* think_db_putfield */
int think_db_putfield(THINK_DB *db,unsigned int no,const void *value,unsigned int length,int flags);

/* think_db_putfieldbyname */
int think_db_putfieldbyname(THINK_DB *db,const char *name,const void *value,unsigned int length,int flags);

/* think_db_insert */
int think_db_insert(THINK_DB *db);

/* think_db_seek */
int think_db_seek(THINK_DB *db,int offset,int whence);

/* think_db_sync */
int think_db_sync(THINK_DB *db);

/* think_db_eof */
int think_db_eof(THINK_DB *db);

/* think_db_close */
int think_db_close(THINK_DB *db);

/* C++ */
#ifdef __cplusplus
}
#endif

#endif	/* __THINK_DB_H__ */
