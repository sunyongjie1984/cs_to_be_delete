/*
 * think_utility.h: Think Utility Interface
 * version: 1.0
 * OS: AIX,HP-UX,Solaris,FreeBSD,Linux,Mac OS X,Windows
 * author: luojian(enigma1983@qq.com)
 * history:
 * 2008-11-07	1.0 released
 *
 */

#ifndef __THINK_UTILITY_H__
#define __THINK_UTILITY_H__

#include "think_os.h"

/* C++ */
#ifdef __cplusplus
extern "C" {
#endif

#ifdef __THINK_WINDOWS__
extern int opterr,optind,optopt;
extern char *optarg;
int getopt(int argc,char *argv[],const char *ostr);
#define R_OK        4       /* Test for read permission */
#define W_OK        2       /* Test for write permission */
#define X_OK        1       /* Test for execute (search) permission */
#define F_OK        0       /* Test for existence of file */
#define atoll atol
#define think_mkdir(path,mode) mkdir(path)
#define SIGPIPE 0
#else
#define atoll(s) strtoll(s,(char **)NULL,10)
#define think_mkdir(path,mode) mkdir(path,mode)
#endif	/* __THINK_WINDOWS__ */

int think_bin_to_hex(char *dest,const char *src,int len);
int think_bin_to_bcd(char *dest,const char *src,int len);
int think_hex_to_bin(char *dest,const char *src,int len);
int think_bcd_to_bin(char *dest,const char *src,int len);
int think_hextobin(char *dest,const char *src);
int think_bcdtobin(char *dest,const char *src);
int think_bintohex(char *dest,char src);
int think_bintobcd(char *dest,char src);
int think_inttohex(int bin);
int think_inttobcd(int bin);
int think_hextoint(int hex);
int think_bcdtoint(int hex);
int think_printbin(const char *buf,const int len,int linesize);

char *think_strtrim(char *str);
char *think_strinsert(char *srcstr,int pos,char *insstr);
char *think_chrinsert(char *srcstr,int pos,char insstr);
char *think_strreplace(char *srcstr,char *pattern,char *repstr);
char *think_chrreplace(char *srcstr,char pattern,char repstr);
char *think_strdelete(char *srcstr,const char *pattern);
char *think_chrdelete(char *srcstr,char delchr);
int think_strfind(const char *str,const char *pattern,int index);
int think_chrfind(const char *str,char chr,int index);
int think_chrstat(const char *str,char ch);
int think_strstat(const char *str,const char *pattern);

int think_strgetfield(const char *str,char sepchr,int index,char *value,unsigned int size);

int think_bitset(char *bitmap,int bit);
int think_bittest(const char *bitmap,int bit);
int think_bitclear(char *bitmap,int bit);

#define THINK_TIME_SUNDAY	0
#define THINK_TIME_MONDAY	1
#define THINK_TIME_TUESDAY	2
#define THINK_TIME_WEDNESDAY	3
#define THINK_TIME_THURSDAY	4
#define THINK_TIME_FRIDAY	5
#define THINK_TIME_SATURDAY	6

struct _think_time {
	unsigned int year;
	unsigned int month;
	unsigned int day;
	unsigned int week;
	unsigned int hour;
	unsigned int minute;
	unsigned int second;
	unsigned int msecond;
};
typedef struct _think_time think_time;
int think_gettime(think_time *t);
int think_sleep(unsigned int t); /* mil sleep */

#define THINK_OPT_CHAR		'C'		/* 1 bytes */
#define THINK_OPT_SHORT		'S'		/* 2 bytes */
#define THINK_OPT_INT		'I'		/* 4 bytes */
#define THINK_OPT_LONG		'L'		/* 8 bytes */
#define THINK_OPT_FLOAT		'F'		/* 4 bytes */
#define THINK_OPT_DOUBLE	'D'		/* 8 bytes */
#define THINK_OPT_MASK_TYPE	0xFF		/* type mask */

#define THINK_OPT_ARG			0x0100
#define THINK_OPT_NOT_IGNORE		0x0200
#define THINK_OPT_NOT_EMPTY		0x0400

struct __think_optarray {
	char opt;
	void *value;
	unsigned int size;
	int flags;
	int *exists;			/* 0:not exists,1:exists */
};
typedef struct __think_optarray THINK_OPTARRAY;
int think_getopt(int argc,char *argv[],char opt,void *value,unsigned int size,int flags);
int think_getopts(int argc,char *argv[],THINK_OPTARRAY *optarray,unsigned int optcount);

#define THINK_ENV_CHAR		'C'		/* 1 bytes */
#define THINK_ENV_SHORT		'S'		/* 2 bytes */
#define THINK_ENV_INT		'I'		/* 4 bytes */
#define THINK_ENV_LONG		'L'		/* 8 bytes */
#define THINK_ENV_FLOAT		'F'		/* 4 bytes */
#define THINK_ENV_DOUBLE	'D'		/* 8 bytes */
#define THINK_ENV_MASK_TYPE	0xFF		/* type mask */

#define THINK_ENV_NOT_IGNORE		0x0100
#define THINK_ENV_NOT_EMPTY		0x0200

struct __think_envarray {
	const char *name;
	void *value;
	unsigned int size;
	int flags;
	int *exists;
};
typedef struct __think_envarray THINK_ENVARRAY;
int think_getenv(const char *name,void *value,int size,int flags);
int think_getenvs(THINK_ENVARRAY *envarray,unsigned int envcount);

int automkdir(const char *path,int mode);

/* C++ */
#ifdef __cplusplus
}
#endif

#endif	/* __THINK_UTILITY_H__ */
