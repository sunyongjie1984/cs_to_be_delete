/*
 * think_netcenter.h: Think NetCenter Interface
 * version: 1.0
 * OS: AIX,HP-UX,Solaris,FreeBSD,Linux,Mac OS X,Windows
 * author: luojian(enigma1983@qq.com)
 * history:
 * 2008-11-07	1.0 released
 *
 */

#ifndef __THINK_NETCENTER_H__
#define __THINK_NETCENTER_H__

#include "think_os.h"
#include "think_net.h"

/* C++ */
#ifdef __cplusplus
extern "C" {
#endif

#define THINK_NETCENTER_BUFSIZE	8192

#define THINK_NETCENTER_ACCEPT 			0x00000001	/* accept */
#define THINK_NETCENTER_DISCONNECTED	0x00000002	/* disconnected */
#define THINK_NETCENTER_ERROR			0x00000004	/* error */
#define THINK_NETCENTER_DATARECVED		0x00000008	/* datarecved */

struct __think_netcenter_buflist {
	char *buf;
	unsigned int pos;
	unsigned int len;
	struct __think_netcenter_buflist *prior;
	struct __think_netcenter_buflist *next;
};
typedef struct __think_netcenter_buflist THINK_NETCENTER_BUFLIST;

struct __think_netcenter_net;
typedef struct __think_netcenter_net THINK_NETCENTER_NET;
typedef void (*THINK_NETCENTER_NETHANDLE)(THINK_NETCENTER_NET *,int);
struct __think_netcenter_net {
	THINK_NET *net;
	THINK_NETCENTER_BUFLIST *rlist;
	THINK_NETCENTER_BUFLIST *wlist;
	unsigned int nrbytes;
	unsigned int nwbytes;
	THINK_NETCENTER_NETHANDLE nethandle;
};

struct __think_netcenter_netlist{
	THINK_NETCENTER_NET *net;
	struct __think_netcenter_netlist *prior;
	struct __think_netcenter_netlist *next;
};
typedef struct __think_netcenter_netlist THINK_NETCENTER_NETLIST;

struct __think_netcenter{
	THINK_NETCENTER_NETLIST *netlist;
	THINK_NETLIST *nlist;
};
typedef struct __think_netcenter THINK_NETCENTER;

int think_netcenter_recvto(THINK_NETCENTER_NET *net);
int think_netcenter_send(THINK_NETCENTER_NET *net,const void *buf,unsigned int len);
int think_netcenter_recv(THINK_NETCENTER_NET *net,void *buf,unsigned int siz);
int think_netcenter_sendfrom(THINK_NETCENTER_NET *net);
int think_netcenter_peek(THINK_NETCENTER_NET *net,void *buf,unsigned int siz);
int think_netcenter_select(THINK_NETCENTER *netcenter,int timeout);

THINK_NETCENTER *think_netcenter_new();
int think_netcenter_idle(THINK_NETCENTER *netcenter,int timeout);
int think_netcenter_free(THINK_NETCENTER *netcenter);

THINK_NETCENTER_NETLIST *think_netcenter_netadd(THINK_NETCENTER *netcenter,THINK_NET *net,THINK_NETCENTER_NETHANDLE nethandle);
int think_netcenter_netdel(THINK_NETCENTER *netcenter,THINK_NET *net);
THINK_NETCENTER_NETLIST *think_netcenter_netfind(THINK_NETCENTER *netcenter,THINK_NET *net);
int think_netcenter_netclean(THINK_NETCENTER *netcenter);

int think_netcenter_ismsgok(THINK_NETCENTER_NET *net);
int think_netcenter_recvmsg(THINK_NETCENTER_NET *net,void *buf,unsigned int siz);
int think_netcenter_sendmsg(THINK_NETCENTER_NET *net,const void *buf,unsigned int len);

/* C++ */
#ifdef __cplusplus
}
#endif

#endif	/* __THINK_NETCENTER_H__ */
