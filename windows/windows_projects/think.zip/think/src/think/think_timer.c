#include "think_error.h"
#include "think_utility.h"
#include "think_timer.h"

THINK_TIMER *think_timernew(THINK_TIMERHANDLE timerhandle,unsigned int timeout)
{
	THINK_TIMER *timer;
	think_time t;
	unsigned int timenow;

	if((timer=malloc(sizeof(THINK_TIMER)))==NULL){
		think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return NULL;
	}
	memset(timer,0x00,sizeof(THINK_TIMER));
	timer->timeout=timeout;
	timer->timerhandle=timerhandle;
	think_gettime(&t);
	timenow=(t.hour*3600+t.minute*60+t.second)*1000+t.msecond;
	timer->lasttime=timenow;

	return timer;
}

int think_timerfree(THINK_TIMER *timer)
{
	free(timer);

	return 0;
}

int think_timerrefresh(THINK_TIMER *timer)
{
	think_time t;
	unsigned int timenow;

	think_gettime(&t);
	timenow=(t.hour*3600+t.minute*60+t.second)*1000+t.msecond;
	if(timenow-timer->lasttime>timer->timeout)
		timer->timerhandle(timer);
	timer->lasttime=timenow;

	return 0;
}
int think_timerreset(THINK_TIMER *timer)
{
	think_time t;
	unsigned int timenow;
	
	think_gettime(&t);
	timenow=(t.hour*3600+t.minute*60+t.second)*1000+t.msecond;
	timer->lasttime=timenow;

	return 0;
}
int think_timerlist_add(THINK_TIMERLIST **timerlist,THINK_TIMER *timer)
{
	THINK_TIMERLIST *head,*tail;
	THINK_TIMERLIST *p;
	
	if((p=malloc(sizeof(THINK_TIMERLIST)))==NULL){
		think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}
	p->timer=timer;
	p->prior=NULL;
	p->next=NULL;
	if(*timerlist==NULL){
		p->prior=p;
		p->next=p;
		*timerlist=p;
	}else{
		head=*timerlist;
		tail=(*timerlist)->prior;
		p->prior=tail;
		tail->next=p;
		p->next=head;
		head->prior=p;
	}
	
	return 0;
}

int think_timerlist_del(THINK_TIMERLIST **timerlist,THINK_TIMER *timer)
{
	THINK_TIMERLIST *p;
	
	if((p=think_timerlist_find(*timerlist,timer))==NULL){
		think_error(0,"[%s]:net not found.",__func__);
		return -1;
	}
	p->timer=NULL;
	
	return 0;
}

THINK_TIMERLIST *think_timerlist_find(THINK_TIMERLIST *timerlist,THINK_TIMER *timer)
{
	THINK_TIMERLIST *p;
	
	if(timerlist==NULL)
		return NULL;
	p=timerlist;
	do{
		if(p->timer==timer)
			return p;
		p=p->next;
	}while(p!=timerlist);
	
	return NULL;
}
int think_timerlist_free(THINK_TIMERLIST **timerlist)
{
	THINK_TIMERLIST *p;

	if(*timerlist==NULL)
		return 0;
	p=*timerlist;
	do{
		p->timer=NULL;
		p=p->next;
	}while(p!=*timerlist);
	think_timerlist_clean(timerlist);

	return 0;
}
int think_timerlist_clean(THINK_TIMERLIST **timerlist)
{
	THINK_TIMERLIST *next,*prior;
	THINK_TIMERLIST *p;
	
	if(*timerlist==NULL)
		return 0;
	/* timerclean */
	p=*timerlist;
	do{
		if(p==*timerlist && p->timer==NULL){
			if(p==p->next){
				*timerlist=NULL;
				free(p);
				return 0;
			}else{
				*timerlist=p->next;
				next=p->next;
				prior=p->prior;
				prior->next=next;
				next->prior=prior;				
				free(p);
				p=*timerlist;
				continue;
			}
		}
		if(p->timer!=NULL){
			p=p->next;
			if(p==*timerlist)
				break;
			continue;
		}
		next=p->next;
		prior=p->prior;
		prior->next=next;
		next->prior=prior;
		free(p);
		p=next;
		if(p==*timerlist)
			break;
	}while(1);
	
	return 0;
}

int think_timerlist_idle(THINK_TIMERLIST **timerlist)
{
	THINK_TIMERLIST *p;
	THINK_TIMER *timer;
	think_time t;
	unsigned int timenow,n;
	
	think_timerlist_clean(timerlist);
	if(*timerlist==NULL)
		return 0;

	think_gettime(&t);
	timenow=(t.hour*3600+t.minute*60+t.second)*1000+t.msecond;

	p=*timerlist;
	n=0;
	do{
		timer=p->timer;
		if(timenow-timer->lasttime>timer->timeout){
			timer->timerhandle(timer);
			timer->lasttime=timenow;
			n++;
		}
		p=p->next;
	}while(p!=*timerlist);

	return n;
}
