#include "think_error.h"
#include "think_thread.h"

#ifdef __THINK_WINDOWS__ /* Windows */
int WINAPI think_os_threadroutine(void *arg)
{
	THINK_THREADARG *threadarg;

	threadarg=arg;
	threadarg->routine(threadarg->arg);
	free(arg);

	return 0;
}
#else /* UNIX */
void *think_os_threadroutine(void *arg)
{
	THINK_THREADARG *threadarg;

	threadarg=arg;
#if defined(__THINK_AIX__) || defined(__THINK_HPUX__)
	if(threadarg->flags & THINK_THREAD_SUSPEND)
		pthread_suspend(pthread_self());
#endif
	threadarg->routine(threadarg->arg);
	free(arg);

	return NULL;
}
#endif

THINK_THREAD *think_threadcreate(THINK_THREADROUTINE routine,void *arg,int flags)
{
	THINK_THREAD *thread;
	THINK_THREADARG *threadarg;
#ifdef __THINK_WINDOWS__
	int oflags=0;
#endif

	if((thread=malloc(sizeof(THINK_THREAD)))==NULL){
		think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return NULL;
	}

	if((threadarg=malloc(sizeof(THINK_THREADARG)))==NULL){
		think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		free(thread);
		return NULL;
	}
	threadarg->routine=routine;
	threadarg->arg=arg;
	threadarg->flags=flags;
#ifdef __THINK_WINDOWS__ /* Windows */
	if(flags & THINK_THREAD_SUSPEND)
		oflags|=CREATE_SUSPENDED;
	if((thread->handle=CreateThread(NULL,0,think_os_threadroutine,threadarg,oflags,&thread->threadid))==NULL){
		think_error(0,"[%s]:CreateThread error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		free(threadarg);
		free(thread);
		return NULL;
	}
#else /* UNIX */
	if(pthread_create(&thread->thread,NULL,think_os_threadroutine,threadarg)<0){
		think_error(0,"[%s]:pthread_create error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		free(threadarg);
		free(thread);
		return NULL;
	}
	thread->threadid=(int)thread->thread;
#endif

	return thread;
}
int think_threadid()
{
	int threadid;

#ifdef __THINK_WINDOWS__ /* Windows */
	threadid=GetCurrentThreadId();
#else /* UNIX */
	threadid=(int)pthread_self();
#endif

	return threadid;
}
int think_threadexit(int exitcode)
{
#ifdef __THINK_WINDOWS__ /* Windows */
	ExitThread(exitcode);
#else /* UNIX */
	pthread_exit((void *)exitcode);
#endif

	return 0;
}
int think_threadsuspend(THINK_THREAD *thread)
{
#ifdef __THINK_WINDOWS__ /* Windows */
	if(SuspendThread(thread->handle)<0){
		think_error(0,"[%s]:SuspendThread error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}
#else /* UNIX */
#if defined(__THINK_AIX__) || defined(__THINK_HPUX__)
	if(pthread_suspend(thread->thread)<0){
		think_error(0,"[%s]:pthread_suspend error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}
#endif
#endif /* Windows */
	
	return 0;
}
int think_threadcontinue(THINK_THREAD *thread)
{
#ifdef __THINK_WINDOWS__ /* Windows */
	if(ResumeThread(thread->handle)<0){
		think_error(0,"[%s]:ResumeThread error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}
#else /* UNIX */
#if defined(__THINK_AIX__) || defined(__THINK_HPUX__)
	if(pthread_continue(thread->thread)<0){
		think_error(0,"[%s]:pthread_continue error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}
#endif
#endif /* Windows */
	
	return 0;
}
int think_threadcancel(THINK_THREAD *thread)
{
#ifdef __THINK_WINDOWS__ /* Windows */
	if(TerminateThread(thread->handle,0)==0){
		think_error(0,"[%s]:TerminateThread error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}
#else /* UNIX */
	if(pthread_cancel(thread->thread)<0){
		think_error(0,"[%s]:pthread_cancel error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}
#endif
	free(thread);

	return 0;
}
int think_threadjoin(THINK_THREAD *thread,int *exitcode,int timeout)
{
#ifdef __THINK_WINDOWS__ /* Windows */
	int r;

	if(timeout<0)
		timeout=INFINITE;
	if((r=WaitForSingleObject(thread->handle,timeout))!=WAIT_OBJECT_0){
		if(r==WAIT_TIMEOUT)
			return 0;
		think_error(0,"[%s]:WaitForSingleObject error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}
	if(exitcode)
		GetExitCodeThread(thread->handle,exitcode);
#else /* UNIX */
	if(pthread_join(thread->thread,(void **)exitcode)<0){
		think_error(0,"[%s]:pthread_join error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}
#endif
	free(thread);

	return 1;
}
int think_thread_detach(THINK_THREAD *thread)
{
#ifdef __THINK_WINDOWS__ /* Windows */
#else /* UNIX */
	if(pthread_detach(thread->thread)<0){
		think_error(0,"[%s]:pthread_detach error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}
#endif
	
	return 0;
}
