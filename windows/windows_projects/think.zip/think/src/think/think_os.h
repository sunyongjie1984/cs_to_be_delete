/*
 * think_os.h: Think OS Interface
 * version: 1.0
 * OS: AIX,HP-UX,Solaris,FreeBSD,Linux,Mac OS X,Windows
 * author: luojian(enigma1983@qq.com)
 * history:
 * 2008-11-07	1.0 released
 *
 */

#ifndef __THINK_OS_H__
#define __THINK_OS_H__

/* C++ */
#ifdef __cplusplus
extern "C" {
#endif

/* Softwares */

#ifdef _AIX	/* IBM AIX OS */
#define __THINK_AIX__
#endif

#ifdef __hpux	/* HP HP-UX OS */
#define __THINK_HPUX__
#endif

#ifdef __SVR4	/* Sun Solaris OS */
#define __THINK_SOLARIS__
#endif

#ifdef __FreeBSD__	/* Berkeley FreeBSD OS */
#define __THINK_FREEBSD__
#endif

#ifdef __linux	/* GNU Linux OS */
#define __THINK_LINUX__
#endif

#ifdef __APPLE__	/* Apple Mac OS X */
#define __THINK_APPLE__
#endif

#ifdef _WIN32	/* Microsoft Windows OS */
#define __THINK_WINDOWS__
#endif

/* Hardwares */
#ifdef __sparc	/* Sun Sparc Machine */
#define __THINK_SPARC__
#endif

#ifdef __ppc__ /* IBM PowerPC */
#define __THINK_POWERPC__
#endif

#if defined(__THINK_AIX__) || defined(__THINK_HPUX__) || defined(__THINK_SOLARIS__) || defined(__THINK_FREEBSD__) || defined(__THINK_LINUX__) || defined(__THINK_APPLE__)
#define __THINK_UNIX__
#endif

#if defined(__THINK_WINDOWS__)	/* windows */

#if _MSC_VER > 1000
#pragma once
#endif

#ifdef _WIN32
#pragma warning (disable:4786)
#pragma warning (disable:4018)
#pragma warning (disable:4761)
#pragma warning (disable:4244)
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <signal.h>
#define WIN32_LEAN_AND_MEAN	/* for socket api */
#include <windows.h>
#include <process.h>
#include <direct.h>
#include <io.h>
#include <winsock2.h>

typedef char THINK_CHAR;
typedef unsigned char THINK_UCHAR;
typedef short THINK_SHORT;
typedef unsigned short THINK_USHORT;
typedef int THINK_INT;
typedef unsigned int THINK_UINT;
typedef __int64 THINK_LONG;
typedef unsigned __int64 THINK_ULONG;
typedef float THINK_FLOAT;
typedef double THINK_DOUBLE;

#define __func__ "__func__"
#define snprintf _snprintf
#define vsnprintf _vsnprintf
#define bzero(address,size) memset(address,0x00,size)

#elif defined(__THINK_UNIX__)	/* unix */

/* hp-ux */
#ifdef __THINK_HPUX__
#define _XOPEN_SOURCE_EXTENDED 1
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <signal.h>

#include <strings.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <poll.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <pthread.h>

#include <sys/msg.h>
#include <sys/sem.h>
#include <sys/shm.h>

typedef char THINK_CHAR;
typedef unsigned char THINK_UCHAR;
typedef short THINK_SHORT;
typedef unsigned short THINK_USHORT;
typedef int THINK_INT;
typedef unsigned int THINK_UINT;
typedef long long THINK_LONG;
typedef unsigned long long THINK_ULONG;
typedef float THINK_FLOAT;
typedef double THINK_DOUBLE;

#else	/* Unknown OS */
#error Operation System not supported!
#endif	/* __THINK_WINDOWS__ */


/* byte order */

#if defined(__THINK_SPARC__) || defined(__THINK_AIX__) || defined(__THINK_HPUX__) || defined(__THINK_POWERPC__)
#define __THINK_BIG_ENDIAN__
#else
#define __THINK_LITTLE_ENDIAN__
#endif

#ifdef __THINK_LITTLE_ENDIAN__
#define think_htol2(s) (s)
#define think_htol4(i) (i)
#define think_htol8(l) (l)
#define think_ltoh2(s) (s)
#define think_ltoh4(i) (i)
#define think_ltoh8(l) (l)
#else
#define think_htol2(s) ((((s)&0x00FFU)<<8)+(((s)&0xFF00U)>>8))
#define think_htol4(i) ((((i)&0x000000FFU)<<24)+(((i)&0xFF000000U)>>24)\
		+(((i)&0x0000FF00U)<<8)+(((i)&0x00FF0000U)>>8))
#define think_htol8(l) ((((l)&0x00000000000000FFULL)<<56)+(((l)&0xFF00000000000000ULL)>>56)\
		+(((l)&0x000000000000FF00ULL)<<40)+(((l)&0x00FF000000000000ULL)>>40)\
		+(((l)&0x0000000000FF0000ULL)<<24)+(((l)&0x0000FF0000000000ULL)>>24)\
		+(((l)&0x00000000FF000000ULL)<<8)+(((l)&0x0000000FF0000000ULL)>>8))
#define think_ltoh2(s) ((((s)&0x00FFU)<<8)+(((s)&0xFF00U)>>8))
#define think_ltoh4(i) ((((i)&0x000000FFU)<<24)+(((i)&0xFF000000U)>>24)\
		+(((i)&0x0000FF00U)<<8)+(((i)&0x00FF0000U)>>8))
#define think_ltoh8(l) ((((l)&0x00000000000000FFULL)<<56)+(((l)&0xFF00000000000000ULL)>>56)\
		+(((l)&0x000000000000FF00ULL)<<40)+(((l)&0x00FF000000000000ULL)>>40)\
		+(((l)&0x0000000000FF0000ULL)<<24)+(((l)&0x0000FF0000000000ULL)>>24)\
		+(((l)&0x00000000FF000000ULL)<<8)+(((l)&0x0000000FF0000000ULL)>>8))
#endif

#ifdef __THINK_BIG_ENDIAN__
#define think_htob2(s) (s)
#define think_htob4(i) (i)
#define think_htob8(l) (l)
#define think_btoh2(s) (s)
#define think_btoh4(i) (i)
#define think_btoh8(l) (l)
#else
#define think_htob2(s) ((((s)&0x00FFU)<<8)+(((s)&0xFF00U)>>8))
#define think_htob4(i) ((((i)&0x000000FFU)<<24)+(((i)&0xFF000000U)>>24)\
		+(((i)&0x0000FF00U)<<8)+(((i)&0x00FF0000U)>>8))
#define think_htob8(l) ((((l)&0x00000000000000FFULL)<<56)+(((l)&0xFF00000000000000ULL)>>56)\
		+(((l)&0x000000000000FF00ULL)<<40)+(((l)&0x00FF000000000000ULL)>>40)\
		+(((l)&0x0000000000FF0000ULL)<<24)+(((l)&0x0000FF0000000000ULL)>>24)\
		+(((l)&0x00000000FF000000ULL)<<8)+(((l)&0x0000000FF0000000ULL)>>8))
#define think_btoh2(s) ((((s)&0x00FFU)<<8)+(((s)&0xFF00U)>>8))
#define think_btoh4(i) ((((i)&0x000000FFU)<<24)+(((i)&0xFF000000U)>>24)\
		+(((i)&0x0000FF00U)<<8)+(((i)&0x00FF0000U)>>8))
#define think_btoh8(l) ((((l)&0x00000000000000FFULL)<<56)+(((l)&0xFF00000000000000ULL)>>56)\
		+(((l)&0x000000000000FF00ULL)<<40)+(((l)&0x00FF000000000000ULL)>>40)\
		+(((l)&0x0000000000FF0000ULL)<<24)+(((l)&0x0000FF0000000000ULL)>>24)\
		+(((l)&0x00000000FF000000ULL)<<8)+(((l)&0x0000000FF0000000ULL)>>8))
#endif

/* C++ */
#ifdef __cplusplus
}
#endif

#endif /* __THINK_OS_H__ */
