#include "think_error.h"
#include "think_file.h"

THINK_FILE *think_fileopen(const char *pathname,int flags,int mode)
{
	THINK_FILE *file;
	int oflags;

	/* malloc file descriptor */
	if((file=malloc(sizeof(THINK_FILE)))==NULL){
		think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return NULL;
	}
	bzero(file,sizeof(THINK_FILE));

	/* open flags */
	oflags=0;
	if(flags & THINK_FILE_CREAT)
		oflags|=O_CREAT;
	if(flags & THINK_FILE_EXCL)
		oflags|=O_EXCL;
	if(flags & THINK_FILE_TRUNC)
		oflags|=O_TRUNC;
	if(flags & THINK_FILE_RDONLY)
		oflags|=O_RDONLY;
	if(flags & THINK_FILE_WRONLY)
		oflags|=O_WRONLY;
	if(flags & THINK_FILE_RDWR)
		oflags|=O_RDWR;
	if(flags & THINK_FILE_APPEND)
		oflags|=O_APPEND;
	if(flags & THINK_FILE_BINARY)
		oflags|=O_BINARY;
	
	/* open file */
	if((file->fd=open(pathname,oflags,mode))<0){
		think_error(0,"[%s]:open failed.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		free(file);
		return NULL;
	}

	return file;
}
int think_fileread(THINK_FILE *file,void *buffer,unsigned int nbytes)
{
	int n;

	if((n=read(file->fd,buffer,nbytes))<0){
		think_error(0,"[%s]:read failed.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}

	return n;
}
int think_filewrite(THINK_FILE *file,const void *buffer,unsigned int nbytes)
{
	int n;

	if((n=write(file->fd,buffer,nbytes))<0){
		think_error(0,"[%s]:write failed.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}

	return n;
}
int think_fileseek(THINK_FILE *file,int offset,int whence)
{
	int pos;

	if((pos=lseek(file->fd,offset,whence))<0){
		think_error(0,"[%s]:lseek failed.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}

	return pos;
}
int think_fileclose(THINK_FILE *file)
{
	close(file->fd);
	free(file);

	return 0;
}
