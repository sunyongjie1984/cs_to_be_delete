#include "think_error.h"
#include "think_net.h"

int think_netstart(void)
{
#ifdef __THINK_WINDOWS__
	WSADATA data;
	
	if(WSAStartup(MAKEWORD(2,2),&data)<0){
		think_error(0,"[%s]:WSAStartup error.[%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
		return -1;
	}
#endif
	
	return 0;
}

int think_netstop(void)
{
#ifdef __THINK_WINDOWS__
	if(WSACleanup()<0){
		think_error(0,"[%s]:WSACleanup error.[%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
		return -1;
	}
#endif

	return 0;
}

THINK_NET *think_netconnect(const char *ip,unsigned short port)
{
	struct sockaddr_in servaddr;
	int sockfd;
	THINK_NET *net;

	bzero(&servaddr,sizeof(struct sockaddr_in));
	servaddr.sin_family=AF_INET;
	servaddr.sin_port=htons(port);
	if((servaddr.sin_addr.s_addr=inet_addr(ip))==INADDR_NONE){
		think_error(0,"[%s]:inet_addr error.[%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
		return NULL;
	}
	if((sockfd=socket(AF_INET,SOCK_STREAM,0))<0){
		think_error(0,"[%s]:socket create error.[%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
		return NULL;
	}
	if(connect(sockfd,(struct sockaddr *)&servaddr,sizeof(struct sockaddr_in))<0){
		think_error(0,"[%s]:connect error.[%d:%s][%s:%d]",__func__,think_socketerrno,think_strerror(think_socketerrno),ip,port);
		socketclose(sockfd);
		return NULL;
	}
	if((net=malloc(sizeof(THINK_NET)))==NULL){
		think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		socketclose(sockfd);
		return NULL;
	}
	memset(net,0x00,sizeof(THINK_NET));
	net->sockfd=sockfd;
	snprintf(net->ip,sizeof(net->ip),"%s",ip);
	net->port=port;

	return net;
}

THINK_NET *think_netlisten(const char *ip,unsigned short port)
{
	struct sockaddr_in servaddr;
	int sockfd;
	struct linger so_linger;
	int option;
	THINK_NET *net;

	bzero(&servaddr,sizeof(struct sockaddr_in));
	servaddr.sin_family=AF_INET;
	servaddr.sin_port=htons(port);
	if(strcmp(ip,"*")==0){
		servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
	}else{
		if((servaddr.sin_addr.s_addr=inet_addr(ip))==INADDR_NONE){
			think_error(0,"[%s]:inet_addr error.[%d:%s][%s:%d]",__func__,think_socketerrno,think_strerror(think_socketerrno),ip,port);
			return NULL;
		}
	}
	if((sockfd=socket(AF_INET,SOCK_STREAM,0))<0){
		think_error(0,"[%s]:socket create error.[%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
		return NULL;
	}
	so_linger.l_onoff=1;
	so_linger.l_linger=0;
	if(setsockopt(sockfd,SOL_SOCKET,SO_LINGER,(void *)&so_linger,sizeof(so_linger))<0){
		think_error(0,"[%s]:setsockopt error.[%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
		socketclose(sockfd);
		return NULL;
	}
	option=1;
	if(setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,(void *)&option,sizeof(option))<0){
		think_error(0,"[%s]:setsockopt error.[%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
		socketclose(sockfd);
		return NULL;
	}
	option=1;
	if(setsockopt(sockfd,SOL_SOCKET,SO_KEEPALIVE,(void *)&option,sizeof(option))<0){
		think_error(0,"[%s]:setsockopt error.[%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
		socketclose(sockfd);
		return NULL;
	}
	if(bind(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr))<0){
		think_error(0,"[%s]:bind error.[%d:%s][%s:%d]",__func__,think_socketerrno,think_strerror(think_socketerrno),ip,port);
		socketclose(sockfd);
		return NULL;
	}
	if(listen(sockfd,5)<0){
		think_error(0,"[%s]:listen error.[%d:%s][%s:%d]",__func__,think_socketerrno,think_strerror(think_socketerrno),ip,port);
		socketclose(sockfd);
		return NULL;
	}
	if((net=malloc(sizeof(THINK_NET)))==NULL){
		think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		socketclose(sockfd);
		return NULL;
	}
	memset(net,0x00,sizeof(THINK_NET));
	net->sockfd=sockfd;
	snprintf(net->ip,sizeof(net->ip),"%s",ip);
	net->port=port;
	net->flags|=THINK_NET_LISTENER;

	return net;
}

THINK_NET *think_netaccept(THINK_NET *net)
{
	struct sockaddr_in addr;
	socklen_t addrlen;
	int sockfd;
	char *p;
	THINK_NET *client;

	if(!(net->flags & THINK_NET_LISTENER)){
		think_error(0,"[%s]:net is not a listener.",__func__);
		return NULL;
	}
	addrlen=sizeof(addr);
	if((sockfd=accept(net->sockfd,(struct sockaddr *)&addr,&addrlen))<0){
		think_error(0,"[%s]:accept error.[%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
		return NULL;
	}
	if((p=inet_ntoa(addr.sin_addr))==NULL){
		think_error(0,"[%s]:inet_ntoa error.[%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
		return NULL;
	}
	if((client=malloc(sizeof(THINK_NET)))==NULL){
		think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		socketclose(sockfd);
		return NULL;
	}
	memset(client,0x00,sizeof(THINK_NET));
	client->sockfd=sockfd;
	snprintf(client->ip,sizeof(client->ip),"%s",p);
	client->port=ntohs(addr.sin_port);

	return client;
}

int think_netrecv(THINK_NET *net,void *buf,unsigned int siz,int flags)
{
	int n,nbytes;

	for(nbytes=0;siz>0;nbytes+=n,siz-=n){
		if((n=recv(net->sockfd,(char *)buf+nbytes,siz,0))<=0){
			think_error(0,"[%s]:read error![%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
			return -1;
		}
		if(!(flags & THINK_NET_WAIT))
			return n;
	}

	return nbytes;
}

int think_netsend(THINK_NET *net,const void *buf,unsigned int len,int flags)
{
	int n,nbytes;

	for(nbytes=0;len>0;nbytes+=n,len-=n){
		if((n=send(net->sockfd,(char *)buf+nbytes,len,0))<=0){
			think_error(0,"[%s]:write error![%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
			return -1;
		}
		if(!(flags & THINK_NET_WAIT))
			return n;
	}

	return nbytes;
}

int think_netlist_add(THINK_NETLIST **netlist,THINK_NET *net)
{
	THINK_NETLIST *head,*tail;
	THINK_NETLIST *p;

	if((p=malloc(sizeof(THINK_NETLIST)))==NULL){
		think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return -1;
	}
	memset(p,0x00,sizeof(THINK_NETLIST));
	p->net=net;
	p->prior=NULL;
	p->next=NULL;
	if(*netlist==NULL){
		p->prior=p;
		p->next=p;
		*netlist=p;
	}else{
		head=*netlist;
		tail=(*netlist)->prior;
		p->prior=tail;
		tail->next=p;
		p->next=head;
		head->prior=p;
	}

	return 0;
}

int think_netlist_del(THINK_NETLIST **netlist,THINK_NET *net)
{
	THINK_NETLIST *p;

	if((p=think_netlist_find(*netlist,net))==NULL){
		think_error(0,"[%s]:net not found.",__func__);
		return -1;
	}
	p->net=NULL;

	return 0;
}

THINK_NETLIST *think_netlist_find(THINK_NETLIST *netlist,THINK_NET *net)
{
	THINK_NETLIST *p;
	
	if(netlist==NULL)
		return NULL;
	p=netlist;
	do{
		if(p->net==net)
			return p;
		p=p->next;
	}while(p!=netlist);

	return NULL;
}

int think_netlist_clean(THINK_NETLIST **netlist)
{
	THINK_NETLIST *next,*prior;
	THINK_NETLIST *p;

	if(*netlist==NULL)
		return 0;
	/* netclean */
	p=*netlist;
	do{
		if(p==*netlist && p->net==NULL){
			if(p==p->next){
				*netlist=NULL;
				free(p);
				return 0;
			}else{
				*netlist=p->next;
				next=p->next;
				prior=p->prior;
				prior->next=next;
				next->prior=prior;				
				free(p);
				p=*netlist;
				continue;
			}
		}
		if(p->net!=NULL){
			p=p->next;
			if(p==*netlist)
				break;
			continue;
		}
		next=p->next;
		prior=p->prior;
		prior->next=next;
		next->prior=prior;
		free(p);
		p=next;
		if(p==*netlist)
			break;
	}while(1);

	return 0;
}
int think_netlist_free(THINK_NETLIST **netlist)
{
	THINK_NETLIST *p;

	if(*netlist==NULL)
		return 0;
	p=*netlist;
	do{
		p->net=NULL;
		p=p->next;
	}while(p!=*netlist);
	think_netlist_clean(netlist);

	return 0;
}
int think_netselect(THINK_NETLIST **netlist,int timeout)
{
	fd_set fdrset,fdwset,fdeset;
	int maxfd;
	THINK_NET *net;
	THINK_NETLIST *p;
	struct timeval t,*pt;
	int r;

	think_netlist_clean(netlist);
	if(*netlist==NULL)
		return 0;
	FD_ZERO(&fdrset);
	FD_ZERO(&fdwset);
	FD_ZERO(&fdeset);
	maxfd=0;
	p=*netlist;
	do{
		net=p->net;
		if(p->flags & THINK_NET_READ)
			FD_SET(net->sockfd,&fdrset);
		if(p->flags & THINK_NET_WRITE)
			FD_SET(net->sockfd,&fdwset);
		if(p->flags & THINK_NET_ERROR)
			FD_SET(net->sockfd,&fdeset);
		maxfd=net->sockfd>maxfd?net->sockfd:maxfd;
		p=p->next;
	}while(p!=*netlist);
	if(timeout<0)
		pt=NULL;
	else{
		pt=&t;
		t.tv_sec=0;
		t.tv_usec=timeout;
	}
	if((r=select(maxfd+1,&fdrset,&fdwset,&fdeset,pt))<0){
		if(think_socketerrno==EINTR)
			return 0;
		think_error(0,"[%s]:select error.[%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
		return -1;
	}
	if(r==0)
		return 0;
	p=*netlist;
	do{
		p->flags&=~THINK_NET_READ;
		p->flags&=~THINK_NET_WRITE;
		p->flags&=~THINK_NET_ERROR;
		net=p->net;
		if(FD_ISSET(net->sockfd,&fdrset))
			p->flags|=THINK_NET_READ;
		if(FD_ISSET(net->sockfd,&fdwset))
			p->flags|=THINK_NET_WRITE;
		if(FD_ISSET(net->sockfd,&fdeset))
			p->flags|=THINK_NET_ERROR;
		p=p->next;
	}while(p!=*netlist);

	return r;
}

#ifdef __THINK_UNIX__
int think_netpoll(THINK_NETLIST **netlist,int timeout)
{
	struct pollfd fdarray[1024];
	int nfds;
	THINK_NET *net;
	THINK_NETLIST *p;
	int i,j,r;
	
	think_netlist_clean(netlist);
	if(*netlist==NULL)
		return 0;
	nfds=0;
	p=*netlist;
	do{
		net=p->net;
		fdarray[nfds].fd=net->sockfd;
		if(p->flags & THINK_NET_READ)
			fdarray[nfds].events=POLLIN;
		if(p->flags & THINK_NET_WRITE)
			fdarray[nfds].events&=POLLOUT;
		if(p->flags & THINK_NET_ERROR)
			fdarray[nfds].events&=POLLERR;
		fdarray[nfds].revents=0;
		nfds++;
		p=p->next;
	}while(p!=*netlist);
	if((r=poll(fdarray,nfds,timeout))<0){
		if(think_socketerrno==EINTR)
			return 0;
		think_error(0,"[%s]:poll error.[%d:%s]",__func__,think_socketerrno,think_strerror(think_socketerrno));
		return -1;
	}
	if(r==0)
		return 0;
	p=*netlist;
	do{
		net=p->net;
		net->flags&=~THINK_NET_READ;
		net->flags&=~THINK_NET_WRITE;
		net->flags&=~THINK_NET_ERROR;
		for(i=0;i<nfds;i++){
			if(fdarray[i].fd==net->sockfd){
				if(fdarray[i].revents&POLLIN)
					net->flags|=THINK_NET_READ;
				if(fdarray[i].revents&POLLOUT)
					net->flags|=THINK_NET_WRITE;
				if(fdarray[i].revents&POLLERR)
					net->flags|=THINK_NET_ERROR;
				break;
			}
		}
		p=p->next;
	}while(p!=*netlist);

	return r;
}
#endif

int think_netclose(THINK_NET *net)
{
	socketclose(net->sockfd);
	free(net);

	return 0;
}

int think_netsendmsg(THINK_NET *net,const void *buf,unsigned int len)
{
	int t;

	t=htonl(len);
	if(think_netsend(net,&t,4,THINK_NET_WAIT)<0){
		think_errorerror();
		return -1;
	}
	if(think_netsend(net,buf,len,THINK_NET_WAIT)<0){
		think_errorerror();
		return -1;
	}

	return 0;
}

int think_netrecvmsg(THINK_NET *net,void *buf,unsigned int siz)
{
	int len;

	if(think_netrecv(net,&len,4,THINK_NET_WAIT)<0){
		think_errorerror();
		return -1;
	}
	len=ntohl(len);
	if(len>siz){
		think_error(0,"[%s]:msg too long![siz=%d][len=%d]",__func__,siz,len);
		return -1;
	}
	if(think_netrecv(net,buf,len,THINK_NET_WAIT)<0){
		think_errorerror();
		return -1;
	}

	return len;
}
