/*
 * think_file.h: Think File Interface
 * version: 1.0
 * OS: AIX,HP-UX,Solaris,FreeBSD,Linux,Mac OS X,Windows
 * author: luojian(enigma1983@qq.com)
 * history:
 * 2008-11-07	1.0 released
 *
 */

#ifndef __THINK_FILE_H__
#define __THINK_FILE_H__

#include "think_os.h"

/* C++ */
#ifdef __cplusplus
extern "C" {
#endif

#ifdef __THINK_WINDOWS__
#define O_RDONLY        _O_RDONLY
#define O_WRONLY        _O_WRONLY
#define O_RDWR          _O_RDWR
#define O_APPEND        _O_APPEND
#define O_CREAT         _O_CREAT
#define O_TRUNC         _O_TRUNC
#define O_EXCL          _O_EXCL
#define O_BINARY        _O_BINARY

#define open _open
#define read _read
#define write _write
#define lseek _lseek
#define close _close
#define access _access
#else
#define O_BINARY 0
#endif	/* __THINK_WINDOWS__ */

struct __think_file {
	int fd;	/* file descriptor */
};
typedef struct __think_file THINK_FILE;

/* open flags */
#define THINK_FILE_CREAT 	0x01		/* creat */
#define THINK_FILE_EXCL 	0x02		/* excl */
#define THINK_FILE_TRUNC 	0x04		/* trunc */
#define THINK_FILE_RDONLY 	0x08		/* read only */
#define THINK_FILE_WRONLY 	0x10		/* write only */
#define THINK_FILE_RDWR 	0x20		/* read & write */
#define THINK_FILE_APPEND 	0x40		/* append */
#define THINK_FILE_BINARY	0x80		/* binary */

#define THINK_FILE_SEEK_SET	SEEK_SET
#define THINK_FILE_SEEK_CUR	SEEK_CUR
#define THINK_FILE_SEEK_END	SEEK_END

THINK_FILE *think_fileopen(const char *pathname,int flags,int mode);
int think_fileread(THINK_FILE *file,void *buffer,unsigned int nbytes);
int think_filewrite(THINK_FILE *file,const void *buffer,unsigned int nbytes);
int think_fileseek(THINK_FILE *file,int offset,int whence);
int think_fileclose(THINK_FILE *file);

/* C++ */
#ifdef __cplusplus
}
#endif

#endif	/* __THINK_FILE_H__ */
