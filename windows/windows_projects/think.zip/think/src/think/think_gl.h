/*
 * think_gl.h: Think General Language Interface
 * version: 1.0
 * OS: AIX,HP-UX,Solaris,FreeBSD,Linux,Mac OS X,Windows
 * author: luojian(enigma1983@qq.com)
 * history:
 * 2008-11-07	1.0 released
 *
 */
#ifndef __THINK_GL_H__
#define __THINK_GL_H__

#include "think_os.h"

/* C++ */
#ifdef __cplusplus
extern "C" {
#endif

#define THINK_GL_CHAR		'C'		/* 1 bytes */
#define THINK_GL_SHORT		'S'		/* 2 bytes */
#define THINK_GL_INT		'I'		/* 4 bytes */
#define THINK_GL_LONG		'L'		/* 8 bytes */
#define THINK_GL_FLOAT		'F'		/* 4 bytes */
#define THINK_GL_DOUBLE		'D'		/* 8 bytes */

/* rule */
typedef struct {
	unsigned int no;	/* no */
	char name[32];		/* name */
	char sname[16];		/* short name */
	char type;		/* type */
	unsigned int maxlen;	/* max length */
	char note[128];		/* note */
} THINK_GL_RULE;

/* field */
typedef struct {
	unsigned int no;	/* field no */
	void *data;		/* data address */
	unsigned int size;	/* data size */
	unsigned int *len;	/* data length */
} THINK_GL_FIELD;

/* think_gl_get */
int think_gl_get(const char *msgbuf,unsigned int msglen,unsigned int no,char type,unsigned int maxlen,void *data,unsigned int size);

/* think_gl_put */
int think_gl_put(char *msgbuf,unsigned int msgsiz,unsigned int no,char type,unsigned int maxlen,const void *data,unsigned int len);

/* think_gl_del */
int think_gl_del(char *msgbuf,unsigned int msglen,unsigned int no);

/* think_gl_exist */
int think_gl_exist(const char *msgbuf,unsigned int msglen,unsigned int no);

/* think_gl_gets */
int think_gl_gets(const char *msgbuf,unsigned int msglen,const THINK_GL_FIELD *fieldarray,unsigned int fieldcount,const THINK_GL_RULE *rulearray,unsigned int rulecount);

/* think_gl_puts */
int think_gl_puts(char *msgbuf,unsigned int msgsiz,const THINK_GL_FIELD *fieldarray,unsigned int fieldcount,const THINK_GL_RULE *rulearray,unsigned int rulecount);

/* think_gl_loadrules */
int think_gl_loadrules(const char *file,THINK_GL_RULE **rulearray);

/* C++ */
#ifdef __cplusplus
}
#endif

#endif	/* __THINK_GL_H__ */
