#include "think_error.h"
#include "think_utility.h"
#include "think_conf.h"
#include "think_db.h"

int think_db_seek(THINK_DB *db,int offset,int whence)
{
	int pos;

	switch(whence){
		case THINK_DB_SEEK_SET:
			if(offset<0){
				offset=0;
			}else if(offset>db->record_count){
				offset=db->record_count;
			}
			break;
		case THINK_DB_SEEK_CUR:
			if(db->cursor==0){
				if(offset<0){
					offset=0;
				}else if(offset>db->record_count){
					offset=db->record_count;
				}
			}else if(think_db_eof(db) || db->cursor==db->record_count){
				if(offset>=0){
					offset=db->record_count;
				}else{
					if(abs(offset)>db->record_count){
						offset=0;
					}else{
						offset=db->record_count-offset*(-1)+1;
					}
				}
			}else{
				if(offset>0){
					if(offset>db->record_count-db->cursor){
						offset=db->record_count;
					}else{
						offset=db->cursor+offset;
					}
				}else if(offset==0){
					offset=db->cursor;
				}else{
					if(offset<db->cursor*(-1)){
						offset=0;
					}else{
						offset=db->cursor+offset;
					}
				}
			}
			break;
		case THINK_DB_SEEK_END:
			if(offset>=0){
				offset=db->record_count;
			}else{
				if(abs(offset)>db->record_count){
					offset=0;
				}else{
					offset=db->record_count-offset*(-1)+1;
				}
			}
			break;
		default:
			think_error(0,"[%s]:illegal whence value.[whence=%d]",__func__,whence);
			return -1;
	};
	pos=offset*db->record_length+db->head_length;
	if(think_fileseek(db->file,pos,THINK_FILE_SEEK_SET)<0){
		think_errorerror();
		return -1;
	}
	db->cursor=offset;

	return 0;
}

int think_db_close(THINK_DB *db)
{
	if(!(db->flags & THINK_DB_RDONLY) && !(db->flags & THINK_DB_SYNC))
		think_db_sync(db);
	think_fileclose(db->file);
	free(db->buffer);
	free(db->field_array);
	free(db);

	return 0;
}
THINK_DB *think_db_open(const char *pathname,int flags,THINK_DB_FIELD *fieldarray,unsigned int fieldcount)
{
	THINK_DB *db;
	THINK_DB_FIELD *p;
	int oflags,i,pos,db_create;
	char buffer[32];
	think_time tm;


	/* db handle */
	if((db=malloc(sizeof(THINK_DB)))==NULL){
		think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		return NULL;
	}
	bzero(db,sizeof(THINK_DB));

	/* summary info */
	db->record_count=0;
	db->head_length=32+1;	/* file head,field end */
	db->field_count=0;
	db->record_length=1;	/* delete flag */

	/* cursor set */
	db->cursor=0;

	/* creat & excl & trunc */
	db_create=0;	/* file create or not */
	if(flags & THINK_DB_CREAT){
		if(access(pathname,F_OK)==0){
			if(flags & THINK_DB_EXCL){
				think_error(0,"[%s]:file exists.",__func__);
				free(db);
				return NULL;
			}
		}else{
			db_create=1;	/* create */
		}
	}
	if(flags & THINK_DB_TRUNC)
		db_create=1;	/* create */

	/* open flags */
	db->flags=flags;
	if(flags==0)
		db->flags=THINK_DB_RDWR;	/* defalut flags */
	oflags=0;
	if(db->flags & THINK_DB_CREAT)	/* creat */
		oflags|=THINK_FILE_CREAT;
	if(db->flags & THINK_DB_TRUNC)	/* trunc */
		oflags|=THINK_FILE_TRUNC;
	oflags|=THINK_FILE_RDWR|THINK_FILE_BINARY;
	if((db->file=think_fileopen(pathname,oflags,0666))==NULL){
		think_errorerror();
		free(db);
		return NULL;
	}

	if(db_create){	/* create */
		if(fieldcount==0){
			think_error(0,"[%s]:fieldcount is 0.",__func__);
			think_fileclose(db->file);
			free(db);
			return NULL;
		}

		/* summary info */
		think_gettime(&tm);
		sprintf(db->last_modify_date,"%04d-%02d-%02d",tm.year,tm.month,tm.day);
		db->field_count=fieldcount;
		db->head_length+=32*fieldcount;
		for(i=0,p=fieldarray;i<fieldcount;i++,p++){
			db->record_length+=p->length;
		}

		/* init field array */
		if((db->field_array=malloc(sizeof(THINK_DB_FIELD)*db->field_count))==NULL){
			think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
			think_fileclose(db->file);
			free(db);
			return NULL;
		}
		memcpy(db->field_array,fieldarray,sizeof(THINK_DB_FIELD)*db->field_count);
		pos=1;	/* 0 used for delete flag */
		for(i=0,p=db->field_array;i<fieldcount;i++,p++){
			switch(p->type){
				case 'C':	/* character */
				case 'N':	/* numeric */
					break;
				default:
					think_error(0,"[%s]:field type not supported![type=%s]",__func__,p->type);
					free(db->field_array);
					think_fileclose(db->file);
					free(db);
					return NULL;
			};
			p->offset=pos;
			pos+=p->length;
		}

		/* sync */
		if(db->flags & THINK_DB_SYNC){
			if(think_db_sync(db)<0){
				think_errorerror();
				free(db->field_array);
				think_fileclose(db->file);
				free(db);
				return NULL;
			}
		}
	}else{	/* open */
		/* summary */
		if(think_fileseek(db->file,0,THINK_FILE_SEEK_SET)<0){
			think_errorerror();
			think_fileclose(db->file);
			free(db);
			return NULL;
		}
		/* read */
		if(think_fileread(db->file,buffer,32)!=32){
			think_errorerror();
			think_fileclose(db->file);
			free(db);
			return NULL;
		}

		/* file type */
		if(buffer[0]!=0x03){
			think_error(0,"[%s]:file type not supported![filetype=0x%0X]",__func__,buffer[0]);
			think_fileclose(db->file);
			free(db);
			return NULL;
		}
		/*last modify date*/
		strcpy(db->last_modify_date,"2000-00-00");
		think_bintohex(db->last_modify_date+2,*(buffer+1));
		think_bintohex(db->last_modify_date+5,*(buffer+2));
		think_bintohex(db->last_modify_date+8,*(buffer+3));

		/*record count*/
		db->record_count=think_ltoh4(*((unsigned int *)(buffer+4)));

		/*head length*/
		db->head_length=think_ltoh2(*((unsigned short *)(buffer+8)));

		/*record lenght*/
		db->record_length=think_ltoh2(*((unsigned short *)(buffer+10)));

		/*field count*/
		db->field_count=(db->head_length-1-32)/32;

		/* fields */
		if((db->field_array=malloc(sizeof(THINK_DB_FIELD)*db->field_count))==NULL){
			think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
			think_fileclose(db->file);
			free(db);
			return NULL;
		}
		bzero(db->field_array,sizeof(THINK_DB_FIELD)*db->field_count);
		if(think_fileseek(db->file,32,THINK_FILE_SEEK_SET)<0){
			think_errorerror();
			free(db->field_array);
			think_fileclose(db->file);
			free(db);
			return NULL;
		}
		pos=1;	/* 0 used for delete flag */
		for(i=0,p=db->field_array;i<db->field_count;i++,p++){
			if(think_fileread(db->file,buffer,32)!=32){
				think_errorerror();
				free(db->field_array);
				think_fileclose(db->file);
				free(db);
				return NULL;
			}

			/* field name */
			snprintf(p->name,sizeof(p->name),"%s",buffer);
			think_strtrim(p->name);

			/* field type */
			switch(buffer[11]){
				case 'C':
				case 'N':
					p->type=buffer[11];
					break;
				default:
					think_error(0,"[%s]:field type not supported![type=%c]",__func__,buffer[11]);
					free(db->field_array);
					think_fileclose(db->file);
					free(db);
					return NULL;
			}

			/*field offset*/
			p->offset=pos;

			/*field length*/
			p->length=(unsigned char)buffer[16];

			pos+=p->length;
		}

		/* db head end flag */
		if(think_fileread(db->file,buffer,1)!=1){
			think_errorerror();
			free(db->field_array);
			think_fileclose(db->file);
			free(db);
			return NULL;
		}
		if(buffer[0]!=0x0D){
			think_error(0,"[%s]:db head end flag not match.",__func__);
			free(db->field_array);
			think_fileclose(db->file);
			free(db);
			return NULL;
		}
	}
	if((db->buffer=malloc(db->record_length))==NULL){
		think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
		free(db->field_array);
		think_fileclose(db->file);
		free(db);
		return NULL;
	}

	return db;
}

THINK_DB *think_db_openx(const char *pathname,int flags,const char *conffile)
{
	THINK_DB_FIELD *p,*fieldarray;
	int pos,h,db_create,fieldcount;
	THINK_CONF *conf;
	
	/* creat & excl & trunc */
	db_create=0;	/* file create or not */
	if(flags & THINK_DB_CREAT){
		if(access(pathname,F_OK)==0){
			if(flags & THINK_DB_EXCL){
				think_error(0,"[%s]:file exists.",__func__);
				return NULL;
			}
		}else{
			db_create=1;	/* create */
		}
	}
	if(flags & THINK_DB_TRUNC)
		db_create=1;	/* create */
	
	if(db_create){	/* create */
		/* load conf */
		if((conf=think_loadconf(conffile,'|'))==NULL){
			think_errorerror();
			return NULL;
		}
		if(conf->hcount==0){
			think_error(0,"[%s]:no fields.",__func__);
			think_freeconf(conf);
			return NULL;
		}
		fieldcount=conf->hcount;
		
		/* init field array */
		if((fieldarray=malloc(sizeof(THINK_DB_FIELD)*fieldcount))==NULL){
			think_error(0,"[%s]:malloc error.[%d:%s]",__func__,think_errno,think_strerror(think_errno));
			think_freeconf(conf);
			return NULL;
		}
		bzero(fieldarray,sizeof(THINK_DB_FIELD)*fieldcount);
		
		pos=1;	/* 0 used for delete flag */
		for(h=0,p=fieldarray;h<fieldcount;h++,p++){
			if(think_getconf(conf,h,0,p->name,sizeof(p->name),0)<0){
				think_errorerror();
				free(fieldarray);
				think_freeconf(conf);
				return NULL;
			}
			if(think_getconf(conf,h,1,&p->type,1,0)<0){
				think_errorerror();
				free(fieldarray);
				think_freeconf(conf);
				return NULL;
			}
			switch(p->type){
			case 'C':	/* character */
			case 'N':	/* numeric */
				break;
			default:
				think_error(0,"[%s]:field type not supported![type=%s]",__func__,p->type);
				free(fieldarray);
				think_freeconf(conf);
				return NULL;
			};
			p->offset=pos;
			if(think_getconf(conf,h,2,&p->length,sizeof(p->length),THINK_CONF_INT)<0){
				think_errorerror();
				free(fieldarray);
				think_freeconf(conf);
				return NULL;
			}
			pos+=p->length;
		}
		
		/* freeconf */
		think_freeconf(conf);
	}
	return think_db_open(pathname,flags,fieldarray,fieldcount);
}

int think_db_sync(THINK_DB *db)
{
	THINK_DB_FIELD *p;
	think_time tm;
	char buffer[32];
	int i,offset,whence;

	/* seek */
	if(think_fileseek(db->file,0,THINK_FILE_SEEK_SET)<0){
		think_errorerror();
		return -1;
	}
	/* write db summary */
	bzero(buffer,sizeof(buffer));

	/* file type: 0 */
	buffer[0]=0x03;

	/* last modify date: 1 */
	think_gettime(&tm);
	sprintf(db->last_modify_date,"%04d-%02d-%02d",tm.year,tm.month,tm.day);
	think_hextobin(buffer+1,db->last_modify_date+2);	/* yy */
	think_hextobin(buffer+2,db->last_modify_date+5);	/* mm */
	think_hextobin(buffer+3,db->last_modify_date+8);	/* dd */

	/* record count: 4 */
	*((unsigned int *)(buffer+4))=think_htol4(db->record_count);

	/* head length: 8 */
	*((unsigned short *)(buffer+8))=think_htol2(db->head_length);

	/* record lenght: 10 */
	*((unsigned short *)(buffer+10))=think_htol2(db->record_length);

	/* write */
	if(think_filewrite(db->file,buffer,32)!=32){
		think_errorerror();
		return -1;
	}

	/* write db fields */
	for(i=0,p=db->field_array;i<db->field_count;i++,p++){
		bzero(buffer,sizeof(buffer));

		/*field name*/
		snprintf(buffer,11,"%s",p->name);

		/*field type*/
		buffer[11]=p->type;

		/*field offset*/
		*((unsigned int *)(buffer+12))=think_htol4(p->offset);

		/*field length*/
		*((unsigned char *)buffer+16)=p->length;

		/* write */
		if(think_filewrite(db->file,buffer,32)!=32){
			think_errorerror();
			return -1;
		}
	}

	/* write db head end flag */
	buffer[0]=0x0D;
	if(think_filewrite(db->file,buffer,1)!=1){
		think_errorerror();
		return -1;
	}

	/* cursor reset */
	if(think_db_eof(db)){
		offset=0;
		whence=THINK_DB_SEEK_END;
	}else{
		offset=db->cursor;
		whence=THINK_DB_SEEK_SET;
	}
	if(think_db_seek(db,offset,whence)<0){
		think_errorerror();
		return -1;
	}

	return 0;
}
int think_db_fetch(THINK_DB *db)
{
	if(db->flags & THINK_DB_WRONLY){
		think_error(0,"[%s]:write only.",__func__);
		return -1;
	}
	if(think_db_eof(db)){
		think_error(0,"[%s]:record end.",__func__);
		return -1;
	}
	if(db->record_count==0 || db->cursor==db->record_count){
		db->cursor=THINK_DB_EOF;
		return 0;
	}
	if(think_fileread(db->file,db->buffer,db->record_length)!=db->record_length){
		think_errorerror();
		return -1;
	}
	db->cursor++;

	return 1;
}
void think_db_new(THINK_DB *db)
{
	db->buffer[0]=0x20;
	bzero(db->buffer+1,db->record_length-1);
}
int think_db_insert(THINK_DB *db)
{
	if(db->flags & THINK_DB_RDONLY){
		think_error(0,"[%s]:read only.",__func__);
		return -1;
	}

	/* append */
	if(db->flags & THINK_DB_APPEND){
		if(think_db_seek(db,0,THINK_DB_SEEK_END)<0){
			think_errorerror();
			return -1;
		}
	}
	if(think_filewrite(db->file,db->buffer,db->record_length)!=db->record_length){
		think_errorerror();
		return -1;
	}

	/* record count */
	if(think_db_eof(db) || db->cursor==db->record_count)	/* else is update */
		db->record_count++;

	/* cursor */
	if(think_db_eof(db))
		db->cursor=db->record_count;
	else
		db->cursor++;

	if(db->flags & THINK_DB_SYNC){
		if(think_db_sync(db)<0)
			return -1;
	}

	return 0;
}
int think_db_getfield(THINK_DB *db,unsigned int no,void *value,unsigned int size,int flags)
{
	THINK_DB_FIELD *p;
	char fieldvalue[256];
	THINK_SHORT t_short;
	THINK_INT t_int;
	THINK_LONG t_long;
	float t_float;
	double t_double;

	if(no>=db->field_count){
		think_error(0,"[%s]:field no out of range.[no=%d]",__func__);
		return -1;
	}
	p=db->field_array+no;
	bzero(fieldvalue,sizeof(fieldvalue));
	memcpy(fieldvalue,db->buffer+p->offset,p->length);
	think_strtrim(fieldvalue);
	if(strlen(fieldvalue)==0 && (flags & THINK_DB_NOT_EMPTY)){
		think_error(0,"[%s]:field value is empty.[%d]->[%d:%s]",__func__,db->cursor,no,p->name);
		return -1;
	}
	switch(flags & THINK_DB_MASK_TYPE){
		case 0:				/* default(char) */
		case THINK_DB_CHAR:		/* char */
			if(strlen(fieldvalue)>=size){
				if(size!=1 || (size==1 && strlen(fieldvalue)>1)){
					think_error(0,"[%s]:value too long![%d]->[%d:%s]:[%s]",__func__,db->cursor,no,p->name,fieldvalue);
					return -1;
				}
			}
			if(size==1)
				memcpy(value,fieldvalue,1);
			else
				strcpy(value,fieldvalue);
			return strlen(value);
		case THINK_DB_SHORT:		/* short */
			if(size!=2){
				think_error(0,"[%s]:field size not equal to 2 with short type![size=%d][%d:%s]",__func__,no,p->name,size);
				return -1;
			}
			t_short=atol(fieldvalue);
			memcpy(value,&t_short,2);
			break;
		case THINK_DB_INT:		/* int */
			if(size!=4){
				think_error(0,"[%s]:field size not equal to 4 with int type![size=%d][%d:%s]",__func__,size,no,p->name);
				return -1;
			}
			t_int=atol(fieldvalue);
			memcpy(value,&t_int,4);
			break;
		case THINK_DB_LONG:		/* long */
			if(size!=8){
				think_error(0,"[%s]:field size not equal to 8 with long type![size=%d][%d:%s]",__func__,size,no,p->name);
				return -1;
			}
			t_long=atoll(fieldvalue);
			memcpy(value,&t_long,8);
			break;
		case THINK_DB_FLOAT:		/* float */
			if(size!=4){
				think_error(0,"[%s]:field size not equal to 4 with float type![size=%d][%d:%s]",__func__,size,no,p->name);
				return -1;
			}
			t_float=atof(fieldvalue);
			memcpy(value,&t_float,4);
			break;
		case THINK_DB_DOUBLE:		/* double */
			if(size!=8){
				think_error(0,"[%s]:field size not equal to 8 with double type![size=%d][%d:%s]",__func__,size,no,p->name);
				return -1;
			}
			t_double=atof(fieldvalue);
			memcpy(value,&t_double,8);
			break;
		default:
			think_error(0,"[%s]:illegal field type.[fieldno=%d][type='%c']",__func__,no,flags&THINK_DB_MASK_TYPE);
			return -1;
	}

	return 0;
}
int think_db_getfieldbyname(THINK_DB *db,const char *name,void *value,unsigned int size,int flags)
{
	THINK_DB_FIELD *p;
	int i,r;

	for(i=0,p=db->field_array;i<db->field_count;i++,p++){
		if(strcmp(name,p->name)==0)
			break;
	}
	if(i==db->field_count){
		think_error(0,"[%s]:field not exists.[name=%s]",__func__,name);
		return -1;
	}
	if((r=think_db_getfield(db,i,value,size,flags))<0){
		think_errorerror();
		return -1;
	}

	return r;
}
int think_db_putfield(THINK_DB *db,unsigned int no,const void *value,unsigned int length,int flags)
{
	THINK_DB_FIELD *p;
	char fieldvalue[256];
	THINK_SHORT t_short;
	THINK_INT t_int;
	THINK_LONG t_long;
	float t_float;
	double t_double;

	if(no>=db->field_count){
		think_error(0,"[%s]:field no out of range.[no=%d]",__func__);
		return -1;
	}
	p=db->field_array+no;
	bzero(fieldvalue,sizeof(fieldvalue));
	switch(flags & THINK_DB_MASK_TYPE){
		case 0:
		case THINK_DB_CHAR:
			if(length>p->length){
				think_error(0,"[%s]:value too long![%d:%s],[type=char],[length=%d],[len=%d]",__func__,no,p->name,p->length,length);
				return -1;
			}
			memcpy(fieldvalue,value,p->length);
			memcpy(db->buffer+p->offset,fieldvalue,p->length);
			break;
		case THINK_DB_SHORT:
			if(length!=2){
				think_error(0,"[%s]:data len not match![%d:%s],[type=short],[len=%d]",__func__,no,p->name,length);
				return -1;
			}
			memcpy(&t_short,value,2);
			sprintf(fieldvalue,"%d",t_short);
			memcpy(db->buffer+p->offset,fieldvalue,p->length);
			break;
		case THINK_DB_INT:
			if(length!=4){
				think_error(0,"[%s]:data len not match![%d:%s],[type=int],[len=%d]",__func__,no,p->name,length);
				return -1;
			}
			memcpy(&t_int,value,4);
			sprintf(fieldvalue,"%d",t_int);
			memcpy(db->buffer+p->offset,fieldvalue,p->length);
			break;
		case THINK_DB_LONG:
			if(length!=8){
				think_error(0,"[%s]:data len not match![%d:%s],[type=long],[len=%d]",__func__,no,p->name,length);
				return -1;
			}
			memcpy(&t_long,value,8);
			sprintf(fieldvalue,"%lld",t_long);
			memcpy(db->buffer+p->offset,fieldvalue,p->length);
			break;
		case THINK_DB_FLOAT:
			if(length!=4){
				think_error(0,"[%s]:data len not match![%d:%s],[type=float],[len=%d]",__func__,no,p->name,length);
				return -1;
			}
			memcpy(&t_float,value,4);
			sprintf(fieldvalue,"%f",t_float);
			memcpy(db->buffer+p->offset,fieldvalue,p->length);
			break;
		case THINK_DB_DOUBLE:
			if(length!=8){
				think_error(0,"[%s]:data len not match![%d:%s],[type=double],[len=%d]",__func__,no,p->name,length);
				return -1;
			}
			memcpy(&t_double,value,8);
			sprintf(fieldvalue,"%f",t_double);
			memcpy(db->buffer+p->offset,fieldvalue,p->length);
			break;
		default:
			think_error(0,"[%s]:illegal field type.[fieldno=%d][type='%c']",__func__,no,flags&THINK_DB_MASK_TYPE);
			return -1;
	};

	return 0;
}
int think_db_putfieldbyname(THINK_DB *db,const char *name,const void *value,unsigned int length,int flags)
{
	THINK_DB_FIELD *p;
	int i;

	for(i=0,p=db->field_array;i<db->field_count;i++,p++){
		if(strcmp(name,p->name)==0)
			break;
	}
	if(i==db->field_count){
		think_error(0,"[%s]:field not exists.[name=%s]",__func__,name);
		return -1;
	}
	if(think_db_putfield(db,i,value,length,flags)<0){
		think_errorerror();
		return -1;
	}

	return 0;
}

int think_db_eof(THINK_DB *db)
{
	if(db->cursor==THINK_DB_EOF)
		return 1;

	return 0;
}
