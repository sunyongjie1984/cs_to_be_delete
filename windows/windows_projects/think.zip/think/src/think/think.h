/*
 * think.h: Think Interface
 * version: 1.0
 * OS: AIX,HP-UX,Solaris,FreeBSD,Linux,Mac OS X,Windows
 * author: luojian(enigma1983@qq.com)
 * history:
 * 2008-11-07	1.0 released
 *
 */

#ifndef __THINK_H__
#define __THINK_H__

/* C++ */
#ifdef __cplusplus
extern "C" {
#endif

/* think_os */

/* Softwares */

#ifdef _AIX	/* IBM AIX OS */
#define __THINK_AIX__
#endif

#ifdef __hpux	/* HP HP-UX OS */
#define __THINK_HPUX__
#endif

#ifdef __SVR4	/* Sun Solaris OS */
#define __THINK_SOLARIS__
#endif

#ifdef __FreeBSD__	/* Berkeley FreeBSD OS */
#define __THINK_FREEBSD__
#endif

#ifdef __linux	/* GNU Linux OS */
#define __THINK_LINUX__
#endif

#ifdef __APPLE__	/* Apple Mac OS X */
#define __THINK_APPLE__
#endif

#ifdef _WIN32	/* Microsoft Windows OS */
#define __THINK_WINDOWS__
#endif

/* Hardwares */
#ifdef __sparc	/* Sun Sparc Machine */
#define __THINK_SPARC__
#endif

#ifdef __ppc__ /* IBM PowerPC */
#define __THINK_POWERPC__
#endif

#if defined(__THINK_AIX__) || defined(__THINK_HPUX__) || defined(__THINK_SOLARIS__) || defined(__THINK_FREEBSD__) || defined(__THINK_LINUX__) || defined(__THINK_APPLE__)
#define __THINK_UNIX__
#endif

#if defined(__THINK_WINDOWS__)	/* windows */

#if _MSC_VER > 1000
#pragma once
#endif

#ifdef _WIN32
#pragma warning (disable:4786) 
#pragma warning (disable:4018)
#pragma warning (disable:4761)
#pragma warning (disable:4244)
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <signal.h>
#define WIN32_LEAN_AND_MEAN	/* for socket api */
#include <windows.h>
#include <process.h>
#include <direct.h>
#include <io.h>
#include <winsock2.h>

typedef char THINK_CHAR;
typedef unsigned char THINK_UCHAR;
typedef short THINK_SHORT;
typedef unsigned short THINK_USHORT;
typedef int THINK_INT;
typedef unsigned int THINK_UINT;
typedef __int64 THINK_LONG;
typedef unsigned __int64 THINK_ULONG;
typedef float THINK_FLOAT;
typedef double THINK_DOUBLE;

#define __func__ "__func__"
#define snprintf _snprintf
#define vsnprintf _vsnprintf
#define bzero(address,size) memset(address,0x00,size)

#elif defined(__THINK_UNIX__)	/* unix */

/* hp-ux */
#ifdef __THINK_HPUX__
#define _XOPEN_SOURCE_EXTENDED 1
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <signal.h>

#include <strings.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <poll.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <pthread.h>

#include <sys/msg.h>
#include <sys/sem.h>
#include <sys/shm.h>

typedef char THINK_CHAR;
typedef unsigned char THINK_UCHAR;
typedef short THINK_SHORT;
typedef unsigned short THINK_USHORT;
typedef int THINK_INT;
typedef unsigned int THINK_UINT;
typedef long long THINK_LONG;
typedef unsigned long long THINK_ULONG;
typedef float THINK_FLOAT;
typedef double THINK_DOUBLE;

#else	/* Unknown OS */
#error Operation System not supported!
#endif	/* __THINK_WINDOWS__ */


/* byte order */

#if defined(__THINK_SPARC__) || defined(__THINK_AIX__) || defined(__THINK_HPUX__) || defined(__THINK_POWERPC__)
#define __THINK_BIG_ENDIAN__
#else
#define __THINK_LITTLE_ENDIAN__
#endif

#ifdef __THINK_LITTLE_ENDIAN__
#define think_htol2(s) (s)
#define think_htol4(i) (i)
#define think_htol8(l) (l)
#define think_ltoh2(s) (s)
#define think_ltoh4(i) (i)
#define think_ltoh8(l) (l)
#else
#define think_htol2(s) ((((s)&0x00FFU)<<8)+(((s)&0xFF00U)>>8))
#define think_htol4(i) ((((i)&0x000000FFU)<<24)+(((i)&0xFF000000U)>>24)\
		+(((i)&0x0000FF00U)<<8)+(((i)&0x00FF0000U)>>8))
#define think_htol8(l) ((((l)&0x00000000000000FFULL)<<56)+(((l)&0xFF00000000000000ULL)>>56)\
		+(((l)&0x000000000000FF00ULL)<<40)+(((l)&0x00FF000000000000ULL)>>40)\
		+(((l)&0x0000000000FF0000ULL)<<24)+(((l)&0x0000FF0000000000ULL)>>24)\
		+(((l)&0x00000000FF000000ULL)<<8)+(((l)&0x0000000FF0000000ULL)>>8))
#define think_ltoh2(s) ((((s)&0x00FFU)<<8)+(((s)&0xFF00U)>>8))
#define think_ltoh4(i) ((((i)&0x000000FFU)<<24)+(((i)&0xFF000000U)>>24)\
		+(((i)&0x0000FF00U)<<8)+(((i)&0x00FF0000U)>>8))
#define think_ltoh8(l) ((((l)&0x00000000000000FFULL)<<56)+(((l)&0xFF00000000000000ULL)>>56)\
		+(((l)&0x000000000000FF00ULL)<<40)+(((l)&0x00FF000000000000ULL)>>40)\
		+(((l)&0x0000000000FF0000ULL)<<24)+(((l)&0x0000FF0000000000ULL)>>24)\
		+(((l)&0x00000000FF000000ULL)<<8)+(((l)&0x0000000FF0000000ULL)>>8))
#endif

#ifdef __THINK_BIG_ENDIAN__
#define think_htob2(s) (s)
#define think_htob4(i) (i)
#define think_htob8(l) (l)
#define think_btoh2(s) (s)
#define think_btoh4(i) (i)
#define think_btoh8(l) (l)
#else
#define think_htob2(s) ((((s)&0x00FFU)<<8)+(((s)&0xFF00U)>>8))
#define think_htob4(i) ((((i)&0x000000FFU)<<24)+(((i)&0xFF000000U)>>24)\
		+(((i)&0x0000FF00U)<<8)+(((i)&0x00FF0000U)>>8))
#define think_htob8(l) ((((l)&0x00000000000000FFULL)<<56)+(((l)&0xFF00000000000000ULL)>>56)\
		+(((l)&0x000000000000FF00ULL)<<40)+(((l)&0x00FF000000000000ULL)>>40)\
		+(((l)&0x0000000000FF0000ULL)<<24)+(((l)&0x0000FF0000000000ULL)>>24)\
		+(((l)&0x00000000FF000000ULL)<<8)+(((l)&0x0000000FF0000000ULL)>>8))
#define think_btoh2(s) ((((s)&0x00FFU)<<8)+(((s)&0xFF00U)>>8))
#define think_btoh4(i) ((((i)&0x000000FFU)<<24)+(((i)&0xFF000000U)>>24)\
		+(((i)&0x0000FF00U)<<8)+(((i)&0x00FF0000U)>>8))
#define think_btoh8(l) ((((l)&0x00000000000000FFULL)<<56)+(((l)&0xFF00000000000000ULL)>>56)\
		+(((l)&0x000000000000FF00ULL)<<40)+(((l)&0x00FF000000000000ULL)>>40)\
		+(((l)&0x0000000000FF0000ULL)<<24)+(((l)&0x0000FF0000000000ULL)>>24)\
		+(((l)&0x00000000FF000000ULL)<<8)+(((l)&0x0000000FF0000000ULL)>>8))
#endif


/* think_error */

#ifdef __THINK_UNIX__
#define think_strerror strerror
#define think_errno errno
#define think_socketerrno errno
#else
const char *think_strerror(int e);
#define think_errno GetLastError()
#define think_socketerrno WSAGetLastError()
#endif	/* __THINK_UNIX__ */
#include <errno.h>

#define THINK_ERROR_ERRMSG_SIZE	1024
extern unsigned int __think_errno__;
extern char __think_errmsg__[THINK_ERROR_ERRMSG_SIZE];

void think_error(unsigned int e,const char *fmt,...);
void think_showerror(void);

#define think_errorerror() think_error(__think_errno__,"[%s]:%s",__func__,__think_errmsg__)


/* think_utility */

#ifdef __THINK_WINDOWS__
extern int opterr,optind,optopt;
extern char *optarg;
int getopt(int argc,char *argv[],const char *ostr);
#define R_OK        4       /* Test for read permission */
#define W_OK        2       /* Test for write permission */
#define X_OK        1       /* Test for execute (search) permission */
#define F_OK        0       /* Test for existence of file */
#define atoll atol
#define think_mkdir(path,mode) mkdir(path)
#define SIGPIPE 0
#else
#define atoll(s) strtoll(s,(char **)NULL,10)
#define think_mkdir(path,mode) mkdir(path,mode)
#endif	/* __THINK_WINDOWS__ */

int think_bin_to_hex(char *dest,const char *src,int len);
int think_bin_to_bcd(char *dest,const char *src,int len);
int think_hex_to_bin(char *dest,const char *src,int len);
int think_bcd_to_bin(char *dest,const char *src,int len);
int think_hextobin(char *dest,const char *src);
int think_bcdtobin(char *dest,const char *src);
int think_bintohex(char *dest,char src);
int think_bintobcd(char *dest,char src);
int think_inttohex(int bin);
int think_inttobcd(int bin);
int think_hextoint(int hex);
int think_bcdtoint(int hex);
int think_printbin(const char *buf,const int len,int linesize);

char *think_strtrim(char *str);
char *think_strinsert(char *srcstr,int pos,char *insstr);
char *think_chrinsert(char *srcstr,int pos,char insstr);
char *think_strreplace(char *srcstr,char *pattern,char *repstr);
char *think_chrreplace(char *srcstr,char pattern,char repstr);
char *think_strdelete(char *srcstr,const char *pattern);
char *think_chrdelete(char *srcstr,char delchr);
int think_strfind(const char *str,const char *pattern,int index);
int think_chrfind(const char *str,char chr,int index);
int think_chrstat(const char *str,char ch);
int think_strstat(const char *str,const char *pattern);

int think_strgetfield(const char *str,char sepchr,int index,char *value,unsigned int size);

int think_bitset(char *bitmap,int bit);
int think_bittest(const char *bitmap,int bit);
int think_bitclear(char *bitmap,int bit);

#define THINK_TIME_SUNDAY	0
#define THINK_TIME_MONDAY	1
#define THINK_TIME_TUESDAY	2
#define THINK_TIME_WEDNESDAY	3
#define THINK_TIME_THURSDAY	4
#define THINK_TIME_FRIDAY	5
#define THINK_TIME_SATURDAY	6

struct _think_time {
	unsigned int year;
	unsigned int month;
	unsigned int day;
	unsigned int week;
	unsigned int hour;
	unsigned int minute;
	unsigned int second;
	unsigned int msecond;
};
typedef struct _think_time think_time;
int think_gettime(think_time *t);
int think_sleep(unsigned int t); /* mil sleep */

#define THINK_OPT_CHAR		'C'		/* 1 bytes */
#define THINK_OPT_SHORT		'S'		/* 2 bytes */
#define THINK_OPT_INT		'I'		/* 4 bytes */
#define THINK_OPT_LONG		'L'		/* 8 bytes */
#define THINK_OPT_FLOAT		'F'		/* 4 bytes */
#define THINK_OPT_DOUBLE	'D'		/* 8 bytes */
#define THINK_OPT_MASK_TYPE	0xFF		/* type mask */

#define THINK_OPT_ARG			0x0100
#define THINK_OPT_NOT_IGNORE		0x0200
#define THINK_OPT_NOT_EMPTY		0x0400

struct __think_optarray {
	char opt;
	void *value;
	unsigned int size;
	int flags;
	int *exists;			/* 0:not exists,1:exists */
};
typedef struct __think_optarray THINK_OPTARRAY;
int think_getopt(int argc,char *argv[],char opt,void *value,unsigned int size,int flags);
int think_getopts(int argc,char *argv[],THINK_OPTARRAY *optarray,unsigned int optcount);

#define THINK_ENV_CHAR		'C'		/* 1 bytes */
#define THINK_ENV_SHORT		'S'		/* 2 bytes */
#define THINK_ENV_INT		'I'		/* 4 bytes */
#define THINK_ENV_LONG		'L'		/* 8 bytes */
#define THINK_ENV_FLOAT		'F'		/* 4 bytes */
#define THINK_ENV_DOUBLE	'D'		/* 8 bytes */
#define THINK_ENV_MASK_TYPE	0xFF		/* type mask */

#define THINK_ENV_NOT_IGNORE		0x0100
#define THINK_ENV_NOT_EMPTY		0x0200

struct __think_envarray {
	const char *name;
	void *value;
	unsigned int size;
	int flags;
	int *exists;
};
typedef struct __think_envarray THINK_ENVARRAY;
int think_getenv(const char *name,void *value,int size,int flags);
int think_getenvs(THINK_ENVARRAY *envarray,unsigned int envcount);

int automkdir(const char *path,int mode);


/* think_file */

#ifdef __THINK_WINDOWS__
#define O_RDONLY        _O_RDONLY
#define O_WRONLY        _O_WRONLY
#define O_RDWR          _O_RDWR
#define O_APPEND        _O_APPEND
#define O_CREAT         _O_CREAT
#define O_TRUNC         _O_TRUNC
#define O_EXCL          _O_EXCL
#define O_BINARY        _O_BINARY

#define open _open
#define read _read
#define write _write
#define lseek _lseek
#define close _close
#define access _access
#else
#define O_BINARY 0
#endif	/* __THINK_WINDOWS__ */

struct __think_file {
	int fd;	/* file descriptor */
};
typedef struct __think_file THINK_FILE;

/* open flags */
#define THINK_FILE_CREAT 	0x01		/* creat */
#define THINK_FILE_EXCL 	0x02		/* excl */
#define THINK_FILE_TRUNC 	0x04		/* trunc */
#define THINK_FILE_RDONLY 	0x08		/* read only */
#define THINK_FILE_WRONLY 	0x10		/* write only */
#define THINK_FILE_RDWR 	0x20		/* read & write */
#define THINK_FILE_APPEND 	0x40		/* append */
#define THINK_FILE_BINARY	0x80		/* binary */

#define THINK_FILE_SEEK_SET	0
#define THINK_FILE_SEEK_CUR	1
#define THINK_FILE_SEEK_END	2

THINK_FILE *think_fileopen(const char *pathname,int flags,int mode);
int think_fileread(THINK_FILE *file,void *buffer,unsigned int nbytes);
int think_filewrite(THINK_FILE *file,const void *buffer,unsigned int nbytes);
int think_fileseek(THINK_FILE *file,int offset,int whence);
int think_fileclose(THINK_FILE *file);


/* think_net */

#ifdef __THINK_WINDOWS__
#define socketclose closesocket
#define socklen_t int
#else
#define socketclose close
#endif

#ifndef INADDR_NONE
#define INADDR_NONE -1
#endif

#define THINK_NET_LISTENER	0x00000001		/* listener */

#define THINK_NET_WAIT		0x00000001		/* wait */
#define THINK_NET_READ		0x00000002		/* read */
#define THINK_NET_WRITE		0x00000004		/* write */
#define THINK_NET_ERROR		0x00000008		/* error */

struct __think_net {
	int sockfd;
	char ip[16];
	unsigned short port;
	int flags;
};
typedef struct __think_net THINK_NET;

struct __think_netlist {
	THINK_NET *net;
	int flags;
	struct __think_netlist *prior;
	struct __think_netlist *next;
};
typedef struct __think_netlist THINK_NETLIST;

int think_netstart(void);
int think_netstop(void);

THINK_NET *think_netconnect(const char *ip,unsigned short port);
THINK_NET *think_netlisten(const char *ip,unsigned short port);
THINK_NET *think_netaccept(THINK_NET *net);
int think_netrecv(THINK_NET *net,void *buf,unsigned int siz,int flags);
int think_netsend(THINK_NET *net,const void *buf,unsigned int len,int flags);
int think_netclose(THINK_NET *net);

/* select & poll */
int think_netlist_add(THINK_NETLIST **netlist,THINK_NET *net);
int think_netlist_del(THINK_NETLIST **netlist,THINK_NET *net);
THINK_NETLIST *think_netlist_find(THINK_NETLIST *netlist,THINK_NET *net);
int think_netlist_clean(THINK_NETLIST **netlist);
int think_netselect(THINK_NETLIST **netlist,int timeout);
#ifdef __THINK_UNIX__
int think_netpoll(THINK_NETLIST **netlist,int timeout);
#else	/* windows */
#define think_netpoll think_netselect
#endif
int think_netlist_free(THINK_NETLIST **netlist);

int think_netsendmsg(THINK_NET *net,const void *buf,unsigned int len);
int think_netrecvmsg(THINK_NET *net,void *buf,unsigned int siz);


/* think_netcenter */

#define THINK_NETCENTER_BUFSIZE	8192

#define THINK_NETCENTER_ACCEPT 			0x00000001	/* accept */
#define THINK_NETCENTER_DISCONNECTED	0x00000002	/* disconnected */
#define THINK_NETCENTER_ERROR			0x00000004	/* error */
#define THINK_NETCENTER_DATARECVED		0x00000008	/* datarecved */

struct __think_netcenter_buflist {
	char *buf;
	unsigned int pos;
	unsigned int len;
	struct __think_netcenter_buflist *prior;
	struct __think_netcenter_buflist *next;
};
typedef struct __think_netcenter_buflist THINK_NETCENTER_BUFLIST;

struct __think_netcenter_net;
typedef struct __think_netcenter_net THINK_NETCENTER_NET;
typedef void (*THINK_NETCENTER_NETHANDLE)(THINK_NETCENTER_NET *,int);
struct __think_netcenter_net {
	THINK_NET *net;
	THINK_NETCENTER_BUFLIST *rlist;
	THINK_NETCENTER_BUFLIST *wlist;
	unsigned int nrbytes;
	unsigned int nwbytes;
	THINK_NETCENTER_NETHANDLE nethandle;
};

struct __think_netcenter_netlist{
	THINK_NETCENTER_NET *net;
	struct __think_netcenter_netlist *prior;
	struct __think_netcenter_netlist *next;
};
typedef struct __think_netcenter_netlist THINK_NETCENTER_NETLIST;

struct __think_netcenter{
	THINK_NETCENTER_NETLIST *netlist;
	THINK_NETLIST *nlist;
};
typedef struct __think_netcenter THINK_NETCENTER;

int think_netcenter_recvto(THINK_NETCENTER_NET *net);
int think_netcenter_send(THINK_NETCENTER_NET *net,const void *buf,unsigned int len);
int think_netcenter_recv(THINK_NETCENTER_NET *net,void *buf,unsigned int siz);
int think_netcenter_sendfrom(THINK_NETCENTER_NET *net);
int think_netcenter_peek(THINK_NETCENTER_NET *net,void *buf,unsigned int siz);
int think_netcenter_select(THINK_NETCENTER *netcenter,int timeout);

THINK_NETCENTER *think_netcenter_new();
int think_netcenter_idle(THINK_NETCENTER *netcenter,int timeout);
int think_netcenter_free(THINK_NETCENTER *netcenter);

THINK_NETCENTER_NETLIST *think_netcenter_netadd(THINK_NETCENTER *netcenter,THINK_NET *net,THINK_NETCENTER_NETHANDLE nethandle);
int think_netcenter_netdel(THINK_NETCENTER *netcenter,THINK_NET *net);
THINK_NETCENTER_NETLIST *think_netcenter_netfind(THINK_NETCENTER *netcenter,THINK_NET *net);
int think_netcenter_netclean(THINK_NETCENTER *netcenter);

int think_netcenter_ismsgok(THINK_NETCENTER_NET *net);
int think_netcenter_recvmsg(THINK_NETCENTER_NET *net,void *buf,unsigned int siz);
int think_netcenter_sendmsg(THINK_NETCENTER_NET *net,const void *buf,unsigned int len);


/* think_timer */

#define THINK_TIMER_TIMEOUT 0x00000001

struct __think_timer;
typedef struct __think_timer THINK_TIMER;
typedef void (*THINK_TIMERHANDLE)(THINK_TIMER *);
struct __think_timer {
	unsigned int timeout;
	unsigned int lasttime;
	THINK_TIMERHANDLE timerhandle;
};

struct __think_timerlist {
	THINK_TIMER *timer;
	struct __think_timerlist *prior;
	struct __think_timerlist *next;
};
typedef struct __think_timerlist THINK_TIMERLIST;

THINK_TIMER *think_timernew(THINK_TIMERHANDLE timerhandle,unsigned int timeout);
int think_timerfree(THINK_TIMER *timer);
int think_timerrefresh(THINK_TIMER *timer);
int think_timerreset(THINK_TIMER *timer);

int think_timerlist_add(THINK_TIMERLIST **timerlist,THINK_TIMER *timer);
int think_timerlist_del(THINK_TIMERLIST **timerlist,THINK_TIMER *timer);
THINK_TIMERLIST *think_timerlist_find(THINK_TIMERLIST *timerlist,THINK_TIMER *timer);
int think_timerlist_clean(THINK_TIMERLIST **timerlist);
int think_timerlist_free(THINK_TIMERLIST **timerlist);
int think_timerlist_idle(THINK_TIMERLIST **timerlist);


/* think_cfg */

#define THINK_CFG_FIELD_SIZE	128	/* field size */
#define THINK_CFG_NAME_SIZE	128	/* name size */
#define THINK_CFG_VALUE_SIZE	1024	/* value size */
#define THINK_CFG_FILE_SIZE	256	/* file size */

struct __think_cfg_cfglist {
	char field[THINK_CFG_FIELD_SIZE];	/* field */
	char name[THINK_CFG_NAME_SIZE];		/* name */
	char value[THINK_CFG_VALUE_SIZE];	/* value */
	char file[THINK_CFG_FILE_SIZE];		/* file */
	unsigned int lineno;
	struct __think_cfg_cfglist *prior;
	struct __think_cfg_cfglist *next;
};			/* cfg list */
typedef struct __think_cfg_cfglist THINK_CFG_CFGLIST;

struct __think_cfg{
	unsigned int cfgcount;		/* cfg count */
	THINK_CFG_CFGLIST *cfglist; 	/* cfg list */
};
typedef struct __think_cfg THINK_CFG;

#define THINK_CFG_CHAR			'C'		/* 1 bytes */
#define THINK_CFG_SHORT			'S'		/* 2 bytes */
#define THINK_CFG_INT			'I'		/* 4 bytes */
#define THINK_CFG_LONG			'L'		/* 8 bytes */
#define THINK_CFG_FLOAT			'F'		/* 4 bytes */
#define THINK_CFG_DOUBLE		'D'		/* 8 bytes */

#define THINK_CFG_MASK_TYPE		0xFF		/* mask */

#define THINK_CFG_NOT_IGNORE		0x0100		/* not ignore */
#define THINK_CFG_NOT_EMPTY		0x0200		/* not empty */

struct __think_cfgarray {
	const char *domain;
	const char *name;
	void *value;
	unsigned int size;
	int flags;
	int *exists;
};		/* cfg array */
typedef struct __think_cfgarray THINK_CFGARRAY;

/* load cfg */
THINK_CFG *think_loadcfg(const char *file,const char *path);

/* get cfg */
int think_getcfg(THINK_CFG *cfg,const char *field,const char *name,void *value,unsigned int size,int flags);

/* show cfg */
int think_showcfg(THINK_CFG *cfg);

/* free cfg */
int think_freecfg(THINK_CFG *cfg);

/* get cfgs */
int think_getcfgs(THINK_CFG *cfg,THINK_CFGARRAY *cfgarray,unsigned int cfgcount);


/* think_conf */

/* field type */
#define THINK_CONF_CHAR		'C'		/* 1 bytes */
#define THINK_CONF_SHORT	'S'		/* 2 bytes */
#define THINK_CONF_INT		'I'		/* 4 bytes */
#define THINK_CONF_LONG		'L'		/* 8 bytes */
#define THINK_CONF_FLOAT	'F'		/* 4 bytes */
#define THINK_CONF_DOUBLE	'D'		/* 8 bytes */
#define THINK_CONF_MASK_TYPE	0xFF		/* field type mask */

#define THINK_CONF_NOT_EMPTY	0x0100		/* field value not empty */

#define THINK_CONF_VALUE_SIZE	1024
#define THINK_CONF_FILE_SIZE	256

struct __think_conf_vlist {
	char value[THINK_CONF_VALUE_SIZE];	/* column value */
	struct __think_conf_vlist *prior;
	struct __think_conf_vlist *next;
};	/* column list */
typedef struct __think_conf_vlist THINK_CONF_VLIST;

struct __think_conf_hlist {
	struct __think_conf_vlist *vlist;		/* column list */
	struct __think_conf_hlist *prior;
	struct __think_conf_hlist *next;
};	/* line list */
typedef struct __think_conf_hlist THINK_CONF_HLIST;

struct __think_conf {
	char d;					/* column delimiter */
	unsigned int hcount;			/* line count */
	unsigned int vcount;			/* column count */
	char file[THINK_CONF_FILE_SIZE];	/* file */
	THINK_CONF_HLIST *hlist;		/* line list */
};
typedef struct __think_conf THINK_CONF;

THINK_CONF *think_loadconf(const char *file,char d);
int think_getconf(THINK_CONF *conf,int h,int v,void *value,unsigned int size,int flags);               
int think_showconf(THINK_CONF *conf);
int think_freeconf(THINK_CONF *conf);


/* think_db */

/* open flags */
#define THINK_DB_CREAT 		0x01		/* creat */
#define THINK_DB_EXCL 		0x02		/* excl */
#define THINK_DB_TRUNC 		0x04		/* trunc */
#define THINK_DB_RDONLY 	0x08		/* read only */
#define THINK_DB_WRONLY 	0x10		/* write only */
#define THINK_DB_RDWR 		0x20		/* read & write */
#define THINK_DB_APPEND 	0x40		/* append */
#define THINK_DB_SYNC		0x80		/* sync */

/* seek */
#define THINK_DB_SEEK_SET	0		/* from first record */
#define THINK_DB_SEEK_CUR	1		/* from current record */
#define THINK_DB_SEEK_END	2		/* from last record */

/* field type */
#define THINK_DB_CHAR		'C'		/* 1 bytes */
#define THINK_DB_SHORT		'S'		/* 2 bytes */
#define THINK_DB_INT		'I'		/* 4 bytes */
#define THINK_DB_LONG		'L'		/* 8 bytes */
#define THINK_DB_FLOAT		'F'		/* 4 bytes */
#define THINK_DB_DOUBLE		'D'		/* 8 bytes */
#define THINK_DB_MASK_TYPE	0xFF		/* field type mask */

/* flags */
#define THINK_DB_NOT_EMPTY	0x0100		/* field value not empty */

#define THINK_DB_EOF		-1		/* eof */

/* db field */
struct __think_db_field {
	char name[11];				/* field name */
	char type;				/* field type */
	unsigned int offset;			/* field offset */
	unsigned int length;			/* field length */
};
typedef struct __think_db_field THINK_DB_FIELD;

/* db handle */
struct __think_db {
	THINK_FILE *file;			/* db file */
	int flags;				/* open flags */
	int cursor;				/* cursor */
	char *buffer;				/* buffer */

	char last_modify_date[11];		/* last modify date: yyyy-mm-dd */
	unsigned int record_count;		/* record count */
	unsigned short head_length;		/* head length */
	unsigned short record_length;		/* record length */
	unsigned int field_count;		/* field count */
	THINK_DB_FIELD *field_array;		/* field array */
};
typedef struct __think_db THINK_DB;

/* think_db_open */
THINK_DB *think_db_open(const char *pathname,int flags,THINK_DB_FIELD *fieldarray,unsigned int fieldcount);
THINK_DB *think_db_openx(const char *pathname,int flags,const char *conffile);

/* think_db_fetch */
int think_db_fetch(THINK_DB *db);

/* think_db_getfield */
int think_db_getfield(THINK_DB *db,unsigned int no,void *value,unsigned int size,int flags);

/* think_db_getfieldbyname */
int think_db_getfieldbyname(THINK_DB *db,const char *name,void *value,unsigned int size,int flags);

/* think_db_new */
void think_db_new(THINK_DB *db);

/* think_db_putfield */
int think_db_putfield(THINK_DB *db,unsigned int no,const void *value,unsigned int length,int flags);

/* think_db_putfieldbyname */
int think_db_putfieldbyname(THINK_DB *db,const char *name,const void *value,unsigned int length,int flags);

/* think_db_insert */
int think_db_insert(THINK_DB *db);

/* think_db_seek */
int think_db_seek(THINK_DB *db,int offset,int whence);

/* think_db_sync */
int think_db_sync(THINK_DB *db);

/* think_db_eof */
int think_db_eof(THINK_DB *db);

/* think_db_close */
int think_db_close(THINK_DB *db);


/* think_mdb */


/* think_gl */

#define THINK_GL_CHAR		'C'		/* 1 bytes */
#define THINK_GL_SHORT		'S'		/* 2 bytes */
#define THINK_GL_INT		'I'		/* 4 bytes */
#define THINK_GL_LONG		'L'		/* 8 bytes */
#define THINK_GL_FLOAT		'F'		/* 4 bytes */
#define THINK_GL_DOUBLE		'D'		/* 8 bytes */

/* rule */
typedef struct {
	unsigned int no;	/* no */
	char name[32];		/* name */
	char sname[16];		/* short name */
	char type;		/* type */
	unsigned int maxlen;	/* max length */
	char note[128];		/* note */
} THINK_GL_RULE;

/* field */
typedef struct {
	unsigned int no;	/* field no */
	void *data;		/* data address */
	unsigned int size;	/* data size */
	unsigned int *len;	/* data length */
} THINK_GL_FIELD;

/* think_gl_get */
int think_gl_get(const char *msgbuf,unsigned int msglen,unsigned int no,char type,unsigned int maxlen,void *data,unsigned int size);

/* think_gl_put */
int think_gl_put(char *msgbuf,unsigned int msgsiz,unsigned int no,char type,unsigned int maxlen,const void *data,unsigned int len);

/* think_gl_del */
int think_gl_del(char *msgbuf,unsigned int msglen,unsigned int no);

/* think_gl_exist */
int think_gl_exist(const char *msgbuf,unsigned int msglen,unsigned int no);

/* think_gl_gets */
int think_gl_gets(const char *msgbuf,unsigned int msglen,const THINK_GL_FIELD *fieldarray,unsigned int fieldcount,const THINK_GL_RULE *rulearray,unsigned int rulecount);

/* think_gl_puts */
int think_gl_puts(char *msgbuf,unsigned int msgsiz,const THINK_GL_FIELD *fieldarray,unsigned int fieldcount,const THINK_GL_RULE *rulearray,unsigned int rulecount);

/* think_gl_loadrules */
int think_gl_loadrules(const char *file,THINK_GL_RULE **rulearray);


/* think_log */

#define THINK_LOG_DEBUG		1	/* debug */
#define THINK_LOG_NORMAL	2	/* normal(default) */
#define THINK_LOG_INFO		3	/* info */
#define THINK_LOG_KEY		4	/* key */
#define THINK_LOG_WARN		5	/* warn */
#define THINK_LOG_ERROR		6	/* error */
#define THINK_LOG_FATAL		7	/* fatal */
#define THINK_LOG_MASK_LEVEL	0x07	/* log level mask */

#define THINK_LOG_PRINT		0x08	/* print to screen */

#define THINK_LOG_TRUNC		0x80	/* trunc */
#define THINK_LOG_EXCL		0x40	/* exclusive */
#define THINK_LOG_LOCAL		0x20	/* local */
#define THINK_LOG_QUIET		0x10	/* not print to screen */

struct __think_log {
	THINK_NET *net;			/* net */
	THINK_DB *db;			/* local */
	char addr[128];			/* address */
	char name[32];			/* name */
	int flags;			/* open flags */
	int pid;			/* process id */
};
typedef struct __think_log THINK_LOG;

THINK_LOG *think_logopen(const char *addr,const char *name,int flags);
int think_logsend(THINK_LOG *lp,int flags,const char *desc,const char *fmt,...);
int think_logclose(THINK_LOG *lp);
int think_loggetflags(const char *strflags);


/* think_shm */

#define THINK_SHM_CREAT		0x80000000
#define THINK_SHM_EXCL		0x40000000
#define THINK_SHM_TRUNC		0x20000000
#define THINK_SHM_RDONLY	0x10000000
#define THINK_SHM_RDWR		0x08000000
#define THINK_SHM_RUSR		0x00000100		/*0400(r)*/
#define THINK_SHM_WUSR		0x00000080		/*0200(w)*/
#define THINK_SHM_XUSR		0x00000040		/*0100(x)*/
#define THINK_SHM_RGRP		0x00000020		/*0040(r)*/
#define THINK_SHM_WGRP		0x00000010		/*0020(w)*/
#define THINK_SHM_XGRP		0x00000008		/*0010(x)*/
#define THINK_SHM_ROTH		0x00000004		/*0004(r)*/
#define THINK_SHM_WOTH		0x00000002		/*0002(w)*/
#define THINK_SHM_XOTH		0x00000001		/*0001(x)*/

#define THINK_SHM_MASK_SECURITY	0x000001FF	/*0777(rwxrwxrwx)*/

#ifndef SHM_FAILED
#define SHM_FAILED (void *)-1L
#endif

struct __think_shm{
#ifdef __THINK_WINDOWS__ /* Windows */
	HANDLE handle;
#else /* UNIX */
	int shmid;
#endif
	void *addr;
};
typedef struct __think_shm THINK_SHM;
THINK_SHM *think_shmopen(const char *name,int size,int flags);
int think_shmclose(THINK_SHM *shm);


/* think_sem.h */

#define THINK_SEM_CREAT		0x80000000
#define THINK_SEM_TRUNC		0x40000000
#define THINK_SEM_EXCL		0x20000000
#define THINK_SEM_UNDO		0x10000000
#define THINK_SEM_RUSR		0x00000100		/*0400(r)*/
#define THINK_SEM_WUSR		0x00000080		/*0200(w)*/
#define THINK_SEM_XUSR		0x00000040		/*0100(x)*/
#define THINK_SEM_RGRP		0x00000020		/*0040(r)*/
#define THINK_SEM_WGRP		0x00000010		/*0020(w)*/
#define THINK_SEM_XGRP		0x00000008		/*0010(x)*/
#define THINK_SEM_ROTH		0x00000004		/*0004(r)*/
#define THINK_SEM_WOTH		0x00000002		/*0002(w)*/
#define THINK_SEM_XOTH		0x00000001		/*0001(x)*/

#define THINK_SEM_MASK_SECURITY	0x000001FF	/*0777(rwxrwxrwx)*/

struct __think_sem{
#ifdef __THINK_WINDOWS__ /* Windows */
	HANDLE handle;
#else /* UNIX */
	int semid;
#endif
	int flags;
};
typedef struct __think_sem THINK_SEM;

#ifdef __THINK_UNIX__ /* UNIX */
struct __think_semun{
	int val;
	struct semid_ds *buf;
	ushort *array;
#ifdef __THINK_LINUX__ /* linux */
	struct seminfo *__buf;
#endif /* __THINK_LINUX__ */
};
typedef struct __think_semun THINK_SEMUN;
#endif /* __THINK_UNIX__ */

THINK_SEM *think_semopen(const char *name,int flags);
int think_semget(THINK_SEM *sem,int timeout);
int think_semput(THINK_SEM *sem);
int think_semclose(THINK_SEM *sem);


/* think_mutex */

#define THINK_MUTEX_CREAT		0x80000000
#define THINK_MUTEX_TRUNC		0x40000000
#define THINK_MUTEX_EXCL		0x20000000
#define THINK_MUTEX_RUSR		0x00000100		/*0400(r)*/
#define THINK_MUTEX_WUSR		0x00000080		/*0200(w)*/
#define THINK_MUTEX_XUSR		0x00000040		/*0100(x)*/
#define THINK_MUTEX_RGRP		0x00000020		/*0040(r)*/
#define THINK_MUTEX_WGRP		0x00000010		/*0020(w)*/
#define THINK_MUTEX_XGRP		0x00000008		/*0010(x)*/
#define THINK_MUTEX_ROTH		0x00000004		/*0004(r)*/
#define THINK_MUTEX_WOTH		0x00000002		/*0002(w)*/
#define THINK_MUTEX_XOTH		0x00000001		/*0001(x)*/

#define THINK_MUTEX_MASK_SECURITY	0x000001FF	/*0777(rwxrwxrwx)*/

struct __think_mutex{
#ifdef __THINK_WINDOWS__ /* Windows */
	HANDLE handle;
#else /* UNIX */
	int semid;
#endif
	int flags;
};
typedef struct __think_mutex THINK_MUTEX;

THINK_MUTEX *think_mutexopen(const char *name,int flags);
int think_mutexlock(THINK_MUTEX *mutex,int timeout);
int think_mutexunlock(THINK_MUTEX *mutex);
int think_mutexclose(THINK_MUTEX *mutex);


/* think_shmq */

/* open mode */
#define THINK_SHMQ_CREAT		0x80000000
#define THINK_SHMQ_EXCL			0x40000000
#define THINK_SHMQ_TRUNC		0x20000000
#define THINK_SHMQ_RDONLY		0x10000000
#define THINK_SHMQ_RUSR			0x00000100		/*0400(r)*/
#define THINK_SHMQ_WUSR			0x00000080		/*0200(w)*/
#define THINK_SHMQ_XUSR			0x00000040		/*0100(x)*/
#define THINK_SHMQ_RGRP			0x00000020		/*0040(r)*/
#define THINK_SHMQ_WGRP			0x00000010		/*0020(w)*/
#define THINK_SHMQ_XGRP			0x00000008		/*0010(x)*/
#define THINK_SHMQ_ROTH			0x00000004		/*0004(r)*/
#define THINK_SHMQ_WOTH			0x00000002		/*0002(w)*/
#define THINK_SHMQ_XOTH			0x00000001		/*0001(x)*/

#define THINK_SHMQ_MASK_SECURITY	0x000001FF	/*0777(rwxrwxrwx)*/

typedef struct {
	int size;
	int totalsize;
	int freesize;
	int head;
	int tail;
	int msgnum;
}THINK_SHMQHEAD;

typedef struct {
	THINK_SHM *shm;
	THINK_SEM *sem;
	THINK_MUTEX *mutex;
	int flags;
	THINK_SHMQHEAD *head;
	void *data;
}THINK_SHMQ;

THINK_SHMQ *think_shmqopen(const char *name,int size,int flags);
int think_shmqget(THINK_SHMQ *shmq,void *buf,int size,int timeout);
int think_shmqput(THINK_SHMQ *shmq,const void *buf,int len,int timeout);
int think_shmqclose(THINK_SHMQ *shmq);


/* think_thread */

#define THINK_THREAD_SUSPEND	0x10000000 /* suspend when created */

struct __think_thread{
#ifdef __THINK_WINDOWS__ /* Windows */
	HANDLE handle;
#else /* UNIX */
	pthread_t thread;
#endif
	int threadid;
};
typedef struct __think_thread THINK_THREAD;
	
#ifdef __THINK_WINDOWS__ /* Windows */
typedef int (WINAPI *THINK_OS_THREADROUTINE)(void *);
int WINAPI think_os_threadroutine(void *);
#else /* UNIX */
typedef void *(*THINK_OS_THREADROUTINE)(void *);
void *think_os_threadroutine(void *);
#endif

/* think thread routine and arg */
typedef void (*THINK_THREADROUTINE)(void *);
struct __think_threadarg{
	THINK_THREADROUTINE routine;
	void *arg;
	int flags;
};
typedef struct __think_threadarg THINK_THREADARG;
	
THINK_THREAD *think_threadcreate(THINK_THREADROUTINE routine,void *arg,int flags);
int think_threadid(void); /* get current thread id */
int think_threadexit(int exitcode);
int think_threadsuspend(THINK_THREAD *thread);
int think_threadcontinue(THINK_THREAD *thread);
int think_threadcancel(THINK_THREAD *thread);
int think_threadjoin(THINK_THREAD *thread,int *exitcode,int timeout);
int think_thread_detach(THINK_THREAD *thread);


/* think_threadmutex */

struct __think_threadmutex{
#ifdef __THINK_WINDOWS__ /* Windows */
	HANDLE handle;
#else /* UNIX */
	pthread_mutex_t *threadmutex;
#endif
};
typedef struct __think_threadmutex THINK_THREADMUTEX;


THINK_THREADMUTEX *think_threadmutex_open();
int think_threadmutex_lock(THINK_THREADMUTEX *threadmutex,int timeout);
int think_threadmutex_unlock(THINK_THREADMUTEX *threadmutex);
int think_threadmutex_close(THINK_THREADMUTEX *threadmutex);

/* C++ */
#ifdef __cplusplus
}
#endif

#endif	/* __THINK_H__ */
