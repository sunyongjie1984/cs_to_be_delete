/*
 * think_mdb.h: Think Memory DB Interface
 * version: 1.0
 * OS: AIX,HP-UX,Solaris,FreeBSD,Linux,Mac OS X,Windows
 * author: luojian(enigma1983@qq.com)
 * history:
 * 2008-11-07	1.0 released
 *
 */

#ifndef __THINK_MDB_H__
#define __THINK_MDB_H__

#include "think_os.h"

/* C++ */
#ifdef __cplusplus
extern "C" {
#endif

/* open flags */
#define THINK_MDB_APPEND 	0x40		/* append */

/* seek */
#define THINK_MDB_SEEK_SET	0		/* from first record */
#define THINK_MDB_SEEK_CUR	1		/* from current record */
#define THINK_MDB_SEEK_END	2		/* from last record */

/* field type */
#define THINK_MDB_CHAR		'C'		/* 1 bytes */
#define THINK_MDB_SHORT		'S'		/* 2 bytes */
#define THINK_MDB_INT		'I'		/* 4 bytes */
#define THINK_MDB_LONG		'L'		/* 8 bytes */
#define THINK_MDB_FLOAT		'F'		/* 4 bytes */
#define THINK_MDB_DOUBLE	'D'		/* 8 bytes */
#define THINK_MDB_MASK_TYPE	0xFF		/* field type mask */

/* flags */
#define THINK_MDB_NOT_EMPTY	0x0100		/* field value not empty */

#define THINK_MDB_EOF		-1		/* eof */

/* mdb field */
struct __think_mdb_field {
	char name[11];				/* field name */
	char type;				/* field type */
	unsigned int length;			/* field length */
	unsigned int offset;			/* field offset */
};
typedef struct __think_mdb_field THINK_MDB_FIELD;

/* mdb handle */
struct __think_mdb {
	int flags;				/* open flags */
	int cursor;				/* cursor */
	char *buffer;				/* buffer */

	unsigned int record_count;		/* record count */
	unsigned short head_length;		/* head length */
	unsigned short record_length;		/* record length */
	unsigned int field_count;		/* field count */
	THINK_MDB_FIELD *field_array;		/* field array */
};
typedef struct __think_mdb THINK_MDB;

/* think_mdb_open */
THINK_MDB *think_mdb_open(const char *name,int flags,THINK_MDB_FIELD *fieldarray,unsigned int fieldcount);

/* think_mdb_fetch */
int think_mdb_fetch(THINK_MDB *mdb);

/* think_mdb_getfield */
int think_mdb_getfield(THINK_MDB *mdb,unsigned int no,void *value,unsigned int size,int flags);

/* think_mdb_getfieldbyname */
int think_mdb_getfieldbyname(THINK_MDB *mdb,const char *name,void *value,unsigned int size,int flags);

/* think_mdb_new */
void think_mdb_new(THINK_MDB *mdb);

/* think_mdb_putfield */
int think_mdb_putfield(THINK_MDB *mdb,unsigned int no,const void *value,unsigned int length,int flags);

/* think_mdb_putfieldbyname */
int think_mdb_putfieldbyname(THINK_MDB *mdb,const char *name,const void *value,unsigned int length,int flags);

/* think_mdb_insert */
int think_mdb_insert(THINK_MDB *mdb);

/* think_mdb_seek */
int think_mdb_seek(THINK_MDB *mdb,int offset,int whence);

/* think_mdb_eof */
int think_mdb_eof(THINK_MDB *mdb);

/* think_mdb_close */
int think_mdb_close(THINK_MDB *mdb);

/* C++ */
#ifdef __cplusplus
}
#endif

#endif	/* __THINK_MDB_H__ */
