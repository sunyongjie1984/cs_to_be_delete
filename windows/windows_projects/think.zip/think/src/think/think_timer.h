/*
 * think_timer.h: Think Timer Interface
 * version: 1.0
 * OS: AIX,HP-UX,Solaris,FreeBSD,Linux,Mac OS X,Windows
 * author: luojian(enigma1983@qq.com)
 * history:
 * 2008-11-07	1.0 released
 *
 */

#ifndef __THINK_TIMER_H__
#define __THINK_TIMER_H__

#include "think_os.h"

/* C++ */
#ifdef __cplusplus
extern "C" {
#endif

#define THINK_TIMER_TIMEOUT 0x00000001

struct __think_timer;
typedef struct __think_timer THINK_TIMER;
typedef void (*THINK_TIMERHANDLE)(THINK_TIMER *);
struct __think_timer {
	unsigned int timeout;
	unsigned int lasttime;
	THINK_TIMERHANDLE timerhandle;
};

struct __think_timerlist {
	THINK_TIMER *timer;
	struct __think_timerlist *prior;
	struct __think_timerlist *next;
};
typedef struct __think_timerlist THINK_TIMERLIST;

THINK_TIMER *think_timernew(THINK_TIMERHANDLE timerhandle,unsigned int timeout);
int think_timerfree(THINK_TIMER *timer);
int think_timerrefresh(THINK_TIMER *timer);
int think_timerreset(THINK_TIMER *timer);

int think_timerlist_add(THINK_TIMERLIST **timerlist,THINK_TIMER *timer);
int think_timerlist_del(THINK_TIMERLIST **timerlist,THINK_TIMER *timer);
THINK_TIMERLIST *think_timerlist_find(THINK_TIMERLIST *timerlist,THINK_TIMER *timer);
int think_timerlist_clean(THINK_TIMERLIST **timerlist);
int think_timerlist_free(THINK_TIMERLIST **timerlist);
int think_timerlist_idle(THINK_TIMERLIST **timerlist);

/* C++ */
#ifdef __cplusplus
}
#endif

#endif /* __THINK_TIMER_H__ */
