/*
 * think_route.h: Think Route Interface
 * version: 1.0
 * OS: AIX,HP-UX,Solaris,FreeBSD,Linux,Mac OS X,Windows
 * author: luojian(enigma1983@qq.com)
 * history:
 * 2008-11-07	1.0 released
 *
 */

#ifndef __THINK_ROUTE_H__
#define __THINK_ROUTE_H__

#include "think_os.h"
#include "think_net.h"

/* C++ */
#ifdef __cplusplus
extern "C" {
#endif

struct __think_route {
	THINK_NET *net;
	char addr[32];
	unsigned int id;
};
typedef struct __think_route THINK_ROUTE;

THINK_ROUTE *think_routelogin(const char *addr,unsigned int id);
int think_routesend(THINK_ROUTE *route,unsigned int id,const void *buf,unsigned int len,int flags);
int think_routerecv(THINK_ROUTE *route,unsigned int *id,void *buf,unsigned int siz,int flags);
int think_routelogout(THINK_ROUTE *route);

/* C++ */
#ifdef __cplusplus
}
#endif

#endif	/* __THINK_ROUTE_H__ */
