#include "think.h"

THINK_THREADMUTEX *threadmutex;

void mprintf(const char *fmt,...)
{
	va_list args;
	
	think_threadmutex_lock(threadmutex,-1);
	va_start(args,fmt);
	vprintf(fmt,args);
	va_end(args);
	think_threadmutex_unlock(threadmutex);
}

void func1(void *s)
{
	const char *str;
	int i;

	str=s;
	for(i=0;i<15;i++){
		think_sleep(1000);
		mprintf("threadid=%d str=%s\n",think_threadid(),str);
	}
	think_threadexit(1);
}
void func2(void *s)
{
	const char *str;
	int i;

	str=s;
	for(i=0;i<20;i++){
		think_sleep(1000);
		mprintf("threadid=%d str=%s\n",think_threadid(),str);
	}
	think_threadexit(9);
}

int main(int argc,char *argv[])
{
	THINK_THREAD *thread1,*thread2;
	int exitcode,r;

	if((threadmutex=think_threadmutex_open())==NULL){
		think_showerror();
		return -1;
	}
	if((thread1=think_threadcreate(func1,"thread1",0))==NULL){
		think_showerror();
		return -1;
	}
	if((thread2=think_threadcreate(func2,"thread2",0))==NULL){
		think_showerror();
		return -1;
	}
	think_sleep(3000);
	think_threadsuspend(thread1);
	think_sleep(3000);
	think_threadcontinue(thread1);

	think_sleep(3000);
	think_threadsuspend(thread2);
	think_sleep(3000);
	think_threadcontinue(thread2);

	mprintf("waiting for thread1 to exit ...\n");
	if((r=think_threadjoin(thread1,&exitcode,10*1000))<0){
		think_showerror();
		return -1;
	}
	if(r==0)
		mprintf("wait thread1 timeout.");
	else
		mprintf("thread1 exit %d\n",exitcode);

	mprintf("waiting for thread2 to exit ...\n");
	if((r=think_threadjoin(thread2,&exitcode,10*1000))<0){
		think_showerror();
		return -1;
	}
	if(r==0)
		mprintf("wait thread2 timeout.");
	else
		mprintf("thread2 exit %d\n",exitcode);

	think_threadmutex_close(threadmutex);

	return 0;
}
