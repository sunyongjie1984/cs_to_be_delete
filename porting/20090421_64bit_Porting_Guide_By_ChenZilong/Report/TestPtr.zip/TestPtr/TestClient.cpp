#include <iostream>
#include <cstdio>
#include <windows.h>

#ifdef _WIN64
#define INTEGER_FORMAT	"0x%016X"
#elif defined (_WIN32)
#define INTEGER_FORMAT	"0x%08X"
#elif defined (_WIN16)
#define INTEGER_FORMAT	"0x%04X"
#else
#error Not supported Windows version
#endif

void TruncatedCasting( int* pInt )
{
	int nCast = reinterpret_cast<int>( pInt );
	long lCast = reinterpret_cast<long>( pInt );
	unsigned int unCast = reinterpret_cast<unsigned int>( pInt );
	unsigned long ulCast = reinterpret_cast<unsigned long>( pInt );

	char szBuf[MAX_PATH] = { 0 };

	sprintf( szBuf, "\tCast to int\t\t\t= %s\n", INTEGER_FORMAT );
	printf( szBuf, nCast );
	sprintf( szBuf, "\tCast to long\t\t\t= %s\n", INTEGER_FORMAT );
	printf( szBuf, lCast );
	sprintf( szBuf, "\tCast to unsigned int\t\t= %s\n", INTEGER_FORMAT );
	printf( szBuf, unCast );
	sprintf( szBuf, "\tCast to unsigned long\t\t= %s\n\n", INTEGER_FORMAT );
	printf( szBuf, ulCast );
}

void SafeCasting( int* pInt )
{
	INT_PTR npCast = reinterpret_cast<INT_PTR>( pInt );
	UINT_PTR unpCast = reinterpret_cast<UINT_PTR>( pInt );
	LONG_PTR lpCast = reinterpret_cast<LONG_PTR>( pInt );
	ULONG_PTR ulpCast = reinterpret_cast<ULONG_PTR>( pInt );
	DWORD_PTR dwpCast = reinterpret_cast<DWORD_PTR>( pInt );
	
	char szBuf[MAX_PATH] = { 0 };
	
	sprintf( szBuf, "\tCast to INT_PTR\t\t\t= %s\n", INTEGER_FORMAT );
	printf( szBuf, npCast );
	sprintf( szBuf, "\tCast to UINT_PTR\t\t= %s\n", INTEGER_FORMAT );
	printf( szBuf, unpCast );
	sprintf( szBuf, "\tCast to LONG_PTR\t\t= %s\n", INTEGER_FORMAT );
	printf( szBuf, lpCast );
	sprintf( szBuf, "\tCast to ULONG_PTR\t\t= %s\n", INTEGER_FORMAT );
	printf( szBuf, ulpCast );
	sprintf( szBuf, "\tCast to DWORD_PTR\t\t= %s\n\n", INTEGER_FORMAT );
	printf( szBuf, dwpCast );
}

int main()
{
	int* pInt = new int( 0x12345678 );
	int** ppInt = &pInt;

	printf( "--------Pointer Casting--------\n\n" );
	printf( "\tInitial pointer value\t\t= 0x%p\n\n", pInt );
	TruncatedCasting( pInt );
	SafeCasting( pInt );
	printf( "--------\n" );

	return 0;
}