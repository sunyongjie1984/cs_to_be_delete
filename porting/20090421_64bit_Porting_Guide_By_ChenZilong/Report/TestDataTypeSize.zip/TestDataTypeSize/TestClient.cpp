#include <iostream>
#include <stddef.h>
#include <conio.h>
#include <tchar.h>
#include <windows.h>

// Const for C++ standard data type size
const size_t PTR_SIZE				= sizeof( void* );
const size_t BOOL_SIZE				= sizeof( bool );
const size_t CHAR_SIZE				= sizeof( char );
const size_t SHORT_SIZE				= sizeof( short );
const size_t INT_SIZE				= sizeof( int );
const size_t LONG_SIZE				= sizeof( long );
const size_t FLOAT_SIZE				= sizeof( float );
const size_t DOUBLE_SIZE			= sizeof( double );
const size_t LONGDOUBLE_SIZE		= sizeof( long double );
const size_t WCHAR_T_SIZE			= sizeof( wchar_t );

// Const for Microsoft specific data type size
const size_t __INT8_SIZE			= sizeof( __int8 );
const size_t __INT16_SIZE			= sizeof( __int16 );
const size_t __INT32_SIZE			= sizeof( __int32 );
const size_t __INT64_SIZE			= sizeof( __int64 );
#if _MSC_VER > 1200
const size_t LONGLONG_SIZE			= sizeof( long long );
#endif

// Const for Windows data type size
const size_t WIN_HANDLE_SIZE		= sizeof( HANDLE );
const size_t WIN_BOOL_SIZE			= sizeof( BOOL );
const size_t WIN_BYTE_SIZE			= sizeof( BYTE );
const size_t WIN_CHAR_SIZE			= sizeof( CHAR );
const size_t WIN_SHORT_SIZE			= sizeof( SHORT );
const size_t WIN_INT_SIZE			= sizeof( INT );
const size_t WIN_LONG_SIZE			= sizeof( LONG );
const size_t WIN_FLOAT_SIZE			= sizeof( FLOAT );
const size_t WIN_WORD_SIZE			= sizeof( WORD );
const size_t WIN_DWORD_SIZE			= sizeof( DWORD );
const size_t WIN_LPCTSTR_SIZE		= sizeof( LPCTSTR );
const size_t WIN_LPARAM_SIZE		= sizeof( LPARAM );
const size_t WIN_WPARAM_SIZE		= sizeof( WPARAM );

const size_t WIN_INT32_SIZE			= sizeof( INT32 );
const size_t WIN_INT64_SIZE			= sizeof( INT64 );
const size_t WIN_LONG32_SIZE		= sizeof( LONG32 );
const size_t WIN_LONG64_SIZE		= sizeof( LONG64 );
const size_t WIN_UINT32_SIZE		= sizeof( UINT32 );
const size_t WIN_UINT64_SIZE		= sizeof( UINT64 );
const size_t WIN_ULONG32_SIZE		= sizeof( ULONG32 );
const size_t WIN_ULONG64_SIZE		= sizeof( ULONG64 );
const size_t WIN_DWORD32_SIZE		= sizeof( DWORD32 );
const size_t WIN_DWORD64_SIZE		= sizeof( DWORD64 );

const size_t WIN_INT_PTR_SIZE		= sizeof( INT_PTR );
const size_t WIN_LONG_PTR_SIZE		= sizeof( LONG_PTR );
const size_t WIN_UINT_PTR_SIZE		= sizeof( UINT_PTR );
const size_t WIN_ULONG_PTR_SIZE		= sizeof( ULONG_PTR );
const size_t WIN_DWORD_PTR_SIZE		= sizeof( DWORD_PTR );

int* POINTER_32 ptr_32;
int* POINTER_64 ptr_64;
const size_t WIN_POINTER_32_SIZE	= sizeof( ptr_32 );
const size_t WIN_POINTER_64_SIZE	= sizeof( ptr_64 );


#define SIZE_UNIT				"\tBytes"
#define SIZE_EQUAL				"= "

void TestCppDataTypeSize( void )
{
	std::cout << "\tC++ Standard Data Type:" << std::endl;
	std::cout << "\tThe size of pointer\t\t" << SIZE_EQUAL << PTR_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of bool\t\t" << SIZE_EQUAL << BOOL_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of char\t\t" << SIZE_EQUAL << CHAR_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of short\t\t" << SIZE_EQUAL << SHORT_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of int\t\t\t" << SIZE_EQUAL << INT_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of long\t\t" << SIZE_EQUAL << LONG_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of float\t\t" << SIZE_EQUAL << FLOAT_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of double\t\t" << SIZE_EQUAL << DOUBLE_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of long double\t\t" << SIZE_EQUAL << LONGDOUBLE_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of wchar_t\t\t" << SIZE_EQUAL << WCHAR_T_SIZE << SIZE_UNIT << std::endl;
	std::cout << std::endl;
}

void TestMSDataTypeSize( void )
{
	std::cout << "\tMicrosoft Specific Data Type:" << std::endl;
	std::cout << "\tThe size of __int8\t\t" << SIZE_EQUAL << __INT8_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of __int16\t\t" << SIZE_EQUAL << __INT16_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of __int32\t\t" << SIZE_EQUAL << __INT32_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of __int64\t\t" << SIZE_EQUAL << __INT64_SIZE << SIZE_UNIT << std::endl;

	// VC6 does not support long long
#if _MSC_VER > 1200
	std::cout << "\tThe size of long long\t\t" << SIZE_EQUAL << LONGLONG_SIZE << SIZE_UNIT << std::endl;
#endif
	std::cout << std::endl;
}

void TestWindowsDataTypeSize( void )
{
	std::cout << "\tTraditional Data Type:" << std::endl;
	std::cout << "\tThe size of HANDLE\t\t" << SIZE_EQUAL << WIN_HANDLE_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of BOOL\t\t" << SIZE_EQUAL << WIN_BOOL_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of BYTE\t\t" << SIZE_EQUAL << WIN_BYTE_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of CHAR\t\t" << SIZE_EQUAL << WIN_CHAR_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of SHORT\t\t" << SIZE_EQUAL << WIN_SHORT_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of INT\t\t\t" << SIZE_EQUAL << WIN_INT_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of LONG\t\t" << SIZE_EQUAL << WIN_LONG_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of FLOAT\t\t" << SIZE_EQUAL << WIN_FLOAT_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of WORD\t\t" << SIZE_EQUAL << WIN_WORD_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of DWORD\t\t" << SIZE_EQUAL << WIN_DWORD_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of LPCTSTR\t\t" << SIZE_EQUAL << WIN_LPCTSTR_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of LPARAM\t\t" << SIZE_EQUAL << WIN_LPARAM_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of WPARAM\t\t" << SIZE_EQUAL << WIN_WPARAM_SIZE << SIZE_UNIT << std::endl;
	std::cout << std::endl;

	std::cout << "\tFixed Precision Data Type:" << std::endl;
	std::cout << "\tThe size of INT32\t\t" << SIZE_EQUAL << WIN_INT32_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of INT64\t\t" << SIZE_EQUAL << WIN_INT64_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of LONG32\t\t" << SIZE_EQUAL << WIN_LONG32_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of LONG64\t\t" << SIZE_EQUAL << WIN_LONG64_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of UINT32\t\t" << SIZE_EQUAL << WIN_UINT32_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of UINT64\t\t" << SIZE_EQUAL << WIN_UINT64_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of ULONG32\t\t" << SIZE_EQUAL << WIN_ULONG32_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of ULONG64\t\t" << SIZE_EQUAL << WIN_ULONG64_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of DWORD32\t\t" << SIZE_EQUAL << WIN_DWORD32_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of DWORD64\t\t" << SIZE_EQUAL << WIN_DWORD64_SIZE << SIZE_UNIT << std::endl;
	std::cout << std::endl;

	std::cout << "\tPointer Precision Data Type:" << std::endl;
	std::cout << "\tThe size of INT_PTR\t\t" << SIZE_EQUAL << WIN_INT_PTR_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of LONG_PTR\t\t" << SIZE_EQUAL << WIN_LONG_PTR_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of UINT_PTR\t\t" << SIZE_EQUAL << WIN_UINT_PTR_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of ULONG_PTR\t\t" << SIZE_EQUAL << WIN_ULONG_PTR_SIZE << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of DWORD_PTR\t\t" << SIZE_EQUAL << WIN_DWORD_PTR_SIZE << SIZE_UNIT << std::endl;
	std::cout << std::endl;

	std::cout << "\tSpecific Pointer Precision Data Type:" << std::endl;
	std::cout << "\tThe size of POINTER_32 type\t" << SIZE_EQUAL << sizeof(WIN_POINTER_32_SIZE) << SIZE_UNIT << std::endl;
	std::cout << "\tThe size of POINTER_64 type\t" << SIZE_EQUAL << WIN_POINTER_64_SIZE << SIZE_UNIT << std::endl;
	std::cout << std::endl;
}

int main()
{
	std::cout << "--------C++ Data Type Size--------\n" << std::endl;
	TestCppDataTypeSize();
	TestMSDataTypeSize();
	std::cout << "--------" << std::endl;

	std::cout << std::endl;

	std::cout << "--------Windows Data Type Size--------\n" << std::endl;
	TestWindowsDataTypeSize();
	std::cout << "--------" << std::endl;

	_getch();
	return 0;
}



