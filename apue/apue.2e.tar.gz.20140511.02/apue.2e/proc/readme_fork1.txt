./fork1 and ./fork1 > tmp.txt
is different, with or with out the command fflush(stdout)
