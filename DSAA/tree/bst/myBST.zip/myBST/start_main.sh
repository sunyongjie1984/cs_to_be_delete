./main | tee a.txt &
