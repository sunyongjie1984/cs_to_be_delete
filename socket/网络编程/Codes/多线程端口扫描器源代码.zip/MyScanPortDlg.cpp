// MyScanPortDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MyScanPort.h"
#include "MyScanPortDlg.h"
#include "afxmt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BOOL REPORT_SUCCEED,REPORT_FAILED;
typedef struct ThreadParam
{
	int StartPort;
	int EndPort;
	HWND hwnd;
	byte a,b,c,d;
}THREADPARAM;
typedef struct PortParam
{
	int iPort;
	HWND hwnd;
	byte a,b,c,d;
}PORTPARAM;
THREADPARAM threadparam1;
bool IsStop;
HANDLE g_Busy;
CString g_message;
bool ReleaseSmp;
CCriticalSection criticalSection;

int NowWhere;
UINT GetPortMessage(LPVOID pParam);
UINT MyThread(LPVOID pParam)
{
	THREADPARAM* threadparam=(THREADPARAM*)pParam;
	sockaddr_in addr;
	addr.sin_family=AF_INET;	
	addr.sin_addr.S_un.S_un_b.s_b1=threadparam->a; 
	addr.sin_addr.S_un.S_un_b.s_b2=threadparam->b;
	addr.sin_addr.S_un.S_un_b.s_b3=threadparam->c;
	addr.sin_addr.S_un.S_un_b.s_b4=threadparam->d;	
	for(int i=threadparam->StartPort;(i<threadparam->EndPort)&&(!IsStop)&&(NowWhere<=threadparam->EndPort);i++)
	{
		SOCKET sck_Conn;
		sck_Conn=socket(AF_INET,SOCK_STREAM,0);
		if(sck_Conn==INVALID_SOCKET)
		{		
			return 0;
		}
		criticalSection.Lock();
		i=NowWhere;
		NowWhere++;
		criticalSection.Unlock();
		addr.sin_port=htons(i);
	
		sck_Conn=socket(AF_INET,SOCK_STREAM,0);
		if(sck_Conn==INVALID_SOCKET)
		{			
			return 0;
		}
		int ddd=connect(sck_Conn,(sockaddr*)&addr,sizeof(addr));
		CString aa="";
		char buffer[80];
		strcpy(buffer,"");
		if(ddd==SOCKET_ERROR)
		{
			if(REPORT_FAILED)
				aa.Format("failed!   port:%d\r\n",i); 
		}
		else
		{
			if(REPORT_SUCCEED)
				aa.Format("succeed!  port:%d\r\n",i);			
		}
		PORTPARAM *portparam=new PORTPARAM;
		portparam->a=threadparam->a; 
		portparam->b=threadparam->b; 
		portparam->c=threadparam->c; 
		portparam->d=threadparam->d;
		portparam->hwnd=threadparam->hwnd; 
		portparam->iPort=i;
		AfxBeginThread(GetPortMessage,portparam,THREAD_PRIORITY_IDLE);
		closesocket(sck_Conn);
		if(g_message.GetLength()>30000)
			g_message="";
		g_message=aa+g_message;		
		
		if(i==threadparam->EndPort)
		{
			g_message="scan port complete!\r\n\r\n"+g_message;
		}
		::SetWindowText(threadparam->hwnd,g_message);
	}
	if(!ReleaseSmp)
	{
		if(ReleaseSemaphore(g_Busy,1,NULL))
			ReleaseSmp=true;
	}
	return 0;
}
UINT GetPortMessage(LPVOID pParam)
{
	PORTPARAM* portparam1=(PORTPARAM*)pParam;
	sockaddr_in addr;
	addr.sin_family=AF_INET;	
	addr.sin_addr.S_un.S_un_b.s_b1=portparam1->a; 
	addr.sin_addr.S_un.S_un_b.s_b2=portparam1->b;
	addr.sin_addr.S_un.S_un_b.s_b3=portparam1->c;
	addr.sin_addr.S_un.S_un_b.s_b4=portparam1->d;	
	addr.sin_port=htons(portparam1->iPort);
	SOCKET sck_Conn;
	sck_Conn=socket(AF_INET,SOCK_STREAM,0);
	if(sck_Conn==INVALID_SOCKET)
	{		
		delete pParam;
		return 0;
	}
	sck_Conn=socket(AF_INET,SOCK_STREAM,0);
	int ddd=connect(sck_Conn,(sockaddr*)&addr,sizeof(addr));
	if(ddd==SOCKET_ERROR)
	{
		closesocket(sck_Conn);
		delete pParam;
		return 0;
	}
	char buffer[256];
	strcpy(buffer,"");
	ddd=recv(sck_Conn,buffer,256,0);
	if(ddd==SOCKET_ERROR)
	{
		closesocket(sck_Conn);
		delete pParam;
		return 0;
	}	
	if(strcmp(buffer,"")!=0)
	{
		CString aa="";
		for(int i=0;i<256;i++)
		{
			if(buffer[i]>128||buffer[i]<0)
			{
				buffer[i]='\0';
				break;
			}
		}
		aa.Format("port:%d  is %s\r\n",portparam1->iPort,buffer); 
		closesocket(sck_Conn);
		
		if(g_message.GetLength()>30000)
		{
			g_message="";
		}
		g_message=aa+g_message;		
		::SetWindowText(portparam1->hwnd,g_message);
	
	}
	delete pParam;
	return 0;return 0;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyScanPortDlg dialog

CMyScanPortDlg::CMyScanPortDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyScanPortDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyScanPortDlg)
	m_endport = 65536;
	m_startport = 0;
	m_message = _T("");
	m_threadnum = 1;
	m_failed = FALSE;
	m_succeed = TRUE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	IsStop=false;
	g_Busy=CreateSemaphore(NULL,1,1,NULL);
	g_message="";	
	NowWhere=0;
	ReleaseSmp=false;
	REPORT_SUCCEED=true;
	REPORT_FAILED=false;
}

void CMyScanPortDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyScanPortDlg)
	DDX_Control(pDX, IDC_IPADDRESS, m_ipaddress);
	DDX_Text(pDX, IDC_ENDPORT, m_endport);
	DDX_Text(pDX, IDC_STARTPORT, m_startport);
	DDX_Text(pDX, IDC_MESSAGE, m_message);
	DDX_Text(pDX, IDC_THREADNUM, m_threadnum);
	DDX_Check(pDX, IDC_CHECKFAILED, m_failed);
	DDX_Check(pDX, IDC_CHECKSUCCEED, m_succeed);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMyScanPortDlg, CDialog)
	//{{AFX_MSG_MAP(CMyScanPortDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_START, OnStart)
	ON_BN_CLICKED(IDC_STOP, OnStop)
	ON_BN_CLICKED(IDC_CLOSE, OnClose)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyScanPortDlg message handlers

BOOL CMyScanPortDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	GetDlgItem(IDC_STOP)->EnableWindow(false);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMyScanPortDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMyScanPortDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMyScanPortDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMyScanPortDlg::OnStart() 
{
	
	UpdateData(true);
	if(m_threadnum<1)
	{
		AfxMessageBox("������������һ���̡߳�");
		return ;
	}
	DWORD dword=WaitForSingleObject(g_Busy,1000);
	if(dword==WAIT_TIMEOUT)
	{
		AfxMessageBox("��ֻ��ͬʱִ��һ������");
		ReleaseSemaphore(g_Busy,1,NULL);
		return;
	}
	GetDlgItem(IDC_STOP)->EnableWindow(true);
	IsStop=false;
	ReleaseSmp=false;
	REPORT_SUCCEED=m_succeed;
	REPORT_FAILED=m_failed;
	NowWhere=m_startport;
	
	BYTE a,b,c,d;
	m_ipaddress.GetAddress(a,b,c,d);
	g_message="";
	threadparam1.a=a;
	threadparam1.b=b;
	threadparam1.c=c;
	threadparam1.d=d;
	threadparam1.EndPort=m_endport;
	threadparam1.StartPort=m_startport;
	threadparam1.hwnd=GetDlgItem(IDC_MESSAGE)->GetSafeHwnd();
	for(int i=0;i<m_threadnum;i++)
		AfxBeginThread(MyThread,&threadparam1,THREAD_PRIORITY_IDLE);	

	
}

void CMyScanPortDlg::OnStop() 
{
	IsStop=true;	
	GetDlgItem(IDC_STOP)->EnableWindow(false);
	Sleep(1000);

}

void CMyScanPortDlg::OnClose() 
{
	CDialog::OnCancel();
	
}
