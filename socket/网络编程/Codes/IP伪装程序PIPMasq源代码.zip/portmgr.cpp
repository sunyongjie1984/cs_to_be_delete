#include "stdafx.h"
#include "PIPMasq.h"

////////////////////////// PortMgr /////////////////////////////////

PortMgr::PortMgr(void)
{
	pICMPIndex = pUDPSocketIndex = pTCPSocketIndex = 0;

	for(int i = 0; i < RSV_PORT_ENTRY; i++)
		ICMPTable[i] = UDPSocketTable[i] = TCPSocketTable[i] = false;

}


PortMgr::~PortMgr()
{
	printf(".....PortMgr is destructed.\n"); 
}

bool
PortMgr::reservPort(__u8 Protocol, __u16 *port)
{
	int i;
	int roop = 0;

	switch (Protocol)
	{
	case UDP:
		i = pUDPSocketIndex;

		while(UDPSocketTable[i] == true)
		{
			i++;
			i = i % RSV_PORT_ENTRY;

			if (roop++ > RSV_PORT_ENTRY)
				return false;  // ASSERT
		}

		*port = htons(i + BEGIN_RSV_PORT);
		UDPSocketTable[i] = true;

		i++;
		pUDPSocketIndex = i % RSV_PORT_ENTRY;		

		break;

	case TCP:
		i = pTCPSocketIndex;

		while(TCPSocketTable[i] == true)
		{
			i++;
			i = i % RSV_PORT_ENTRY;

			if (roop++ > RSV_PORT_ENTRY)
				return false;  // ASSERT
		}

		*port = htons(i + BEGIN_RSV_PORT);
		
		TCPSocketTable[i] = true;

		i++;
		pTCPSocketIndex = i % RSV_PORT_ENTRY;		

		break;

	case ICMP:
		i = pICMPIndex;

		while(ICMPTable[i] == true)
		{
			i++;
			i = i % RSV_PORT_ENTRY;

			if (roop++ > RSV_PORT_ENTRY)
				return false;  // ASSERT
		}

		*port = htons(i + BEGIN_RSV_PORT);
		
		ICMPTable[i] = true;

		i++;
		pICMPIndex = i % RSV_PORT_ENTRY;		

		break;

	default:
		return false;

	}

	return true;
}


bool 
PortMgr::cancelPort(__u8 Protocol, __u16 port)
{
	switch (Protocol)
	{
	case UDP:
		UDPSocketTable[port - BEGIN_RSV_PORT] = false;

		break;

	case TCP:
		TCPSocketTable[port - BEGIN_RSV_PORT] = false;

		break;

	case ICMP:
		ICMPTable[port - BEGIN_RSV_PORT] = false;

		break;


	default:
		return false;

	}
	
	return true;
}
