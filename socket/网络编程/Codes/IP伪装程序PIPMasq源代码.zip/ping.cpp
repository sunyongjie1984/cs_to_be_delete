#include "stdafx.h"
#include "PIPMasq.h"

////////////////////////// PingServer /////////////////////////////////

PingServer::PingServer(PseudIF* pseudIF)
{
	m_pseudIF = pseudIF;
}

PingServer::~PingServer()
{
	printf(".....PingServer is destructed.\n");
//	Sleep(1000);	

}


bool 
PingServer::analizePingPacket(char *pChar, int dataLen)
{
	char* _pChar = pChar;

	struct ethhdr *_ethhdr;
	_ethhdr = (struct ethhdr *)_pChar;	
	
	// exchange ether address
	unsigned char dummyMac[ETH_ALEN];
	
	memcpy(dummyMac, _ethhdr->h_source, ETH_ALEN);
	memcpy(_ethhdr->h_source, _ethhdr->h_dest, ETH_ALEN);
	memcpy(_ethhdr->h_dest, dummyMac, ETH_ALEN);

	// exchange IP address
	_pChar += sizeof(struct ethhdr);
	struct iphdr *_iphdr;
	_iphdr = (struct iphdr *)_pChar;

	__u32 dummyaddr;
	
	dummyaddr = _iphdr->saddr;
	_iphdr->saddr = _iphdr->daddr;
	_iphdr->daddr = dummyaddr;

	// IP checksum
	_iphdr->check = 0;
	_iphdr->check = in_cksum((unsigned short *)_iphdr, sizeof(struct iphdr));


	// exchange ICMP header
	_pChar += sizeof(struct iphdr);
	struct icmphdr *_icmphdr;
	_icmphdr = (struct icmphdr *)_pChar;

	// must be Echo Request
	if (_icmphdr->type != ICMP_ECHO)
		return false;
	
	// change to Echo Reply
	_icmphdr->type = ICMP_ECHOREPLY;

	_icmphdr->checksum = 0; // should be 0
	_icmphdr->checksum = 
		in_cksum((unsigned short *)_icmphdr, 
		ntohs(_iphdr->tot_len) - sizeof(struct iphdr));

	// Packet Release !!
	m_pseudIF->releasePacket((void *)pChar, dataLen);

	return true;

};


