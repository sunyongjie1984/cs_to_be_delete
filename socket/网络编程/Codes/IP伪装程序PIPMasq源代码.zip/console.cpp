#include "stdafx.h"
#include "PIPMasq.h"

////////////////////////// ConsoleMgr /////////////////////////////////

ConsoleMgr::ConsoleMgr(
					   TableMgr *tableMgr, 
					   ThreadMgr *threadMgr,
					   
					   char* pseudIPAddr,
					   char* lanIPAddr,
					   char* wanIPAddr,
					   char* subWanIPAddr,
					   char* defaultWanGWAddr,
					   bool	 pingDown 	
					   )
{
	SetConsoleTitle(PROGRAMNAME);
	
	m_tableMgr = tableMgr;
	m_threadMgr = threadMgr;
	
	m_pseudIPAddr = pseudIPAddr;
	m_lanIPAddr = lanIPAddr;
	m_wanIPAddr = wanIPAddr;
	m_subWanIPAddr = subWanIPAddr;
	m_defaultWanGWAddr = defaultWanGWAddr;	
	m_pingDown = pingDown;
}

ConsoleMgr::~ConsoleMgr()
{
	// revisit	
	printf(".....ConsoleMgr is destructed.\n"); 
//	Sleep(1000);
}

ConsoleMgr::start()
{
	// Disable close button	
	HWND hWnd = ::FindWindow(NULL, PROGRAMNAME);
	if (hWnd)
	{
		HMENU hMenu = GetSystemMenu(hWnd, FALSE);
		RemoveMenu(hMenu, SC_CLOSE, MF_BYCOMMAND);
	}
	else
	{
		m_threadMgr->m_lifeFlag = true;
		return false;
	}

	HANDLE consoleStdin, consoleStdout;

	consoleStdin = GetStdHandle(STD_INPUT_HANDLE);
	consoleStdout = GetStdHandle(STD_OUTPUT_HANDLE);

	if (consoleStdin == consoleStdout)
	{
		m_threadMgr->m_lifeFlag = true;
		return false;
	}

	char buffer[1000];
	DWORD numRead, numWrite;

	memset(buffer, 0, 1000);

	char _onoff[2][4];
	strcpy(_onoff[0], "off");
	strcpy(_onoff[1], "on");

	do
	{
		WriteFile(consoleStdout, "\n>",2, &numWrite, 0);

		ReadFile(consoleStdin, buffer, 1000, &numRead, 0);
		buffer[numRead] = '\0';

		if ((strncmp(buffer, "list",4) == 0) ||
			(strncmp(buffer, "LIST",4) == 0) ||	
			(strncmp(buffer, "l",1) == 0) ||
			(strncmp(buffer, "L",1) == 0))
		{
			m_tableMgr->browseEntry();	
		}
		else if 
			((strncmp(buffer, "conf",4) == 0) ||
			(strncmp(buffer, "CONF",4) == 0) ||	
			(strncmp(buffer, "c",1) == 0) ||
			(strncmp(buffer, "C",1) == 0))
		{
			printf("\n Pseud IP masquerading configuration\n");
			printf(" -----------------------------------\n");

			printf(" Pseud IP\t%-16s\n", m_pseudIPAddr);
			printf(" Outer IP\t%-16s\n", m_wanIPAddr);
			printf(" Subnet IP\t%-16s\n", m_subWanIPAddr);
			printf(" Gateway IP\t%-16s\n", m_defaultWanGWAddr);
			printf(" Intra IP\t%-16s\n", m_lanIPAddr);
			printf(" PingDown\t%-16s\n", _onoff[m_pingDown]);
		}
		else if 
			((strncmp(buffer, "help",4) == 0) ||
			(strncmp(buffer, "HELP",4) == 0) ||	
			(strncmp(buffer, "h",1) == 0) ||
			(strncmp(buffer, "H",1) == 0))
		{
			printf(" command  \n");
			printf(" ----------------------------------------\n");			
			printf(" 'conf'		configuration information\n");
			printf(" 'list'		masquerade table entries\n");
			printf(" 'help'		this menu\n");
			printf(" 'exit'		exits \n");
		}
	
	}while (strncmp(buffer, "exit", 4) != 0);

	m_threadMgr->m_lifeFlag = true;
	return true;
}


		
