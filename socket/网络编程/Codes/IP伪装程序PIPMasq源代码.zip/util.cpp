#include "stdafx.h"
#include "PIPMasq.h"


// Don't forget the following next two lines before using this function
//		WSADATA			Data;
//		int status = WSAStartup(MAKEWORD(1,1), &Data);
bool
_hostnameToDotIP(const char *IPAddr, char *dotIP)
{
	memset(dotIP, 0, 16);
	
	struct in_addr iaHost;
	LPHOSTENT lpHostEntry;
	struct in_addr *pinAddr;

	iaHost.s_addr = inet_addr(IPAddr);
	if (iaHost.s_addr == INADDR_NONE)
	{
		lpHostEntry = gethostbyname(IPAddr);
		if (lpHostEntry == NULL)
			return false;

		pinAddr = (LPIN_ADDR)lpHostEntry->h_addr_list[0];

		memcpy(dotIP, inet_ntoa(*pinAddr), 16);
	}
	else
	{
		memcpy(dotIP, IPAddr, 16);		
	}

	return true;
}


// Don't forget the following next two lines before using this function
//		WSADATA			Data;
//		int status = WSAStartup(MAKEWORD(1,1), &Data);
// This function is a reverse function of inet_addr
bool
rev_inet_addr(__u32 netByteIPAddr32, char *dotIP)
{
	memset(dotIP, 0, 16);
	
	struct in_addr	addr;
	addr.s_addr = netByteIPAddr32;

	memcpy(dotIP, inet_ntoa(addr), 16); 
	return true;
}


bool 
double_start_check(void)
{
	// Create mutex
	
	HANDLE hMutex;
	hMutex = CreateMutex(NULL, TRUE, "DSC4PIPMasq");
	
	if (!hMutex)
		return FALSE;
	
	// If GetLastError() returns ERROR_ALREADY_EXISTS,
	// another PIPMasq has already started.

	if (GetLastError() == ERROR_ALREADY_EXISTS)
		return false;

	return true;
}
