#include "stdafx.h"
#include "PIPMasq.h"

////////////////////////// TimeMgr /////////////////////////////////

TimeMgr::TimeMgr(TableMgr *tableMgr,
				 ThreadMgr*	threadMgr)
{
	m_tableMgr = tableMgr;
	m_threadMgr = threadMgr;
	m_tableBrowseCounter = 0;
}

TimeMgr::~TimeMgr()
{
	// Revisit 

	printf(".....TimeMgr is destructed.\n"); 
//	Sleep(1000);	
}

TimeMgr::start()
{
	int sleepCounter = 0;

	while(1)
	{
		Sleep(1000); // 1 second
		sleepCounter++;

		if (m_threadMgr->m_lifeFlag == true)
			return false;

		if (sleepCounter >= TABLE_CHECK_TIME)
		{
			sleepCounter = 0;
			
			time_t now = time(NULL);
			m_tableMgr->delEntry(now);
		}
	}
}

