#include "stdafx.h"
#include "PIPMasq.h"
#include <signal.h>

////////////////////////// ThreadMgr /////////////////////////////////


ThreadMgr::ThreadMgr()
{
	m_lifeFlag = false;
}

ThreadMgr::~ThreadMgr()
{
	// revisit
	printf(".....ThreadMgr is destructed.\n"); 
//	Sleep(1000);	
}


