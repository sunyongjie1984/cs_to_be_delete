(1) WinPcap Developer's pack is needed in order to build.

	Download WinPcap Developer's pack from
	http://netgroup-serv.polito.it/winpcap/install/bin/WPdpack.zip
	
	After that, uncompress and locate it on the proper directory.

	You need the following header files and libraries ONLY.

		Include\devioctl.h
      		Include\ntddndis.h
      		Include\ntddpack.h
      		Include\packet32.h
      		Lib\packet.lib

(2)Setting project

	Add the include paths and library paths that are located on
	the above directories to project file.
	Add "packet.lib" as a link library.

