// main.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "PIPMasq.h"
#include "packet32.h"
#include <signal.h>

bool double_start_check(void);

bool getAdapterInfo(
	const char* nicIPAddress,	// input
	char* AdapterName,			// output
	unsigned char*	macAddr		// output	
)
{
	// string that contains a list of the network adapters
	WCHAR		TempBuffer[1024]; 

	char        adapterList[Max_Num_Adapter][512];
	char        adapterList2[Max_Num_Adapter][512];

	char		AdapterName2[512];

	__u32			ipAddr;				// IP Address
	__u32			maskAddr;			// Mask (Subnet) Address

	DWORD dwVersion=GetVersion();
	DWORD dwWindowsMajorVersion =  (DWORD)(LOBYTE(LOWORD(dwVersion)));

	// Windows NT 
	if (!(!(dwVersion >= 0x80000000 && dwWindowsMajorVersion >= 4)))
		return false;
  
	ULONG		AdapterLength = 1024;

	memset(TempBuffer,0, sizeof(TempBuffer));
	memset(adapterList,0, sizeof(adapterList));
	memset(adapterList2,0, sizeof(adapterList2));
	
	PacketGetAdapterNames((char *)TempBuffer,&AdapterLength);

	WCHAR		*temp,*temp1;

	temp=TempBuffer;
	temp1=TempBuffer;
	
	int i = 0;

	while ((*temp!='\0')||(*(temp-1)!='\0'))
	{
		if (*temp=='\0') 
		{
			memcpy(adapterList[i],temp1,(temp-temp1)*2);
			temp1=temp+1;
			i++;
		}
	
		temp++;
	}
	 
	// Change adapterList the part of "/" to "//" for Windows NT
	int AdapterNum = i;
	
	for (i=0;i<AdapterNum;i++)
	{

		memcpy(adapterList2[i],adapterList[i],sizeof(adapterList[i]));
		temp1 = temp = (WCHAR *)(adapterList2[i]);
		
		int adapterList2Length = 0;
		while ((*temp!='\0')||(*(temp-1)!='\0'))
		{
			adapterList2Length++;
			temp++;
		}

		int j =0;
		temp = temp1;
		while ((*temp!='\0')||(*(temp-1)!='\0'))
		{
			if (*temp == 0x005c)
			{
				int k;
				for (k = adapterList2Length ; k > j ; k--)
				{
					*(temp1 + k + 1) = *(temp1 + k); 
				}

				*(temp + 1) =  0x005c;	// add "/"
				temp++;
				adapterList2Length++;
			}
			j++;
			temp++;
		}
	}

	__u32 nicAddr = htonl(inet_addr(nicIPAddress));

	for (i=0;i<AdapterNum;i++)
	{
		// Get the IP Address
		BOOLEAN truefalse = 
			PacketGetNetInfo(adapterList2[i],(PULONG)(&ipAddr),(PULONG)(&maskAddr));

		if (ipAddr == nicAddr)
		{
			memcpy(AdapterName, adapterList[i], 512 /*sizeof(AdapterName) */);
			memcpy(AdapterName2, adapterList2[i], 512 /*sizeof(AdapterName2) */);
		
			LPADAPTER temp_lpAdapter 
				= PacketOpenAdapter(AdapterName);

			if (!temp_lpAdapter || (temp_lpAdapter->hFile == INVALID_HANDLE_VALUE))
			{
				DWORD dwErrorCode=GetLastError();

				return false;
			}

			// Check the Adapter Type (It should be Ethernet)
			NetType netType;

			PacketGetNetType(temp_lpAdapter, &netType);
			if (netType.LinkType != NdisMedium802_3)
				return false;
			
			// Get the MAC Address
			PACKET_OID_DATA pod;

			pod.Oid = OID_802_3_PERMANENT_ADDRESS;
			pod.Length = ETH_ALEN /* sizeof(macAddr) */;

			if (PacketRequest(temp_lpAdapter, 0, &pod) == NULL)
			{
				return false;
			}

			memcpy(macAddr, pod.Data, pod.Length);

			PacketCloseAdapter(temp_lpAdapter);

			return true;
		}
	}

	return false;
}

unsigned int __stdcall _outWardThread(void *wardInfo)
{
	struct wardInfo *wi = (struct wardInfo *)wardInfo;

	COutward _outWard(	wi->tableMgr,
						wi->portMgr,
						wi->arpMgr,
						wi->psuedIF,
						wi->threadMgr,
						wi->ftpMgr,
						wi->lanIPAddr,
						wi->wanIPAddr,
						wi->subWanIPAddr,
						wi->defaultWanGWAddr);


	_outWard.start();

	return(0);

}

unsigned int __stdcall _inWardThread(void *wardInfo)
{
	struct wardInfo *wi = (struct wardInfo *)wardInfo;

	CInward _inWard(	wi->tableMgr,
						wi->portMgr,
						wi->arpMgr,
						wi->pingSvr,
						wi->psuedIF,
						wi->threadMgr,
						wi->lanIPAddr,
						wi->wanIPAddr,
						wi->pingDown			
						);

	try
	{
		_inWard.start();
	}
	catch(panic panic) 
	{
		int i=0;
		// revist
	}

	return(0);

}

unsigned int __stdcall _timeMgrThread(void *wardInfo)
{
	struct wardInfo *wi = (struct wardInfo *)wardInfo;

	TimeMgr _timeMgr(	wi->tableMgr,
						wi->threadMgr);

	_timeMgr.start();

	return(0);

}

unsigned int __stdcall _consoleMgrThread(void *wardInfo)
{
	struct wardInfo *wi = (struct wardInfo *)wardInfo;

	ConsoleMgr _consoleMgr(	wi->tableMgr,
							wi->threadMgr,
														
							wi->pseudIPAddr,
							wi->lanIPAddr,
							wi->wanIPAddr,
							wi->subWanIPAddr,
							wi->defaultWanGWAddr,
							wi->pingDown
							);

	_consoleMgr.start();

	return(0);

}



struct wardInfo wi;


bool getDefaultGWMacAddr(
	char* wanIPAddr, 
	char* subWanIPAddr, 
	char* defaultWanGWAddr,
	unsigned char*	defaultGWMacAddr)
{
	CArp	_carp(wanIPAddr, subWanIPAddr, defaultWanGWAddr);

	if (_carp.isArpVaild == false)
		return false;

	__u32 defaultWanGWAddr_u32 = inet_addr(defaultWanGWAddr);

	if (_carp.arpSendRecv(defaultWanGWAddr_u32, (char*)defaultGWMacAddr) == false)
		return false;

	return true;
}

bool
loadNetInfo(
			char* pseudIPAddr,
			char* wanIPAddr,
			char* subWanIPAddr,
			char* defaultWanGWAddr,
			char* lanIPAddr,
			bool* pingDown
			)
{
	// You should prepare the configuration file that is named "pipmasq.cfg"
	//		
	//		PSEUD=15.2.117.199
	//		OUTER=15.2.117.197
	//		NETWORK=255.255.248.0 
	//		GATEWAY=15.2.112.1
	//		INTRA=192.168.0.2	

	memset(pseudIPAddr, 0, 16);
	memset(wanIPAddr, 0, 16);
	memset(subWanIPAddr, 0, 16);
	memset(defaultWanGWAddr, 0, 16);
	memset(lanIPAddr, 0, 16);
	
	FILE *f;
	char string[200];
	char buffer[MAX_PATH];
	int counter = 0;
	
	if (GetCurrentDirectory(MAX_PATH, buffer) == 0)
		return false;
	
	char configFileName[MAX_PATH];
	strcpy(configFileName, buffer);
	strcat(configFileName, "\\pipmasq.cfg");
	
	f = fopen(configFileName,"r");
	if (!f)
	{
		strcat(configFileName, " is not found.\n");
		return false;
	}
	
	while((string[counter++] = fgetc(f)) != EOF);
	
	counter--;
	string[counter] = NULL;
	
	fclose(f);
	
	bool pseudIPAddr_flag = false;
	bool wanIPAddr_flag = false;
	bool subWanIPAddr_flag = false;
	bool defaultWanGWAddr_flag = false;
	bool lanIPAddr_flag = false;
	
	char seps[]   = "= \t\n";
	char *token;
	
	token = strtok( string, seps );
	
	while( token != NULL )
	{
		if (strcmp(token,"PSEUD") == 0)
		{
			if ((token = strtok( NULL, seps )) == NULL)
				return false;
			
			strcpy(pseudIPAddr, token);
			
			pseudIPAddr_flag = true;
		}
		else if (strcmp(token,"OUTER") == 0)
		{
			if ((token = strtok( NULL, seps )) == NULL)
				return false;
			
			strcpy(wanIPAddr, token);
			
			wanIPAddr_flag = true;
		}
		else if (strcmp(token,"NETWORK") == 0)
		{
			if ((token = strtok( NULL, seps )) == NULL)
				return false;
			
			strcpy(subWanIPAddr, token);
			
			subWanIPAddr_flag = true;
		}
		else if (strcmp(token,"GATEWAY") == 0)
		{
			if ((token = strtok( NULL, seps )) == NULL)
				return false;
			
			strcpy(defaultWanGWAddr, token);
			
			defaultWanGWAddr_flag = true;
		}
		else if (strcmp(token,"INTRA") == 0)
		{
			if ((token = strtok( NULL, seps )) == NULL)
				return false;
			
			strcpy(lanIPAddr, token);
			
			lanIPAddr_flag = true;
		}
		else if (strcmp(token,"PINGDOWN") == 0)
		{
			if ((token = strtok( NULL, seps )) == NULL)
				return false;
			
			if ((strcmp(token,"ON") == 0)|| (strcmp(token,"on") == 0))
				*pingDown = true;
		}
		token = strtok( NULL, seps );
	}
	
	if (pseudIPAddr_flag 
		& wanIPAddr_flag 
		& subWanIPAddr_flag 
		& defaultWanGWAddr_flag 
		& lanIPAddr_flag)
	{
		return true;
	}
	else 
	{
		return false;
	}
}	

void
openingMessage(void)
{
	cout <<"==========================================================="<< endl;
	cout <<"                                                           "<< endl;
	cout <<"                                                           "<< endl;
	cout <<"            Pseud IP Masquerade on Win32                   "<< endl;
	cout <<"                                                           "<< endl;
	cout <<"                                       Ver " << VERSION     << endl;
	cout <<"                                                           "<< endl;
	cout <<"                                       Tomoichi Ebata      "<< endl;
	cout <<"                                                           "<< endl;
	cout <<"        http://www.ff.iij4u.or.jp/~ebata/soft/pipmasq/     "<< endl;
	cout <<"                                                           "<< endl;
	cout <<"                                                           "<< endl;
	cout <<"        This product includes software developed by        "<< endl;
	cout <<"      the Politecnico di Torino, and its contributors.     "<< endl; 
	cout <<"                                                           "<< endl;
	cout <<"          http://netgroup-serv.polito.it/winpcap/          "<< endl;
	cout <<"                                                           "<< endl;
	cout <<"                                                           "<< endl;
	cout <<"==========================================================="<< endl;
}

void _sigCatch(int sig)
{
	printf("\n'Ctrl-c' is not available now. Try 'exit' \n");
	signal(SIGINT,_sigCatch);
}


#if _NTS
DWORD ServiceThread(LPDWORD param)  // This is for NT Service
#else
int main(void) 
#endif
{
	if (double_start_check() == false)
	{
		openingMessage();
		printf("\n\n");
		printf("Another PIPMasq has already started.\n");
		printf("\n");
		printf("Existing");

		// Waiting time to show the above message to user
		for (int i=0; i<4; i++)
		{
			printf(".");
			Sleep(500);
		}

		return -1;
	}

	signal(SIGINT,_sigCatch);

	openingMessage();

	char		lanIPAddr[16];
	char		wanIPAddr[16];
	char		subWanIPAddr[16];
	char		defaultWanGWAddr[16];
	char		pseudIPAddr[16];
	bool 		pingDown = false;

	if (!loadNetInfo(
			pseudIPAddr, 
			wanIPAddr, 
			subWanIPAddr, 
			defaultWanGWAddr, 
			lanIPAddr,
			&pingDown
			))
		return -1;

	unsigned char	defaultGWMacAddr[ETH_ALEN];

	if (getDefaultGWMacAddr(
		wanIPAddr, subWanIPAddr, defaultWanGWAddr, defaultGWMacAddr) == false)
		return -1;

	PortMgr		_portMgr;
	TableMgr	_tableMgr(&_portMgr);
	FtpMgr		_ftpMgr(&_tableMgr, &_portMgr, pseudIPAddr);
	
	PseudIF		_pseudIF(wanIPAddr, pseudIPAddr, subWanIPAddr, defaultGWMacAddr);

	ArpMgr		_arpMgr(&_pseudIF);

	PingServer	_pingSvr(&_pseudIF);

	ThreadMgr	_threadMgr;

	wi.tableMgr = &_tableMgr;
	wi.portMgr = &_portMgr;
	wi.arpMgr = &_arpMgr;
	wi.pingSvr = &_pingSvr;
	wi.psuedIF = &_pseudIF;
	wi.threadMgr = &_threadMgr;

	wi.pseudIPAddr = pseudIPAddr;
	wi.lanIPAddr = lanIPAddr;
	wi.wanIPAddr = wanIPAddr;
	wi.subWanIPAddr = subWanIPAddr;
	wi.defaultWanGWAddr = defaultWanGWAddr;

	wi.pingDown = pingDown;
	wi.ftpMgr = &_ftpMgr;


	HANDLE threadHandle[3];
	unsigned threadID;

	// Start Outward thread 
	threadHandle[0] =
		(HANDLE)_beginthreadex(NULL, 0, &_outWardThread, &wi, 0, &threadID);

	// Start Inward thread 
	threadHandle[1] =
		(HANDLE)_beginthreadex(NULL, 0, &_inWardThread, &wi, 0, &threadID);

	// Start TimeMgr thread 
	threadHandle[2] =
		(HANDLE)_beginthreadex(NULL, 0, &_timeMgrThread, &wi, 0, &threadID);

#if _NTS
#else
	HANDLE threadHandleConsole;	
	unsigned threadIDConsole;	
	// Start ConsoleMgr thread
	threadHandleConsole =
		(HANDLE)_beginthreadex(NULL, 0, &_consoleMgrThread, &wi, 0, &threadIDConsole);
#endif 

	WaitForMultipleObjects(3, threadHandle, TRUE, INFINITE);

	for(int i = 0; i < 3; i++)
	{
		CloseHandle(threadHandle[i]);
	}

#if _NTS
#else
	// Force to finish ConsoleMgr
	TerminateThread(threadHandleConsole,0);
	CloseHandle(threadHandleConsole);
#endif 


	printf("\n\nStart Terminating.......\n");
	printf("Please wait a few seconds to terminate completely.....\n\n\n");
		
	return 0;
}

