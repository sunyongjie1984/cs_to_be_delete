#include "stdafx.h"
#include "PIPMasq.h"

bool getAdapterInfo(
	const char* nicIPAddress,	// input
	char* AdapterName,			// output
	unsigned char*	macAddr		// output	
);


////////////////////////// PseudIF /////////////////////////////////

PseudIF::PseudIF(
	const char* wanIPAddr, 
	const char* pseudIPAddr,
	const char*	subWanIPAddr,
	unsigned const char* defaultGWMacAddr)
{
	//////////

	strcpy(m_wanIPAddr, wanIPAddr);
	memset(m_wanAdapterName, 0 , sizeof(m_wanAdapterName));

	if (getAdapterInfo(m_wanIPAddr, m_wanAdapterName, m_wanMacAddr))
		m_pseudLpAdapter = PacketOpenAdapter(m_wanAdapterName);
	else
		return;

	memcpy(m_pseudMacAddr, m_wanMacAddr, ETH_ALEN);
	memcpy(m_defaultGWMacAddr, defaultGWMacAddr, ETH_ALEN);

	PacketSetHwFilter(m_pseudLpAdapter,NDIS_PACKET_TYPE_DIRECTED);

	if((m_pseudLpPacket = PacketAllocatePacket())==NULL)
	{
  	 	sprintf(m_message,"\nError:failed to allocate the LPPACKET structure."); 
	 	return;
	}	
	
	PacketInitPacket(m_pseudLpPacket,(char*)m_pseudBuffer, MAX_ETH_SIZE);

	//////////

	m_wanIPAddr_u32 = htonl(inet_addr(wanIPAddr));
	m_pseudIPAddr_u32 = htonl(inet_addr(pseudIPAddr));
	m_subWanIPAddr_u32 = htonl(inet_addr(subWanIPAddr));
	m_netWanAddr_u32 = (m_wanIPAddr_u32 & m_subWanIPAddr_u32);

	//////////

	m_pseudIFLock = CreateMutex(0, FALSE, "pseudIFLock");

}

PseudIF::~PseudIF()
{
	PacketFreePacket(m_pseudLpPacket);
	PacketCloseAdapter(m_pseudLpAdapter);

	printf(".....PseudIF is destructed.\n");
//	Sleep(1000);	

}

bool
PseudIF::releasePacket(void* packet, int dataLen)
{
	WaitForSingleObject(m_pseudIFLock, INFINITE);	

	// Release Preparation
	PacketInitPacket(m_pseudLpPacket, (void *)packet, dataLen);

	// Release !
	BOOLEAN truefalse = PacketSendPacket(m_pseudLpAdapter,m_pseudLpPacket,TRUE);

	ReleaseMutex(m_pseudIFLock);

	return true;
}
