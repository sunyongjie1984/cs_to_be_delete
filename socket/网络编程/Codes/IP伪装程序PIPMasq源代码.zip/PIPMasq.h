#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <process.h>
#include <iostream.h>

#include "packet32.h"

#define PROGRAMNAME		"Pseud IP Masquerade on Win32"
#define VERSION			"0.32" 

#define Max_Num_Adapter 10
#define ETH_ALEN		6		/* Octets in one ethernet addr	 */

#define UDP				0x11
#define TCP				0x06
#define ICMP			0x01		

#define	FTP				21
#define FTP_DATA		20
	
#define EXPIRE_PERIOD	900		// Seconds (15 mins)
#define ICMP_EXPIRE_PERIOD 20	// Seconds
#define	MAX_ETH_SIZE	1514

#define RECV_BUF		512000

typedef unsigned int __u32;
typedef unsigned short __u16;
typedef unsigned char __u8;


DWORD	ServiceThread(LPDWORD param);
void	install(void);
void	remove(void);


///// ThreadMgr //////

class ThreadMgr
{
public:
	ThreadMgr();
	~ThreadMgr();

	void	signalCatch(int sig);

	bool			m_lifeFlag;
};

///// PsudeoIF //////

class PseudIF
{
public:
	PseudIF(
		const char* wanIPAddr, 
		const char* pseudIPAddr,
		const char*	subWanIPAddr,
		unsigned const char* defaultGWMacAddr);

	~PseudIF();

	bool releasePacket(void* packet, int dataLen);

	__u32			m_wanIPAddr_u32; // Real IP Network byte
	__u32			m_pseudIPAddr_u32;	// Pseud IP Network byte
	__u32			m_subWanIPAddr_u32; // Subnet IP Network byte
	__u32			m_netWanAddr_u32; // ( = m_wanIPAddr_u32 & m_subWanIPAddr_u32);

	unsigned char	m_pseudMacAddr[ETH_ALEN];
	unsigned char	m_defaultGWMacAddr[ETH_ALEN];


private:
	char			m_wanIPAddr[16];
	char			m_wanAdapterName[512];
	unsigned char	m_wanMacAddr[ETH_ALEN];
	char			m_message[1024];

	LPADAPTER		m_pseudLpAdapter;
	LPPACKET		m_pseudLpPacket;
	char			m_pseudBuffer[5000];
	HANDLE			m_pseudIFLock;
};

///// CheckSumCalc ///////

class CheckSumCalc
{
protected:
	CheckSumCalc(){};
	~CheckSumCalc(){};

	unsigned short in_cksum(
		unsigned short *addr, int len);
	
	unsigned short tcpchecksum(
		struct tcphdr *_tcphdr, 
		struct iphdr *_iphdr, 
		int tcpDataLenInPacket);

	unsigned short udpchecksum(
		struct udphdr *_udphdr, 
		struct iphdr *_iphdr, 
		int udpDataLenInPacket);
};


///// ArpMgr /////
class ArpMgr
{
public:
	ArpMgr(PseudIF* pseudIF);
	~ArpMgr();

	bool arpSendRecv(__u32 hostTypeIPAddr32, char* mac_ethAlen);

	bool analizeArpPacket(char* pChar, int dataLen);
	bool analizeArpPacket2(char* pChar, int dataLen);


private:
	PseudIF* m_pseudIF;

	unsigned char	m_getMacAddr[ETH_ALEN];
	__u32			_ipAddr_u32_n;
	__u32			_ipAddr_u32_h;
	bool			m_waitFlag;
	HANDLE			m_arpLock_out,m_arpLock_in;
};


///// PingServer /////
class PingServer: public CheckSumCalc
{
public:
	PingServer(PseudIF* pseudIF);
	~PingServer();

	bool analizePingPacket(char* pChar, int dataLen);

private:
	PseudIF* m_pseudIF;
};




///// Port Mgr //////////


#define PORT_IGNORED	-1
#define BEGIN_RSV_PORT	60000
#define	RSV_PORT_ENTRY	5000

class PortMgr
{
public:
	PortMgr();
	~PortMgr();
	
	bool reservPort(__u8 Protocol, __u16 *port);
	bool cancelPort(__u8 Protocol, __u16 port);

private:
	int pUDPSocketIndex;
	int pTCPSocketIndex;
	int pICMPIndex;

	bool UDPSocketTable[RSV_PORT_ENTRY];
	bool TCPSocketTable[RSV_PORT_ENTRY];
	bool ICMPTable[RSV_PORT_ENTRY];
};


///// Table Mgr //////////

typedef enum refLevel
{
	L0,
	L1,
	L2
} RefLevel;


typedef struct TableEntry
{
	time_t			expireTime;				// Expire Time

	__u8			Protocol;				// TCP or UDP

	__u16			masqPort;				// Masqurate Port
	
	__u16			destPort;				// Destination Port
	__u32			destIPAddr;				// Destination IP Address
	unsigned char	destMACAddr[ETH_ALEN];	// Destination Mac Address
			
	__u16			srcPort;				// Source Port
	__u32			srcIPAddr;				// Source IP Address
	unsigned char	srcMACAddr[ETH_ALEN];	// Source Mac Address

	int				diff_ack;				// Only for FTP

	TableEntry *p_before;
	TableEntry *p_after;

} TableEntry;


class TableMgr
{
public:

	TableMgr(PortMgr* portMgr);
	~TableMgr();

	RefLevel refEntry(
		__u8			Protocol,				// TCP or UDP
		__u16			srcPort,				// Source Port
		__u32			srcIPAddr,				// Source IP Address
		__u16			destPort,				// Destination Port
		__u32			destIPAddr,				// Destination IP Address
		TableEntry*		*entry
	);

	bool	
	TableMgr::refEntry2(
			__u8			Protocol,				// TCP or UDP
			__u16			masqPort,				// Masq Port
			TableEntry*		*tableEntry				
	);

	bool addEntry(TableEntry *tableEntry);
	bool delEntry(time_t time);
	bool browseEntry(void);

	TableEntry	*top_of_TableEntry ;
	TableEntry	*end_of_TableEntry;
	HANDLE		tableLock;

private:
	PortMgr* m_portMgr;

	struct EntryPointer
	{
	    TableEntry *_entry;
	};
	
	int countEntry(void);
	void printOneEntry(TableEntry *entry);
	bool sortEntry(EntryPointer* entries, int num);
};
	

///// Time Mgr /////

#define TABLE_CHECK_TIME	60
#define TABLE_BROWSE_LOOP	5

class TimeMgr
{
public:
	TimeMgr(TableMgr*	tableMgr,
			ThreadMgr*	threadMgr);

	~TimeMgr();

	start();
private:
	TableMgr*		m_tableMgr;
	int				m_tableBrowseCounter;
	ThreadMgr*		m_threadMgr;
};


class FtpMgr
{
public:

	FtpMgr::FtpMgr(
		TableMgr*	tableMgr,
		PortMgr*	portMgr,
		const char* pseudIPAddr
	);

	void activeMode_out(char *pChar, int *dataLen, TableEntry* m_table);

	~FtpMgr();

private:
	TableMgr	*m_tableMgr;
	PortMgr		*m_portMgr;
	char		m_pseudIPAddr[16];
};



class COutward : public CheckSumCalc
{
public:
	COutward(
		TableMgr*	tableMgr, 
		PortMgr*	portMgr, 
		ArpMgr*		arpMgr,
		PseudIF*	pseudIF,
		ThreadMgr*	threadMgr,
		FtpMgr*		ftpMgr,

		const char* lanIPAddr,
		const char* wanIPAddr, 
		const char* subWanIPAddr, 
		const char* defaultWanGWAddr);
	
	~COutward();

	start();

	__u32			m_wanIPAddr_u32;	// Host byte
	unsigned char	m_wanMacAddr[ETH_ALEN];

private:
	bool			packetDelimiter();
	bool			analizeRawPacket(char* pChar, int dataLen);

	char			m_message[1024];
	
	char			m_lanIPAddr[16];
	char			m_wanIPAddr[16];

	__u32			m_lanIPAddr_u32;	// Host byte

	char			m_lanAdapterName[512];
	char			m_wanAdapterName[512];
	
	unsigned char	m_lanMacAddr[ETH_ALEN];	

	LPADAPTER		m_lanLpAdapter;

	LPPACKET		m_lanLpPacket;
	
	char			m_lanBuffer[256000];

	TableMgr*		m_tableMgr;
	PortMgr*		m_portMgr;
	PseudIF*		m_pseudIF;
	ArpMgr*			m_arpMgr;
	ThreadMgr*		m_threadMgr;
	FtpMgr*			m_ftpMgr;
};

class CInward : public CheckSumCalc
{
public:
	CInward(
		TableMgr*	tableMgr, 
		PortMgr*	portMgr,
		ArpMgr*		arpMgr,
		PingServer* pingSvr,
		PseudIF*	pseudIF,
		ThreadMgr*	threadMgr,		
		const char* lanIPAddr,
		const char* wanIPAddr,
		bool pingDown
		);

	~CInward();

	start();

private:
	bool			packetDelimiter();
	bool			analizeRawPacket(char* pChar, int dataLen);

	char			m_message[1024];
	
	char			m_lanIPAddr[16];
	char			m_wanIPAddr[16];

	__u32			m_lanIPAddr_u32;	// Host byte	
	__u32			m_wanIPAddr_u32;	// Host byte	
	
	char			m_lanAdapterName[512];
	char			m_wanAdapterName[512];
	
	unsigned char	m_lanMacAddr[ETH_ALEN];	
	unsigned char	m_wanMacAddr[ETH_ALEN];
	
	LPADAPTER		m_lanLpAdapter;
	LPADAPTER		m_wanLpAdapter;

	LPPACKET		m_lanLpPacket;
	LPPACKET		m_wanLpPacket;
	
	char			m_lanBuffer[MAX_ETH_SIZE];
	char			m_wanBuffer[256000];

	TableMgr*		m_tableMgr;
	PortMgr*		m_portMgr;
	ArpMgr*			m_arpMgr;
	PingServer*		m_pingServer;
	PseudIF*		m_pseudIF;
	bool			m_pingDown;
	ThreadMgr*		m_threadMgr;
};




///// Network //////////

#define ETH_P_IP	0x0800		/* Internet Protocol packet	*/

struct ethhdr 
{
	unsigned char	h_dest[ETH_ALEN];	/* destination eth addr	*/
	unsigned char	h_source[ETH_ALEN];	/* source ether addr	*/
	unsigned short	h_proto;			/* packet type ID field	*/
};

struct iphdr 
{
	__u8	ihl:4, 
		version:4;	// LITTLE_ENDIAN_BITFIELD ( for INTEL chip )

	__u8	tos;
	__u16	tot_len;
	__u16	id;
	__u16	frag_off;
	__u8	ttl;
	__u8	protocol;
	__u16	check;
	__u32	saddr;
	__u32	daddr;
};


struct pesudeIphdr
{
	__u32	saddr;
	__u32	daddr;
	__u8	zero;		// should be 0
	__u8	protocol;
	__u16	len;		// UDP/TCP data length
};



struct udphdr {
	__u16	source;
	__u16	dest;
	__u16	len;
	__u16	check;
};

struct tcphdr {
	__u16	source;
	__u16	dest;
	__u32	seq;
	__u32	ack_seq;
	__u16	res1:4,
		doff:4,
		fin:1,
		syn:1,
		rst:1,
		psh:1,
		ack:1,
		urg:1,
		res2:2;
	__u16	window;
	__u16	check;
	__u16	urg_ptr;
};


#define ICMP_ECHOREPLY		0	/* Echo Reply			*/
#define ICMP_ECHO			8	/* Echo Request			*/

struct icmphdr {
  __u8		type;
  __u8		code;
  __u16		checksum;
  union {
	struct {
		__u16	id;
		__u16	sequence;
	} echo;
	__u32	gateway;
	struct {
		__u16	__unused;
		__u16	mtu;
	} frag;
  } un;
};





#define ETH_P_ARP	0x0806		/* Address Resolution packet	*/
#define ETH_P_802_3	0x0001		/* Dummy type for 802.3 frames  */
#define	ARPOP_REQUEST	1		/* ARP request			*/
#define	ARPOP_REPLY	2			/* ARP reply			*/

struct arphdr
{
	unsigned short	ar_hrd;		/* format of hardware address	*/
	unsigned short	ar_pro;		/* format of protocol address	*/
	unsigned char	ar_hln;		/* length of hardware address	*/
	unsigned char	ar_pln;		/* length of protocol address	*/
	unsigned short	ar_op;		/* ARP opcode (command)		*/

	unsigned char	ar_sha[ETH_ALEN];	/* sender hardware address	*/
	unsigned char	ar_sip[4];			/* sender IP address		*/
	unsigned char	ar_tha[ETH_ALEN];	/* target hardware address	*/
	unsigned char	ar_tip[4];			/* target IP address		*/
};

struct arpPacket
{
	struct ethhdr	ethhdr;
	struct arphdr	arphdr;
};


#define	ARP_WAIT_TIME	500		/* Arp Response waiting time (ms) */

const char *_hostnameToDotIP(const char *IPAddr);

// This class is exported from the Arp.dll
class CArp {
public:
	CArp::CArp(
		const char* srcIPAddr,
		const char* subnetIPAddr,
		const char* defaultGWAddr,
		unsigned long waitTime = ARP_WAIT_TIME // 500
		);

	~CArp();

	bool isArpVaild();

	char* getLastMessage();

	bool arpSendRecv(const char* ipAddr, char* macAddr);
	bool arpSendRecv(__u32 hostTypeIPAddr32, char* mac_ethAlen);

private:

	bool			m_CArpFlag;

	bool getAdapterInfo(
		const char* nicIPAddress,	// input
		char* AdapterName,			// output
		unsigned char*	macAddr		// output
		);
	
	bool packetDelimiter(
		struct arpPacket *p_arp, unsigned char* ar_tip);

	bool analizeRawPacket(
		char *pChar, u_int dataLen, struct arpPacket *p_arp, unsigned char* ar_tip);

	LPADAPTER		m_lpAdapter; 
	LPPACKET		m_lpPacket;

	LPADAPTER		m_lpAdapter2; 
	LPPACKET		m_lpPacket2;

	char			m_buffer2[25600];  // buffer to hold the data coming from the driver

	char			m_message[1024];

	// string that contains a list of the network adapters
	char			m_adapterName[512];
	
	// local MAC Address
	unsigned char	m_macAddr[ETH_ALEN];
	char			m_ipAddr[16];
	char			m_subAddr[16];
	char			m_defgAddr[16];

	char			m_defgMacAddr[18];
	char			m_localMacAddr[18];

	__u32			m_subAddr_u32;
	__u32			m_defgAddr_u32;
	__u32			m_netAddr_u32;

	unsigned long	m_waitTime;

};


class ConsoleMgr
{
public:
	ConsoleMgr::ConsoleMgr(
		TableMgr *tableMgr, 
		ThreadMgr *threadMgr,
					   
		char* pseudIPAddr,
		char* lanIPAddr,
		char* wanIPAddr,
		char* subWanIPAddr,
		char* defaultWanGWAddr,
		bool  pingDown
	);

	~ConsoleMgr();

	start();

private:

	TableMgr *m_tableMgr;
	ThreadMgr *m_threadMgr;

	char*	 m_pseudIPAddr;
	char*	 m_lanIPAddr;
	char*	 m_wanIPAddr;
	char*	 m_subWanIPAddr;
	char*	 m_defaultWanGWAddr;
	bool	 m_pingDown;
};






class panic
{
public:
	panic(){};
	virtual ~panic(){};
};



struct wardInfo
{
	TableMgr*	tableMgr;
	PortMgr*	portMgr;
	PseudIF*	psuedIF;
	ArpMgr*		arpMgr;
	PingServer* pingSvr;
	ThreadMgr*	threadMgr;
	FtpMgr*		ftpMgr;

	char*		pseudIPAddr;
	char*		lanIPAddr;
	char*		wanIPAddr;
	char*		subWanIPAddr;
	char*		defaultWanGWAddr;
	
	bool		pingDown;
};
