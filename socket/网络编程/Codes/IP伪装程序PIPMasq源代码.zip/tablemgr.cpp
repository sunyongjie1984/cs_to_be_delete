#include "stdafx.h"
#include "PIPMasq.h"
#include <time.h>


bool rev_inet_addr(__u32 netByteIPAddr32, char *dotIP);


////////////////////////// TableMgr /////////////////////////////////

TableMgr::TableMgr(
	PortMgr*	portMgr
)
{
	m_portMgr = portMgr;
	
	top_of_TableEntry = (TableEntry *)malloc(sizeof(TableEntry));
	end_of_TableEntry = (TableEntry *)malloc(sizeof(TableEntry));
	
	top_of_TableEntry->p_before = NULL;
	top_of_TableEntry->p_after = end_of_TableEntry;
	
	end_of_TableEntry->p_before = top_of_TableEntry;
	end_of_TableEntry->p_after = NULL;
	
	tableLock = CreateMutex(0, FALSE, "tableLock");
}

TableMgr::~TableMgr()
{
	TableEntry *entry;

	if (top_of_TableEntry != NULL)
	{
		while(end_of_TableEntry->p_before != top_of_TableEntry)
		{
			entry = end_of_TableEntry;
			end_of_TableEntry = entry->p_before;

			free((void *)entry);
		}

		free((void *)end_of_TableEntry);
		free((void *)top_of_TableEntry);

		top_of_TableEntry = NULL;
	}
	
	CloseHandle(tableLock);


	printf(".....TableMgr is destructed.\n"); 
//	Sleep(1000);	
}


RefLevel	
TableMgr::refEntry(
		__u8			Protocol,				// TCP or UDP
		__u16			srcPort,				// Source Port
		__u32			srcIPAddr,				// Source IP Address
		__u16			destPort,				// Destination Port
		__u32			destIPAddr,				// Destination IP Address
		TableEntry*		*tableEntry				
)
{
	WaitForSingleObject(tableLock, INFINITE);

	TableEntry *entry = top_of_TableEntry->p_after;

	bool _flagL1 = false;
	TableEntry *entryL1;

	while(entry != end_of_TableEntry)
	{
		if ((entry->Protocol == Protocol) && 
			(entry->destPort == destPort) &&
			(entry->destIPAddr == destIPAddr))
		{		
			if ((entry->srcPort == srcPort) && 
				(entry->srcIPAddr == srcIPAddr ) )
			{
				*tableEntry = entry;
				ReleaseMutex(tableLock);
			
				return L2;
			}
			else
			{
				_flagL1 = true;
				entryL1 = entry;
			}
		}

		entry = entry->p_after;
	}

	ReleaseMutex(tableLock);

	if (_flagL1 == true)
	{
		*tableEntry = entryL1;
		return L1;
	}

	*tableEntry = NULL;
	return L0;

}

bool	
TableMgr::refEntry2(
		__u8			Protocol,				// TCP or UDP or ICMP
		__u16			masqPort,				// Masq Port
		TableEntry*		*tableEntry				
)
{
	WaitForSingleObject(tableLock, INFINITE);

	TableEntry *entry = top_of_TableEntry->p_after;

	while(entry != end_of_TableEntry)
	{
		if ((entry->Protocol == Protocol) && 
			(entry->masqPort == masqPort))
		{
			*tableEntry = entry;
			ReleaseMutex(tableLock);

			return true;
		}

		entry = entry->p_after;
	}

	ReleaseMutex(tableLock);

	*tableEntry = NULL;
	return false;
}





bool
TableMgr::addEntry(TableEntry *tableEntry)
{
	WaitForSingleObject(tableLock, INFINITE);

	TableEntry *entry = (TableEntry *)malloc(sizeof(TableEntry));

	if (entry == NULL)
		return false;

	memcpy(entry, tableEntry, sizeof(TableEntry));

	top_of_TableEntry->p_after->p_before = entry;
	entry->p_before = top_of_TableEntry;
	
	entry->p_after = top_of_TableEntry->p_after;
	top_of_TableEntry->p_after = entry;

	ReleaseMutex(tableLock);
	
	return true;
}

bool
TableMgr::delEntry(time_t now)
{
	WaitForSingleObject(tableLock, INFINITE);

	TableEntry *entry = top_of_TableEntry->p_after;

	while(entry != end_of_TableEntry)
	{
		TableEntry *entry_p_after;
		bool passFlag =false;

		if (entry->expireTime <= now )
		{
			// delete the entry
			entry->p_before->p_after = entry->p_after;
			entry->p_after->p_before = entry->p_before;

			passFlag = true;
			entry_p_after = entry->p_after;
			
			// Release Port Number
			m_portMgr->cancelPort(entry->Protocol, ntohs(entry->masqPort));
			free((void *)entry);
		}
		
		if (passFlag == true)
			entry = entry_p_after;
		else
			entry = entry->p_after;
	}

	ReleaseMutex(tableLock);

	return true;
}

void
TableMgr::printOneEntry(TableEntry *entry)
{
    static char 	dotIPsrcIPAddr[16];
    static char 	dotIPdestIPAddr[16];
    static char		strTCP[] = "tcp";
    static char		strUDP[] = "udp";
    static char		strICMP[] = "icmp";
    static char		strUnknown[] = "unknown";
    static char		*strProtocol;
    
    rev_inet_addr(entry->srcIPAddr, dotIPsrcIPAddr);
    rev_inet_addr(entry->destIPAddr, dotIPdestIPAddr);
    
    switch( entry->Protocol )
    {
    case TCP:
		strProtocol = strTCP;
		break;
    case UDP:
		strProtocol = strUDP;
		break;
    case ICMP:
		strProtocol = strICMP;
		break;
    default:
		strProtocol = strUnknown;
    }
    
    time_t ct = entry->expireTime;
    struct tm *lst = localtime(&ct);
    
    
    printf(" %-6s  %02d:%02d:%02d  %-16s %-16s %d(%d)->%d\n",
		strProtocol,
		lst->tm_hour,	
		lst->tm_min,	
		lst->tm_sec,	
		dotIPsrcIPAddr,
		dotIPdestIPAddr,
		ntohs(entry->srcPort),
		ntohs(entry->masqPort),
		ntohs(entry->destPort)
		);
}

int
TableMgr::countEntry(void)
{
	int num = 0;
	TableEntry *entry = top_of_TableEntry->p_after;
	while(entry != end_of_TableEntry)
	{
	    entry = entry->p_after;
	    num++;
	}

	return num;
}

bool
TableMgr::sortEntry(EntryPointer* entries, int num)
{
    if(num < 2) return true;
	
    int i, j;
    EntryPointer ep;
    for (i = 0; i < num - 1; i++)
    {
		for (j = 0; j < num - i - 1; j++)
		{
			if (entries[j]._entry->expireTime < entries[j + 1]._entry->expireTime)
			{
				ep = entries[j];
				entries[j]   = entries[j+1];
				entries[j+1] = ep;
			}
		}
    }
    return true;
}

bool
TableMgr::browseEntry(void)
{

	printf("\n Pseud IP masquerading entries\n");
	printf(" prot    expire    source           destination      ports\n");
	printf(" ----------------------------------------------------------------------\n");

	WaitForSingleObject(tableLock, INFINITE);

	TableEntry *entry = top_of_TableEntry->p_after;

	while(entry != end_of_TableEntry)
	{
		int num = countEntry();
		if (num > 0) 
		{
			EntryPointer *sortedEntry;
			sortedEntry = (EntryPointer *)malloc(sizeof(EntryPointer) * num);
		
			int i = 0;
			entry = top_of_TableEntry->p_after;
			
			for(i = 0; i < num; i++) {
				sortedEntry[i]._entry = entry;
				entry = entry->p_after;
			}
			
			sortEntry(sortedEntry, num);
			
			for(i = 0; i < num; i++)
			{
				printOneEntry(sortedEntry[i]._entry);
			}
			
			free (sortedEntry);
		}
	}
	printf("\n");

	ReleaseMutex(tableLock);

	return true;
}
