// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__8403F6FF_34F3_11D4_9A56_0050BABA55BC__INCLUDED_)
#define AFX_MAINFRM_H__8403F6FF_34F3_11D4_9A56_0050BABA55BC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Input.h"
#include <winsock.h>

class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:
	SOCKET	m_sck;
	HWND	m_hwndViewEdit;
	CInput		m_wndInput;
	BYTE		b1, b2, b3, b4;
	CString		m_strYourName;
	int			m_nPort;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	void StartListen();
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSend();
	afx_msg void OnOption();
	afx_msg void OnDestroy();
	afx_msg void OnConnect();
	afx_msg void OnDisconnect();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

typedef struct tagTHREADPARAM{
	HWND	hWnd;
	int	nPort;
	SOCKET	*pSck;
	char	pszName[32];
}THREADPARAM;

typedef struct tagRECVTHREAD{
	HWND hWnd;
	SOCKET sck;
}RECVTHREAD;
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__8403F6FF_34F3_11D4_9A56_0050BABA55BC__INCLUDED_)
