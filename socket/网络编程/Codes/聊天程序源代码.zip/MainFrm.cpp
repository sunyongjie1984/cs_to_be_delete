// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Chat.h"
#include "Option.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define PUT(pszStr) ::SendMessage(pThreadParam->hWnd, EM_REPLACESEL, true, (LPARAM)(pszStr))
#define OUTPUT(str) ::SendMessage(m_hwndViewEdit, EM_REPLACESEL, true, (LPARAM)(str))
/////////////////////////////////////////////////////////////////////////////
HANDLE g_hBusy;
THREADPARAM threadParam;
RECVTHREAD recvThread;

UINT RecvThread(LPVOID lpVoid)
{
	char buf[512];
	char pszMsg[512];
	char pszName[32];
	int iRet;
	RECVTHREAD * pThreadParam = (RECVTHREAD*)lpVoid;
	PUT("RecvThread started.\r\n");

	iRet = recv(pThreadParam->sck, buf, 511, 0);
	buf[iRet] = NULL;
	strcpy(pszName, buf);
	OUT("["); OUT(pszName); OUT("]");
	OUT("is your partner.\r\n");

	do{
		iRet = recv(pThreadParam->sck, buf, 511, 0);
		if(iRet==SOCKET_ERROR)
		{
			PUT("RecvThread/recv()=SOCKET_ERROR\t");
			sprintf(pszMsg, "WSAGetLastError()=%d\r\nRecvThread terminated.\r\n", WSAGetLastError());
			PUT(pszMsg);
			ReleaseSemaphore(g_hBusy, 1, NULL);
			closesocket(pThreadParam->sck);
			return 0;
		}
		buf[iRet] = NULL;
		PUT(pszName);PUT(":\t");
		PUT(buf);
	}while(iRet);
	return 0;
}

UINT ListenThread(LPVOID lpVoid)
{
	char pszMsg[512];
	int addrlen, iRet;
	SOCKET sckListen, sckAccept;
	DWORD dwRet;
	hostent* pEnt;
	sockaddr_in addr;
	THREADPARAM* pThreadParam = (THREADPARAM*)lpVoid;
	RECVTHREAD *pRecvThread;

	PUT("Listenning thread started.\r\n");

	iRet = gethostname(pszMsg, 256);
	if(iRet)
	{
		sprintf(pszMsg, "Error occur when gethostname(), WSAGetLastError()=%d\r\nListening Thread terminated.\r\n", WSAGetLastError());
		PUT(pszMsg);
		return 0;
	}

	pEnt =gethostbyname(pszMsg);
	if(!pEnt)
	{
		sprintf(pszMsg, "Error occur when gethostbyname(), WSAGetLastError()=%d\r\nListening Thread terminated.\r\n", WSAGetLastError());
		PUT(pszMsg);
		return 0;
	}

	addr.sin_family = AF_INET;
	addr.sin_port = htons(pThreadParam->nPort);
	addr.sin_addr.S_un.S_un_b.s_b1 = pEnt->h_addr_list[0][0];
	addr.sin_addr.S_un.S_un_b.s_b2 = pEnt->h_addr_list[0][1];
	addr.sin_addr.S_un.S_un_b.s_b3 = pEnt->h_addr_list[0][2];
	addr.sin_addr.S_un.S_un_b.s_b4 = pEnt->h_addr_list[0][3];

	sckListen = socket(AF_INET, SOCK_STREAM, 0);
	if(sckListen==INVALID_SOCKET)
	{
		PUT("Failed to create listenning socket.");
		sprintf(pszMsg, "WSAGetLastError()=%d\tm_sck=%d\r\n", WSAGetLastError(), sckListen);
		PUT(pszMsg);
		return 0;
	}
	else
		PUT("create socket successfully.\r\n");

	iRet = bind(sckListen, (sockaddr*)&addr, sizeof(addr));
	if(iRet==SOCKET_ERROR)
	{
		PUT("Failed to bind listenning socket to local host\r\n");
		sprintf(pszMsg, "WSAGetLastError()=%d\r\n", WSAGetLastError());
		PUT(pszMsg);
	}

	iRet = listen(sckListen, SOMAXCONN);
	if(iRet==SOCKET_ERROR)
	{
		PUT("listen return SOCKET_ERROR\r\n");
		return 0;
	}

	while(1)
	{
		addrlen = sizeof(addr);
		sckAccept = accept(sckListen, (sockaddr*)&addr, &addrlen);
		if(sckAccept==INVALID_SOCKET)
		{
			PUT("accept()=INVALID_SOCKET");
			sprintf(pszMsg, "WSAGetLastError()=%d\r\n", WSAGetLastError());
			PUT(pszMsg);
		}
		dwRet = WaitForSingleObject(g_hBusy, 1000);
		if(dwRet==WAIT_TIMEOUT)
		{
			send(sckAccept, "\1", 1, 0);
			closesocket(sckAccept);
			PUT("Someone call you when you are busy.\r\n");
			continue;
		}

		PUT("One partner accepted successfully.\r\n");
		pRecvThread = new RECVTHREAD;
		pRecvThread->hWnd = pThreadParam->hWnd;
		pRecvThread->sck = sckAccept;
		*pThreadParam->pSck= sckAccept;
		*pszMsg = 0;
		strcpy(pszMsg+1, pThreadParam->pszName);
		send(sckAccept, pszMsg, 1+strlen(pszMsg+1), 0);
		AfxBeginThread(RecvThread, (LPVOID)pRecvThread, THREAD_PRIORITY_IDLE);
	}
	return 0;
}
/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(IDC_SEND, OnSend)
	ON_COMMAND(ID_OPTION, OnOption)
	ON_WM_DESTROY()
	ON_COMMAND(IDC_CONNECT, OnConnect)
	ON_COMMAND(IDC_DISCONNECT, OnDisconnect)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_sck = NULL;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	if (!m_wndInput.Create(this, IDD_INPUT,
		CBRS_BOTTOM|CBRS_TOOLTIPS|CBRS_FLYBY, IDD_INPUT))
	{
		TRACE0("Failed to create DlgBar\n");
		return -1;      // fail to create
	}


	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	m_wndInput.SetEditFocus();

	// HKEY_CURRENT_USER\Software\Max Studio
	HKEY hKey;
	unsigned long ulIP;
	DWORD dwSize, dwType;
	char pszName[32];
	if(RegCreateKey(HKEY_CURRENT_USER, "Software\\Max Studio\\Chat", &hKey)!=ERROR_SUCCESS)
	{
		b1 = 192;
		b2 = 168;
		b3 = 1;
		b4 = 1;
		m_strYourName = "YourName";
		m_nPort = 2501;
	}
	else
	{
		dwSize = sizeof(unsigned long);
		if(RegQueryValueEx(hKey, "ipDestination", 0, &dwType, (unsigned char*)&ulIP, &dwSize)!=ERROR_SUCCESS)
		{
			b1 = 192;
			b2 = 168;
			b3 = 1;
			b4 = 1;
		}
		else
		{
			b1 = (0xFF000000 & ulIP) >> 24;
			b2 = (0xFF0000 & ulIP) >> 16;
			b3 = (0xFF00 & ulIP) >> 8;
			b4 = 0xFF & ulIP;
		}

		dwSize = 32;
		if(RegQueryValueEx(hKey, "m_strYourName", 0, &dwType, (unsigned char*)pszName, &dwSize)!=ERROR_SUCCESS)
		{
			m_strYourName = "YourName";
		}
		else
			m_strYourName = (CString)pszName;
		
		dwSize = sizeof(int);
		if(RegQueryValueEx(hKey, "m_nPort", 0, &dwType, (unsigned char*)&m_nPort, &dwSize)!=ERROR_SUCCESS)
			m_nPort = 2501;

		RegCloseKey(hKey);
	}

	g_hBusy = CreateSemaphore(NULL, 1, 1, NULL);
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnSend() 
{
	// TODO: Add your command handler code here
	CString str;
	int iRet;

	m_wndInput.GetLine(str);
	str += "\r\n";
	if(m_sck)
	{
		iRet = send(m_sck, (LPCTSTR)str, str.GetLength(), 0);
		if(iRet==SOCKET_ERROR)
		{
			OUTPUT("Error when send string.\r\n");
			closesocket(m_sck);
			m_sck=NULL;
			return;
		}
	}

	::SendMessage(m_hwndViewEdit, EM_REPLACESEL, true, (LPARAM)(LPCTSTR)m_strYourName);
	::SendMessage(m_hwndViewEdit, EM_REPLACESEL, true, (LPARAM)":\t");
	::SendMessage(m_hwndViewEdit, EM_REPLACESEL, true, (LPARAM)(LPCTSTR)str);
	m_wndInput.SetEditFocus();
}

void CMainFrame::OnOption() 
{
	COption dlg;
	dlg.m_nPort = m_nPort;
	dlg.m_strYourName = m_strYourName;
	dlg.b1 = b1;
	dlg.b2 = b2;
	dlg.b3 = b3;
	dlg.b4 = b4;

	if(dlg.DoModal()==IDOK)
	{
		m_nPort = dlg.m_nPort;
		m_strYourName = dlg.m_strYourName;
		b1 = dlg.b1;
		b2 = dlg.b2;
		b3 = dlg.b3;
		b4 = dlg.b4;
	}
}

void CMainFrame::OnDestroy() 
{
	CFrameWnd::OnDestroy();
	// HKEY_CURRENT_USER\Software\Max Studio
	HKEY hKey;
	unsigned long ulIP;
	if(RegCreateKey(HKEY_CURRENT_USER, "Software\\Max Studio\\Chat", &hKey)==ERROR_SUCCESS)
	{
		RegSetValueEx(hKey, "m_strYourName", 0, REG_SZ, (BYTE*)(LPCTSTR)m_strYourName, m_strYourName.GetLength());
		RegSetValueEx(hKey, "m_nPort", 0, REG_DWORD, (BYTE*)&m_nPort, sizeof(int));

		ulIP = b1<<24 | b2<<16 | b3<<8 | b4;
		RegSetValueEx(hKey, "ipDestination", 0, REG_DWORD, (BYTE*)&ulIP, sizeof(DWORD));
	}
}

void CMainFrame::OnConnect() 
{
	int iRet;
	DWORD dwRet;
	BYTE byRet;
	sockaddr_in addr;
	char pszMsg[512];

	dwRet = WaitForSingleObject(g_hBusy, 1000);
	if(dwRet==WAIT_TIMEOUT)
	{
		OUTPUT("Telephone is busy\r\n");
		return;
	}

	m_sck = socket(AF_INET, SOCK_STREAM, 0);
	if(m_sck==INVALID_SOCKET)
	{
		OUTPUT("Failed to create socket.");
		sprintf(pszMsg, "WSAGetLastError()=%d\tm_sck=%d\r\n", WSAGetLastError(), m_sck);
		OUTPUT(pszMsg);
		m_sck = NULL;
		ReleaseSemaphore(g_hBusy, 1, NULL);
		return;
	}
	else
		OUTPUT("create socket successfully.\r\n");

	addr.sin_family = AF_INET;
	addr.sin_port = htons(m_nPort);
	addr.sin_addr.S_un.S_un_b.s_b1 = b1;
	addr.sin_addr.S_un.S_un_b.s_b2 = b2;
	addr.sin_addr.S_un.S_un_b.s_b3 = b3;
	addr.sin_addr.S_un.S_un_b.s_b4 = b4;
	sprintf(pszMsg, "Connecting to %d.%d.%d.%d\r\n............\r\n", b1, b2, b3, b4);
	OUTPUT(pszMsg);
	iRet = connect(m_sck, (sockaddr*)&addr, sizeof(addr));
	if(iRet==SOCKET_ERROR)
	{
		OUTPUT("Failed to connect to destination.");
		sprintf(pszMsg, "WSAGetLastError()=%d\tm_sck=%d\r\n", WSAGetLastError(), m_sck);
		OUTPUT(pszMsg);
		closesocket(m_sck);
		m_sck = NULL;
		ReleaseSemaphore(g_hBusy, 1, NULL);
		return;
	}
	else
	{
		OUTPUT("Connect to destination successfully.\r\n");
		recvThread.hWnd = m_hwndViewEdit;
		recvThread.sck = m_sck;
		recv(m_sck, (char*)&byRet, 1, 0);
		if(byRet)
		{
			closesocket(m_sck);
			m_sck = NULL;
			ReleaseSemaphore(g_hBusy, 1, NULL);
			OUTPUT("Destination is busy.\r\n");
			return;
		}

		send(m_sck, (LPCTSTR)m_strYourName, m_strYourName.GetLength(), 0);
		AfxBeginThread(RecvThread, (LPVOID)&recvThread, THREAD_PRIORITY_IDLE);
	}
}

void CMainFrame::StartListen()
{
	WSADATA data;
	int iRet = WSAStartup(MAKEWORD(2, 2), &data);
	if(iRet)
	{
		OUTPUT("WSAStartup error\r\n");
	}

	threadParam.hWnd = m_hwndViewEdit;
	threadParam.nPort = m_nPort;
	threadParam.pSck = &m_sck;
	strcpy(threadParam.pszName, m_strYourName);
	AfxBeginThread(ListenThread, (LPVOID)&threadParam, THREAD_PRIORITY_IDLE);
	return;
}

void CMainFrame::OnDisconnect() 
{
	closesocket(m_sck);
}
