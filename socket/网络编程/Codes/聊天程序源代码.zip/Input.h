#if !defined(AFX_INPUT_H__8403F70D_34F3_11D4_9A56_0050BABA55BC__INCLUDED_)
#define AFX_INPUT_H__8403F70D_34F3_11D4_9A56_0050BABA55BC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Input.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CInput dialog

class CInput : public CDialogBar
{
// Construction
public:
	void GetLine(CString& str);
	void SetEditFocus();
	CWnd*	m_pEdit;
	CInput();   // standard constructor

// Dialog Data
	//{{AFX_DATA(CInput)
	enum { IDD = IDD_INPUT };
	CEdit	m_editLine;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInput)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInput)
	virtual BOOL OnInitDialog();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INPUT_H__8403F70D_34F3_11D4_9A56_0050BABA55BC__INCLUDED_)
