//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Chat.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_INPUT                       103
#define IDR_MAINFRAME                   128
#define IDR_CHATTYPE                    129
#define IDD_OPTION                      130
#define IDC_IP_DESTINATION              1001
#define IDC_NAME                        1003
#define IDC_PORT                        1004
#define IDC_LINE                        1005
#define IDC_SEND                        1006
#define ID_OPTION                       32771
#define IDC_CONNECT                     32772
#define IDC_DISCONNECT                  32773
#define ID_CLEAR                        32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
