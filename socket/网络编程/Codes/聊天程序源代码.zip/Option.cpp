// Option.cpp : implementation file
//

#include "stdafx.h"
#include "Chat.h"
#include "Option.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COption dialog


COption::COption(CWnd* pParent /*=NULL*/)
	: CDialog(COption::IDD, pParent)
{
	//{{AFX_DATA_INIT(COption)
	m_strYourName = _T("");
	m_nPort = 0;
	//}}AFX_DATA_INIT
}


void COption::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COption)
	DDX_Control(pDX, IDC_IP_DESTINATION, m_ipDestination);
	DDX_Text(pDX, IDC_NAME, m_strYourName);
	DDX_Text(pDX, IDC_PORT, m_nPort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COption, CDialog)
	//{{AFX_MSG_MAP(COption)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COption message handlers

BOOL COption::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_ipDestination.SetAddress(b1, b2, b3, b4);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void COption::OnOK() 
{
	m_ipDestination.GetAddress(b1, b2, b3, b4);
	CDialog::OnOK();
}
