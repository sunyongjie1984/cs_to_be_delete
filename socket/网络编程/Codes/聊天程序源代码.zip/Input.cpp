// Input.cpp : implementation file
//

#include "stdafx.h"
#include "Chat.h"
#include "Input.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInput dialog


CInput::CInput()
	: CDialogBar()
{
	//{{AFX_DATA_INIT(CInput)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CInput::DoDataExchange(CDataExchange* pDX)
{
	CDialogBar::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInput)
	DDX_Control(pDX, IDC_LINE, m_editLine);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInput, CDialogBar)
	//{{AFX_MSG_MAP(CInput)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInput message handlers

BOOL CInput::OnInitDialog() 
{
//	CDialogBar::OnInitDialog();
	
	GetDlgItem(IDC_SEND)->EnableWindow(true);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

int CInput::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialogBar::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	return 0;
}

void CInput::SetEditFocus()
{
	GetDlgItem(IDC_LINE)->SetFocus();
	((CEdit*)GetDlgItem(IDC_LINE))->SetSel(0, -1);
}

void CInput::GetLine(CString &str)
{
	GetDlgItem(IDC_LINE)->GetWindowText(str);
}
