#if !defined(AFX_OPTION_H__8403F70B_34F3_11D4_9A56_0050BABA55BC__INCLUDED_)
#define AFX_OPTION_H__8403F70B_34F3_11D4_9A56_0050BABA55BC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Option.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COption dialog

class COption : public CDialog
{
// Construction
public:
	BYTE b1, b2, b3, b4;
	COption(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(COption)
	enum { IDD = IDD_OPTION };
	CIPAddressCtrl	m_ipDestination;
	CString	m_strYourName;
	int		m_nPort;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COption)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(COption)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTION_H__8403F70B_34F3_11D4_9A56_0050BABA55BC__INCLUDED_)
