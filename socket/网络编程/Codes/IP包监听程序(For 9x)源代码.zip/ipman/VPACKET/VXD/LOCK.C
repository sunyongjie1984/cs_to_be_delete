// lock.c - PacketPageLock, PacketPageUnlock
//          

// Original code by William Ingle (address unknown)
// debugged and extended by Chris Chlap (chrisc@fir.canberra.edu.au)

#define WANTVXDWRAPS

#include <basedef.h>
#include <vmm.h>
#include <vxdwraps.h>               // must come last

#pragma VxD_LOCKED_CODE_SEG
#pragma VxD_LOCKED_DATA_SEG

//--------------------------------------------------------------------
//
//  PacketPageLock - lock a page
//
//--------------------------------------------------------------------

DWORD _stdcall PacketPageLock(DWORD lpMem, DWORD cbSize)
{
   DWORD LinPageNum, LinOffset, nPages;

   LinOffset = lpMem & 0xfff; // page offset of memory to map
   LinPageNum = lpMem >> 12;  // generate page number

   // Calculate # of pages to map globally

   nPages = ((lpMem + cbSize) >> 12) - LinPageNum + 1;

   //
   // Return global mapping of passed in pointer, as this new pointer
   // is how the memory must be accessed out of context.
   //

   return (_LinPageLock(LinPageNum, nPages, PAGEMAPGLOBAL) + LinOffset);
}

//--------------------------------------------------------------------
//
//  PacketPageUnlock - unlock a page
//
//--------------------------------------------------------------------

void _stdcall PacketPageUnlock(DWORD lpMem, DWORD cbSize)
{
   DWORD LinPageNum, nPages;

   LinPageNum = lpMem >> 12;
   nPages = ((lpMem + cbSize) >> 12) - LinPageNum + 1;

   // Free globally mapped memory

   _LinPageUnlock(LinPageNum, nPages, PAGEMAPGLOBAL);
}
