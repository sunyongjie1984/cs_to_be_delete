// request.c - PacketRequest, PacketRequestComplete 
//           
//           

// Original code by William Ingle (address unknown)
// debugged and extended by Chris Chlap (chrisc@fir.canberra.edu.au)

#include <basedef.h>
#include <vmm.h>
#include <debug.h>
#include <ndis.h>
#include <vwin32.h>

#include "packet.h"
#include "ntddpack.h"

#pragma VxD_LOCKED_CODE_SEG
#pragma VxD_LOCKED_DATA_SEG

//--------------------------------------------------------------------
//
//  PacketRequest - perform a packet request
//
//--------------------------------------------------------------------

DWORD PacketRequest(POPEN_INSTANCE  Open,
                    DWORD           FunctionCode,
                    DWORD           dwDDB,
                    DWORD           hDevice,
                    PDIOCPARAMETERS pDiocParms)
{
    PLIST_ENTRY       RequestListEntry;
    PINTERNAL_REQUEST pRequest;
	PPACKET_RESERVED  pReserved;
    PPACKET_OID_DATA  OidData;
    NDIS_STATUS       Status;

	//
	// Acquire request element from list
	//

    NdisAcquireSpinLock(&Open->RequestSpinLock);

    if (IsListEmpty(&Open->RequestList)) { 
        *(DWORD *)(pDiocParms->lpcbBytesReturned) = 0;
        NdisReleaseSpinLock(&Open->RequestSpinLock);
Debug_Out("PacketRequest: ERROR: request list empty\n"); 
        return NDIS_STATUS_SUCCESS;
	}
    else {
        RequestListEntry = RemoveHeadList(&Open->RequestList);
        NdisReleaseSpinLock(&Open->RequestSpinLock);
    }

    pReserved = CONTAINING_RECORD(RequestListEntry, PACKET_RESERVED, ListElement);
    pRequest  = CONTAINING_RECORD(pReserved, INTERNAL_REQUEST, Reserved);
	OidData   = (PPACKET_OID_DATA)(pDiocParms->lpvInBuffer);
	
    if ((pDiocParms->cbInBuffer == pDiocParms->cbOutBuffer) &&
        (pDiocParms->cbInBuffer >= sizeof(PACKET_OID_DATA) - 1 
        + OidData->Length)) {
        //
        // The buffer is valid
        //
        pReserved->lpBuffer          = (PVOID)PacketPageLock(pDiocParms->lpvInBuffer, pDiocParms->cbInBuffer);

        pReserved->lpcbBytesReturned = (PVOID)PacketPageLock((PVOID)pDiocParms->lpcbBytesReturned, sizeof(DWORD));

        pReserved->lpoOverlapped     = (PVOID)PacketPageLock((PVOID)pDiocParms->lpoOverlapped, sizeof(OVERLAPPED));

        pReserved->cbBuffer          = pDiocParms->cbInBuffer;
        pReserved->hDevice           = pDiocParms->hDevice;
        pReserved->tagProcess        = pDiocParms->tagProcess;

        OidData = (PPACKET_OID_DATA) (pReserved->lpBuffer); // Thanks to Arnoud Zwemmer
        
        if (FunctionCode == IOCTL_PROTOCOL_SET_OID) {                      
            pRequest->Request.RequestType                                  = NdisRequestSetInformation;
            pRequest->Request.DATA.SET_INFORMATION.Oid                     = OidData->Oid;
            pRequest->Request.DATA.SET_INFORMATION.InformationBufferLength = OidData->Length;
            pRequest->Request.DATA.SET_INFORMATION.InformationBuffer       = OidData->Data;
        } 
        else 
        if (FunctionCode == IOCTL_PROTOCOL_QUERY_OID) {
            pRequest->Request.RequestType                                    = NdisRequestQueryInformation;
            pRequest->Request.DATA.QUERY_INFORMATION.Oid                     = OidData->Oid;
            pRequest->Request.DATA.QUERY_INFORMATION.InformationBufferLength = OidData->Length;
            pRequest->Request.DATA.QUERY_INFORMATION.InformationBuffer       = OidData->Data;
        }
        else {
        pRequest->Request.RequestType                                      = NdisRequestGeneric1;
                                                                            // NdisRequestQueryStatistics;
        pRequest->Request.DATA.QUERY_INFORMATION.Oid                       = OidData->Oid;
        pRequest->Request.DATA.QUERY_INFORMATION.InformationBufferLength   = OidData->Length;
        pRequest->Request.DATA.QUERY_INFORMATION.InformationBuffer         = OidData->Data;
        }

        //
        // submit the request
        //

        NdisRequest(&Status, Open->AdapterHandle, &pRequest->Request);

        if (Status != NDIS_STATUS_PENDING) {
            PacketRequestComplete(Open, &pRequest->Request, Status);
			return NDIS_STATUS_SUCCESS;
		}
        return(-1);      // This will make DeviceIOControl return ERROR_IO_PENDING
    }
    else {
Debug_Out("PacketRequest: ERROR: invalid request\n"); 
		*(DWORD *)(pDiocParms->lpcbBytesReturned) = 0;
	}
	return NDIS_STATUS_SUCCESS;
}

//--------------------------------------------------------------------
//
//  PacketRequestComplete - perform a packet request complete
//
//--------------------------------------------------------------------

VOID NDIS_API PacketRequestComplete(IN NDIS_HANDLE   ProtocolBindingContext,
                                    IN PNDIS_REQUEST NdisRequest,
                                    IN NDIS_STATUS   Status)
{
    POPEN_INSTANCE    Open;
    PINTERNAL_REQUEST pRequest;
    PPACKET_RESERVED  pReserved;
    OVERLAPPED*       pOverlap;
	PPACKET_OID_DATA  oidData;

    Open        = (POPEN_INSTANCE)ProtocolBindingContext;
    pRequest    = CONTAINING_RECORD(NdisRequest, INTERNAL_REQUEST, Request);
    pReserved   = &pRequest->Reserved;
    pOverlap    = (OVERLAPPED *) pReserved->lpoOverlapped;
	oidData		= (PPACKET_OID_DATA)(pReserved->lpBuffer);


    if (Status == NDIS_STATUS_SUCCESS) {
		//
		// set total bytes returned
		//
		*(pReserved->lpcbBytesReturned)	= oidData->Length + sizeof(PACKET_OID_DATA) - 1;
        pOverlap->O_InternalHigh        = *(pReserved->lpcbBytesReturned);
	}
    else {
		//
		// set total bytes returned
		//
		*(pReserved->lpcbBytesReturned)	= 0;
        pOverlap->O_InternalHigh        = *(pReserved->lpcbBytesReturned);

		//
		// return status in oidData if there is an error 
		//		
		oidData->Length = Status;
	}

	//
    // The internal member of overlapped structure contains
    // a pointer to the event structure that will be signalled,
    // resuming the execution of the waitng GetOverlappedResult
    // call.
    //
    VWIN32_DIOCCompletionRoutine(pOverlap->O_Internal);

	// Unlock buffers	
    PacketPageUnlock(pReserved->lpBuffer, pReserved->cbBuffer);
    PacketPageUnlock(pReserved->lpcbBytesReturned, sizeof(DWORD));
    PacketPageUnlock(pReserved->lpoOverlapped, sizeof(OVERLAPPED));

	//
	// Return request element to list
	//
    NdisAcquireSpinLock(&Open->RequestSpinLock);

    InsertTailList(&Open->RequestList, &pReserved->ListElement);

    NdisReleaseSpinLock(&Open->RequestSpinLock);
    return;
}
