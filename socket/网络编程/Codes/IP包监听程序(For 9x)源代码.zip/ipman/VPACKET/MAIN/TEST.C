/****************************************************************************
*
* PROGRAM: TEST.C
*
* PURPOSE: Simple console application to demonstrate the use of Vpacket
*
****************************************************************************/


#include <stdio.h>
#include <windows.h>

#include "ntddpack.h"
#include "conpack.h"

#define ERROR_OUT(str) { printf(str); CloseHandle(hEvent); return(0); }

BYTE InBuff[ sizeof(PACKET_OID_DATA) + 128 ];

DWORD GetPacket(HANDLE hVxD, 
                ULONG ioctl,
                BYTE* inBuffer, 
                DWORD cbIn, 
                BYTE* outBuffer, 
                DWORD cbOut )
{
    HANDLE          hEvent  = 0;
    DWORD           cbRet   = 0;
    OVERLAPPED      ovlp    = {0,0,0,0,0};
    int result;

    if (!(hEvent = CreateEvent(0, TRUE, 0, NULL)))
        ERROR_OUT("CreateEvent failed!\n")

    ovlp.hEvent = hEvent;
    
    result = DeviceIoControl(hVxD, ioctl, inBuffer, cbIn, outBuffer, cbOut, &cbRet, &ovlp);
    if (!result)
        GetOverlappedResult(hVxD, &ovlp, &cbRet, TRUE);

    return cbRet;
}

DWORD Bind(HANDLE hVxD, BYTE* inBuffer)
{
    HANDLE          hEvent  = 0;
    DWORD           cbRet   = 0;
    OVERLAPPED      ovlp    = {0,0,0,0,0};
    int result;
    int cbIn = 5;
    
    if (!(hEvent = CreateEvent(0, TRUE, 0, NULL)))
        ERROR_OUT("CreateEvent failed!\n")

    ovlp.hEvent = hEvent;
    
    result = DeviceIoControl(hVxD, IOCTL_PROTOCOL_BIND, inBuffer, cbIn, inBuffer, cbIn, &cbRet, &ovlp);

    if (!result)
        GetOverlappedResult(hVxD, &ovlp, &cbRet, TRUE);

    return cbRet;
}

DWORD QueryPacket(HANDLE hVxD, 
						 ULONG ioctl, 
						 BYTE* inBuffer, 
						 DWORD cbIn, 
						 BYTE* outBuffer, 
						 DWORD cbOut )
{
    HANDLE      hEvent = 0;
    DWORD       cbRet;
    OVERLAPPED  ovlp = {0,0,0,0,0};
   
    if (!(hEvent = CreateEvent(0, TRUE, 0, NULL)))
        ERROR_OUT("CreateEvent failed!\n")

    ovlp.hEvent = hEvent;
    
    if (!DeviceIoControl(hVxD, ioctl, inBuffer, cbIn, outBuffer, cbOut, &cbRet, &ovlp)) {
        if (GetLastError() == ERROR_IO_PENDING)                         
            printf( "VxD correctly returned operation incomplete.\n" );
        else
            ERROR_OUT( "VxD does not support the requested API!!!\n" );

        //
        // DeviceIoControl call will have returned without completing
        // requested function. GetOverlappedResult at this point
        // should return ERROR_IO_INCOMPLETE if called w/ fWait=FALSE.
        //
        if (!GetOverlappedResult(hVxD, &ovlp, &cbRet, FALSE)) {
            if (GetLastError() == ERROR_IO_INCOMPLETE)
                printf("GetOverlappedResult returned expected value.\n");
            else
                ERROR_OUT("GetOverlappedResult returned unexpected error.\n");
        }

        //
        // This call to GetOverlappedResult will suspend this thread 
        // until the operation is completed by the VxD. I.e. until the 
        // VxD calls DIOC_VWIN32CompletionRoutine.
        //
        GetOverlappedResult( hVxD, &ovlp, &cbRet, TRUE);
	}
	printf( "DevIoctl returned  : %ld bytes\n", cbRet );
    return cbRet;
}


BYTE* QueryOid(HANDLE hVxD, ULONG ulOid, ULONG ulLength)
{
    DWORD               cbIn = sizeof(PACKET_OID_DATA) + ulLength;
    DWORD               cbRet;
	PPACKET_OID_DATA	pOidData = (PPACKET_OID_DATA)InBuff;
    ULONG               ioctl;
	
    ioctl = (ulOid >= OID_802_3_PERMANENT_ADDRESS) 
		  	
		  			? IOCTL_PROTOCOL_QUERY_OID : IOCTL_PROTOCOL_STATISTICS;

    //
    // Prepare data for call to VxD.
	//
    memset(InBuff, 0, cbIn+1);

	pOidData->Oid    = ulOid;
	pOidData->Length = ulLength;

	printf("DevIoctl OID:%lx Length:%ld\n", pOidData->Oid, pOidData->Length );

	cbRet = QueryPacket( hVxD, ioctl, InBuff, cbIn, InBuff, cbIn );
   
	if ( cbRet > 0 )
	{
		printf( "DevIoctl Oid       : %08lx      Length : %lu\n", pOidData->Oid, pOidData->Length );

        return (InBuff+sizeof(PACKET_OID_DATA)-1);
	}

	printf( "DevIoctl Oid       : %08lx      Status : %08lx\n", pOidData->Oid, pOidData->Length );

	return 0;
}

BYTE* SetOid(HANDLE hVxD, ULONG ulOid, ULONG ulLength, ULONG data)
{
    DWORD               cbIn = sizeof(PACKET_OID_DATA) + ulLength;
    DWORD               cbRet;
	PPACKET_OID_DATA	pOidData = (PPACKET_OID_DATA)InBuff;
    ULONG               ioctl;
	
    if (ulOid == OID_GEN_CURRENT_PACKET_FILTER)
        ioctl = (ULONG) IOCTL_PROTOCOL_SET_OID;

    //
    // Prepare data for call to VxD.
	//
    memset(InBuff, 0, cbIn+1);

    pOidData->Oid     = ulOid;
    pOidData->Length  = ulLength;
    pOidData->Data[0] = (UCHAR) data;

    printf("DevIoctl OID:%lx Length:%ld Data:%lx\n", pOidData->Oid, pOidData->Length, pOidData->Data[0]);

    cbRet = QueryPacket(hVxD, ioctl, InBuff, cbIn, InBuff, cbIn);
   
	return 0;
}


void Query802_3(HANDLE hVxD, ULONG ulOid, ULONG ulLength, char *name)
{
    BYTE*   buffer = QueryOid(hVxD, ulOid, ulLength);

    if (buffer) {
        ULONG i;

        printf("%-19s: ", name);

        for (i=0; i<ulLength; i++)
			printf( "%02x ", buffer[i] );
	}
	printf( "\n\n" );
	return;
}

void QueryMacName(HANDLE hVxD)
{
    DWORD cbRet;
	DWORD dwLength = 32;
	BYTE  name[10] = "Mac Name";

	//
    // Prepare data for call to VxD.
	//
	memset( InBuff, 0, dwLength );

    cbRet = QueryPacket(hVxD, (ULONG)IOCTL_PROTOCOL_MACNAME, InBuff, dwLength, InBuff, dwLength);

    if (cbRet > 0) {
        printf( "%-19s: %s      ", name, InBuff );
	}
    printf("\n\n");
	return;
}


int main(int argc, char **args)
{
    HANDLE  hVxD = 0;
    DWORD   dwErrorCode;
    BYTE    ibuf[1514];
    BYTE    obuf[1514];
    ULONG   ilen=1514;
    ULONG   olen=1514;
    int     count, i;

    if (argc != 2) {
        printf("Usage: test ndis_name\n");
        return 0;
    }
    
    memset(ibuf, 0, 1514);
    memset(obuf, 0, 1514);

    //
    // Dynamically prepare to call VPACKET
    // The FILE_FLAG_OVERLAPPED flag is used to inform the Win32 subsystem
    // that the VxD will be processing some DeviceIOControl calls
    // asynchronously.
    //

    hVxD = CreateFile("\\\\.\\VPACKET.VXD", 
                      GENERIC_READ | GENERIC_WRITE,
                      0,
                      NULL,
                      OPEN_EXISTING,
                      FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED |
                      FILE_FLAG_DELETE_ON_CLOSE,
                      NULL);

    if (hVxD == INVALID_HANDLE_VALUE) {
        dwErrorCode = GetLastError();
        if (dwErrorCode == ERROR_NOT_SUPPORTED) {
            printf("Unable to open VxD,\ndevice does not support DeviceIOCTL\n");
        }
        else
            printf("Unable to open VxD, Error code: %lx\n", dwErrorCode);

       return(0);
    }

    //
    // Bind the driver to an NDIS3 Adapter
    //

    Bind(hVxD, args[1]);

    //
    // Set a packet filter so we receive something
    //
    
    SetOid(hVxD, OID_GEN_CURRENT_PACKET_FILTER, 4, NDIS_PACKET_TYPE_DIRECTED);

    //
    // Just for fun, find out the Name of the adapter
    //
    
    QueryMacName(hVxD);
    
    //
    // Just for fun, find out the Ethernet Address of the adapter
    //
    
    Query802_3( hVxD, OID_802_3_CURRENT_ADDRESS, 6, "Current Address" );

    //
    // no loop until Ctrl-C is pressed, displaying everything which arrives
    //
    
    while (1) {
        count = GetPacket(hVxD, (ULONG) IOCTL_PROTOCOL_READ, ibuf, ilen, obuf, olen); 
        if (count == 0) {
            printf("ERROR: GetPacket returned 0\n");
            break;
        }
        printf("length %d\n", count);
        for (i=0; i<count; i++)         // just dump the packet in hex
            printf("%02x ", obuf[i]); 
        printf("\n");
    }

    CloseHandle( hVxD );
    return( 0 );
}
