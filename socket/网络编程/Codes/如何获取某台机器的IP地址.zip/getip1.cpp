////////////////////////////////////////////////////////////////
// VCKBASE Online Journal
//
// getip1.cpp
//
// This program reports the IP address for each adapter in your machine.
// To compile from command-line type:
//
// cl getip1.cpp wsock32.lib
//
// Make sure your INCLUDE and LIB environment variables are set up properly;
// you can run vcvars32.bat
//
#include <winsock.h>
#include <wsipx.h>
#include <wsnwlink.h>
#include <stdio.h>

int main()
{
	////////////////
	// Initialize windows sockets API. Ask for version 1.1
	//
	WORD wVersionRequested = MAKEWORD(1, 1);
	WSADATA wsaData;
	if (WSAStartup(wVersionRequested, &wsaData)) {
		printf("WSAStartup failed %s\n", WSAGetLastError());
		return -1;
	}

	//////////////////
	// Get host name.
	//
	char hostname[256];
	int res = gethostname(hostname, sizeof(hostname));
	if (res != 0) {
		printf("Error: %u\n", WSAGetLastError());
		return -1;
	}
	printf("hostname=%s\n", hostname);

	////////////////
	// Get host info for hostname. 
	//
	hostent* pHostent = gethostbyname(hostname);
	if (pHostent==NULL) {
		printf("Error: %u\n", WSAGetLastError());
		return -1;
	}

	//////////////////
	// Parse the hostent information returned
	//
	hostent& he = *pHostent;
	printf("name=%s\naliases=%s\naddrtype=%d\nlength=%d\n",
		he.h_name, he.h_aliases, he.h_addrtype, he.h_length);
	
	sockaddr_in sa;
	for (int nAdapter=0; he.h_addr_list[nAdapter]; nAdapter++) {
		memcpy ( &sa.sin_addr.s_addr, he.h_addr_list[nAdapter],he.h_length);
      // Output the machines IP Address.
      printf("Address: %s\n", inet_ntoa(sa.sin_addr)); // display as string
	}

	//////////////////
	// Terminate windows sockets API
	//
	WSACleanup();

	return 0;
}
