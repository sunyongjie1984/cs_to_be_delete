//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Client.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CLIENT_DIALOG               102
#define IDP_SOCKETS_INIT_FAILED         103
#define ID_SYSTEMTRAY                   112
#define IDR_MAINFRAME                   128
#define IDD_REG                         129
#define IDD_CHAT                        130
#define IDI_ICON1                       131
#define IDI_ICON2                       132
#define IDI_ICON3                       133
#define IDI_ICON4                       134
#define IDI_ICON5                       135
#define IDI_ICON6                       136
#define IDI_ICON7                       137
#define IDI_ICON8                       138
#define IDI_ICON9                       139
#define IDI_ICON10                      140
#define IDI_ICON11                      141
#define IDI_ICON12                      142
#define IDI_ICON13                      143
#define IDI_ICON14                      144
#define IDI_ICON15                      145
#define IDI_ICON16                      146
#define IDI_ICON17                      147
#define IDI_ICON18                      148
#define IDI_ICON19                      149
#define IDI_ICON20                      150
#define IDI_ICON21                      151
#define IDI_ICON22                      152
#define IDI_ICON23                      153
#define IDI_ICON24                      154
#define IDI_ICON25                      155
#define IDI_NULL                        156
#define IDR_ACCELERATOR1                157
#define IDR_MENU1                       158
#define IDD_MYINTRO                     159
#define IDB_BITMAP1                     160
#define IDC_REGISTER                    1000
#define IDC_USERNAME                    1001
#define IDC_USERID                      1002
#define IDC_PICTURE                     1006
#define IDC_ID                          1007
#define IDC_REID                        1008
#define IDC_AGE                         1010
#define IDC_SEX                         1011
#define IDC_TRUENAME                    1012
#define IDC_PLACE                       1013
#define IDC_MESSAGE                     1013
#define IDC_MAIL                        1014
#define IDC_RECEIVE                     1014
#define IDC_SEND                        1015
#define IDC_REPLY                       1016
#define IDC_MORE                        1017
#define IDC_TUBIAO                      1018
#define IDC_ROOM                        1019
#define IDC_PETNAME                     1020
#define IDC_FRIEND                      1021
#define IDC_LIST1                       1022
#define ID_SHOW                         32771
#define ID_ABOUT                        32772
#define ID_CLOSE                        32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        161
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
