#ifndef CHAT_H
#define CHAT_H

#if !defined(AFX_CHAT_H__98E600C1_4B9C_11D6_82FF_0000E84D1E4B__INCLUDED_)
#define AFX_CHAT_H__98E600C1_4B9C_11D6_82FF_0000E84D1E4B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Chat.h : header file
//
//#include "MySocket.h"
/////////////////////////////////////////////////////////////////////////////
// CChat dialog

class CChat : public CDialog
{
// Construction
public:
	CString m_username;
	UINT res;

	LRESULT OnSystemTray(WPARAM wParam,LPARAM lParam);
//	void Receive();
	BOOL Init_net();
	CChat(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CChat)
	enum { IDD = IDD_CHAT };
	CButton	m_friend;
	CComboBox	m_petname;
	CEdit	m_message;
	CStatic	m_tubiao;
	CButton	m_more;
	CString	m_room;
	CString	m_recv;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChat)
	public:
	virtual BOOL DestroyWindow();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void ToggleSize();
	HICON m_hIcon;
	WSADATA Data;
	SOCKADDR_IN destSockAddr;
	SOCKET destSocket;
	unsigned long destAddr;
	int status;
	int numsnd;
	int numrcv;
//	CMySocket clientsocket;
	BOOL m_bToggleSize;
	CRect m_rectFull;
	CRect m_rectHalf;
	BOOL flag;
	CString m_netuser;
	UINT m_netsel;
	CString filename;
	CStdioFile m_file;
//	CString room[30];
	UINT	pet[30];
	CString send_data;
	CMapStringToString map;
	BOOL bReply;
	CString res_own;

	// Generated message map functions
	//{{AFX_MSG(CChat)
	virtual BOOL OnInitDialog();
	afx_msg void OnMore();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSend();
	afx_msg void OnReply();
	afx_msg void OnSelchangePetname();
	afx_msg void RecvData(WPARAM wParam,LPARAM lParam);
	afx_msg void OnAbout();
	afx_msg void OnClose();
	afx_msg void OnShow();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHAT_H__98E600C1_4B9C_11D6_82FF_0000E84D1E4B__INCLUDED_)
#endif // CHAT_H
