// Register.cpp : implementation file
//

#include "stdafx.h"
#include "Client.h"
#include "Register.h"
#include "clientdlg.h"

#define DEST_IP_ADDR "127.0.0.1"
#define PORT (u_short)56789
#define NO_FLAGS_SET 0
#define FIRST 131

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern BOOL bBegin;
/////////////////////////////////////////////////////////////////////////////
// CRegister dialog


CRegister::CRegister(CWnd* pParent /*=NULL*/)
	: CDialog(CRegister::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRegister)
	m_truename = _T("");
	m_username = _T("");
	m_reID = _T("");
	m_ID = _T("");
	m_mail = _T("");
	m_place = _T("");
	m_age = _T("");
	//}}AFX_DATA_INIT
}


void CRegister::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRegister)
	DDX_Control(pDX, IDC_SEX, m_sex);
	DDX_Control(pDX, IDC_PICTURE, m_pic);
	DDX_Text(pDX, IDC_TRUENAME, m_truename);
	DDX_Text(pDX, IDC_USERNAME, m_username);
	DDX_Text(pDX, IDC_REID, m_reID);
	DDX_Text(pDX, IDC_ID, m_ID);
	DDX_Text(pDX, IDC_MAIL, m_mail);
	DDX_Text(pDX, IDC_PLACE, m_place);
	DDX_Text(pDX, IDC_AGE, m_age);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRegister, CDialog)
	//{{AFX_MSG_MAP(CRegister)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRegister message handlers

BOOL CRegister::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
//////////////////////////ͷ��ѡ��////////////////////////////////////
	m_pic.SetItemHeight(-1, m_pic.m_sizeIcon.cy + 6);
	char str_pic[20];
	for(int i=1;i<=25;i++)
	{
		if(i<10)
			sprintf(str_pic,".\\face\\0%d.ico",i);
		else
			sprintf(str_pic,".\\face\\%d.ico",i);
		m_pic.AddIcon(str_pic);
	}
	
	m_pic.SelectIcon(0);
//////////////////////////////////////////////////////////////////////
////////////////////////////sex///////////////////////////////////////
	m_sex.AddString("male");
	m_sex.AddString("female");
	m_sex.SetCurSel(1);
//////////////////////////////////////////////////////////////////////
	Init_net();	
///////////////////////////////////////////////////////////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRegister::OnOK() 
{
	// TODO: Add extra validation here
//	Init_net();		//��ʼ��
	UpdateData();
	if(m_username.IsEmpty()||m_age.IsEmpty()||m_ID.IsEmpty()||m_reID.IsEmpty())
		MessageBox("���������еĻ�����Ϣ!","���ʷɱ�",MB_OK);
	else if(m_ID!=m_reID)
	{
		MessageBox("������������벻һ��!\n����������!","���ʷɱ�",MB_OK);
		m_ID=m_reID="";
		UpdateData(false);
	}
	else
	{
		if(Reg())
		{
//			close(destSocket);
			closesocket(destSocket);
			CDialog::OnOK();
			bBegin=true;
			CClientDlg dlg;
			dlg.m_username=m_username;
//			dlg.res=res;
			dlg.DoModal();
		}
		else
		{
			MessageBox("ע���������!\n���Ժ�����!","���ʷɱ�",MB_OK);
		}
	}
}

BOOL CRegister::Reg()
{
	CString sex;
	if(m_sex.GetCurSel())
		sex="male";
	else
		sex="female";
	res=m_pic.GetCurSel()+FIRST;
////////////////////////����ע����Ϣ�����շ�����Ϣ/////////////////////////////
	char sendText[300],recvText[100];
	sprintf(sendText,"Reg:%s,%s,%s,%s,%s,%s,%s,%d",m_username,m_age,sex,m_ID,m_truename,m_place,m_mail,res);
	numsnt=send(destSocket, sendText, strlen(sendText) + 1, NO_FLAGS_SET);
	if (numsnt != (int)strlen(sendText) + 1)
    {
		MessageBox("ERROR: Connection terminated!","���ʷɱ�",MB_OK);
		status=closesocket(destSocket);
		if (status == SOCKET_ERROR)
			MessageBox("ERROR: closesocket unsuccessful!","���ʷɱ�",MB_OK);
	    status=WSACleanup();
		if (status == SOCKET_ERROR)
			MessageBox("ERROR: WSACleanup unsuccessful!","���ʷɱ�",MB_OK);
		return false;
    }

	numrcv=recv(destSocket, recvText, 100, NO_FLAGS_SET);
	if ((numrcv == 0) || (numrcv == SOCKET_ERROR))
    {
      MessageBox("ERROR: Connection terminated!","���ʷɱ�",MB_OK);
      status=closesocket(destSocket);
      if (status == SOCKET_ERROR)
		  MessageBox("ERROR: closesocket unsuccessful!","���ʷɱ�",MB_OK);
      status=WSACleanup();
      if (status == SOCKET_ERROR)
		  MessageBox("ERROR: WSACleanup unsuccessful!","���ʷɱ�",MB_OK);
      return false;
    }
	recvText[numrcv]='\0';
	if(strcmp(recvText,"success!")!=0)
		return false;
///////////////////////////////////////////////////////////////////////////////
	return true;
}

BOOL CRegister::Init_net()
{
/////////////////////////�����ʼ��///////////////////////////////////
	status=WSAStartup(MAKEWORD(1, 1), &Data);
	if (status != 0)
		MessageBox("ERROR: WSAStartup unsuccessful!","���ʷɱ�",MB_OK);
	destAddr=inet_addr(DEST_IP_ADDR);		//��ʱ��Ϊ����ʹ��
	memcpy(&destSockAddr.sin_addr, &destAddr,sizeof(destAddr));
	destSockAddr.sin_port=htons(PORT);
	destSockAddr.sin_family=AF_INET;
	destSocket=socket(AF_INET, SOCK_STREAM, 0);
	if (destSocket == INVALID_SOCKET)
	{
		MessageBox("ERROR: socket unsuccessful!","���ʷɱ�",MB_OK);
		status=WSACleanup();
		if (status == SOCKET_ERROR)
			MessageBox("ERROR: WSACleanup unsuccessful!","���ʷɱ�",MB_OK);
		return false;
	}
//////////////////////////////////////////////////////////////////////
///////////////////////////��������////////////////////////////////////////////
	status=connect(destSocket, (LPSOCKADDR) &destSockAddr,sizeof(destSockAddr));
	if (status == SOCKET_ERROR)
	{
		MessageBox("ERROR: connect unsuccessful!","���ʷɱ�",MB_OK);
		status=closesocket(destSocket);
		if (status == SOCKET_ERROR)
			MessageBox("ERROR: closesocket unsuccessful!","���ʷɱ�",MB_OK);
		status=WSACleanup();
		if (status == SOCKET_ERROR)
			MessageBox("ERROR: WSACleanup unsuccessful!","���ʷɱ�",MB_OK);
		return false;
	}
	return true;
}
