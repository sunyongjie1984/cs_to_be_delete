#ifndef RIGISTER_H
#define RIGISTER_H

#if !defined(AFX_REGISTER_H__B4B5B9EF_4B00_11D6_82FF_0000E84D1E4B__INCLUDED_)
#define AFX_REGISTER_H__B4B5B9EF_4B00_11D6_82FF_0000E84D1E4B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Register.h : header file
//
#include "IconComboBox.h"

/////////////////////////////////////////////////////////////////////////////
// CRegister dialog

class CRegister : public CDialog
{
// Construction
public:
	BOOL Init_net();
	BOOL Reg();
	CRegister(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRegister)
	enum { IDD = IDD_REG };
	CComboBox	m_sex;
	CIconComboBox m_pic;
	CString	m_truename;
	CString	m_username;
	CString	m_reID;
	CString	m_ID;
	CString	m_mail;
	CString	m_place;
	CString	m_age;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRegister)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	WSADATA Data;
	SOCKADDR_IN destSockAddr;
	SOCKET destSocket;
	unsigned long destAddr;
	int status;
	int numsnt;
	int numrcv;
	UINT res;

	// Generated message map functions
	//{{AFX_MSG(CRegister)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REGISTER_H__B4B5B9EF_4B00_11D6_82FF_0000E84D1E4B__INCLUDED_)
#endif // RIGISTER_H
