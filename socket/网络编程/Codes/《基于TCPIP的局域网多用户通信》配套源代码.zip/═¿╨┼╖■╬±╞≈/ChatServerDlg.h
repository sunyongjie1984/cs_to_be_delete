// ChatServerDlg.h : header file
//

#if !defined(AFX_CHATSERVERDLG_H__EFEE1447_4C8F_11D6_82FF_0000E84D1E4B__INCLUDED_)
#define AFX_CHATSERVERDLG_H__EFEE1447_4C8F_11D6_82FF_0000E84D1E4B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CChatServerDlg dialog
struct socket_info
{
	SOCKET s_client;
	u_long client_addr;
	CString pet;
	CWinThread* thread;
};

struct send_info
{
	CString data;
	CWinThread* thread;
};

class CChatServerDlg : public CDialog
{
// Construction
public:
	void Chat();
	BOOL Init_net(u_short PORT);
	CChatServerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CChatServerDlg)
	enum { IDD = IDD_CHATSERVER_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChatServerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	WSADATA Data;
	SOCKADDR_IN serverSockAddr;
	SOCKADDR_IN clientSockAddr;
	SOCKET serverSocket;
	SOCKET clientSocket;
	int status;
	int addrLen;
//    DWORD threadID;

	// Generated message map functions
	//{{AFX_MSG(CChatServerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnChat();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHATSERVERDLG_H__EFEE1447_4C8F_11D6_82FF_0000E84D1E4B__INCLUDED_)
