// ServerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Server.h"
#include "ServerDlg.h"
#include "user.h"

#define PORT (u_short)56789
#define NO_FLAGS_SET 0
#define MAXBUFLEN 5025

#define WM_SYSTEMTRAY WM_USER+10

//#define	WM_CHAT	WM_USER+10

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//HWND serWnd;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

////////�յ�����Ϣ��"Reg:"��ͷ����Ϊע����Ϣ����"Data:"��ͷ��Ϊһ����Ϣ//////
UINT talkToClient(void *cs)		
{
	BOOL bLoad=false;
	char buffer[MAXBUFLEN];
	int numrcv;
	SOCKET clientSocket=(SOCKET)cs;
	while(1)
	{
		numrcv=recv(clientSocket, buffer, MAXBUFLEN, NO_FLAGS_SET);
		if ((numrcv == 0) || (numrcv == SOCKET_ERROR))
		{
			AfxMessageBox("Connection terminated!",MB_OK);
			break;
		}
		buffer[numrcv]='\0';
		char start[6];
		char *pos=strchr(buffer,':');
		int len_buffer=strlen(buffer);
		int len=strlen(pos);
		int len_start=len_buffer-len;
		for(int i=0;i<len_start;i++)
			start[i]=buffer[i];
		start[len_start]='\0';
		char *pos_data=pos+1;
///////////////////////////////Reg//////////////////////////////////////////////////
		if(strcmp(start,"Reg")==0)
		{
			CString username,age,sex,ID,truename,place,mail,res;
//////////////////////////ȡ��Ϣ////////////////////////////////////////////////////
/////username
			char data[100];
			pos=strchr(pos_data,',');
			int len_data=strlen(pos_data);
			int len_pos=strlen(pos);
			int len=len_data-len_pos;
			for(i=0;i<len;i++)
				data[i]=pos_data[i];
			data[len]='\0';
			username=data;
			pos_data=pos+1;
/////age
			pos=strchr(pos_data,',');
			len_data=strlen(pos_data);
			len_pos=strlen(pos);
			len=len_data-len_pos;
			for(i=0;i<len;i++)
				data[i]=pos_data[i];
			data[len]='\0';
			age=data;
			pos_data=pos+1;
//////sex
			pos=strchr(pos_data,',');
			len_data=strlen(pos_data);
			len_pos=strlen(pos);
			len=len_data-len_pos;
			for(i=0;i<len;i++)
				data[i]=pos_data[i];
			data[len]='\0';
			sex=data;
			pos_data=pos+1;
//////ID
			pos=strchr(pos_data,',');
			len_data=strlen(pos_data);
			len_pos=strlen(pos);
			len=len_data-len_pos;
			for(i=0;i<len;i++)
				data[i]=pos_data[i];
			data[len]='\0';
			ID=data;
			pos_data=pos+1;
//////truename
			pos=strchr(pos_data,',');
			len_data=strlen(pos_data);
			len_pos=strlen(pos);
			len=len_data-len_pos;
			for(i=0;i<len;i++)
				data[i]=pos_data[i];
			data[len]='\0';
			truename=data;
			pos_data=pos+1;
//////place
			pos=strchr(pos_data,',');
			len_data=strlen(pos_data);
			len_pos=strlen(pos);
			len=len_data-len_pos;
			for(i=0;i<len;i++)
				data[i]=pos_data[i];
			data[len]='\0';
			place=data;
			pos_data=pos+1;
//////mail
			pos=strchr(pos_data,',');
			len_data=strlen(pos_data);
			len_pos=strlen(pos);
			len=len_data-len_pos;
			for(i=0;i<len;i++)
				data[i]=pos_data[i];
			data[len]='\0';
			mail=data;
			pos_data=pos+1;
//////res
			res=pos_data;
////////////////////////////////////////////////////////////////////////////////////
			CUser rec;
			rec.Open();
			rec.AddNew();
			rec.m_age=atoi(age);
			rec.m_mail=mail;
			rec.m_res=atoi(res);
			rec.m_sex=sex;
			rec.m_truename=truename;
			rec.m_userID=ID;
			rec.m_username=username;
			rec.m_place=place;

			CString turn;
			if(rec.Update())
			{
			////////////����"success!"//////////////
				turn="success!";
			}
			else
			{
			////////////����"error!"/////////////////
				turn="error!";
			}
			send(clientSocket, turn, strlen(turn) + 1, NO_FLAGS_SET);
			rec.Close();
			shutdown(clientSocket, 2);
			closesocket(clientSocket);
			break;
		}
/////////////////////////////////////////////////////////////////////////////////
///////////////////////////////Load///////////////////////////////////////////////
		else if(strcmp(start,"Load")==0)
		{
			CString username,ID;
/////username
			char data[100];
			pos=strchr(pos_data,',');
			int len_data=strlen(pos_data);
			int len_pos=strlen(pos);
			int	len=len_data-len_pos;
			for(i=0;i<len;i++)
				data[i]=pos_data[i];
			data[len]='\0';
			username=data;
			pos_data=pos+1;
//////ID
			ID=pos_data;
//////////////////////////��֤///////////////////////////////////////////////////
			CUser rec;
			rec.m_strSort="username";
			rec.Open();
			CString turn,Info;
			while(!rec.IsEOF())
			{
				if(rec.m_username==username&&rec.m_userID==ID)
				{
				////////////����"success!"//////////////
					turn="success!";
//					send(clientSocket, turn, strlen(turn) + 1, NO_FLAGS_SET);
//					::PostMessage(serWnd,WM_CHAT,clientSocket,0);
					bLoad=true;
//					break;
				}
				Info+=rec.m_username;
				Info+=",";
				CString resource;
				resource.Format("%d",rec.m_res);
				Info+=resource;
				Info+=",";
				Info+=rec.m_place;
				Info+="\r\n";
				rec.MoveNext();
			}
			rec.Close();
			////////////����"error!"/////////////////
			if(!bLoad)
			{
				turn="error!";
//				send(clientSocket, turn, strlen(turn) + 1, NO_FLAGS_SET);
			}
//			turn+="\r\n";
			turn+=Info;
			send(clientSocket, turn, strlen(turn) + 1, NO_FLAGS_SET);
/////////////////////////////////////////////////////////////////////////////////
			shutdown(clientSocket, 2);
			closesocket(clientSocket);
			break;	//�˳�
		}
//////////////////////////////////////////////////////////////////////////////////
		delete pos_data;
		delete pos;
	}
	ExitThread(0);
	return 1;
}
/////////////////////////////////////////////////////////////////////////////
class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerDlg dialog

CServerDlg::CServerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CServerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CServerDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON1);
}

void CServerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CServerDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CServerDlg, CDialog)
	//{{AFX_MSG_MAP(CServerDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_RUN, OnRun)
	ON_COMMAND(IDC_CLOSEWINS, OnClosewins)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_SYSTEMTRAY,OnSystemTray)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerDlg message handlers

BOOL CServerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	Init_net();
//	serWnd=m_hWnd;
	NOTIFYICONDATA nid;
	nid.cbSize=sizeof(NOTIFYICONDATA);
	nid.hWnd=m_hWnd;
	nid.uID=ID_SYSTEMTRAY;
	nid.uFlags=NIF_MESSAGE|NIF_ICON|NIF_TIP;
	nid.uCallbackMessage=WM_SYSTEMTRAY;
	nid.hIcon=AfxGetApp()->LoadIcon(IDI_ICON1);
	strcpy(nid.szTip,"���ʷɱ�");
	::Shell_NotifyIcon(NIM_ADD,&nid);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CServerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CServerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CServerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CServerDlg::Reg_Load()
{
	while(1)
	{
		CWinThread*  hHandle;
		clientSocket=accept(serverSocket,(LPSOCKADDR) &clientSockAddr, &addrLen);
		hHandle=AfxBeginThread(talkToClient,(LPVOID)clientSocket);
//		AfxBeginThread(Recv_Thread,(LPVOID)destSocket);
		if (hHandle ==NULL)
		{
			MessageBox("ERROR: Unable to create thread!","����ɱ�",MB_OK);
			status=closesocket(clientSocket);
			if (status == SOCKET_ERROR)
				MessageBox("ERROR: closesocket unsuccessful!","����ɱ�",MB_OK);
		}
	}
}

void CServerDlg::OnRun() 
{
	// TODO: Add your control notification handler code here
	::ShowWindow(m_hWnd,SW_HIDE);
	Reg_Load();
}

BOOL CServerDlg::Init_net()
{
////////////////////////////�����ʼ��////////////////////////////////////////
	addrLen=sizeof(SOCKADDR_IN);
	status=WSAStartup(MAKEWORD(1, 1), &Data);
	if (status != 0)
	{
		MessageBox("ERROR: WSAStartup unsuccessful!","����ɱ�",MB_OK);
		return  false;
	}

	memset(&serverSockAddr, 0, sizeof(serverSockAddr));
    serverSockAddr.sin_port=htons(PORT);
    serverSockAddr.sin_family=AF_INET;
    serverSockAddr.sin_addr.s_addr=htonl(INADDR_ANY);

    serverSocket=socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET)
	{
		MessageBox("socket unsuccessful!","����ɱ�",MB_OK);
		status=WSACleanup();
		if (status == SOCKET_ERROR)
			 MessageBox("ERROR: WSACleanup unsuccessful!","����ɱ�",MB_OK); 
		return false;
	}

    status=bind(serverSocket, (LPSOCKADDR) &serverSockAddr, sizeof(serverSockAddr));
    if (status == SOCKET_ERROR)
	{
		MessageBox("ERROR: bind unsuccessful!","����ɱ�",MB_OK);
		return false;
	}

	status=listen(serverSocket, 5);
	if (status == SOCKET_ERROR)
	{
		MessageBox("ERROR: listen unsuccessful!","����ɱ�",MB_OK);
		return false;
	}
//////////////////////////////////////////////////////////////////////////////
	return true;
}

/*void CServerDlg::Chat(WPARAM wParam,LPARAM lParam)
{
	SOCKET clientsocket=(SOCKET)wParam;
	char str[10];
	sprintf(str,"%d",clientsocket);
	MessageBox(str);
}*/

LRESULT CServerDlg::OnSystemTray(WPARAM wParam, LPARAM lParam)
{

	if(wParam=ID_SYSTEMTRAY)
	{
		switch(lParam)
		{
/*		case  WM_LBUTTONDBLCLK:
			{
				KillTimer(0);
				NOTIFYICONDATA nid;
	            nid.cbSize=sizeof(NOTIFYICONDATA);
	            nid.hWnd=m_hWnd;
	            nid.uID=ID_SYSTEMTRAY;
	            nid.uFlags=NIF_MESSAGE|NIF_ICON|NIF_TIP;
	            nid.uCallbackMessage=WM_SYSTEMTRAY;
	            nid.hIcon=AfxGetApp()->LoadIcon(sel);
	            strcpy(nid.szTip,"���ʷɱ�");
	            ::Shell_NotifyIcon(NIM_MODIFY,&nid);
				::ShowWindow(m_hWnd,SW_SHOWDEFAULT);
		        sndPlaySound(NULL,SND_ASYNC);
				m_tubiao.SetIcon(AfxGetApp()->LoadIcon(m_netsel));
			}
			break;*/
		case WM_RBUTTONDOWN:
			{
				CMenu pMenu;
	            pMenu.LoadMenu(IDR_MENU1);
	            CMenu* pMenu1=pMenu.GetSubMenu(0);
	            ASSERT(pMenu1!=NULL);
                CPoint point;
				GetCursorPos(&point);
	            pMenu1->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON,point.x,point.y,this);
				break;
			}
		default:
			break;
		}
	}
	return 1;
}

void CServerDlg::OnClosewins() 
{
	// TODO: Add your command handler code here
	CDialog::OnCancel();
	NOTIFYICONDATA nid;
	nid.cbSize=sizeof(NOTIFYICONDATA);
	nid.hWnd=m_hWnd;
	nid.uID=ID_SYSTEMTRAY;
	nid.uFlags=0;
	::Shell_NotifyIcon(NIM_DELETE,&nid);
}

BOOL CServerDlg::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
//	AfxEndThread(0);
	return CDialog::DestroyWindow();
}
