// portscan.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <winsock2.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys\stat.h>
#include "scanport.h"

#define THREAD_NUM          60

//��ʾ��Ϣ
void Usage();
//�����������
void AnalyseCommandLines(int argc,char** argv);
bool WinSocket_Open ();  //window Socket��ĳ�ʼ��     
void WinSocket_Close();  //window Socket��Ĺر�

char Address[128];
unsigned int sPort = DEFAULT_BEGIN_PORT;
unsigned int ePort = DEFAULT_END_PORT;
unsigned int cPort = DEFAULT_END_PORT;
#define PortNum  ( ePort - sPort + 1)

HANDLE  ThreadHandleArray[THREAD_NUM];
DWORD count = THREAD_NUM ;
DWORD dwWait;
int _tmain(int argc, _TCHAR* argv[])
{
   
	WinSocket_Open();
	Usage();
    AnalyseCommandLines(argc,argv);
	CScanPort*  pScaner[THREAD_NUM]={NULL};
    //ɨ��Ķ˿��������߳���
    if ( PortNum <= THREAD_NUM )
	{
		 for (int i=0; i< (int)PortNum ;i++)
		 {
           pScaner[i] = new CScanPort(Address,sPort+i,sPort+i,i);  
		   ThreadHandleArray[i] =  pScaner[i]->hThread ;
		 }
		 count = PortNum;
	}
	else
	{
		 int sp = sPort,ep= sPort;
         int A = PortNum / THREAD_NUM ;  
		 int B = PortNum - A*THREAD_NUM; //����
		 //������Bϸ�ֵ����THREAD_NUM�߳���
		 if ( B <= THREAD_NUM )
		 {
			 //��ǰB���̼߳���1
		
			for (int i=0; i< THREAD_NUM; i++)
			{
				sp = ep;
				if ( i!= 0)
					sp +=1;
				ep = sp + A -1;

				if ( i < B)
					ep +=1;
									
				pScaner[i] = new CScanPort(Address,sp,ep,i); 
				ThreadHandleArray[i] =  pScaner[i]->hThread ;

			}
		 }
		 else
		 {
		    //��ÿ���߳��ټ���Aa,���һ���̼߳���Bb
		     int Aa = B / THREAD_NUM ; 
			 int Bb = B - Aa*THREAD_NUM;
			for (int i=0; i< THREAD_NUM; i++)
			{
				sp = ep;
				if ( i!= 0)
					sp +=1;
				ep = sp + A +Aa-1;
				if ( i == THREAD_NUM-1 ) 
				{
					ep = ep + Bb ;  
				}
				pScaner[i] = new CScanPort(Address,sp,ep,i); 
				ThreadHandleArray[i] =  pScaner[i]->hThread ;

		     }
		 }
			

	
	   

	}
   //�ȴ�ֱ�����һ���߳̽���
	while ( count )
	{
		dwWait = ::WaitForMultipleObjects( count, ThreadHandleArray, FALSE, INFINITE );
		if( dwWait >= WAIT_OBJECT_0 && dwWait < ( WAIT_OBJECT_0 + count ) )
		{
			dwWait -= WAIT_OBJECT_0;
			// dwWait now has index to thread that completed do whateve	you want to do with it
			// set array back up for next wait
			if( dwWait != ( count - 1 ) )
				ThreadHandleArray[ dwWait ] = ThreadHandleArray[count - 1 ];
				count--;
		    
		    
		}
	  printf ("--------------------------------------------Thread:%3d Complete\n",THREAD_NUM-count-1);

	}
	//��ʾ���
	printf ("--------------------------------------------------------------------------\n");
	printf ("Scan Address <%s> Open Port:\n",Address);
	struct Save ss;
	struct stat statbuf;
    FILE* fp ;
	fp = fopen ("port.txt","r");
    int res=stat("port.txt", &statbuf );
	if ( res == -1 ) return 0;
	int len = statbuf.st_size;
	int opennum = len /(sizeof (ss) );
	for (int i=0; i< opennum ;i++)
	{
         fread(&ss,1,sizeof (ss),fp);
		 fseek(fp,sizeof (ss)*(i+1), SEEK_SET  );
		 printf ("-> %5d \n", ss.port );
	}


    for (int n=0; n< THREAD_NUM; n++)
	{
		 if (  pScaner[n]  )
			 delete  pScaner[n];
	}

    WinSocket_Close();
	return 0;
}

void Usage()
{
  printf ("==========================================================================\n");
  printf ("PortScan v1.1 -TCP/IP Multi-Thread to Search Open Port\n");
  printf ("Free SoftWare\n");
  printf ("Email: check_815@sohu.com qq:14321410 tianya\n");
  printf ("==========================================================================\n");
} 
void AnalyseCommandLines(int argc,char** argv)
{
	
	//��������û�в���������Ĭ������ ip:127.0.0.1 sPort:0 ePort 65534
	if (argc == 1)
	{
	
		printf ("portscan [IP | NAME] [Start Port] [End Port]\n");
		printf ("default ip:127.0.0.1 sPort:0 ePort 65534\n");
		exit(0);
		
	}
	else if ( argc ==2 )
	{
		 strcpy ( Address, argv[1] );
	}
	else if ( argc == 3)
	{
		 strcpy ( Address, argv[1] );
		 sPort = atoi( argv[2] );
	}
	else 
	{
		 strcpy ( Address, argv[1] );
		 sPort = atoi( argv[2] );
		 ePort = atoi( argv[3] );
	}
}
bool WinSocket_Open ()
{
	  WSADATA wsaData;
	  int err=WSAStartup(MAKEWORD(2,2),&wsaData);
	  return  (err==0? true:false) ;

}
void WinSocket_Close()
{
	 WSACleanup();
}