#include "StdAfx.h"
#include "scanport.h"
#include <winsock2.h>
CScanPort::CScanPort(char* addr,unsigned start,unsigned end,int threadid)
{
    ThreadID = threadid;
	if ( addr!=NULL && addr[0]!='\0')
		strcpy ( Address, addr);
	else
		Address[0] = '\0';
	c_socket = -1;
	sPort  = start ;
    ePort  = end ;
	hThread = CreateThread( 
							NULL,                        // no security attributes 
							0,                           // use default stack size  
							(LPTHREAD_START_ROUTINE)BeginScan ,                  // thread function 
							this,                        // argument to thread function 
							0,                           // use default creation flags 
							NULL);                       // returns the thread identifier 
					 

}

CScanPort::~CScanPort(void)
{
}

UINT CScanPort:: BeginScan(LPVOID* param)
{
    CScanPort* This = (CScanPort*) param;
	int i;
    fopen ("port.txt","w");
	
	for ( i=This->sPort; i<This->ePort+1 ;i++)
	{
		This->cPort = i;     
	    if (This-> Open() == 0 )//�ɹ�
		{
			 printf ("< %3d >  connect port %5d success!\n",This->ThreadID,This-> cPort ) ;
		     This-> WritetoFile();
		}
	}
  return 0;
}
/*
  ��һ��socket����
  ���أ�
      0:�ɹ�
     -1:ʧ��
*/
int CScanPort::CreateSocket()
{
 
	c_socket = socket ( AF_INET, SOCK_STREAM, 0 );
	if ( c_socket == SOCKET_ERROR )
	{ 
		 printf (" create socket fault!\n ");
         return -1;
	}

}
/*
 ����������socketͨ��
 ���أ�
      0:�ɹ�
     -1:ʧ��
*/
int CScanPort::Open ()
{
	struct sockaddr_in remoteaddr;
	struct hostent*    remotehost;
	remoteaddr.sin_family = AF_INET;
	remoteaddr.sin_addr.s_addr   = inet_addr ( Address );
	remoteaddr.sin_port          = htons ( cPort );
	if ( CreateSocket() == -1 ) return -1;
	//���������õ�ip��ַ
	if ( remoteaddr.sin_addr.s_addr == INADDR_NONE) 
	{
       remotehost =  gethostbyname( Address );
	   if ( remotehost == NULL )
	   {
		   Address [0] = '\0';
		   printf ("have no such a machine%s!\n",Address);
		   return -1;
	   }

	   memcpy( &remoteaddr.sin_addr , remotehost->h_addr,remotehost->h_length );
	   strcpy ( Address , inet_ntoa( remoteaddr.sin_addr) );
	} 
	//����
    if  ( connect ( c_socket, (SOCKADDR*) &remoteaddr, sizeof ( struct sockaddr_in ) ) == SOCKET_ERROR )
	{
		 printf ("< %3d >  connect port %5d  ...\n",ThreadID,cPort ) ;
		 closesocket( c_socket);
		 return -1; 
	}
	closesocket( c_socket);
	return 0;
}
/*
 �ѽ��д���ļ�
 ���أ�
      0:�ɹ�
     -1:ʧ��
*/
int CScanPort::WritetoFile()
{
	struct Save ss;
	FILE* fp;
    int  len;
	int  ret = 0;
	fp = fopen ("port.txt","a+");
	if (fp == NULL) 
	{
		printf ("file port.txt open fault!\n");
		ret = -1;
		goto _EXIT_;
	}
    len = sizeof (ss);
	strcpy ( ss.address ,Address);
	ss.port = cPort;
	if ( fwrite ( &ss,1, len, fp ) != len )
	{
		printf ("file write fault!\n");
		ret = -1;
		goto _EXIT_;
	}
_EXIT_:
	fclose ( fp );
	return ret;

}
