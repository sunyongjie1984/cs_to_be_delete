#ifndef _PARSEMESSAGE_H
#define _PARSEMESSAGE_H
class CParseMessage
{
public:
	CParseMessage(const CWnd * pWnd,const Message & Value);
	~CParseMessage();
private:
	const CParseMessage & operator = (const CParseMessage &);
	CParesMessage(const CParseMessage &);
public:
	BOOL SWitchMessage();
	void SetMessage(const Message & Value);
private:
	CWnd * pView;
	Message Msg;
};
#endif