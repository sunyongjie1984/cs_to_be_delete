// ClientFormView.cpp : implementation file
//

#include "stdafx.h"
#include "chatclient.h"
#include "ClientFormView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClientFormView

IMPLEMENT_DYNCREATE(CClientFormView, CFormView)

CClientFormView::CClientFormView()
	: CFormView(CClientFormView::IDD)
{
	//{{AFX_DATA_INIT(CClientFormView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CClientFormView::~CClientFormView()
{
}

void CClientFormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClientFormView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CClientFormView, CFormView)
	//{{AFX_MSG_MAP(CClientFormView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientFormView diagnostics

#ifdef _DEBUG
void CClientFormView::AssertValid() const
{
	CFormView::AssertValid();
}

void CClientFormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CClientFormView message handlers
