// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "ChatClient.h"
#include "MyTreeView.h"
#include "MyEditView.h"
#include "ClientFormView.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame
IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{

	
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	CRect rect;
	rect.SetRect(0,0,200,420);
	MoveWindow(&rect);
	CenterWindow();

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	CSize size;
	size.cx = 150;
	size.cy = 60;
	if(!m_wndSplitter.CreateStatic(this,2,1))
	{
		return FALSE;
	}
	if(!m_wndSplitter.CreateView(0,0,RUNTIME_CLASS(CClientFormView),size,pContext))
		return FALSE;
	if(!m_wndSplitter.CreateView(1,0,RUNTIME_CLASS(CMyTreeView),size,pContext))
		return FALSE;
	

	return TRUE;
}
CMyTreeView * CMainFrame::GetTreeView()
{
	return (CMyTreeView*)m_wndSplitter.GetPane(1,0);
}
CClientFormView * CMainFrame::GetFormView()
{
	return (CClientFormView*)m_wndSplitter.GetPane(0,0);
}



BOOL CMainFrame::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CFrameWnd::DestroyWindow();
}
