#ifndef _TYPEDEF_H_
#define _TYPEDEF_H_
//type
#define USERLOG  1
#define USERSESSION 2
#define SYSERROR   3
#define FIRSTLOG   4
#define FILETIME   23
//subtype
#define FILETIMEBEGIN 24
#define FILETIMEDURING 25
#define FILETIMEEND    26
#define FILECONTENTLEN 27
#define DECLINEFILE 22
#define ACCEPTFILE 5
#define FILETRANCE  6
#define NOTFIRSTTIME 7
#define FIRSTTIME  8
#define TEMPNAME   9
#define USERLOGIN  10
#define USERLOGOUT 11
#define ROOMLIST  12
#define USERLIST  13
#define USERQUIT  14
#define CHANGEROOM 15
#define SAYINPRIVATE 16
#define SAYINPUBLIC  17
#define SAYINALLROOM 18
#define BUILDNEWROOM 19
#define SERVERQUIT   20
#define USEREXSIT    21


#define NOTLOGIN     25
#define HAVELOGIN    26
#endif