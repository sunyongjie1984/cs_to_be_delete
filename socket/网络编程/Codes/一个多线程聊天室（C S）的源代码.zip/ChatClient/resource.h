//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ChatClient.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_FORMVIEW                    101
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_CHATCLTYPE                  129
#define IDD_CONNECTSERVER               130
#define IDR_JOINROOM                    135
#define IDD_CLIENTLOG                   136
#define IDI_ICON1                       137
#define IDR_CLIENT                      139
#define IDD_SENDMESSAGE                 140
#define IDD_SHOWMESSAGE                 141
#define IDI_ICON2                       142
#define IDI_ICON3                       143
#define IDB_IMAGELIST                   144
#define IDC_SERVERIP                    1003
#define IDC_SERVERPORT                  1004
#define IDC_USERNAME                    1005
#define IDC_SELFNAME                    1009
#define IDC_SENDSENTENCE                1011
#define IDC_ROOMNAME                    1012
#define IDC_MESSAGE                     1013
#define IDC_CLIENTNAME                  1014
#define IDC_SERVERSPECIAL               1015
#define IDC_CLIENTUSERNAME              1016
#define IDA_JOININ                      32771
#define ID_JOININROOM                   32773
#define ID_MENU_SEND                    32775
#define ID_MENU_TRANSEFILE              32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
