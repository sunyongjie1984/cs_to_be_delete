#ifndef _MESSAGE_H
#define _MESSAGE_H
struct Message
{
public:
	int iType;
	int iSubType;
	char strRoom[20];
	char strName[20];
	char strClientName[20];
	char strContent[1024];

};
#endif