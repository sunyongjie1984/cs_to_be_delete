#if !defined(AFX_CLIENTFORMVIEW_H__E3862461_517D_11D7_AF7F_0000E8A3A8FB__INCLUDED_)
#define AFX_CLIENTFORMVIEW_H__E3862461_517D_11D7_AF7F_0000E8A3A8FB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ClientFormView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CClientFormView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CClientFormView : public CFormView
{
protected:
	CClientFormView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CClientFormView)

// Form Data
public:
	//{{AFX_DATA(CClientFormView)
	enum { IDD = IDD_FORMVIEW };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientFormView)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CClientFormView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CClientFormView)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTFORMVIEW_H__E3862461_517D_11D7_AF7F_0000E8A3A8FB__INCLUDED_)
