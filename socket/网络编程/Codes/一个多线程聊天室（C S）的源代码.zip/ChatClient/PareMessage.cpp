#include "Stdafx.h"
#include "ParseMessage.h"
#include "ChatClient.h"
#include "ClientFormView.h"
#include "ConnectServerDlg.h"
#include "MainFrm.h"
CParseMessage::~CParseMessage()
{
}
CParseMessage::CParseMessage(const CWnd * pWnd,const Message & Value)
{
	pView = const_cast < CWnd *>(pWnd);
	Msg = Value;
}
extern CChatClientApp theApp;
BOOL CParseMessage::SWitchMessage()
{
	ASSERT(pView != NULL);
	ASSERT_VALID(pView);
	CClientFormView * m_pFormView =(CClientFormView *) ((CMainFrame * )AfxGetMainWnd())->GetFormView();
	int iTryTimes = 0;
	switch(Msg.iType)
	{
	case USERLOG:
		switch(Msg.iSubType)
		{
		case ROOMLIST:
			pView ->PostMessage(WM_ADDNEWROOM,WPARAM(&Msg),0);
			break;
		case  USERLIST:
			pView ->PostMessage(WM_NEWCLIENTCOMEIN,WPARAM(&Msg),0);
			break;
		case USERLOGIN:
			pView ->PostMessage(WM_NEWCLIENTCOMEIN,WPARAM(&Msg),0);
			break;
		case  USERLOGOUT:
			pView ->PostMessage(WM_USERLOGOUT,WPARAM(&Msg),0);
			break;
		default:
			break;
		}
		break;
		case USERSESSION:
			
			switch( Msg.iSubType)
			{
			case SAYINPRIVATE:
				pView ->PostMessage(WM_SAYINPRIVATE,WPARAM(&Msg),0);
				break;
			case FILETRANCE:
				pView ->PostMessage(WM_FILETRANCE,WPARAM(&Msg),0);
				break;
			case ACCEPTFILE:
				pView->PostMessage(WM_ACCEPTFILE,WPARAM(&Msg),0);
				break;
				
			default:
				break;
			}
			break;
			
			case SYSERROR :
				
				switch(Msg.iSubType)
				{
				case  SERVERQUIT:
					AfxMessageBox("�������ر�");
					AfxGetMainWnd()->PostMessage(WM_QUIT,0);
					break;
				case USEREXSIT:
					{
						AfxMessageBox("�û����Ѿ�����");
						theApp.m_skMainSocket.SetState(NOTLOGIN);
						
						CConnectServerDlg Dlg(theApp.m_skMainSocket.GetUserName());
						
						if(Dlg.DoModal() == IDCANCEL)
						{
							AfxGetMainWnd()->PostMessage(WM_QUIT);
							break;
						}
						Message msObj;
						msObj.iType = FIRSTLOG;
						msObj.iSubType = NOTFIRSTTIME;
						CString strTemp = Dlg.m_strUserName;
						int iLen = strTemp.GetLength();
						lstrcpy(msObj.strName,strTemp.GetBuffer(iLen));
						strTemp.ReleaseBuffer();
						theApp.m_skMainSocket.Send(&msObj,sizeof(Message));
						theApp.m_skMainSocket.SetUserName(strTemp);
					}
					break;
				default:
					break;
				}
				break;
		case FILETIME:
			pView->SendMessage(WM_FILETIME,WPARAM(&Msg),0);
				
			break;
		default:
			break;
	}
	return TRUE;

}
