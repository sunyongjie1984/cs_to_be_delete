// ConnectServerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ChatClient.h"
#include "ConnectServerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConnectServerDlg dialog


CConnectServerDlg::CConnectServerDlg(CString strName,CWnd* pParent /*=NULL*/)
	: CDialog(CConnectServerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConnectServerDlg)
	m_strServerIp = _T("127.0.0.1");
	m_iServerPort = 1080;
	m_bServerSpecial = FALSE;
	m_strUserName = _T(strName);
	//}}AFX_DATA_INIT
}


void CConnectServerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConnectServerDlg)
	DDX_Text(pDX, IDC_SERVERIP, m_strServerIp);
	DDX_Text(pDX, IDC_SERVERPORT, m_iServerPort);
	DDV_MinMaxInt(pDX, m_iServerPort, 0, 65536);
	DDX_Check(pDX, IDC_SERVERSPECIAL, m_bServerSpecial);
	DDX_Text(pDX, IDC_CLIENTUSERNAME, m_strUserName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConnectServerDlg, CDialog)
	//{{AFX_MSG_MAP(CConnectServerDlg)
	ON_BN_CLICKED(IDC_SERVERSPECIAL, OnServerspecial)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConnectServerDlg message handlers
extern CChatClientApp theApp;
void CConnectServerDlg::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	theApp.IniFile.SetVarStr("USERNAME","DEFUALTNAME",m_strUserName,1);
	CDialog::OnOK();
}

BOOL CConnectServerDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	GetClientRect(&rect);
	TempRect = rect;
	rect.bottom /= 2;
	rect.bottom += 20;
	ClientToScreen(&rect);

	MoveWindow(&rect);
	CenterWindow();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CConnectServerDlg::OnServerspecial() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if(!m_bServerSpecial)
	{
	
		MoveWindow(rect);

	}
	else
	{
		MoveWindow(TempRect);
	
	}
	CenterWindow();
	return;
}
