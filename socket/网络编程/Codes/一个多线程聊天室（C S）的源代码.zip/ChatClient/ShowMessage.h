#if !defined(AFX_SHOWMESSAGE_H__87F02A52_FB1A_4CDE_AF37_66BD3C2B4DC5__INCLUDED_)
#define AFX_SHOWMESSAGE_H__87F02A52_FB1A_4CDE_AF37_66BD3C2B4DC5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ShowMessage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CShowMessage dialog

class CShowMessage : public CDialog
{
// Construction
public:
	CShowMessage(CString strMessage,CString strClientName,CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CShowMessage)
	enum { IDD = IDD_SHOWMESSAGE };
	CString	m_strMessage;
	CString	m_strClientName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShowMessage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CShowMessage)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHOWMESSAGE_H__87F02A52_FB1A_4CDE_AF37_66BD3C2B4DC5__INCLUDED_)
