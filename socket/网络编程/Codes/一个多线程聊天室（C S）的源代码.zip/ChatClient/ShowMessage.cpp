// ShowMessage.cpp : implementation file
//

#include "stdafx.h"
#include "ChatClient.h"
#include "ShowMessage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShowMessage dialog


CShowMessage::CShowMessage(CString strMessage,CString strClientName,CWnd* pParent /*=NULL*/)
	: CDialog(CShowMessage::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShowMessage)
	m_strMessage = _T(strMessage);
	m_strClientName = _T(strClientName);
	//}}AFX_DATA_INIT
}


void CShowMessage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShowMessage)
	DDX_Text(pDX, IDC_MESSAGE, m_strMessage);
	DDX_Text(pDX, IDC_CLIENTNAME, m_strClientName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CShowMessage, CDialog)
	//{{AFX_MSG_MAP(CShowMessage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShowMessage message handlers

BOOL CShowMessage::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	GetDlgItem(IDC_MESSAGE) ->SetFocus();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
extern CChatClientApp theApp;
void CShowMessage::OnOK() 
{
	// TODO: Add extra validation here
	CString strButtonTitle;
	GetDlgItemText(IDOK,strButtonTitle);
	if(strButtonTitle == "�ظ�")
	{
		m_strMessage = "";
		UpdateData(FALSE);
		SetDlgItemText(IDOK,"����");
	}
	else
	{
		UpdateData();
		if(m_strMessage.GetLength())
		{
			Message msObj;
			memset(&msObj,0,sizeof(Message));
			msObj.iType = USERSESSION;
			msObj.iSubType = SAYINPRIVATE;
			CString strTemp  = theApp.m_skMainSocket.GetRoomName();
			int iLen = strTemp.GetLength();
			lstrcpy(msObj.strRoom,strTemp.GetBuffer(iLen));
			strTemp.ReleaseBuffer();
			strTemp = m_strMessage;
			iLen = strTemp.GetLength();
			iLen > 1024 ? 1024 : iLen;
			lstrcpy(msObj.strContent,strTemp.GetBuffer(iLen));
			strTemp.ReleaseBuffer();
			theApp.m_skMainSocket.Send(&msObj,sizeof(Message));
			//�Լ�������
			strTemp = theApp.m_skMainSocket.GetUserName();
			iLen = strTemp.GetLength();
			iLen > 20 ? 20:iLen;
			lstrcpy(msObj.strName,strTemp.GetBuffer(iLen));
			strTemp.ReleaseBuffer();
			//˵�����������
			
			strTemp =m_strClientName;
			iLen = strTemp.GetLength();
			iLen > 20 ? 20 : iLen;
			lstrcpy(msObj.strClientName,strTemp.GetBuffer(iLen));
			strTemp.ReleaseBuffer();
			theApp.m_skMainSocket.Send(&msObj,sizeof(Message));
		}
		CDialog::OnOK();
	}
	
}
