#if !defined(AFX_CONNECTSERVERDLG_H__03E121BB_3B98_41CB_B898_D4EC84AA2C94__INCLUDED_)
#define AFX_CONNECTSERVERDLG_H__03E121BB_3B98_41CB_B898_D4EC84AA2C94__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ConnectServerDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CConnectServerDlg dialog

class CConnectServerDlg : public CDialog
{
// Construction
public:
	CConnectServerDlg(CString strName,CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CConnectServerDlg)
	enum { IDD = IDD_CONNECTSERVER };
	CString	m_strServerIp;
	int		m_iServerPort;
	BOOL	m_bServerSpecial;
	CString	m_strUserName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConnectServerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
private:
		CRect rect;
		CRect TempRect;
	// Generated message map functions
	//{{AFX_MSG(CConnectServerDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnServerspecial();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONNECTSERVERDLG_H__03E121BB_3B98_41CB_B898_D4EC84AA2C94__INCLUDED_)
