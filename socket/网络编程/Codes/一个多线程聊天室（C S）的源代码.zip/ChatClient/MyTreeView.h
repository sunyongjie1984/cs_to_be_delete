#if !defined(AFX_MYTREEVIEW_H__D477B171_F2DC_433E_97D5_5934D2C6394D__INCLUDED_)
#define AFX_MYTREEVIEW_H__D477B171_F2DC_433E_97D5_5934D2C6394D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyTreeView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView view

class CMyTreeView : public CTreeView
{
protected:
	CMyTreeView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMyTreeView)

// Attributes
public:
	CTreeCtrl & m_Tree;
	CImageList  m_ImageList ;
	HTREEITEM    m_ParentItem;
// Operations
public:
	void OnNewClientIn(WPARAM wParam,LPARAM lParam);
	void OnClientOut(WPARAM wParam, LPARAM lParam);
	void OnSayInPrivate(WPARAM wParam,LPARAM lParam);
	void OnFileTrance(WPARAM wParam,LPARAM lParam);
	void OnAcceptFile(WPARAM wParam,LPARAM lParam);
	void OnFileTime(WPARAM wParam,LPARAM lParam);



// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyTreeView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMyTreeView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	void AddNewRoom(WPARAM wParam,LPARAM lParam);
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CMyTreeView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnRclick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnJoininroom();
	afx_msg void OnMenuSend();
	afx_msg void OnMenuTransefile();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYTREEVIEW_H__D477B171_F2DC_433E_97D5_5934D2C6394D__INCLUDED_)
