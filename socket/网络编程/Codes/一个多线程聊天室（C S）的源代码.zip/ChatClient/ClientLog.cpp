// ClientLog.cpp : implementation file
//

#include "stdafx.h"
#include "ChatClient.h"
#include "ClientLog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClientLog dialog


CClientLog::CClientLog(CWnd* pParent /*=NULL*/)
	: CDialog(CClientLog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CClientLog)
	m_strUsrName = _T("asdf");
	//}}AFX_DATA_INIT
}


void CClientLog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClientLog)
	DDX_Text(pDX, IDC_USERNAME, m_strUsrName);
	DDV_MaxChars(pDX, m_strUsrName, 20);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CClientLog, CDialog)
	//{{AFX_MSG_MAP(CClientLog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientLog message handlers

void CClientLog::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	CDialog::OnOK();
}

BOOL CClientLog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
