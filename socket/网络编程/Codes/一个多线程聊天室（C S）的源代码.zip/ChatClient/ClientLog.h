#if !defined(AFX_CLIENTLOG_H__65858385_8D78_4930_9580_BBD9C3081B2A__INCLUDED_)
#define AFX_CLIENTLOG_H__65858385_8D78_4930_9580_BBD9C3081B2A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ClientLog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CClientLog dialog

class CClientLog : public CDialog
{
// Construction
public:
	CClientLog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CClientLog)
	enum { IDD = IDD_CLIENTLOG };
	CString	m_strUsrName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientLog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CClientLog)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTLOG_H__65858385_8D78_4930_9580_BBD9C3081B2A__INCLUDED_)
