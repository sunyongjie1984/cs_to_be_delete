// MyTreeView.cpp : implementation file
//

#include "stdafx.h"
#include "ChatClient.h"
#include "MyTreeView.h"
#include "ClientLog.h"
#include "SendMessageDlg.h"
#include "ClientFormView.h"
#include "MainFrm.h"
#include "ShowMessage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView

IMPLEMENT_DYNCREATE(CMyTreeView, CTreeView)

CMyTreeView::CMyTreeView():m_Tree(GetTreeCtrl())
{

}

CMyTreeView::~CMyTreeView()
{

}


BEGIN_MESSAGE_MAP(CMyTreeView, CTreeView)
	//{{AFX_MSG_MAP(CMyTreeView)
	ON_WM_CREATE()
	ON_NOTIFY_REFLECT(NM_RCLICK, OnRclick)
	ON_COMMAND(ID_JOININROOM, OnJoininroom)
	ON_COMMAND(ID_MENU_SEND, OnMenuSend)
	ON_WM_LBUTTONDBLCLK()
	ON_NOTIFY_REFLECT(NM_RDBLCLK, OnRclick)
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnRclick)
	ON_COMMAND(ID_MENU_TRANSEFILE, OnMenuTransefile)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_FILETIME,OnFileTime)
	ON_MESSAGE(WM_ADDNEWROOM,AddNewRoom)
	ON_MESSAGE(WM_NEWCLIENTCOMEIN,OnNewClientIn)
	ON_MESSAGE(WM_USERLOGOUT,OnClientOut)
	ON_MESSAGE(WM_SAYINPRIVATE,OnSayInPrivate)
	ON_MESSAGE(WM_FILETRANCE,OnFileTrance)
	ON_MESSAGE(WM_ACCEPTFILE,OnAcceptFile)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView drawing

void CMyTreeView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView diagnostics

#ifdef _DEBUG
void CMyTreeView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CMyTreeView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}
#endif //_DEBUG
extern CChatClientApp theApp;
void CMyTreeView::AddNewRoom(WPARAM wParam,LPARAM lParam)
{
		//CString
	CMainFrame * m_pMainFrame = (CMainFrame *)AfxGetMainWnd();
	ASSERT_VALID(m_pMainFrame);
	ASSERT(m_pMainFrame != NULL);
	//CClientFormView *pFormView = m_pMainFrame->GetFormView();
	//pFormView->SetDlgItemText(IDC_SELFNAME,theApp.m_skMainSocket.GetUserName());
	Message *m_pNewRoom = (Message *)wParam;
	CString strRoom = m_pNewRoom ->strRoom;
	m_Tree.InsertItem(strRoom,2,3,m_ParentItem);
	m_Tree.Expand(m_ParentItem,TVE_EXPAND);
	
}

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView message handlers

int CMyTreeView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CTreeView::OnCreate(lpCreateStruct) == -1)
		return -1;


	// TODO: Add your specialized creation code here
	m_ImageList.Create(IDB_IMAGELIST,16,4,RGB(255,0,255));
	m_Tree.SetImageList(&m_ImageList,TVSIL_NORMAL);
	m_ParentItem = m_Tree.InsertItem("�������б�",2,3);
	
	return 0;
}
extern CChatClientApp theApp;

void CMyTreeView::OnRclick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	
	CMenu menu;

	CMenu * pContextMenu; 
	POINT point;
	GetCursorPos(&point);
//	CTreeView::OnLButtonDown(0,point);
	ScreenToClient(&point);
	
	HTREEITEM hItem = m_Tree.GetSelectedItem();
	CRect rect;
	m_Tree.GetItemRect(hItem,&rect,TRUE);

	if(rect.PtInRect(point))
	{
		if(m_Tree.GetParentItem(hItem) == m_ParentItem)
		{
			menu.LoadMenu(IDR_JOINROOM);
			pContextMenu = menu.GetSubMenu(0);
			ClientToScreen(&point);
			
			pContextMenu->TrackPopupMenu(TPM_LEFTBUTTON   ,point.x,point.y ,this);
		}
		else
		{
			if(hItem != m_ParentItem && m_Tree.GetItemText(hItem) != theApp.m_skMainSocket.GetUserName() && theApp.m_skMainSocket.GetState() == HAVELOGIN)
			{
				HTREEITEM hParent = m_Tree.GetParentItem(hItem);
				CString strRoom = m_Tree.GetItemText(hParent);
				if(strRoom == theApp.m_skMainSocket.GetRoomName())
				{
					menu.LoadMenu(IDR_CLIENT);
					pContextMenu = menu.GetSubMenu(0);
					ClientToScreen(&point);
					
					pContextMenu->TrackPopupMenu(TPM_LEFTBUTTON   ,point.x,point.y ,this);
					
				}
				else
					AfxMessageBox("���ڲ�ͬ�ķ����ڣ�����ִ�д������");
			}

		}
	}


	*pResult = 0;
}
extern CChatClientApp theApp;
void CMyTreeView::OnJoininroom() 
{
	// TODO: Add your command handler code here
	Message msObj;
	HTREEITEM hItem;
	
	if(theApp.m_skMainSocket.GetState() == NOTLOGIN)
	{
	//����msobj
	

		hItem = m_Tree.GetSelectedItem();
		CString strRoomName = m_Tree.GetItemText(hItem);
		CString strUsrName = theApp.m_skMainSocket.GetUserName();
	//	theApp.m_skMainSocket.SetUserName(strUsrName);
		theApp.m_skMainSocket.SetRoomName(strRoomName);
		theApp.m_skMainSocket.SetState(HAVELOGIN);
	

		msObj.iType = USERLOG;
		msObj.iSubType = USERLOGIN;
		int iLen = strRoomName.GetLength();
		iLen > 20 ? 20: iLen;
		lstrcpy(msObj.strRoom,strRoomName.GetBuffer(iLen));
		strRoomName.ReleaseBuffer();
		
		iLen = strUsrName.GetLength();
		iLen > 20 ? 20 : iLen;
		lstrcpy(msObj.strName,strUsrName.GetBuffer(iLen));
		strUsrName.ReleaseBuffer();
		
		iLen = theApp.m_skMainSocket.Send(&msObj,sizeof(msObj));
		if(iLen < sizeof(msObj))
		{
			AfxMessageBox("����ʧ��");
			return;
		}	
	}
	else
		if(theApp.m_skMainSocket.GetState() == HAVELOGIN)
		{
			HTREEITEM hItem = m_Tree.GetSelectedItem();
			CString strRoomName = m_Tree.GetItemText(hItem);
			if(strRoomName != theApp.m_skMainSocket.GetRoomName())
			{
				
				HTREEITEM hItem = m_Tree.GetChildItem(m_ParentItem);
							
				msObj.iType = USERSESSION;
				msObj.iSubType = CHANGEROOM;
				//�û���
				CString strTemp;
				strTemp =  theApp.m_skMainSocket.GetUserName();
				int iLen = strTemp.GetLength();
				iLen > 20 ? 20:iLen;
				lstrcpy(msObj.strName,strTemp.GetBuffer(iLen));
				strTemp.ReleaseBuffer();
				//�ɷ�����
				strTemp = theApp.m_skMainSocket.GetRoomName();
				iLen = strTemp.GetLength();
				iLen > 20 ? 20 : iLen;
				lstrcpy(msObj.strRoom,strTemp.GetBuffer(iLen));
				strTemp.ReleaseBuffer();
				//�·�����
				hItem = m_Tree.GetSelectedItem();
				strTemp = m_Tree.GetItemText(hItem);
				iLen = strTemp.GetLength();
				iLen > 20 ? 20 :iLen;
				lstrcpy(msObj.strContent,strTemp.GetBuffer(iLen));
				strTemp.ReleaseBuffer();
				
				if(theApp.m_skMainSocket.Send(&msObj,sizeof(msObj)) != sizeof(msObj))
				{
					AfxMessageBox("���ʹ���");
				}
				theApp.m_skMainSocket.SetRoomName(m_Tree.GetItemText(hItem));
			}
		}			
	return;
	
}
void CMyTreeView::OnClientOut(WPARAM wParam, LPARAM lParam)
{
	Message msObj = *(Message*)wParam;
	CString strRoom = msObj.strRoom;
	CString strUsrName = msObj.strName;
	HTREEITEM	hItem = m_Tree.GetChildItem(m_ParentItem);
	BOOL bFind = FALSE;
	while(hItem && !bFind)
	{
		CString strNodeName = m_Tree.GetItemText(hItem);
		if(strNodeName == strRoom)
		{
			//�����û�������һ��
			HTREEITEM hChildItem = m_Tree.GetChildItem(hItem);
			while(hChildItem)
			{
				CString strUserNode = m_Tree.GetItemText(hChildItem);
				if(strUserNode == strUsrName)
				{
					m_Tree.DeleteItem(hChildItem);
					m_Tree.Expand(hItem,TVE_EXPAND);
					bFind = TRUE;
					break;
				}
				hChildItem = m_Tree.GetNextItem(hChildItem,1);
			}
			
		
		}
		hItem = m_Tree.GetNextItem(hItem,1);
	}
}
void CMyTreeView::OnNewClientIn(WPARAM wParam, LPARAM lParam)
{
	Message msObj = *(Message*)wParam;
	CString strRoom = msObj.strRoom;
	CString strUsrName = msObj.strName;
	if(strRoom == theApp.m_skMainSocket.GetRoomName() && strUsrName == theApp.m_skMainSocket.GetUserName())
	{
		CClientFormView * m_pFormView =(CClientFormView *) ((CMainFrame * )AfxGetMainWnd())->GetFormView();
		ASSERT(m_pFormView != NULL);
		ASSERT_VALID(m_pFormView);
		m_pFormView ->SetDlgItemText(IDC_SELFNAME,strUsrName);
		m_pFormView ->SetDlgItemText(IDC_ROOMNAME,strRoom);
		return;
	}

	HTREEITEM hItem = m_Tree.GetChildItem(m_ParentItem);
	while(hItem)
	{
		CString strNodeName = m_Tree.GetItemText(hItem);
		CString strTemp = theApp.m_skMainSocket.GetUserName();
		if(strNodeName == strRoom)
		{
			if(strUsrName != strTemp)
			{
				m_Tree.InsertItem(strUsrName,0,1,hItem);
				m_Tree.Expand(hItem,TVE_EXPAND);
				break;
			}
		}
		hItem = m_Tree.GetNextItem(hItem,1);
	}


}

void CMyTreeView::OnMenuSend() 
{
	// TODO: Add your command handler code here
	CSendMessageDlg Dlg;
	
	if(Dlg.DoModal() == IDOK)
	{
		if(Dlg.m_strSentence.GetLength())
		{
			if(Dlg.m_strSentence.GetLength == 0)
				return;
			Message msObj;
			memset(&msObj,0,sizeof(Message));
			msObj.iType = USERSESSION;
			msObj.iSubType = SAYINPRIVATE;
			CString strTemp  = theApp.m_skMainSocket.GetRoomName();
			int iLen = strTemp.GetLength();
			lstrcpy(msObj.strRoom,strTemp.GetBuffer(iLen));
			strTemp.ReleaseBuffer();
			strTemp = Dlg.m_strSentence;
			iLen = strTemp.GetLength();
			iLen > 1024 ? 1024 : iLen;
			lstrcpy(msObj.strContent,strTemp.GetBuffer(iLen));
			strTemp.ReleaseBuffer();
			//�Լ�������
			strTemp = theApp.m_skMainSocket.GetUserName();
			iLen = strTemp.GetLength();
			iLen > 20 ? 20:iLen;
			lstrcpy(msObj.strName,strTemp.GetBuffer(iLen));
			strTemp.ReleaseBuffer();
			//˵�����������
			HTREEITEM hItem = m_Tree.GetSelectedItem();
			strTemp = m_Tree.GetItemText(hItem);
			iLen = strTemp.GetLength();
			iLen > 20 ? 20 : iLen;
			lstrcpy(msObj.strClientName,strTemp.GetBuffer(iLen));
			strTemp.ReleaseBuffer();

			 iLen = theApp.m_skMainSocket.Send(&msObj,sizeof(Message));


		}
		
	}

	return;	
}
void CMyTreeView::OnSayInPrivate(WPARAM wParam,LPARAM lParam)
{
	Message msObj = *(Message *)wParam;
	CString strContent  = msObj.strContent;
	CString strName = msObj.strName;
//	AfxMessageBox("ok");
	CShowMessage Dlg(strContent,strName);
	Dlg.DoModal();
	return;
}

BOOL CMyTreeView::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	cs.style |= TVS_HASLINES;
	cs.style |= TVS_LINESATROOT;
	cs.style |= TVS_HASBUTTONS;
	return CTreeView::PreCreateWindow(cs);
}

void CMyTreeView::OnMenuTransefile() 
{
	// TODO: Add your command handler code here
	Message msObj;
	memset(&msObj,0,sizeof(Message));
	msObj.iType = USERSESSION;
	msObj.iSubType = FILETRANCE;
	
	CString strTemp  = theApp.m_skMainSocket.GetRoomName();
	int iLen = strTemp.GetLength();
	lstrcpy(msObj.strRoom,strTemp.GetBuffer(iLen));
	strTemp.ReleaseBuffer();
/*	strTemp = Dlg.m_strSentence;
	iLen = strTemp.GetLength();
	iLen > 1024 ? 1024 : iLen;
	lstrcpy(msObj.strContent,strTemp.GetBuffer(iLen));
	strTemp.ReleaseBuffer();
	theApp.m_skMainSocket.Send(&msObj,sizeof(Message));*/
	//�Լ�������
	strTemp = theApp.m_skMainSocket.GetUserName();
	iLen = strTemp.GetLength();
	iLen > 20 ? 20:iLen;
	lstrcpy(msObj.strName,strTemp.GetBuffer(iLen));
	strTemp.ReleaseBuffer();
	//˵�����������
	HTREEITEM hItem = m_Tree.GetSelectedItem();
	strTemp = m_Tree.GetItemText(hItem);
	iLen = strTemp.GetLength();
	iLen > 20 ? 20 : iLen;
	lstrcpy(msObj.strClientName,strTemp.GetBuffer(iLen));
	strTemp.ReleaseBuffer();
	iLen = theApp.m_skMainSocket.Send(&msObj,sizeof(Message));
	return;

}
void CMyTreeView::OnFileTrance(WPARAM wParam,LPARAM lParam)
{
	Message msObj = *(Message *)wParam;
	CString strTitle = msObj.strName;
	strTitle+="���㴫���ļ�,���ܣ�";
	if(AfxMessageBox(strTitle,IDRETRY) == IDYES)
	{
		msObj.iSubType = ACCEPTFILE;
	}
	else
		msObj.iSubType = DECLINEFILE;
	msObj.iType = USERSESSION;
	
	CString strName = msObj.strName;
	CString strClientName = msObj.strClientName;
	
	int iLen = strName.GetLength();
	iLen > 20 ? 20 : iLen;
	lstrcpy(msObj.strClientName,strName.GetBuffer(iLen));
	strName.ReleaseBuffer();
	iLen = strClientName.GetLength();
	iLen > 20 ? 20 :iLen;
	lstrcpy(msObj.strName,strClientName.GetBuffer(iLen));
	strClientName.ReleaseBuffer();
	
	theApp.m_skMainSocket.Send(&msObj,sizeof(Message));
	
	

	return;

}
void CMyTreeView::OnAcceptFile(WPARAM wParam,LPARAM lParam)
{
	CFileDialog Dlg(TRUE,"*.*");
	Message  msObj = *(Message *)wParam;

	if(Dlg.DoModal() == IDOK)
	{
		//��ClientName��Name���ֻ��ཻ��
		CString strName = msObj.strName;
		CString strClientName = msObj.strClientName;
		
		int iLen = strName.GetLength();
		iLen > 20 ? 20 : iLen;
		lstrcpy(msObj.strClientName,strName.GetBuffer(iLen));
		strName.ReleaseBuffer();
		iLen = strClientName.GetLength();
		iLen > 20 ? 20 :iLen;
		lstrcpy(msObj.strName,strClientName.GetBuffer(iLen));
		strClientName.ReleaseBuffer();
		
		
		CString strFile = Dlg.GetFileName();
		CFile FileToSend;
		if(FileToSend.Open(strFile,CFile::modeRead && CFile::typeBinary))
		{
			
			msObj.iType = FILETIME;
			msObj.iSubType = FILETIMEBEGIN;
			iLen = strFile.GetLength();
			iLen > 1024 ? 1024: iLen;
			lstrcpy(msObj.strContent,strFile.GetBuffer(iLen));
			strFile.ReleaseBuffer();
			theApp.m_skMainSocket.Send(&msObj,sizeof(Message));
			Sleep(100);
			char FileContent[1024];
			memset(FileContent,0,1024);
			DWORD dwFileLength = FileToSend.GetLength();
			
			while(dwFileLength>0)
			{
				iLen = FileToSend.Read(FileContent,1024);
				msObj.iSubType = FILECONTENTLEN;
				CString strTemp;
				strTemp.Format("%d",iLen);
				int iTempLen = strTemp.GetLength();
				iTempLen > 1024?1024:iTempLen;
				lstrcpy(msObj.strContent,strTemp.GetBuffer(iTempLen));
				strTemp.ReleaseBuffer();

				theApp.m_skMainSocket.Send(&msObj,sizeof(Message));

				Sleep(100);
			//	if(iLen == 1024)
				msObj.iSubType = FILETIMEDURING;
			//	else
			//		msObj.iSubType = FILETIMEEND;
				lstrcpy(msObj.strContent,FileContent);
				theApp.m_skMainSocket.Send(&msObj,sizeof(Message));
				Sleep(100);
				dwFileLength -= iLen;

			}
			msObj.iSubType = FILETIMEEND;
			theApp.m_skMainSocket.Send(&msObj,sizeof(Message));
			FileToSend.Close();
				
	
			
		}
	
		
		
	}
	return;
}
void CMyTreeView::OnFileTime(WPARAM wParam,LPARAM lParam)
{

	Message  msObj = *(Message *)wParam;
	CString strTemp;
	char  FileContent[1024];
	int iLen = 0;
	CFile FileToSave;
	CFileDialog Dlg(FALSE,"*.*");
	switch(msObj.iSubType)
	{
	default:
		break;
	case FILETIMEBEGIN:
		if(Dlg.DoModal() == IDOK)
		{
			strTemp = Dlg.GetPathName();
		}
		else
			strTemp = msObj.strContent;
		if(FileToSave.Open(strTemp,CFile::modeCreate && CFile::typeBinary))
		{
		}
		break;
	case FILECONTENTLEN:
		strTemp = msObj.strContent;
		iLen = atoi(strTemp.GetBuffer(strTemp.GetLength()));
		break;
	case FILETIMEDURING:
		memset(FileContent,0,1024);
		theApp.m_skMainSocket.Receive(FileContent,iLen);
		if(iLen)
		FileToSave.Write(FileContent,1);
		break;
	case FILETIMEEND:
		memset(FileContent,0,1024);
		theApp.m_skMainSocket.Receive(FileContent,iLen);
		if(iLen)
			FileToSave.Write(FileContent,1);
		FileToSave.Close();
		AfxMessageBox("�ļ��������");

		break;

	}
	return;
}

