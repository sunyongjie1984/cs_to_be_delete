#if !defined(AFX_MAINSOCKET_H__53C49AD9_EC3F_4CAC_AE30_D5B30CFCEF08__INCLUDED_)
#define AFX_MAINSOCKET_H__53C49AD9_EC3F_4CAC_AE30_D5B30CFCEF08__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MainSocket.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CMainSocket command target

class CMainSocket : public CSocket
{
// Attributes
public:

// Operations
public:
	CMainSocket();
	virtual ~CMainSocket();
public:
	void SetState(const int state);
	int GetState();
	void SetRoomName(const CString Name)
	{
		strRoomName = Name;
	}
	CString GetRoomName()
	{
		return strRoomName;
	}
	CString GetUserName()
	{
		return strUserName;
	}
	void  SetUserName(const CString UsrName)
	{
		strUserName = UsrName;
	}

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainSocket)
	public:
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CMainSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
private:
	int iState;
	CString strRoomName;
	CString strUserName;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINSOCKET_H__53C49AD9_EC3F_4CAC_AE30_D5B30CFCEF08__INCLUDED_)
