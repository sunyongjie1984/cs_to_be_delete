// MainSocket.cpp : implementation file
//

#include "stdafx.h"
#include "ChatClient.h"
#include "MainSocket.h"
#include "MainFrm.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainSocket

CMainSocket::CMainSocket():iState(NOTLOGIN)
{
}

CMainSocket::~CMainSocket()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CMainSocket, CSocket)
	//{{AFX_MSG_MAP(CMainSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CMainSocket member functions

void CMainSocket::OnReceive(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	CMainFrame * pFrame = static_cast <CMainFrame *>(AfxGetMainWnd());
	CWnd * pTreeView = (CWnd*)pFrame->GetTreeView();
	Message msContent;
	int iLen1 = sizeof(msContent);	int iLen2 = sizeof(Message);
	memset(&msContent,0,sizeof(msContent));
	int iLen = Receive(&msContent,sizeof(msContent));


	CParseMessage Parse(pTreeView,msContent);
	Parse.SWitchMessage();
	


	CSocket::OnReceive(nErrorCode);
	
}
void CMainSocket::SetState(int state)
{
	if(state == NOTLOGIN || state == HAVELOGIN)
		iState = state;
}
int CMainSocket::GetState()
{	
	return iState;
}