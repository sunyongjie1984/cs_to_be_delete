#if !defined(AFX_SETSERVERPORTDLG_H__53CCCC79_33D6_44C1_9C56_A067449144AF__INCLUDED_)
#define AFX_SETSERVERPORTDLG_H__53CCCC79_33D6_44C1_9C56_A067449144AF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SetServerPortDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSetServerPortDlg dialog

class CSetServerPortDlg : public CDialog
{
// Construction
public:
	CSetServerPortDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSetServerPortDlg)
	enum { IDD = IDD_SETSERVERPORT };
	int		m_iServerPort;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetServerPortDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSetServerPortDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETSERVERPORTDLG_H__53CCCC79_33D6_44C1_9C56_A067449144AF__INCLUDED_)
