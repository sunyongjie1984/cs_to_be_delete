#include "Stdafx.h"
#include "ParseMessage.h"
#include "ClientSocket.h"
#include "CChatServer.h"
extern CCChatServerApp theApp;

CParseMessage::~CParseMessage()
{
}
CParseMessage::CParseMessage(const CWnd * pWnd,const Message & Value)
{
	pView = const_cast < CWnd *>(pWnd);
	Msg = Value;
}

BOOL CParseMessage::SWitchMessage()
{
	ASSERT(pView != NULL);
	ASSERT_VALID(pView);
	switch(Msg.iType)
	{
	case USERLOG:
		switch(Msg.iSubType)
		{
		case USERLOGIN:
			pView ->PostMessage(WM_NEWCLIENTCOMEIN,WPARAM(&Msg),0);
			break;
		default:
			break;
		}
		break;
	case USERSESSION:
		switch(Msg.iSubType)
		{
		default:
			break;
		case CHANGEROOM:
			pView ->PostMessage(WM_CHANGEROOM ,WPARAM(&Msg),0);
			break;
		case SAYINPRIVATE:
			pView->PostMessage(WM_SAYINPRIVATE,WPARAM(&Msg),0);
			break;
		case  FILETRANCE:
			pView ->PostMessage(WM_FILETRANCE,WPARAM(&Msg),0);
			break;
		case ACCEPTFILE:
			pView ->PostMessage(WM_FILETRANCE,WPARAM(&Msg),0);
			break;
		case DECLINEFILE:
			pView ->PostMessage(WM_FILETRANCE,WPARAM(&Msg),0);
			break;
	


		case USERQUIT:
			{
				g_cs.Lock();
				CString strUserName = Msg.strName;
				CString strRoomName = Msg.strRoom;
				CPtrList * m_pClientList = theApp.m_pClientSocketList;
				int iCount = m_pClientList->GetCount();
				POSITION pos = m_pClientList ->GetHeadPosition();
				POSITION tempos = pos;
				if(pos)
				{	 
					for(int i = 0; i < m_pClientList ->GetCount(); i++)
					{
						tempos = pos;
						CClientSocket *m_pClientSocket = static_cast < CClientSocket *>(m_pClientList->GetNext(pos));
						if(m_pClientSocket ->GetRoomName() == strRoomName && m_pClientSocket ->GetUserName() == strUserName)
						{
							m_pClientSocket ->ShutDown();
							m_pClientSocket ->Close();
							delete m_pClientSocket;
							m_pClientList->RemoveAt(tempos);
							break;
						}
						
					}
					g_cs.Unlock();
				}
				pView ->PostMessage(WM_USERLOGOUT,WPARAM(&Msg),0);
			}
			break;
		}
		break;
	case FILETIME:
		pView ->PostMessage(WM_FILETRANCE,WPARAM(&Msg),0);
		break;

	default:
			break;
		
	}
	return TRUE;
}




	/*	}

	

	else if(Msg.iType == USERSESSION && Msg.iSubType == CHANGEROOM)
	{
	
		pView ->PostMessage(WM_CHANGEROOM ,WPARAM(&Msg),0);
	}
	else if(Msg.iType == USERSESSION && Msg.iSubType == SAYINPRIVATE)
	{
		pView->PostMessage(WM_SAYINPRIVATE,WPARAM(&Msg),0);
	}
	else if(Msg.iType == USERSESSION && Msg.iSubType == USERQUIT)
	{
		g_cs.Lock();
		CString strUserName = Msg.strName;
		CString strRoomName = Msg.strRoom;
		CPtrList * m_pClientList = theApp.m_pClientSocketList;
		int iCount = m_pClientList->GetCount();
		POSITION pos = m_pClientList ->GetHeadPosition();
		POSITION tempos = pos;
		if(pos)
		{	 
			for(int i = 0; i < m_pClientList ->GetCount(); i++)
			{
				tempos = pos;
				CClientSocket *m_pClientSocket = static_cast < CClientSocket *>(m_pClientList->GetNext(pos));
				if(m_pClientSocket ->GetRoomName() == strRoomName && m_pClientSocket ->GetUserName() == strUserName)
				{
					m_pClientSocket ->ShutDown();
					m_pClientSocket ->Close();
					delete m_pClientSocket;
					m_pClientList->RemoveAt(tempos);
					break;
				}
				
			}
			g_cs.Unlock();
		}
		pView ->PostMessage(WM_USERLOGOUT,WPARAM(&Msg),0);
	}

	return TRUE;
}
*/