// MyTreeView.cpp : implementation file
//

#include "stdafx.h"
#include "CChatServer.h"
#include "MyTreeView.h"
#include "ClientSocket.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView

IMPLEMENT_DYNCREATE(CMyTreeView, CTreeView)

CMyTreeView::CMyTreeView():m_Tree(GetTreeCtrl())
{
}

CMyTreeView::~CMyTreeView()
{
}


BEGIN_MESSAGE_MAP(CMyTreeView, CTreeView)
	//{{AFX_MSG_MAP(CMyTreeView)
	ON_WM_CREATE()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_NEWCLIENTCOMEIN,OnNewClientIn)
	ON_MESSAGE(WM_CHANGEROOM,OnChangeRoom)
	ON_MESSAGE(WM_SAYINPRIVATE,OnSendInPrivate)
	ON_MESSAGE(WM_FILETRANCE,OnSendInPrivate)
//	ON_MESSAGE(WM_
	ON_MESSAGE(WM_USERLOGOUT,OnClientOut)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView drawing

void CMyTreeView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView diagnostics

#ifdef _DEBUG
void CMyTreeView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CMyTreeView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView message handlers

void CMyTreeView::OnInitialUpdate() 
{
	CTreeView::OnInitialUpdate();
	
	
}
extern CCChatServerApp theApp;
int CMyTreeView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CTreeView::OnCreate(lpCreateStruct) == -1)
		return -1;
	

		// TODO: Add your specialized creation code here
	m_ImageList.Create(IDB_IMAGELIST,32,1,RGB(255,0,255));
	m_Tree.SetImageList(&m_ImageList,TVSIL_NORMAL);
	m_ParentItem = m_Tree.InsertItem("�������б�",2,3);

	POSITION pos = theApp.m_ChatRoomList.GetHeadPosition();
	for(int i = 0; i < theApp.m_ChatRoomList.GetCount(); i ++)
	{
		CString * m_pstrRoom = static_cast <CString *>(theApp.m_ChatRoomList.GetNext(pos));
		m_Tree.InsertItem(m_pstrRoom->GetBuffer(8),2,3,m_ParentItem);
	//	m_pstrRoom = static_cast <CString *>(theApp.m_ChatRoomList.GetNext(pos));
	}
	m_Tree.Expand(m_ParentItem,TVE_EXPAND);
	
	return 0;
}
void CMyTreeView::OnClientOut(WPARAM wParam, LPARAM lParam)
{
	Message *msObj = (Message*)wParam;
	CString strRoom = msObj->strRoom;
	CString strUsrName = msObj->strName;
	HTREEITEM	hItem = m_Tree.GetChildItem(m_ParentItem);
	BOOL bFind = FALSE;
	while(hItem && !bFind)
	{
		CString strNodeName = m_Tree.GetItemText(hItem);
		if(strNodeName == strRoom)
		{
			//�����û�������һ��
			HTREEITEM hChildItem = m_Tree.GetChildItem(hItem);
			while(hChildItem)
			{
				CString strUserNode = m_Tree.GetItemText(hChildItem);
				if(strUserNode == strUsrName)
				{
					m_Tree.DeleteItem(hChildItem);
					m_Tree.Expand(hItem,TVE_EXPAND);
					bFind = TRUE;
					break;
				}
				hChildItem = m_Tree.GetNextItem(hChildItem,1);
			}
			
		
		}
		hItem = m_Tree.GetNextItem(hItem,1);
	}
//�������û������û��˳���Ϣ
	//���¹���msObj
	msObj ->iType = USERLOG;
	msObj ->iSubType = USERLOGOUT;
	int iLen = strUsrName.GetLength();
	iLen > 20 ? 20 : iLen;
	lstrcpy(msObj ->strName,strUsrName.GetBuffer(iLen));
	strUsrName.ReleaseBuffer();
	iLen = strRoom.GetLength();
	iLen > 20 ? 20 : iLen;
	lstrcpy(msObj ->strRoom,strRoom.GetBuffer(iLen));
	strRoom.ReleaseBuffer();
	g_cs.Lock();
	CPtrList * m_pClientList = theApp.m_pClientSocketList;
	POSITION pos = m_pClientList ->GetHeadPosition();
	if(pos)
	{
		CClientSocket *  m_pClientSocket;
		for(int i = 0; i < m_pClientList ->GetCount(); i++)
		{
			m_pClientSocket = static_cast < CClientSocket *>(m_pClientList->GetNext(pos));
			CString strTemp = m_pClientSocket ->GetRoomName();
			m_pClientSocket ->Send(msObj,sizeof(Message));
			
			Sleep(100);
			
		}
	}
	g_cs.Unlock();

}
void CMyTreeView::OnNewClientIn(WPARAM wParam, LPARAM lParam)
{
	Message *msObj = (Message*)wParam;
	CString strRoom = msObj->strRoom;
	CString strUsrName = msObj->strName;
	HTREEITEM hItem = m_Tree.GetChildItem(m_ParentItem);
	while(hItem)
	{
		CString strNodeName = m_Tree.GetItemText(hItem);
		if(strNodeName == strRoom)
		{
			m_Tree.InsertItem(strUsrName,0,1,hItem);
			m_Tree.Expand(hItem,TVE_EXPAND);
			break;
		}
		hItem = m_Tree.GetNextItem(hItem,1);
	}

	//�����е��û�������Ϣ
	msObj ->iType = USERLOG;
	msObj ->iSubType = USERLOGIN;
	int iLen = strUsrName.GetLength();
	iLen > 20 ? 20 : iLen;
	lstrcpy(msObj ->strName,strUsrName.GetBuffer(iLen));
	strUsrName.ReleaseBuffer();
	iLen = strRoom.GetLength();
	iLen > 20 ? 20 : iLen;
	lstrcpy(msObj ->strRoom,strRoom.GetBuffer(iLen));
	strRoom.ReleaseBuffer();
	g_cs.Lock();
	CPtrList * m_pClientList = theApp.m_pClientSocketList;
	int iCount = m_pClientList->GetCount();
	POSITION pos = m_pClientList ->GetHeadPosition();
	
	if(pos)
	{	 
		for(int i = 0; i < m_pClientList ->GetCount(); i++)
		{
			CClientSocket *m_pClientSocket = static_cast < CClientSocket *>(m_pClientList->GetNext(pos));
			iLen = m_pClientSocket ->Send(msObj,sizeof(Message));
			
			Sleep(100);
	
			
		}
	}
	g_cs.Unlock();
	return;

}
void CMyTreeView::OnChangeRoom(WPARAM wParam, LPARAM lParam)
{
	Message msObj = *(Message*)wParam;
	CString strName = msObj .strName;
	CString strNewRoom = msObj.strContent;
	int iType = msObj .iType;
	int iSubType = msObj.iSubType;

	OnClientOut((WPARAM)&msObj,0);

	msObj .iSubType = iSubType;
	msObj .iType = iType;
	int iLen = strName.GetLength();
	iLen > 20 ? 20 : iLen;
	lstrcpy(msObj .strName,strName.GetBuffer(iLen));

	iLen = strNewRoom.GetLength();
	iLen > 20 ? 20 : iLen;
	lstrcpy(msObj .strRoom,strNewRoom.GetBuffer(iLen));
	strNewRoom.ReleaseBuffer();
	OnNewClientIn((WPARAM)&msObj,lParam);
	return;

}
void CMyTreeView::OnSendInPrivate(WPARAM wParam,LPARAM lParam)
{
	Message msObj = *(Message *)wParam;
	CString strUserName = msObj.strName;
	CString strClientName = msObj.strClientName;
	g_cs.Lock();
	CPtrList * m_pClientList = theApp.m_pClientSocketList;
	int iCount = m_pClientList->GetCount();
	POSITION pos = m_pClientList ->GetHeadPosition();
	//�ҵ��û�����
	if(pos)
	{	 
		for(int i = 0; i < m_pClientList ->GetCount(); i++)
		{
			CClientSocket *m_pClientSocket = static_cast < CClientSocket *>(m_pClientList->GetNext(pos));
			CString strName = m_pClientSocket ->GetUserName();
			if(strName == strClientName )
			{
				m_pClientSocket ->Send(&msObj,sizeof(Message));
				CString strOut;
				strOut.Format("%d %d %s %s\n",msObj.iType,msObj.iSubType,msObj.strRoom,msObj.strName);
				TRACE0(strOut);

				g_cs.Unlock();
				return;
			}
			
		}
	}
	g_cs.Unlock();
	return;
}


void CMyTreeView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	CTreeView::OnTimer(nIDEvent);
}

BOOL CMyTreeView::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
		cs.style |= TVS_HASLINES;
	cs.style |= TVS_LINESATROOT;
	cs.style |= TVS_HASBUTTONS;

	return CTreeView::PreCreateWindow(cs);
}

