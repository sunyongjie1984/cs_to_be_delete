// CChatServerView.cpp : implementation of the CCChatServerView class
//

#include "stdafx.h"
#include "CChatServer.h"

#include "CChatServerDoc.h"
#include "CChatServerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCChatServerView

IMPLEMENT_DYNCREATE(CCChatServerView, CView)

BEGIN_MESSAGE_MAP(CCChatServerView, CView)
	//{{AFX_MSG_MAP(CCChatServerView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCChatServerView construction/destruction

CCChatServerView::CCChatServerView()
{
	// TODO: add construction code here

}

CCChatServerView::~CCChatServerView()
{
}

BOOL CCChatServerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CCChatServerView drawing

void CCChatServerView::OnDraw(CDC* pDC)
{
	CCChatServerDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CCChatServerView printing

BOOL CCChatServerView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CCChatServerView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CCChatServerView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CCChatServerView diagnostics

#ifdef _DEBUG
void CCChatServerView::AssertValid() const
{
	CView::AssertValid();
}

void CCChatServerView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CCChatServerDoc* CCChatServerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCChatServerDoc)));
	return (CCChatServerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCChatServerView message handlers
