#include "Stdafx.h"
#include "ParseMessage.h"
CParseMessage::~CParseMessage()
{
}
CParseMessage::CParseMessage(const CWnd * pWnd,const Message & Value)
{
	pView = const_cast < CWnd *>(pWnd);
	Msg = Value;
}
BOOL CParseMessage::SWitchMessage()
{
	ASSERT(pView != NULL);
	ASSERT_VALID(pView);
	if(Msg.iType == USERLOG && Msg.iSubType == ROOMLIST)
	{
		pView ->PostMessage(WM_ADDNEWROOM,WPARAM(&Msg),0);

	}
	return TRUE;

}
