#if !defined(AFX_MYTREEVIEW_H__3B48AB4D_2688_4DD0_A39F_49B96E80A027__INCLUDED_)
#define AFX_MYTREEVIEW_H__3B48AB4D_2688_4DD0_A39F_49B96E80A027__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyTreeView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView view

class CMyTreeView : public CTreeView
{
protected:
	CMyTreeView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMyTreeView)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyTreeView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMyTreeView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
public:
	void OnNewClientIn(WPARAM wParam,LPARAM lParam);
	void OnClientOut(WPARAM wParam, LPARAM lParam);
	void OnChangeRoom(WPARAM wParam,LPARAM lParam);
	void OnSendInPrivate(WPARAM wParam,LPARAM lParam);

	CTreeCtrl & m_Tree;
	CImageList  m_ImageList ;
	// Generated message map functions
protected:
	HTREEITEM m_ParentItem;
	//{{AFX_MSG(CMyTreeView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYTREEVIEW_H__3B48AB4D_2688_4DD0_A39F_49B96E80A027__INCLUDED_)
