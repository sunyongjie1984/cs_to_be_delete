//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CChatServer.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_FORMVIEW                    101
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_CCHATSTYPE                  129
#define IDI_ROOM                        132
#define IDI_ROOMSELECTED                133
#define IDI_MAN                         134
#define IDI_MANSELECTED                 136
#define IDB_IMAGELIST                   139
#define IDB_BITMAP1                     140
#define IDD_SETSERVERPORT               141
#define IDD_DIALOG1                     144
#define IDC_CLIENTIP                    1000
#define IDC_CLIENTNAME                  1001
#define IDC_CLIENTPORT                  1002
#define IDC_SERVERPORT                  1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
