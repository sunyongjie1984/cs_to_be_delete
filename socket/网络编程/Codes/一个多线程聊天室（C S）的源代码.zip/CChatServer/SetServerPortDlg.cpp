// SetServerPortDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CChatServer.h"
#include "SetServerPortDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetServerPortDlg dialog


CSetServerPortDlg::CSetServerPortDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetServerPortDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetServerPortDlg)
	m_iServerPort = 1080;
	//}}AFX_DATA_INIT
}


void CSetServerPortDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetServerPortDlg)
	DDX_Text(pDX, IDC_SERVERPORT, m_iServerPort);
	DDV_MinMaxInt(pDX, m_iServerPort, 0, 65536);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSetServerPortDlg, CDialog)
	//{{AFX_MSG_MAP(CSetServerPortDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetServerPortDlg message handlers
