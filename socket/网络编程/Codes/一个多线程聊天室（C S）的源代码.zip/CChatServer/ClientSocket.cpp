// ClientSocket.cpp : implementation file
//

#include "stdafx.h"
#include "CChatServer.h"
#include "ClientSocket.h"
#include "MainFrm.h"
#include "ParseMessage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClientSocket

CClientSocket::CClientSocket():iState(NOTLOGIN)
{
}

CClientSocket::~CClientSocket()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CClientSocket, CSocket)
//{{AFX_MSG_MAP(CClientSocket)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CClientSocket member functions

void CClientSocket::OnSend(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CSocket::OnSend(nErrorCode);
}
extern CCChatServerApp theApp;
void CClientSocket::OnReceive(int nErrorCode) 
{
	
	CMainFrame * pFrame = static_cast <CMainFrame *>(AfxGetMainWnd());
	CWnd * pTreeView = pFrame->GetTreeView();
	
	Message msContent;
	memset(&msContent,0,sizeof(msContent));
	//�õ�����
	Receive(&msContent,sizeof(msContent));
	//��������
	//�û���һ�ε�½,CClientSocket�б�����Ϣ
	g_cs.Lock();
	
	if(msContent.iType == FIRSTLOG)// && msContent.iSubType == FIRSTTIME)
	{
	//	static BOOL bFirst = TRUE;
		if(msContent.iSubType == FIRSTTIME)
			theApp.m_pClientSocketList->AddTail(this);
		CPtrList * m_pClientList = theApp.m_pClientSocketList;
		int iCount = m_pClientList->GetCount();
		POSITION pos = m_pClientList ->GetHeadPosition();
		
		if(pos)
		{	 
			CString strUserName = msContent.strName;
			for(int i = 0; i < m_pClientList ->GetCount()-1; i++)
			{
				CClientSocket *m_pClientSocket = static_cast < CClientSocket *>(m_pClientList->GetNext(pos));
				if(m_pClientSocket ->GetUserName() == strUserName)
				{
					Message msObj;
					memset(&msObj,0,sizeof(Message));
					msObj.iType = SYSERROR;
					msObj.iSubType = USEREXSIT;
					Send(&msObj,sizeof(Message));
					
					return;
				}
				
			}
			
		}
		Message msObj;
		::ZeroMemory(&msObj,sizeof(msObj));
		msObj.iType = USERLOG;
		msObj.iSubType = ROOMLIST;
		if(theApp.m_ChatRoomList.GetCount())
		{
			POSITION pos = theApp.m_ChatRoomList.GetHeadPosition();
			if(pos)
			{
				for(int i = 0 ; i < theApp.m_ChatRoomList.GetCount();i ++)
				{
					CString * m_pstrRoom = static_cast < CString *>(theApp.m_ChatRoomList.GetNext(pos));
					ASSERT(m_pstrRoom != NULL);
					int iLen = m_pstrRoom->GetLength();
					
					iLen > 20 ? iLen : 20;
					lstrcpy(msObj.strRoom,m_pstrRoom->GetBuffer(iLen));
					Send(&msObj,sizeof(msObj));
					
					Sleep(200);
					
				}
			}
			//�������е��û�����
			msObj.iType = USERLOG;
			msObj.iSubType = USERLIST;
			CPtrList * m_pClientList = theApp.m_pClientSocketList;
			pos = m_pClientList ->GetHeadPosition();
			int iCount = m_pClientList ->GetCount();
			if(pos && iCount > 0)
			{
				CClientSocket *  m_pClientSocket;
				for(int i = 0; i < iCount-1; i++)
				{
					m_pClientSocket = static_cast < CClientSocket *>(m_pClientList->GetNext(pos));
					CString strTemp = m_pClientSocket ->GetRoomName();
					int iLen = strTemp.GetLength();
					iLen > 20 ? 20 : iLen;
					lstrcpy(msObj.strRoom,strTemp.GetBuffer(iLen));
					strTemp.ReleaseBuffer();
					strTemp = m_pClientSocket ->GetUserName();
					iLen = strTemp.GetLength();
					iLen > 20 ? 20 : iLen;
					lstrcpy(msObj.strName,strTemp.GetBuffer(iLen));
					strTemp.ReleaseBuffer();
					Send(&msObj,sizeof(msObj));
					Sleep(100);
					
				}
			}
			
		
			g_cs.Unlock();
			
		}
		SetUserName(msContent.strName);
		SetState(HAVELOGIN);
	}
	
	if(msContent.iType == USERLOG && msContent.iSubType == USERLOGIN)
	{
		//����û����Ƿ����
		
		SetRoomName(msContent.strRoom);
		SetState(HAVELOGIN);
	}
	else if(msContent.iType == USERSESSION && msContent.iSubType == CHANGEROOM)
	{
		CString strNewRoom = msContent.strContent;
		SetRoomName(strNewRoom);
	}
	
	
	CParseMessage Parse(pTreeView,msContent);
	Parse.SWitchMessage();
	g_cs.Unlock();
	CSocket::OnReceive(nErrorCode);
	
}
