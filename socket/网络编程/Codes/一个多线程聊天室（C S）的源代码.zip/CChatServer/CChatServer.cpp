// CChatServer.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "CChatServer.h"
#include "SetServerPortDlg.h"
#include "MyTreeView.h"
#include "ClientSocket.h"
#include "CIniFile.h"

#include "MainFrm.h"
#include "CChatServerDoc.h"
#include "CChatServerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCChatServerApp

BEGIN_MESSAGE_MAP(CCChatServerApp, CWinApp)
	//{{AFX_MSG_MAP(CCChatServerApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCChatServerApp construction

CCChatServerApp::CCChatServerApp():bInit(FALSE)
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
	m_pClientSocketList = new CPtrList();
	CIniFile m_IniFile;
	bInit = 	m_IniFile.Create("RoomList.ini");
	if(bInit)
	{
	
		int   iRoomNum;
		m_IniFile.GetVarInt("ROOMNUM","RoomNumber",iRoomNum);
		for(int i = 1; i<=iRoomNum; i++)
		{	
			CString  *strRoom = new CString ;
			CString strTemp ;;
			strTemp.Format("Room%d",i);
			m_IniFile.GetVarStr("ROOMNAME",strTemp,*strRoom);
			m_ChatRoomList.AddTail(strRoom);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CCChatServerApp object

CCChatServerApp theApp;
CCriticalSection g_cs;

/////////////////////////////////////////////////////////////////////////////
// CCChatServerApp initialization

BOOL CCChatServerApp::InitInstance()
{
	if(!bInit)
	{
		AfxMessageBox("��ʼ���ļ�������");
		return FALSE;
	}
	if (!AfxSocketInit())
	{
	
		return FALSE;
	}
	

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CCChatServerDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		//RUNTIME_CLASS(CMyTreeView));
		NULL);
		AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
	{
		return FALSE;
	}

	// The one and only window has been initialized, so show and update it.
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
	m_pMainWnd->SetWindowText("��������");

	//
		// Place all significant initialization in InitInstance

	CSetServerPortDlg Dlg;
	if(Dlg.DoModal() == IDCANCEL)
	{
		return FALSE;
	}
	else
	{
		if(!m_skServerSocket.Create(Dlg.m_iServerPort))
		{
			if(m_ChatRoomList.GetCount())
			{
				m_ChatRoomList.RemoveAll();

			}
				return FALSE;
		}
	}
	if(!m_skServerSocket.Listen())
	{	return FALSE;
		
	}


	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CCChatServerApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CCChatServerApp message handlers


int CCChatServerApp::ExitInstance() 
{
	// TODO: Add your specialized code here and/or call the base class

//�������û������˳���Ϣ
   	Message msObj;
	msObj.iType = SYSERROR;
	msObj.iSubType = SERVERQUIT;

	CPtrList * m_pClientList = theApp.m_pClientSocketList;
	POSITION pos = m_pClientList ->GetHeadPosition();
	if(pos)
	{
		CClientSocket *  m_pClientSocket;
		for(int i = 0; i < m_pClientList ->GetCount(); i++)
		{
		//	if(m_pClientSocket ->GetState() == HAVELOGIN)
			{
				m_pClientSocket = static_cast < CClientSocket *>(m_pClientList->GetNext(pos));
				m_pClientSocket ->Send(&msObj,sizeof(Message));
				Sleep(100);
				

			}
			
		}
	}
	
	//ɾ��
	DeleteAllList();
	return CWinApp::ExitInstance();
}

void CCChatServerApp::DeleteAllList()
{

		
	//ɾ��
	POSITION pos = m_pClientSocketList ->GetHeadPosition();

	if(pos)
	{
		CClientSocket *  m_pClientSocket;
		for(int i = 0; i < m_pClientSocketList ->GetCount(); i++)
		{
			m_pClientSocket = static_cast < CClientSocket *>(m_pClientSocketList->GetNext(pos));
			ASSERT(m_pClientSocket != NULL);
			ASSERT_VALID(m_pClientSocket);
			delete m_pClientSocket;
			
		}
	}
//	if(m_pClientSocketList ->GetCount())
//	
	delete m_pClientSocketList;

	pos = m_ChatRoomList.GetHeadPosition();
	if(pos)
	{
		CString *  m_pRoomName;
		for(int i = 0; i < m_ChatRoomList .GetCount(); i++)
		{
			m_pRoomName = static_cast < CString  *>(m_ChatRoomList.GetNext(pos));
			ASSERT(m_pRoomName!=NULL);
			delete m_pRoomName;
			
		}
	}
	
//	m_ChatRoomList.RemoveAll();
}
