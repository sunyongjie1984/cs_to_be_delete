#if !defined(AFX_MYSOCKET_H__DF6FB001_509B_11D6_8E99_00E04C498874__INCLUDED_)
#define AFX_MYSOCKET_H__DF6FB001_509B_11D6_8E99_00E04C498874__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MySocket.h : header file


#define MYNET_CLIENTREAD	0
#define MYNET_CLIENTSEND	1
#define MYNET_CONNECT		2
#define MYNET_SERVERCLOSE	3
#define MYNET_SERVERREAD	4
#define MYNET_SERVERSEND	5
#define MYNET_ACCEPT		6
#define MYNET_CLIENTCLOSE	7



/////////////////////////////////////////////////////////////////////////////
// MySocket command target

class MySocket : public CAsyncSocket
{
public:
	MySocket();
	virtual ~MySocket();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(MySocket)
	public:
	virtual void OnSend(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(MySocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
public:
	BOOL SendStr(CString m_str);
	CString GetMessStr(void);
	void SetMessagePara(CWnd* pParent,UINT m_nMessageID);

protected:
	CWnd * m_pWnd;
	UINT m_UserMsg;
    char m_szBuffer[4096];  //��Ϣ������
	CString m_MessStr;

public:
	BOOL m_bAccept;
};




/////////////////////////////////////////////////////////////////////////////
// MyServerSocket command target

class MyServerSocket : public CAsyncSocket
{
public:
	MyServerSocket();
	virtual ~MyServerSocket();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(MyServerSocket)
	public:
	virtual void OnAccept(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(MyServerSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
public:
	BOOL SendStr(CString m_str);
	CString GetMessStr(void);
	void SetMessagePara(CWnd* pParent,UINT m_nMessageID);
	void CloseServer(void);

protected:
	CWnd *m_pWnd;
	UINT m_UserMsg;
	MySocket *m_pSocket;
	CString m_MessStr;
};



/////////////////////////////////////////////////////////////////////////////
// MyClientSocket command target

class MyClientSocket : public CAsyncSocket
{
public:
	MyClientSocket();
	virtual ~MyClientSocket();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(MyClientSocket)
	public:
	virtual void OnConnect(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	virtual void OnSend(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(MyClientSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
public:
	BOOL IsConnect(void);
	BOOL SendStr(CString m_str);
	CString GetMessStr(void);
	void Rest(void);
	void SetMessagePara(CWnd* pParent,UINT m_nMessageID);

protected:
	CWnd * m_pWnd;
	UINT m_UserMsg;
    BOOL m_bConnected;	 //�Ƿ�����
    char m_szBuffer[4096];  //��Ϣ������
	CString m_MessStr;
};



//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSOCKET_H__DF6FB001_509B_11D6_8E99_00E04C498874__INCLUDED_)
