// NetDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Net.h"
#include "NetDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetDlg dialog

CNetDlg::CNetDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNetDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNetDlg)
	m_message = _T("");
	m_port = 1025;
	m_type = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	NetType = 0;

	m_clientSocket.SetMessagePara(this,WM_MY_NETMESSAGE);
	m_srvrSocket.SetMessagePara(this,WM_MY_NETMESSAGE);
}

void CNetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNetDlg)
	DDX_Control(pDX, IDC_LINK, m_link);
	DDX_Control(pDX, IDC_ICONSTATE, m_iconstate);
	DDX_Control(pDX, IDC_IP, m_ipadrres);
	DDX_Text(pDX, IDC_MESSAGE, m_message);
	DDX_Text(pDX, IDC_PORT, m_port);
	DDV_MinMaxInt(pDX, m_port, 1024, 9999);
	DDX_Radio(pDX, IDC_SEVER, m_type);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CNetDlg, CDialog)
	//{{AFX_MSG_MAP(CNetDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SEND, OnSend)
	ON_BN_CLICKED(IDC_LINK, OnLink)
	ON_BN_CLICKED(IDC_CLIENT, OnClient)
	ON_BN_CLICKED(IDC_SEVER, OnSever)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_STOP, OnStop)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_MY_NETMESSAGE,MyNETMessage)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetDlg message handlers

LRESULT CNetDlg::MyNETMessage(WPARAM wParam, LPARAM lParam)
{
	CString str;

	switch(wParam){
	case MYNET_CLIENTREAD:
		str = m_clientSocket.GetMessStr();
		m_message = str;
			break;
	case MYNET_CLIENTSEND:
			break;
	case MYNET_CONNECT:
		m_message = "�������Ϸ����� !";
			break;
	case MYNET_SERVERCLOSE:
		m_message = "�������ѹر�";
			break;

	case MYNET_SERVERREAD:
		str = m_srvrSocket.GetMessStr();
		m_message = str;
			break;
	case MYNET_SERVERSEND:
			break;
	case MYNET_ACCEPT:
		KillTimer(2);
		m_message = "�ѽ��ܿͻ������� !";
			break;
	case MYNET_CLIENTCLOSE:
		m_message = "�ͻ����ѹر�";
			break;
	}

	UpdateData(false);
	return TRUE;
}


BOOL CNetDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	m_ipadrres.EnableWindow(FALSE);
	
	BYTE a1 = 127;
	BYTE a2 = 0;
	BYTE a3 = 0;
	BYTE a4 = 1;
	m_ipadrres.SetAddress(a1,a2,a3,a4);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CNetDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CNetDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CNetDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CNetDlg::OnSend() 
{
	// TODO: Add your control notification handler code here
	UpdateData(true);
	char ch[255];
	strcpy(ch,LPCTSTR(m_message));

	if(	!NetType )
	{
		m_srvrSocket.SendStr(m_message);
	}
	else
	{
		m_clientSocket.SendStr(m_message);
	}
}

void CNetDlg::OnLink() 
{
	// TODO: Add your control notification handler code here
	if(	!NetType )
	{
		if(m_srvrSocket.m_hSocket == INVALID_SOCKET)
		{
		    BOOL bFlag = m_srvrSocket.Create(m_port, SOCK_STREAM, FD_ACCEPT);
			if(!bFlag)
			{
    			MessageBox("���罨������ !");
		    	m_srvrSocket.Close();
		    	return;
			}
		}
		//���������ɹ����ȴ���������
		if(!m_srvrSocket.Listen(1))
		{
		    int nErrorCode = m_srvrSocket.GetLastError();
		    if(nErrorCode = WSAEWOULDBLOCK)
			{
		    	MessageBox("������������ !");
		    	m_srvrSocket.Close();
		    	return;
		    }
		}
		SetTimer(2,500,NULL);
	}
	else
	{
		BYTE a1,a2,a3,a4;
		m_ipadrres.GetAddress(a1,a2,a3,a4);
		m_ServerAdr.Format("%d.%d.%d.%d",a1,a2,a3,a4);
		
		m_clientSocket.ShutDown(2);
		m_clientSocket.Rest();
	    //������ʱ����ÿ1�볢������һ�Σ�ֱ�����ϻ�TryCount>10
		SetTimer(1,500,NULL);
		SetTimer(2,500,NULL);
		TryCount=0;
	}
}

void CNetDlg::OnClient() 
{
	// TODO: Add your control notification handler code here
	m_ipadrres.EnableWindow(TRUE);
	m_link.SetWindowText("����");
	m_type = 1;
	NetType = 1;
}

void CNetDlg::OnSever() 
{
	// TODO: Add your control notification handler code here
	m_ipadrres.EnableWindow(FALSE);
	m_link.SetWindowText("����");
	m_type = 0;
	NetType = 0;
}

void CNetDlg::OnTimer(UINT nIDEvent) 
{
	switch(nIDEvent){
	case 1:
		if (m_clientSocket.m_hSocket == INVALID_SOCKET)
		{
			BOOL bFlag=m_clientSocket.Create(0,SOCK_STREAM,FD_CONNECT);
			if(!bFlag)
			{	
				MessageBox("��������ʧ�� !");
				m_clientSocket.Close();
				KillTimer(1);
				KillTimer(2);
	    		return;
			}
		}
		m_clientSocket.Connect(m_ServerAdr,m_port);
		TryCount++;
		if (TryCount >=10 || m_clientSocket.IsConnect())
		{	
			KillTimer(1);
			KillTimer(2);
			if (TryCount >=10) AfxMessageBox("Connect Failed!");
		    return;
		}
		break;
	case 2:
		{
		    static BOOL bOne=TRUE;
			bOne=!bOne;
			HICON hIcon=AfxGetApp()->LoadIcon((bOne)?IDI_NET1:IDI_NET2);
			m_iconstate.SetIcon(hIcon);
		}
		break;
	}

	CDialog::OnTimer(nIDEvent);
}

void CNetDlg::OnStop() 
{
	// TODO: Add your control notification handler code here
	if(!NetType)
	{
		m_srvrSocket.Close();
		KillTimer(2);
	}
	else
	{
		KillTimer(1);
		KillTimer(2);
	}
}
