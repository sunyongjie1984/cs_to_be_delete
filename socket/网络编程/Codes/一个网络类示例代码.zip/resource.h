//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Net.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_NET_DIALOG                  102
#define CG_IDS_SOCKETS_INIT_FAILED      103
#define IDR_MAINFRAME                   128
#define IDI_NET1                        129
#define IDI_NET2                        130
#define IDC_SEVER                       1000
#define IDC_CLIENT                      1001
#define IDC_MESSAGE                     1002
#define IDC_SEND                        1003
#define IDC_PORT                        1004
#define IDC_IP                          1005
#define IDC_LINK                        1006
#define IDC_ICONSTATE                   1007
#define IDC_STOP                        1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
