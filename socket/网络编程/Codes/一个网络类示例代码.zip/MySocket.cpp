// MySocket.cpp : implementation file
//

#include "stdafx.h"
#include "MySocket.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// MySocket

// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(MySocket, CAsyncSocket)
	//{{AFX_MSG_MAP(MySocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0


MySocket::MySocket()
{
	m_bAccept = FALSE;
}

MySocket::~MySocket()
{
	if(m_hSocket != INVALID_SOCKET)	Close();
}

void MySocket::OnReceive(int nErrorCode) 
{
	int m_nLength = Receive(m_szBuffer, 4096);
	m_szBuffer[m_nLength]='\0';
	m_MessStr = m_szBuffer;
	m_pWnd->SendMessage(m_UserMsg, MYNET_SERVERREAD);

//	CAsyncSocket::OnReceive(nErrorCode);
}

void MySocket::OnSend(int nErrorCode) 
{
	while(Send(m_szBuffer, strlen(m_szBuffer)) == SOCKET_ERROR);
	m_MessStr = "Message Sended !";
	m_pWnd->SendMessage(m_UserMsg, MYNET_SERVERSEND);
	//��������һ���������������¼�������Server��Ϣ
	AsyncSelect(FD_READ | FD_CLOSE);

//	CAsyncSocket::OnSend(nErrorCode);
}

BOOL MySocket::SendStr(CString m_str)
{
	if(m_bAccept)
	{
		strcpy(m_szBuffer, LPCTSTR(m_str));
		AsyncSelect(FD_WRITE);
		return TRUE;
	}

	return FALSE;
}

CString MySocket::GetMessStr(void)
{
	return m_MessStr;
}

void MySocket::SetMessagePara(CWnd* pParent,UINT m_nMessageID)
{
	m_UserMsg = m_nMessageID;
	m_pWnd = pParent;
}

void MySocket::OnClose(int nErrorCode) 
{
	m_pWnd->SendMessage(m_UserMsg, MYNET_CLIENTCLOSE);

	CAsyncSocket::OnClose(nErrorCode);
}




/////////////////////////////////////////////////////////////////////////////
// MyServerSocket

// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(MyServerSocket, CAsyncSocket)
	//{{AFX_MSG_MAP(MyServerSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0


MyServerSocket::MyServerSocket()
{
	m_pSocket = new MySocket();
}

MyServerSocket::~MyServerSocket()
{
}

void MyServerSocket::OnAccept(int nErrorCode) 
{
	//�������������󣬵���Accept����
	MySocket* pSocket = new MySocket();
	if(Accept(*pSocket))
	{
		delete m_pSocket;

	    pSocket->AsyncSelect(FD_READ | FD_CLOSE);
		m_pSocket = pSocket;

		m_pSocket->SetMessagePara(m_pWnd,m_UserMsg);

		m_pSocket->m_bAccept = TRUE;
		m_pWnd->SendMessage(m_UserMsg, MYNET_ACCEPT);
	}
	else
	    delete pSocket;
	
//	CAsyncSocket::OnAccept(nErrorCode);
}

BOOL MyServerSocket::SendStr(CString m_str)
{
	return m_pSocket->SendStr(m_str);
}

CString MyServerSocket::GetMessStr(void)
{
	return m_pSocket->GetMessStr();
}

void MyServerSocket::SetMessagePara(CWnd* pParent,UINT m_nMessageID)
{
	m_UserMsg = m_nMessageID;
	m_pWnd = pParent;
	m_pSocket->SetMessagePara(m_pWnd,m_UserMsg);
}

void MyServerSocket::CloseServer(void) 
{
	m_pSocket->Close();
	delete m_pSocket;

	Close();
}



/////////////////////////////////////////////////////////////////////////////
// MyClientSocket

// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(MyClientSocket, CAsyncSocket)
	//{{AFX_MSG_MAP(MyClientSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0


MyClientSocket::MyClientSocket()
{
	m_bConnected = FALSE;
}

MyClientSocket::~MyClientSocket()
{
	//�ر��׽���
	if(m_hSocket != INVALID_SOCKET)	Close();
}

void MyClientSocket::OnConnect(int nErrorCode) 
{
	if (nErrorCode == 0)
	{
	    m_bConnected = TRUE;
		m_pWnd->SendMessage(m_UserMsg, MYNET_CONNECT);

		//	����һ���������������¼���׼������
		AsyncSelect(FD_READ  | FD_CLOSE);
	}

//	CAsyncSocket::OnConnect(nErrorCode);
}

void MyClientSocket::OnReceive(int nErrorCode) 
{
	int m_nLength = Receive(m_szBuffer, 4096);
	m_szBuffer[m_nLength]='\0';
	m_MessStr = m_szBuffer;
	m_pWnd->SendMessage(m_UserMsg, MYNET_CLIENTREAD);
	
//	CAsyncSocket::OnReceive(nErrorCode);
}

void MyClientSocket::OnSend(int nErrorCode) 
{
	while(Send(m_szBuffer, strlen(m_szBuffer)) == SOCKET_ERROR);
	m_MessStr = "Message Sended !";
	m_pWnd->SendMessage(m_UserMsg, MYNET_CLIENTSEND);
	//��������һ���������������¼�������Server��Ϣ
	AsyncSelect(FD_READ | FD_CLOSE);
	
//	CAsyncSocket::OnSend(nErrorCode);
}

BOOL MyClientSocket::IsConnect(void)
{
	return m_bConnected;
}

BOOL MyClientSocket::SendStr(CString m_str)
{
	if(m_bConnected)
	{
		strcpy(m_szBuffer, LPCTSTR(m_str));
		AsyncSelect(FD_WRITE);
		return TRUE;
	}

	return FALSE;
}

CString MyClientSocket::GetMessStr(void)
{
	return m_MessStr;
}

void MyClientSocket::Rest(void)
{
	m_hSocket = INVALID_SOCKET;
	m_bConnected = FALSE;
}

void MyClientSocket::SetMessagePara(CWnd* pParent,UINT m_nMessageID)
{
	m_UserMsg = m_nMessageID;
	m_pWnd = pParent;
}

void MyClientSocket::OnClose(int nErrorCode) 
{
	m_pWnd->SendMessage(m_UserMsg, MYNET_SERVERCLOSE);
	
	CAsyncSocket::OnClose(nErrorCode);
}
