// NetDlg.h : header file
//

#if !defined(AFX_NETDLG_H__6E075E27_4F21_11D6_8E99_00E04C498874__INCLUDED_)
#define AFX_NETDLG_H__6E075E27_4F21_11D6_8E99_00E04C498874__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MySocket.h"
/////////////////////////////////////////////////////////////////////////////
// CNetDlg dialog

#define WM_MY_NETMESSAGE WM_USER + 999


class CNetDlg : public CDialog
{
// Construction
public:
	CNetDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CNetDlg)
	enum { IDD = IDD_NET_DIALOG };
	CButton	m_link;
	CStatic	m_iconstate;
	CIPAddressCtrl	m_ipadrres;
	CString	m_message;
	int		m_port;
	int		m_type;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CNetDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSend();
	afx_msg void OnLink();
	afx_msg void OnClient();
	afx_msg void OnSever();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnStop();
	//}}AFX_MSG
	LRESULT	MyNETMessage(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

public:
	BOOL NetType;

	int TryCount;
	CString m_ServerAdr;
	MyClientSocket m_clientSocket;
	MyServerSocket m_srvrSocket;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NETDLG_H__6E075E27_4F21_11D6_8E99_00E04C498874__INCLUDED_)
