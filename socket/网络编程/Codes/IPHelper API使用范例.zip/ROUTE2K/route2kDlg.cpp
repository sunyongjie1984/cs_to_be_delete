// route2kDlg.cpp : implementation file
//

#include "stdafx.h"
#include "route2k.h"
#include "route2kDlg.h"
#include "Iprtrmib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRoute2kDlg dialog

CRoute2kDlg::CRoute2kDlg(CWnd* pParent /*=NULL*/)
: CDialog(CRoute2kDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRoute2kDlg)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CRoute2kDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRoute2kDlg)
	DDX_Control(pDX, IDC_COMBO2, m_use_ip);
	DDX_Control(pDX, IDC_IPADDRESS2, m_ip_add);
	DDX_Control(pDX, IDC_COMBO3, m_current_ip);
	DDX_Control(pDX, IDC_IPADDRESS1, m_ip);
	DDX_Control(pDX, IDC_COMBO1, m_ifcb);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRoute2kDlg, CDialog)
//{{AFX_MSG_MAP(CRoute2kDlg)
ON_WM_PAINT()
ON_WM_QUERYDRAGICON()
ON_BN_CLICKED(IDC_BUTTON3, OnSetRoute)
ON_BN_CLICKED(IDC_BUTTON1, OnAddip)
ON_BN_CLICKED(IDC_BUTTON2, OnRelease)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRoute2kDlg message handlers

BOOL CRoute2kDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	pIpAbstract = new IpAbstract();
	POSITION pos1;
	for( pos1 = pIpAbstract->m_iflist.GetHeadPosition(); pos1 != NULL; )    
		m_ifcb.AddString(pIpAbstract->m_iflist.GetNext( pos1 ));
	for( pos1 = pIpAbstract->m_iplist.GetHeadPosition(); pos1 != NULL; )    
		m_current_ip.AddString(pIpAbstract->m_iplist.GetNext( pos1 ));
	for( pos1 = pIpAbstract->m_iplist.GetHeadPosition(); pos1 != NULL; )    
		m_use_ip.AddString(pIpAbstract->m_iplist.GetNext( pos1 ));
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CRoute2kDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting
		
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		
		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		
		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CRoute2kDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CRoute2kDlg::OnSetRoute() 
{
	UpdateData(TRUE);
	MIB_IPFORWARDROW Route;
	char lpszText[256] = "";
    DWORD dwDestAddr;
    DWORD dwSourceAddr = 0;
	m_ip.GetAddress(dwDestAddr);
	m_ifcb.GetLBText(m_ifcb.GetCurSel(),lpszText);
	ULONG selIdx = pIpAbstract->GetInterfaceIndex(lpszText);
	GetBestRoute(dwDestAddr,dwSourceAddr,&Route);
	/*	m_ip.GetAddress((Route.dwForwardDest)); // IP addr of destination
    Route.dwForwardMask = 0xffffff00;       // subnetwork mask of destination
    Route.dwForwardPolicy = 0;     // conditions for multi-path route
	m_ip.GetAddress((Route.dwForwardNextHop)); // IP address of next hop
	Route.dwForwardIfIndex;    // index of interface
    Route.dwForwardType = 3;       // route type
    Route.dwForwardAge;        // age of route
    Route.dwForwardNextHopAS;  // autonomous system number 
	// of next hop
    Route.dwForwardMetric1;    // protocol-specific metric 
    Route.dwForwardMetric2;    // protocol-specific metric 
    Route.dwForwardMetric3;    // protocol-specific metric 
    Route.dwForwardMetric4;    // protocol-specific metric 
    Route.dwForwardMetric5;    // protocol-specific metric */
	/*	Route.dwForwardDest = dwDestAddr; 
	Route.dwForwardIfIndex = selIdx;
	Route.dwForwardProto = MIB_IPPROTO_NETMGMT;*/
	DWORD res = SetIpForwardEntry(&Route);
	if(res == ERROR_INVALID_PARAMETER)
	{
		MessageBox("ERROR_INVALID_PARAMETER","ERROR",MB_OK);
	}
	else if(res == ERROR_NOT_SUPPORTED)
	{
		MessageBox("ERROR_NOT_SUPPORTED","ERROR",MB_OK);
	}
	else
	{
		char lpMsgBuf[128]="";
		DWORD eRRR = GetLastError();
		FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_IGNORE_INSERTS,NULL,eRRR,0,lpMsgBuf,128,NULL);
		MessageBox(lpMsgBuf,"ERROR",MB_OK);
	}
}

void CRoute2kDlg::OnAddip() 
{
	UpdateData(TRUE);
	DWORD dwDestAddr;
	char lpszText[256] = "";
	char ip[20] = "";
	DWORD dwip;
	BYTE nField0,nField1,nField2,nField3;
	m_ip_add.GetAddress(nField0,nField1,nField2,nField3);
	m_ip_add.GetAddress(dwip);
	wsprintf(ip,"%d.%d.%d.%d",nField0,nField1,nField2,nField3);
	dwDestAddr = inet_addr(ip);
	m_ifcb.GetLBText(m_ifcb.GetCurSel(),lpszText);
	ULONG selIdx = pIpAbstract->GetInterfaceIndex(lpszText);
	char lpMsgBuf[128]="";
	DWORD res = AddIPAddress(dwDestAddr,0x00ffffff,selIdx,&NTEContext,&NTEInstance);	
	if(res != NO_ERROR)
	{
		DWORD eRRR = GetLastError();
		FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_IGNORE_INSERTS,NULL,eRRR,0,lpMsgBuf,128,NULL);
		MessageBox(lpMsgBuf,"ERROR",MB_OK);
	}
	else
	{
		pIpAbstract->SetIPAdrNETContextMap(dwip,NTEContext);
	}
}

void CRoute2kDlg::OnRelease() 
{
	UpdateData(TRUE);
	char lpszText[256] = "";
	m_current_ip.GetLBText(m_current_ip.GetCurSel(),lpszText);
	ULONG delIdx = 0;
	pIpAbstract->ip2ntemap.Lookup(inet_addr(lpszText),delIdx);
	if(delIdx != 0)
	{
		DWORD res = DeleteIPAddress(delIdx);
		if(res != NO_ERROR)
		{
			char lpMsgBuf[128]="";
			DWORD eRRR = GetLastError();
			FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_IGNORE_INSERTS,NULL,eRRR,0,lpMsgBuf,128,NULL);
			MessageBox(lpMsgBuf,"ERROR",MB_OK);
		}
	}
}
