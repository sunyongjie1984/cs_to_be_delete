#include "stdafx.h"
#include "IpAbstract.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

IpAbstract::IpAbstract()
{
	GetNumberOfInterfaces(&num_nif);
	pIfTable = NULL;
	dwOutBufLen = 0;
	DWORD res;
	res = GetInterfaceInfo((PIP_INTERFACE_INFO)pIfTable,&dwOutBufLen);
	if(res == ERROR_INVALID_PARAMETER)
		MessageBox(NULL,"ERROR_INVALID_PARAMETER","ERROR",MB_OK);
	else if(res == ERROR_INSUFFICIENT_BUFFER)
	{
		pIfTable = new BYTE[dwOutBufLen];
		GetInterfaceInfo((PIP_INTERFACE_INFO)pIfTable,&dwOutBufLen);
	}
	else if(res == ERROR_NOT_SUPPORTED)
		MessageBox(NULL,"ERROR_NOT_SUPPORTED","ERROR",MB_OK);
	PIP_INTERFACE_INFO pII = (PIP_INTERFACE_INFO)pIfTable;
	for(int i=0;i<pII->NumAdapters;i++)
	{
		char wchrTgt[256] = "";
		memset(wchrTgt,0,256);
		WideCharToMultiByte(CP_ACP,0,(unsigned short*)&(pII->Adapter[i].Name),128,wchrTgt,256,NULL,NULL);
		POSITION pos1 = NULL;
		POSITION pos2 = NULL;
		if( ( pos1 = m_iflist.GetHeadPosition() ) != NULL )    
			pos2 = m_iflist.InsertAfter(pos1,wchrTgt);  
		else
			m_iflist.AddHead(wchrTgt);	
	}
	dwOutBufLen = 0;
	res = GetIpAddrTable((PMIB_IPADDRTABLE)pIpAddrTable,&dwOutBufLen,true);
	if(dwOutBufLen > 0)
	{
		pIpAddrTable = new BYTE[dwOutBufLen];
		GetIpAddrTable((PMIB_IPADDRTABLE)pIpAddrTable,&dwOutBufLen,true);
	}
	PMIB_IPADDRTABLE pIPTBL = (PMIB_IPADDRTABLE)pIpAddrTable;
	for(unsigned long j=0;j<pIPTBL->dwNumEntries;j++)
	{
		char wchrTgt[32] = "";
		POSITION pos1 = NULL;
		POSITION pos2 = NULL;
		SetIPAdrNETContextMap(pIPTBL->table[j].dwAddr,j+1);
		wsprintf(wchrTgt,"%d.%d.%d.%d",(pIPTBL->table[j].dwAddr&0xFF),((pIPTBL->table[j].dwAddr>>8 ) & 0xFF),((pIPTBL->table[j].dwAddr>>16) & 0xFF),((pIPTBL->table[j].dwAddr>>24) & 0xFF));
		if( ( pos1 = m_iplist.GetHeadPosition() ) != NULL )    
			pos2 = m_iplist.InsertAfter(pos1,wchrTgt);  
		else
			m_iplist.AddHead(wchrTgt);	
	}
}

IpAbstract::~IpAbstract()
{
	if(pIfTable != NULL)
		delete pIfTable;
}

ULONG IpAbstract::GetInterfaceIndex(char *iName)
{
	PIP_INTERFACE_INFO pII = (PIP_INTERFACE_INFO)pIfTable;
	for(int i=0;i<pII->NumAdapters;i++)
	{
		char wchrTgt[256] = "";
		memset(wchrTgt,0,256);
		WideCharToMultiByte(CP_ACP,0,(unsigned short*)&(pII->Adapter[i].Name),128,wchrTgt,256,NULL,NULL);
		if(strcmp(wchrTgt,iName)==0)
			return pII->Adapter[i].Index;
	}
	return 0;
}

ULONG IpAbstract::GetIPAdrNTEContext(char *sz_ip)
{
	return 0;
}


void IpAbstract::SetIPAdrNETContextMap(DWORD ip, ULONG nte)
{
	ip2ntemap.SetAt(ip,nte);
	return;
}
