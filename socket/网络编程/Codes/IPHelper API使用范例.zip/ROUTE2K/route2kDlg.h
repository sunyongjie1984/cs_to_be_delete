// route2kDlg.h : header file
//

#if !defined(AFX_ROUTE2KDLG_H__ADF0E6F3_7FA9_41F6_9882_A4D54C84E6DF__INCLUDED_)
#define AFX_ROUTE2KDLG_H__ADF0E6F3_7FA9_41F6_9882_A4D54C84E6DF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "IpAbstract.h"
/////////////////////////////////////////////////////////////////////////////
// CRoute2kDlg dialog

class CRoute2kDlg : public CDialog
{
// Construction
public:
	CStringList m_iflist;
	IpAbstract* pIpAbstract;
	CRoute2kDlg(CWnd* pParent = NULL);	// standard constructor
    ULONG NTEContext;     // Net Table Entry context
    ULONG NTEInstance;   
// Dialog Data
	//{{AFX_DATA(CRoute2kDlg)
	enum { IDD = IDD_ROUTE2K_DIALOG };
	CComboBox	m_use_ip;
	CIPAddressCtrl	m_ip_add;
	CComboBox	m_current_ip;
	CIPAddressCtrl	m_ip;
	CComboBox	m_ifcb;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRoute2kDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CRoute2kDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSetRoute();
	afx_msg void OnAddip();
	afx_msg void OnRelease();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ROUTE2KDLG_H__ADF0E6F3_7FA9_41F6_9882_A4D54C84E6DF__INCLUDED_)
