// IpAbstract.h: interface for the IpAbstract class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IPABSTRACT_H__D41CC5CD_EFAF_4031_A6E3_ACAF633B754E__INCLUDED_)
#define AFX_IPABSTRACT_H__D41CC5CD_EFAF_4031_A6E3_ACAF633B754E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Iphlpapi.h"

class IpAbstract  
{
public:
	void SetIPAdrNETContextMap(DWORD ip,ULONG nte);
	ULONG GetIPAdrNTEContext(char* sz_ip);
	CStringList m_iplist;
	ULONG GetInterfaceIndex(char* iName);
	CStringList m_iflist;
	DWORD num_nif;
	IpAbstract();
	CMap <DWORD,DWORD,ULONG,ULONG> ip2ntemap;
	virtual ~IpAbstract();

protected:
	IP_ADAPTER_INDEX_MAP nifadaptor[9];
	DWORD dwOutBufLen;
	LPBYTE pIfTable; 
	LPBYTE pIpAddrTable;
};

#endif // !defined(AFX_IPABSTRACT_H__D41CC5CD_EFAF_4031_A6E3_ACAF633B754E__INCLUDED_)
