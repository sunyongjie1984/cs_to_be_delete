// DlgIpIn.cpp : implementation file
//

#include "stdafx.h"
#include "SnmpManager.h"
#include "DlgIpIn.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgIpIn dialog


CDlgIpIn::CDlgIpIn(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgIpIn::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgIpIn)
	m_IpAddress = _T("");
	//}}AFX_DATA_INIT
}


void CDlgIpIn::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgIpIn)
	DDX_Text(pDX, IDC_EDIT1, m_IpAddress);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgIpIn, CDialog)
	//{{AFX_MSG_MAP(CDlgIpIn)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgIpIn message handlers
