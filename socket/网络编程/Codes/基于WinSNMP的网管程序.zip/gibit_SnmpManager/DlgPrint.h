#if !defined(AFX_DLGPRINT_H__5A39D45C_FD6A_47D8_94DB_E38A379DB4A6__INCLUDED_)
#define AFX_DLGPRINT_H__5A39D45C_FD6A_47D8_94DB_E38A379DB4A6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgPrint.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgPrint dialog

class CDlgPrint : public CDialog
{
// Construction
public:
	CDlgPrint(CWnd* pParent = NULL);// standard constructor

	LPTSTR* m_Oid;
	LPTSTR* m_value;
	int n;

// Dialog Data
	//{{AFX_DATA(CDlgPrint)
	enum { IDD = IDD_DIALOG1 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgPrint)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:


	// Generated message map functions
	//{{AFX_MSG(CDlgPrint)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPRINT_H__5A39D45C_FD6A_47D8_94DB_E38A379DB4A6__INCLUDED_)
