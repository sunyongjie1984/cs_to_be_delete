// Snmp1.h: interface for the CSnmp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SNMP1_H__CA06E5D7_9923_4E40_8D50_2BE119C4C9D0__INCLUDED_)
#define AFX_SNMP1_H__CA06E5D7_9923_4E40_8D50_2BE119C4C9D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "winsnmp.h"
#include "stdafx.h"

class CSnmp  
{
public:
	CSnmp();
	~CSnmp();
	
private:
	smiLPUINT32 nMajorVersion,nMinorVersion,nLevel,nTranslateMode;
	smiLPUINT32 nRetransmitMode;
	HSNMP_SESSION session;
	CString strErr;
	HSNMP_PDU m_hpdu;
	HSNMP_VBL m_hvbl;

public:
	int nCount;
	BOOL sessionID;
	

public:
	CreateSession(HWND hWnd,UINT wMsg);
	Send(LPCSTR address,const char* community/*,HSNMP_PDU pdu*/);
	CreatePdu(
		smiINT PDU_type,       // PDU type 
		smiINT32 request_id,   // PDU request identifier 
		smiINT error_status,   // PDU error status, unless type is SNMP_PDU_GETBULK
		smiINT error_index   // PDU error index, unless type is SNMP_PDU_GETBULK
		//HSNMP_VBL varbindlist  // handle to the variable bindings list 
		);
	CreateVbl(LPCSTR name,smiLPVALUE pvalue);
	Register();
	Receive(LPTSTR *name,smiLPVALUE *value);
	SetVbl(LPCSTR name);	

};

#endif // !defined(AFX_SNMP1_H__CA06E5D7_9923_4E40_8D50_2BE119C4C9D0__INCLUDED_)
