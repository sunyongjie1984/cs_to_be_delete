// Snmp1.cpp: implementation of the CSnmp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "snmp.h"
#include "SnmpManager.h"

#ifdef _DEBUG
//CMemoryState oldMemState,newMemState,diffMemState;
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSnmp::CSnmp()
 {
	nMajorVersion=new unsigned long;
	nMinorVersion=new unsigned long;
	nLevel=new unsigned long;
	nTranslateMode=new unsigned long;
	nRetransmitMode=new unsigned long;
 	if(SnmpStartup(nMajorVersion,nMinorVersion,nLevel,nTranslateMode,
 				nRetransmitMode)!=SNMPAPI_SUCCESS)
		{//dwErr=SnmpGetLastError(NULL);
		 AfxMessageBox("initilization failure");}
	if(SnmpSetTranslateMode(SNMPAPI_UNTRANSLATED_V1)!=SNMPAPI_SUCCESS)
		AfxMessageBox("SetTranslateMode failure");
	if(SnmpSetRetransmitMode(SNMPAPI_ON)!=SNMPAPI_SUCCESS)
		AfxMessageBox("SetRetransmitMode failure");
	sessionID=FALSE;
}

CSnmp::~CSnmp()
{
	if(nRetransmitMode!=NULL)
		delete nRetransmitMode;
	if(nTranslateMode!=NULL)
		delete nTranslateMode;
	if(nLevel!=NULL)
		delete nLevel;
	if(nMinorVersion!=NULL)
		delete nMinorVersion;
	if(nMajorVersion!=NULL)
		delete nMajorVersion;
	if(session!=NULL)
		SnmpClose(session);
	SnmpCleanup();


}

CSnmp::CreateSession(HWND hWnd,UINT wMsg)
{
	if((session=SnmpCreateSession(hWnd,wMsg,NULL,NULL))==SNMPAPI_FAILURE)
		AfxMessageBox("CreateSession failure");
}

CSnmp::CreateVbl(LPCSTR name,smiLPVALUE pvalue)
{
	smiLPOID pOid=new smiOID;
	if(SnmpStrToOid(name,pOid)==SNMPAPI_FAILURE)
		{AfxMessageBox("CreateVbl failure");
		//dwErr=SnmpGetLastError(session);
		}
	m_hvbl=SnmpCreateVbl(session,pOid,pvalue);
	if(m_hvbl==SNMPAPI_FAILURE)
		{AfxMessageBox("CreateVbl failure");
		//dwErr=SnmpGetLastError(session);
		}
	if(pOid!=NULL)
		delete pOid;
}

CSnmp::SetVbl(LPCSTR name)
{
	smiLPOID pOid=new smiOID;
	if(SnmpStrToOid(name,pOid)==SNMPAPI_FAILURE)
		{AfxMessageBox("SetVbl failure--oid");
		//dwErr=SnmpGetLastError(session);
		}
	if(SnmpSetVb(m_hvbl,0,pOid,NULL)==SNMPAPI_FAILURE)
		{AfxMessageBox("SetVbl failure");
		//dwErr=SnmpGetLastError(session);
		}
	if(pOid!=NULL)
		delete pOid;
}


CSnmp::CreatePdu(smiINT PDU_type,smiINT32 request_id,
				 smiINT error_status,smiINT error_index)
{
	m_hpdu=SnmpCreatePdu(session,PDU_type,NULL,error_status,error_index,m_hvbl);
	if(m_hpdu==SNMPAPI_FAILURE)
	{
		AfxMessageBox("CreatePdu failure");
		//dwErr=SnmpGetLastError(session);
	}
	else if (error_status > 0)
                {
                AfxMessageBox("Error: error_status=%d, error_index=%d\n",
                       error_status, error_index);
                }
}

CSnmp::Send(LPCSTR address,const char * community)
{
//	oldMemState.Checkpoint();
	HSNMP_ENTITY hAgent;
	if((hAgent=SnmpStrToEntity(session,address))==SNMPAPI_FAILURE)
		AfxMessageBox("SendMsg failure--entity");
	smiOCTETS contextName;
	contextName.ptr=(unsigned char *)community;
	contextName.len=lstrlen(community);
	HSNMP_CONTEXT hView;
	if((hView=SnmpStrToContext(session,&contextName))==SNMPAPI_FAILURE)
		AfxMessageBox("SendMsg failure--context");
	if(SnmpSendMsg(session,NULL,hAgent,hView,m_hpdu)==SNMPAPI_FAILURE)
	{
		AfxMessageBox("SendMsg failure");
		//dwErr=SnmpGetLastError(session);
		CString str;
		str.Format("%d",SnmpGetLastError(session));
		AfxMessageBox(str);
	}
	if(m_hpdu!=NULL)
		SnmpFreePdu(m_hpdu);
	if(m_hvbl!=NULL)
		SnmpFreeVbl(m_hvbl);
	if(hAgent!=NULL)
		SnmpFreeEntity(hAgent);
	if(hView!=NULL)
		SnmpFreeContext(hView);
/*#ifdef _DEBUG
	newMemState.Checkpoint();
	if(diffMemState.Difference(oldMemState,newMemState))
	{TRACE("diffrence between fire and noe\n\n");
		diffMemState.DumpStatistics();
	}
#endif*/
}

CSnmp::Register()
{
/*	if(SnmpRegister(NULL,NULL,NULL,NULL,NULL,SNMPAPI_ON)==SNMPAPI_FAILURE)
	{	AfxMessageBox("Register failure");
		if((dwErr=SnmpGetLastError(session))=SNMPAPI_SUCCESS)
			AfxMessageBox("strange");
		CString str;
		str.Format("%d",dwErr);
		AfxMessageBox(str);
	}*/
}

CSnmp::Receive(LPTSTR *name,smiLPVALUE *value)
{	
	HSNMP_ENTITY srcEntity; 
	HSNMP_ENTITY dstEntity; 
	HSNMP_CONTEXT context;
	HSNMP_PDU pPdu;
	smiLPINT PDU_type=new smiINT; 
	smiLPINT32 request_id=new smiINT32;
	smiLPINT error_status=new smiINT;
	smiLPINT error_index=new smiINT;
	HSNMP_VBL varbindlist;
	smiLPOID pOid=new smiOID;
	if(SnmpRecvMsg(session,&srcEntity,&dstEntity,&context,&pPdu)!=SNMPAPI_SUCCESS)
		AfxMessageBox("receive failure--recv");
	if(SnmpGetPduData(pPdu,PDU_type,request_id,error_status,error_index,&varbindlist)!=SNMPAPI_SUCCESS)
	{
		AfxMessageBox("receive failure--getpdu");
		CString str;
		str.Format("%d",SnmpGetLastError(NULL));
		AfxMessageBox(str);
	}
	if((nCount=SnmpCountVbl(varbindlist))==SNMPAPI_FAILURE)
		AfxMessageBox("Count Vbl Error");
	for(int i=1;i<=nCount;i++)
	{if(SnmpGetVb(varbindlist,i,pOid,value[i])!=SNMPAPI_SUCCESS)
		{
		AfxMessageBox("receive failure--getvb");
		CString str;
		str.Format("%d",SnmpGetLastError(NULL));
		AfxMessageBox(str);
		}
	if(SnmpOidToStr(pOid,100,name[i])==SNMPAPI_FAILURE)
	{AfxMessageBox("Get Vb Error");
		CString str;
		str.Format("%d",SnmpGetLastError(NULL));
		AfxMessageBox(str);}
	}

	SnmpFreeEntity(srcEntity);
	SnmpFreeEntity(dstEntity);
	SnmpFreeContext(context);
	SnmpFreePdu(pPdu);
	SnmpFreeVbl(varbindlist);
	//SnmpFreeDescriptor(SNMP_SYNTAX_OID,*pOid);
	delete PDU_type; 
	delete request_id;
	delete error_status;
	delete error_index;
	delete pOid;
}