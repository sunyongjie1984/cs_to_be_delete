#if !defined(AFX_DLGIPIN_H__F5CCEEAE_A84C_4185_A3F2_3EB867746022__INCLUDED_)
#define AFX_DLGIPIN_H__F5CCEEAE_A84C_4185_A3F2_3EB867746022__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgIpIn.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgIpIn dialog

class CDlgIpIn : public CDialog
{
// Construction
public:
	CDlgIpIn(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgIpIn)
	enum { IDD = IDD_DLGINIP };
	CString	m_IpAddress;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgIpIn)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgIpIn)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGIPIN_H__F5CCEEAE_A84C_4185_A3F2_3EB867746022__INCLUDED_)
