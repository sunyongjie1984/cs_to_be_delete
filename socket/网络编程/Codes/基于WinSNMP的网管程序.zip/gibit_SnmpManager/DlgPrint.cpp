// DlgPrint.cpp : implementation file
//

#include "stdafx.h"
#include "SnmpManager.h"
#include "DlgPrint.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgPrint dialog


CDlgPrint::CDlgPrint(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgPrint::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgPrint)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgPrint::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPrint)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgPrint, CDialog)
	//{{AFX_MSG_MAP(CDlgPrint)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPrint message handlers

void CDlgPrint::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	for(int i=0;i<n;i++)
	{
		dc.TextOut(0,i*20,*(m_Oid+i),lstrlen(*(m_Oid+i)));
		dc.TextOut(240,i*20,*(m_value+i),lstrlen(*(m_value+i)));
	}
	
	
	// Do not call CDialog::OnPaint() for painting messages
}
