// SnmpManagerDlg.h : header file
//

#if !defined(AFX_SNMPMANAGERDLG_H__626F38BE_8E96_4A15_9D74_16C4CF260BB7__INCLUDED_)
#define AFX_SNMPMANAGERDLG_H__626F38BE_8E96_4A15_9D74_16C4CF260BB7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Snmp.h"
/////////////////////////////////////////////////////////////////////////////
// CSnmpManagerDlg dialog
#define wMsg WM_USER+5
class CSnmpManagerDlg : public CDialog
{
// Construction
public:
	CSnmpManagerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSnmpManagerDlg)
	enum { IDD = IDD_SNMPMANAGER_DIALOG };
	CString	m_sAgent;
	CString	m_sIpin;
	CString	m_sIpout;
	CString	m_sName;
	CString	m_sDesr;
	CString	m_sSysOid;
	CString	m_sSysTime;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSnmpManagerDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementati
protected:
	void Start();
	void Draw(int x,int y,CDC* pDc);
	HICON m_hIcon;
	LPTSTR m_Agent;
	BOOL m_bNext;
	CSnmp pSnmp;
	CDC* pDc;
	int m_nCount;
	double m_nIpin;
	double m_preIn;
	char* str[10];
	double m_nTrack;

	CString m_IpNext;
	LPTSTR m_sOid[10];
	LPCSTR m_initOid[10];
	smiLPVALUE m_value[10];
	LPTSTR m_OidNext[50];
	LPTSTR m_valueNext[50];
	// Generated message map functions
	//{{AFX_MSG(CSnmpManagerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnAddagent();
	afx_msg void OnSelchangeList1();
	afx_msg void OnRecv();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnEnd();
	afx_msg void OnSet();
	afx_msg void OnGetnext();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void Next(LPTSTR Oid);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SNMPMANAGERDLG_H__626F38BE_8E96_4A15_9D74_16C4CF260BB7__INCLUDED_)
