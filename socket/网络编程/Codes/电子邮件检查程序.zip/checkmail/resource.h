//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by checkmail.rc
//
#define IDD_DIALOGMAIN                  101
#define IDI_ICONMAIN                    103
#define IDI_ICONBLANK                   104
#define IDC_SERVER                      1002
#define IDC_ACCOUNT                     1003
#define IDC_PASSWORD                    1004
#define IDC_CHECKNOW                    1007
#define IDC_TIMEWAIT                    1008
#define IDC_SAVESETTINGS                1009
#define IDC_STATUS                      1010
#define IDC_CHECKMAIL                   1011
#define IDC_TIME                        1012
#define IDC_WAV                         1014
#define IDC_BROWSE                      1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
