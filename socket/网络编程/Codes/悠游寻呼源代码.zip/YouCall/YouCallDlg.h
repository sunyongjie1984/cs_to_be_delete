// YouCallDlg.h : header file
//

#if !defined(AFX_YOUCALLDLG_H__73A931DE_BD68_4F0B_8DF2_A5D50E5D09BF__INCLUDED_)
#define AFX_YOUCALLDLG_H__73A931DE_BD68_4F0B_8DF2_A5D50E5D09BF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CYouCallDlg dialog

class CYouCallDlg : public CDialog
{
// Construction
public:
	CYouCallDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CYouCallDlg)
	enum { IDD = IDD_YOUCALL_DIALOG };
	CString	m_backnumber;
	CString	m_callnumber;
	CString	m_country;
	CString	m_mysay;
	CString	m_zipcode;
	int		m_select;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CYouCallDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CYouCallDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnCall();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnRadioCn();
	afx_msg void OnRadioNu();
	afx_msg void OnSelchangeComboSelect();
	afx_msg void OnRadio3();
	afx_msg void OnRadio4();
	afx_msg void OnRadio5();
	afx_msg void OnRadio6();
	afx_msg void OnRadio7();
	afx_msg void OnRadio8();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CSocket sock;
	BOOL flag;
	void chk();
	int m_sex;
	int m_type;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_YOUCALLDLG_H__73A931DE_BD68_4F0B_8DF2_A5D50E5D09BF__INCLUDED_)
