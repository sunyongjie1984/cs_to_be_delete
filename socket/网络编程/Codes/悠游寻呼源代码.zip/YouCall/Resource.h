//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by YouCall.rc
//
#define ID_TIME                         1
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_YOUCALL_DIALOG              102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define ID_CALL                         1000
#define IDC_STATIC_MAIL                 1000
#define IDC_COMBO_SELECT                1001
#define IDC_STATIC_HOMEPAGE             1001
#define IDC_STATIC_TIME                 1002
#define IDC_EDIT_CALLNUMBER             1004
#define IDC_EDIT_COUNTRY                1005
#define IDC_EDIT_ZIPCODE                1006
#define IDC_RADIO_CN                    1007
#define IDC_RADIO_NU                    1008
#define IDC_EDIT_BACKNUMBER             1009
#define IDC_EDIT_MYSAY                  1010
#define IDC_RADIO1                      1011
#define IDC_RADIO2                      1012
#define IDC_RADIO3                      1013
#define IDC_RADIO4                      1014
#define IDC_RADIO5                      1015
#define IDC_RADIO6                      1016
#define IDC_RADIO7                      1017
#define IDC_RADIO8                      1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
