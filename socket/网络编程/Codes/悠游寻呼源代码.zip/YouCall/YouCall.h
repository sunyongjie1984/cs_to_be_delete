// YouCall.h : main header file for the YOUCALL application
//

#if !defined(AFX_YOUCALL_H__A5DA6B2F_7145_4568_A015_11F2821FEEB0__INCLUDED_)
#define AFX_YOUCALL_H__A5DA6B2F_7145_4568_A015_11F2821FEEB0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CYouCallApp:
// See YouCall.cpp for the implementation of this class
//

class CYouCallApp : public CWinApp
{
public:
	CYouCallApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CYouCallApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CYouCallApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_YOUCALL_H__A5DA6B2F_7145_4568_A015_11F2821FEEB0__INCLUDED_)
