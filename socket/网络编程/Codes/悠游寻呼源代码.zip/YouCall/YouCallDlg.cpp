// YouCallDlg.cpp : implementation file
//

#include "stdafx.h"
#include "YouCall.h"
#include "YouCallDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	afx_msg void OnStaticHomepage();
	afx_msg void OnStaticMail();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_BN_CLICKED(IDC_STATIC_HOMEPAGE, OnStaticHomepage)
	ON_BN_CLICKED(IDC_STATIC_MAIL, OnStaticMail)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CYouCallDlg dialog

CYouCallDlg::CYouCallDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CYouCallDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CYouCallDlg)
	m_backnumber = _T("");
	m_callnumber = _T("");
	m_country = _T("86");
	m_mysay = _T("");
	m_zipcode = _T("010");
	m_select = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_sex=0;
	m_type=0;
	CWinApp * pApp=AfxGetApp();
	m_callnumber=pApp->GetProfileString("YouCALL","Call_Number",NULL);
	m_backnumber=pApp->GetProfileString("YouCALL","Back_Number",NULL);
	m_country=pApp->GetProfileString("YouCALL","Call_Country",NULL);
	m_zipcode=pApp->GetProfileString("YouCALL","Call_Zipcode",NULL);
	m_mysay=pApp->GetProfileString("YouCALL","Call_Mysay",NULL);
	m_sex=pApp->GetProfileInt("YouCALL","Sex",0);
	m_type=pApp->GetProfileInt("YouCALL","type",0); 
}

void CYouCallDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CYouCallDlg)
	DDX_Text(pDX, IDC_EDIT_BACKNUMBER, m_backnumber);
	DDX_Text(pDX, IDC_EDIT_CALLNUMBER, m_callnumber);
	DDX_Text(pDX, IDC_EDIT_COUNTRY, m_country);
	DDX_Text(pDX, IDC_EDIT_MYSAY, m_mysay);
	DDX_Text(pDX, IDC_EDIT_ZIPCODE, m_zipcode);
	DDX_CBIndex(pDX, IDC_COMBO_SELECT, m_select);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CYouCallDlg, CDialog)
	//{{AFX_MSG_MAP(CYouCallDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(ID_CALL, OnCall)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_RADIO_CN, OnRadioCn)
	ON_BN_CLICKED(IDC_RADIO_NU, OnRadioNu)
	ON_CBN_SELCHANGE(IDC_COMBO_SELECT, OnSelchangeComboSelect)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	ON_BN_CLICKED(IDC_RADIO4, OnRadio4)
	ON_BN_CLICKED(IDC_RADIO5, OnRadio5)
	ON_BN_CLICKED(IDC_RADIO6, OnRadio6)
	ON_BN_CLICKED(IDC_RADIO7, OnRadio7)
	ON_BN_CLICKED(IDC_RADIO8, OnRadio8)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CYouCallDlg message handlers

BOOL CYouCallDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here	
	chk();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CYouCallDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CYouCallDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CYouCallDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CYouCallDlg::OnCall() 
{
	// Ѱ��
	int len,res;
	char temp[32];
    

	UpdateData(TRUE);
	if (m_select<0){
		::MessageBox(m_hWnd,"��ѡ��ҪѰ���ĵ�����","����������",MB_OK+MB_ICONERROR);
	      return;
	}
	if (m_callnumber==""){
		::MessageBox(m_hWnd,"������ҪѰ����BP�����룡","����������",MB_OK+MB_ICONERROR);
	      return;
	}
	if (m_country==""){
		::MessageBox(m_hWnd,"��������Ҵ��ţ�","����������",MB_OK+MB_ICONERROR);
	    return;
	}
	if (m_zipcode==""){
		::MessageBox(m_hWnd,"������������ţ�","����������",MB_OK+MB_ICONERROR);
	    return;
	}
	if (m_backnumber==""){
		::MessageBox(m_hWnd,"������ظ��绰���룡","����������",MB_OK+MB_ICONERROR);
	      return;
	}
	GetDlgItem(ID_CALL)->EnableWindow(FALSE);
	CWinApp * pApp=AfxGetApp();
    pApp->WriteProfileString("YouCALL","Call_Number",m_callnumber);
	pApp->WriteProfileString("YouCALL","Back_Number",m_backnumber);
	pApp->WriteProfileString("YouCALL","Call_Country",m_country);
	pApp->WriteProfileString("YouCALL","Call_Zipcode",m_zipcode);
	pApp->WriteProfileString("YouCALL","Call_Mysay",m_mysay);
	pApp->WriteProfileInt("YouCALL","Sex",m_sex);
	pApp->WriteProfileInt("YouCALL","type",m_type); 
	CString msg="";
	CString head="";
	switch (m_select){
	case 0:{//����
        msg+="FormName04=1&FormTai=1"; 
	    msg+="&rBpTai="; //̨��
	    if (m_sex==0) msg+="127";
	    if (m_sex==1) msg+="199";
	    if (m_sex==2) msg+="280";
		if (m_sex==3) msg+="283";
		if (m_sex==4) msg+="287";
		if (m_sex==5) msg+="289";
		if (m_sex==6) msg+="126";
        if (m_sex==7) msg+="128";		
        msg+="&FormName02=";//BP����
        msg+=m_callnumber;
		msg+="&rBpType="; //��   ��
        msg+=(m_type==0)?"C":"D";
		msg+="&FormCountry="; //�� ��
	    msg+=m_country;
	    msg+="&FormRegion="; //��������
	    msg+=m_zipcode;
	    msg+="&FormName01="; //�ظ��绰
	    msg+=m_backnumber;
	    msg+="&txtContent="; //����	
	    msg+=m_mysay;
	    msg+="\r\n&MySend=���"; //���
	    head+="POST /gnetpri/netcall_1_form.asp HTTP/1.0 \r\n";
	    head+="Accept:image/gif,image/x-xbitmap,image/jpeg,image/pjpeg,*/* \r\n";
	    head+="Content-Type:application/x-www-form-rulencoded \r\n";
	    head+="User-Agent:(compatible) \r\n";
	    head+="content-Length:";
	    len=strlen((LPCTSTR)msg);
	    itoa(len,temp,10);
	    head+=temp;
    	head+="\r\n\r\n";
    	sock.Close();
	    flag=FALSE;
	    res=sock.Create();
        res=sock.Connect("202.106.81.22",80);
	}
	case 1:{//����
        msg+="FormName04=1&FormTai=1"; 
	    msg+="&rCallTai="; //̨��
		msg+=(m_sex==0)?"1":"2";
        msg+="&FormName02=";//BP����
        msg+=m_callnumber;
		msg+="&FormName04="; //��   ��
        msg+=(m_type==0)?"1":"2";
		msg+="&FormCountry="; //�� ��
	    msg+=m_country;
	    msg+="&FormRegion="; //��������
	    msg+=m_zipcode;
	    msg+="&FormName01="; //�ظ��绰
	    msg+=m_backnumber;
	    msg+="&FormName032="; //����	
	    msg+=m_mysay;
	    msg+="\r\n&MySend=���"; //���
	    head+="POST /webcall/netcall_1_content.asp HTTP/1.0 \r\n";
	    head+="Accept:image/gif,image/x-xbitmap,image/jpeg,image/pjpeg,*/* \r\n";
	    head+="Content-Type:application/x-www-form-rulencoded \r\n";
	    head+="User-Agent:(compatible) \r\n";
	    head+="content-Length:";
	    len=strlen((LPCTSTR)msg);
	    itoa(len,temp,10);
	    head+=temp;
    	head+="\r\n\r\n";
    	sock.Close();
	    flag=FALSE;
	    res=sock.Create();
        res=sock.Connect("202.100.72.28",80);
	}
	case 2:{//����
	    msg+="FormName04=1&FormTai=1"; 
	    msg+="&PagerSystem="; // ̨ ��
	    msg+=(m_sex==0)?"127":"129";
	    msg+="&PagerNumber="; //BP����
	    msg+=m_callnumber;
	    msg+="&MacType="; //��   ��
	    msg+=(m_type==0)?"0":"1";
	    msg+="&FormCountry="; //�� ��
	    msg+=m_country;
	    msg+="&FormRegion="; //��������
	    msg+=m_zipcode;
	    msg+="&PageMessage="; //�ظ��绰
	    msg+=m_backnumber;
	    msg+="&PageMessage2="; //����	
	    msg+=m_mysay;
	    msg+="\r\n&Page=���"; //���
	    head+="POST /pnet_paging.dll HTTP/1.0 \r\n";
	    head+="Accept:image/gif,image/x-xbitmap,image/jpeg,image/pjpeg,*/* \r\n";
	    head+="Content-Type:application/x-www-form-rulencoded \r\n";
	    head+="User-Agent:(compatible) \r\n";
	    head+="content-Length:";
	    len=strlen((LPCTSTR)msg);
	    itoa(len,temp,10);
	    head+=temp;
    	head+="\r\n\r\n";
    	sock.Close();
	    flag=FALSE;
	    res=sock.Create();
        res=sock.Connect("202.100.204.180",80);
	}
	case 3:{//����
	    msg+="FormName04=1&FormTai=1"; 
	    msg+="&CallTai="; // ̨ ��
	    msg+="1";
	    msg+="&FormName02="; //BP����
	    msg+=m_callnumber;
	    msg+="&MacType="; //��   ��
	    msg+=(m_type==0)?"1":"0";
	    msg+="&FormCountry="; //�� ��
	    msg+=m_country;
	    msg+="&FormRegion="; //��������
	    msg+=m_zipcode;
	    msg+="&FormName01="; //�ظ��绰
	    msg+=m_backnumber;
	    msg+="&TEXTAREA1="; //����	
	    msg+=m_mysay;
	    msg+="\r\n&Page=���"; //���
	    head+="GET /bin_1/iserver.dll/gx_m11e HTTP/1.0 \r\n";
	    head+="Accept:image/gif,image/x-xbitmap,image/jpeg,image/pjpeg,*/* \r\n";
	    head+="Content-Type:application/x-www-form-rulencoded \r\n";
	    head+="User-Agent:(compatible) \r\n";
	    head+="content-Length:";
	    len=strlen((LPCTSTR)msg);
	    itoa(len,temp,10);
	    head+=temp;
    	head+="\r\n\r\n";
    	sock.Close();
	    flag=FALSE;
	    res=sock.Create();
        res=sock.Connect("www.hn.gnetpri.com",80);
	}
	case 4:{//�Ϻ�
	    msg+="FormName04=1&FormTai=1"; 
	    msg+="&sys="; // ̨ ��
	    if (m_sex==0) msg+="126";
	    if (m_sex==1) msg+="127";
	    if (m_sex==2) msg+="128";
		if (m_sex==3) msg+="1250";
	    msg+="&pager="; //BP����
	    msg+=m_callnumber;
	    msg+="&MacType="; //��   ��
	    msg+=(m_type==0)?"c":"n";
	    msg+="&FormCountry="; //�� ��
	    msg+=m_country;
	    msg+="&area="; //��������
	    msg+=m_zipcode;
	    msg+="&info="; //�ظ��绰������
	    msg+=m_backnumber;
	    //msg+="&TEXTAREA1="; //����	
	    //msg+=m_mysay;
	    msg+="\r\n&MySend=���"; //���
	    head+="POST /cgi-bin/callnet.cgi HTTP/1.0 \r\n";
	    head+="Accept:image/gif,image/x-xbitmap,image/jpeg,image/pjpeg,*/* \r\n";
	    head+="Content-Type:application/x-www-form-rulencoded \r\n";
	    head+="User-Agent:(compatible) \r\n";
	    head+="content-Length:";
	    len=strlen((LPCTSTR)msg);
	    itoa(len,temp,10);
	    head+=temp;
    	head+="\r\n\r\n";
    	sock.Close();
	    flag=FALSE;
	    res=sock.Create();
        res=sock.Connect("www.sh.gnetpri.com",80);
		   }
	case 5:{//������
	    msg+="FormName04=1&FormTai=1"; 
	    msg+="&FormTai="; // ̨ ��
	    if (m_sex==0) msg+="1";
	    if (m_sex==1) msg+="2";
	    msg+="FormName02="; //BP����
	    msg+=m_callnumber;
	    msg+="&FormName04="; //��   ��
	    msg+=(m_type==0)?"2":"1";
	    msg+="&FormCountry="; //�� ��
	    msg+=m_country;
	    msg+="&FormRegion="; //��������
	    msg+=m_zipcode;
	    msg+="FormName01="; //�ظ��绰������
	    msg+=m_backnumber;
	    msg+="&FormName032="; //����	
	    msg+=m_mysay;
	    msg+="\r\n&MySend=���"; //���
	    head+="POST /netcall_1_ok1.asp HTTP/1.0 \r\n";
	    head+="Accept:image/gif,image/x-xbitmap,image/jpeg,image/pjpeg,*/* \r\n";
	    head+="Content-Type:application/x-www-form-rulencoded \r\n";
	    head+="User-Agent:(compatible) \r\n";
	    head+="content-Length:";
	    len=strlen((LPCTSTR)msg);
	    itoa(len,temp,10);
	    head+=temp;
    	head+="\r\n\r\n";
    	sock.Close();
	    flag=FALSE;
	    res=sock.Create();
        res=sock.Connect("www.hl.gnetpri.com",80);
		   }
   }
	if (!res){
		::MessageBox(m_hWnd,"�޷����ӵ���������","������",MB_OK+MB_ICONERROR);
	    GetDlgItem(ID_CALL)->EnableWindow(TRUE);
	    return;
	}else
    {
		sock.Send(head,strlen((LPCTSTR)head));
		sock.Send(msg,strlen((LPCTSTR)msg));
		DWORD tick=::GetTickCount()+5000;
		res=0;
		while (::GetTickCount()<tick)
		{
			res+=sock.Receive(temp,sizeof(temp));
			if (res>16)
			{
				if (temp[13]=='O'&&temp[14]=='K')
				{
					::MessageBox(m_hWnd,"��ϲ��Ѱ���Ѿ�������","��Ϣ",MB_OK+MB_ICONINFORMATION);					 
					flag=TRUE;
				}
				break;
			}
			else  Sleep(1); 
		}
	}
	if (flag==FALSE)::MessageBox(m_hWnd,"����ʧ�ܣ�����������","����",MB_OK+MB_ICONERROR);
	GetDlgItem(ID_CALL)->EnableWindow(TRUE);
	sock.Close(); 
}

void CYouCallDlg::OnRadio1() 
{
 m_sex=0;
 chk();
}

void CYouCallDlg::OnRadio2() 
{
 m_sex=1;
 chk();	
}

void CYouCallDlg::OnRadioCn() 
{
  m_type=0;	
  chk();
}

void CYouCallDlg::OnRadioNu() 
{
  m_type=1;	
  chk();
}

void CYouCallDlg::chk()
{
	if (m_sex==0) CheckRadioButton(IDC_RADIO1,IDC_RADIO8,IDC_RADIO1);
	if (m_sex==1) CheckRadioButton(IDC_RADIO1,IDC_RADIO8,IDC_RADIO2);
	if (m_sex==2) CheckRadioButton(IDC_RADIO1,IDC_RADIO8,IDC_RADIO3);
	if (m_sex==3) CheckRadioButton(IDC_RADIO1,IDC_RADIO8,IDC_RADIO4);
	if (m_sex==4) CheckRadioButton(IDC_RADIO1,IDC_RADIO8,IDC_RADIO5);
	if (m_sex==5) CheckRadioButton(IDC_RADIO1,IDC_RADIO8,IDC_RADIO6);
	if (m_sex==6) CheckRadioButton(IDC_RADIO1,IDC_RADIO8,IDC_RADIO7);
	if (m_sex==7) CheckRadioButton(IDC_RADIO1,IDC_RADIO8,IDC_RADIO8);
	
	
	CheckRadioButton(IDC_RADIO_CN,IDC_RADIO_NU,(m_type==0)?IDC_RADIO_CN:IDC_RADIO_NU);	
	if (m_type==1) 	GetDlgItem(IDC_EDIT_MYSAY)->EnableWindow(FALSE);
	else GetDlgItem(IDC_EDIT_MYSAY)->EnableWindow(TRUE);
}

void CYouCallDlg::OnSelchangeComboSelect() 
{
	UpdateData(TRUE);
	m_country="86";
	switch(m_select)
	{
	case 0: {
		m_zipcode="010"; 
        GetDlgItem(IDC_RADIO1)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO2)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO3)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO4)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO5)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO6)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO7)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO8)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO1)->SetWindowText("127");
		GetDlgItem(IDC_RADIO2)->SetWindowText("198/199");
		GetDlgItem(IDC_RADIO3)->SetWindowText("280");
		GetDlgItem(IDC_RADIO4)->SetWindowText("283");
		GetDlgItem(IDC_RADIO5)->SetWindowText("286/287");
		GetDlgItem(IDC_RADIO6)->SetWindowText("288/289");
		GetDlgItem(IDC_RADIO7)->SetWindowText("126");
		GetDlgItem(IDC_RADIO8)->SetWindowText("128");
		break;
	}
	case 1: {
		m_zipcode="931";m_country="086";
		GetDlgItem(IDC_RADIO1)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO2)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO3)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO4)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO5)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO6)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO7)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO8)->ShowWindow(FALSE);
        GetDlgItem(IDC_RADIO1)->SetWindowText("126/127");
		GetDlgItem(IDC_RADIO2)->SetWindowText("198/199");
		break;
	}
	case 2: {
		m_zipcode="898";
		GetDlgItem(IDC_RADIO1)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO2)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO3)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO4)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO5)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO6)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO7)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO8)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO1)->SetWindowText("126/127");
		GetDlgItem(IDC_RADIO2)->SetWindowText("128/129/990/198/199");  
		break;
	}
	case 3: {
		m_zipcode="0731";
		GetDlgItem(IDC_RADIO1)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO2)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO3)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO4)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO5)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO6)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO7)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO8)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO1)->SetWindowText("126/127");
		break;
	}
    case 4: {
		m_zipcode="";
		GetDlgItem(IDC_RADIO1)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO2)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO3)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO4)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO5)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO6)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO7)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO8)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO1)->SetWindowText("126");
		GetDlgItem(IDC_RADIO2)->SetWindowText("127");
		GetDlgItem(IDC_RADIO3)->SetWindowText("128");
		GetDlgItem(IDC_RADIO4)->SetWindowText("1250");
		break;
			}
    case 5: {
		m_zipcode="451";m_country="086";
		GetDlgItem(IDC_RADIO1)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO2)->ShowWindow(TRUE);
		GetDlgItem(IDC_RADIO3)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO4)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO5)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO6)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO7)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO8)->ShowWindow(FALSE);
		GetDlgItem(IDC_RADIO1)->SetWindowText("126/127");
		GetDlgItem(IDC_RADIO2)->SetWindowText("128/129");
		break;
			}
	}
	UpdateData(FALSE);		
}

void CYouCallDlg::OnRadio3() 
{
 m_sex=2;
 chk();		
}

void CYouCallDlg::OnRadio4() 
{
 m_sex=3;
 chk();		
}

void CYouCallDlg::OnRadio5() 
{
 m_sex=4;
 chk();		
}

void CYouCallDlg::OnRadio6() 
{
 m_sex=5;
 chk();	
}

void CYouCallDlg::OnRadio7() 
{
 m_sex=6;
 chk();		
}

void CYouCallDlg::OnRadio8() 
{
 m_sex=7;
 chk();		
}

void CAboutDlg::OnStaticHomepage() 
{
	//��ҳ
	ShellExecute(m_hWnd,"OPEN","http://yousoft.home.chinaren.com",NULL,NULL,SW_SHOW);
}

void CAboutDlg::OnStaticMail() 
{
	//�ʼ�
	ShellExecute(m_hWnd,"OPEN","mailto:yousoft@chinaren.com",NULL,NULL,SW_SHOW);
}

