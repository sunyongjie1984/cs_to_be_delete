// IPManView.cpp : implementation of the CIPManView class
//

#include "stdafx.h"
#include "IPMan.h"

#include "IPManDoc.h"
#include "IPManView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIPManView

IMPLEMENT_DYNCREATE(CIPManView, CView)

BEGIN_MESSAGE_MAP(CIPManView, CView)
	//{{AFX_MSG_MAP(CIPManView)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIPManView construction/destruction
//----------------var----------------------------------
CIPManView* pIPManView;
//-----------------------------------------------------

CIPManView::CIPManView()
{
	// TODO: add construction code here
    pIPManView=this;
}

CIPManView::~CIPManView()
{
}

BOOL CIPManView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CIPManView drawing

void CIPManView::OnDraw(CDC* pDC)
{
	CIPManDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CIPManView printing

BOOL CIPManView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CIPManView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CIPManView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CIPManView diagnostics

#ifdef _DEBUG
void CIPManView::AssertValid() const
{
	CView::AssertValid();
}

void CIPManView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CIPManDoc* CIPManView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CIPManDoc)));
	return (CIPManDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CIPManView message handlers


