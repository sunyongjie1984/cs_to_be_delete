//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IPMan.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_DIALOGBAR                   103
#define IDR_MAINFRAME                   128
#define IDR_IPMANTYPE                   129
#define IDD_ARP_DIALOG                  131
#define IDR_TRAY_MENU                   132
#define IDC_EDIT1                       1005
#define IDC_BUTTON1                     1006
#define IDC_RADIO1                      1007
#define IDC_RADIO2                      1008
#define IDC_BUTTON2                     1009
#define IDC_LIST1                       1010
#define IDC_IPADDRESS1                  1011
#define IDC_IPADDRESS2                  1014
#define IDC_SPIN1                       1015
#define IDC_BUTTON3                     1017
#define IDC_BUTTON4                     1018
#define IDC_TAB1                        1019
#define IDC_LIST5                       1024
#define IDC_PROGRESS1                   1025
#define ID_BUTTON32772                  32772
#define ID_BUTTON32773                  32773
#define ID_BUTTON32774                  32774
#define ID_BUTTON32775                  32775
#define ID_MENUITEM32776                32776
#define ID_MENU_OPEN                    32776
#define ID_MENUITEM32777                32777
#define ID_MENU_CLOSE                   32777
#define ID_MENUITEM32778                32778
#define ID_MENU_ABOUT                   32778
#define ID_COMBO_BUTTON                 32779
#define ID_INDICATOR_HINT               59142

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
