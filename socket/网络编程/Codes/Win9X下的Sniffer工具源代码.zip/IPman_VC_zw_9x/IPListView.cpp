// IPListView.cpp : implementation file
//

#include "stdafx.h"
#include "IPMan.h"
#include "IPListView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIPListView
//-------------------ȫ�ֱ���------------------------------
CIPListView* pIPListView;
//---------------------------------------------------------
IMPLEMENT_DYNCREATE(CIPListView, CListView)

CIPListView::CIPListView()
{
	pIPListView=this;
}

CIPListView::~CIPListView()
{
}


BEGIN_MESSAGE_MAP(CIPListView, CListView)
	//{{AFX_MSG_MAP(CIPListView)
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDblclk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIPListView drawing

void CIPListView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CIPListView diagnostics

#ifdef _DEBUG
void CIPListView::AssertValid() const
{
	CListView::AssertValid();
}

void CIPListView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CIPListView message handlers

void CIPListView::OnInitialUpdate() 
{
	CListView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
    
	//--------------------listview ��ʼ��---------------------
    DWORD dwStyle=GetWindowLong(GetListCtrl().GetSafeHwnd(),GWL_STYLE);
	dwStyle&=~LVS_TYPEMASK;
	dwStyle|=LVS_REPORT;
	SetWindowLong(GetListCtrl().GetSafeHwnd(),GWL_STYLE,dwStyle);
	SetRedraw(TRUE);

	GetListCtrl().InsertColumn(0,"����",LVCFMT_LEFT,280);
	GetListCtrl().InsertColumn(0,"��С",LVCFMT_LEFT,80);
    GetListCtrl().InsertColumn(0,"�˿�",LVCFMT_LEFT,40);
	GetListCtrl().InsertColumn(0,"Ŀ�ĵ�ַ",LVCFMT_LEFT,100);
	GetListCtrl().InsertColumn(0,"�˿�",LVCFMT_LEFT,40);
	GetListCtrl().InsertColumn(0,"Դ��ַ",LVCFMT_LEFT,100);
	GetListCtrl().InsertColumn(0,"Э��",LVCFMT_LEFT,40);
    
    ::SendMessage(GetListCtrl().m_hWnd, LVM_SETEXTENDEDLISTVIEWSTYLE,
      LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);
	//--------------------------------------------------------	
	
}

void CIPListView::OnDblclk(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	CString str;
	int SelIndex=GetListCtrl().GetSelectionMark( );
	str=GetListCtrl().GetItemText(SelIndex,0)+":";
	str+=GetListCtrl().GetItemText(SelIndex,1)+":";
	str+=GetListCtrl().GetItemText(SelIndex,2)+" -> ";
	str+=GetListCtrl().GetItemText(SelIndex,3)+":";
	str+=GetListCtrl().GetItemText(SelIndex,4)+"\n";
	str+=GetListCtrl().GetItemText(SelIndex,5)+"\n";
	str+=GetListCtrl().GetItemText(SelIndex,6);
	if(str!="")AfxMessageBox(str);	
	*pResult = 0;
}
