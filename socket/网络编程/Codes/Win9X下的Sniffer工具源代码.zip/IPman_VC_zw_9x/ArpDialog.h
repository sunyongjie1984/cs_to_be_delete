#if !defined(AFX_ARPDIALOG_H__9032B5E2_9FE4_11D5_A956_00058D09EB5F__INCLUDED_)
#define AFX_ARPDIALOG_H__9032B5E2_9FE4_11D5_A956_00058D09EB5F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ArpDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CArpDialog dialog

class CArpDialog : public CDialog
{
// Construction
public:
	BOOL m_bStart;
	CArpDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CArpDialog)
	enum { IDD = IDD_ARP_DIALOG };
	CListBox	m_ARPList;
	CTabCtrl	m_ctlTab;
	CSpinButtonCtrl	m_spin;
	CListBox	m_MacList;
	CIPAddressCtrl	m_IPEdit2;
	CIPAddressCtrl	m_IPEdit1;
	int		m_SpinEdit;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CArpDialog)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CArpDialog)
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnButtonBeginArp();
	afx_msg void OnButtonExitArp();
	afx_msg void OnClose();
	afx_msg void OnFieldchangedIpaddress1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonSave();
	afx_msg void OnButtonClear();
	afx_msg void OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	//zw
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ARPDIALOG_H__9032B5E2_9FE4_11D5_A956_00058D09EB5F__INCLUDED_)
