// IPMan.h : main header file for the IPMAN application
//

#if !defined(AFX_IPMAN_H__5C060085_9F8D_11D5_A956_00058D09EB5F__INCLUDED_)
#define AFX_IPMAN_H__5C060085_9F8D_11D5_A956_00058D09EB5F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CIPManApp:
// See IPMan.cpp for the implementation of this class
//

class CIPManApp : public CWinApp
{
public:
	CIPManApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIPManApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CIPManApp)
	afx_msg void OnAppAbout();
	afx_msg void OnTrayMenuAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IPMAN_H__5C060085_9F8D_11D5_A956_00058D09EB5F__INCLUDED_)
