// write.c - PacketWrite, PacketSendComplete
//          

// Original code by William Ingle (address unknown)
// debugged and extended by Chris Chlap (chrisc@fir.canberra.edu.au)

#include <basedef.h>
#include <vmm.h>
#include <debug.h>
#include <ndis.h>
#include <vwin32.h>

#include "packet.h"
#include "ntddpack.h"

#pragma VxD_LOCKED_CODE_SEG
#pragma VxD_LOCKED_DATA_SEG

//--------------------------------------------------------------------
//
//  PacketWrite - write a packet
//
//--------------------------------------------------------------------

DWORD PacketWrite(POPEN_INSTANCE    Open,
                  DWORD             dwDDB,
                  DWORD             hDevice,
                  PDIOCPARAMETERS   pDiocParms)

{
    PNDIS_PACKET    pPacket;
    PNDIS_BUFFER    pNdisBuffer;
    NDIS_STATUS     Status;
    
    PacketAllocatePacketBuffer(&Status, Open, &pPacket, pDiocParms, IOCTL_PROTOCOL_WRITE);


    if (Status != NDIS_STATUS_SUCCESS) {
        Debug_Out("PacketWrite: ERROR: no Packet Buffer Allocated\n");
        return 0;   // This will return immediately with no data written
	}

    //
    //  Call the MAC
	//

    NdisSend(&Status, Open->AdapterHandle, pPacket);

    if (Status != NDIS_STATUS_PENDING) {

        //
        //  The send didn't pend so call the completion handler now
        //

        PacketSendComplete(Open, pPacket, Status);
	}
    return(-1); // This will make DeviceIOControl return ERROR_IO_PENDING
}

//--------------------------------------------------------------------
//
//  PacketSendComplete - upcall on completion of send
//
//--------------------------------------------------------------------
VOID NDIS_API PacketSendComplete(IN NDIS_HANDLE     ProtocolBindingContext,
                                 IN PNDIS_PACKET    pPacket,
                                 IN NDIS_STATUS     Status)
{
    PNDIS_BUFFER     pNdisBuffer;
    PPACKET_RESERVED Reserved = (PPACKET_RESERVED) pPacket->ProtocolReserved;

	//
	// free buffer descriptor
	//

    NdisUnchainBufferAtFront(pPacket, &pNdisBuffer);
	
    if (pNdisBuffer)
        NdisFreeBuffer(pNdisBuffer);

    // return status
    
    Reserved->lpoOverlapped->O_InternalHigh = Status;

	//
    // The internal member of overlapped structure contains
    // a pointer to the event structure that will be signalled,
    // resuming the execution of the waiting GetOverlappedResult
    // call.
    //

    VWIN32_DIOCCompletionRoutine(Reserved->lpoOverlapped->O_Internal);

	// Unlock buffers	

    PacketPageUnlock(Reserved->lpBuffer, Reserved->cbBuffer);
    PacketPageUnlock(Reserved->lpcbBytesReturned, sizeof(DWORD));
    PacketPageUnlock(Reserved->lpoOverlapped, sizeof(OVERLAPPED));

    //
    // recycle the packet
    //

    NdisReinitializePacket(pPacket);

    //
    // Put the packet back on the free list
    //

    NdisFreePacket(pPacket);

    return;
}
