// IPManDoc.h : interface of the CIPManDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_IPMANDOC_H__5C06008B_9F8D_11D5_A956_00058D09EB5F__INCLUDED_)
#define AFX_IPMANDOC_H__5C06008B_9F8D_11D5_A956_00058D09EB5F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CIPManDoc : public CDocument
{
protected: // create from serialization only
	CIPManDoc();
	DECLARE_DYNCREATE(CIPManDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIPManDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void OnCloseDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	void ExitArp();
	void BeginArp(int nWait);
	int m_display;
	virtual ~CIPManDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CIPManDoc)
	afx_msg void OnButtonBeginSniffer();
	afx_msg void OnButtonExitSniffer();
	afx_msg void OnButtonClear();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IPMANDOC_H__5C06008B_9F8D_11D5_A956_00058D09EB5F__INCLUDED_)
