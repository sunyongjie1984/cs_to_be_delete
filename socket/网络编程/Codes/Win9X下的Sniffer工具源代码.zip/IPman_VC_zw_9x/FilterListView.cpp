// FilterListView.cpp : implementation file
//

#include "stdafx.h"
#include "IPMan.h"
#include "FilterListView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFilterListView
//-------------------ȫ�ֱ���------------------------------
CFilterListView* pFilterListView;
//---------------------------------------------------------

IMPLEMENT_DYNCREATE(CFilterListView, CListView)

CFilterListView::CFilterListView()
{
	pFilterListView=this;
}

CFilterListView::~CFilterListView()
{
}


BEGIN_MESSAGE_MAP(CFilterListView, CListView)
	//{{AFX_MSG_MAP(CFilterListView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFilterListView drawing

void CFilterListView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CFilterListView diagnostics

#ifdef _DEBUG
void CFilterListView::AssertValid() const
{
	CListView::AssertValid();
}

void CFilterListView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFilterListView message handlers

void CFilterListView::OnInitialUpdate() 
{
	CListView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
    
	//--------------------listview ��ʼ��---------------------
    DWORD dwStyle=GetWindowLong(GetListCtrl().GetSafeHwnd(),GWL_STYLE);
	dwStyle&=~LVS_TYPEMASK;
	dwStyle|=LVS_REPORT;
	SetWindowLong(GetListCtrl().GetSafeHwnd(),GWL_STYLE,dwStyle);
	SetRedraw(TRUE);

	GetListCtrl().InsertColumn(0,"Filters",LVCFMT_LEFT,150);
   
    ::SendMessage(GetListCtrl().m_hWnd, LVM_SETEXTENDEDLISTVIEWSTYLE,
      LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);
	GetListCtrl().SetExtendedStyle(LVS_EX_GRIDLINES);

	//--------------------------------------------------------	
	
}
