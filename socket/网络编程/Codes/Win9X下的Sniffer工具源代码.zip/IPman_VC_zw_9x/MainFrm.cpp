// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "IPMan.h"

#include "MainFrm.h"
#include "IPListView.h"
#include "MACListView.h"
#include "FilterListView.h"
#include "IPManDoc.h"
#include "ArpDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//-------------------------------------------------------
// determine number of elements in an array (not bytes)
#define _countof(array) (sizeof(array)/sizeof(array[0]))
//-------------------------------------------------------

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_COMMAND(ID_BUTTON32775, OnButtonARP)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_COMMAND(ID_MENUITEM32777, OnTrayMenuClose)
	ON_COMMAND(ID_MENUITEM32776, OnTrayMenuOpen)
	//}}AFX_MSG_MAP
	//---�ֹ�����-�û��ӿڴ�������--------------------
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_HINT,OnHint) 
	ON_UPDATE_COMMAND_UI(ID_BUTTON32772,OnUpdateBeginButton)
    ON_UPDATE_COMMAND_UI(ID_BUTTON32773,OnUpdateStopButton)
	ON_UPDATE_COMMAND_UI(ID_BUTTON32774,OnUpdateClearButton)
	ON_UPDATE_COMMAND_UI(ID_BUTTON32775,OnUpdateARPButton)
	//-------------------------------------------------
	//---------�ֹ����ӵ���Ϣ----��ʾ����ͼ��----------
	ON_WM_SYSCOMMAND()
	ON_MESSAGE(WM_TRAY_ICON_NOTIFY,OnTrayNotification)
	//-------------------------------------------------

END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_HINT,  //zw(strintable����Ҫ����
	ID_SEPARATOR,      //zw
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction
//-----------------------------------------
CMainFrame* pMainFrame;
extern CFilterListView* pFilterListView;
extern CMACListView* pMACListView;
extern CIPManDoc* pIPManDoc;
//-----------------------------------------

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	pMainFrame=this;
	m_bBegin=true;
	m_bStop=false;
	m_bClear=false;
	m_bARP=true;
}

CMainFrame::~CMainFrame()
{
}

//----------------�ֹ�����-�û��ӿڴ�������-------------------
void CMainFrame::OnHint(CCmdUI* pCmdUI) //״̬��
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateBeginButton(CCmdUI* pCmdUI) //��������ť
{
	pCmdUI->Enable(m_bBegin);
}

void CMainFrame::OnUpdateStopButton(CCmdUI* pCmdUI) //��������ť
{
	pCmdUI->Enable(m_bStop);
}

void CMainFrame::OnUpdateClearButton(CCmdUI* pCmdUI) //��������ť
{
	pCmdUI->Enable(m_bClear);
}

void CMainFrame::OnUpdateARPButton(CCmdUI* pCmdUI) //��������ť
{
	pCmdUI->Enable(m_bARP);
}
//------------------------------------------------------------

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	/*if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}*/

	//---------------------------------ToolBarEx----------------------------
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	// create an additional CComboBox-control on the toolbar
	
	DWORD dwComboStyle = WS_VSCROLL|CBS_AUTOHSCROLL|CBS_DROPDOWN|CBS_HASSTRINGS|WS_TABSTOP;
	m_wndToolBar.CreateCombo(dwComboStyle,&m_wndToolBarCombo,ID_COMBO_BUTTON,150,150);
	//------------------------------------------------------------------

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	//---------------implement tray icon------------------
	HICON hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_ctlTrayIcon.Create(this,WM_TRAY_ICON_NOTIFY,"���������-IPMan",hIcon,IDR_TRAY_MENU);
	//----------------------------------------------------


	//------------------����DialogBar---------------------
	if(!m_DlgToolBar.Create(this,IDD_DIALOGBAR,CBRS_BOTTOM,AFX_IDW_CONTROLBAR_LAST-1))
	{
		TRACE0("Failed to create dialogbar");
		return -1;
	}
    //----------------------------------------------------

	//----------------------------------------------------
	// install/load cool menus
	UINT pToolBarId [] = 
	{
		//IDR_MAINFRAME,
		IDR_TRAY_MENU,
	};

	m_ctlMenuManager.Install(this);
	m_ctlMenuManager.LoadToolbars((const UINT*)pToolBarId,_countof(pToolBarId));
	m_ctlMenuManager.m_bAutoAccel = FALSE;
	//m_ctlMenuManager.SetCheckmarkBitmap(IDB_SMILE1, IDB_SMILE);
    //-----------------------------------------------------

   	return 0;
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT /*lpcs*/,
	CCreateContext* pContext)
{
	/*return m_wndSplitter.Create(this,
		2, 2,               // TODO: adjust the number of rows, columns
		CSize(10, 10),      // TODO: adjust the minimum pane size
		pContext);*/
    
	//-----------������̬�з���ͼ--------------------
	if(!m_wndSplitter.CreateStatic(this,2,1))return false; //2��1��
    if(!m_wndSplitter.CreateView(0,0,RUNTIME_CLASS(CIPListView),CSize(150,250),pContext))/*||
       !m_wndSplitter.CreateView(1,0,RUNTIME_CLASS(CBaseCView),CSize(100,100),pContext))*/
	{
		m_wndSplitter.DestroyWindow();
		return false;
	}

    if(m_wndSplitter2.CreateStatic(&m_wndSplitter,1,2,WS_CHILD|WS_VISIBLE, m_wndSplitter.IdFromRowCol(1, 0))==NULL) 
      return FALSE; //����1��0���ٷֿ�1��2�� 
	if(!m_wndSplitter2.CreateView(0,0,RUNTIME_CLASS(CFilterListView),CSize(150,160),pContext)||
       !m_wndSplitter2.CreateView(0,1,RUNTIME_CLASS(CMACListView),CSize(100,160),pContext))
	{
		m_wndSplitter2.DestroyWindow();
		return false;
	}

    
	return true;
	//-----------------------------------------------

}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	//--------------------�޸������ڵķ��------------------
	int cxScreen=::GetSystemMetrics(SM_CXSCREEN);
	int cyScreen=::GetSystemMetrics(SM_CYSCREEN);
	//cs.cy = 500; //height
	//cs.cx = 700; //width
	cs.y = 40; //top
	cs.x = 40; //left
	cs.cx=cxScreen-100; //width
	cs.cy=cyScreen-120; //height
	//------------------------------------------------------

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers




void CMainFrame::OnButton1() 
{
	// TODO: Add your control notification handler code here
	CString str;
	m_DlgToolBar.GetDlgItem(IDC_EDIT1)->GetWindowText(str);
	//AfxMessageBox(str);
	if(str!="")
	{
		pFilterListView->GetListCtrl().InsertItem(0,str);
		m_DlgToolBar.GetDlgItem(IDC_EDIT1)->SetWindowText("");
	}
	else AfxMessageBox("����Edit��������Ҫ���˵��ַ�����");
	
}



void CMainFrame::OnButton2() 
{
	// TODO: Add your control notification handler code here
	pMACListView->SaveToFile();
}

void CMainFrame::OnButtonARP() 
{
	// TODO: Add your command handler code here
	CArpDialog dlg(this);
	dlg.DoModal();
	
}

void CMainFrame::OnButton3() 
{
	// TODO: Add your control notification handler code here

	POSITION pos=pFilterListView->GetListCtrl().GetFirstSelectedItemPosition();
	if(pos==NULL)AfxMessageBox("��ѡ����Ҫɾ����Filter��");
    int nItem = pFilterListView->GetListCtrl().GetNextSelectedItem(pos);
   	pFilterListView->GetListCtrl().DeleteItem(nItem);
	
}





void CMainFrame::OnButton4() 
{
	// TODO: Add your control notification handler code here
	pMACListView->GetListCtrl().DeleteAllItems();
}

LRESULT CMainFrame::OnTrayNotification(WPARAM wParam,LPARAM lParam)
{
	TRACE("WPARAM %i,LPARAM %i\n",wParam,lParam);
	switch(LOWORD(lParam))
	{
	case WM_LBUTTONUP:
		ShowWindow(SW_SHOW);
		SendMessage(WM_SYSCOMMAND,SC_RESTORE);
		break;
	}

	return m_ctlTrayIcon.OnTrayNotification(wParam,lParam);

}

void CMainFrame::OnSysCommand(UINT nID, LPARAM lParam)
{
	
	switch(nID)
	{
	    case SC_MINIMIZE:
		
		m_ctlTrayIcon.ShowIcon();
		ShowWindow(SW_HIDE);
		break;

		case SC_CLOSE:
		if(AfxMessageBox("������˳���",MB_YESNO,0 )==IDYES)
			this->SendMessage(WM_CLOSE);
		    //AfxGetMainWnd()->SendMessage()
		break;

		default:
		CFrameWnd::OnSysCommand(nID,lParam);
	}
	//AfxMessageBox("here");
    

}

void CMainFrame::OnTrayMenuClose() 
{
	// TODO: Add your command handler code here
	this->SendMessage(WM_CLOSE);
}

void CMainFrame::OnTrayMenuOpen() 
{
	// TODO: Add your command handler code here
	ShowWindow(SW_SHOW);
}


