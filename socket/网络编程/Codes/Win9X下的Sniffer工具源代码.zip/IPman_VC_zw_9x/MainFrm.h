// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__5C060089_9F8D_11D5_A956_00058D09EB5F__INCLUDED_)
#define AFX_MAINFRM_H__5C060089_9F8D_11D5_A956_00058D09EB5F__INCLUDED_


#include "TRAY\SystemTray.h"	// Added by ClassView
#include "ToolBarEx\ToolBarEx.h"
#include "COOLMENU\CoolMenu.h"	// Added by ClassView

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//--------------�û��Զ�����Ϣ------------------
#define WM_TRAY_ICON_NOTIFY		WM_USER + 0x1000
//----------------------------------------------

class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
protected:
	CSplitterWnd m_wndSplitter;
	CSplitterWnd m_wndSplitter2;
public:
    CDialogBar m_DlgToolBar;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	CCoolMenuManager m_ctlMenuManager;
	
	CSystemTray m_ctlTrayIcon;
	BOOL m_bBegin;
	BOOL m_bARP;
	BOOL m_bClear;
	BOOL m_bStop;
	CStatusBar  m_wndStatusBar;
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	
	CToolBarEx    m_wndToolBar;
	CComboBox m_wndToolBarCombo;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	afx_msg void OnButtonARP();
	afx_msg void OnButton3();
	afx_msg void OnButton4();
	afx_msg void OnTrayMenuClose();
	afx_msg void OnTrayMenuOpen();
	//}}AFX_MSG
	//--------�ֹ�����-�û��ӿڴ�������----------
    afx_msg void OnHint(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBeginButton(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStopButton(CCmdUI* pCmdUI);
	afx_msg void OnUpdateClearButton(CCmdUI* pCmdUI);
	afx_msg void OnUpdateARPButton(CCmdUI* pCmdUI);
	//-------------------------------------------
	//--------------------tray icon--------------
	
	afx_msg LRESULT OnTrayNotification(WPARAM wParam=0,LPARAM lParam=0);
	//--------------------------------------------
    afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__5C060089_9F8D_11D5_A956_00058D09EB5F__INCLUDED_)
