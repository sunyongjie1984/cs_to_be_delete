// MACListView.cpp : implementation file
//

#include "stdafx.h"
#include "IPMan.h"
#include "MACListView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMACListView
//-------------------ȫ�ֱ���------------------------------
CMACListView* pMACListView;
//---------------------------------------------------------

IMPLEMENT_DYNCREATE(CMACListView, CListView)

CMACListView::CMACListView()
{
	pMACListView=this;
}

CMACListView::~CMACListView()
{
}


BEGIN_MESSAGE_MAP(CMACListView, CListView)
	//{{AFX_MSG_MAP(CMACListView)
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDblclk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMACListView drawing

void CMACListView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CMACListView diagnostics

#ifdef _DEBUG
void CMACListView::AssertValid() const
{
	CListView::AssertValid();
}

void CMACListView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMACListView message handlers

void CMACListView::OnInitialUpdate() 
{
	CListView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class

	//--------------------listview ��ʼ��---------------------
    DWORD dwStyle=GetWindowLong(GetListCtrl().GetSafeHwnd(),GWL_STYLE);
	dwStyle&=~LVS_TYPEMASK;
	dwStyle|=LVS_REPORT;
	SetWindowLong(GetListCtrl().GetSafeHwnd(),GWL_STYLE,dwStyle);
	SetRedraw(TRUE);

	GetListCtrl().InsertColumn(0,"���˺������",LVCFMT_LEFT,525);
	/*GetListCtrl().InsertColumn(0,"��С",LVCFMT_LEFT,80);
    GetListCtrl().InsertColumn(0,"�˿�",LVCFMT_LEFT,40);
	GetListCtrl().InsertColumn(0,"Ŀ�ĵ�ַ",LVCFMT_LEFT,100);
	GetListCtrl().InsertColumn(0,"�˿�",LVCFMT_LEFT,40);
	GetListCtrl().InsertColumn(0,"Դ��ַ",LVCFMT_LEFT,100);
	GetListCtrl().InsertColumn(0,"Э��",LVCFMT_LEFT,40);*/
    
    /*::SendMessage(GetListCtrl().m_hWnd, LVM_SETEXTENDEDLISTVIEWSTYLE,
      LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);*/
	//--------------------------------------------------------	
	
	
}

void CMACListView::OnDblclk(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	CString str;
	int SelIndex=GetListCtrl().GetSelectionMark( );
	str=GetListCtrl().GetItemText(SelIndex,0);
	if(str!="")AfxMessageBox(str);	
	*pResult = 0;
}



void CMACListView::SaveToFile()
{
	int Count=GetListCtrl().GetItemCount();
	CFile f;
	CFileException e;
	CString strFileName;

	CTime t=CTime::GetCurrentTime();
	CString strTime = t.Format( "%d-%H-%M-%S" );
	strTime="IP_LOG-"+strTime;
	//char* filename=(LPSTR)(LPCTSTR)strTime;

	CFileDialog fileDlg(FALSE,"txt",strTime,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,"txt",NULL); //TRUE Ϊ�򿪶Ի���
	if(fileDlg.DoModal()==IDOK)
	{
		UpdateData(true);
		strFileName=fileDlg.GetFileName();
		UpdateData(false);
		
		if( f.Open(strFileName, CFile::modeCreate | CFile::modeWrite, &e ) )
		{
		
			//f.Write( m_Edit, m_Edit.GetLength() );
			//AfxMessageBox((LPSTR)(LPCTSTR)strFileName);
			for(int i=0;i<Count;i++)
			{

				CString str;
				str=GetListCtrl().GetItemText(i,0);
				str+="\r\n\r\n";
				f.Write( str, str.GetLength() );
			}
			f.Close();
		}
	}	
   
}
