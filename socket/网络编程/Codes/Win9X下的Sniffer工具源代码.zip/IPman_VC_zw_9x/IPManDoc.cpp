// IPManDoc.cpp : implementation of the CIPManDoc class
//

#include "stdafx.h"
#include "IPMan.h"

#include "IPManDoc.h"

#include "FilterListView.h"
#include "IPListView.h"
#include "MacListView.h"
#include "MainFrm.h"
#include "ArpDialog.h"

//#include <windows.h>
//#include <stdio.h>
#include "IPfunc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIPManDoc
//----------------------------var------------------------------
	int argc=0;
	//char *argv[];
	
	//---------------
	HANDLE hVxD;
	DWORD dwErrorCode;
	struct EtherAddr m_EtherAddr;
	struct IPAddr m_IPAddr;
	HANDLE hEvent;
	BOOL Continue;
	int i,j,k;
	BYTE Buffer[BUFFER_SIZE];
	WORD DataLen;
	struct EtherPacketHead *pEtherHead;
	struct IPPacketHead *pIPHead;
	struct TCPPacketHead *pTCPHead;
	struct ARPPacket *pARPHead;
	struct ICMPPacketHead *pICMPHead;
	struct UDPPacketHead *pUDPHead;
	int headlen,totallen;
	struct IPAddr *psourip,*pdestip;
	struct EtherAddr *psoureth,*pdesteth;
	WORD sourport,destport;
	DWORD seqno,ackno;
	BYTE *pdata;
	WORD filter;
	BOOL flag;
	FILE /**pfout=NULL,*pfcmd=NULL,*/*pfini=NULL;
	struct EtherAddr ethernull,etherbroad;
	struct IPAddr ipnull;
	struct CommandLine cmdline;
	struct InitialFile inifile;
	char Command[BUFFER_SIZE];
	char *pbufh,*pbuft;
	struct EtherAddr sendethaddr,recvethaddr,sourethaddr,destethaddr;
	struct IPAddr sipaddr,dipaddr;
	WORD arpoper,tcpid;
	struct TCPConnection TCP[MAX_CONNECTION];
	WORD maxconn=0;
	WORD TCPFlag;
    //----------------
	CString strFind;
	int findCount=0;
	bool exitthread;
	int iWait;
//-------------------------------------------------------------

IMPLEMENT_DYNCREATE(CIPManDoc, CDocument)

BEGIN_MESSAGE_MAP(CIPManDoc, CDocument)
	//{{AFX_MSG_MAP(CIPManDoc)
	ON_COMMAND(ID_BUTTON32772, OnButtonBeginSniffer)
	ON_COMMAND(ID_BUTTON32773, OnButtonExitSniffer)
	ON_COMMAND(ID_BUTTON32774, OnButtonClear)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIPManDoc construction/destruction
//-------------------ȫ�ֱ���------------------------------
CIPManDoc* pIPManDoc;
extern CIPListView* pIPListView;
extern CFilterListView* pFilterListView;
extern CMACListView* pMACListView;
extern CMainFrame* pMainFrame;
extern CArpDialog* pDlg; 
//---------------------------------------------------------

CIPManDoc::CIPManDoc()
{
	// TODO: add one-time construction code here
    pIPManDoc=this;
	m_display=0;
}

CIPManDoc::~CIPManDoc()
{
}

BOOL CIPManDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)
	pIPManDoc->SetTitle("���������");
	int ver=GetVersion() & 0xff;
	//str.Format("%d",ver);
	//AfxMessageBox(str);
	if(ver>4)AfxMessageBox("IPManʹ�õ���vxd,��������Win9x��Windows MEϵͳ!");

	//===========================================
    /* Set null ethernet address and broadcast ethernet address */
	memset((void*)&ethernull,0,6);
	memset((void*)&etherbroad,0xff,6);
	memset((void*)&ipnull,0,6);

	//-----------------��IPMan.ini--------------------------
	/* Get initial file property */ 
	if((pfini=fopen(INITIAL_FILE,"r"))==NULL) {
		str.Format("Can not open %s\n",INITIAL_FILE);
		AfxMessageBox(str);
		//return 0;
	}
	if(GetInitial(pfini,&inifile)!=OK) {
		AfxMessageBox("Not valid initial file.\n");
		//return 0;
	}
	Max_Data_Len=inifile.maxdatalen;
	memcpy((void *)&m_IPAddr,(void *)&inifile.mipaddr,4);
	//----------------------------------------------------------

    //----------------VXD����--------------------------------------------------
    
	/* Open device */
    hVxD = CreateFile("\\\\.\\VPACKET.VXD", 
                      GENERIC_READ | GENERIC_WRITE,
                      0,
                      NULL,
                      OPEN_EXISTING,
                      FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED |
                      FILE_FLAG_DELETE_ON_CLOSE,
                      NULL);

    if (hVxD == INVALID_HANDLE_VALUE) {
        dwErrorCode = GetLastError();
        if (dwErrorCode == ERROR_NOT_SUPPORTED) {
            AfxMessageBox("Unable to open VxD,\ndevice does not support DeviceIOCTL\n");
        }
        else
		{
		    str.Format("Unable to open VxD, Error code: %lx\n", dwErrorCode);
		    AfxMessageBox(str);
		}
		//return(0);
    }

	else
	{
		//AfxMessageBox("Device opened successfully");
		//---------------------statusbar��ʼ��---------------
	    int st1=pMainFrame->m_wndStatusBar.CommandToIndex(ID_INDICATOR_HINT);
	    pMainFrame->m_wndStatusBar.SetPaneStyle(st1,SBPS_NORMAL);
	    pMainFrame->m_wndStatusBar.SetPaneText(st1,"Device opened successfully",true);
	//---------------------------------------------------
	}
	/* Device opened successfully */
		/* Bind driver to NDIS3 adapter	*/

	Bind(hVxD,(unsigned char*)inifile.ndis);

	if(GetHardEtherAddr(hVxD,&m_EtherAddr)!=OK) AfxMessageBox("Cant't get ethernet address");
	//===========================================
	exitthread=false;
	//AfxGetMainWnd()->SetWindowText("WinIPMan 1.0");
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CIPManDoc serialization

void CIPManDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here

	}
}

/////////////////////////////////////////////////////////////////////////////
// CIPManDoc diagnostics

#ifdef _DEBUG
void CIPManDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CIPManDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CIPManDoc commands
//----------------------------�����߳�-----------------------------
UINT ListenAllThread(LPVOID param)
{
	    CString strIP,strMAC,strPORT,strB,strData,strAll,str1;
		int index,tem;

		//AfxMessageBox("��ʼ����")

		//========================
		/* Set Filter */
		filter=NDIS_PACKET_TYPE_PROMISCUOUS;
		SetOid(hVxD, OID_GEN_CURRENT_PACKET_FILTER, 4, filter);
		//========================

		/* Do listen */
		Continue=TRUE;
		while(Continue) {

			if(exitthread)
			{
				AfxMessageBox("�жϼ����̣߳�");
				exitthread=false;
				return 1;
			}

			strAll="";

			DataLen=RecvPacket(hVxD,Buffer,100,3);

			if(exitthread)
			{
				AfxMessageBox("�жϼ����̣߳�");
				exitthread=false;
				return 1;
			}			
			
			if(DataLen==SYSERR)
			{
			
				AfxMessageBox("error:DataLen==SYSERR");
				return 1;//goto ENDOFTASK;
			}
			/* Begin to process data */
			
			pEtherHead=(struct EtherPacketHead *)Buffer;
			
			switch (swaps(pEtherHead->ServType)) {
			case ETHER_PROTO_IP:	/* IP packet */
				pIPHead=(struct IPPacketHead *)(Buffer+ETHER_HEAD_LEN);
				headlen=(pIPHead->VerHLen)&0xf;
				headlen*=4;
				totallen=swaps(pIPHead->TtlLen);
				psourip=&(pIPHead->SourIP);
				pdestip=&(pIPHead->DestIP);
				flag=TRUE;
				if(cmdline.option&OPT_LISTEN_IP) {
					flag=FALSE;
					if((cmdline.option&OPT_LISTEN_IP_1)&&
					   (memcmp((void *)&cmdline.queip[0],(void *)psourip,4)==0||
						memcmp((void *)&cmdline.queip[0],(void *)pdestip,4)==0))  
						flag=TRUE;
					else if((cmdline.option&OPT_LISTEN_IP_2)&&
							((memcmp((void *)&cmdline.queip[0],(void *)psourip,4)==0&&
							  memcmp((void *)&cmdline.queip[1],(void *)pdestip,4))||
							 (memcmp((void *)&cmdline.queip[0],(void *)pdestip,4)==0&&
							  memcmp((void *)&cmdline.queip[1],(void *)psourip,4))))
						flag=TRUE;
				}
				else if(cmdline.option&OPT_LISTEN_INIT) {
					flag=FALSE;
					for(i=0;i<inifile.ipno;i++) 
						if(memcmp((void *)&inifile.qip[i],(void *)psourip,4)==0||
						   memcmp((void *)&inifile.qip[i],(void *)pdestip,4)==0) break;
					if(i<inifile.ipno) flag=TRUE;
				}
				if(flag) {
					switch (pIPHead->Proto) {
					case IP_PROTO_TCP:	/* TCP packet */
						pTCPHead=(struct TCPPacketHead *)(Buffer+ETHER_HEAD_LEN+headlen);
						totallen-=headlen;
						sourport=swaps(pTCPHead->SourPort);
						destport=swaps(pTCPHead->DestPort);
						seqno=swapl(pTCPHead->SeqNo);
						ackno=swapl(pTCPHead->AckNo);
						headlen=(pTCPHead->HLen)>>4;
						headlen*=4;
						totallen-=headlen;
						pdata=((BYTE *)pTCPHead)+headlen;
						/* TODO */
						flag=TRUE;
						if(cmdline.option&OPT_LISTEN_PORT) {
							flag=FALSE;
							if((cmdline.option&OPT_LISTEN_PORT_1)&&
							   (cmdline.queport[0]==sourport||
							    cmdline.queport[0]==destport))
								flag=TRUE;
							else if((cmdline.option&OPT_LISTEN_PORT_2)&&
								     ((cmdline.queport[0]==sourport&&cmdline.queport[1]==destport)||
									  (cmdline.queport[0]==destport&&cmdline.queport[1]==sourport)))
								flag=TRUE;										
						}
						else if(cmdline.option&OPT_LISTEN_INIT) {
							flag=FALSE;
							for(i=0;i<inifile.portno;i++) 
								if(sourport==inifile.qport[i]||
								   destport==inifile.qport[i]) break;
							if(i<inifile.portno) flag=TRUE;
						}
						if(flag) {
							index=pIPListView->GetListCtrl().InsertItem(0,"TCP");

							strIP=StrIPAddr(psourip);
							pIPListView->GetListCtrl().SetItem(index,1,LVIF_TEXT,strIP, 0, 0, 0,0);
							
							strPORT.Format("%d",sourport);
							pIPListView->GetListCtrl().SetItem(index,2,LVIF_TEXT,strPORT, 0, 0, 0,0);

							strAll="TCP:"+strIP+":"+strPORT+" -> ";

							strIP=StrIPAddr(pdestip);
							pIPListView->GetListCtrl().SetItem(index,3,LVIF_TEXT,strIP, 0, 0, 0,0);
							
							strPORT.Format("%d",destport);
							pIPListView->GetListCtrl().SetItem(index,4,LVIF_TEXT,strPORT, 0, 0, 0,0);
							
							strB.Format("%d Byte(s)",totallen);
							pIPListView->GetListCtrl().SetItem(index,5,LVIF_TEXT,strB, 0, 0, 0,0);

							strData=StrData(pdata,totallen,pIPManDoc->m_display);
							pIPListView->GetListCtrl().SetItem(index,6,LVIF_TEXT,strData, 0, 0, 0,0);

							strAll=strAll+strIP+":"+strPORT+":\r\n"+strB+":\r\n"+strData;
							//pDlg->m_FilterBox.InsertString(0,strAll);
							//http filter
							//if(strData.Find("http")!=-1)pDlg->m_FilterBox.InsertString(0,strAll);
						}
						break;
					case IP_PROTO_UDP:	/* UDP packet */
						pUDPHead=(struct UDPPacketHead *)(Buffer+ETHER_HEAD_LEN+headlen);
						totallen-=headlen;
						sourport=swaps(pUDPHead->SourPort);
						destport=swaps(pUDPHead->DestPort);
						pdata=((BYTE *)pUDPHead)+UDP_HEAD_LEN;
						/* TODO */
						totallen-=UDP_HEAD_LEN;
						flag=TRUE;
						if(cmdline.option&OPT_LISTEN_PORT) {
							flag=FALSE;
							if((cmdline.option&OPT_LISTEN_PORT_1)&&
							   (cmdline.queport[0]==sourport||
							    cmdline.queport[0]==destport))
								flag=TRUE;
							else if((cmdline.option&OPT_LISTEN_PORT_2)&&
								     ((cmdline.queport[0]==sourport&&cmdline.queport[1]==destport)||
									  (cmdline.queport[0]==destport&&cmdline.queport[1]==sourport)))
								flag=TRUE;										
						}
						else if(cmdline.option&OPT_LISTEN_INIT) {
							flag=FALSE;
							for(i=0;i<inifile.portno;i++) 
								if(sourport==inifile.qport[i]||
								   destport==inifile.qport[i]) break;
							if(i<inifile.portno) flag=TRUE;
						}
						if(flag) {
							index=pIPListView->GetListCtrl().InsertItem(0,"UDP");

							strIP=StrIPAddr(psourip);
                            pIPListView->GetListCtrl().SetItem(index,1,LVIF_TEXT,strIP, 0, 0, 0,0);
							
							strPORT.Format("%d",sourport);
							pIPListView->GetListCtrl().SetItem(index,2,LVIF_TEXT,strPORT, 0, 0, 0,0);
		
                            strAll="UDP:"+strIP+":"+strPORT+" -> ";

							strIP=StrIPAddr(pdestip);
							pIPListView->GetListCtrl().SetItem(index,3,LVIF_TEXT,strIP, 0, 0, 0,0);
							
							strPORT.Format("%d",destport);
							pIPListView->GetListCtrl().SetItem(index,4,LVIF_TEXT,strPORT, 0, 0, 0,0);

							strB.Format("%d Byte(s)",totallen);
							pIPListView->GetListCtrl().SetItem(index,5,LVIF_TEXT,strB, 0, 0, 0,0);

							strData=StrData(pdata,totallen,pIPManDoc->m_display);
							pIPListView->GetListCtrl().SetItem(index,6,LVIF_TEXT,strData, 0, 0, 0,0);
							
							strAll=strAll+strIP+":"+strPORT+":\r\n"+strB+":\r\n"+strData;
						}
						break;
					case IP_PROTO_ICMP:	/* ICMP packet */
						flag=TRUE;
						if(cmdline.option&OPT_LISTEN_PORT) 
						   flag=FALSE;
						if(flag) {
							pICMPHead=(struct ICMPPacketHead *)(Buffer+ETHER_HEAD_LEN+headlen);
							totallen-=headlen;
							pdata=((BYTE *)pICMPHead)+ICMP_HEAD_LEN;
							totallen-=ICMP_HEAD_LEN;
							/* TODO */
							index=pIPListView->GetListCtrl().InsertItem(0,"ICMP");

							strIP=StrIPAddr(psourip);
							pIPListView->GetListCtrl().SetItem(index,1,LVIF_TEXT,strIP, 0, 0, 0,0);

							strPORT="-";  //����˿�
							pIPListView->GetListCtrl().SetItem(index,2,LVIF_TEXT,strPORT, 0, 0, 0,0);

							strAll="ICMP:"+strIP+":"+strPORT+" -> ";
							
							strIP=StrIPAddr(pdestip);
							pIPListView->GetListCtrl().SetItem(index,3,LVIF_TEXT,strIP, 0, 0, 0,0);

							strPORT="-"; //����˿�
							pIPListView->GetListCtrl().SetItem(index,4,LVIF_TEXT,strPORT, 0, 0, 0,0);
							
							strB.Format("%d Byte(s)",totallen);
							pIPListView->GetListCtrl().SetItem(index,5,LVIF_TEXT,strB, 0, 0, 0,0);

							strData.Format("ICMP Message:Type:%d Code:%d\n",pICMPHead->Type,pICMPHead->Code);
							pIPListView->GetListCtrl().SetItem(index,6,LVIF_TEXT,strData, 0, 0, 0,0);

							strAll=strAll+strIP+":"+strPORT+":\r\n"+strB+":\r\n"+strData;
						}
						break;
					default:	/* Unknown packet */
						/*fprintf(stderr,"Unknown ip packet type.\n");*/
						break;
					}
				}
				break;
			case ETHER_PROTO_ARP:	/* ARP packet */
				if((cmdline.option&OPT_LISTEN_SPEC)==0) {
					pARPHead=(struct ARPPacket*)(Buffer+ETHER_HEAD_LEN);
					psourip=&(pARPHead->SourIP);
					pdestip=&(pARPHead->DestIP);
					psoureth=&(pARPHead->SourEther);
					pdesteth=&(pARPHead->DestEther);
					/* TODO */
					index=pIPListView->GetListCtrl().InsertItem(0,"ARP");

					strMAC=StrEtherAddr(psoureth);					
					strIP=StrIPAddr(psourip);
					str=strIP+"("+strMAC+")";
					pIPListView->GetListCtrl().SetItem(index,1,LVIF_TEXT,str, 0, 0, 0,0);

					strPORT="-"; //����˿�
					pIPListView->GetListCtrl().SetItem(index,2,LVIF_TEXT,strPORT, 0, 0, 0,0);

					strAll="ARP:"+str+":"+strPORT+" -> ";
					
					strMAC=StrEtherAddr(pdesteth);		
					strIP=StrIPAddr(pdestip);
					str=strIP+"("+strMAC+")";
					pIPListView->GetListCtrl().SetItem(index,3,LVIF_TEXT,str, 0, 0, 0,0);
					
					strPORT="-"; //����˿�
					pIPListView->GetListCtrl().SetItem(index,4,LVIF_TEXT,strPORT, 0, 0, 0,0);

					strB="-"; 
					pIPListView->GetListCtrl().SetItem(index,5,LVIF_TEXT,strPORT, 0, 0, 0,0);

					strData.Format(" Operation:%d\n",swaps(pARPHead->Oper));
					pIPListView->GetListCtrl().SetItem(index,6,LVIF_TEXT,strData, 0, 0, 0,0);

					strAll="ARP: "+str+strIP+":"+strPORT+":\r\n"+strB+":\r\n"+strData;
				}
				break;
			default:	/* Unknown packet */
				//pDlg->m_ctlList.InsertString(0,"Unknown ethernet packet type.");
				//pDlg->m_ctlList.AddString("Unknown ethernet packet type.");
				//pDlg->m_ctlList.AddString("���������˷��������ھ�Ӵ��");
				break;
			}
			
            str1=strAll;
			findCount=pFilterListView->GetListCtrl().GetItemCount();
            for(tem=0;tem<findCount;tem++)
			{
				str1.MakeLower();
				strFind=pFilterListView->GetListCtrl().GetItemText(tem,0);
				strFind.MakeLower();
				if(str1.Find(strFind)!=-1)pMACListView->GetListCtrl().InsertItem(0,strAll);
			}
			//pDlg->m_FilterBox.InsertString(0,strAll);

			continue;
		}
	
	//pDlg->m_ctlList.AddString("leave listen!");
	return 0;
}
//-------------------------------------------------------------

//------------------------------arp�߳�----------------------
UINT ArpThread(LPVOID param)
{
	//int line=10;
    
    
	//========================
	/* Set Filter */
	filter=NDIS_PACKET_TYPE_DIRECTED;
	SetOid(hVxD, OID_GEN_CURRENT_PACKET_FILTER, 4, filter);
	//========================

	pDlg->m_IPEdit1.GetAddress(cmdline.queip[0].AddrByte[0],
							  cmdline.queip[0].AddrByte[1],
							  cmdline.queip[0].AddrByte[2],
							  cmdline.queip[0].AddrByte[3]);
    
	unsigned char AddrB[4];
	pDlg->m_IPEdit2.GetAddress(AddrB[0],AddrB[1],AddrB[2],AddrB[3]);
	if(AddrB[2]<cmdline.queip[0].AddrByte[2]){AfxMessageBox("��ֹ��ַӦ������ʼ��ַ��"); return 0;}
	else if(AddrB[2]==cmdline.queip[0].AddrByte[2]&&AddrB[3]<cmdline.queip[0].AddrByte[3]){AfxMessageBox("��ֹ��ַӦ������ʼ��ַ��"); return 0;}
	if(AddrB[0]!=cmdline.queip[0].AddrByte[0]||AddrB[1]!=cmdline.queip[0].AddrByte[1]){AfxMessageBox("��֧��A���B������"); return 0;}

	do{
		/* Do query ethernet address form IP */
		if(exitthread)
		{
			    //AfxMessageBox("�ж�ARP�̣߳�");
				exitthread=false;
				pDlg->GetDlgItem(IDC_BUTTON1)->EnableWindow(true);
	            pDlg->GetDlgItem(IDC_BUTTON2)->EnableWindow(false);
	            pDlg->GetDlgItem(IDC_BUTTON3)->EnableWindow(true);
	            pDlg->GetDlgItem(IDOK)->EnableWindow(true);
				pDlg->m_bStart=false;
				return 1;
		}

		CString strIP,strMAC;
		strIP.Format("%d.%d.%d.%d",cmdline.queip[0].AddrByte[0],cmdline.queip[0].AddrByte[1],cmdline.queip[0].AddrByte[2],cmdline.queip[0].AddrByte[3]);
		//pDlg->m_ctlList.AddString(strIP);
		ListenStart(hVxD);
		SendARPPacket(hVxD,
					  &m_EtherAddr,
					  &etherbroad,
					  &m_EtherAddr,
					  &ethernull,
					  &m_IPAddr,
					  &cmdline.queip[0],
					  ARP_OPER_ARP_REQ);
		
		////pDlg->m_ctlList.AddString("ARP��������ϡ��ȴ���Ӧ......");

		Continue=TRUE;
		
		//int n=0;
		while(Continue) {
			   
                //pDlg->UpdateData(true);
			    int nWait=pDlg->m_SpinEdit;
				
				//pDlg->UpdateData(false);
				if((DataLen=RecvPacket(hVxD,Buffer,nWait,1))==SYSERR) {
				AfxMessageBox("Can not recv ARP packet.");
				
				goto ENDOFARP;
			}
			
			
			if(DataLen==65535)
			{
				////pDlg->m_ctlList.AddString("-----------end of ARP-----------");
				strMAC="Time Out!";
				goto ENDOFARP;//return 0;
			}

			pEtherHead=(struct EtherPacketHead *)Buffer;
			if(swaps(pEtherHead->ServType)!=ETHER_PROTO_ARP) continue;
			pARPHead=(struct ARPPacket *)(Buffer+ETHER_HEAD_LEN);
			if(swaps(pARPHead->Oper)!=ARP_OPER_ARP_ANS) continue;
			if(memcmp((void *)&pARPHead->SourIP,(void *)&cmdline.queip[0],4)!=0) continue;
			/* Get ethernet address */
			/////pDlg->m_ctlList.AddString("Ethernet Address:");
			strMAC=StrEtherAddr(&pARPHead->SourEther);
			
			Continue=FALSE;
		}
ENDOFARP:
		//pDlg->m_ctlList.AddString(strIP+":"+strMAC);
		str=strIP+"  :  "+strMAC+"\r\n";
		//pDlg->UpdateData(true);
		pDlg->m_MacList.InsertString(0,str);
		if(strMAC!="Time Out!")pDlg->m_ARPList.InsertString(0,str);
		//pDlg->UpdateData(false);

		//::SendMessage(pDlg->m_ctEdit.GetSafeHwnd(),WM_VSCROLL,SB_PAGEDOWN,1);
		//line+=1;
		//::SetScrollPos(pDlg->m_ctEdit.GetSafeHwnd(),SB_VERT,line,true);

		if(cmdline.queip[0].AddrByte[2]<=AddrB[2])
		{
		   //if(cmdline.queip[0].AddrByte[3]==255)AfxMessageBox("here0");
		   if(cmdline.queip[0].AddrByte[3]<AddrB[3])cmdline.queip[0].AddrByte[3]++;
		   else if(cmdline.queip[0].AddrByte[2]<AddrB[2]&&cmdline.queip[0].AddrByte[3]<255)cmdline.queip[0].AddrByte[3]++;
		   else if(cmdline.queip[0].AddrByte[2]<AddrB[2]&&cmdline.queip[0].AddrByte[3]==255)
		   {
			   //AfxMessageBox("here");
               cmdline.queip[0].AddrByte[3]=0;
			   cmdline.queip[0].AddrByte[2]++;
		   }
		}
		else break;
		if(cmdline.queip[0].AddrByte[3]>=AddrB[3]&&cmdline.queip[0].AddrByte[2]>=AddrB[2])break;

	}while(cmdline.queip[0].AddrByte[2]<=255&&cmdline.queip[0].AddrByte[3]<=255);
	//pDlg->m_ctlList.AddString("---------end of all arp---------");

	//pDlg->UpdateData(true);
	pDlg->m_MacList.InsertString(0,"---------end of all arp---------\r\n");
	//pDlg->UpdateData(false);

	//========================
	/* Set Filter */
	filter=NDIS_PACKET_TYPE_PROMISCUOUS;
	SetOid(hVxD, OID_GEN_CURRENT_PACKET_FILTER, 4, filter);
	//========================
	pDlg->GetDlgItem(IDC_BUTTON1)->EnableWindow(true);
	pDlg->GetDlgItem(IDC_BUTTON2)->EnableWindow(false);
	pDlg->GetDlgItem(IDC_BUTTON3)->EnableWindow(true);
	pDlg->GetDlgItem(IDOK)->EnableWindow(true);
	pDlg->m_bStart=false;
    AfxMessageBox("ARP������ϣ�");
	return 0;
}
//-----------------------------------------------------------

void CIPManDoc::OnButtonBeginSniffer() 
{
	// TODO: Add your command handler code here

	//---------------------statusbar ---------------
	    int st1=pMainFrame->m_wndStatusBar.CommandToIndex(ID_INDICATOR_HINT);
	    pMainFrame->m_wndStatusBar.SetPaneStyle(st1,SBPS_NORMAL);
	    pMainFrame->m_wndStatusBar.SetPaneText(st1,"��ʼ����",true);
     //----------------------------------------------
	pMainFrame->m_bBegin = false;
	pMainFrame->m_bStop = true;
	pMainFrame->m_bClear = false;
	pMainFrame->m_bARP = false;

	exitthread=false;

	AfxBeginThread(ListenAllThread,this,THREAD_PRIORITY_NORMAL);

}

void CIPManDoc::OnButtonExitSniffer() 
{
	// TODO: Add your command handler code here
	exitthread=true;
	pMainFrame->m_bBegin = true;
	pMainFrame->m_bStop = false;
	pMainFrame->m_bClear = true;
	pMainFrame->m_bARP = true;
}



void CIPManDoc::OnButtonClear() 
{
	// TODO: Add your command handler code here
	pIPListView->GetListCtrl().DeleteAllItems();
	pFilterListView->GetListCtrl().DeleteAllItems();
	pMACListView->GetListCtrl().DeleteAllItems();
}

void CIPManDoc::OnRadio1() 
{
	// TODO: Add your control notification handler code here
	m_display=0;
}

void CIPManDoc::OnRadio2() 
{
	// TODO: Add your control notification handler code here
	m_display=1;
}

void CIPManDoc::BeginArp(int nWait)
{

	AfxBeginThread(ArpThread,this,THREAD_PRIORITY_NORMAL);

}

void CIPManDoc::ExitArp()
{
	exitthread=true;

}

void CIPManDoc::OnCloseDocument() 
{
	// TODO: Add your specialized code here and/or call the base class
	CloseHandle(hVxD);
	//if(pfout!=NULL) fclose(pfout);
	//if(pfcmd!=NULL) fclose(pfcmd);		
	CDocument::OnCloseDocument();
}
