// ArpDialog.cpp : implementation file
//

#include "stdafx.h"
#include "IPMan.h"
#include "ArpDialog.h"

#include "IPManDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CArpDialog dialog
//-------------------------------var----------------------
CArpDialog* pDlg;
extern CIPManDoc* pIPManDoc;
//--------------------------------------------------------

CArpDialog::CArpDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CArpDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CArpDialog)
	m_SpinEdit = 0;
	//}}AFX_DATA_INIT
	pDlg=this;
	m_bStart=false;
}


void CArpDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CArpDialog)
	DDX_Control(pDX, IDC_LIST5, m_ARPList);
	DDX_Control(pDX, IDC_TAB1, m_ctlTab);
	DDX_Control(pDX, IDC_SPIN1, m_spin);
	DDX_Control(pDX, IDC_LIST1, m_MacList);
	DDX_Control(pDX, IDC_IPADDRESS2, m_IPEdit2);
	DDX_Control(pDX, IDC_IPADDRESS1, m_IPEdit1);
	DDX_Text(pDX, IDC_EDIT1, m_SpinEdit);
	//}}AFX_DATA_MAP

}


BEGIN_MESSAGE_MAP(CArpDialog, CDialog)
	//{{AFX_MSG_MAP(CArpDialog)
	ON_WM_SHOWWINDOW()
	ON_BN_CLICKED(IDC_BUTTON1, OnButtonBeginArp)
	ON_BN_CLICKED(IDC_BUTTON2, OnButtonExitArp)
	ON_WM_CLOSE()
	ON_NOTIFY(IPN_FIELDCHANGED, IDC_IPADDRESS1, OnFieldchangedIpaddress1)
	ON_BN_CLICKED(IDC_BUTTON3, OnButtonSave)
	ON_BN_CLICKED(IDC_BUTTON4, OnButtonClear)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB1, OnSelchangeTab1)
	//}}AFX_MSG_MAP
	//�ֹ�����
    ON_WM_SYSCOMMAND()

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CArpDialog message handlers

void CArpDialog::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	m_IPEdit1.SetAddress(210,28,128,1);
	m_IPEdit2.SetAddress(210,28,143,255);
	m_spin.SetRange(1,10000);
	m_spin.SetPos(100);
	GetDlgItem(IDC_BUTTON2)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON3)->EnableWindow(false);

   //------------ Tab initialize--------------
   TC_ITEM tci;
   
   CString str = "���е�ַ";

   tci.mask       = TCIF_TEXT;    
   tci.pszText    = (LPSTR)(LPCTSTR)str;     
   tci.cchTextMax = str.GetLength();    
   m_ctlTab.InsertItem(0, &tci);
   //-----------------
   str = "����Ӧ�ĵ�ַ";

   tci.mask       = TCIF_TEXT;    
   tci.pszText    = (LPSTR)(LPCTSTR)str;     
   tci.cchTextMax = str.GetLength();    

   m_ctlTab.InsertItem(1, &tci);

   m_MacList.ShowWindow(SW_SHOWNORMAL);
   m_ARPList.ShowWindow(SW_HIDE);
   //-----------------------------------------
}

void CArpDialog::OnButtonBeginArp() 
{
	// TODO: Add your control notification handler code here
	UpdateData(true);
	pIPManDoc->BeginArp(m_SpinEdit);
	UpdateData(false);
	GetDlgItem(IDC_BUTTON1)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON2)->EnableWindow(true);
	GetDlgItem(IDC_BUTTON3)->EnableWindow(false);
	GetDlgItem(IDOK)->EnableWindow(false);
	m_bStart=true;
}

void CArpDialog::OnButtonExitArp() 
{
	// TODO: Add your control notification handler code here

	pIPManDoc->ExitArp();
	
}

void CArpDialog::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	pIPManDoc->ExitArp();
	
	CDialog::OnClose();
}

void CArpDialog::OnFieldchangedIpaddress1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here

	unsigned char AddrB[4];
	m_IPEdit1.GetAddress(AddrB[0],AddrB[1],AddrB[2],AddrB[3]);
	m_IPEdit2.SetAddress(AddrB[0],AddrB[1],AddrB[2],AddrB[3]);

	*pResult = 0;
}

void CArpDialog::OnButtonSave() 
{
	// TODO: Add your control notification handler code here

	CListBox*	TemList;
	if(m_ctlTab.GetCurSel()==0)TemList=&m_MacList;
	else TemList=&m_ARPList;

	int Count=TemList->GetCount();
	CFile f;
	CFileException e;
	CString strFileName;

	CTime t=CTime::GetCurrentTime();
	CString strTime = t.Format( "%d-%H-%M-%S" );
	strTime="ARP_LOG-"+strTime;
	//char* filename=(LPSTR)(LPCTSTR)strTime;

	CFileDialog fileDlg(FALSE,"txt",strTime,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,"txt",NULL); //TRUE Ϊ�򿪶Ի���
	if(fileDlg.DoModal()==IDOK)
	{
		UpdateData(true);
		strFileName=fileDlg.GetFileName();
		UpdateData(false);
		
		if( f.Open(strFileName, CFile::modeCreate | CFile::modeWrite, &e ) )
		{
		
			//f.Write( m_Edit, m_Edit.GetLength() );
			//AfxMessageBox((LPSTR)(LPCTSTR)strFileName);
			for(int i=0;i<Count;i++)
			{

				CString str;
				TemList->GetText(i,str);
				str+="\0\r";
				f.Write( str, str.GetLength() );
			}
			f.Close();
		}
	}
	
}

void CArpDialog::OnButtonClear() 
{
	// TODO: Add your control notification handler code here
	m_MacList.ResetContent();
}



void CArpDialog::OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here

   int nCurTab = m_ctlTab.GetCurSel();
   switch (nCurTab)
   {
      case 0:
		 m_MacList.ShowWindow(SW_SHOWNORMAL);
         m_ARPList.ShowWindow(SW_HIDE);
         break;

      case 1:
         m_ARPList.ShowWindow(SW_SHOWNORMAL);
		 m_MacList.ShowWindow(SW_HIDE);
		 break;

	  //default:
		 
   }

	*pResult = 0;
}

void CArpDialog::OnSysCommand(UINT nID, LPARAM lParam)
{
	//CStealthFrame::OnSysCommand(nID, lParam);
	switch(nID)
	{
		case SC_CLOSE:
		/*if(AfxMessageBox("������˳���",MB_YESNO,0 )==IDYES)
			this->SendMessage(WM_CLOSE);
		    //AfxGetMainWnd()->SendMessage()*/
		if(m_bStart)AfxMessageBox("���Ƚ���ARP�߳�");
		else this->SendMessage(WM_CLOSE);
		break;
		default:CDialog::OnSysCommand(nID,lParam);
	}

}
