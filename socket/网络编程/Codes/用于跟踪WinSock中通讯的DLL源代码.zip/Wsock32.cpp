//****************************************************************
//
//      ���������ѷ�������һ�����Լ��޸Ķ��ɣ�
//      �ȸ�лǰ�����ߡ�
//
//      ����ͨ���滻wsock32.dll �����winsock����
//      ԭwsock32.dll ����Ϊ wsock32.aaa        
//      ˭����Ȥ�޸ĵø��ã������Ҳ��һ��
//      hjx321@21cn.com
//      vchelp ID : 283 
//
//***************************************************************
#include <windows.h>
#include <stdio.h>
#include "wsock32.h"
#define Max_Data_Len 400
#define DataFile  "c:\\popsocket.txt"

void SaveRecord(char *p)
{
FILE *fp=fopen(DataFile,"a+");
if(fp!=NULL) {
fprintf(fp,"%s\n",p);
fclose(fp);
}
//��־�ļ�
}

void PrintData(FILE *pf, BYTE FAR *pdata,int len)
{
	int i;
    int size;
	size = len;
	if(size>Max_Data_Len) size=Max_Data_Len;
	for(i=0;i<size;i++) {
		if(pdata[i]<' ') {
			switch (pdata[i]){
			case '\n':
            case '\r' :
                fprintf(pf,"%c",pdata[i]);
			    break;
			default:
			     fprintf(pf,"\\%03d",pdata[i]);
			}
		}
		else fprintf(pf,"%c",pdata[i]);
	}
	fprintf(pf,"\n");
}

int SaveRecvData(int socket, char FAR *p, int size)
{
FILE *fp;
if(size<0) return size;
fp=fopen(DataFile,"a+");
if(fp!=NULL) {
fprintf(fp,"call recv,  used socket=%d,len:%d\n",socket,size);
PrintData(fp,(BYTE *)p,size);
fclose(fp);
}
return size;
}

void SaveSendData(int socket, char *p, int size)
{
FILE *fp=fopen(DataFile,"a+");
if(fp!=NULL) {
fprintf(fp,"call send, used socket=%d,len:%d\n",socket,size);
PrintData(fp,(BYTE *)p,size);
fclose(fp);
}
}

void SaveRecvfromData(char *addr,int port, char FAR * p, int size)
{
FILE *fp=fopen(DataFile,"a+");
if(fp!=NULL) {
fprintf(fp,"call recvfrom, recvice data from %s port:%d,len:%d\n",addr,port,size);
PrintData(fp,(BYTE *)p,size);
fclose(fp);
}
//��־�ļ�
}

void SaveSendtoData(char *addr,int port, BYTE *p, int size)
{
FILE *fp=fopen(DataFile,"a+");
if(fp!=NULL) {
fprintf(fp,"call sendto, send data to %s port:%d,len:%d\n",addr,port,size);
PrintData(fp,(BYTE *)p,size);
fclose(fp);
}
//��־�ļ�
}

//���������ԭWSOCK32.DLL��ͬ���ĺ�����
//************
BOOL WINAPI DllMain (HANDLE hInst,
					 ULONG ul_reason_for_call,
                     LPVOID lpReserved)
{
SaveRecord("begin");

//װ��ԭ��̬��
if(i==NULL){
i=LoadLibrary("c:\\windows\\system\\wsock32.aaa");
SaveRecord("reload old wsock32.dll");
}
else
return 1;

if(i!=NULL){
//ȡ��ԭͬ��������ַ
a=GetProcAddress(i,"WSAStartup");
WSAStartup1=(int (_stdcall *)(WORD,LPWSADATA))a;

a=GetProcAddress(i,"WSACleanup");
//ȡ��ԭͬ��������ַ
WSACleanup1=(int (_stdcall *)())a;

a=GetProcAddress(i,"htons");
htons1=(u_short (_stdcall *)(u_short))a;

a=GetProcAddress(i,"socket");
socket1=(SOCKET (_stdcall *)(int ,int,int))a;

a=GetProcAddress(i,"WSAAsyncSelect");
WSAAsyncSelect1=(int (_stdcall *)(SOCKET,HWND ,u_int,long ))a;

a=GetProcAddress(i,"setsockopt");
setsockopt1=(int (_stdcall *)(SOCKET ,int ,int ,const char * ,int ))a;

a=GetProcAddress(i,"ioctlsocket");
ioctlsocket1=(int (_stdcall *)(SOCKET ,long ,u_long FAR *))a;

a=GetProcAddress(i,"WSAAsyncGetHostByName");
WSAAsyncGetHostByName1=(HANDLE (_stdcall *)(HWND ,u_int ,const char FAR * , char FAR * ,int ))a;

a=GetProcAddress(i,"closesocket");
closesocket1=(int (_stdcall *)(SOCKET ))a;

a=GetProcAddress(i,"select");
select1=(int (_stdcall *)(int ,fd_set FAR *,fd_set FAR *,fd_set FAR *,const struct timeval FAR *))a;

a=GetProcAddress(i,"NPLoadNameSpaces");
NPLoadNameSpaces1=(int (_stdcall *)(int ,int ,int ))a;


a=GetProcAddress(i,"connect");
connect1=(int (_stdcall *)(SOCKET ,const struct sockaddr *,int ))a;

a=GetProcAddress(i,"closesockinfo");
closesockinfo1=(int (_stdcall *)(int))a;

a=GetProcAddress(i,"WSAGetLastError");
WSAGetLastError1=(int (_stdcall *)())a;

a=GetProcAddress(i,"send");
send1=(int (_stdcall *)(SOCKET ,const char * ,int ,int ))a;

a=GetProcAddress(i,"recv");
recv1=(int (_stdcall *)(SOCKET ,char FAR * ,int ,int ))a;

a=GetProcAddress(i,"__WSAFDIsSet");
__WSAFDIsSet1=(int (_stdcall *)(SOCKET,fd_set FAR *))a;

a=GetProcAddress(i,"inet_addr");
inet_addr1=(unsigned long (_stdcall *)(const char FAR * ))a;

a=GetProcAddress(i,"WsControl");
WsControl1=(int (_stdcall *)(int ,int ,int ,int ,int ,int ))a;

a=GetProcAddress(i,"inet_ntoa");
inet_ntoa1=(char *  (_stdcall *)(struct in_addr))a;

a=GetProcAddress(i,"htonl");
htonl1=(u_long  (_stdcall *)(u_long))a;

a=GetProcAddress(i,"bind");
bind1=(int (_stdcall *)(SOCKET ,const struct sockaddr *,int ))a;

a=GetProcAddress(i,"getsockname");
getsockname1=(int (_stdcall *)(SOCKET ,struct sockaddr *,int * ))a;

a=GetProcAddress(i,"gethostbyname");
gethostbyname1=(struct hostent * (_stdcall *)(const char FAR * ))a;

a=GetProcAddress(i,"ntohs");
ntohs1=(u_short (_stdcall *)(u_short))a;

a=GetProcAddress(i,"getsockopt");
getsockopt1=(int (_stdcall *)(SOCKET ,int ,int ,char * , int *))a;

a=GetProcAddress(i,"gethostname");
gethostname1=(int (_stdcall *)(char FAR *, int))a;

a=GetProcAddress(i,"WSHEnumProtocols");
WSHEnumProtocols1=(int (_stdcall *)(void))a;


a=GetProcAddress(i,"getprotobyname");
getprotobyname1=(getprotobyname0)a;

a=GetProcAddress(i,"accept");
accept1 =(accept0)a;

a=GetProcAddress(i,"shutdown");
shutdown1 =(shutdown0)a;

a=GetProcAddress(i,"getservbyname");
getservbyname1 =(getservbyname0)a;

a=GetProcAddress(i,"getservbyport");
getservbyport1 =(getservbyport0)a;

a=GetProcAddress(i,"getprotobynumber");
getprotobynumber1=(getprotobynumber0)a;

a=GetProcAddress(i,"sendto");
sendto1 =(sendto0)a;

a=GetProcAddress(i,"recvfrom");
recvfrom1 =(recvfrom0)a;

a=GetProcAddress(i,"ntohl");
ntohl1 =(ntohl0)a;

a=GetProcAddress(i,"listen");
listen1=(listen0)a;

a=GetProcAddress(i,"getpeername");
getpeername1 =(getpeername0)a;

}else return 0;

return 1;
}

int PASCAL FAR WSAStartup(WORD wVersionRequired, LPWSADATA lpWSAData)
{
SaveRecord("WSAStartup");
//����־����ȻҲ����������ģ��

return WSAStartup1(wVersionRequired,lpWSAData);
//ִ�������Ĵ���
}

int PASCAL FAR WSACleanup(void)
{
SaveRecord("WSACleanup");
//����־
return WSACleanup1();
//ִ�������Ĵ���
}
u_short PASCAL FAR htons (u_short hostshort)
{
SaveRecord("htons");
return htons1(hostshort);
//ִ�������Ĵ���

}
SOCKET PASCAL FAR socket (int af, int type, int protocol)
{
char disp[64];
SOCKET rc;
rc = socket1(af,type,protocol);
wsprintf(disp,"socket(af:%d,type:%d,proto:%d) rc=%d",af,type,protocol,rc);
SaveRecord(disp);
return rc;
}
int PASCAL FAR WSAAsyncSelect(SOCKET s, HWND hWnd, u_int wMsg,long lEvent)
{
char disp[128];
int rc;
rc = WSAAsyncSelect1(s,hWnd,wMsg,lEvent);
wsprintf(disp,"WSAAsyncSelect(s=%d,hWnd,wMsg=%d,lEvent=%ld),rc=%d",s,wMsg,lEvent,rc);
SaveRecord(disp);
return rc;
}
int PASCAL FAR setsockopt(SOCKET s,int level,int optname,const char * optval,int optlen)
{
SaveRecord("setsockopt");
return setsockopt1(s,level,optname,optval,optlen);
//ִ�������Ĵ���

}
int PASCAL FAR ioctlsocket(SOCKET s, long cmd, u_long FAR *argp)
{
SaveRecord("ioctlsocket");
return ioctlsocket1(s,cmd,argp);
//ִ�������Ĵ���

}
HANDLE PASCAL FAR WSAAsyncGetHostByName(HWND hWnd, u_int wMsg,const char FAR * name, char FAR * buf,int buflen)
{
SaveRecord("WSAAsyncGetHostByName");
return WSAAsyncGetHostByName1(hWnd,wMsg,name,buf,buflen);
//ִ�������Ĵ���

}
int PASCAL FAR select(int nfds, fd_set FAR *readfds, fd_set FAR *writefds,fd_set FAR *exceptfds, const struct timeval FAR *timeout)
{
SaveRecord("select");
return select1(nfds,readfds,writefds,exceptfds,timeout);
//ִ�������Ĵ���

}
int PASCAL FAR closesocket(SOCKET s)
{
SaveRecord("closesocket");
return closesocket1(s);
//ִ�������Ĵ���

}
int PASCAL FAR NPLoadNameSpaces(int p,int q,int r)
{
SaveRecord("NPLoadNameSpaces");
return NPLoadNameSpaces1(p,q,r);
//ִ�������Ĵ���

}
int PASCAL FAR closesockinfo(int p)
{
SaveRecord("closesockinfo");
return closesockinfo1(p);
//ִ�������Ĵ���

}
int PASCAL FAR connect(SOCKET s,const struct sockaddr *name, int namelen)
{
int rc;
sin =(sockaddr_in *)name;
LPCSTR psz=inet_ntoa1(sin->sin_addr);
wsprintf(msg,"connect,ip=%s:%d socket=%d",psz,ntohs1(sin->sin_port),s);
SaveRecord(msg);
rc = connect1(s,name,namelen);
return rc;

//ִ�������Ĵ���

}
int PASCAL FAR WSAGetLastError(void)
{
d=WSAGetLastError1();
sprintf(aa,"WSAGetLastError %d",d);
SaveRecord(aa);
return d;
//ȡ��ԭͬ��������ַ
//ִ�������Ĵ���

}
int PASCAL FAR send(SOCKET s,const char * buf,int len,int flags)
{
int rc;
rc = send1(s,buf,len,flags);
SaveSendData((int)s, (char *)buf, rc);
return rc;

}


int PASCAL FAR recv(SOCKET s, char FAR * buf, int len, int flags)
{

int rc;
SaveRecord("recv() ");
rc = recv1(s,  buf,  len,  flags);
if(rc<0)  return rc;
//SaveRecvData((int)s, buf, rc);
//
//
//   ������SaveRecvData��ʱ������ ��֪�ιʣ�
//   �����������ң�лл��
//
return rc;
}

int PASCAL FAR __WSAFDIsSet(SOCKET p,fd_set FAR *q)
{
SaveRecord("__WSAFDIsSet");
return __WSAFDIsSet1(p,q);
}

unsigned long PASCAL inet_addr(const char FAR * cp)
{
unsigned long rc;
char disp[64];
rc = inet_addr1(cp);
wsprintf(disp,"inet_addr(%s)",cp);
SaveRecord(disp);
return rc;
//ִ�������Ĵ���

}
int PASCAL WsControl(int p,int q,int r,int s,int t,int u)
{
SaveRecord("WsControl");
return WsControl1(p,q,r,s,t,u);
//ȡ��ԭͬ��������ַ
//ִ�������Ĵ���

}
char * PASCAL inet_ntoa (struct in_addr in)
{
SaveRecord("inet_ntoa");
return inet_ntoa1(in);
//ȡ��ԭͬ��������ַ
//ִ�������Ĵ���

}
u_long PASCAL FAR htonl(u_long hostlong)
{
SaveRecord("htonl");
return htonl1(hostlong);
//ȡ��ԭͬ��������ַ
//ִ�������Ĵ���

}
int PASCAL bind(SOCKET s, const struct sockaddr FAR *addr, int namelen)
{
SaveRecord("bind");
return bind1(s,addr,namelen);
//ȡ��ԭͬ��������ַ
//ִ�������Ĵ���

}
int PASCAL getsockname(SOCKET s, struct sockaddr *name,int * namelen)
{
int rc;
char disp[512];
sockaddr_in *sin;
rc = getsockname1(s,name,namelen);
sin =(sockaddr_in *)name;
LPCSTR psz=inet_ntoa1(sin->sin_addr);
wsprintf(disp,"getsockname(addr:%s,port:%d)",psz,ntohs1(sin->sin_port));
SaveRecord(disp);
return rc;
}
struct hostent * PASCAL FAR gethostbyname(const char FAR * name)
{
char disp[512];
PHOSTENT hostinfo;
if((hostinfo = gethostbyname1(name)) != NULL){
LPCSTR ip = inet_ntoa1 (*(struct in_addr *)*hostinfo->h_addr_list);
wsprintf(disp,"gethostbyname(hostname:%s,addr:%s)",name,ip);
}
else
wsprintf(disp,"gethostbyname(hostname:%s)",name);

SaveRecord(disp);
return hostinfo;
}

u_short PASCAL ntohs(u_short netshort)
{
SaveRecord("ntohs");
return ntohs1(netshort);
//ȡ��ԭͬ��������ַ
//ִ�������Ĵ���

}
int PASCAL getsockopt(SOCKET s,int level,int optname,char * optval, int *optlen)
{
SaveRecord("getsockopt");
return getsockopt1(s,level,optname,optval,optlen);
//ȡ��ԭͬ��������ַ
//ִ�������Ĵ���

}

int PASCAL FAR gethostname (char FAR * name, int namelen)
{
int rc;
char disp[256];
rc = gethostname1 (name, namelen);
if(rc==0){
wsprintf(disp,"gethostname(hostname:%s)",name);
SaveRecord(disp);
}else
SaveRecord("gethostname(return error)"); 
return rc; 
}

int PASCAL FAR WSHEnumProtocols()
{
SaveRecord("WSHEnumProtocols");
return WSHEnumProtocols1();
}

SOCKET PASCAL FAR accept (SOCKET s, struct sockaddr FAR *addr,int FAR *addrlen)
{
char disp[64];
SOCKET rc;
sockaddr_in *sin;
rc = accept1(s, addr,addrlen);
sin =(sockaddr_in *)addr;
LPCSTR psz=inet_ntoa1(sin->sin_addr);
wsprintf(disp,"accept,ip=%s:%d socket=%d",psz,ntohs1(sin->sin_port),rc);
SaveRecord(disp);
return rc;
}

int PASCAL FAR getpeername (SOCKET s, struct sockaddr FAR *name,int FAR * namelen)
{
SaveRecord("getpeername");
return getpeername1(s,name,namelen);
}

int PASCAL FAR listen (SOCKET s, int backlog)
{
SaveRecord("listen");
return listen1(s, backlog);
}

u_long PASCAL FAR ntohl (u_long netlong)
{
SaveRecord("ntohl");
return ntohl1 (netlong);
}

int PASCAL FAR recvfrom (SOCKET s, char FAR * buf, int len, int flags,struct sockaddr FAR *from, int FAR * fromlen)
{

int rc;
sockaddr_in *sin;
rc = recvfrom1(s,  buf,  len,  flags, from, fromlen);
sin =(sockaddr_in *)from;
LPCSTR psz=inet_ntoa1(sin->sin_addr);
SaveRecvfromData((char *)psz,ntohs1(sin->sin_port),buf, rc);
return rc;

}

int PASCAL FAR sendto (SOCKET s, const char FAR * buf, int len, int flags,const struct sockaddr FAR *to, int tolen)
{
int rc;
sockaddr_in *sin;
rc = sendto1 (s, buf,  len, flags,to, tolen);
sin =(sockaddr_in *)to;
LPCSTR psz=inet_ntoa1(sin->sin_addr);
SaveSendtoData((char *)psz,ntohs1(sin->sin_port),(unsigned char *)buf, rc);

return rc;
}

int PASCAL FAR shutdown (SOCKET s, int how)
{
SaveRecord("shutdown");
return shutdown1( s, how);
}

struct hostent FAR * PASCAL FAR gethostbyaddr(const char FAR * addr,int len, int type)
{
SaveRecord("gethostbyaddr");
return gethostbyaddr1(addr, len, type);
}

struct protoent FAR * PASCAL FAR getprotobynumber(int proto)
{
SaveRecord("getprotobynumber");
return getprotobynumber1(proto);
}

struct protoent FAR * PASCAL FAR getprotobyname(const char FAR * name)
{
SaveRecord("getprotobyname");
return getprotobyname1(name);
}

struct servent FAR * PASCAL FAR getservbyport(int port, const char FAR * proto)
{
SaveRecord("getservbyport");
return getservbyport1(port,  proto);
}
struct servent FAR * PASCAL FAR getservbyname(const char FAR * name,const char FAR * proto)
{
SaveRecord("getservbyname");
return getservbyname1( name, proto);;
}

HANDLE PASCAL FAR WSAAsyncGetServByName(HWND hWnd, u_int wMsg,const char FAR * name,const char FAR * proto,char FAR * buf, int buflen)
{
SaveRecord("WSAAsyncGetServByName");
return WSAAsyncGetServByName1( hWnd,  wMsg, name, proto, buf,  buflen);
}

HANDLE PASCAL FAR WSAAsyncGetServByPort(HWND hWnd, u_int wMsg, int port,const char FAR * proto, char FAR * buf,int buflen)
{
SaveRecord("WSAAsyncGetServByPort");
return WSAAsyncGetServByPort1( hWnd,  wMsg,  port, proto, buf, buflen);
}

HANDLE PASCAL FAR WSAAsyncGetProtoByName(HWND hWnd, u_int wMsg,const char FAR * name, char FAR * buf,int buflen)
{
SaveRecord("WSAAsyncGetProtoByName");
return WSAAsyncGetProtoByName1(hWnd, wMsg, name,  buf, buflen);
}

HANDLE PASCAL FAR WSAAsyncGetProtoByNumber(HWND hWnd, u_int wMsg,int number, char FAR * buf,int buflen)
{
SaveRecord("WSAAsyncGetProtoByNumber");
return WSAAsyncGetProtoByNumber1( hWnd,  wMsg, number,  buf, buflen);
}

HANDLE PASCAL FAR WSAAsyncGetHostByAddr(HWND hWnd, u_int wMsg,const char FAR * addr, int len, int type,char FAR * buf, int buflen)
{
SaveRecord("WSAAsyncGetHostByAddr");
return WSAAsyncGetHostByAddr1( hWnd,  wMsg, addr, len, type,  buf, buflen);
}
int PASCAL FAR WSACancelAsyncRequest(HANDLE hAsyncTaskHandle)
{
SaveRecord("WSACancelAsyncRequest");
return WSACancelAsyncRequest1(hAsyncTaskHandle);
}

FARPROC PASCAL FAR WSASetBlockingHook(FARPROC lpBlockFunc)
{
SaveRecord("WSASetBlockingHook");
return WSASetBlockingHook1(lpBlockFunc);
}

int PASCAL FAR WSAUnhookBlockingHook(void)
{
SaveRecord("WSAUnhookBlockingHook");
return WSAUnhookBlockingHook1();
}

void PASCAL FAR WSASetLastError(int iError)
{
char disp[64];
wsprintf(disp,"WSASetLastError(%d)",iError);
SaveRecord(disp);
WSASetLastError1(iError);
}

int PASCAL FAR WSACancelBlockingCall(void)
{
SaveRecord("WSACancelBlockingCall");
return WSACancelBlockingCall1();
}

BOOL PASCAL FAR WSAIsBlocking(void)
{
SaveRecord("WSAIsBlocking");
return WSAIsBlocking1();
}

int PASCAL FAR WSARecvEx (SOCKET s, char FAR * buf, int len, int FAR *flags)
{
int rc;
char disp[512];
char tmp[400];
rc = WSARecvEx1 ( s, buf, len, flags);
strncpy(tmp,buf,400);
wsprintf(disp,"WSARecvEx(len=%d,buf:%s)",len,tmp);
SaveRecord(disp);
return rc;
}

BOOL PASCAL FAR TransmitFile (IN SOCKET hSocket,IN HANDLE hFile,IN DWORD nNumberOfBytesToWrite,IN DWORD nNumberOfBytesPerSend,IN LPOVERLAPPED lpOverlapped,IN void *lpTransmitBuffers,IN DWORD dwReserved)
{
SaveRecord("TransmitFile");
return TransmitFile1 ( hSocket, hFile, nNumberOfBytesToWrite, nNumberOfBytesPerSend, lpOverlapped,lpTransmitBuffers, dwReserved);
}

int PASCAL FAR Arecv ()
{
SaveRecord("Arecv");
return Arecv1();
}
int PASCAL FAR Asend ()
{
SaveRecord("Asend");
return Asend1 ();
}
int PASCAL FAR inet_network ()
{
SaveRecord("inet_network");
return inet_network1 ();
}
int PASCAL FAR getnetbyname ()
{
SaveRecord("getnetbyname");
return getnetbyname1 ();
}

int PASCAL FAR rcmd  ()
{
SaveRecord("rcmd ");
return rcmd1  ();
}

int PASCAL FAR rexec ()
{
SaveRecord("rexec");
return rexec1 ();
}
int PASCAL FAR rresvport ()
{
SaveRecord("rresvport");
return rresvport1 ();
}
int PASCAL FAR sethostname ()
{
SaveRecord("sethostname");
return sethostname1 ();
}
int PASCAL FAR dn_expand ()
{
SaveRecord("dn_expand");
return dn_expand1 ();
}
int PASCAL FAR s_perror  ()
{
SaveRecord("s_perror ");
return s_perror1  ();
}
int PASCAL FAR GetAddressByNameA ()
{
SaveRecord(" GetAddressByNameA ");
return GetAddressByNameA1 ();
}

int PASCAL FAR GetAddressByNameW ()
{
SaveRecord("GetAddressByNameW");
return GetAddressByNameW1 ();
}
int PASCAL FAR EnumProtocolsA ()
{
SaveRecord("EnumProtocolsA ");
return EnumProtocolsA1 ();
}
int PASCAL FAR EnumProtocolsW ()
{
SaveRecord("EnumProtocolsW");
return EnumProtocolsW1 ();
}

int PASCAL FAR GetTypeByNameA ()
{
SaveRecord("GetTypeByNameA");
return GetTypeByNameA1 ();
}
int PASCAL FAR GetTypeByNameW ()
{
SaveRecord("GetTypeByNameW ");
return GetTypeByNameW1();
}
int PASCAL FAR GetNameByTypeA ()
{SaveRecord("GetNameByTypeA ");
return GetNameByTypeA1 ();
}
int PASCAL FAR GetNameByTypeW ()
{
SaveRecord("GetNameByTypeW");
return GetNameByTypeW1 ();
}
int PASCAL FAR SetServiceA ()
{
SaveRecord("SetServiceA ");
return SetServiceA1 ();
}
int PASCAL FAR SetServiceW ()
{
SaveRecord("SetServiceW");
return SetServiceW1 ();
}
int PASCAL FAR GetServiceA ()
{
SaveRecord("GetServiceA");
return GetServiceA1 ();
}
int PASCAL FAR GetServiceW ()
{
SaveRecord("GetServiceW ");
return GetServiceW1 ();
}


//BOOL PASCAL FAR AcceptEx (IN SOCKET sListenSocket,IN SOCKET sAcceptSocket,IN PVOID lpOutputBuffer,IN DWORD dwReceiveDataLength,IN DWORD dwLocalAddressLength,IN DWORD dwRemoteAddressLength,OUT LPDWORD lpdwBytesReceived,IN LPOVERLAPPED lpOverlapped){SaveRecord("1");return 0;}
//VOID PASCAL FAR GetAcceptExSockaddrs (IN PVOID lpOutputBuffer,IN DWORD dwReceiveDataLength,IN DWORD dwLocalAddressLength,IN DWORD dwRemoteAddressLength,OUT struct sockaddr **LocalSockaddr,OUT LPINT LocalSockaddrLength,OUT struct sockaddr **RemoteSockaddr,OUT LPINT RemoteSockaddrLength){SaveRecord("1");return 0;}

