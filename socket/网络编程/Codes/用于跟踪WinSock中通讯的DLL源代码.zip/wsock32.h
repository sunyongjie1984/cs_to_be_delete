HMODULE i=NULL;
char aa[1000];
char msg[1000];
sockaddr_in *sin;


FARPROC a;
DWORD d;

int (__stdcall *getsockopt1)(SOCKET ,int ,int ,char * , int * );
u_short (__stdcall *ntohs1)(u_short );
struct hostent *  (__stdcall *gethostbyname1)(const char FAR *  );
int (__stdcall *getsockname1)(SOCKET ,struct sockaddr *,int * );
int (__stdcall *bind1)(SOCKET ,const struct sockaddr *,int );
u_long (__stdcall *htonl1)(u_long);
char * (__stdcall *inet_ntoa1)(struct in_addr);
int (__stdcall *WsControl1)(int ,int ,int ,int ,int ,int );
unsigned long (__stdcall *inet_addr1)(const char FAR * );
int (__stdcall *__WSAFDIsSet1)(SOCKET,fd_set FAR *);
int (__stdcall *WSAGetLastError1)();
int (__stdcall *recv1)(SOCKET ,char FAR * ,int ,int );
int (__stdcall *send1)(SOCKET ,const char * ,int ,int);
int (__stdcall *connect1)(SOCKET,const struct sockaddr *,int);
int (__stdcall *closesockinfo1)(int );
int (__stdcall *NPLoadNameSpaces1)(int ,int ,int );
int (__stdcall *closesocket1)(SOCKET );
int (__stdcall *select1)(int ,fd_set FAR *,fd_set FAR *,fd_set FAR *,const struct timeval FAR * );
HANDLE  (__stdcall *WSAAsyncGetHostByName1)(HWND ,u_int ,const char FAR * , char FAR * ,int );
int (__stdcall *ioctlsocket1)(SOCKET ,long ,u_long FAR *);
int (__stdcall *setsockopt1)(SOCKET ,int ,int ,const char * ,int );
int (__stdcall *WSAAsyncSelect1)(SOCKET,HWND ,u_int,long);
SOCKET (__stdcall *socket1)(int ,int,int);
u_short (__stdcall *htons1)(u_short);
int	(__stdcall *WSAStartup1)(WORD,LPWSADATA);
int	(__stdcall *WSACleanup1)();
int (__stdcall *gethostname1)(char FAR * , int);
int (__stdcall  *WSHEnumProtocols1)();

typedef ( WINAPI  * WAITFORWORK)(int,char **,char **,int *);

typedef struct protoent FAR * (PASCAL FAR * getprotobyname0)(const char FAR * name);
getprotobyname0  getprotobyname1;

typedef SOCKET (PASCAL FAR *accept0)(SOCKET s, struct sockaddr FAR *addr,int FAR *addrlen);
accept0 accept1;

typedef int (PASCAL FAR *getpeername0)(SOCKET s, struct sockaddr FAR *name,int FAR * namelen);
getpeername0 getpeername1;

typedef int (PASCAL FAR *listen0)(SOCKET s, int backlog);
listen0 listen1;

typedef u_long (PASCAL FAR *ntohl0 )(u_long netlong);
ntohl0 ntohl1;

typedef int (PASCAL FAR *recvfrom0) (SOCKET s, char FAR * buf, int len, int flags,struct sockaddr FAR *from, int FAR * fromlen);
recvfrom0 recvfrom1;

typedef int (PASCAL FAR *sendto0) (SOCKET s, const char FAR * buf, int len, int flags,const struct sockaddr FAR *to, int tolen);
sendto0 sendto1;

typedef int (PASCAL FAR *shutdown0) (SOCKET s, int how);
shutdown0 shutdown1;

typedef struct hostent FAR * (PASCAL FAR *gethostbyaddr0)(const char FAR * addr,int len, int type);
gethostbyaddr0 gethostbyaddr1;

typedef struct protoent FAR * (PASCAL FAR *getprotobynumber0)(int proto);
getprotobynumber0 getprotobynumber1;

typedef struct servent FAR * (PASCAL FAR *getservbyport0)(int port, const char FAR * proto);
getservbyport0 getservbyport1;

typedef struct servent FAR * (PASCAL FAR *getservbyname0)(const char FAR * name,const char FAR * proto);
getservbyname0 getservbyname1;


typedef HANDLE (PASCAL FAR *WSAAsyncGetServByName0)(HWND hWnd, u_int wMsg,const char FAR * name,const char FAR * proto,char FAR * buf, int buflen);
WSAAsyncGetServByName0 WSAAsyncGetServByName1;

typedef HANDLE (PASCAL FAR *WSAAsyncGetServByPort0)(HWND hWnd, u_int wMsg, int port,const char FAR * proto, char FAR * buf,int buflen);
WSAAsyncGetServByPort0 WSAAsyncGetServByPort1;

typedef HANDLE (PASCAL FAR *WSAAsyncGetProtoByName0)(HWND hWnd, u_int wMsg,const char FAR * name, char FAR * buf,int buflen);
WSAAsyncGetProtoByName0 WSAAsyncGetProtoByName1;

typedef HANDLE (PASCAL FAR *WSAAsyncGetProtoByNumber0)(HWND hWnd, u_int wMsg,int number, char FAR * buf,int buflen);
WSAAsyncGetProtoByNumber0 WSAAsyncGetProtoByNumber1;

typedef HANDLE (PASCAL FAR *WSAAsyncGetHostByAddr0)(HWND hWnd, u_int wMsg,const char FAR * addr, int len, int type,char FAR * buf, int buflen);
WSAAsyncGetHostByAddr0 WSAAsyncGetHostByAddr1;

typedef int (PASCAL FAR *WSACancelAsyncRequest0)(HANDLE hAsyncTaskHandle);
WSACancelAsyncRequest0 WSACancelAsyncRequest1;

typedef FARPROC (PASCAL FAR *WSASetBlockingHook0)(FARPROC lpBlockFunc);
WSASetBlockingHook0 WSASetBlockingHook1;

typedef int (PASCAL FAR *WSAUnhookBlockingHook0)(void);
WSAUnhookBlockingHook0 WSAUnhookBlockingHook1;

typedef void (PASCAL FAR *WSASetLastError0)(int iError);
WSASetLastError0 WSASetLastError1;

typedef int (PASCAL FAR *WSACancelBlockingCall0)(void);
WSACancelBlockingCall0 WSACancelBlockingCall1;

typedef BOOL (PASCAL FAR *WSAIsBlocking0)(void);
WSAIsBlocking0 WSAIsBlocking1;

typedef int (PASCAL FAR *WSARecvEx0)(SOCKET s, char FAR * buf, int len, int FAR *flags);
WSARecvEx0 WSARecvEx1;

typedef BOOL (PASCAL FAR *TransmitFile0)(IN SOCKET hSocket,IN HANDLE hFile,IN DWORD nNumberOfBytesToWrite,IN DWORD nNumberOfBytesPerSend,IN LPOVERLAPPED lpOverlapped,IN void *lpTransmitBuffers,IN DWORD dwReserved);
TransmitFile0 TransmitFile1;

typedef int (PASCAL FAR *Arecv0) ();
Arecv0 Arecv1;
typedef int (PASCAL FAR *Asend0) ();
Asend0 Asend1;
typedef int (PASCAL FAR *inet_network0 )();
inet_network0 inet_network1;
typedef int (PASCAL FAR *getnetbyname0 )();
getnetbyname0 getnetbyname1;
typedef int (PASCAL FAR *rcmd0  )();
rcmd0 rcmd1;
typedef int (PASCAL FAR *rexec0 )();
rexec0 rexec1;
typedef int (PASCAL FAR *rresvport0 )();
rresvport0 rresvport1;
typedef int (PASCAL FAR *sethostname0 )();
sethostname0 sethostname1;
typedef int (PASCAL FAR *dn_expand0) ();
dn_expand0 dn_expand1;
typedef int (PASCAL FAR *s_perror0 ) ();
s_perror0 s_perror1;
typedef int (PASCAL FAR *GetAddressByNameA0) ();
GetAddressByNameA0 GetAddressByNameA1;
typedef int (PASCAL FAR *GetAddressByNameW0) ();
GetAddressByNameW0 GetAddressByNameW1;
typedef int (PASCAL FAR *EnumProtocolsA0) ();
EnumProtocolsA0 EnumProtocolsA1;
typedef int (PASCAL FAR *EnumProtocolsW0) ();
EnumProtocolsW0 EnumProtocolsW1;
typedef int (PASCAL FAR *GetTypeByNameA0) ();
GetTypeByNameA0 GetTypeByNameA1;
typedef int (PASCAL FAR *GetTypeByNameW0) ();
GetTypeByNameW0 GetTypeByNameW1;
typedef int (PASCAL FAR *GetNameByTypeA0) ();
GetNameByTypeA0 GetNameByTypeA1;
typedef int (PASCAL FAR *GetNameByTypeW0) ();
GetNameByTypeW0 GetNameByTypeW1;
typedef int (PASCAL FAR *SetServiceA0) ();
SetServiceA0 SetServiceA1;
typedef int (PASCAL FAR *SetServiceW0) ();
SetServiceW0 SetServiceW1;
typedef int (PASCAL FAR *GetServiceA0) ();
GetServiceA0 GetServiceA1;
typedef int (PASCAL FAR *GetServiceW0) ();
GetServiceW0 GetServiceW1;

