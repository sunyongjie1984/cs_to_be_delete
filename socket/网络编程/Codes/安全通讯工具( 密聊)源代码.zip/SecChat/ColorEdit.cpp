// ColorEdit.cpp : implementation file
//

#include "stdafx.h"
#include "SecretChat.h"
#include "ColorEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CColorEdit

CColorEdit::CColorEdit()
{
	m_FontColor = RGB(0, 0, 255);			//������ɫ 
	m_backgroundColor = RGB(255, 255, 255);		//������ɫ 
	m_brush.CreateSolidBrush(m_backgroundColor/*������ɫ*/);
}

CColorEdit::~CColorEdit()
{
}


BEGIN_MESSAGE_MAP(CColorEdit, CEdit)
	//{{AFX_MSG_MAP(CColorEdit)
	ON_WM_CTLCOLOR_REFLECT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorEdit message handlers

HBRUSH CColorEdit::CtlColor(CDC* pDC, UINT nCtlColor) 
{
	pDC->SetTextColor(m_FontColor);
	pDC->SetBkColor(m_backgroundColor);
	return (HBRUSH) m_brush.GetSafeHandle();
}

void CColorEdit::SetBkColor(COLORREF crBkgnd)
{
	m_backgroundColor = crBkgnd;
}
	
void CColorEdit::SetTextColor(COLORREF crText)
{
	m_FontColor = crText;
}