// PublicKeyManager.cpp : implementation file
//

#include "stdafx.h"
#include "SecretChat.h"
#include "PublicKeyManager.h"
#include "SecretChatDlg.h"	//��������ͷ�ļ�

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPublicKeyManager dialog


CPublicKeyManager::CPublicKeyManager(CWnd* pParent /*=NULL*/)
	: CDialog(CPublicKeyManager::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPublicKeyManager)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CPublicKeyManager::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPublicKeyManager)
	DDX_Control(pDX, IDC_FRIENDLIST, m_friendList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPublicKeyManager, CDialog)
	//{{AFX_MSG_MAP(CPublicKeyManager)
	ON_BN_CLICKED(IDC_SELECT, OnSelect)
	ON_BN_CLICKED(IDC_ASK, OnAsk)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_EDIT, OnEdit)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_LBN_DBLCLK(IDC_FRIENDLIST, OnDblclkFriendlist)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPublicKeyManager message handlers

void CPublicKeyManager::OnOK() 
{
	// TODO: Add extra validation here
	
	//CDialog::OnOK();
}

void CPublicKeyManager::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	//CDialog::OnCancel();
}

BOOL CPublicKeyManager::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CPublicKeyManager::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CPublicKeyManager::OnSelect() 
{
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();
	CString strFriend;

	//�������ѡ���б�������
	if(m_friendList.GetCurSel() != -1)
	{
		m_friendList.GetText(
			m_friendList.GetCurSel(),
			strFriend);
		AfxGetApp()->WriteProfileString(
					"SecretKeySetup",
					"FriendPublicKey",
					strFriend);
		pSecretChatDlg->m_setupDlg.ShowTabWindow(0);
	}	
	else
	{
		AfxMessageBox("ûѡ��Կ");
	}	
}

void CPublicKeyManager::OnAsk() 
{
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();
	pSecretChatDlg->AskPublicKey();
	pSecretChatDlg->m_setupDlg.PostMessage(WM_COMMAND, IDCANCEL);

}

void CPublicKeyManager::OnAdd() 
{
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();
	CString str = "��Կ�ļ�(*.pk)|*.pk|";
	CFileDialog fileName(
		TRUE,
		0,
		0,
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		str,
		this);
	if ( fileName.DoModal() == 1)
	{				
		CString strNewFileName = pSecretChatDlg->m_appName 
			+ "\\friend\\" 
			+ fileName.GetFileName();

		WIN32_FIND_DATA wfd;
		HANDLE hSearch = ::FindFirstFile(
			strNewFileName,
			&wfd);
		if(hSearch != INVALID_HANDLE_VALUE)
		{
			if(MessageBox(
				"��Կ�ļ��Ѿ����ڡ����� " + strNewFileName + " �ļ���",
				"���ӹ�Կ�ļ�",
				MB_YESNO | MB_ICONQUESTION) == IDNO)
			{
				return;
			}
		}

		::CopyFile(
			fileName.GetPathName(),
			strNewFileName,
			FALSE);	

		pSecretChatDlg->m_setupDlg.ShowTabWindow(0);	//ˢ���б�
		pSecretChatDlg->m_setupDlg.ShowTabWindow(2);	//ˢ���б�
	}	
}

void CPublicKeyManager::OnEdit() 
{
	CSecretKeyEdit secretKeyEditDlg;
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();
	//�������ѡ���б�������
	if(m_friendList.GetCurSel() != -1)
	{
		CString strFriend;
		m_friendList.GetText(
			m_friendList.GetCurSel(),
			strFriend);

		secretKeyEditDlg.m_select = SELECT_PUBLIC;
		if(secretKeyEditDlg.validateSecretKey(
			pSecretChatDlg->m_appName + "\\friend\\" + strFriend) != SELECT_PUBLIC)
		{
			MessageBox(
				"�����û���Կ�ļ�",
				"����",
				MB_ICONINFORMATION);
			return;
		}
		secretKeyEditDlg.DoModal();

	}	
}

void CPublicKeyManager::OnDelete() 
{
	CSecretKeyEdit secretKeyEditDlg;
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();
	//�������ѡ���б�������
	if(m_friendList.GetCurSel() != -1)
	{
		CString strFriend;
		m_friendList.GetText(
			m_friendList.GetCurSel(),
			strFriend);

		if(MessageBox(
			"�Ƿ�ɾ����Կ�ļ� " + strFriend + " ��",
			"ɾ����Կ�ļ�",
			MB_YESNO | MB_ICONQUESTION) == IDNO)
		{
			return;
		}
		::DeleteFile(
			pSecretChatDlg->m_appName 
			+ "\\friend\\"
			+ strFriend);
			
		pSecretChatDlg->m_setupDlg.ShowTabWindow(0);	//ˢ���б�����Ϊ�����б�û���£��ٵ��ȷ���Ͳ��ܱ�����
		pSecretChatDlg->m_setupDlg.ShowTabWindow(2);	//ˢ���б�
	}	
}

void CPublicKeyManager::OnDblclkFriendlist() //˫���б�
{
	OnEdit();	
}
