// ColorComboBox.cpp : implementation file
//

#include "stdafx.h"
#include "ColorComboBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CColorComboBox

CColorComboBox::CColorComboBox()
{
	m_clrText=RGB(0,0,0);
	m_clrBackGround=RGB(255,255,255);
}

CColorComboBox::~CColorComboBox()
{
	if(m_szaryItem.GetSize()>0)
	{
		m_szaryItem.RemoveAll();
	}

	if(m_aryColorBackGround.GetSize()>0)
	{
		m_aryColorBackGround.RemoveAll();
	}

	if(this->m_aryColorText.GetSize()>0)
	{
		m_aryColorText.RemoveAll();
	}
}

BEGIN_MESSAGE_MAP(CColorComboBox, CComboBox)
	//{{AFX_MSG_MAP(CColorComboBox)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorComboBox message handlers

void CColorComboBox::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your code to draw the specified item
	CDC dc;
	dc.Attach(lpDrawItemStruct->hDC);
	CRect rect(&(lpDrawItemStruct->rcItem));
	int nIndex=lpDrawItemStruct->itemID;

	COLORREF clrBackGround;
	if(nIndex==-1)
	{
		clrBackGround=RGB(255,255,255);
	}
	else if(nIndex<=m_aryColorBackGround.GetSize())
	{
		clrBackGround=(COLORREF)m_aryColorBackGround.GetAt(nIndex);
	}
	else
	{
		clrBackGround=
			(COLORREF)m_aryColorBackGround.GetAt(m_aryColorBackGround.GetUpperBound());
	}

	CBrush brhBack(clrBackGround);
	rect.InflateRect(-1,-1);
	dc.FillRect(&rect,&brhBack);

	if(lpDrawItemStruct->itemState&ODS_SELECTED)
	{
		dc.DrawFocusRect(&rect);
	}

	COLORREF clrText;
	if(nIndex==-1)
	{
		clrText=RGB(0,0,0);
	}
	else if(nIndex<=m_aryColorText.GetSize())
	{
		clrText=(COLORREF)m_aryColorText.GetAt(nIndex);
	}
	else
	{
		clrText=
			(COLORREF)m_aryColorText.GetAt(m_aryColorText.GetUpperBound());
	}
	dc.SetBkMode(TRANSPARENT);
	dc.SetTextColor(clrText);
	if(nIndex!=-1)
		dc.DrawText(m_szaryItem.GetAt(nIndex),&rect,DT_SINGLELINE|DT_LEFT|DT_VCENTER);
		
	CBrush brhFrame(RGB(0,0,0));
	dc.FrameRect(rect, &brhFrame);

	dc.Detach();
}

int CColorComboBox::AddString(LPCTSTR lpszString)
{
	m_aryColorBackGround.Add((COLORREF)m_clrBackGround);
	m_aryColorText.Add((COLORREF)m_clrText);
	m_szaryItem.Add(lpszString);
	int iResult=CComboBox::AddString("");

	return iResult;
}

void CColorComboBox::SetTextColor(COLORREF clrText)
{
	m_clrText=clrText;
}

void CColorComboBox::SetBckGndColor(COLORREF clrBckGnd)
{
	m_clrBackGround=clrBckGnd;
}
