// SecretKeySetup.cpp : implementation file
//

#include "stdafx.h"
#include "secretchat.h"
#include "SecretKeySetup.h"
#include "SecretChatDlg.h"	//��������ͷ�ļ�

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSecretKeySetup dialog


CSecretKeySetup::CSecretKeySetup(CWnd* pParent /*=NULL*/)
	: CDialog(CSecretKeySetup::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSecretKeySetup)
	m_friendIndex = -1;
	m_userIndex = -1;
	//}}AFX_DATA_INIT
}


void CSecretKeySetup::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSecretKeySetup)
	DDX_Control(pDX, IDC_FRIENDPUBLICKEY, m_friendPublicKey);
	DDX_Control(pDX, IDC_USERPRIVATEKEY, m_userPrivateKey);
	DDX_CBIndex(pDX, IDC_FRIENDPUBLICKEY, m_friendIndex);
	DDX_CBIndex(pDX, IDC_USERPRIVATEKEY, m_userIndex);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSecretKeySetup, CDialog)
	//{{AFX_MSG_MAP(CSecretKeySetup)
	ON_BN_CLICKED(IDC_PRIVATEMANAGER, OnPrivatemanager)
	ON_BN_CLICKED(IDC_PUBLICKEYMANAGER, OnPublickeymanager)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSecretKeySetup message handlers

void CSecretKeySetup::OnOK() 
{
	// TODO: Add extra validation here
	
	//CDialog::OnOK();
}

void CSecretKeySetup::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	//CDialog::OnCancel();
}

BOOL CSecretKeySetup::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CString str = "˽Կ������";
	m_privateManager.SubclassDlgItem(IDC_PRIVATEMANAGER, this);
	m_privateManager.SetActiveFgColor(RGB(255, 255, 255));
	m_privateManager.SetTooltipText(&str);
	m_privateManager.SetBtnCursor(IDC_HAND);

	str = "��Կ������";
	m_publickeyManager.SubclassDlgItem(IDC_PUBLICKEYMANAGER, this);
	m_publickeyManager.SetActiveFgColor(RGB(255, 255, 255));
	m_publickeyManager.SetTooltipText(&str);
	m_publickeyManager.SetBtnCursor(IDC_HAND);


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CSecretKeySetup::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::PreTranslateMessage(pMsg);
}


void CSecretKeySetup::OnPrivatemanager() 
{
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();
	pSecretChatDlg->m_setupDlg.ShowTabWindow(1);

}

void CSecretKeySetup::OnPublickeymanager() 
{
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();	
	pSecretChatDlg->m_setupDlg.ShowTabWindow(2);

}
