#if !defined(AFX_SETUP_H__74D2A6A5_0BB1_4A15_B043_048E256225F8__INCLUDED_)
#define AFX_SETUP_H__74D2A6A5_0BB1_4A15_B043_048E256225F8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Setup.h : header file
//
//����ͷ�ļ�
#include "SecretKeySetup.h"
#include "PrivateManager.h"
#include "PublicKeyManager.h"
#include "General.h"
#include "AboutDlg.h"
#include "SecretKeyEdit.h"

/////////////////////////////////////////////////////////////////////////////
// CSetup dialog

class CSetup : public CDialog
{
// Construction
public:
	void ShowTabWindow(int index);	//��ʾ�Ǹ�ѡ�����
	int m_index;	//�����Ҫ��ʾ�Ǹ�ѡ��Ĵ���
	CSecretKeySetup		m_secretKeySetupDlg;
	CPrivateManager		m_privateManagerDlg;
	CPublicKeyManager	m_publicKeyManagerDlg;
	CGeneral			m_generalDlg;
	CAboutDlg			m_aboutDlg;

	CSetup(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSetup)
	enum { IDD = IDD_SETUP };
	CTabCtrl	m_setupTab;
	CStatic	m_dingWei;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetup)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSetup)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeSetuptab(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETUP_H__74D2A6A5_0BB1_4A15_B043_048E256225F8__INCLUDED_)
