// PrivateManager.cpp : implementation file
//

#include "stdafx.h"
#include "secretchat.h"
#include "PrivateManager.h"
#include "SecretChatDlg.h"	//��������ͷ�ļ�

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPrivateManager dialog


CPrivateManager::CPrivateManager(CWnd* pParent /*=NULL*/)
	: CDialog(CPrivateManager::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPrivateManager)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CPrivateManager::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPrivateManager)
	DDX_Control(pDX, IDC_USERLIST, m_userList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPrivateManager, CDialog)
	//{{AFX_MSG_MAP(CPrivateManager)
	ON_BN_CLICKED(IDC_SELECT, OnSelect)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_CREATE, OnCreate)
	ON_BN_CLICKED(IDC_CREATEPUBLICKEY, OnCreatepublickey)
	ON_BN_CLICKED(IDC_EDIT, OnEdit)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_LBN_DBLCLK(IDC_USERLIST, OnDblclkUserlist)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPrivateManager message handlers


void CPrivateManager::OnOK() 
{
	// TODO: Add extra validation here
	
	//CDialog::OnOK();
}

void CPrivateManager::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	//CDialog::OnCancel();
}

BOOL CPrivateManager::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CPrivateManager::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CPrivateManager::OnSelect() 
{	
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();
	CString strUser;

	//�������ѡ���б�������
	if(m_userList.GetCurSel() != -1)
	{
		m_userList.GetText(
			m_userList.GetCurSel(),
			strUser);
		AfxGetApp()->WriteProfileString(
					"SecretKeySetup",
					"UserPrivateKey",
					strUser);
		pSecretChatDlg->m_setupDlg.ShowTabWindow(0);
	}	
	else
	{
		AfxMessageBox("ûѡ��˽Կ");
	}

	
}

void CPrivateManager::OnAdd() 
{	
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();
	CString str = "˽Կ�ļ�(*.sk)|*.sk|";
	CFileDialog fileName(
		TRUE,
		0,
		0,
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		str,
		this);
	if ( fileName.DoModal() == 1)
	{				
		CString strNewFileName = pSecretChatDlg->m_appName 
			+ "\\user\\" 
			+ fileName.GetFileName();

		WIN32_FIND_DATA wfd;
		HANDLE hSearch = ::FindFirstFile(
			strNewFileName,
			&wfd);
		if(hSearch != INVALID_HANDLE_VALUE)
		{
			if(MessageBox(
				"˽Կ�ļ��Ѿ����ڡ����� " + strNewFileName + " �ļ���",
				"����˽Կ�ļ�",
				MB_YESNO | MB_ICONQUESTION) == IDNO)
			{
				return;
			}
		}

		::CopyFile(
			fileName.GetPathName(),
			strNewFileName,
			FALSE);	

		pSecretChatDlg->m_setupDlg.ShowTabWindow(0);//ˢ����ʾ
		pSecretChatDlg->m_setupDlg.ShowTabWindow(1);	//ˢ���б�
	}

}

void CPrivateManager::OnCreate() 
{	
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();

	CSecretKeyEdit secretKeyEditDlg;
	secretKeyEditDlg.m_select = SELECT_CREATE;
	secretKeyEditDlg.DoModal();

	pSecretChatDlg->m_setupDlg.ShowTabWindow(0);//ˢ����ʾ
	pSecretChatDlg->m_setupDlg.ShowTabWindow(1);//ˢ����ʾ
	
}

void CPrivateManager::OnCreatepublickey() 
{	
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();
	CSecretKeyEdit secretKeyEditDlg;

	//�������ѡ���б�������
	if(m_userList.GetCurSel() != -1)
	{
		CString strUser;
		m_userList.GetText(
			m_userList.GetCurSel(),
			strUser);

		if(secretKeyEditDlg.validateSecretKey(
			pSecretChatDlg->m_appName + "\\user\\" + strUser) != 1)
		{
			MessageBox(
				strUser + " ����˽Կ�ļ�",
				"����",
				MB_ICONEXCLAMATION);
			return;
		}
		if(secretKeyEditDlg.CreatePublicKey(
			pSecretChatDlg->m_appName + "\\user\\" + strUser))
		{
			strUser.SetAt(
				strUser.GetLength() - 2,
				'p');
			MessageBox(
				"�Ѿ����ɹ�Կ�ļ� " + strUser,
				"����",
				MB_ICONINFORMATION);
		}

	}
}

void CPrivateManager::OnEdit() 
{
	CSecretKeyEdit secretKeyEditDlg;
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();
	//�������ѡ���б�������
	if(m_userList.GetCurSel() != -1)
	{
		CString strUser;
		m_userList.GetText(
			m_userList.GetCurSel(),
			strUser);

		secretKeyEditDlg.m_select = SECRETKEY_PRIVATE;
		if(secretKeyEditDlg.validateSecretKey(
			pSecretChatDlg->m_appName + "\\user\\" + strUser) != SECRETKEY_PRIVATE)
		{
			MessageBox(
				"�����û�˽Կ�ļ�",
				"����",
				MB_ICONINFORMATION);
			return;
		}
		secretKeyEditDlg.DoModal();

	}	
}

void CPrivateManager::OnDelete() 
{
	CSecretKeyEdit secretKeyEditDlg;
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();
	//�������ѡ���б�������
	if(m_userList.GetCurSel() != -1)
	{
		CString strUser, strFriend;
		m_userList.GetText(
			m_userList.GetCurSel(),
			strUser);
		strFriend = strUser;
		strFriend.SetAt(
			strFriend.GetLength() - 2,
			'p');

		if(MessageBox(
			"�Ƿ�ɾ��˽Կ�ļ� " + strUser + " �����Ĺ�Կ�ļ� " + strFriend + " ��",
			"ɾ��˽Կ�ļ�",
			MB_YESNO | MB_ICONQUESTION) == IDNO)
		{
			return;
		}
		::DeleteFile(
			pSecretChatDlg->m_appName 
			+ "\\user\\"
			+ strUser);	
		::DeleteFile(
			pSecretChatDlg->m_appName 
			+ "\\user\\"
			+ strFriend);	
	
		pSecretChatDlg->m_setupDlg.ShowTabWindow(0);//ˢ����ʾ
		pSecretChatDlg->m_setupDlg.ShowTabWindow(1);	//ˢ���б�
	}	
}

void CPrivateManager::OnDblclkUserlist() //˫���б�
{
	OnEdit();	
}
