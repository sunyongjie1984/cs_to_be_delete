//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SecretChat.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SECRETCHAT_DIALOG           102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDS_JIAMI                       104
#define IDS_HELP                        105
#define IDS_CREATEPUBLICKEYHELP         106
#define IDS_USEHELP                     107
#define IDR_MAINFRAME                   128
#define IDD_PUBLICKEYMANAGER            129
#define IDD_CONNECT                     130
#define IDI_IDIOGRAPH                   132
#define IDI_ENCRYPT                     133
#define IDI_BLUE                        134
#define IDI_GRAY                        135
#define IDI_GREEN                       136
#define IDI_RED                         137
#define IDI_EXIT                        138
#define IDI_CONNECT                     139
#define IDI_DISCONNECTION               140
#define IDI_IP                          141
#define IDI_NOTE                        142
#define IDC_HAND                        143
#define IDR_ONLINE                      149
#define IDD_SECRETKEYSETUP              153
#define IDD_PRIVATEMANAGER              154
#define IDR_MESSAGERECEIVE              159
#define IDR_MESSAGESEND                 160
#define IDR_OFFLINE                     161
#define IDI_SETUP                       162
#define IDD_SECRETKEYEDIT               163
#define IDD_SETUP                       165
#define IDD_GENERAL                     168
#define IDI_JIAMI                       169
#define IDI_OFFLINE                     170
#define IDD_DIALOG1                     172
#define IDR_ICONMENU                    173
#define IDI_SENDFILE                    174
#define IDI_SENDSTOP                    176
#define IDC_IDENTITY                    1000
#define IDC_LIST1                       1001
#define IDC_FRIENDLIST                  1001
#define IDC_ADD                         1002
#define IDC_PUBLICKEYMANAGER            1003
#define IDC_DELETE                      1004
#define IDC_MESSAGENOTE                 1005
#define IDC_GETIP                       1006
#define IDC_MESSAGE                     1007
#define IDC_SEND                        1008
#define IDC_EDIT                        1009
#define IDC_STATUSMESSAGES              1010
#define IDC_CREATE                      1010
#define IDC_NOTE                        1011
#define IDC_CREATEPUBLICKEY             1011
#define IDC_CONNECT                     1012
#define IDC_CONNECT_DISCONNECTION       1012
#define IDC_IP                          1013
#define IDC_DISCONNECTION               1014
#define IDC_EXIT                        1015
#define IDC_JIAMI                       1016
#define IDC_SETUP                       1016
#define IDC_BUTTON1                     1018
#define IDC_SELECT                      1018
#define IDC_PRIVATEMANAGER              1018
#define IDC_SENDFILE                    1018
#define IDC_USERLIST                    1019
#define IDC_USERPRIVATEKEY              1020
#define IDC_FRIENDPUBLICKEY             1022
#define IDC_HOMEPAGELINK                1024
#define IDC_EMAILLINK                   1025
#define IDC_USERNAME                    1026
#define IDC_SECRETKEYSTATIC             1028
#define IDC_SECRETKEY                   1029
#define IDC_QQ                          1030
#define IDC_SETUPTAB                    1030
#define IDC_EMAIL                       1031
#define IDC_DINGWEI                     1031
#define IDC_ASK                         1032
#define IDC_BUTTON3                     1034
#define IDC_RETURN                      1037
#define IDC_TRAY                        1038
#define IDC_TOP                         1039
#define IDC_ARRIVESOUND                 1040
#define IDC_ARRIVESHOW                  1041
#define IDC_USER                        1042
#define IDC_FRIENDNAME                  1043
#define IDC_LANSTARTUP                  1044
#define IDC_STARTUP                     1045
#define IDC_LANIP                       1047
#define IDC_PROGRESS1                   1048
#define IDC_SENDFILEPROGRESS            1048
#define ID_EXIT                         32771
#define ID_EMAIL                        32772
#define ID_HOMEPAGE                     32773
#define ID_SHOW                         32774
#define ID_HIDE                         32775
#define ID_TOP                          32776
#define ID_JIAMI                        32779
#define ID_ABOUT                        32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        177
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
