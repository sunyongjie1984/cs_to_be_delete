#if !defined(AFX_SECRETKEYSETUP_H__50D7E04C_7C84_4CF7_B3DD_EB7670E0A306__INCLUDED_)
#define AFX_SECRETKEYSETUP_H__50D7E04C_7C84_4CF7_B3DD_EB7670E0A306__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SecretKeySetup.h : header file
//

#include "BtnST.h"	// Added by ClassView

/////////////////////////////////////////////////////////////////////////////
// CSecretKeySetup dialog

class CSecretKeySetup : public CDialog
{
// Construction
public:
	CSecretKeySetup(CWnd* pParent = NULL);   // standard constructor

	CButtonST m_privateManager;
	CButtonST m_publickeyManager;
// Dialog Data
	//{{AFX_DATA(CSecretKeySetup)
	enum { IDD = IDD_SECRETKEYSETUP };
	CComboBox	m_friendPublicKey;
	CComboBox	m_userPrivateKey;
	int		m_friendIndex;
	int		m_userIndex;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSecretKeySetup)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSecretKeySetup)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnPrivatemanager();
	afx_msg void OnPublickeymanager();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SECRETKEYSETUP_H__50D7E04C_7C84_4CF7_B3DD_EB7670E0A306__INCLUDED_)
