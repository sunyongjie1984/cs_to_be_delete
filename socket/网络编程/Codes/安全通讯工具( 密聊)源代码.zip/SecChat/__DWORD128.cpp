// __DWORD128.cpp: implementation of the __DWORD128 class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SecretChat.h"
#include "__DWORD128.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

__DWORD128::__DWORD128()
{
	srand((unsigned)::GetTickCount());
	char *y;// = new char[16];
	y = (char *)a;
	for(int i = 0;i < 16;i++)
	{
		y[i] = (char)(0x41+rand()%0xAF);
	}

}

__DWORD128::__DWORD(DWORD x, DWORD y, DWORD z, DWORD w)
{
	a[0] = x;
	a[1] = y;
	a[2] = z;
	a[3] = w;
}

__DWORD128::__DWORD(DWORD *x)
{
	a[0] = x[0];
	a[1] = x[1];
	a[2] = x[2];
	a[3] = x[3];

}

__DWORD128::~__DWORD128()
{
}

void __DWORD128::DigitalID()//���Լ�������ֱ�ʶ������һ���̶�����
{
	a[0] = 0x01234567;
	a[1] = 0x89abcdef;
	a[2] = 0xfedcba98;
	a[3] = 0x76543210;
}

long __DWORD128::IsDigitalID()
{
	if(a[0] != 0x01234567)
	{
		return 0;
	}
	if(a[1] != 0x89abcdef)
	{
		return 0;
	}
	if(a[2] != 0xfedcba98)
	{
		return 0;
	}
	if(a[3] != 0x76543210)
	{
		return 0;
	}

	return 1;
}

void __DWORD128::RandCount()	//���Լ����һ�������
{
	srand((unsigned)::GetTickCount());
	char *y;// = new char[16];
	y = (char *)a;
	for(int i = 0;i < 16;i++)
	{
		y[i] = (char)(0x41+rand()%0xAF);
	}
}

void __DWORD128::Nil()			//���Լ������
{
	a[0] = 0X00000000;
	a[1] = 0X00000000;
	a[2] = 0X00000000;
	a[3] = 0X00000000;
}

void __DWORD128::Load(DWORD *x)//��DWORD���鸳ֵ��__DWORD128����
{
	a[0] = x[0];
	a[1] = x[1];
	a[2] = x[2];
	a[3] = x[3];
}

void __DWORD128::Store(DWORD *x)//��__DWORD128���͸�ֵ��DWORD����
{
	x[0] = a[0];
	x[1] = a[1];
	x[2] = a[2];
	x[3] = a[3];
}

void __DWORD128::operator =(__DWORD128 &x)
{
	a[0] = x.a[0];
	a[1] = x.a[1];
	a[2] = x.a[2];
	a[3] = x.a[3];
}

void __DWORD128::operator %(__DWORD128 &x)
{
	__DWORD128 z;
	z = x;
	x = *this;
	*this = z;
}

long __DWORD128::operator ==(__DWORD128 &x)
{
	if(a[3] != x.a[3]) return FALSE;
	if(a[2] != x.a[2]) return FALSE;
	if(a[1] != x.a[1]) return FALSE;
	if(a[0] != x.a[0]) return FALSE;

	return TRUE;
}

long __DWORD128::operator <(__DWORD128 &x)
{
	if(x.a[3] < a[3]) return FALSE;
	if(x.a[2] < a[2]) return FALSE;
	if(x.a[1] < a[1]) return FALSE;
	if(x.a[0] <= a[0]) return FALSE;

	return TRUE;
}

long __DWORD128::operator >(__DWORD128 &x)
{
	if(x.a[3] > a[3]) return TRUE;
	if(x.a[2] > a[2]) return TRUE;
	if(x.a[1] > a[1]) return TRUE;
	if(x.a[0] > a[0]) return TRUE;

	return FALSE;
}

__DWORD128 addition;	//Ϊʲôaddition������operator ^�ﶨ���أ���Ϊ�ڷ�������ֲ�����ǰ�ᱻע��
__DWORD128& __DWORD128::operator ^(__DWORD128 &x)
{
	addition.a[0] = x.a[0] ^ a[0];
	addition.a[1] = x.a[1] ^ a[1];
	addition.a[2] = x.a[2] ^ a[2];
	addition.a[3] = x.a[3] ^ a[3];

	return addition;
}

__DWORD128 addition2;
__DWORD128& __DWORD128::operator +(__DWORD128 &x)
{
	addition2.a[0] = x.a[0] + a[0];
	addition2.a[1] = x.a[1] + a[1];
	addition2.a[2] = x.a[2] + a[2];
	addition2.a[3] = x.a[3] + a[3];

	return addition2;
}