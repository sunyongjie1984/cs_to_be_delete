#if !defined(AFX_PUBLICKEYMANAGER_H__A409E4D3_0E24_435A_AC76_605D3E5A40BD__INCLUDED_)
#define AFX_PUBLICKEYMANAGER_H__A409E4D3_0E24_435A_AC76_605D3E5A40BD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PublicKeyManager.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CPublicKeyManager dialog

class CPublicKeyManager : public CDialog
{
// Construction
public:
	CPublicKeyManager(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPublicKeyManager)
	enum { IDD = IDD_PUBLICKEYMANAGER };
	CListBox	m_friendList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPublicKeyManager)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPublicKeyManager)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelect();
	afx_msg void OnAsk();
	afx_msg void OnAdd();
	afx_msg void OnEdit();
	afx_msg void OnDelete();
	afx_msg void OnDblclkFriendlist();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PUBLICKEYMANAGER_H__A409E4D3_0E24_435A_AC76_605D3E5A40BD__INCLUDED_)
