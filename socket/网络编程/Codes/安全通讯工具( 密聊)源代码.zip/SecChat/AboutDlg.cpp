// AboutDlg.cpp: implementation of the CAboutDlg class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "secretchat.h"
#include "AboutDlg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_HOMEPAGELINK, m_HomePageLink);
	DDX_Control(pDX, IDC_EMAILLINK, m_EMailLink);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


void CAboutDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	//CDialog::OnOK();
}

void CAboutDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	//CDialog::OnCancel();
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// Set HyperLink for E-Mail
	m_EMailLink.SetURL("mailto:webmaster@wjmshome.com");	//��ϵ��email��ַ
	m_EMailLink.SetUnderline(FALSE);	//û���»���
	m_EMailLink.SetLinkCursor(AfxGetApp()->LoadCursor(IDC_HAND));

	// Set HyperLink for Home Page
	m_HomePageLink.SetURL("http://www.wjmshome.com");
	m_HomePageLink.SetUnderline(FALSE);
	m_HomePageLink.SetLinkCursor(AfxGetApp()->LoadCursor(IDC_HAND));

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
/////////////////////////////////////////////////////////////////////////////
