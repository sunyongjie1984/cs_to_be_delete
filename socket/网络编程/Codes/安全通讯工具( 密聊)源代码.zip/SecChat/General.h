#if !defined(AFX_GENERAL_H__9047E9CF_F373_4BEE_9DEB_C31818E624EC__INCLUDED_)
#define AFX_GENERAL_H__9047E9CF_F373_4BEE_9DEB_C31818E624EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// General.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGeneral dialog

class CGeneral : public CDialog
{
// Construction
public:
	CGeneral(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGeneral)
	enum { IDD = IDD_GENERAL };
	CButton	m_trayButton;
	CButton	m_LANStartupButton;
	CButton	m_startupButton;
	CIPAddressCtrl	m_LANIP;
	BOOL	m_top;
	BOOL	m_tray;
	BOOL	m_arriveShow;
	BOOL	m_arriveSound;
	BOOL	m_LANStartup;
	BOOL	m_startup;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGeneral)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CGeneral)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnLanstartup();
	afx_msg void OnStartup();
	afx_msg void OnTray();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GENERAL_H__9047E9CF_F373_4BEE_9DEB_C31818E624EC__INCLUDED_)
