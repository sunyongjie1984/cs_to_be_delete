// General.cpp : implementation file
//

#include "stdafx.h"
#include "secretchat.h"
#include "General.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGeneral dialog


CGeneral::CGeneral(CWnd* pParent /*=NULL*/)
	: CDialog(CGeneral::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGeneral)
	m_top = FALSE;
	m_tray = FALSE;
	m_arriveShow = FALSE;
	m_arriveSound = FALSE;
	m_LANStartup = FALSE;
	m_startup = FALSE;
	//}}AFX_DATA_INIT
}


void CGeneral::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGeneral)
	DDX_Control(pDX, IDC_TRAY, m_trayButton);
	DDX_Control(pDX, IDC_LANSTARTUP, m_LANStartupButton);
	DDX_Control(pDX, IDC_STARTUP, m_startupButton);
	DDX_Control(pDX, IDC_LANIP, m_LANIP);
	DDX_Check(pDX, IDC_TOP, m_top);
	DDX_Check(pDX, IDC_TRAY, m_tray);
	DDX_Check(pDX, IDC_ARRIVESHOW, m_arriveShow);
	DDX_Check(pDX, IDC_ARRIVESOUND, m_arriveSound);
	DDX_Check(pDX, IDC_LANSTARTUP, m_LANStartup);
	DDX_Check(pDX, IDC_STARTUP, m_startup);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGeneral, CDialog)
	//{{AFX_MSG_MAP(CGeneral)
	ON_BN_CLICKED(IDC_LANSTARTUP, OnLanstartup)
	ON_BN_CLICKED(IDC_STARTUP, OnStartup)
	ON_BN_CLICKED(IDC_TRAY, OnTray)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGeneral message handlers

void CGeneral::OnOK() 
{
	// TODO: Add extra validation here
	
	//CDialog::OnOK();
}

void CGeneral::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	//CDialog::OnCancel();
}

BOOL CGeneral::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_arriveSound = 
		AfxGetApp()->GetProfileInt("General", "ArriveSound", 1);
	m_arriveShow = 
		AfxGetApp()->GetProfileInt("General", "ArriveShow", 0);
	m_top =
		AfxGetApp()->GetProfileInt("General", "Top", 0);
	m_tray = 
		AfxGetApp()->GetProfileInt("General", "Tray", 1);

	m_LANStartup = 
		AfxGetApp()->GetProfileInt("General", "LANStartup", 0);
	m_startup = 
		AfxGetApp()->GetProfileInt("General", "Startup", 0);
	if(!m_LANStartup)
	{
		m_startupButton.EnableWindow(FALSE);
	}
    CString  strIP;
	BYTE  b1,b2,b3,b4;
//	int	  n1,n2,n3,n4;
	strIP =
		AfxGetApp()->GetProfileString("General", "LANIP", "192.168.0.1");

	_stscanf(/*���ְ����ò�����ֻ����m_LANIP.SetWindowText�˻����һ���������*/
		strIP,
		"%d.%d.%d.%d",
		&b1, &b2, &b3, &b4);	//���ַ�ת��������
//	_stscanf(/*���ְ����ò�����ֻ����m_LANIP.SetWindowText�˻����һ���������*/
//		strIP,
//		"%i.%i.%i.%i",
//		&n1, &n2, &n3, &n4);	//���ַ�ת��������
//	strIP.Format("%d%d%d%d",b1,b2,b3,b4);	AfxMessageBox(strIP);
	m_LANIP.SetAddress(b1, b2, b3, b4);	//����IP
	m_LANIP.SetWindowText(strIP);
//	m_LANIP.SetAddress(n1, n2, n3, n4);	//����IP
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CGeneral::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CGeneral::OnLanstartup() 
{
	if(m_LANStartupButton.GetCheck())
	{
		m_startupButton.EnableWindow();
	}
	else
	{
		m_startupButton.SetCheck(FALSE);
		m_startupButton.EnableWindow(FALSE);
	}
}

void CGeneral::OnStartup() 
{
	if(m_startupButton.GetCheck())
	{
		m_trayButton.SetCheck(TRUE);
	}
	
}

void CGeneral::OnTray() 
{
	if(m_startupButton.GetCheck())
	{
		m_trayButton.SetCheck(TRUE);
	}	
}
