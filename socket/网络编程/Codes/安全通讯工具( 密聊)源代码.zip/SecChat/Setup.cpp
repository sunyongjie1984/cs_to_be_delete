// Setup.cpp : implementation file
//

#include "stdafx.h"
#include "secretchat.h"
#include "Setup.h"
#include "SecretChatDlg.h"	//��������ͷ�ļ�

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetup dialog


CSetup::CSetup(CWnd* pParent /*=NULL*/)
	: CDialog(CSetup::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetup)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSetup::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetup)
	DDX_Control(pDX, IDC_SETUPTAB, m_setupTab);
	DDX_Control(pDX, IDC_DINGWEI, m_dingWei);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSetup, CDialog)
	//{{AFX_MSG_MAP(CSetup)
	ON_NOTIFY(TCN_SELCHANGE, IDC_SETUPTAB, OnSelchangeSetuptab)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetup message handlers

void CSetup::OnOK() 
{
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();
	CWaitCursor WaitCursor;	//�ȴ����

	if( !m_secretKeySetupDlg.UpdateData()) return;
	if( !m_privateManagerDlg.UpdateData()) return;
	if( !m_publicKeyManagerDlg.UpdateData()) return;
	if( !m_generalDlg.UpdateData()) return;
	
	//������Կ����ѡ��
	CString strUser, strFriend;
	if(m_secretKeySetupDlg.m_userIndex == -1)
	{
		MessageBox(
			"û��ѡ���û�˽Կ",
			"����",
			MB_ICONINFORMATION);
	}
	else
	{
		m_secretKeySetupDlg.m_userPrivateKey.GetLBText(
			m_secretKeySetupDlg.m_userIndex,
			strUser);
		AfxGetApp()->WriteProfileString(
			"SecretKeySetup",
			"UserPrivateKey",
			strUser);
	}
	if(m_secretKeySetupDlg.m_friendIndex == -1)
	{
		MessageBox(
			"û��ѡ����ѹ�Կ",
			"����",
			MB_ICONINFORMATION);
	}
	else
	{
		m_secretKeySetupDlg.m_friendPublicKey.GetLBText(
			m_secretKeySetupDlg.m_friendIndex,
			strFriend);
		AfxGetApp()->WriteProfileString(
			"SecretKeySetup",
			"FriendPublicKey",
			strFriend);
	}

	//���ó���ѡ��
	AfxGetApp()->WriteProfileInt("General", "ArriveSound", m_generalDlg.m_arriveSound);
	AfxGetApp()->WriteProfileInt("General", "ArriveShow", m_generalDlg.m_arriveShow);
	AfxGetApp()->WriteProfileInt("General", "Top", m_generalDlg.m_top);
	AfxGetApp()->WriteProfileInt("General", "Tray", m_generalDlg.m_tray);

	AfxGetApp()->WriteProfileInt("General", "LANStartup", m_generalDlg.m_LANStartup);
    CString  strIP;
	BYTE  b1,b2,b3,b4;
    m_generalDlg.m_LANIP.GetAddress(b1,b2,b3,b4);	//���IP
	m_generalDlg.m_LANIP.GetWindowText(strIP);	//���IP
	//AfxMessageBox(strIP);
 //   strIP.Format(
//		"%d.%d.%d.%d",
//		b1,b2,b3,b4);	//������ת�����ַ�
	AfxGetApp()->WriteProfileString("General", "LANIP", strIP);

	AfxGetApp()->WriteProfileInt("General", "Startup", m_generalDlg.m_startup);
	//����ʱ�Ƿ��Զ�����
	HKEY hkey;	//�����
	if(m_generalDlg.m_startup)
	{
		//����
		::RegOpenKeyEx(
			HKEY_LOCAL_MACHINE/*����*/,
			"SOFTWARE\\MICROSOFT\\WINDOWS\\CURRENTVERSION\\RUN"/*�Ӽ�*/,
			NULL,
			KEY_ALL_ACCESS,
			&hkey); 
		::RegSetValueEx(
			hkey,
			"SecretChat"/*��ֵ*/,
			0,
			REG_SZ,
			(LPBYTE)__argv[0]/*��ֵ������*/,
			256);	//��sz������д�뵽���±���ֵ
		::RegCloseKey(hkey);	//�ر�
	}
	else
	{
		//�ر�
		::RegOpenKeyEx( 
			HKEY_LOCAL_MACHINE,
			"SOFTWARE\\MICROSOFT\\WINDOWS\\CURRENTVERSION\\RUN",
			NULL,
			KEY_ALL_ACCESS,
			&hkey);
		::RegDeleteValue( 
			hkey,
			"SecretChat"/*��ֵ*/);	//ɾ����ֵ
		::RegCloseKey(hkey);
	}

	////����ע������ݽ�������
	pSecretChatDlg->MyUpdateData();


	CDialog::OnOK();
}

void CSetup::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

BOOL CSetup::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	//����ѡ�
    TC_ITEM tItem;
    tItem.mask = TCIF_TEXT;
    tItem.pszText = "��Կ����";
    tItem.cchTextMax = strlen( tItem.pszText);     
    m_setupTab.InsertItem( 0, &tItem);	//����ѡ��
 
	tItem.pszText="˽Կ����";
	tItem.cchTextMax = strlen( tItem.pszText);
    m_setupTab.InsertItem( 1, &tItem);	//����ѡ��

	tItem.pszText="��Կ����";
	tItem.cchTextMax = strlen( tItem.pszText);
    m_setupTab.InsertItem( 2, &tItem);	//����ѡ��

	tItem.pszText="����";
	tItem.cchTextMax = strlen( tItem.pszText);
    m_setupTab.InsertItem( 3, &tItem);	//����ѡ��

	tItem.pszText="����";
	tItem.cchTextMax = strlen( tItem.pszText);
    m_setupTab.InsertItem( 4, &tItem);	//����ѡ��

	CRect rect;
	m_dingWei.GetWindowRect( &rect);
	ScreenToClient( &rect);

	m_secretKeySetupDlg.Create(IDD_SECRETKEYSETUP,this);
	m_privateManagerDlg.Create(IDD_PRIVATEMANAGER,this);
	m_publicKeyManagerDlg.Create(IDD_PUBLICKEYMANAGER,this);
	m_generalDlg.Create(IDD_GENERAL,this);
	m_aboutDlg.Create(IDD_ABOUTBOX,this);

	m_secretKeySetupDlg.MoveWindow( &rect);
	m_privateManagerDlg.MoveWindow( &rect);
	m_publicKeyManagerDlg.MoveWindow( &rect);
	m_generalDlg.MoveWindow( &rect);
	m_aboutDlg.MoveWindow( &rect);

	ShowTabWindow(0);	//���������б�
	ShowTabWindow(m_index);	//ÿ����ʾǰ��Ҫ����m_index��ֵ

	//��û��˽Կʱ��ʾ����


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSetup::OnSelchangeSetuptab(NMHDR* pNMHDR, LRESULT* pResult) 
{
	ShowTabWindow( m_setupTab.GetCurSel() );

	*pResult = 0;
}

void CSetup::ShowTabWindow(int index)	
{
	CSecretChatDlg * pSecretChatDlg = (CSecretChatDlg *)AfxGetMainWnd();
	switch(index)
	{	
	case 0: 
		m_secretKeySetupDlg.ShowWindow( SW_SHOW);
		m_privateManagerDlg.ShowWindow( SW_HIDE);
		m_publicKeyManagerDlg.ShowWindow( SW_HIDE);
		m_generalDlg.ShowWindow( SW_HIDE);
		m_aboutDlg.ShowWindow( SW_HIDE);
		//���ô���ͼ��
		SetIcon(AfxGetApp()->LoadIcon(IDI_IDIOGRAPH), FALSE);

		/*ɾ�������б��е������ַ�*/
		m_secretKeySetupDlg.m_userPrivateKey.ResetContent();
		//����ָ��Ŀ¼���ļ��������б�����ѡ��ָ������
		m_secretKeySetupDlg.m_userPrivateKey.Dir(
			DDL_DIRECTORY, 
			pSecretChatDlg->m_appName + "\\user\\*.sk");
		//m_secretKeySetupDlg.m_userPrivateKey.SetCurSel(0);	//���ֻ��һ�����ѡ��
		m_secretKeySetupDlg.m_userPrivateKey.SelectString(
			-1,
			AfxGetApp()->GetProfileString("SecretKeySetup", "UserPrivateKey"));

		m_secretKeySetupDlg.m_friendPublicKey.ResetContent();
		m_secretKeySetupDlg.m_friendPublicKey.Dir(
			DDL_DIRECTORY, 
			pSecretChatDlg->m_appName + "\\friend\\*.pk");
		m_secretKeySetupDlg.m_friendPublicKey.SelectString(
			-1,
			AfxGetApp()->GetProfileString("SecretKeySetup", "FriendPublicKey"));

		SetWindowText("���� - ��Կ����");
		break;
	case 1:
		m_secretKeySetupDlg.ShowWindow( SW_HIDE);
		m_privateManagerDlg.ShowWindow( SW_SHOW);
		m_publicKeyManagerDlg.ShowWindow( SW_HIDE);
		m_generalDlg.ShowWindow( SW_HIDE);
		m_aboutDlg.ShowWindow( SW_HIDE);
		SetIcon(AfxGetApp()->LoadIcon(IDI_IDIOGRAPH), FALSE);

		//ɾ��ȫ���б�
		m_privateManagerDlg.m_userList.ResetContent();
		//��ָ��Ŀ¼��sk�ļ�ȫ�����ӵ��б�
		m_privateManagerDlg.m_userList.Dir(
			DDL_DIRECTORY, 
			pSecretChatDlg->m_appName + "\\user\\*.sk");
		//ѡ���б��е�ĳ���ַ�
		m_privateManagerDlg.m_userList.SelectString(
			-1,
			AfxGetApp()->GetProfileString("SecretKeySetup", "UserPrivateKey"));

		SetWindowText("���� - ˽Կ����");			
		break;
	case 2:  
		m_secretKeySetupDlg.ShowWindow( SW_HIDE);
		m_privateManagerDlg.ShowWindow( SW_HIDE);
		m_publicKeyManagerDlg.ShowWindow( SW_SHOW);
		m_generalDlg.ShowWindow( SW_HIDE);
		m_aboutDlg.ShowWindow( SW_HIDE);
		SetIcon(AfxGetApp()->LoadIcon(IDI_IDIOGRAPH), FALSE);
		//ɾ��ȫ���б�
		m_publicKeyManagerDlg.m_friendList.ResetContent();
		//��ָ��Ŀ¼��sk�ļ�ȫ�����ӵ��б�
		m_publicKeyManagerDlg.m_friendList.Dir(
			DDL_DIRECTORY, 
			pSecretChatDlg->m_appName + "\\friend\\*.pk");
		//ѡ���б��е�ĳ���ַ�
		m_publicKeyManagerDlg.m_friendList.SelectString(
			-1,
			AfxGetApp()->GetProfileString("SecretKeySetup", "FriendPublicKey"));

		SetWindowText("���� - ��Կ����");
		break;
	case 3:
		m_secretKeySetupDlg.ShowWindow( SW_HIDE);
		m_privateManagerDlg.ShowWindow( SW_HIDE);
		m_publicKeyManagerDlg.ShowWindow( SW_HIDE);
		m_generalDlg.ShowWindow( SW_SHOW);
		m_aboutDlg.ShowWindow( SW_HIDE);
		SetIcon(AfxGetApp()->LoadIcon(IDI_SETUP), FALSE);

		SetWindowText("���� - ����");
		break;
	case 4:
		m_secretKeySetupDlg.ShowWindow( SW_HIDE);
		m_privateManagerDlg.ShowWindow( SW_HIDE);
		m_publicKeyManagerDlg.ShowWindow( SW_HIDE);
		m_generalDlg.ShowWindow( SW_HIDE);
		m_aboutDlg.ShowWindow( SW_SHOW);
		SetIcon(AfxGetApp()->LoadIcon(IDI_SETUP), FALSE);

		SetWindowText("���� - ����");
		break;
	}

	m_setupTab.SetCurSel(index);	//����ѡ�����ʾ����
}
