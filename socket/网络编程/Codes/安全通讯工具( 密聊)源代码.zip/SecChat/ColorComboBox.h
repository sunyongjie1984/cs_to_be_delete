#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ColorComboBox.h : header file
//

#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CColorComboBox window
/*������combo box properties�е�style��������ȷ������
Type(Drop List) Owner draw(Fixed) sortȡ��*/
class CColorComboBox : public CComboBox
{
// Construction
public:
	CColorComboBox();

// Attributes
private:
	CStringArray m_szaryItem;
	COLORREF m_clrText,m_clrBackGround;
	CArray <COLORREF,COLORREF> m_aryColorText;
	CArray <COLORREF,COLORREF> m_aryColorBackGround;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColorComboBox)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetBckGndColor(COLORREF clrBckGnd);
	void SetTextColor(COLORREF clrText);
	int AddString(LPCTSTR lpszString);
	virtual ~CColorComboBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CColorComboBox)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
