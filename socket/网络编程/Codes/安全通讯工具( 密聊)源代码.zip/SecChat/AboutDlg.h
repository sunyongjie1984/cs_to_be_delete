// AboutDlg.h: interface for the CAboutDlg class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ABOUTDLG_H__F3E52C7C_7899_4E43_8127_47A0C04067DE__INCLUDED_)
#define AFX_ABOUTDLG_H__F3E52C7C_7899_4E43_8127_47A0C04067DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "HyperLink.h"	// Added by ClassView

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

private:
// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CHyperLink	m_HomePageLink;
	CHyperLink	m_EMailLink;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_ABOUTDLG_H__F3E52C7C_7899_4E43_8127_47A0C04067DE__INCLUDED_)
