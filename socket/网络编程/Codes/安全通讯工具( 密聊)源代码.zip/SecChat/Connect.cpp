// Connect.cpp : implementation file
//

#include "stdafx.h"
#include "SecretChat.h"
#include "Connect.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConnect dialog
#include "SecretChatDlg.h"

CConnect::CConnect(CWnd* pParent /*=NULL*/)
	: CDialog(CConnect::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConnect)
	m_IP = _T("");
	m_port = LISTEN_PORT;
	//}}AFX_DATA_INIT
}


void CConnect::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConnect)
	DDX_Control(pDX, IDC_IP, m_IPComboBox);
	DDX_CBString(pDX, IDC_IP, m_IP);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConnect, CDialog)
	//{{AFX_MSG_MAP(CConnect)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConnect message handlers

void CConnect::OnOK() 
{
	CDialog::OnOK();
}

void CConnect::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

BOOL CConnect::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_IPComboBox.AddString(
		AfxGetApp()->GetProfileString("Connect", "IPHistory", "127.0.0.1"));
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
