//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by 666.rc
//
#define IDD_MY666_DIALOG                102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_IP                          1000
#define IDC_CONNECT                     1002
#define IDC_COMPUTER                    1003
#define IDC_PASSWORD                    1005
#define IDC_SHARE                       1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
