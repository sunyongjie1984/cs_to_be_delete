// SendEMailDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SendEMail.h"
#include "SendEMailDlg.h"

#include "mapi.h"	//Added by Geng

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSendEMailDlg dialog

CSendEMailDlg::CSendEMailDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSendEMailDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSendEMailDlg)
	m_szEmail = _T("");
	m_szEmailMAPI = _T("");
	m_szSubject = _T("�����������");
	m_szText = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_szDefaultEMail = "webmaster@microsoft.com";
	m_szEmail = m_szDefaultEMail;
	m_szEmailMAPI = m_szDefaultEMail;

}

void CSendEMailDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSendEMailDlg)
	DDX_Control(pDX, IDC_ATTACH, m_list);
	DDX_Text(pDX, IDC_EMAIL, m_szEmail);
	DDX_Text(pDX, IDC_EMAIL2, m_szEmailMAPI);
	DDX_Text(pDX, IDC_SUBJECT, m_szSubject);
	DDX_Text(pDX, IDC_TEXT, m_szText);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSendEMailDlg, CDialog)
	//{{AFX_MSG_MAP(CSendEMailDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SHELLEXECUTE, OnShellExecute)
	ON_BN_CLICKED(IDC_ADD_ATTACH, OnAddAttachment)
	ON_BN_CLICKED(IDC_SEND_MAPI, OnSendMapi)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSendEMailDlg message handlers

BOOL CSendEMailDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	//��ȡ��ǰ·��
	CString szPath("");
	GetModuleFileName(NULL,szPath.GetBuffer(MAX_PATH),MAX_PATH);	
	szPath.ReleaseBuffer();
	szPath = szPath.Left(szPath.ReverseFind('\\') + 1);

	//��readme�ļ��ж�ȡ�ʼ�����������
	CString szFileName = szPath + "\\Readme.txt";
	CFileFind find;
	bool bRet = find.FindFile(szFileName);
	find.Close();
	if(!bRet)
	{
		HRSRC hSrc = FindResource(NULL,MAKEINTRESOURCE(IDR_README),_T("OWNER_DATA"));
		if(hSrc != NULL)
		{
			HGLOBAL hGlobal = LoadResource(NULL,hSrc);
			if(hGlobal != NULL)
			{
				LPVOID lp = LockResource(hGlobal);
				DWORD dwSize = SizeofResource(NULL,hSrc);

				CFile file;
				if(file.Open(szFileName,CFile::modeCreate|CFile::modeWrite))
				{
					file.Write(lp,dwSize);
					file.Close();
				}
				FreeResource(hGlobal);
			}
		}
	}	

	CFile file;
	if(file.Open(szFileName,CFile::modeRead))
	{
		DWORD dwLen = file.GetLength();
		file.Read(m_szText.GetBuffer(dwLen),dwLen);
		file.Close();

		m_szText.ReleaseBuffer();
		UpdateData(false);
	}

	m_list.AddString(szFileName);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSendEMailDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CSendEMailDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSendEMailDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSendEMailDlg::OnShellExecute() 
{
	UpdateData(true);
	
	if(m_szEmail.IsEmpty()) m_szEmail = m_szDefaultEMail;
	m_szEmail = "mailto:" + m_szEmail;

	ShellExecute(NULL,NULL,m_szEmail,NULL,NULL,SW_SHOW);
}

/*********************************************************************
 * ��������:CSendEMailDlg::OnAddAttachment
 * ˵��:  ���Ӹ������б�����
 * ����:  Geng
 * ʱ�� : 2003-04-22 20:25:13 
*********************************************************************/
void CSendEMailDlg::OnAddAttachment() 
{
	CFileDialog dlg(true,NULL,NULL,OFN_ALLOWMULTISELECT);

	if(dlg.DoModal() == IDOK)
	{
		POSITION pos = dlg.GetStartPosition();
		while(pos != NULL)
		{
			m_list.AddString(dlg.GetNextPathName(pos));
		}
	}
}


/*********************************************************************
 * ��������:CSendEMailDlg::OnSendMapi
 * ˵��:  ����MAPI���������ʼ���ժ�� VC98\MFC\SRC\DOCMAPI.CPP
 * ����:  Geng
 * ʱ�� : 2003-04-22 20:08:30 
*********************************************************************/
void CSendEMailDlg::OnSendMapi() 
{
	UpdateData(true);

	//����MAPI32.DLL��̬��
	HMODULE hMod = LoadLibrary("MAPI32.DLL");

	if (hMod == NULL)	//���ض�̬��ʧ��
	{
		AfxMessageBox(AFX_IDP_FAILED_MAPI_LOAD);
		return;
	}

	//��ȡ�����ʼ��ĺ�����ַ
	ULONG (PASCAL *lpfnSendMail)(ULONG, ULONG, MapiMessage*, FLAGS, ULONG);
	(FARPROC&)lpfnSendMail = GetProcAddress(hMod, "MAPISendMail");

	if (lpfnSendMail == NULL)
	{
		AfxMessageBox(AFX_IDP_INVALID_MAPI_DLL);
		return;
	}

	int nFileCount = m_list.GetCount();	//�ж��ٸ�������Ҫ����

	//�����ڴ汣�渽����Ϣ	����ʹ�þ�̬���飬��Ϊ��֪��Ҫ���͸����ĸ���
	MapiFileDesc* pFileDesc = (MapiFileDesc*)malloc(sizeof(MapiFileDesc) * nFileCount);
	memset(pFileDesc,0,sizeof(MapiFileDesc) * nFileCount);

	//�����ڴ汣�渽���ļ�·��
	TCHAR* pTchPath = (TCHAR*)malloc(MAX_PATH * nFileCount);

	CString szText;
	for(int i = 0;i < nFileCount;i++)
	{
		TCHAR* p = pTchPath + MAX_PATH * i;
		m_list.GetText(i,szText);
		strcpy(p,szText);

		(pFileDesc + i)->nPosition = (ULONG)-1;
		(pFileDesc + i)->lpszPathName = p;
		(pFileDesc + i)->lpszFileName = p;
	}

	//�ռ��˽ṹ��Ϣ
	MapiRecipDesc recip;
	memset(&recip,0,sizeof(MapiRecipDesc));
	recip.lpszAddress	= m_szEmailMAPI.GetBuffer(0);
	recip.ulRecipClass = MAPI_TO;

	//�ʼ��ṹ��Ϣ
	MapiMessage message;
	memset(&message, 0, sizeof(message));
	message.nFileCount	= nFileCount;				//�ļ�����
	message.lpFiles		= pFileDesc;				//�ļ���Ϣ
	message.nRecipCount = 1;						//�ռ��˸���
	message.lpRecips 	= &recip;					//�ռ���
	message.lpszSubject	= m_szSubject.GetBuffer(0);	//����
	message.lpszNoteText= m_szText.GetBuffer(0);	//��������

	//���汾���򴰿�ָ�룬��Ϊ�����ʼ���Ҫ���ر�����Ĵ���
	CWnd* pParentWnd = CWnd::GetSafeOwner(NULL, NULL);

	//�����ʼ�
	int nError = lpfnSendMail(0, 0,
					&message, MAPI_LOGON_UI|MAPI_DIALOG, 0);

	if (nError != SUCCESS_SUCCESS && nError != MAPI_USER_ABORT 
			&& nError != MAPI_E_LOGIN_FAILURE)
	{
		AfxMessageBox(AFX_IDP_FAILED_MAPI_SEND);
	}

	//���س���
	pParentWnd->SetActiveWindow();

	//��Ҫ�����ͷŷ�����ڴ�
	free(pFileDesc);
	free(pTchPath);
	FreeLibrary(hMod);
}

void CSendEMailDlg::OnAbout() 
{
	CAboutDlg dlg;
	dlg.DoModal();
}
