// RingOption.cpp : implementation file
//

#include "stdafx.h"
#include "DBtest.h"
#include "RingOption.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRingOption dialog


CRingOption::CRingOption(CWnd* pParent /*=NULL*/)
	: CDialog(CRingOption::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRingOption)
	//}}AFX_DATA_INIT
	 
}


void CRingOption::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRingOption)
	DDX_Control(pDX, IDC_RADIO_RING, m_RadioRing);
	DDX_Control(pDX, IDC_RADIO_RING2, m_RadioTime);
	DDX_Control(pDX, IDC_EDIT_RING, m_EditRing);
	DDX_Control(pDX, IDC_SPIN_TIME, m_SpinTime);
	DDX_Control(pDX, IDC_EDIT_TIME, m_EditTime);
	DDX_Control(pDX, IDC_SPIN_RING, m_SpinRing);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRingOption, CDialog)
	//{{AFX_MSG_MAP(CRingOption)
	ON_BN_CLICKED(IDC_RADIO_RING2, OnRadioRing2)
	ON_BN_CLICKED(IDC_RADIO_RING, OnRadioRing)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRingOption message handlers

 

BOOL CRingOption::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
 	m_RadioRing.SetCheck(TRUE);
    m_RadioTime.SetCheck (FALSE);     //��ʼ����ѡť

	bRingNum=TRUE;
	m_SpinRing.SetBuddy(&m_EditRing);
	m_EditRing.SetWindowText("1");    //���������¿ؼ����û�鼰��ʼ��
	m_SpinRing.SetRange(1,10);
	m_SpinRing.SetPos(1);

	m_SpinTime.SetBuddy(&m_EditTime);
	m_EditTime.SetWindowText("3");   //��ʱ�����¿ؼ����û�鼰��ʼ��Ϊ��Ч
	m_SpinTime.SetRange(1,60);
	m_SpinTime.SetPos(3);
	m_SpinTime.EnableWindow (FALSE);
	m_EditTime.EnableWindow (FALSE);

	iRingCount=1;
	iTimeCount=3; //��ʼ�����������ʱ������

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRingOption::OnRadioRing2() 
{
  m_RadioRing.SetCheck(FALSE); 
  m_SpinRing.EnableWindow(FALSE);
  m_EditRing.EnableWindow (FALSE); //����ѡ������Ϊ��Ч

  m_RadioTime.SetCheck (TRUE);   //ʱ��ѡ������Ϊ��Ч
  m_SpinTime.EnableWindow (TRUE);
  m_EditTime.EnableWindow (TRUE);
  bRingNum=FALSE;

}

void CRingOption::OnRadioRing() 
{
  m_RadioTime.SetCheck (FALSE);   //ʱ��ѡ������Ϊ��Ч
  m_SpinTime.EnableWindow (FALSE);
  m_EditTime.EnableWindow (FALSE);	

  m_RadioRing.SetCheck(TRUE); 
  m_SpinRing.EnableWindow(TRUE);
  m_EditRing.EnableWindow (TRUE); //����ѡ������Ϊ��Ч
  bRingNum=TRUE;
}

void CRingOption::OnClose() 
{
    iRingCount=m_SpinRing.GetPos(); //����ı�ֵ
	iTimeCount=m_SpinTime.GetPos();
	CDialog::OnClose();
}
