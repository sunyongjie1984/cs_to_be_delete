// DBtestSet.cpp : implementation of the CDBtestSet class
//

#include "stdafx.h"
#include "DBtest.h"
#include "DBtestSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBtestSet implementation

IMPLEMENT_DYNAMIC(CDBtestSet, CRecordset)

CDBtestSet::CDBtestSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDBtestSet)
	m_sampleID = 0;
	m_RecordNum = 0;
	m_FileName = _T("");
	m_type = _T("");
	m_memo = _T("");
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}

CString CDBtestSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=ARdemo");
}

CString CDBtestSet::GetDefaultSQL()
{
	return _T("[sample]");
}

void CDBtestSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDBtestSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[sampleID]"), m_sampleID);
	RFX_Long(pFX, _T("[RecordNum]"), m_RecordNum);
	RFX_Text(pFX, _T("[FileName]"), m_FileName);
	RFX_Text(pFX, _T("[type]"), m_type);
	RFX_Text(pFX, _T("[memo]"), m_memo);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDBtestSet diagnostics

#ifdef _DEBUG
void CDBtestSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CDBtestSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG

BOOL CDBtestSet::Open(UINT nOpenType, LPCTSTR lpszSql, DWORD dwOptions) 
{
	// TODO: Add your specialized code here and/or call the base class
   
	return CRecordset::Open(nOpenType, lpszSql, dwOptions);
}
