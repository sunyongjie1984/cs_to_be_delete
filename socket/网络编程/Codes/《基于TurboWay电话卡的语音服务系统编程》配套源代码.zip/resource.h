//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DBtest.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDI_ICON1                       100
#define IDD_DBTEST_FORM                 101
#define ID_INDICATOR_DATE               102
#define IDP_FAILED_OPEN_DATABASE        103
#define ID_INDICATOR_TIME               104
#define IDR_MAINFRAME                   128
#define IDR_DBTESTTYPE                  129
#define IDI_ICON3                       148
#define IDI_AboutBox                    148
#define IDD_DIALOG_ARDEMO               150
#define IDD_SITE_SELECT                 151
#define IDD_SITE_RING                   152
#define IDD_QUERY_RECORD                154
#define IDD_PHONENUM                    155
#define IDB_ANI                         158
#define IDI_PHONE                       159
#define IDI_PHONERNG                    160
#define IDR_TRAYPOPUP                   161
#define IDD_GetWeb                      162
#define IDC_RECORD_ID                   1000
#define IDC_EDIT_SEG0                   1000
#define IDC_RECORD_FILENAME             1001
#define IDC_EDIT_CHANNELS0              1001
#define IDC_OUT                         1001
#define IDC_RECORD_TYPE                 1002
#define IDC_EDIT_SERIAL                 1002
#define IDC_RECORD_MEMO                 1003
#define IDC_EDIT_VER                    1003
#define IDC_EDIT_SEG1                   1004
#define IDC_EDIT_CHANNELS1              1005
#define IDC_STATUS                      1006
#define IDC_BUTTONOK                    1006
#define IDC_BUTTONCANCEL                1007
#define IDC_EDIT_SEG2                   1008
#define IDC_RECORD_NUM                  1008
#define IDC_EDIT_CHANNELS2              1009
#define IDC_STATUS2                     1009
#define IDC_EDIT1                       1009
#define IDC_EDIT2                       1010
#define IDC_EDIT3                       1011
#define IDC_EDIT_SEG3                   1012
#define IDC_URL                         1012
#define IDC_EDIT_CHANNELS3              1013
#define IDC_ANCHOR_NAME                 1013
#define IDC_FRAME_NAME                  1014
#define IDC_RADIO_RING                  1015
#define IDC_EDIT_IRQ                    1016
#define IDC_SPIN_RING                   1016
#define IDC_EDIT_RING                   1017
#define IDC_RADIO_RING2                 1018
#define IDC_SPIN_TIME                   1019
#define IDC_EDIT_TIME                   1020
#define IDC_EDIT_INT_TIMES              1021
#define IDC_LIST2                       1021
#define IDC_EDIT_CHANNEL_STATUS         1022
#define IDC_COMBO1                      1022
#define ID_RECORD_ADD                   32772
#define ID_RECORD_DELETE                32773
#define ID_SORT_ID                      32776
#define ID_SORT_FILENAME                32777
#define ID_SORT_TYPE                    32778
#define ID_RECORD_PLAY                  32779
#define ID_MENUITEM32782                32782
#define ID_ARDEMO                       32783
#define ID_RECORD_REPAIR                32786
#define ID_BUTTON32789                  32789
#define ID_GO_SITE                      32789
#define ID_RECORD_QUERY                 32790
#define ID_GO_HOME                      32791
#define ID_RING                         32793
#define ID_PHONENUM                     32794
#define ID_SysTray_SHOW                 32800
#define ID_SysTray_HIDE                 32801
#define ID_SysTray_EXIT                 32802
#define ID_GetWeb                       32804
#define ID_GetWebContents               32806
#define IDS_ABOUTBOX                    61446

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        163
#define _APS_NEXT_COMMAND_VALUE         32807
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
