// DBtestDoc.h : interface of the CDBtestDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DBTESTDOC_H__3078FB6D_DAB0_11D2_8628_00002100096B__INCLUDED_)
#define AFX_DBTESTDOC_H__3078FB6D_DAB0_11D2_8628_00002100096B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CDBtestDoc : public CDocument
{
protected: // create from serialization only
	CDBtestDoc();
	DECLARE_DYNCREATE(CDBtestDoc)

// Attributes
public:
	CDBtestSet m_dBtestSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBtestDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDBtestDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDBtestDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBTESTDOC_H__3078FB6D_DAB0_11D2_8628_00002100096B__INCLUDED_)
