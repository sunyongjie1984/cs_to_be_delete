// DBtestDoc.cpp : implementation of the CDBtestDoc class
//

#include "stdafx.h"
#include "DBtest.h"
#include "DBtestSet.h"
#include "DBtestDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBtestDoc

IMPLEMENT_DYNCREATE(CDBtestDoc, CDocument)

BEGIN_MESSAGE_MAP(CDBtestDoc, CDocument)
	//{{AFX_MSG_MAP(CDBtestDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_FILE_SEND_MAIL,OnFileSendMail)
	ON_UPDATE_COMMAND_UI(ID_FILE_SEND_MAIL,OnUpdateFileSendMail)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDBtestDoc construction/destruction

CDBtestDoc::CDBtestDoc()
{
	// TODO: add one-time construction code here

}

CDBtestDoc::~CDBtestDoc()
{
}

BOOL CDBtestDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CDBtestDoc diagnostics

#ifdef _DEBUG
void CDBtestDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDBtestDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDBtestDoc commands
