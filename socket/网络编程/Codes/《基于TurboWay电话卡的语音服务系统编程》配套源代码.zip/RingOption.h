#if !defined(AFX_RINGOPTION_H__8DFBA821_0222_11D3_B49E_F6740D7F6E86__INCLUDED_)
#define AFX_RINGOPTION_H__8DFBA821_0222_11D3_B49E_F6740D7F6E86__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RingOption.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRingOption dialog

class CRingOption : public CDialog
{
// Construction
public:
	CRingOption(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRingOption)
	enum { IDD = IDD_SITE_RING };
	CButton	m_RadioRing;
	CButton	m_RadioTime;
	CEdit	m_EditRing;
	CSpinButtonCtrl	m_SpinTime;
	CEdit	m_EditTime;
	CSpinButtonCtrl	m_SpinRing;
	//}}AFX_DATA
	bool bRingNum;
    int iRingCount;
    int iTimeCount;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRingOption)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRingOption)
	virtual BOOL OnInitDialog();
	afx_msg void OnRadioRing2();
	afx_msg void OnRadioRing();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RINGOPTION_H__8DFBA821_0222_11D3_B49E_F6740D7F6E86__INCLUDED_)
