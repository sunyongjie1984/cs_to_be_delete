// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__3078FB6B_DAB0_11D2_8628_00002100096B__INCLUDED_)
#define AFX_MAINFRM_H__3078FB6B_DAB0_11D2_8628_00002100096B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "animateicon.h" //�����ͼ��ͷ�ļ�
#include "SysTray.h" //����ϵͳ���ͼ��ͷ�ļ�

class CMainFrame : public CFrameWnd
{
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:
   int iRingTimeNum;
   //���ûͼ���������
   CAnimateIcon m_animicon;    
   UINT m_timerid;
   //����ϵͳ���ͼ���������
   CTrayNotifyIcon m_TrayIcon;
   HICON m_hIcons[2];
   BOOL m_bHide;  //��ʾ�����ز˵���ѡ��
   BOOL m_bShow;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	int m_nDatePaneNo;
	int m_nTimePaneNo;
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

// Generated message map functions
protected:
	afx_msg void OnMenuSelect(UINT nItemID, UINT nFlags, HMENU hSysMenu);
	afx_msg void OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
	afx_msg void OnUpdateDate(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTime(CCmdUI* pCmdUI);
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnHelpIndex();
	afx_msg void OnGoHome();
	afx_msg void OnGoSite();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSysTrayHIDE();
	afx_msg void OnUpdateSysTrayHIDE(CCmdUI* pCmdUI);
	afx_msg void OnSysTraySHOW();
	afx_msg void OnUpdateSysTraySHOW(CCmdUI* pCmdUI);
	afx_msg void OnGetWebContents();
	//}}AFX_MSG
	//����ϵͳ��ͼ���Զ�����Ϣ����
   afx_msg LRESULT OnTrayNotification(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
private:
	UINT m_nStatusPane1ID;
private:
	UINT m_nStatusPane1Style;
private:
	INT  m_nStatusPane1Width;
private:
	BOOL m_bMenuSelect;
private:
	BOOL InitStatusBar(UINT *pIndicators, int nSize, int nSeconds);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__3078FB6B_DAB0_11D2_8628_00002100096B__INCLUDED_)
