// PhonenumOpt.cpp : implementation file
//

#include "stdafx.h"
#include "DBtest.h"
#include "PhonenumOpt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPhonenumOpt dialog

CString str;

CPhonenumOpt::CPhonenumOpt(CWnd* pParent /*=NULL*/)
	: CDialog(CPhonenumOpt::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPhonenumOpt)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CPhonenumOpt::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPhonenumOpt)
	DDX_Control(pDX, IDC_COMBO1, m_oPhonenum);
	DDX_Control(pDX, IDC_LIST2, m_oDepartment);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPhonenumOpt, CDialog)
	//{{AFX_MSG_MAP(CPhonenumOpt)
	ON_LBN_SELCHANGE(IDC_LIST2, OnSelchangeList2)
	ON_CBN_KILLFOCUS(IDC_COMBO1, OnKillfocusCombo1)
	ON_CBN_DROPDOWN(IDC_COMBO1, OnDropdownCombo1)
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelchangeCombo1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPhonenumOpt message handlers

BOOL CPhonenumOpt::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
/*	m_oPhonenum.InsertString(0,"8637772");//��ʼ��������Ͽ�
	m_oPhonenum.InsertString (1,"8630031");
	m_oPhonenum.InsertString (2,"999669507");
	m_oPhonenum.InsertString (3,"7253827");*/
	m_oPhonenum.AddString ("����");
	m_oPhonenum.SetCurSel(0);

 	m_oDepartment.InsertString (0,"��װ����");//��ʼ������������
	m_oDepartment.InsertString (1,"���޲���");
	m_oDepartment.InsertString (2,"ά������");
	m_oDepartment.InsertString(3,"��ѯ����");
	m_oDepartment.InsertString (4,"����");
	m_oDepartment.SetCurSel(0);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CPhonenumOpt::OnSelchangeList2() 
{
  //�������沿����ĸı�����Ӧ�ı仯
	m_oPhonenum.SetCurSel (m_oDepartment.GetCurSel());
 
}


void CPhonenumOpt::OnKillfocusCombo1() 
{
 int i;
           
 m_oPhonenum.GetWindowText (str); //���ֶ��ı�ĺ���
 i=m_oDepartment.GetCurSel();  //���滻ԭ����ѡ��
 m_oPhonenum.DeleteString(i);
 m_oPhonenum.InsertString (i,str);
 m_oPhonenum.SetCurSel(i);
}


void CPhonenumOpt::OnOK() 
{
 int i;
	      //�������õĺ���
   for(i=0;i<=3;i++)
   {
	m_oPhonenum.SetCurSel (i);
	m_oPhonenum.GetWindowText(Phone[i],14);
   }
	CDialog::OnOK();
}

void CPhonenumOpt::OnDropdownCombo1() 
{
	// TODO: Add your control notification handler code here
	
}

void CPhonenumOpt::OnSelchangeCombo1() 
{
	// TODO: Add your control notification handler code here
	
}
