#if !defined(AFX_GETWEB_H__26CC63A0_F63E_11D2_A2E9_DE7A47DCA4C5__INCLUDED_)
#define AFX_GETWEB_H__26CC63A0_F63E_11D2_A2E9_DE7A47DCA4C5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GetWeb.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// GetWeb dialog

class GetWeb : public CDialog
{
// Construction
public:
	GetWeb(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(GetWeb)
	enum { IDD = IDD_GetWeb };
	CString	m_out;
	CString	m_url;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(GetWeb)
	public:
	virtual int DoModal();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(GetWeb)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GETWEB_H__26CC63A0_F63E_11D2_A2E9_DE7A47DCA4C5__INCLUDED_)
