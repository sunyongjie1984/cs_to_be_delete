// DBtestView.h : interface of the CDBtestView class
//
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INCLUDES()
#include "webbrowser2.h"
//}}AFX_INCLUDES

#if !defined(AFX_DBTESTVIEW_H__3078FB6F_DAB0_11D2_8628_00002100096B__INCLUDED_)
#define AFX_DBTESTVIEW_H__3078FB6F_DAB0_11D2_8628_00002100096B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "ToolTipWnd.h" //�������ݹ�����ʾͷ�ļ�

class CDBtestSet;

class CDBtestView : public CRecordView
{
protected: // create from serialization only
	CDBtestView();
	DECLARE_DYNCREATE(CDBtestView)

public:
	//{{AFX_DATA(CDBtestView)
	enum { IDD = IDD_DBTEST_FORM };
	CEdit	m_oNum;
	CButton	m_oOk;
	CButton	m_oCancel;
	CEdit	m_oMemo;
	CEdit	m_oFilename;
	CEdit	m_oType;
	CEdit	m_oSampleID;
	CDBtestSet* m_pSet;
	//}}AFX_DATA

// Attributes
public:
	CDBtestDoc* GetDocument();
	int iRingTimeNum;
	bool bRingTime;   //���壬ʱ������

	bool bPhoneNum;    //�绰�����Ƿ�ı�
	
	CToolTipWnd m_BalloonToolWnd; //�������ݹ�����ʾ�����
protected:
	BOOL m_bAdding; //���ӻ���ɾ��
    HICON m_hIcon;

public:
	void InternalChannels (WORD i);
	void ExternalChannels(WORD i);
	void CheckDtmf(WORD i);
	void ChPaint(WORD);
	char* GetFileName(char i,int j);				//����
	DWORD m_IntTimes;
	void UpdateIntTimes(void);

// Operations

public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBtestView)
	public:
	virtual CRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDBtestView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDBtestView)
	afx_msg void OnRecordAdd();
	afx_msg void OnRecordDelete();
	afx_msg void OnSortId();
	afx_msg void OnSortType();
	afx_msg void OnSortFilename();
	afx_msg void OnRecordPlay();
	afx_msg void OnRecordFirst();
	afx_msg void OnRecordLast();
	afx_msg void OnRecordNext();
	afx_msg void OnRecordPrev();
	afx_msg void OnButtonok();
	afx_msg void OnButtoncancel();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnPaint();
	afx_msg void OnRecordRepair();
	afx_msg void OnKillfocusRecordMemo();
	afx_msg void OnDestroy();
	afx_msg void OnRing();
	afx_msg void OnRecordQuery();
	afx_msg void OnPhonenum();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in DBtestView.cpp
inline CDBtestDoc* CDBtestView::GetDocument()
   { return (CDBtestDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBTESTVIEW_H__3078FB6F_DAB0_11D2_8628_00002100096B__INCLUDED_)
