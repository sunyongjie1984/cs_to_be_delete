// DBtestSet.h : interface of the CDBtestSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DBTESTSET_H__3078FB71_DAB0_11D2_8628_00002100096B__INCLUDED_)
#define AFX_DBTESTSET_H__3078FB71_DAB0_11D2_8628_00002100096B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CDBtestSet : public CRecordset
{
public:
	CDBtestSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDBtestSet)

// Field/Param Data
	//{{AFX_FIELD(CDBtestSet, CRecordset)
	long	m_sampleID;
	long	m_RecordNum;
	CString	m_FileName;
	CString	m_type;
	CString	m_memo;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBtestSet)
	public:
	virtual CString GetDefaultConnect();	// Default connection string
	virtual CString GetDefaultSQL(); 	// default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);	// RFX support
	virtual BOOL Open(UINT nOpenType = snapshot, LPCTSTR lpszSql = NULL, DWORD dwOptions = none);
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBTESTSET_H__3078FB71_DAB0_11D2_8628_00002100096B__INCLUDED_)
