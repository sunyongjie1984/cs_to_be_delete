// DBtest.h : main header file for the DBTEST application
//

#if !defined(AFX_DBTEST_H__3078FB67_DAB0_11D2_8628_00002100096B__INCLUDED_)
#define AFX_DBTEST_H__3078FB67_DAB0_11D2_8628_00002100096B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDBtestApp:
// See DBtest.cpp for the implementation of this class
//

class CDBtestApp : public CWinApp
{
public:
	CDBtestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBtestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
//protected:
//	HICON m_hIcon;
	//{{AFX_MSG(CDBtestApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBTEST_H__3078FB67_DAB0_11D2_8628_00002100096B__INCLUDED_)
