// GetWeb.cpp : implementation file
//

#include "stdafx.h"
#include "wininet.h"
#include "DBtest.h"
#include "GetWeb.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// GetWeb dialog


GetWeb::GetWeb(CWnd* pParent /*=NULL*/)
	: CDialog(GetWeb::IDD, pParent)
{
	//{{AFX_DATA_INIT(GetWeb)
	m_out = _T("");
	m_url = _T("");
	//}}AFX_DATA_INIT
}


void GetWeb::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(GetWeb)
	DDX_Text(pDX, IDC_OUT, m_out);
	DDX_Text(pDX, IDC_URL, m_url);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(GetWeb, CDialog)
	//{{AFX_MSG_MAP(GetWeb)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GetWeb message handlers

BOOL GetWeb::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_url="http://www.microsoft.com";
	UpdateData(false);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

CString GetWebPage(const CString& url)
{
	HINTERNET hHttpFile;
	char szSizeBuffer[32];
	DWORD dwLengthSizeBuffer=sizeof(szSizeBuffer);
	DWORD dwFileSize;
	DWORD dwBytesRead;
	bool bSuccessful;
	CString Contents;
	HINTERNET m_Session;

	Contents="������ʱ������һЩ����!";
	m_Session=::InternetOpen (NULL,
		                     INTERNET_OPEN_TYPE_PRECONFIG, //Use registry settings
		                      NULL, //Proxy name,null indicates use default.
							  NULL, //List of local servers,null indicates default.
							  0);
    //Open the url and getting a handle for HTTp file
	hHttpFile=::InternetOpenUrl (m_Session,(const char*)url,NULL,0,0,0);
    if (hHttpFile)
	{
		//Get the size of HTTP files
	bool bQuery=::HttpQueryInfo (hHttpFile,HTTP_QUERY_CONTENT_LENGTH,szSizeBuffer,&dwLengthSizeBuffer,NULL);
		if(bQuery==true)
		{
			//Allocating the memory space for HTTP file contents
			dwFileSize=atol(szSizeBuffer);
			LPSTR szContents=Contents.GetBuffer(dwFileSize);
			//read the HTTP file
			bool bRead=::InternetReadFile (hHttpFile,szContents,dwFileSize,&dwBytesRead);
			if (bRead)
			{
				bSuccessful=true;
				::InternetCloseHandle (hHttpFile); //Close the connection
				Contents=szContents;
			}
		}
		else
		{
			//connection failed
			bSuccessful=false;
		}
	}
		return Contents;
}

void GetWeb::OnOK() 
{
 UpdateData(true);
 if(m_url=="") 
	  MessageBox("URL�б������һ����ַ!","��ʾ",MB_ICONINFORMATION);
 else
 {
  
  m_out.Format("%s\n",GetWebPage(m_url));
  UpdateData(false);
 }
	
	//CDialog::OnOK();
}

int GetWeb::DoModal() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::DoModal();
}
