// FindIt.cpp : implementation file
//

#include "stdafx.h"
#include "DBtest.h"
#include "FindIt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// FindIt dialog


FindIt::FindIt(CWnd* pParent /*=NULL*/)
	: CDialog(FindIt::IDD, pParent)
{
	//{{AFX_DATA_INIT(FindIt)
	m_FindID = _T("");
	//}}AFX_DATA_INIT
}


void FindIt::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FindIt)
	DDX_Text(pDX, IDC_EDIT1, m_FindID);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FindIt, CDialog)
	//{{AFX_MSG_MAP(FindIt)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// FindIt message handlers
