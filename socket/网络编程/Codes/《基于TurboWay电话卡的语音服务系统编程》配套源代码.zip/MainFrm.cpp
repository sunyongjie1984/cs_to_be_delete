// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "DBtest.h"
#include "SiteSelect.h"
#include "RingOption.h"
#include "GetWeb.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define WM_TRAYNOTIFY WM_USER + 100  //�û��Զ�����Ϣ���
CWnd *pMainWnd;
/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_INITMENUPOPUP()
	ON_WM_MENUSELECT()
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_DATE, OnUpdateDate)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_TIME, OnUpdateTime)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_HELP_INDEX, OnHelpIndex)
	ON_COMMAND(ID_GO_HOME, OnGoHome)
	ON_COMMAND(ID_GO_SITE, OnGoSite)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_COMMAND(ID_SysTray_HIDE, OnSysTrayHIDE)
	ON_UPDATE_COMMAND_UI(ID_SysTray_HIDE, OnUpdateSysTrayHIDE)
	ON_COMMAND(ID_SysTray_SHOW, OnSysTraySHOW)
	ON_UPDATE_COMMAND_UI(ID_SysTray_SHOW, OnUpdateSysTraySHOW)
	ON_COMMAND(ID_GetWebContents, OnGetWebContents)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_HELP_USING,CFrameWnd::OnHelp)
	ON_COMMAND(ID_HELP_INDEX,CFrameWnd::OnHelpIndex)
	ON_MESSAGE(WM_TRAYNOTIFY, OnTrayNotification)//�Զ����޸�ϵͳ��ͼ����Ϣӳ��
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// CG: The following block was inserted by 'Status Bar' component.
	{
		m_nStatusPane1Width = -1;
		m_bMenuSelect = FALSE;
	}

  
	// TODO: add member initialization code here
//	m_bHide = FALSE;
//	m_bShow=TRUE;
    m_hIcons[0] = AfxGetApp()->LoadIcon(IDI_PHONE);
    m_hIcons[1] = AfxGetApp()->LoadIcon(IDI_PHONERNG);
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	//new VC 6.0 toolbar
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

/*	//Old VC 5.0 toolbar
    if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");     
		return -1;      // fail to create
	} */

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS |CBRS_FLOAT_MULTI | CBRS_FLYBY | 
		CBRS_GRIPPER|CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	// CG: The following block was inserted by 'Status Bar' component.
	{
		// Find out the size of the static variable 'indicators' defined
		// by AppWizard and copy it
		int nOrigSize = sizeof(indicators) / sizeof(UINT);

		UINT* pIndicators = new UINT[nOrigSize + 2];
		memcpy(pIndicators, indicators, sizeof(indicators));

		// Call the Status Bar Component's status bar creation function
		if (!InitStatusBar(pIndicators, nOrigSize, 60))
		{
			TRACE0("Failed to initialize Status Bar\n");
			return -1;
		}
		delete[] pIndicators;
	}
	//װ��ͼ��겢������ʱ��
    m_animicon.SetImageList(IDB_ANI,2,RGB(0,0,0));
    m_timerid = this->SetTimer(99,500,NULL);

    //Ϊϵͳ���ͼ�꽨�������˵�,ÿ��500����ѭ����ʾ�ͼ��
   if (!m_TrayIcon.Create(this, IDR_TRAYPOPUP, _T("Ͷ�����޹���ϵͳ"), m_hIcons, 2, 500, WM_TRAYNOTIFY))
  {
    AfxMessageBox(_T("ϵͳ��ͼ�꽨��ʧ�ܣ�"), MB_OK | MB_ICONSTOP);
    return -1;
  }
  
	return 0;
}
  //�Զ����޸�ϵͳ��ͼ����Ϣ����
LRESULT CMainFrame::OnTrayNotification(WPARAM wParam, LPARAM lParam)
{
  //Delegate all the work back to the default implementation in
  //CTrayNotifyIcon.
  return m_TrayIcon.OnTrayNotification(wParam, lParam);
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

 

void CMainFrame::OnMenuSelect(UINT nItemID, UINT nFlags, HMENU hSysMenu)
{
  	CFrameWnd::OnMenuSelect(nItemID, nFlags, hSysMenu);
  
	// CG: The following block was inserted by 'Status Bar' component.
	{
		// Restore first pane of the statusbar?
		if (nFlags == 0xFFFF && hSysMenu == 0 && m_nStatusPane1Width != -1)
		{
			m_bMenuSelect = FALSE;
			m_wndStatusBar.SetPaneInfo(0, 
				m_nStatusPane1ID, m_nStatusPane1Style, m_nStatusPane1Width);
			m_nStatusPane1Width = -1;   // Set it to illegal value
		}
		else 
		{
			m_bMenuSelect = TRUE;
		}
	}

}

void CMainFrame::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu)
{
  	CFrameWnd::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);
  
	// CG: The following block was inserted by 'Status Bar' component.
	{
		// store width of first pane and its style
		if (m_nStatusPane1Width == -1 && m_bMenuSelect)
		{
			m_wndStatusBar.GetPaneInfo(0, m_nStatusPane1ID, 
				m_nStatusPane1Style, m_nStatusPane1Width);
			m_wndStatusBar.SetPaneInfo(0, m_nStatusPane1ID, 
				SBPS_NOBORDERS|SBPS_STRETCH, 16384);
		}
	}

}

void CMainFrame::OnUpdateDate(CCmdUI* pCmdUI)
{
	// CG: This function was inserted by 'Status Bar' component.

	// Get current date and format it
	CTime time = CTime::GetCurrentTime();
	CString strDate = time.Format(_T("%A, %Y��%m��%d��"));

	// BLOCK: compute the width of the date string
	CSize size;
	{
		HGDIOBJ hOldFont = NULL;
		HFONT hFont = (HFONT)m_wndStatusBar.SendMessage(WM_GETFONT);
		CClientDC dc(NULL);
		if (hFont != NULL) 
			hOldFont = dc.SelectObject(hFont);
		size = dc.GetTextExtent(strDate);
		if (hOldFont != NULL) 
			dc.SelectObject(hOldFont);
	}

	// Update the pane to reflect the current date
	UINT nID, nStyle;
	int nWidth;
	m_wndStatusBar.GetPaneInfo(m_nDatePaneNo, nID, nStyle, nWidth);
	m_wndStatusBar.SetPaneInfo(m_nDatePaneNo, nID, nStyle, size.cx);
	pCmdUI->SetText(strDate);
	pCmdUI->Enable(TRUE);

}

void CMainFrame::OnUpdateTime(CCmdUI* pCmdUI)
{
	// CG: This function was inserted by 'Status Bar' component.

	// Get current date and format it
	CTime time = CTime::GetCurrentTime();
	CString strTime = time.Format(_T("%I:%M:%S "));
	strTime = (time.GetHour() < 12 ? _T("") : _T(""))+ strTime +(time.GetHour() < 12 ? _T("���� "):_T("���� "));


	// BLOCK: compute the width of the date string
	CSize size;
	{
		HGDIOBJ hOldFont = NULL;
		HFONT hFont = (HFONT)m_wndStatusBar.SendMessage(WM_GETFONT);
		CClientDC dc(NULL);
		if (hFont != NULL) 
			hOldFont = dc.SelectObject(hFont);
		size = dc.GetTextExtent(strTime);
		if (hOldFont != NULL) 
			dc.SelectObject(hOldFont);
	}

	// Update the pane to reflect the current time
	UINT nID, nStyle;
	int nWidth;
	m_wndStatusBar.GetPaneInfo(m_nTimePaneNo, nID, nStyle, nWidth);
	m_wndStatusBar.SetPaneInfo(m_nTimePaneNo, nID, nStyle, size.cx);
	pCmdUI->SetText(strTime);
	pCmdUI->Enable(TRUE);

}

BOOL CMainFrame::InitStatusBar(UINT *pIndicators, int nSize, int nSeconds)
{
	// CG: This function was inserted by 'Status Bar' component.

	// Create an index for the DATE pane
	m_nDatePaneNo = nSize++;
	pIndicators[m_nDatePaneNo] = ID_INDICATOR_DATE;
	// Create an index for the TIME pane
	m_nTimePaneNo = nSize++;
	nSeconds = 1;
	pIndicators[m_nTimePaneNo] = ID_INDICATOR_TIME;

	// TODO: Select an appropriate time interval for updating
	// the status bar when idling.
	m_wndStatusBar.SetTimer(0x1000, nSeconds * 1000, NULL);

	return m_wndStatusBar.SetIndicators(pIndicators, nSize);

}

//����ָ����WEB��ҳ
void CMainFrame::OnGoHome() 
{
       //Go right the company's home page
	HlinkSimpleNavigateToString(L"http://www.microsoft.com",NULL,NULL,NULL,0,NULL,NULL,0);

}

void CMainFrame::OnGoSite() 
{
	 //Create a copy of the dialog
	CSiteSelect NewSiteSelect;

	NewSiteSelect.DoModal();
	
}


void CMainFrame::OnHelpIndex() 
{
 WinHelp(0,HELP_CONTENTS);	
}

void CMainFrame::OnDestroy() 
{
	CFrameWnd::OnDestroy();

	//�������㣬�رռ�ʱ��   
  if(m_timerid != 0)       
     KillTimer(m_timerid);	
}

void CMainFrame::OnTimer(UINT nIDEvent) 
{
    //ѭ����ʾ�ͼ��
	m_animicon.ShowNextImage();
   
	CFrameWnd::OnTimer(nIDEvent);
}

 //ϵͳ�������˵�����ʵ��
void CMainFrame::OnSysTrayHIDE() 
{
	// TODO: Add your command handler code here
//	m_bHide= !m_bHide;
    pMainWnd=AfxGetApp()->GetMainWnd();
	pMainWnd->ShowWindow(SW_HIDE);

}

void CMainFrame::OnUpdateSysTrayHIDE(CCmdUI* pCmdUI) 
{
   
 /*	if( m_bHide==TRUE)  
   {
	  pCmdUI->SetCheck(true);
	  pCmdUI->Enable(FALSE);
	  
   }
   else
   {
	  pCmdUI->SetCheck(false);
      pCmdUI->Enable(true);
   }*/
}

void CMainFrame::OnSysTraySHOW() 
{
 //   m_bShow=!m_bShow;
	pMainWnd=AfxGetApp()->GetMainWnd();
	pMainWnd->ShowWindow(SW_SHOWMAXIMIZED);	
	
}

void CMainFrame::OnUpdateSysTraySHOW(CCmdUI* pCmdUI) 
{
 /*    if( m_bShow==TRUE) 
   {
	  pCmdUI->SetCheck(true);
	  pCmdUI->Enable(FALSE);
   }
   else
   {
	  pCmdUI->SetCheck(false);
      pCmdUI->Enable(true);
   }*/
}

void CMainFrame::OnGetWebContents() 
{
  GetWeb NewWeb;
    
	NewWeb.DoModal();
}
