
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "AnimateIcon.h"
#include "DBtest.h"  //������Դ�ļ�

// default constructor
CAnimateIcon::CAnimateIcon()
{
	m_iImageCounter = -1;
	m_iMaxNoOfImages = -99;
	m_imgList.m_hImageList = NULL;
    //��������ͼ���ļ�
	hIcon[0]=AfxGetApp()->LoadIcon(IDI_PHONE);
	hIcon[1]=AfxGetApp()->LoadIcon(IDI_PHONERNG);
}

// default do nothing destructor
CAnimateIcon::~CAnimateIcon()
{
	if (hPrevIcon) 
		DestroyIcon(hPrevIcon);
}

// This is the first function which needs to be called in order
// to fill the image list
// Parameters :
// ------------
// int IDOfImgListResource - pass the Resource ID of a toolbar resource
//                           containing the image list
// int numberOfImages      - Number of images (16x16) in the toolbar resource
// transparentColor        - RGB value of color you want to be transparent
BOOL CAnimateIcon::SetImageList(int IDOfImgListResource,int numberOfImages,COLORREF transparentColor)
{
	if(numberOfImages <= 0)
		return FALSE;
	m_iMaxNoOfImages = numberOfImages;
	VERIFY(m_imgList.Create(IDOfImgListResource,16,1,transparentColor));
	return TRUE;
}

// This function needs to be called repetatively to show next image
// Parameters :
// ------------
// NONE

BOOL CAnimateIcon::ShowNextImage()
{
	if(m_imgList.m_hImageList == NULL)
		return FALSE;
	m_iImageCounter++; //ͼ��ѭ��������
	if(m_iImageCounter >= m_iMaxNoOfImages)
		m_iImageCounter =0;

	// extract the icon from imagelist

	//����λͼ�ļ�IDI_ANI������IDI_PHONE��IDI_PHONERNG����ͼ���ļ�����ʵ�ֶ�����������������С��ʱͼ����ʾ��͸������
	//hIcon = m_imgList.ExtractIcon(m_iImageCounter);

	// send the message to frame to update icon
	HICON hPrevIcon = (HICON) 	AfxGetMainWnd()->SendMessage(WM_SETICON,TRUE,(LPARAM)hIcon[m_iImageCounter]);	
	// Free the previous icon resource
	if (hPrevIcon) 	
	    DestroyIcon(hPrevIcon);
	return TRUE;
}