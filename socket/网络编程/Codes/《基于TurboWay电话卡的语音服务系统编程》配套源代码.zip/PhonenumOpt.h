#if !defined(AFX_PHONENUMOPT_H__7EE744A1_0922_11D3_B49E_BA6511E35088__INCLUDED_)
#define AFX_PHONENUMOPT_H__7EE744A1_0922_11D3_B49E_BA6511E35088__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PhonenumOpt.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPhonenumOpt dialog

class CPhonenumOpt : public CDialog
{
// Construction
public:
	CPhonenumOpt(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPhonenumOpt)
	enum { IDD = IDD_PHONENUM };
	CComboBox	m_oPhonenum;
	CListBox	m_oDepartment;
	//}}AFX_DATA
   char Phone[4][14];

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPhonenumOpt)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPhonenumOpt)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeList2();
	afx_msg void OnKillfocusCombo1();
	virtual void OnOK();
	afx_msg void OnDropdownCombo1();
	afx_msg void OnSelchangeCombo1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PHONENUMOPT_H__7EE744A1_0922_11D3_B49E_BA6511E35088__INCLUDED_)
