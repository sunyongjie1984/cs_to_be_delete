/*
 *  MailSvr by Davide Libenzi ( Intranet and Internet mail server )
 *  Copyright (C) 1999  Davide Libenzi
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Davide Libenzi <davidel@maticad.it>
 *
 */


#include "SysInclude.h"
#include "SysDep.h"
#include "SvrDefines.h"
#include "ShBlocks.h"
#include "ResLocks.h"
#include "MiscUtils.h"
#include "MailConfig.h"
#include "MailSvr.h"






#define MAX_WAIT_GATES              64
#define MAX_LOCKED_RESOURCES        60000






struct ResWaitGate
{
    SYS_IPCNAME     SemName;
    SYS_SEMAPHORE   SemID;
    int             iWaitingProcesses;
};

struct ResGateData
{
    int             iNumGates;
    ResWaitGate     WaitGates[MAX_WAIT_GATES];
};
/* INDENT OFF */

struct ResLockData
{
    SYS_UINT16      ShLocks:15;
    SYS_UINT16      ExLocks:1;
};

/* INDENT ON */

struct DataLocker
{
    SYS_SEMAPHORE   LockSemID;
    SYS_SHMEM       ResMapShmID,
                    ResGatesShmID;
    ResLockData    *pRLD;
    ResGateData    *pRGD;
};






static unsigned int RLckCreateResourceID(unsigned int uUserID, unsigned int uResID);
static int      RLckGetGateIndex(unsigned int uResourceID, int iNumGates);
static int      RLckSetupDataLock(DataLocker & DL);
static int      RLckCleanupDataLock(DataLocker & DL);
static int      RLckLockData(DataLocker & DL);
static void     RLckUnlockData(DataLocker & DL);








static SYS_IPCNAME LockSem,
                ResMapShm,
                ResGatesShm;
static SYS_SEMAPHORE LockSemID;
static SYS_SHMEM ResMapShmID,
                ResGatesShmID;








int             RLckInitLockers(int iNumWaitGates)
{

///////////////////////////////////////////////////////////////////////////////
//  Create access semaphore
///////////////////////////////////////////////////////////////////////////////
    LockSem = SysCreateIPCName();

    if ((LockSemID = SysCreateSemaphore(1, SYS_DEFAULT_MAXCOUNT,
                            LockSem)) == SYS_INVALID_SEMAPHORE)
        return (ErrGetErrorCode());

///////////////////////////////////////////////////////////////////////////////
//  Create resource lock map
///////////////////////////////////////////////////////////////////////////////
    ResMapShm = SysCreateIPCName();

    if ((ResMapShmID = SysCreateSharedMem(MAX_LOCKED_RESOURCES * sizeof(ResLockData),
                            ResMapShm)) == SYS_INVALID_SHMEM)
    {
        ErrorPush();
        SysCloseSemaphore(LockSemID);
        SysKillSemaphore(LockSemID);
        return (ErrorPop());
    }

    ResLockData    *pRLD = (ResLockData *) SysMapSharedMem(ResMapShmID);

    memset(pRLD, 0, MAX_LOCKED_RESOURCES * sizeof(ResLockData));

    SysUnmapSharedMem(ResMapShmID, pRLD);

///////////////////////////////////////////////////////////////////////////////
//  Create wait gates data
///////////////////////////////////////////////////////////////////////////////
    ResGatesShm = SysCreateIPCName();

    if ((ResGatesShmID = SysCreateSharedMem(sizeof(ResGateData),
                            ResGatesShm)) == SYS_INVALID_SHMEM)
    {
        ErrorPush();
        SysCloseSharedMem(ResMapShmID);
        SysKillSharedMem(ResMapShmID);

        SysCloseSemaphore(LockSemID);
        SysKillSemaphore(LockSemID);
        return (ErrorPop());
    }

    ResGateData    *pRGD = (ResGateData *) SysMapSharedMem(ResGatesShmID);
    ResWaitGate    *pRWG = pRGD->WaitGates;

    memset(pRGD, 0, sizeof(ResGateData));


    pRGD->iNumGates = max(1, min(MAX_WAIT_GATES, iNumWaitGates));


    int             ii;

    for (ii = 0; ii < pRGD->iNumGates; ii++)
    {
        pRWG[ii].SemName = SysCreateIPCName();
        pRWG[ii].iWaitingProcesses = 0;
    }

    for (ii = 0; ii < pRGD->iNumGates; ii++)
    {
        if ((pRWG[ii].SemID = SysCreateSemaphore(0, SYS_DEFAULT_MAXCOUNT,
                                pRWG[ii].SemName)) == SYS_INVALID_SEMAPHORE)
        {
            for (--ii; ii >= 0; ii--)
                SysCloseSemaphore(pRWG[ii].SemID), SysKillSemaphore(pRWG[ii].SemID);

            ErrorPush();
            SysUnmapSharedMem(ResGatesShmID, pRGD);
            SysCloseSharedMem(ResGatesShmID);
            SysKillSharedMem(ResGatesShmID);

            SysCloseSharedMem(ResMapShmID);
            SysKillSharedMem(ResMapShmID);

            SysCloseSemaphore(LockSemID);
            SysKillSemaphore(LockSemID);

            return (ErrorPop());
        }
    }

    SysUnmapSharedMem(ResGatesShmID, pRGD);

    return (0);

}



int             RLckCleanupLockers(void)
{

    SysCloseSemaphore(LockSemID);
    SysKillSemaphore(LockSemID);


    ResGateData    *pRGD = (ResGateData *) SysMapSharedMem(ResGatesShmID);
    ResWaitGate    *pRWG = pRGD->WaitGates;

    for (int ii = 0; ii < pRGD->iNumGates; ii++)
        SysCloseSemaphore(pRWG[ii].SemID), SysKillSemaphore(pRWG[ii].SemID);

    SysUnmapSharedMem(ResGatesShmID, pRGD);

    SysCloseSharedMem(ResGatesShmID);
    SysKillSharedMem(ResGatesShmID);


    SysCloseSharedMem(ResMapShmID);
    SysKillSharedMem(ResMapShmID);

    return (0);

}



static unsigned int RLckCreateResourceID(unsigned int uUserID, unsigned int uResID)
{

    unsigned int    uResourceID = ((uUserID == MAIL_USER) ? uResID :
            (MAX_USER0_RES + (uUserID - 1) * MAX_USER_RES + uResID));

    return (uResourceID);

}



static int      RLckGetGateIndex(unsigned int uResourceID, int iNumGates)
{

    return ((int) (uResourceID % iNumGates));

}



static int      RLckSetupDataLock(DataLocker & DL)
{

    ZeroData(DL);

    if ((DL.LockSemID = SysConnectSemaphore(1, SYS_DEFAULT_MAXCOUNT,
                            LockSem)) == SYS_INVALID_SEMAPHORE)
        return (ErrGetErrorCode());

    if ((DL.ResMapShmID = SysConnectSharedMem(MAX_LOCKED_RESOURCES * sizeof(ResLockData),
                            ResMapShm)) == SYS_INVALID_SHMEM)
    {
        ErrorPush();
        SysCloseSemaphore(DL.LockSemID);
        return (ErrorPop());
    }

    DL.pRLD = (ResLockData *) SysMapSharedMem(DL.ResMapShmID);


    if ((DL.ResGatesShmID = SysConnectSharedMem(sizeof(ResGateData),
                            ResGatesShm)) == SYS_INVALID_SHMEM)
    {
        ErrorPush();
        SysUnmapSharedMem(DL.ResMapShmID, DL.pRLD);
        SysCloseSharedMem(DL.ResMapShmID);

        SysCloseSemaphore(DL.LockSemID);
        return (ErrorPop());
    }

    DL.pRGD = (ResGateData *) SysMapSharedMem(DL.ResGatesShmID);

    return (0);

}



static int      RLckCleanupDataLock(DataLocker & DL)
{

    SysCloseSemaphore(DL.LockSemID);

    SysUnmapSharedMem(DL.ResMapShmID, DL.pRLD);
    SysCloseSharedMem(DL.ResMapShmID);

    SysUnmapSharedMem(DL.ResGatesShmID, DL.pRGD);
    SysCloseSharedMem(DL.ResGatesShmID);

    ZeroData(DL);

    return (0);

}



static int      RLckLockData(DataLocker & DL)
{

    return (SysWaitSemaphore(DL.LockSemID, SYS_INFINITE_TIMEOUT));

}



static void     RLckUnlockData(DataLocker & DL)
{

    SysReleaseSemaphore(DL.LockSemID, 1);

}



RLCK_HANDLE     RLckLockEX(unsigned int uUserID, unsigned int uResID)
{

    unsigned int    uResourceID = RLckCreateResourceID(uUserID, uResID);

    if (uResourceID >= MAX_LOCKED_RESOURCES)
    {
        ErrSetErrorCode(ERR_USERID_TOO_HIGH);
        return (INVALID_RLCK_HANDLE);
    }

    DataLocker      DL;

    if (RLckSetupDataLock(DL) < 0)
        return (INVALID_RLCK_HANDLE);

    SYS_SEMAPHORE   SemID = SYS_INVALID_SEMAPHORE;

    for (;;)
    {
        if (RLckLockData(DL) < 0)
        {
            RLckCleanupDataLock(DL);
            return (INVALID_RLCK_HANDLE);
        }

        if (DL.pRLD[uResourceID].ExLocks || (DL.pRLD[uResourceID].ShLocks != 0))
        {
            int             iGateIndex = RLckGetGateIndex(uResourceID, DL.pRGD->iNumGates);

            if ((SemID == SYS_INVALID_SEMAPHORE) &&
                    ((SemID = SysConnectSemaphore(0, SYS_DEFAULT_MAXCOUNT,
                                            DL.pRGD->WaitGates[iGateIndex].SemName)) == SYS_INVALID_SEMAPHORE))
            {
                RLckUnlockData(DL);
                RLckCleanupDataLock(DL);
                return (INVALID_RLCK_HANDLE);
            }

            ++DL.pRGD->WaitGates[iGateIndex].iWaitingProcesses;

            RLckUnlockData(DL);

            if (SysWaitSemaphore(SemID, SYS_INFINITE_TIMEOUT) < 0)
            {
                SysCloseSemaphore(SemID);
                RLckCleanupDataLock(DL);
                return (INVALID_RLCK_HANDLE);
            }
        }
        else
        {
            DL.pRLD[uResourceID].ExLocks = 1;

            RLckUnlockData(DL);

            break;
        }
    }

    if (SemID != SYS_INVALID_SEMAPHORE)
        SysCloseSemaphore(SemID);

    RLckCleanupDataLock(DL);

    return ((RLCK_HANDLE) uResourceID);

}



int             RLckUnlockEX(RLCK_HANDLE hLock)
{

    DataLocker      DL;

    if (RLckSetupDataLock(DL) < 0)
        return (ErrGetErrorCode());


    unsigned int    uResourceID = (unsigned int) hLock;


    if (RLckLockData(DL) < 0)
    {
        ErrorPush();
        RLckCleanupDataLock(DL);
        return (ErrorPop());
    }

    int             iGateIndex = RLckGetGateIndex(uResourceID, DL.pRGD->iNumGates);

    DL.pRLD[uResourceID].ExLocks = 0;

    if (DL.pRGD->WaitGates[iGateIndex].iWaitingProcesses > 0)
    {
        SYS_SEMAPHORE   SemID = SysConnectSemaphore(0, SYS_DEFAULT_MAXCOUNT,
                DL.pRGD->WaitGates[iGateIndex].SemName);

        if (SemID == SYS_INVALID_SEMAPHORE)
        {
            ErrorPush();
            RLckUnlockData(DL);
            RLckCleanupDataLock(DL);

            return (ErrorPop());
        }


        SysReleaseSemaphore(SemID, DL.pRGD->WaitGates[iGateIndex].iWaitingProcesses);

        DL.pRGD->WaitGates[iGateIndex].iWaitingProcesses = 0;

        SysCloseSemaphore(SemID);
    }

    RLckUnlockData(DL);

    RLckCleanupDataLock(DL);

    return (0);

}



RLCK_HANDLE     RLckLockSH(unsigned int uUserID, unsigned int uResID)
{

    unsigned int    uResourceID = RLckCreateResourceID(uUserID, uResID);

    if (uResourceID >= MAX_LOCKED_RESOURCES)
    {
        ErrSetErrorCode(ERR_USERID_TOO_HIGH);
        return (INVALID_RLCK_HANDLE);
    }

    DataLocker      DL;

    if (RLckSetupDataLock(DL) < 0)
        return (INVALID_RLCK_HANDLE);

    SYS_SEMAPHORE   SemID = SYS_INVALID_SEMAPHORE;

    for (;;)
    {
        if (RLckLockData(DL) < 0)
        {
            RLckCleanupDataLock(DL);
            return (INVALID_RLCK_HANDLE);
        }

        if (DL.pRLD[uResourceID].ExLocks)
        {
            int             iGateIndex = RLckGetGateIndex(uResourceID, DL.pRGD->iNumGates);

            if ((SemID == SYS_INVALID_SEMAPHORE) &&
                    ((SemID = SysConnectSemaphore(0, SYS_DEFAULT_MAXCOUNT,
                                            DL.pRGD->WaitGates[iGateIndex].SemName)) == SYS_INVALID_SEMAPHORE))
            {
                RLckUnlockData(DL);
                RLckCleanupDataLock(DL);
                return (INVALID_RLCK_HANDLE);
            }

            ++DL.pRGD->WaitGates[iGateIndex].iWaitingProcesses;

            RLckUnlockData(DL);

            if (SysWaitSemaphore(SemID, SYS_INFINITE_TIMEOUT) < 0)
            {
                SysCloseSemaphore(SemID);
                RLckCleanupDataLock(DL);
                return (INVALID_RLCK_HANDLE);
            }
        }
        else
        {
            ++DL.pRLD[uResourceID].ShLocks;

            RLckUnlockData(DL);

            break;
        }
    }

    if (SemID != SYS_INVALID_SEMAPHORE)
        SysCloseSemaphore(SemID);

    RLckCleanupDataLock(DL);

    return ((RLCK_HANDLE) uResourceID);

}



int             RLckUnlockSH(RLCK_HANDLE hLock)
{

    DataLocker      DL;

    if (RLckSetupDataLock(DL) < 0)
        return (ErrGetErrorCode());


    unsigned int    uResourceID = (unsigned int) hLock;


    if (RLckLockData(DL) < 0)
    {
        ErrorPush();
        RLckCleanupDataLock(DL);
        return (ErrorPop());
    }

    int             iGateIndex = RLckGetGateIndex(uResourceID, DL.pRGD->iNumGates);

    --DL.pRLD[uResourceID].ShLocks;

    if ((DL.pRGD->WaitGates[iGateIndex].iWaitingProcesses > 0) &&
            (DL.pRLD[uResourceID].ShLocks == 0))
    {
        SYS_SEMAPHORE   SemID = SysConnectSemaphore(0, SYS_DEFAULT_MAXCOUNT,
                DL.pRGD->WaitGates[iGateIndex].SemName);

        if (SemID == SYS_INVALID_SEMAPHORE)
        {
            ErrorPush();
            RLckUnlockData(DL);
            RLckCleanupDataLock(DL);

            return (ErrorPop());
        }


        SysReleaseSemaphore(SemID, DL.pRGD->WaitGates[iGateIndex].iWaitingProcesses);

        DL.pRGD->WaitGates[iGateIndex].iWaitingProcesses = 0;

        SysCloseSemaphore(SemID);
    }

    RLckUnlockData(DL);

    RLckCleanupDataLock(DL);

    return (0);

}
