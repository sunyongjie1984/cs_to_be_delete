/*
 *  MailSvr by Davide Libenzi ( Intranet and Internet mail server )
 *  Copyright (C) 1999  Davide Libenzi
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Davide Libenzi <davidel@maticad.it>
 *
 */


#include "SysInclude.h"
#include "SysDep.h"
#include "SvrDefines.h"
#include "ShBlocks.h"
#include "SWMR.h"
#include "ResLocks.h"
#include "StrUtils.h"
#include "SList.h"
#include "MailConfig.h"
#include "MailSvr.h"
#include "MiscUtils.h"
#include "SvrUtils.h"
#include "POP3GwLink.h"
#include "ExtAliases.h"
#include "UsrUtils.h"
#include "UsrAuth.h"







#define SVR_TABLE_FILE              "mailusers.tab"
#define SVR_ALIAS_FILE              "aliases.tab"
#define USR_TABLE_LINE_MAX          2048
#define USR_ALIAS_LINE_MAX          512
#define USER_PROFILE_FILE           "user.tab"
#define DEFAULT_USER_PROFILE_FILE   "userdef.tab"
#define USER_MAILBOX_DIR            "mailbox"
#define POP3_LOCK_FILE              "pop3"
#define MLUSERS_TABLE_FILE          "mlusers.tab"
#define MAILPROCESS_FILE            "mailproc.tab"









enum UsrFileds
{
    usrDomain = 0,
    usrName,
    usrPassword,
    usrID,
    usrPath,
    usrType,

    usrMax
};

struct UserInfoVar
{
    LISTLINK        LL;
    char           *pszName;
    char           *pszValue;
};

enum AliasFileds
{
    alsDomain = 0,
    alsAlias,
    alsName,

    alsMax
};

struct UsersDBScanData
{
    char            szTmpDBFile[SYS_MAX_PATH];
    FILE           *pDBFile;
};

struct AliasDBScanData
{
    char            szTmpDBFile[SYS_MAX_PATH];
    FILE           *pDBFile;
};






static char    *UsrGetTableFilePath(char *pszUsrFilePath);
static char    *UsrGetAliasFilePath(char *pszAlsFilePath);
static UserInfo *UsrGetUserFromStrings(char **ppszStrings);
static UserInfoVar *UsrAllocVar(const char *pszName, const char *pszValue);
static void     UsrFreeVar(UserInfoVar * pUIV);
static void     UsrFreeInfoList(HSLIST & InfoList);
static UserInfoVar *UsrGetUserVar(HSLIST & InfoList, const char *pszName);
static int      UsrWriteInfoList(HSLIST & InfoList, FILE * pProfileFile);
static int      UsrLoadUserInfo(HSLIST & InfoList, unsigned int uUserID, const char *pszFilePath);
static int      UsrLoadUserDefaultInfo(HSLIST & InfoList);
static int      UsrAliasLookupNameLK(const char *pszDomain, const char *pszAlias,
                        char *pszName = NULL);
static int      UsrWriteAlias(FILE * pAlsFile, AliasInfo * pAI);
static int      UsrRemoveUserAlias(const char *pszName);
static UserInfo *UsrGetUserByNameLK(const char *pszDomain, const char *pszName);
static UserInfo *UsrGetUserByIDLK(const char *pszDomain, unsigned int uUserID);
static int      UsrDropUserEnv(UserInfo * pUI);
static int      UsrWriteUser(UserInfo * pUI, FILE * pUsrFile);
static int      UsrPrepareUserEnv(UserInfo * pUI);







static char    *UsrGetTableFilePath(char *pszUsrFilePath)
{

    CfgGetRootPath(pszUsrFilePath);

    strcat(pszUsrFilePath, SVR_TABLE_FILE);

    return (pszUsrFilePath);

}



static char    *UsrGetAliasFilePath(char *pszAlsFilePath)
{

    CfgGetRootPath(pszAlsFilePath);

    strcat(pszAlsFilePath, SVR_ALIAS_FILE);

    return (pszAlsFilePath);

}



char           *UsrGetMLTableFilePath(UserInfo * pUI, char *pszMLTablePath)
{

    UsrGetUserPath(pUI, pszMLTablePath);

    strcat(pszMLTablePath, MLUSERS_TABLE_FILE);

    return (pszMLTablePath);

}



UserType        UsrGetUserType(UserInfo * pUI)
{

    if (pUI->pszType == NULL)
        return (usrTypeError);

    switch (pUI->pszType[0])
    {
        case ('U'):
            return (usrTypeUser);

        case ('M'):
            return (usrTypeML);
    }

    return (usrTypeError);

}



UserInfo       *UsrCreateDefaultUser(char const * pszDomain, char const * pszName,
                        char const * pszPassword, UserType TypeUser)
{

    UserInfo       *pUI = (UserInfo *) SysAlloc(sizeof(UserInfo));

    if (pUI == NULL)
        return (NULL);

    pUI->pszDomain = SysStrDup(pszDomain);
    pUI->uUserID = 0;
    pUI->pszName = SysStrDup(pszName);
    pUI->pszPassword = SysStrDup(pszPassword);
    pUI->pszPath = SysStrDup(pszName);
    pUI->pszType = SysStrDup((TypeUser == usrTypeUser) ? "U" : "M");

///////////////////////////////////////////////////////////////////////////////
//  Load user profile
///////////////////////////////////////////////////////////////////////////////
    ListInit(pUI->InfoList);

    UsrLoadUserDefaultInfo(pUI->InfoList);

    return (pUI);

}



static UserInfo *UsrGetUserFromStrings(char **ppszStrings)
{

    int             iFieldsCount = StrStringsCount(ppszStrings);

    if (iFieldsCount < usrMax)
        return (NULL);

    char            szPassword[512] = "";

    if (StrDeCrypt(ppszStrings[usrPassword], szPassword) == NULL)
        return (NULL);


    UserInfo       *pUI = (UserInfo *) SysAlloc(sizeof(UserInfo));

    if (pUI == NULL)
        return (NULL);

    pUI->pszDomain = SysStrDup(ppszStrings[usrDomain]);
    pUI->uUserID = (unsigned int) atol(ppszStrings[usrID]);
    pUI->pszName = SysStrDup(ppszStrings[usrName]);
    pUI->pszPassword = SysStrDup(szPassword);
    pUI->pszPath = SysStrDup(ppszStrings[usrPath]);
    pUI->pszType = SysStrDup(ppszStrings[usrType]);

///////////////////////////////////////////////////////////////////////////////
//  Load user profile
///////////////////////////////////////////////////////////////////////////////
    ListInit(pUI->InfoList);

    char            szUsrFilePath[SYS_MAX_PATH] = "";

    UsrGetUserPath(pUI, szUsrFilePath);

    strcat(szUsrFilePath, USER_PROFILE_FILE);

    UsrLoadUserInfo(pUI->InfoList, pUI->uUserID, szUsrFilePath);

    return (pUI);

}



void            UsrFreeUserInfo(UserInfo * pUI)
{

    UsrFreeInfoList(pUI->InfoList);

    if (pUI->pszDomain != NULL)
        SysFree(pUI->pszDomain);

    if (pUI->pszPassword != NULL)
        SysFree(pUI->pszPassword);

    if (pUI->pszName != NULL)
        SysFree(pUI->pszName);

    if (pUI->pszPath != NULL)
        SysFree(pUI->pszPath);

    if (pUI->pszType != NULL)
        SysFree(pUI->pszType);

    SysFree(pUI);

}



char           *UsrGetUserInfoVar(UserInfo * pUI, const char *pszName,
                        const char *pszDefault)
{

    UserInfoVar    *pUIV = UsrGetUserVar(pUI->InfoList, pszName);

    if (pUIV != NULL)
        return (SysStrDup(pUIV->pszValue));

    return ((pszDefault != NULL) ? SysStrDup(pszDefault) : NULL);

}



int             UsrSetUserInfoVar(UserInfo * pUI, const char *pszName,
                        const char *pszValue)
{

    UserInfoVar    *pUIV = UsrGetUserVar(pUI->InfoList, pszName);

    if (pUIV != NULL)
    {
        SysFree(pUIV->pszValue);

        pUIV->pszValue = SysStrDup(pszValue);
    }
    else
    {
        UserInfoVar    *pUIV = UsrAllocVar(pszName, pszValue);

        if (pUIV == NULL)
            return (ErrGetErrorCode());

        ListAddTail(pUI->InfoList, (PLISTLINK) pUIV);
    }

    return (0);

}



char          **UsrGetProfileVars(UserInfo * pUI)
{

    int             iVarsCount = ListGetCount(pUI->InfoList);
    char          **ppszVars = (char **) SysAlloc((iVarsCount + 1) * sizeof(char *));

    if (ppszVars == NULL)
        return (NULL);


    int             iCurrVar = 0;
    UserInfoVar    *pUIV = (UserInfoVar *) ListFirst(pUI->InfoList);

    for (; pUIV != INVALID_SLIST_PTR; pUIV = (UserInfoVar *)
            ListNext(pUI->InfoList, (PLISTLINK) pUIV))
        ppszVars[iCurrVar++] = SysStrDup(pUIV->pszName);

    ppszVars[iCurrVar] = NULL;

    return (ppszVars);

}



static UserInfoVar *UsrAllocVar(const char *pszName, const char *pszValue)
{

    UserInfoVar    *pUIV = (UserInfoVar *) SysAlloc(sizeof(UserInfoVar));

    if (pUIV == NULL)
        return (NULL);

    ListLinkInit(pUIV);
    pUIV->pszName = SysStrDup(pszName);
    pUIV->pszValue = SysStrDup(pszValue);

    return (pUIV);

}



static void     UsrFreeVar(UserInfoVar * pUIV)
{

    SysFree(pUIV->pszName);
    SysFree(pUIV->pszValue);

    SysFree(pUIV);

}



static void     UsrFreeInfoList(HSLIST & InfoList)
{

    UserInfoVar    *pUIV;

    while ((pUIV = (UserInfoVar *) ListRemove(InfoList)) != INVALID_SLIST_PTR)
        UsrFreeVar(pUIV);

}



static UserInfoVar *UsrGetUserVar(HSLIST & InfoList, const char *pszName)
{

    UserInfoVar    *pUIV = (UserInfoVar *) ListFirst(InfoList);

    for (; pUIV != INVALID_SLIST_PTR; pUIV = (UserInfoVar *)
            ListNext(InfoList, (PLISTLINK) pUIV))
        if (strcmp(pUIV->pszName, pszName) == 0)
            return (pUIV);

    return (NULL);

}



static int      UsrWriteInfoList(HSLIST & InfoList, FILE * pProfileFile)
{

    UserInfoVar    *pUIV = (UserInfoVar *) ListFirst(InfoList);

    for (; pUIV != INVALID_SLIST_PTR; pUIV = (UserInfoVar *)
            ListNext(InfoList, (PLISTLINK) pUIV))
    {
///////////////////////////////////////////////////////////////////////////////
//  Write variabile name
///////////////////////////////////////////////////////////////////////////////
        char           *pszQuoted = StrQuote(pUIV->pszName, '"');

        if (pszQuoted == NULL)
            return (ErrGetErrorCode());

        fprintf(pProfileFile, "%s\t", pszQuoted);

        SysFree(pszQuoted);

///////////////////////////////////////////////////////////////////////////////
//  Write variabile value
///////////////////////////////////////////////////////////////////////////////
        pszQuoted = StrQuote(pUIV->pszValue, '"');

        if (pszQuoted == NULL)
            return (ErrGetErrorCode());

        fprintf(pProfileFile, "%s\n", pszQuoted);

        SysFree(pszQuoted);
    }

    return (0);

}



static int      UsrLoadUserInfo(HSLIST & InfoList, unsigned int uUserID,
                        const char *pszFilePath)
{

    RLCK_HANDLE     ProfileLockID = RLckLockSH(uUserID, RES_PROFILE);

    if (ProfileLockID == INVALID_RLCK_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pProfileFile = fopen(pszFilePath, "rt");

    if (pProfileFile == NULL)
    {
        ErrSetErrorCode(ERR_NO_USER_PRFILE);
        RLckUnlockSH(ProfileLockID);
        return (ERR_NO_USER_PRFILE);
    }

    char            szProfileLine[USR_TABLE_LINE_MAX] = "";

    while (MscFGets(szProfileLine, sizeof(szProfileLine) - 1, pProfileFile) != NULL)
    {
        if (szProfileLine[0] == TAB_COMMENT_CHAR)
            continue;

        char          **ppszStrings = StrGetTabLineStrings(szProfileLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if (iFieldsCount == 2)
        {
            UserInfoVar    *pUIV = UsrAllocVar(ppszStrings[0], ppszStrings[1]);

            if (pUIV != NULL)
                ListAddTail(InfoList, (PLISTLINK) pUIV);
        }

        StrFreeStrings(ppszStrings);
    }

    fclose(pProfileFile);

    RLckUnlockSH(ProfileLockID);

    return (0);

}



static int      UsrLoadUserDefaultInfo(HSLIST & InfoList)
{

    char            szUserDefFilePath[SYS_MAX_PATH] = "";

    CfgGetRootPath(szUserDefFilePath);

    strcat(szUserDefFilePath, DEFAULT_USER_PROFILE_FILE);


    SHB_HANDLE      hSWMRResource = SWMRCreateReadLock(SWMR_UserDefVars);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pProfileFile = fopen(szUserDefFilePath, "rt");

    if (pProfileFile == NULL)
    {
        ErrSetErrorCode(ERR_NO_USER_DEFAULT_PRFILE);
        SWMRCloseReadUnlock(hSWMRResource);
        return (ERR_NO_USER_DEFAULT_PRFILE);
    }

    char            szProfileLine[USR_TABLE_LINE_MAX] = "";

    while (MscFGets(szProfileLine, sizeof(szProfileLine) - 1, pProfileFile) != NULL)
    {
        if (szProfileLine[0] == TAB_COMMENT_CHAR)
            continue;

        char          **ppszStrings = StrGetTabLineStrings(szProfileLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if (iFieldsCount == 2)
        {
            UserInfoVar    *pUIV = UsrAllocVar(ppszStrings[0], ppszStrings[1]);

            if (pUIV != NULL)
                ListAddTail(InfoList, (PLISTLINK) pUIV);
        }

        StrFreeStrings(ppszStrings);
    }

    fclose(pProfileFile);

    SWMRCloseReadUnlock(hSWMRResource);

    return (0);

}



static int      UsrAliasLookupNameLK(const char *pszDomain, const char *pszAlias,
                        char *pszName)
{

    char            szAlsFilePath[SYS_MAX_PATH] = "";

    UsrGetAliasFilePath(szAlsFilePath);


    FILE           *pAlsFile = fopen(szAlsFilePath, "rt");

    if (pAlsFile == NULL)
    {
        ErrSetErrorCode(ERR_ALIAS_FILE_NOT_FOUND);
        return (0);
    }

    char            szAlsLine[USR_ALIAS_LINE_MAX] = "";

    while (MscGetConfigLine(szAlsLine, sizeof(szAlsLine) - 1, pAlsFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szAlsLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if ((iFieldsCount >= alsMax) && (stricmp(pszDomain, ppszStrings[alsDomain]) == 0) &&
                StrIWildMatch(pszAlias, ppszStrings[alsAlias]))
        {
            if (pszName != NULL)
                strcpy(pszName, ppszStrings[alsName]);

            StrFreeStrings(ppszStrings);
            fclose(pAlsFile);

            return (1);
        }

        StrFreeStrings(ppszStrings);
    }

    fclose(pAlsFile);

    return (0);

}



int             UsrAliasLookupName(const char *pszDomain, const char *pszAlias,
                        char *pszName)
{

    SHB_HANDLE      hSWMRResource = SWMRCreateReadLock(SWMR_AliasTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (0);


    int             iLookupResult = UsrAliasLookupNameLK(pszDomain, pszAlias, pszName);


    SWMRCloseReadUnlock(hSWMRResource);

    return (iLookupResult);

}



static int      UsrWriteAlias(FILE * pAlsFile, AliasInfo * pAI)
{

///////////////////////////////////////////////////////////////////////////////
//  Domain
///////////////////////////////////////////////////////////////////////////////
    char           *pszQuoted = StrQuote(pAI->pszDomain, '"');

    if (pszQuoted == NULL)
        return (ErrGetErrorCode());

    fprintf(pAlsFile, "%s\t", pszQuoted);

    SysFree(pszQuoted);

///////////////////////////////////////////////////////////////////////////////
//  Alias
///////////////////////////////////////////////////////////////////////////////
    pszQuoted = StrQuote(pAI->pszAlias, '"');

    if (pszQuoted == NULL)
        return (ErrGetErrorCode());

    fprintf(pAlsFile, "%s\t", pszQuoted);

    SysFree(pszQuoted);

///////////////////////////////////////////////////////////////////////////////
//  Account name
///////////////////////////////////////////////////////////////////////////////
    pszQuoted = StrQuote(pAI->pszName, '"');

    if (pszQuoted == NULL)
        return (ErrGetErrorCode());

    fprintf(pAlsFile, "%s\n", pszQuoted);

    SysFree(pszQuoted);

    return (0);

}



AliasInfo      *UsrAllocAlias(const char *pszDomain, const char *pszAlias,
                        const char *pszName)
{

    AliasInfo      *pAI = (AliasInfo *) SysAlloc(sizeof(AliasInfo));

    if (pAI == NULL)
        return (NULL);

    pAI->pszDomain = (pszDomain != NULL) ? SysStrDup(pszDomain) : NULL;
    pAI->pszAlias = (pszAlias != NULL) ? SysStrDup(pszAlias) : NULL;
    pAI->pszName = (pszName != NULL) ? SysStrDup(pszName) : NULL;

    return (pAI);

}



void            UsrFreeAlias(AliasInfo * pAI)
{

    SysFreeCheck(pAI->pszDomain);
    SysFreeCheck(pAI->pszAlias);
    SysFreeCheck(pAI->pszName);

    SysFree(pAI);

}



int             UsrAddAlias(AliasInfo * pAI)
{

    char            szAlsFilePath[SYS_MAX_PATH] = "";

    UsrGetAliasFilePath(szAlsFilePath);


    SHB_HANDLE      hSWMRResource = SWMRCreateWriteLock(SWMR_AliasTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pAlsFile = fopen(szAlsFilePath, "r+t");

    if (pAlsFile == NULL)
    {
        ErrSetErrorCode(ERR_ALIAS_FILE_NOT_FOUND);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ERR_ALIAS_FILE_NOT_FOUND);
    }

    char            szAlsLine[USR_ALIAS_LINE_MAX] = "";

    while (MscFGets(szAlsLine, sizeof(szAlsLine) - 1, pAlsFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szAlsLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if ((iFieldsCount >= alsMax) && (stricmp(pAI->pszDomain, ppszStrings[alsDomain]) == 0) &&
                (stricmp(pAI->pszAlias, ppszStrings[alsAlias]) == 0))
        {
            StrFreeStrings(ppszStrings);
            fclose(pAlsFile);
            SWMRCloseWriteUnlock(hSWMRResource);

            ErrSetErrorCode(ERR_ALIAS_EXIST);
            return (ERR_ALIAS_EXIST);
        }

        StrFreeStrings(ppszStrings);
    }

    fseek(pAlsFile, 0, SEEK_END);

    if (UsrWriteAlias(pAlsFile, pAI) < 0)
    {
        fclose(pAlsFile);
        SWMRCloseWriteUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_WRITE_ALIAS_FILE);
        return (ERR_WRITE_ALIAS_FILE);
    }

    fclose(pAlsFile);

    SWMRCloseWriteUnlock(hSWMRResource);

    return (0);

}



int             UsrRemoveAlias(const char *pszDomain, const char *pszAlias)
{

    char            szAlsFilePath[SYS_MAX_PATH] = "";

    UsrGetAliasFilePath(szAlsFilePath);

    char            szTmpFile[SYS_MAX_PATH] = "";

    SysGetTmpFile(szTmpFile);


    SHB_HANDLE      hSWMRResource = SWMRCreateWriteLock(SWMR_AliasTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
    {
        ErrorPush();
        CheckRemoveFile(szTmpFile);
        return (ErrorPop());
    }


    FILE           *pAlsFile = fopen(szAlsFilePath, "rt");

    if (pAlsFile == NULL)
    {
        SWMRCloseWriteUnlock(hSWMRResource);
        CheckRemoveFile(szTmpFile);

        ErrSetErrorCode(ERR_ALIAS_FILE_NOT_FOUND);
        return (ERR_ALIAS_FILE_NOT_FOUND);
    }

    FILE           *pTmpFile = fopen(szTmpFile, "wt");

    if (pTmpFile == NULL)
    {
        fclose(pAlsFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        CheckRemoveFile(szTmpFile);

        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }

    int             iAliasFound = 0;
    char            szAlsLine[USR_ALIAS_LINE_MAX] = "";

    while (MscFGets(szAlsLine, sizeof(szAlsLine) - 1, pAlsFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szAlsLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if ((iFieldsCount >= alsMax) && (stricmp(pszDomain, ppszStrings[alsDomain]) == 0) &&
                (stricmp(pszAlias, ppszStrings[alsAlias]) == 0))
        {

            ++iAliasFound;

        }
        else
            fprintf(pTmpFile, "%s\n", szAlsLine);

        StrFreeStrings(ppszStrings);
    }

    fclose(pAlsFile);
    fclose(pTmpFile);

    if (iAliasFound == 0)
    {
        SysRemove(szTmpFile);
        SWMRCloseWriteUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_ALIAS_NOT_FOUND);
        return (ERR_ALIAS_NOT_FOUND);
    }

    char            szTmpAlsFilePath[SYS_MAX_PATH] = "";

    sprintf(szTmpAlsFilePath, "%s.tmp", szAlsFilePath);

    if (MscMoveFile(szAlsFilePath, szTmpAlsFilePath) < 0)
    {
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrGetErrorCode());
    }

    if (MscMoveFile(szTmpFile, szAlsFilePath) < 0)
    {
        MscMoveFile(szTmpAlsFilePath, szAlsFilePath);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrGetErrorCode());
    }

    SysRemove(szTmpAlsFilePath);

    SWMRCloseWriteUnlock(hSWMRResource);

    return (0);

}



int             UsrRemoveDomainAliases(const char *pszDomain)
{

    char            szAlsFilePath[SYS_MAX_PATH] = "";

    UsrGetAliasFilePath(szAlsFilePath);

    char            szTmpFile[SYS_MAX_PATH] = "";

    SysGetTmpFile(szTmpFile);


    SHB_HANDLE      hSWMRResource = SWMRCreateWriteLock(SWMR_AliasTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
    {
        ErrorPush();
        CheckRemoveFile(szTmpFile);
        return (ErrorPop());
    }


    FILE           *pAlsFile = fopen(szAlsFilePath, "rt");

    if (pAlsFile == NULL)
    {
        SWMRCloseWriteUnlock(hSWMRResource);
        CheckRemoveFile(szTmpFile);

        ErrSetErrorCode(ERR_ALIAS_FILE_NOT_FOUND);
        return (ERR_ALIAS_FILE_NOT_FOUND);
    }

    FILE           *pTmpFile = fopen(szTmpFile, "wt");

    if (pTmpFile == NULL)
    {
        fclose(pAlsFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        CheckRemoveFile(szTmpFile);

        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }

    int             iAliasFound = 0;
    char            szAlsLine[USR_ALIAS_LINE_MAX] = "";

    while (MscFGets(szAlsLine, sizeof(szAlsLine) - 1, pAlsFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szAlsLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if ((iFieldsCount >= alsMax) && (stricmp(pszDomain, ppszStrings[alsDomain]) == 0))
        {

            ++iAliasFound;

        }
        else
            fprintf(pTmpFile, "%s\n", szAlsLine);

        StrFreeStrings(ppszStrings);
    }

    fclose(pAlsFile);
    fclose(pTmpFile);

    if (iAliasFound == 0)
    {
        SysRemove(szTmpFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (0);
    }


    char            szTmpAlsFilePath[SYS_MAX_PATH] = "";

    sprintf(szTmpAlsFilePath, "%s.tmp", szAlsFilePath);

    if (MscMoveFile(szAlsFilePath, szTmpAlsFilePath) < 0)
    {
        ErrorPush();
        SysRemove(szTmpFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrorPop());
    }

    if (MscMoveFile(szTmpFile, szAlsFilePath) < 0)
    {
        ErrorPush();
        MscMoveFile(szTmpAlsFilePath, szAlsFilePath);
        SysRemove(szTmpFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrorPop());
    }

    SysRemove(szTmpAlsFilePath);

    SWMRCloseWriteUnlock(hSWMRResource);

    return (0);

}



static int      UsrRemoveUserAlias(const char *pszName)
{

    char            szAlsFilePath[SYS_MAX_PATH] = "";

    UsrGetAliasFilePath(szAlsFilePath);

    char            szTmpFile[SYS_MAX_PATH] = "";

    SysGetTmpFile(szTmpFile);


    SHB_HANDLE      hSWMRResource = SWMRCreateWriteLock(SWMR_AliasTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pAlsFile = fopen(szAlsFilePath, "rt");

    if (pAlsFile == NULL)
    {
        SWMRCloseWriteUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_ALIAS_FILE_NOT_FOUND);
        return (ERR_ALIAS_FILE_NOT_FOUND);
    }

    FILE           *pTmpFile = fopen(szTmpFile, "wt");

    if (pTmpFile == NULL)
    {
        fclose(pAlsFile);
        SWMRCloseWriteUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }

    int             iAliasFound = 0;
    char            szAlsLine[USR_ALIAS_LINE_MAX] = "";

    while (MscFGets(szAlsLine, sizeof(szAlsLine) - 1, pAlsFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szAlsLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if ((iFieldsCount >= alsMax) && (stricmp(pszName, ppszStrings[alsName]) == 0))
        {

            ++iAliasFound;

        }
        else
            fprintf(pTmpFile, "%s\n", szAlsLine);

        StrFreeStrings(ppszStrings);
    }

    fclose(pAlsFile);
    fclose(pTmpFile);

    if (iAliasFound == 0)
    {
        SysRemove(szTmpFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (0);
    }

    char            szTmpAlsFilePath[SYS_MAX_PATH] = "";

    sprintf(szTmpAlsFilePath, "%s.tmp", szAlsFilePath);

    if (MscMoveFile(szAlsFilePath, szTmpAlsFilePath) < 0)
    {
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrGetErrorCode());
    }

    if (MscMoveFile(szTmpFile, szAlsFilePath) < 0)
    {
        MscMoveFile(szTmpAlsFilePath, szAlsFilePath);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrGetErrorCode());
    }

    SysRemove(szTmpAlsFilePath);

    SWMRCloseWriteUnlock(hSWMRResource);

    return (0);

}



static UserInfo *UsrGetUserByNameLK(const char *pszDomain, const char *pszName)
{

    char            szUsrFilePath[SYS_MAX_PATH] = "";

    UsrGetTableFilePath(szUsrFilePath);


    FILE           *pUsrFile = fopen(szUsrFilePath, "rt");

    if (pUsrFile == NULL)
    {
        ErrSetErrorCode(ERR_USERS_FILE_NOT_FOUND);
        return (NULL);
    }

    char            szUsrLine[USR_TABLE_LINE_MAX] = "";

    while (MscFGets(szUsrLine, sizeof(szUsrLine) - 1, pUsrFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szUsrLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if ((iFieldsCount >= usrMax) && (stricmp(pszDomain, ppszStrings[usrDomain]) == 0) &&
                (stricmp(pszName, ppszStrings[usrName]) == 0))
        {
            UserInfo       *pUI = UsrGetUserFromStrings(ppszStrings);

            StrFreeStrings(ppszStrings);
            fclose(pUsrFile);

            return (pUI);
        }

        StrFreeStrings(ppszStrings);
    }

    fclose(pUsrFile);


    ErrSetErrorCode(ERR_USER_NOT_FOUND);

    return (NULL);

}



UserInfo       *UsrGetUserByName(const char *pszDomain, const char *pszName)
{

    SHB_HANDLE      hSWMRResource = SWMRCreateReadLock(SWMR_UserTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (NULL);


    UserInfo       *pUI = UsrGetUserByNameLK(pszDomain, pszName);


    SWMRCloseReadUnlock(hSWMRResource);

    return (pUI);

}



UserInfo       *UsrGetUserByNameOrAlias(const char *pszDomain, const char *pszName,
                        char *pszRealUser)
{

    char           *pszAliasedUser = NULL;
    char            szAliasedUser[MAX_ADDR_NAME] = "";

    if (UsrAliasLookupName(pszDomain, pszName, szAliasedUser))
        pszAliasedUser = szAliasedUser;


    SHB_HANDLE      hSWMRResource = SWMRCreateReadLock(SWMR_UserTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (NULL);


    UserInfo       *pUI = UsrGetUserByNameLK(pszDomain, pszName);

    if ((pUI == NULL) && (pszAliasedUser != NULL))
    {
        pUI = UsrGetUserByNameLK(pszDomain, pszAliasedUser);

        pszName = pszAliasedUser;
    }

    if (pszRealUser != NULL)
        strcpy(pszRealUser, pszName);


    SWMRCloseReadUnlock(hSWMRResource);

    return (pUI);

}



static UserInfo *UsrGetUserByIDLK(const char *pszDomain, unsigned int uUserID)
{

    char            szUsrFilePath[SYS_MAX_PATH] = "";

    UsrGetTableFilePath(szUsrFilePath);


    FILE           *pUsrFile = fopen(szUsrFilePath, "rt");

    if (pUsrFile == NULL)
    {
        ErrSetErrorCode(ERR_USERS_FILE_NOT_FOUND);
        return (NULL);
    }

    char            szUsrLine[USR_TABLE_LINE_MAX] = "";

    while (MscFGets(szUsrLine, sizeof(szUsrLine) - 1, pUsrFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szUsrLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if ((iFieldsCount >= usrMax) && (stricmp(pszDomain, ppszStrings[usrDomain]) == 0) &&
                (uUserID == (unsigned int) atol(ppszStrings[usrID])))
        {
            UserInfo       *pUI = UsrGetUserFromStrings(ppszStrings);

            StrFreeStrings(ppszStrings);
            fclose(pUsrFile);

            return (pUI);
        }

        StrFreeStrings(ppszStrings);
    }

    fclose(pUsrFile);

    return (NULL);

}



UserInfo       *UsrGetUserByID(const char *pszDomain, unsigned int uUserID)
{

    SHB_HANDLE      hSWMRResource = SWMRCreateReadLock(SWMR_UserTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (NULL);


    UserInfo       *pUI = UsrGetUserByIDLK(pszDomain, uUserID);


    SWMRCloseReadUnlock(hSWMRResource);

    return (pUI);

}



int             UsrRemoveUser(const char *pszDomain, const char *pszName,
                        unsigned int uUserID)
{

    char            szUsrFilePath[SYS_MAX_PATH] = "";

    UsrGetTableFilePath(szUsrFilePath);

    char            szTmpFile[SYS_MAX_PATH] = "";

    SysGetTmpFile(szTmpFile);


    SHB_HANDLE      hSWMRResource = SWMRCreateWriteLock(SWMR_UserTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
    {
        ErrorPush();
        CheckRemoveFile(szTmpFile);
        return (ErrorPop());
    }


    FILE           *pUsrFile = fopen(szUsrFilePath, "rt");

    if (pUsrFile == NULL)
    {
        SWMRCloseWriteUnlock(hSWMRResource);
        CheckRemoveFile(szTmpFile);

        ErrSetErrorCode(ERR_USERS_FILE_NOT_FOUND);
        return (ERR_USERS_FILE_NOT_FOUND);
    }

    FILE           *pTmpFile = fopen(szTmpFile, "wt");

    if (pTmpFile == NULL)
    {
        fclose(pUsrFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        CheckRemoveFile(szTmpFile);

        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }


    UserInfo       *pUI = NULL;
    char            szUsrLine[USR_TABLE_LINE_MAX] = "";

    while (MscFGets(szUsrLine, sizeof(szUsrLine) - 1, pUsrFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szUsrLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if ((iFieldsCount >= usrMax) && (stricmp(pszDomain, ppszStrings[usrDomain]) == 0) &&
                (((uUserID != 0) && (uUserID == (unsigned int) atol(ppszStrings[usrID]))) ||
                        ((pszName != NULL) && (stricmp(pszName, ppszStrings[usrName]) == 0))))
        {
            if (pUI != NULL)
                UsrFreeUserInfo(pUI);

            pUI = UsrGetUserFromStrings(ppszStrings);
        }
        else
            fprintf(pTmpFile, "%s\n", szUsrLine);

        StrFreeStrings(ppszStrings);
    }

    fclose(pUsrFile);
    fclose(pTmpFile);

    if (pUI == NULL)
    {
        SysRemove(szTmpFile);
        SWMRCloseWriteUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_USER_NOT_FOUND);
        return (ERR_USER_NOT_FOUND);
    }

    char            szTmpUsrFilePath[SYS_MAX_PATH] = "";

    sprintf(szTmpUsrFilePath, "%s.tmp", szUsrFilePath);

    if (MscMoveFile(szUsrFilePath, szTmpUsrFilePath) < 0)
    {
        ErrorPush();
        UsrFreeUserInfo(pUI);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrorPop());
    }

    if (MscMoveFile(szTmpFile, szUsrFilePath) < 0)
    {
        ErrorPush();
        MscMoveFile(szTmpUsrFilePath, szUsrFilePath);
        UsrFreeUserInfo(pUI);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrorPop());
    }

    SysRemove(szTmpUsrFilePath);

    SWMRCloseWriteUnlock(hSWMRResource);


    GwLkRemoveUserLinks(pUI->pszDomain, pUI->pszName);

    ExAlRemoveUserAliases(pUI->pszDomain, pUI->pszName);


    UsrRemoveUserAlias(pUI->pszName);

///////////////////////////////////////////////////////////////////////////////
//  Try ( if defined ) to remove external auth user
///////////////////////////////////////////////////////////////////////////////
    UAthDelUser(AUTH_SERVICE_POP3, pUI);


    UsrDropUserEnv(pUI);

    UsrFreeUserInfo(pUI);

    return (0);

}




int             UsrModifyUser(UserInfo * pUI)
{

    char            szUsrFilePath[SYS_MAX_PATH] = "";

    UsrGetTableFilePath(szUsrFilePath);

    char            szTmpFile[SYS_MAX_PATH] = "";

    SysGetTmpFile(szTmpFile);


    SHB_HANDLE      hSWMRResource = SWMRCreateWriteLock(SWMR_UserTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
    {
        ErrorPush();
        CheckRemoveFile(szTmpFile);
        return (ErrorPop());
    }


    FILE           *pUsrFile = fopen(szUsrFilePath, "rt");

    if (pUsrFile == NULL)
    {
        SWMRCloseWriteUnlock(hSWMRResource);
        CheckRemoveFile(szTmpFile);

        ErrSetErrorCode(ERR_USERS_FILE_NOT_FOUND);
        return (ERR_USERS_FILE_NOT_FOUND);
    }

    FILE           *pTmpFile = fopen(szTmpFile, "wt");

    if (pTmpFile == NULL)
    {
        fclose(pUsrFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        CheckRemoveFile(szTmpFile);

        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }


    UserInfo       *pFoundUI = NULL;
    char            szUsrLine[USR_TABLE_LINE_MAX] = "";

    while (MscFGets(szUsrLine, sizeof(szUsrLine) - 1, pUsrFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szUsrLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if ((iFieldsCount >= usrMax) && (pFoundUI == NULL) &&
                (pUI->uUserID == (unsigned int) atol(ppszStrings[usrID])) &&
                (stricmp(pUI->pszDomain, ppszStrings[usrDomain]) == 0) &&
                (stricmp(pUI->pszName, ppszStrings[usrName]) == 0))
        {
            if ((UsrWriteUser(pUI, pTmpFile) < 0) ||
                    ((pFoundUI = UsrGetUserFromStrings(ppszStrings)) == NULL))
            {
                ErrorPush();
                fclose(pUsrFile);
                fclose(pTmpFile);
                SysRemove(szTmpFile);
                SWMRCloseWriteUnlock(hSWMRResource);
                return (ErrorPop());
            }
        }
        else
            fprintf(pTmpFile, "%s\n", szUsrLine);

        StrFreeStrings(ppszStrings);
    }

    fclose(pUsrFile);
    fclose(pTmpFile);

    if (pFoundUI == NULL)
    {
        SysRemove(szTmpFile);
        SWMRCloseWriteUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_USER_NOT_FOUND);
        return (ERR_USER_NOT_FOUND);
    }

///////////////////////////////////////////////////////////////////////////////
//
//  Adjust for fields changes
//
///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
//  Try ( if defined ) to modify external auth user
///////////////////////////////////////////////////////////////////////////////
    UAthModifyUser(AUTH_SERVICE_POP3, pFoundUI);


    UsrFreeUserInfo(pFoundUI);



    char            szTmpUsrFilePath[SYS_MAX_PATH] = "";

    sprintf(szTmpUsrFilePath, "%s.tmp", szUsrFilePath);

    if (MscMoveFile(szUsrFilePath, szTmpUsrFilePath) < 0)
    {
        ErrorPush();
        SysRemove(szTmpFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrorPop());
    }

    if (MscMoveFile(szTmpFile, szUsrFilePath) < 0)
    {
        ErrorPush();
        MscMoveFile(szTmpUsrFilePath, szUsrFilePath);
        SysRemove(szTmpFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrorPop());
    }

    SysRemove(szTmpUsrFilePath);

    SWMRCloseWriteUnlock(hSWMRResource);

    return (0);

}




int             UsrRemoveDomainUsers(const char *pszDomain)
{

    char            szUsrFilePath[SYS_MAX_PATH] = "";

    UsrGetTableFilePath(szUsrFilePath);

    char            szTmpFile[SYS_MAX_PATH] = "";

    SysGetTmpFile(szTmpFile);


    SHB_HANDLE      hSWMRResource = SWMRCreateWriteLock(SWMR_UserTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
    {
        ErrorPush();
        CheckRemoveFile(szTmpFile);
        return (ErrorPop());
    }


    FILE           *pUsrFile = fopen(szUsrFilePath, "rt");

    if (pUsrFile == NULL)
    {
        SWMRCloseWriteUnlock(hSWMRResource);
        CheckRemoveFile(szTmpFile);

        ErrSetErrorCode(ERR_USERS_FILE_NOT_FOUND);
        return (ERR_USERS_FILE_NOT_FOUND);
    }

    FILE           *pTmpFile = fopen(szTmpFile, "wt");

    if (pTmpFile == NULL)
    {
        fclose(pUsrFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        CheckRemoveFile(szTmpFile);

        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }


    int             iUsersFound = 0;
    char            szUsrLine[USR_TABLE_LINE_MAX] = "";

    while (MscFGets(szUsrLine, sizeof(szUsrLine) - 1, pUsrFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szUsrLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if ((iFieldsCount >= usrMax) && (stricmp(pszDomain, ppszStrings[usrDomain]) == 0))
        {

            ++iUsersFound;

        }
        else
            fprintf(pTmpFile, "%s\n", szUsrLine);

        StrFreeStrings(ppszStrings);
    }

    fclose(pUsrFile);
    fclose(pTmpFile);

    if (iUsersFound == 0)
    {
        SysRemove(szTmpFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (0);
    }


    char            szTmpUsrFilePath[SYS_MAX_PATH] = "";

    sprintf(szTmpUsrFilePath, "%s.tmp", szUsrFilePath);

    if (MscMoveFile(szUsrFilePath, szTmpUsrFilePath) < 0)
    {
        ErrorPush();
        SysRemove(szTmpFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrorPop());
    }

    if (MscMoveFile(szTmpFile, szUsrFilePath) < 0)
    {
        ErrorPush();
        MscMoveFile(szTmpUsrFilePath, szUsrFilePath);
        SysRemove(szTmpFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrorPop());
    }

    SysRemove(szTmpUsrFilePath);

    SWMRCloseWriteUnlock(hSWMRResource);

    return (0);

}



static int      UsrDropUserEnv(UserInfo * pUI)
{

///////////////////////////////////////////////////////////////////////////////
//  User directory cleaning
///////////////////////////////////////////////////////////////////////////////
    char            szUsrUserPath[SYS_MAX_PATH] = "";

    UsrGetUserPath(pUI, szUsrUserPath, 0);

    if (MscClearDirectory(szUsrUserPath) < 0)
        return (ErrGetErrorCode());

///////////////////////////////////////////////////////////////////////////////
//  User directory removing
///////////////////////////////////////////////////////////////////////////////
    if (SysRemoveDir(szUsrUserPath) < 0)
        return (ErrGetErrorCode());


    return (0);

}



static int      UsrWriteUser(UserInfo * pUI, FILE * pUsrFile)
{

///////////////////////////////////////////////////////////////////////////////
//  Domain
///////////////////////////////////////////////////////////////////////////////
    char           *pszQuoted = StrQuote(pUI->pszDomain, '"');

    if (pszQuoted == NULL)
        return (ErrGetErrorCode());

    fprintf(pUsrFile, "%s\t", pszQuoted);

    SysFree(pszQuoted);

///////////////////////////////////////////////////////////////////////////////
//  Name
///////////////////////////////////////////////////////////////////////////////
    pszQuoted = StrQuote(pUI->pszName, '"');

    if (pszQuoted == NULL)
        return (ErrGetErrorCode());

    fprintf(pUsrFile, "%s\t", pszQuoted);

    SysFree(pszQuoted);

///////////////////////////////////////////////////////////////////////////////
//  Password
///////////////////////////////////////////////////////////////////////////////
    char            szPassword[512] = "";

    StrCrypt(pUI->pszPassword, szPassword);

    pszQuoted = StrQuote(szPassword, '"');

    if (pszQuoted == NULL)
        return (ErrGetErrorCode());

    fprintf(pUsrFile, "%s\t", pszQuoted);

    SysFree(pszQuoted);

///////////////////////////////////////////////////////////////////////////////
//  UserID
///////////////////////////////////////////////////////////////////////////////
    fprintf(pUsrFile, "%u\t", pUI->uUserID);

///////////////////////////////////////////////////////////////////////////////
//  Directory
///////////////////////////////////////////////////////////////////////////////
    pszQuoted = StrQuote(pUI->pszPath, '"');

    if (pszQuoted == NULL)
        return (ErrGetErrorCode());

    fprintf(pUsrFile, "%s\t", pszQuoted);

    SysFree(pszQuoted);

///////////////////////////////////////////////////////////////////////////////
//  User type
///////////////////////////////////////////////////////////////////////////////
    pszQuoted = StrQuote(pUI->pszType, '"');

    if (pszQuoted == NULL)
        return (ErrGetErrorCode());

    fprintf(pUsrFile, "%s\n", pszQuoted);

    SysFree(pszQuoted);


    return (0);

}



int             UsrAddUser(UserInfo * pUI)
{

    if (UsrAliasLookupName(pUI->pszDomain, pUI->pszName))
    {
        ErrSetErrorCode(ERR_ALIAS_EXIST);
        return (ERR_ALIAS_EXIST);
    }


    char            szUsrFilePath[SYS_MAX_PATH] = "";

    UsrGetTableFilePath(szUsrFilePath);


    SHB_HANDLE      hSWMRResource = SWMRCreateWriteLock(SWMR_UserTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pUsrFile = fopen(szUsrFilePath, "r+t");

    if (pUsrFile == NULL)
    {
        SWMRCloseWriteUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_USERS_FILE_NOT_FOUND);
        return (ERR_USERS_FILE_NOT_FOUND);
    }


    unsigned int    uMaxUserID = 0;
    char            szUsrLine[USR_TABLE_LINE_MAX] = "";

    while (MscFGets(szUsrLine, sizeof(szUsrLine) - 1, pUsrFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szUsrLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if (iFieldsCount >= usrMax)
        {
            if ((stricmp(pUI->pszDomain, ppszStrings[usrDomain]) == 0) &&
                    (stricmp(pUI->pszName, ppszStrings[usrName]) == 0))
            {
                ErrSetErrorCode(ERR_USER_EXIST);
                fclose(pUsrFile);
                SWMRCloseWriteUnlock(hSWMRResource);
                return (ERR_USER_EXIST);
            }

            unsigned int    uUserID = (unsigned int) atol(ppszStrings[usrID]);

            if (uUserID > uMaxUserID)
                uMaxUserID = uUserID;
        }

        StrFreeStrings(ppszStrings);
    }

    pUI->uUserID = uMaxUserID + 1;


    if (UsrPrepareUserEnv(pUI) < 0)
    {
        fclose(pUsrFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrGetErrorCode());
    }


    fseek(pUsrFile, 0, SEEK_END);

    if (UsrWriteUser(pUI, pUsrFile) < 0)
    {
        fclose(pUsrFile);
        SWMRCloseWriteUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_WRITE_USERS_FILE);
        return (ERR_WRITE_USERS_FILE);
    }

    fclose(pUsrFile);

    SWMRCloseWriteUnlock(hSWMRResource);

///////////////////////////////////////////////////////////////////////////////
//  Try ( if defined ) to add external auth user
///////////////////////////////////////////////////////////////////////////////
    UAthAddUser(AUTH_SERVICE_POP3, pUI);

    return (0);

}



static int      UsrPrepareUserEnv(UserInfo * pUI)
{

    char            szUsrUserPath[SYS_MAX_PATH] = "";

    UsrGetUserPath(pUI, szUsrUserPath, 0);

///////////////////////////////////////////////////////////////////////////////
//  Create main directory
///////////////////////////////////////////////////////////////////////////////
    if (SysMakeDir(szUsrUserPath) < 0)
        return (ErrGetErrorCode());

    if (UsrGetUserType(pUI) == usrTypeUser)
    {
///////////////////////////////////////////////////////////////////////////////
//  Create mailbox directory
///////////////////////////////////////////////////////////////////////////////
        char            szUsrMailboxPath[SYS_MAX_PATH] = "";

        strcpy(szUsrMailboxPath, szUsrUserPath);

        AppendSlash(szUsrMailboxPath);
        strcat(szUsrMailboxPath, USER_MAILBOX_DIR);

        if (SysMakeDir(szUsrMailboxPath) < 0)
        {
            MscClearDirectory(szUsrUserPath);
            SysRemoveDir(szUsrUserPath);
            return (ErrGetErrorCode());
        }
    }
    else
    {
///////////////////////////////////////////////////////////////////////////////
//  Create mailing list users file
///////////////////////////////////////////////////////////////////////////////
        char            szMLUsersFilePath[SYS_MAX_PATH] = "";

        strcpy(szMLUsersFilePath, szUsrUserPath);

        AppendSlash(szMLUsersFilePath);
        strcat(szMLUsersFilePath, MLUSERS_TABLE_FILE);

        if (MscCreateEmptyFile(szMLUsersFilePath) < 0)
        {
            MscClearDirectory(szUsrUserPath);
            SysRemoveDir(szUsrUserPath);
            return (ErrGetErrorCode());
        }
    }

///////////////////////////////////////////////////////////////////////////////
//  Create profile file
///////////////////////////////////////////////////////////////////////////////
    char            szUsrProfileFilePath[SYS_MAX_PATH] = "";

    strcpy(szUsrProfileFilePath, szUsrUserPath);

    AppendSlash(szUsrProfileFilePath);
    strcat(szUsrProfileFilePath, USER_PROFILE_FILE);

    FILE           *pProfileFile = fopen(szUsrProfileFilePath, "wt");

    if (pProfileFile == NULL)
    {
        MscClearDirectory(szUsrUserPath);
        SysRemoveDir(szUsrUserPath);

        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }

    UsrWriteInfoList(pUI->InfoList, pProfileFile);

    fclose(pProfileFile);


    return (0);

}




int             UsrFlushUserVars(UserInfo * pUI)
{

    char            szUsrUserPath[SYS_MAX_PATH] = "";

    UsrGetUserPath(pUI, szUsrUserPath, 0);

///////////////////////////////////////////////////////////////////////////////
//  Build profile file path
///////////////////////////////////////////////////////////////////////////////
    char            szUsrProfileFilePath[SYS_MAX_PATH] = "";

    strcpy(szUsrProfileFilePath, szUsrUserPath);

    AppendSlash(szUsrProfileFilePath);
    strcat(szUsrProfileFilePath, USER_PROFILE_FILE);


    RLCK_HANDLE     ProfLockID = RLckLockEX(pUI->uUserID, RES_PROFILE);

    if (ProfLockID == INVALID_RLCK_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pProfileFile = fopen(szUsrProfileFilePath, "wt");

    if (pProfileFile == NULL)
    {
        RLckUnlockEX(ProfLockID);

        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }

    UsrWriteInfoList(pUI->InfoList, pProfileFile);

    fclose(pProfileFile);


    RLckUnlockEX(ProfLockID);

    return (0);

}




int             UsrGetDBFileSnapShot(const char *pszFileName)
{

    char            szUsrFilePath[SYS_MAX_PATH] = "";

    UsrGetTableFilePath(szUsrFilePath);


    SHB_HANDLE      hSWMRResource = SWMRCreateReadLock(SWMR_UserTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    if (MscCopyFile(pszFileName, szUsrFilePath) < 0)
    {
        SWMRCloseReadUnlock(hSWMRResource);
        return (ErrGetErrorCode());
    }


    SWMRCloseReadUnlock(hSWMRResource);

    return (0);

}



USRF_HANDLE     UsrOpenDB(void)
{

    UsersDBScanData *pUDBSD = (UsersDBScanData *) SysAlloc(sizeof(UsersDBScanData));

    if (pUDBSD == NULL)
        return (INVALID_USRF_HANDLE);

    SysGetTmpFile(pUDBSD->szTmpDBFile);

    if (UsrGetDBFileSnapShot(pUDBSD->szTmpDBFile) < 0)
    {
        SysFree(pUDBSD);
        return (INVALID_USRF_HANDLE);
    }

    if ((pUDBSD->pDBFile = fopen(pUDBSD->szTmpDBFile, "rt")) == NULL)
    {
        SysRemove(pUDBSD->szTmpDBFile);
        SysFree(pUDBSD);
        return (INVALID_USRF_HANDLE);
    }

    return ((USRF_HANDLE) pUDBSD);

}



void            UsrCloseDB(USRF_HANDLE hUsersDB)
{

    UsersDBScanData *pUDBSD = (UsersDBScanData *) hUsersDB;

    fclose(pUDBSD->pDBFile);

    SysRemove(pUDBSD->szTmpDBFile);

    SysFree(pUDBSD);

}



UserInfo       *UsrGetFirstUser(USRF_HANDLE hUsersDB)
{

    UsersDBScanData *pUDBSD = (UsersDBScanData *) hUsersDB;

    rewind(pUDBSD->pDBFile);


    UserInfo       *pUI = NULL;
    char            szUsrLine[USR_TABLE_LINE_MAX] = "";

    while ((pUI == NULL) &&
            (MscFGets(szUsrLine, sizeof(szUsrLine) - 1, pUDBSD->pDBFile) != NULL))
    {
        char          **ppszStrings = StrGetTabLineStrings(szUsrLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if (iFieldsCount >= usrMax)
            pUI = UsrGetUserFromStrings(ppszStrings);

        StrFreeStrings(ppszStrings);
    }

    return (pUI);

}



UserInfo       *UsrGetNextUser(USRF_HANDLE hUsersDB)
{

    UsersDBScanData *pUDBSD = (UsersDBScanData *) hUsersDB;


    UserInfo       *pUI = NULL;
    char            szUsrLine[USR_TABLE_LINE_MAX] = "";

    while ((pUI == NULL) &&
            (MscFGets(szUsrLine, sizeof(szUsrLine) - 1, pUDBSD->pDBFile) != NULL))
    {
        char          **ppszStrings = StrGetTabLineStrings(szUsrLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if (iFieldsCount >= usrMax)
            pUI = UsrGetUserFromStrings(ppszStrings);

        StrFreeStrings(ppszStrings);
    }

    return (pUI);

}



int             UsrPOP3Lock(UserInfo * pUI)
{

    char            szLockPath[SYS_MAX_PATH] = "";

    UsrGetUserPath(pUI, szLockPath);
    strcat(szLockPath, POP3_LOCK_FILE);

    if (SysLockFile(szLockPath) < 0)
        return (ErrGetErrorCode());

    return (0);

}



void            UsrPOP3Unlock(UserInfo * pUI)
{

    char            szLockPath[SYS_MAX_PATH] = "";

    UsrGetUserPath(pUI, szLockPath);
    strcat(szLockPath, POP3_LOCK_FILE);

    SysUnlockFile(szLockPath);

}



int             UsrPOP3UnlockAllUsers(void)
{

    USRF_HANDLE     hUsersDB = UsrOpenDB();

    if (hUsersDB == INVALID_USRF_HANDLE)
        return (ErrGetErrorCode());


    UserInfo       *pUI = UsrGetFirstUser(hUsersDB);

    for (; pUI != NULL; pUI = UsrGetNextUser(hUsersDB))
        UsrPOP3Unlock(pUI);


    UsrCloseDB(hUsersDB);

    return (0);

}



char           *UsrGetUserPath(UserInfo * pUI, char *pszUserPath, int iFinalSlash)
{

    CfgGetRootPath(pszUserPath);

    strcat(pszUserPath, pUI->pszDomain);
    AppendSlash(pszUserPath);
    strcat(pszUserPath, pUI->pszPath);
    if (iFinalSlash)
        AppendSlash(pszUserPath);

    return (pszUserPath);

}



char           *UsrGetMailboxPath(UserInfo * pUI, char *pszMBPath, int iFinalSlash)
{

    UsrGetUserPath(pUI, pszMBPath);

    strcat(pszMBPath, USER_MAILBOX_DIR);
    if (iFinalSlash)
        AppendSlash(pszMBPath);

    return (pszMBPath);

}



int             UsrMoveToMailBox(UserInfo * pUI, const char *pszFileName,
                        const char *pszMBFileName)
{

    char            szMBPath[SYS_MAX_PATH] = "";

    UsrGetMailboxPath(pUI, szMBPath);

    char            szMBFileName[SYS_MAX_PATH] = "";

    if (pszMBFileName == NULL)
    {
        if (SvrGetMsgFileName(pUI->pszDomain, szMBFileName) < 0)
            return (ErrGetErrorCode());

        pszMBFileName = szMBFileName;
    }

    strcat(szMBPath, pszMBFileName);


    RLCK_HANDLE     MBLockID = RLckLockEX(pUI->uUserID, RES_MAILBOX);

    if (MBLockID == INVALID_RLCK_HANDLE)
        return (ErrGetErrorCode());

    if (MscMoveFile(pszFileName, szMBPath) < 0)
    {
        ErrorPush();
        RLckUnlockEX(MBLockID);
        return (ErrorPop());
    }

    RLckUnlockEX(MBLockID);

    return (0);

}




int             UsrGetMailProcessFile(UserInfo * pUI, char *pszMPPath)
{

    char            szMPFilePath[SYS_MAX_PATH] = "";

    if (UsrGetUserPath(pUI, szMPFilePath) == NULL)
        return (ErrGetErrorCode());

    strcat(szMPFilePath, MAILPROCESS_FILE);

    if (!SysExistFile(szMPFilePath))
    {
        ErrSetErrorCode(ERR_NO_MAILPROC_FILE);
        return (ERR_NO_MAILPROC_FILE);
    }


    RLCK_HANDLE     MPLockID = RLckLockSH(pUI->uUserID, RES_MAILPROCESS_FILE);

    if (MPLockID == INVALID_RLCK_HANDLE)
        return (ErrGetErrorCode());

    SysGetTmpFile(pszMPPath);

    if (MscCopyFile(pszMPPath, szMPFilePath) < 0)
    {
        ErrorPush();
        CheckRemoveFile(pszMPPath);
        RLckUnlockSH(MPLockID);
        return (ErrorPop());
    }

    RLckUnlockSH(MPLockID);

    return (0);

}



char           *UsrGetAddress(UserInfo * pUI, char *pszAddress)
{

    sprintf(pszAddress, "%s@%s", pUI->pszName, pUI->pszDomain);

    return (pszAddress);

}



int             UsrGetAliasDBFileSnapShot(char const * pszFileName)
{

    char            szAlsFilePath[SYS_MAX_PATH] = "";

    UsrGetAliasFilePath(szAlsFilePath);


    SHB_HANDLE      hSWMRResource = SWMRCreateReadLock(SWMR_AliasTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    if (MscCopyFile(pszFileName, szAlsFilePath) < 0)
    {
        SWMRCloseReadUnlock(hSWMRResource);
        return (ErrGetErrorCode());
    }


    SWMRCloseReadUnlock(hSWMRResource);

    return (0);

}



ALSF_HANDLE     UsrAliasOpenDB(void)
{

    AliasDBScanData *pADBSD = (AliasDBScanData *) SysAlloc(sizeof(AliasDBScanData));

    if (pADBSD == NULL)
        return (INVALID_ALSF_HANDLE);

    SysGetTmpFile(pADBSD->szTmpDBFile);

    if (UsrGetAliasDBFileSnapShot(pADBSD->szTmpDBFile) < 0)
    {
        SysFree(pADBSD);
        return (INVALID_ALSF_HANDLE);
    }

    if ((pADBSD->pDBFile = fopen(pADBSD->szTmpDBFile, "rt")) == NULL)
    {
        SysRemove(pADBSD->szTmpDBFile);
        SysFree(pADBSD);
        return (INVALID_ALSF_HANDLE);
    }

    return ((ALSF_HANDLE) pADBSD);

}



void            UsrAliasCloseDB(ALSF_HANDLE hAliasDB)
{

    AliasDBScanData *pADBSD = (AliasDBScanData *) hAliasDB;

    fclose(pADBSD->pDBFile);

    SysRemove(pADBSD->szTmpDBFile);

    SysFree(pADBSD);

}



AliasInfo      *UsrAliasGetFirst(ALSF_HANDLE hAliasDB)
{

    AliasDBScanData *pADBSD = (AliasDBScanData *) hAliasDB;

    rewind(pADBSD->pDBFile);


    AliasInfo      *pAI = NULL;
    char            szUsrLine[USR_ALIAS_LINE_MAX] = "";

    while ((pAI == NULL) &&
            (MscFGets(szUsrLine, sizeof(szUsrLine) - 1, pADBSD->pDBFile) != NULL))
    {
        char          **ppszStrings = StrGetTabLineStrings(szUsrLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if (iFieldsCount >= alsMax)
            pAI = UsrAllocAlias(ppszStrings[alsDomain], ppszStrings[alsAlias], ppszStrings[alsName]);

        StrFreeStrings(ppszStrings);
    }

    return (pAI);

}



AliasInfo      *UsrAliasGetNext(ALSF_HANDLE hAliasDB)
{

    AliasDBScanData *pADBSD = (AliasDBScanData *) hAliasDB;


    AliasInfo      *pAI = NULL;
    char            szUsrLine[USR_ALIAS_LINE_MAX] = "";

    while ((pAI == NULL) &&
            (MscFGets(szUsrLine, sizeof(szUsrLine) - 1, pADBSD->pDBFile) != NULL))
    {
        char          **ppszStrings = StrGetTabLineStrings(szUsrLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if (iFieldsCount >= alsMax)
            pAI = UsrAllocAlias(ppszStrings[alsDomain], ppszStrings[alsAlias], ppszStrings[alsName]);

        StrFreeStrings(ppszStrings);
    }

    return (pAI);

}
