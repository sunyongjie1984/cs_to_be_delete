/*
 *  MailSvr by Davide Libenzi ( Intranet and Internet mail server )
 *  Copyright (C) 1999  Davide Libenzi
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Davide Libenzi <davidel@maticad.it>
 *
 */


#include "SysInclude.h"
#include "SysDep.h"
#include "SvrDefines.h"
#include "ShBlocks.h"
#include "SWMR.h"
#include "StrUtils.h"
#include "SList.h"
#include "BuffSock.h"
#include "MailConfig.h"
#include "UsrUtils.h"
#include "SvrUtils.h"
#include "MiscUtils.h"
#include "DNS.h"
#include "SMTPSvr.h"
#include "SMAILUtils.h"
#include "SMTPUtils.h"
#include "MailSvr.h"





#define STD_SMTP_TIMEOUT        60
#define SMTPGW_LINE_MAX         1024
#define SMTPGW_TABLE_FILE       "smtpgw.tab"
#define SMTPRELAY_LINE_MAX      512
#define SMTP_RELAY_FILE         "smtprelay.tab"
#define MAX_MX_RECORDS          32
#define RBL_MAPS_DOMAIN         "rbl.maps.vix.com."
#define RSS_MAPS_DOMAIN         "relays.mail-abuse.org."
#define SMTP_SPAMMERS_FILE      "spammers.tab"
#define SPAMMERS_LINE_MAX       512









enum SmtpGwFileds
{
    gwDomain = 0,
    gwGateway,

    gwMax
};

enum SmtpRelayFileds
{
    rlyFromIP = 0,
    rlyFromMask,

    rlyMax
};

enum SpammerFileds
{
    spmFromIP = 0,
    spmFromMask,

    spmMax
};

struct SmtpMXRecords
{
    int             iNumMXRecords;
    int             iMXCost[MAX_MX_RECORDS];
    char           *pszMXName[MAX_MX_RECORDS];
    int             iCurrMxCost;
};





static int      USmtpWriteGateway(FILE * pGwFile, const char *pszDomain, const char *pszGateway);
static char    *USmtpGetGwTableFilePath(char *pszGwFilePath);
static char    *USmtpGetRelayFilePath(char *pszRelayFilePath);
static int      USmtpSetError(SMTPError * pSMTPE, int iSTMPResponse, char const * pszSTMPResponse);
static int      USmtpResponseClass(int iResponseCode, int iResponseClass);
static int      USmtpGetResultCode(const char *pszResult);
static int      USmtpIsPartialResponse(char const * pszResponse);
static int      USmtpGetResponse(BSOCK_HANDLE hBSock, char *pszResponse, int iMaxResponse,
                        int iTimeout = STD_SMTP_TIMEOUT);
static int      USmtpSendCommand(BSOCK_HANDLE hBSock, const char *pszCommand,
                        char *pszResponse, int iMaxResponse, int iTimeout = STD_SMTP_TIMEOUT);
static int      USmtpSendFile(const char *pszFileName, BSOCK_HANDLE hBSock,
                        int iParseFile);
static int      USmtpGetDomainMX(SVRCFG_HANDLE hSvrConfig, const char *pszDomain,
                        char *&pszMXDomains);
static char    *USmtpGetSpammersFilePath(char *pszSpamFilePath);









static char    *USmtpGetGwTableFilePath(char *pszGwFilePath)
{

    CfgGetRootPath(pszGwFilePath);

    strcat(pszGwFilePath, SMTPGW_TABLE_FILE);

    return (pszGwFilePath);

}



static char    *USmtpGetRelayFilePath(char *pszRelayFilePath)
{

    CfgGetRootPath(pszRelayFilePath);

    strcat(pszRelayFilePath, SMTP_RELAY_FILE);

    return (pszRelayFilePath);

}



int             USmtpGetGateway(SVRCFG_HANDLE hSvrConfig, const char *pszDomain,
                        char *pszGateway)
{

    char            szGwFilePath[SYS_MAX_PATH] = "";

    USmtpGetGwTableFilePath(szGwFilePath);


    SHB_HANDLE      hSWMRResource = SWMRCreateReadLock(SWMR_SMTPGWTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pGwFile = fopen(szGwFilePath, "rt");

    if (pGwFile == NULL)
    {
        SWMRCloseReadUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_SMTPGW_FILE_NOT_FOUND);
        return (ERR_SMTPGW_FILE_NOT_FOUND);
    }

    char            szGwLine[SMTPGW_LINE_MAX] = "";

    while (MscGetConfigLine(szGwLine, sizeof(szGwLine) - 1, pGwFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szGwLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if ((iFieldsCount >= gwMax) && StrIWildMatch(pszDomain, ppszStrings[gwDomain]))
        {
            strcpy(pszGateway, ppszStrings[gwGateway]);

            StrFreeStrings(ppszStrings);
            fclose(pGwFile);

            SWMRCloseReadUnlock(hSWMRResource);

            return (0);
        }

        StrFreeStrings(ppszStrings);
    }

    fclose(pGwFile);

    SWMRCloseReadUnlock(hSWMRResource);

    ErrSetErrorCode(ERR_SMTPGW_NOT_FOUND);
    return (ERR_SMTPGW_NOT_FOUND);

}



static int      USmtpWriteGateway(FILE * pGwFile, const char *pszDomain, const char *pszGateway)
{

///////////////////////////////////////////////////////////////////////////////
//  Domain
///////////////////////////////////////////////////////////////////////////////
    char           *pszQuoted = StrQuote(pszDomain, '"');

    if (pszQuoted == NULL)
        return (ErrGetErrorCode());

    fprintf(pGwFile, "%s\t", pszQuoted);

    SysFree(pszQuoted);

///////////////////////////////////////////////////////////////////////////////
//  Gateway
///////////////////////////////////////////////////////////////////////////////
    pszQuoted = StrQuote(pszGateway, '"');

    if (pszQuoted == NULL)
        return (ErrGetErrorCode());

    fprintf(pGwFile, "%s\n", pszQuoted);

    SysFree(pszQuoted);

    return (0);

}



int             USmtpAddGateway(const char *pszDomain, const char *pszGateway)
{

    char            szGwFilePath[SYS_MAX_PATH] = "";

    USmtpGetGwTableFilePath(szGwFilePath);


    SHB_HANDLE      hSWMRResource = SWMRCreateWriteLock(SWMR_SMTPGWTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pGwFile = fopen(szGwFilePath, "r+t");

    if (pGwFile == NULL)
    {
        SWMRCloseWriteUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_SMTPGW_FILE_NOT_FOUND);
        return (ERR_SMTPGW_FILE_NOT_FOUND);
    }

    char            szGwLine[SMTPGW_LINE_MAX] = "";

    while (MscGetConfigLine(szGwLine, sizeof(szGwLine) - 1, pGwFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szGwLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if ((iFieldsCount >= gwMax) && (stricmp(pszDomain, ppszStrings[gwDomain]) == 0) &&
                (stricmp(pszGateway, ppszStrings[gwGateway]) == 0))
        {
            StrFreeStrings(ppszStrings);
            fclose(pGwFile);
            SWMRCloseWriteUnlock(hSWMRResource);

            ErrSetErrorCode(ERR_GATEWAY_ALREADY_EXIST);
            return (ERR_GATEWAY_ALREADY_EXIST);
        }

        StrFreeStrings(ppszStrings);
    }

    fseek(pGwFile, 0, SEEK_END);


    if (USmtpWriteGateway(pGwFile, pszDomain, pszGateway) < 0)
    {
        fclose(pGwFile);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrGetErrorCode());
    }


    fclose(pGwFile);

    SWMRCloseWriteUnlock(hSWMRResource);

    return (0);

}



int             USmtpRemoveGateway(const char *pszDomain)
{

    char            szGwFilePath[SYS_MAX_PATH] = "";

    USmtpGetGwTableFilePath(szGwFilePath);


    char            szTmpFile[SYS_MAX_PATH] = "";

    SysGetTmpFile(szTmpFile);


    SHB_HANDLE      hSWMRResource = SWMRCreateWriteLock(SWMR_SMTPGWTable);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pGwFile = fopen(szGwFilePath, "rt");

    if (pGwFile == NULL)
    {
        SWMRCloseWriteUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_SMTPGW_FILE_NOT_FOUND);
        return (ERR_SMTPGW_FILE_NOT_FOUND);
    }

    FILE           *pTmpFile = fopen(szTmpFile, "wt");

    if (pTmpFile == NULL)
    {
        fclose(pGwFile);
        SWMRCloseWriteUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }


    int             iGatewayFound = 0;
    char            szGwLine[SMTPGW_LINE_MAX] = "";

    while (MscGetConfigLine(szGwLine, sizeof(szGwLine) - 1, pGwFile, false) != NULL)
    {
        if (szGwLine[0] == TAB_COMMENT_CHAR)
        {
            fprintf(pTmpFile, "%s\n", szGwLine);
            continue;
        }


        char          **ppszStrings = StrGetTabLineStrings(szGwLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if ((iFieldsCount >= gwMax) && (stricmp(pszDomain, ppszStrings[gwDomain]) == 0))
        {

            ++iGatewayFound;

        }
        else
            fprintf(pTmpFile, "%s\n", szGwLine);

        StrFreeStrings(ppszStrings);
    }

    fclose(pGwFile);
    fclose(pTmpFile);


    if (iGatewayFound == 0)
    {
        SysRemove(szTmpFile);
        SWMRCloseWriteUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_GATEWAY_NOT_FOUND);
        return (ERR_GATEWAY_NOT_FOUND);
    }

    char            szTmpGwFilePath[SYS_MAX_PATH] = "";

    sprintf(szTmpGwFilePath, "%s.tmp", szGwFilePath);

    if (MscMoveFile(szGwFilePath, szTmpGwFilePath) < 0)
    {
        ErrorPush();
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrorPop());
    }

    if (MscMoveFile(szTmpFile, szGwFilePath) < 0)
    {
        ErrorPush();
        MscMoveFile(szTmpGwFilePath, szGwFilePath);
        SWMRCloseWriteUnlock(hSWMRResource);
        return (ErrorPop());
    }

    SysRemove(szTmpGwFilePath);


    SWMRCloseWriteUnlock(hSWMRResource);

    return (0);

}



int             USmtpSubmitPackedFile(const char *pszDomain, const char *pszPkgFile)
{

    FILE           *pPkgFile = fopen(pszPkgFile, "rb");

    if (pPkgFile == NULL)
    {
        ErrSetErrorCode(ERR_FILE_OPEN);
        return (ERR_FILE_OPEN);
    }


    char            szSpoolLine[MAX_SPOOL_LINE] = "";

    while ((MscGetString(pPkgFile, szSpoolLine, sizeof(szSpoolLine) - 1) != NULL) &&
            (strncmp(szSpoolLine, SPOOL_FILE_DATA_START, strlen(SPOOL_FILE_DATA_START)) != 0));

    if (strncmp(szSpoolLine, SPOOL_FILE_DATA_START, strlen(SPOOL_FILE_DATA_START)) != 0)
    {
        fclose(pPkgFile);
        ErrSetErrorCode(ERR_INVALID_SPOOL_FILE);
        return (ERR_INVALID_SPOOL_FILE);
    }


    char            szTmpMailFile[SYS_MAX_PATH] = "";

    SysGetTmpFile(szTmpMailFile);

    FILE           *pMailFile = fopen(szTmpMailFile, "w+b");

    if (pMailFile == NULL)
    {
        fclose(pPkgFile);
        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }

    while (MscGetString(pPkgFile, szSpoolLine, sizeof(szSpoolLine) - 1) != NULL)
        fprintf(pMailFile, "%s\r\n", szSpoolLine);


    rewind(pPkgFile);


///////////////////////////////////////////////////////////////////////////////
//  Read SMTP domain ( 1st row of the spool file )
///////////////////////////////////////////////////////////////////////////////
    char            szSMTPDomain[256] = "";

    if (MscGetString(pPkgFile, szSMTPDomain, sizeof(szSMTPDomain) - 1) == NULL)
    {
        fclose(pPkgFile);
        fclose(pMailFile);
        SysRemove(szTmpMailFile);
        ErrSetErrorCode(ERR_INVALID_SPOOL_FILE);
        return (ERR_INVALID_SPOOL_FILE);
    }

///////////////////////////////////////////////////////////////////////////////
//  Read message ID ( 2nd row of the spool file )
///////////////////////////////////////////////////////////////////////////////
    char            szMessageID[128] = "";

    if (MscGetString(pPkgFile, szMessageID, sizeof(szMessageID) - 1) == NULL)
    {
        fclose(pPkgFile);
        fclose(pMailFile);
        SysRemove(szTmpMailFile);
        ErrSetErrorCode(ERR_INVALID_SPOOL_FILE);
        return (ERR_INVALID_SPOOL_FILE);
    }

///////////////////////////////////////////////////////////////////////////////
//  Read "MAIL FROM:" ( 3th row of the spool file )
///////////////////////////////////////////////////////////////////////////////
    char            szMailFrom[MAX_SPOOL_LINE] = "";

    if ((MscGetString(pPkgFile, szMailFrom, sizeof(szMailFrom) - 1) == NULL) ||
            (StrINComp(szMailFrom, MAIL_FROM_STR) != 0))
    {
        fclose(pPkgFile);
        fclose(pMailFile);
        SysRemove(szTmpMailFile);
        ErrSetErrorCode(ERR_INVALID_SPOOL_FILE);
        return (ERR_INVALID_SPOOL_FILE);
    }


///////////////////////////////////////////////////////////////////////////////
//  Read "RCPT TO:" ( 4th row of the spool file )
///////////////////////////////////////////////////////////////////////////////
    while ((MscGetString(pPkgFile, szSpoolLine, sizeof(szSpoolLine) - 1) != NULL) &&
            (StrINComp(szSpoolLine, RCPT_TO_STR) == 0))
    {
        char            szSpoolFile[SYS_MAX_PATH] = "";

        SysGetTmpFile(szSpoolFile);


        FILE           *pSpoolFile = fopen(szSpoolFile, "wb");

        if (pSpoolFile == NULL)
        {
            fclose(pPkgFile);
            fclose(pMailFile);
            SysRemove(szTmpMailFile);
            ErrSetErrorCode(ERR_FILE_CREATE);
            return (ERR_FILE_CREATE);
        }


///////////////////////////////////////////////////////////////////////////////
//  Write SMTP domain
///////////////////////////////////////////////////////////////////////////////
        fprintf(pSpoolFile, "%s\r\n", szSMTPDomain);

///////////////////////////////////////////////////////////////////////////////
//  Write message ID
///////////////////////////////////////////////////////////////////////////////
        fprintf(pSpoolFile, "%s\r\n", szMessageID);

///////////////////////////////////////////////////////////////////////////////
//  Write "MAIL FROM:"
///////////////////////////////////////////////////////////////////////////////
        fprintf(pSpoolFile, "%s\r\n", szMailFrom);

///////////////////////////////////////////////////////////////////////////////
//  Write "RCPT TO:"
///////////////////////////////////////////////////////////////////////////////
        fprintf(pSpoolFile, "%s\r\n", szSpoolLine);

///////////////////////////////////////////////////////////////////////////////
//  Write SPOOL_FILE_DATA_START
///////////////////////////////////////////////////////////////////////////////
        fprintf(pSpoolFile, "%s\r\n", SPOOL_FILE_DATA_START);

///////////////////////////////////////////////////////////////////////////////
//  Write mail data
///////////////////////////////////////////////////////////////////////////////
        rewind(pMailFile);


        while (MscGetString(pMailFile, szSpoolLine, sizeof(szSpoolLine) - 1) != NULL)
            fprintf(pSpoolFile, "%s\r\n", szSpoolLine);


        fclose(pSpoolFile);


///////////////////////////////////////////////////////////////////////////////
//  Transfer file to the spool
///////////////////////////////////////////////////////////////////////////////
        char            szMessageId[256] = "";

        if (USmtpMoveToSpool(pszDomain, szSpoolFile, szMessageId) < 0)
        {
            ErrorPush();
            fclose(pPkgFile);
            fclose(pMailFile);
            SysRemove(szSpoolFile);
            SysRemove(szTmpMailFile);
            return (ErrorPop());
        }
    }

    fclose(pPkgFile);
    fclose(pMailFile);

    SysRemove(szTmpMailFile);

    return (0);

}



int             USmtpGetSpoolFileInfo(char const * pszPkgFile, char *pszDomain, char *pszSmtpMessageID,
                        char *pszFrom, char *pszRcpt)
{

    FILE           *pPkgFile = fopen(pszPkgFile, "rb");

    if (pPkgFile == NULL)
    {
        ErrSetErrorCode(ERR_FILE_OPEN, pszPkgFile);
        return (ERR_FILE_OPEN);
    }

///////////////////////////////////////////////////////////////////////////////
//  Read SMTP domain ( 1st row of the spool file )
///////////////////////////////////////////////////////////////////////////////
    char            szSpoolLine[2048] = "";

    if (MscGetString(pPkgFile, szSpoolLine, sizeof(szSpoolLine) - 1) == NULL)
    {
        fclose(pPkgFile);
        ErrSetErrorCode(ERR_INVALID_SPOOL_FILE);
        return (ERR_INVALID_SPOOL_FILE);
    }

    if (pszDomain != NULL)
        StrNCpy(pszDomain, szSpoolLine, MAX_HOST_NAME);

///////////////////////////////////////////////////////////////////////////////
//  Read message ID ( 2nd row of the spool file )
///////////////////////////////////////////////////////////////////////////////
    char            szMessageID[128] = "";

    if (MscGetString(pPkgFile, szMessageID, sizeof(szMessageID) - 1) == NULL)
    {
        fclose(pPkgFile);
        ErrSetErrorCode(ERR_INVALID_SPOOL_FILE);
        return (ERR_INVALID_SPOOL_FILE);
    }

    if (pszSmtpMessageID != NULL)
        strcpy(pszSmtpMessageID, szMessageID);

///////////////////////////////////////////////////////////////////////////////
//  Read "MAIL FROM:" ( 3th row of the spool file )
///////////////////////////////////////////////////////////////////////////////
    if ((MscGetString(pPkgFile, szSpoolLine, sizeof(szSpoolLine) - 1) == NULL) ||
            (StrINComp(szSpoolLine, MAIL_FROM_STR) != 0))
    {
        fclose(pPkgFile);
        ErrSetErrorCode(ERR_INVALID_SPOOL_FILE);
        return (ERR_INVALID_SPOOL_FILE);
    }

    if (pszFrom != NULL)
    {
        char          **ppszFrom = USmtpGetPathStrings(szSpoolLine);

        if (ppszFrom == NULL)
        {
            ErrorPush();
            fclose(pPkgFile);
            return (ErrorPop());
        }

        int             iFromDomains = StrStringsCount(ppszFrom);

        StrNCpy(pszFrom, ppszFrom[iFromDomains - 1], MAX_ADDR_NAME);

        StrFreeStrings(ppszFrom);
    }

///////////////////////////////////////////////////////////////////////////////
//  Read "RCPT TO:" ( 4th row of the spool file )
///////////////////////////////////////////////////////////////////////////////
    if ((MscGetString(pPkgFile, szSpoolLine, sizeof(szSpoolLine) - 1) == NULL) ||
            (StrINComp(szSpoolLine, RCPT_TO_STR) != 0))
    {
        fclose(pPkgFile);
        ErrSetErrorCode(ERR_INVALID_SPOOL_FILE);
        return (ERR_INVALID_SPOOL_FILE);
    }

    if (pszRcpt != NULL)
    {
        char          **ppszRcpt = USmtpGetPathStrings(szSpoolLine);

        if (ppszRcpt == NULL)
        {
            ErrorPush();
            fclose(pPkgFile);
            return (ErrorPop());
        }

        int             iRcptDomains = StrStringsCount(ppszRcpt);

        StrNCpy(pszRcpt, ppszRcpt[iRcptDomains - 1], MAX_ADDR_NAME);

        StrFreeStrings(ppszRcpt);
    }


    fclose(pPkgFile);

    return (0);

}



int             USmtpCopyToSpool(char const * pszDomain, char const * pszMsgFile,
                        char *pszMessageID)
{

    char            szSpoolFileName[SYS_MAX_PATH] = "";

    if (SvrGetMsgFileName(pszDomain, szSpoolFileName) < 0)
        return (ErrGetErrorCode());

    if (SvrCopyToSpool(pszMsgFile, szSpoolFileName) < 0)
        return (ErrGetErrorCode());


    if (pszMessageID != NULL)
        strcpy(pszMessageID, szSpoolFileName);


    return (0);

}



int             USmtpMoveToSpool(char const * pszDomain, char const * pszMsgFile,
                        char *pszMessageID)
{

    char            szSpoolFileName[SYS_MAX_PATH] = "";

    if (SvrGetMsgFileName(pszDomain, szSpoolFileName) < 0)
        return (ErrGetErrorCode());

    if (SvrMoveToSpool(pszMsgFile, szSpoolFileName) < 0)
        return (ErrGetErrorCode());


    if (pszMessageID != NULL)
        strcpy(pszMessageID, szSpoolFileName);


    return (0);

}



int             USmtpIsAllowedRelay(const SYS_INET_ADDR & PeerInfo,
                        SVRCFG_HANDLE hSvrConfig)
{

    char            szRelayFilePath[SYS_MAX_PATH] = "";

    USmtpGetRelayFilePath(szRelayFilePath);


    SHB_HANDLE      hSWMRResource = SWMRCreateReadLock(SWMR_RelayFile);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pRelayFile = fopen(szRelayFilePath, "rt");

    if (pRelayFile == NULL)
    {
        SWMRCloseReadUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_SMTPRELAY_FILE_NOT_FOUND);
        return (ERR_SMTPRELAY_FILE_NOT_FOUND);
    }


    NET_ADDRESS     TestAddr = SysGetAddrAddress(PeerInfo);


    char            szRelayLine[SMTPRELAY_LINE_MAX] = "";

    while (MscGetConfigLine(szRelayLine, sizeof(szRelayLine) - 1, pRelayFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szRelayLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);
        AddressFilter   AF;

        if ((iFieldsCount > 0) &&
                (MscLoadAddressFilter(ppszStrings, iFieldsCount, AF) == 0) &&
                MscAddressMatch(AF, TestAddr))
        {
            StrFreeStrings(ppszStrings);
            fclose(pRelayFile);
            SWMRCloseReadUnlock(hSWMRResource);

            return (0);
        }

        StrFreeStrings(ppszStrings);
    }

    fclose(pRelayFile);

    SWMRCloseReadUnlock(hSWMRResource);


    ErrSetErrorCode(ERR_RELAY_NOT_ALLOWED);

    return (ERR_RELAY_NOT_ALLOWED);

}



char          **USmtpGetPathStrings(const char *pszMailCmd)
{

    const char     *pszOpen = strchr(pszMailCmd, '<'),
                   *pszClose = strchr(pszMailCmd, '>');

    if ((pszOpen == NULL) || (pszClose == NULL))
    {
        ErrSetErrorCode(ERR_SMTP_PATH_PARSE_ERROR);
        return (NULL);
    }

    int             iPathLength = (int) (pszClose - pszOpen - 1);

    if (iPathLength < 0)
    {
        ErrSetErrorCode(ERR_SMTP_PATH_PARSE_ERROR, pszMailCmd);
        return (NULL);
    }

    char           *pszPath = (char *) SysAlloc(iPathLength + 1);

    if (pszPath == NULL)
        return (NULL);

    strncpy(pszPath, pszOpen + 1, iPathLength);
    pszPath[iPathLength] = '\0';


    char          **ppszDomains = StrTokenize(pszPath, ",:");


    SysFree(pszPath);

    return (ppszDomains);

}



int             USmtpSplitEmailAddr(const char *pszAddr, char *pszUser, char *pszDomain)
{

    const char     *pszAT = strchr(pszAddr, '@');

    if (pszAT == NULL)
    {
        ErrSetErrorCode(ERR_BAD_EMAIL_ADDR);
        return (ERR_BAD_EMAIL_ADDR);
    }

    if (pszUser != NULL)
    {
        int             iUserLength = (int) (pszAT - pszAddr);

        iUserLength = Min(iUserLength, MAX_ADDR_NAME - 1);

        strncpy(pszUser, pszAddr, iUserLength);
        pszUser[iUserLength] = '\0';
    }

    if (pszDomain != NULL)
        StrNCpy(pszDomain, pszAT + 1, MAX_ADDR_NAME);

    return (0);

}



int             USmtpInitError(SMTPError * pSMTPE)
{

    ZeroData(*pSMTPE);
    pSMTPE->iSTMPResponse = 0;
    pSMTPE->pszSTMPResponse = NULL;

    return (0);

}



static int      USmtpSetError(SMTPError * pSMTPE, int iSTMPResponse, char const * pszSTMPResponse)
{

    pSMTPE->iSTMPResponse = iSTMPResponse;

    if (pSMTPE->pszSTMPResponse != NULL)
        SysFree(pSMTPE->pszSTMPResponse);

    pSMTPE->pszSTMPResponse = SysStrDup(pszSTMPResponse);

    return (0);

}



bool            USmtpIsFatalError(SMTPError const * pSMTPE)
{

    return ((pSMTPE->iSTMPResponse >= 500) && (pSMTPE->iSTMPResponse < 600));

}



char const     *USmtpGetErrorMessage(SMTPError const * pSMTPE)
{

    return ((pSMTPE->pszSTMPResponse != NULL) ? pSMTPE->pszSTMPResponse : "");

}



int             USmtpCleanupError(SMTPError * pSMTPE)
{

    if (pSMTPE->pszSTMPResponse != NULL)
        SysFree(pSMTPE->pszSTMPResponse);

    USmtpInitError(pSMTPE);

    return (0);

}



static int      USmtpResponseClass(int iResponseCode, int iResponseClass)
{

    return (((iResponseCode >= iResponseClass) &&
                    (iResponseCode < (iResponseClass + 100))) ? 1 : 0);

}



static int      USmtpGetResultCode(const char *pszResult)
{

    int             ii;
    char            szResCode[64] = "";

    for (ii = 0; isdigit(pszResult[ii]); ii++)
        szResCode[ii] = pszResult[ii];

    szResCode[ii] = '\0';

    if (ii == 0)
    {
        ErrSetErrorCode(ERR_BAD_SMTP_RESPONSE);
        return (ERR_BAD_SMTP_RESPONSE);
    }

    return (atoi(szResCode));

}



static int      USmtpIsPartialResponse(char const * pszResponse)
{

    return (((strlen(pszResponse) >= 4) && (pszResponse[3] == '-')) ? 1 : 0);

}



static int      USmtpGetResponse(BSOCK_HANDLE hBSock, char *pszResponse, int iMaxResponse,
                        int iTimeout)
{

    int             iResultCode = -1,
                    iResponseLenght = 0;
    char            szPartial[1024] = "";

    do
    {
        if (BSckGetString(hBSock, szPartial, sizeof(szPartial) - 1, iTimeout) == NULL)
            return (ErrGetErrorCode());

        if (iResponseLenght < iMaxResponse)
        {
            if (iResponseLenght > 0)
                strcat(pszResponse, "\r\n"), iResponseLenght += 2;

            int             iCopyLenght = Min(iMaxResponse - 1 - iResponseLenght,
                    (int) strlen(szPartial));

            strncpy(pszResponse + iResponseLenght, szPartial, iCopyLenght);

            iResponseLenght += iCopyLenght;

            pszResponse[iResponseLenght] = '\0';
        }

        if ((iResultCode = USmtpGetResultCode(szPartial)) < 0)
            return (ErrGetErrorCode());

    } while (USmtpIsPartialResponse(szPartial));

    return (iResultCode);

}



static int      USmtpSendCommand(BSOCK_HANDLE hBSock, const char *pszCommand,
                        char *pszResponse, int iMaxResponse, int iTimeout)
{

    if (BSckSendString(hBSock, pszCommand, iTimeout) <= 0)
        return (ErrGetErrorCode());

    return (USmtpGetResponse(hBSock, pszResponse, iMaxResponse, iTimeout));

}



static int      USmtpSendFile(const char *pszFileName, BSOCK_HANDLE hBSock,
                        int iParseFile)
{

    FILE           *pFile = fopen(pszFileName, "rb");

    if (pFile == NULL)
        return (ErrGetErrorCode());

    char            szBuffer[1024] = "";

    while (MscGetString(pFile, szBuffer, sizeof(szBuffer) - 1) != NULL)
    {
        if (iParseFile && (szBuffer[0] == '.'))
            for (int ii = strlen(szBuffer); ii >= 0; ii--)
                szBuffer[ii + 1] = szBuffer[ii];

        if (BSckSendString(hBSock, szBuffer, STD_SMTP_TIMEOUT) <= 0)
        {
            fclose(pFile);
            return (ErrGetErrorCode());
        }

        if (SvrInShutdown())
        {
            fclose(pFile);

            ErrSetErrorCode(ERR_SERVER_SHUTDOWN);
            return (ERR_SERVER_SHUTDOWN);
        }
    }

    fclose(pFile);

    return (0);

}



BSOCK_HANDLE    USmtpCreateChannel(const char *pszServer, const char *pszDomain,
                        SMTPError * pSMTPE)
{

    NET_ADDRESS     NetAddr;

    if (MscGetServerAddress(pszServer, NetAddr) < 0)
        return (INVALID_BSOCK_HANDLE);


    SYS_SOCKET      SockFD = SysCreateSocket(AF_INET, SOCK_STREAM, 0);

    if (SockFD == SYS_INVALID_SOCKET)
        return (INVALID_BSOCK_HANDLE);

    SYS_INET_ADDR   SvrAddr;

    SysSetupAddress(SvrAddr, AF_INET, NetAddr, htons(STD_SMTP_PORT));

    if (SysConnect(SockFD, &SvrAddr, sizeof(SvrAddr), STD_SMTP_TIMEOUT) < 0)
    {
        SysCloseSocket(SockFD);
        return (INVALID_BSOCK_HANDLE);
    }

    BSOCK_HANDLE    hBSock = BSckAttach(SockFD);

    if (hBSock == INVALID_BSOCK_HANDLE)
    {
        SysCloseSocket(SockFD);
        return (INVALID_BSOCK_HANDLE);
    }

///////////////////////////////////////////////////////////////////////////////
//  Read welcome message
///////////////////////////////////////////////////////////////////////////////
    int             iSvrReponse = -1;
    char            szRTXBuffer[2048] = "";

    if (!USmtpResponseClass(iSvrReponse = USmtpGetResponse(hBSock, szRTXBuffer,
                            sizeof(szRTXBuffer)), 200))
    {
        BSckDetach(hBSock, 1);

        if (iSvrReponse > 0)
        {
            if (pSMTPE != NULL)
                USmtpSetError(pSMTPE, iSvrReponse, szRTXBuffer);

            ErrSetErrorCode(ERR_BAD_SERVER_RESPONSE, szRTXBuffer);
        }

        return (INVALID_BSOCK_HANDLE);
    }

///////////////////////////////////////////////////////////////////////////////
//  Send HELO and read result
///////////////////////////////////////////////////////////////////////////////
    sprintf(szRTXBuffer, "HELO %s", pszDomain);

    if (!USmtpResponseClass(iSvrReponse = USmtpSendCommand(hBSock, szRTXBuffer, szRTXBuffer,
                            sizeof(szRTXBuffer)), 200))
    {
        BSckDetach(hBSock, 1);

        if (iSvrReponse > 0)
        {
            if (pSMTPE != NULL)
                USmtpSetError(pSMTPE, iSvrReponse, szRTXBuffer);

            ErrSetErrorCode(ERR_BAD_SERVER_RESPONSE, szRTXBuffer);
        }

        return (INVALID_BSOCK_HANDLE);
    }

    return (hBSock);

}



int             USmtpCloseChannel(BSOCK_HANDLE hBSock, int iHardClose, SMTPError * pSMTPE)
{

    if (!iHardClose)
    {
///////////////////////////////////////////////////////////////////////////////
//  Send QUIT and read result
///////////////////////////////////////////////////////////////////////////////
        int             iSvrReponse = -1;
        char            szRTXBuffer[2048] = "";

        if (!USmtpResponseClass(iSvrReponse = USmtpSendCommand(hBSock, "QUIT", szRTXBuffer,
                                sizeof(szRTXBuffer)), 200))
        {
            BSckDetach(hBSock, 1);

            if (iSvrReponse > 0)
            {
                if (pSMTPE != NULL)
                    USmtpSetError(pSMTPE, iSvrReponse, szRTXBuffer);

                ErrSetErrorCode(ERR_BAD_SERVER_RESPONSE, szRTXBuffer);
            }

            return (ErrGetErrorCode());
        }
    }

    BSckDetach(hBSock, 1);

    return (0);

}



int             USmtpChannelReset(BSOCK_HANDLE hBSock, SMTPError * pSMTPE)
{

///////////////////////////////////////////////////////////////////////////////
//  Send RSET and read result
///////////////////////////////////////////////////////////////////////////////
    int             iSvrReponse = -1;
    char            szRTXBuffer[2048] = "";

    if (!USmtpResponseClass(iSvrReponse = USmtpSendCommand(hBSock, "RSET", szRTXBuffer,
                            sizeof(szRTXBuffer)), 200))
    {
        if (iSvrReponse > 0)
        {
            if (pSMTPE != NULL)
                USmtpSetError(pSMTPE, iSvrReponse, szRTXBuffer);

            ErrSetErrorCode(ERR_BAD_SERVER_RESPONSE, szRTXBuffer);
        }

        return (ErrGetErrorCode());
    }

    return (0);

}



int             USmtpSendMail(BSOCK_HANDLE hBSock, const char *pszFrom, const char *pszRcpt,
                        const char *pszFileName, int iParseFile, SMTPError * pSMTPE)
{

///////////////////////////////////////////////////////////////////////////////
//  Send MAIL FROM: and read result
///////////////////////////////////////////////////////////////////////////////
    int             iSvrReponse = -1;
    char            szRTXBuffer[2048] = "";

    sprintf(szRTXBuffer, "MAIL FROM:<%s>", pszFrom);

    if (!USmtpResponseClass(iSvrReponse = USmtpSendCommand(hBSock, szRTXBuffer, szRTXBuffer,
                            sizeof(szRTXBuffer)), 200))
    {
        if (iSvrReponse > 0)
        {
            if (pSMTPE != NULL)
                USmtpSetError(pSMTPE, iSvrReponse, szRTXBuffer);

            ErrSetErrorCode(ERR_SMTP_BAD_MAIL_FROM, szRTXBuffer);
        }

        return (ErrGetErrorCode());
    }

///////////////////////////////////////////////////////////////////////////////
//  Send RCPT TO: and read result
///////////////////////////////////////////////////////////////////////////////
    sprintf(szRTXBuffer, "RCPT TO:<%s>", pszRcpt);

    if (!USmtpResponseClass(iSvrReponse = USmtpSendCommand(hBSock, szRTXBuffer, szRTXBuffer,
                            sizeof(szRTXBuffer)), 200))
    {
        if (iSvrReponse > 0)
        {
            if (pSMTPE != NULL)
                USmtpSetError(pSMTPE, iSvrReponse, szRTXBuffer);

            ErrSetErrorCode(ERR_SMTP_BAD_RCPT_TO, szRTXBuffer);
        }

        return (ErrGetErrorCode());
    }

///////////////////////////////////////////////////////////////////////////////
//  Send DATA and read the "ready to receive"
///////////////////////////////////////////////////////////////////////////////
    if (!USmtpResponseClass(iSvrReponse = USmtpSendCommand(hBSock, "DATA", szRTXBuffer,
                            sizeof(szRTXBuffer)), 300))
    {
        if (iSvrReponse > 0)
        {
            if (pSMTPE != NULL)
                USmtpSetError(pSMTPE, iSvrReponse, szRTXBuffer);

            ErrSetErrorCode(ERR_SMTP_BAD_DATA, szRTXBuffer);
        }

        return (ErrGetErrorCode());
    }

///////////////////////////////////////////////////////////////////////////////
//  Send file
///////////////////////////////////////////////////////////////////////////////
    if (USmtpSendFile(pszFileName, hBSock, iParseFile) < 0)
        return (ErrGetErrorCode());

///////////////////////////////////////////////////////////////////////////////
//  Send END OF DATA and read transfer result
///////////////////////////////////////////////////////////////////////////////
    if (BSckSendString(hBSock, ".", STD_SMTP_TIMEOUT) <= 0)
        return (ErrGetErrorCode());

    if (!USmtpResponseClass(iSvrReponse = USmtpGetResponse(hBSock, szRTXBuffer,
                            sizeof(szRTXBuffer)), 200))
    {
        if (iSvrReponse > 0)
        {
            if (pSMTPE != NULL)
                USmtpSetError(pSMTPE, iSvrReponse, szRTXBuffer);

            ErrSetErrorCode(ERR_BAD_SERVER_RESPONSE, szRTXBuffer);
        }

        return (ErrGetErrorCode());
    }

    return (0);

}




int             USmtpSendMail(const char *pszServer, const char *pszDomain,
                        const char *pszFrom, const char *pszRcpt, const char *pszFileName,
                        int iParseFile, SMTPError * pSMTPE)
{

///////////////////////////////////////////////////////////////////////////////
//  Open STMP channel and try to send the message
///////////////////////////////////////////////////////////////////////////////
    BSOCK_HANDLE    hBSock = USmtpCreateChannel(pszServer, pszDomain, pSMTPE);

    if (hBSock == INVALID_BSOCK_HANDLE)
        return (ErrGetErrorCode());


    int             iResultCode = USmtpSendMail(hBSock, pszFrom, pszRcpt,
            pszFileName, iParseFile, pSMTPE);


    USmtpCloseChannel(hBSock, 0, pSMTPE);

    return (iResultCode);

}



char           *USmtpBuildRcptPath(char const * const * ppszRcptTo, SVRCFG_HANDLE hSvrConfig)
{

    int             iRcptCount = StrStringsCount(ppszRcptTo);
    char            szDestDomain[MAX_HOST_NAME] = "";

    if (USmtpSplitEmailAddr(ppszRcptTo[0], NULL, szDestDomain) < 0)
        return (NULL);

///////////////////////////////////////////////////////////////////////////////
//  Try to get routing path, if not found simply return an address concat
//  of "ppszRcptTo"
///////////////////////////////////////////////////////////////////////////////
    char            szSpecMXHost[1024] = "";

    if (USmtpGetGateway(hSvrConfig, szDestDomain, szSpecMXHost) < 0)
        return (USmlAddrConcat(ppszRcptTo));


    char           *pszSendRcpt = USmlAddrConcat(ppszRcptTo);

    if (pszSendRcpt == NULL)
        return (NULL);

    char           *pszRcptPath = (char *) SysAlloc(strlen(pszSendRcpt) +
            strlen(szSpecMXHost) + 2);

    if (iRcptCount == 1)
        sprintf(pszRcptPath, "%s:%s", szSpecMXHost, pszSendRcpt);
    else
        sprintf(pszRcptPath, "%s,%s", szSpecMXHost, pszSendRcpt);

    SysFree(pszSendRcpt);


    return (pszRcptPath);

}



char          **USmtpGetMailExchangers(SVRCFG_HANDLE hSvrConfig, const char *pszDomain)
{
///////////////////////////////////////////////////////////////////////////////
//  Try to get default gateways
///////////////////////////////////////////////////////////////////////////////
    char           *pszDefaultGws = SvrGetConfigVar(hSvrConfig, "DefaultSMTPGateways");

    if (pszDefaultGws == NULL)
    {
        ErrSetErrorCode(ERR_NO_PREDEFINED_MX);
        return (NULL);
    }

    char          **ppszMXGWs = StrTokenize(pszDefaultGws, ",;: \t\r\n");


    SysFree(pszDefaultGws);

    return (ppszMXGWs);

}




static int      USmtpGetDomainMX(SVRCFG_HANDLE hSvrConfig, const char *pszDomain,
                        char *&pszMXDomains)
{

///////////////////////////////////////////////////////////////////////////////
//  Exist a configured list of smart DNS hosts ?
//  If not do a full DNS query
///////////////////////////////////////////////////////////////////////////////
    char           *pszSmartDNS = SvrGetConfigVar(hSvrConfig, "SmartDNSHost");

    if (pszSmartDNS == NULL)
        return (DNS_GetDomainMX(pszDomain, pszMXDomains));


    char          **ppszTokens = StrTokenize(pszSmartDNS, ",:");


    SysFree(pszSmartDNS);

    if (ppszTokens == NULL)
        return (ErrGetErrorCode());

    int             iTokensCount = StrStringsCount(ppszTokens);

    if (iTokensCount < 2)
    {
        StrFreeStrings(ppszTokens);

        ErrSetErrorCode(ERR_BAD_SMARTDNSHOST_SYNTAX);
        return (ERR_BAD_SMARTDNSHOST_SYNTAX);
    }

    for (int ii = 0; ii < (iTokensCount - 1); ii += 2)
    {
        int             iQuerySockType = (stricmp(ppszTokens[ii + 1], "tcp") == 0) ? DNS_QUERY_TCP : DNS_QUERY_UDP;

        if (DNS_GetDomainMXDirect(ppszTokens[ii], pszDomain, iQuerySockType,
                        pszMXDomains) == 0)
        {
            StrFreeStrings(ppszTokens);
            return (0);
        }
    }

    StrFreeStrings(ppszTokens);

    return (ErrGetErrorCode());

}




MXS_HANDLE      USmtpGetMXFirst(SVRCFG_HANDLE hSvrConfig, const char *pszDomain,
                        char *pszMXHost)
{

///////////////////////////////////////////////////////////////////////////////
//  Make a DNS query for domain MXs
///////////////////////////////////////////////////////////////////////////////
    char           *pszMXHosts = NULL;

    if (USmtpGetDomainMX(hSvrConfig, pszDomain, pszMXHosts) < 0)
        return (INVALID_MXS_HANDLE);

///////////////////////////////////////////////////////////////////////////////
//  MX records structure allocation
///////////////////////////////////////////////////////////////////////////////
    SmtpMXRecords  *pMXR = (SmtpMXRecords *) SysAlloc(sizeof(SmtpMXRecords));

    if (pMXR == NULL)
    {
        SysFree(pszMXHosts);
        return (INVALID_MXS_HANDLE);
    }

    pMXR->iNumMXRecords = 0;
    pMXR->iCurrMxCost = -1;


///////////////////////////////////////////////////////////////////////////////
//  MX hosts string format = c:h[,c:h]  where "c = cost" and "h = hosts"
///////////////////////////////////////////////////////////////////////////////
    int             iMXCost = INT_MAX,
                    iCurrIndex = -1;
    char           *pszToken = strtok(pszMXHosts, ":, \t\r\n");

    while ((pMXR->iNumMXRecords < MAX_MX_RECORDS) && (pszToken != NULL))
    {
///////////////////////////////////////////////////////////////////////////////
//  Get MX cost
///////////////////////////////////////////////////////////////////////////////
        int             iCost = atoi(pszToken);

        if ((pszToken = strtok(NULL, ":, \t\r\n")) == NULL)
        {
            for (--pMXR->iNumMXRecords; pMXR->iNumMXRecords >= 0; pMXR->iNumMXRecords--)
                SysFree(pMXR->pszMXName[pMXR->iNumMXRecords]);
            SysFree(pMXR);

            SysFree(pszMXHosts);

            ErrSetErrorCode(ERR_INVALID_MXRECS_STRING);
            return (INVALID_MXS_HANDLE);
        }

        pMXR->iMXCost[pMXR->iNumMXRecords] = iCost;
        pMXR->pszMXName[pMXR->iNumMXRecords] = SysStrDup(pszToken);

        if ((iCost < iMXCost) && (iCost >= pMXR->iCurrMxCost))
        {
            iMXCost = iCost;

            strcpy(pszMXHost, pMXR->pszMXName[pMXR->iNumMXRecords]);

            iCurrIndex = pMXR->iNumMXRecords;
        }

        ++pMXR->iNumMXRecords;

        pszToken = strtok(NULL, ":, \t\r\n");
    }

    SysFree(pszMXHosts);

    if (iMXCost == INT_MAX)
    {
        for (--pMXR->iNumMXRecords; pMXR->iNumMXRecords >= 0; pMXR->iNumMXRecords--)
            SysFree(pMXR->pszMXName[pMXR->iNumMXRecords]);
        SysFree(pMXR);

        ErrSetErrorCode(ERR_INVALID_MXRECS_STRING);
        return (INVALID_MXS_HANDLE);
    }

    pMXR->iCurrMxCost = iMXCost;
    pMXR->iMXCost[iCurrIndex] = iMXCost - 1;

    return ((MXS_HANDLE) pMXR);

}



int             USmtpGetMXNext(MXS_HANDLE hMXSHandle, char *pszMXHost)
{

    SmtpMXRecords  *pMXR = (SmtpMXRecords *) hMXSHandle;

    int             iMXCost = INT_MAX,
                    iCurrIndex = -1;

    for (int ii = 0; ii < pMXR->iNumMXRecords; ii++)
    {
        if ((pMXR->iMXCost[ii] < iMXCost) && (pMXR->iMXCost[ii] >= pMXR->iCurrMxCost))
        {
            iMXCost = pMXR->iMXCost[ii];

            strcpy(pszMXHost, pMXR->pszMXName[ii]);

            iCurrIndex = ii;
        }
    }

    if (iMXCost == INT_MAX)
    {
        ErrSetErrorCode(ERR_NO_MORE_MXRECORDS);
        return (ERR_NO_MORE_MXRECORDS);
    }

    pMXR->iCurrMxCost = iMXCost;
    pMXR->iMXCost[iCurrIndex] = iMXCost - 1;

    return (0);

}



void            USmtpMXSClose(MXS_HANDLE hMXSHandle)
{

    SmtpMXRecords  *pMXR = (SmtpMXRecords *) hMXSHandle;

    for (--pMXR->iNumMXRecords; pMXR->iNumMXRecords >= 0; pMXR->iNumMXRecords--)
        SysFree(pMXR->pszMXName[pMXR->iNumMXRecords]);

    SysFree(pMXR);

}




int             USmtpRBLCheck(SYS_INET_ADDR const & PeerInfo)
{

    if (USmtpDnsMapsContained(PeerInfo, RBL_MAPS_DOMAIN))
    {
        ErrSetErrorCode(ERR_RBL_SPAMMER, SysInetNToA(PeerInfo));
        return (ERR_RBL_SPAMMER);
    }

    return (0);

}



int             USmtpRSSCheck(SYS_INET_ADDR const & PeerInfo)
{

    if (USmtpDnsMapsContained(PeerInfo, RSS_MAPS_DOMAIN))
    {
        ErrSetErrorCode(ERR_RSS_SPAMMER, SysInetNToA(PeerInfo));
        return (ERR_RSS_SPAMMER);
    }

    return (0);

}



bool            USmtpDnsMapsContained(SYS_INET_ADDR const & PeerInfo, char const * pszMapsServer)
{

    NET_ADDRESS     NetAddr = SysGetAddrAddress(PeerInfo);
    SYS_UINT8       AddrBytes[sizeof(NET_ADDRESS)];

    *((NET_ADDRESS *) AddrBytes) = NetAddr;

    char            szMapsQuery[256] = "";

    sprintf(szMapsQuery, "%u.%u.%u.%u.%s",
            (unsigned int) AddrBytes[3], (unsigned int) AddrBytes[2],
            (unsigned int) AddrBytes[1], (unsigned int) AddrBytes[0], pszMapsServer);


    return ((SysGetHostByName(szMapsQuery) != SYS_INVALID_NET_ADDRESS) ? true : false);

}




static char    *USmtpGetSpammersFilePath(char *pszSpamFilePath)
{

    CfgGetRootPath(pszSpamFilePath);

    strcat(pszSpamFilePath, SMTP_SPAMMERS_FILE);

    return (pszSpamFilePath);

}




int             USmtpSpammerCheck(const SYS_INET_ADDR & PeerInfo)
{

    char            szSpammersFilePath[SYS_MAX_PATH] = "";

    USmtpGetSpammersFilePath(szSpammersFilePath);


    SHB_HANDLE      hSWMRResource = SWMRCreateReadLock(SWMR_SpammersFile);

    if (hSWMRResource == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pSpammersFile = fopen(szSpammersFilePath, "rt");

    if (pSpammersFile == NULL)
    {
        SWMRCloseReadUnlock(hSWMRResource);

        ErrSetErrorCode(ERR_FILE_OPEN);
        return (ERR_FILE_OPEN);
    }


    NET_ADDRESS     TestAddr = SysGetAddrAddress(PeerInfo);


    char            szSpammerLine[SPAMMERS_LINE_MAX] = "";

    while (MscGetConfigLine(szSpammerLine, sizeof(szSpammerLine) - 1, pSpammersFile) != NULL)
    {
        char          **ppszStrings = StrGetTabLineStrings(szSpammerLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);
        AddressFilter   AF;

        if ((iFieldsCount > 0) &&
                (MscLoadAddressFilter(ppszStrings, iFieldsCount, AF) == 0) &&
                MscAddressMatch(AF, TestAddr))
        {
            StrFreeStrings(ppszStrings);
            fclose(pSpammersFile);
            SWMRCloseReadUnlock(hSWMRResource);

            ErrSetErrorCode(ERR_SPAMMER_IP, SysInetNToA(PeerInfo));
            return (ERR_SPAMMER_IP);
        }

        StrFreeStrings(ppszStrings);
    }

    fclose(pSpammersFile);

    SWMRCloseReadUnlock(hSWMRResource);

    return (0);

}
