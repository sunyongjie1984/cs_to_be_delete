/*
 *  MailSvr by Davide Libenzi ( Intranet and Internet mail server )
 *  Copyright (C) 1999  Davide Libenzi
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Davide Libenzi <davidel@maticad.it>
 *
 */


#ifndef _RESLOCKS_H
#define _RESLOCKS_H




#define MAIL_USER                   0
#define MAX_USER0_RES               32
#define MAX_USER_RES                8

///////////////////////////////////////////////////////////////////////////////
//  "Normal" users resources
///////////////////////////////////////////////////////////////////////////////
#define RES_PROFILE                 0
#define RES_MAILBOX                 1
#define RES_MLUSERSTABLE            2
#define RES_MAILPROCESS_FILE        3

///////////////////////////////////////////////////////////////////////////////
//  MAIL_USER resources
///////////////////////////////////////////////////////////////////////////////
#define RES_POP3_LOGFILE            1
#define RES_SMTP_LOGFILE            2
#define RES_FINGER_LOGFILE          3
#define RES_SMAIL_LOGFILE           4
#define RES_CTRL_LOGFILE            5





#define STD_WAIT_GATES              11

#define INVALID_RLCK_HANDLE         ((RLCK_HANDLE) 0)



typedef unsigned long RLCK_HANDLE;




int             RLckInitLockers(int iNumWaitGates = STD_WAIT_GATES);
int             RLckCleanupLockers(void);
RLCK_HANDLE     RLckLockEX(unsigned int uUserID, unsigned int uResID);
int             RLckUnlockEX(RLCK_HANDLE hLock);
RLCK_HANDLE     RLckLockSH(unsigned int uUserID, unsigned int uResID);
int             RLckUnlockSH(RLCK_HANDLE hLock);




#endif
