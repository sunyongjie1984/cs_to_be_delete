/*
 *  MailSvr by Davide Libenzi ( Intranet and Internet mail server )
 *  Copyright (C) 1999  Davide Libenzi
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Davide Libenzi <davidel@maticad.it>
 *
 */


#include "SysInclude.h"
#include "SysDep.h"
#include "SvrDefines.h"
#include "SList.h"
#include "ShBlocks.h"
#include "StrUtils.h"
#include "MiscUtils.h"
#include "ResLocks.h"
#include "BuffSock.h"
#include "SvrUtils.h"
#include "UsrUtils.h"
#include "SMTPUtils.h"
#include "SMAILUtils.h"
#include "ExtAliases.h"
#include "UsrMailList.h"
#include "MailConfig.h"
#include "SMAILSvr.h"
#include "AppDefines.h"
#include "MailSvr.h"








#define CUSTOM_PROC_LINE_MAX        1024
#define FILTER_LINE_MAX             1024
#define FILTER_TIMEOUT              60
#define FILTER_PRIORITY             SYS_PRIORITY_NORMAL
#define FILTER_OUT_EXITCODE         99
#define MODIFY_EXITCODE             100












static SMAILConfig *SMAILGetConfigCopy(SHB_HANDLE hShbSMAIL);
static int      SMAILThreadCountAdd(long lCount, SHB_HANDLE hShbSMAIL,
                        SMAILConfig * pSMAILCfg = NULL);
static int      SMAILLogEnabled(SHB_HANDLE hShbSMAIL, SMAILConfig * pSMAILCfg = NULL);
static int      SMAILTryProcessSpool(SHB_HANDLE hShbSMAIL);
static int      SMAILProcessFile(SHB_HANDLE hShbSMAIL, SPLF_HANDLE hFSpool);
static int      SMAILMailingListExplode(UserInfo * pUI, SPLF_HANDLE hFSpool);
static int      SMAILRemoteMsgSMTPSend(SHB_HANDLE hShbSMAIL, SPLF_HANDLE hFSpool,
                        char const * pszDestDomain, SMTPError * pSMTPE = NULL);
static int      SMAILHandleRemoteUserMessage(SHB_HANDLE hShbSMAIL, SPLF_HANDLE hFSpool,
                        char const * pszDestDomain);
static int      SMAILCustomProcessMessage(SHB_HANDLE hShbSMAIL, SPLF_HANDLE hFSpool,
                        char const * pszDestDomain, char const * pszCustFilePath);
static int      SMAILCmdMacroSubstitutes(char **ppszCmdTokens, SPLF_HANDLE hFSpool);
static int      SMAILCmd_external(SHB_HANDLE hShbSMAIL, char const * pszDestDomain, char **ppszCmdTokens,
                        int iNumTokens, SPLF_HANDLE hFSpool);
static int      SMAILCmd_wait(SHB_HANDLE hShbSMAIL, char const * pszDestDomain, char **ppszCmdTokens,
                        int iNumTokens, SPLF_HANDLE hFSpool);
static int      SMAILCmd_smtp(SHB_HANDLE hShbSMAIL, char const * pszDestDomain, char **ppszCmdTokens,
                        int iNumTokens, SPLF_HANDLE hFSpool);
static int      SMAILCmd_redirect(SHB_HANDLE hShbSMAIL, char const * pszDestDomain, char **ppszCmdTokens,
                        int iNumTokens, SPLF_HANDLE hFSpool);
static int      SMAILCmd_lredirect(SHB_HANDLE hShbSMAIL, char const * pszDestDomain, char **ppszCmdTokens,
                        int iNumTokens, SPLF_HANDLE hFSpool);
static int      SMAILFilterMessage(SHB_HANDLE hShbSMAIL, char const * pszSpoolFilePath);
static int      SMAILFilterMacroSubstitutes(char **ppszCmdTokens, char const * pszSpoolFilePath,
                        SpoolFileHeader const & SFH);











static SMAILConfig *SMAILGetConfigCopy(SHB_HANDLE hShbSMAIL)
{

    SMAILConfig    *pPSYNCCfg = (SMAILConfig *) ShbLock(hShbSMAIL);

    if (pPSYNCCfg == NULL)
        return (NULL);

    SMAILConfig    *pNewPSYNCCfg = (SMAILConfig *) SysAlloc(sizeof(SMAILConfig));

    if (pNewPSYNCCfg != NULL)
        memcpy(pNewPSYNCCfg, pPSYNCCfg, sizeof(SMAILConfig));

    ShbUnlock(hShbSMAIL);

    return (pNewPSYNCCfg);

}



static int      SMAILThreadCountAdd(long lCount, SHB_HANDLE hShbSMAIL,
                        SMAILConfig * pSMAILCfg)
{

    int             iDoUnlock = 0;

    if (pSMAILCfg == NULL)
    {
        if ((pSMAILCfg = (SMAILConfig *) ShbLock(hShbSMAIL)) == NULL)
            return (ErrGetErrorCode());

        ++iDoUnlock;
    }

    pSMAILCfg->lThreadCount += lCount;

    if (iDoUnlock)
        ShbUnlock(hShbSMAIL);

    return (0);

}



static int      SMAILLogEnabled(SHB_HANDLE hShbSMAIL, SMAILConfig * pSMAILCfg)
{

    int             iDoUnlock = 0;

    if (pSMAILCfg == NULL)
    {
        if ((pSMAILCfg = (SMAILConfig *) ShbLock(hShbSMAIL)) == NULL)
            return (ErrGetErrorCode());

        ++iDoUnlock;
    }

    unsigned long   ulFlags = pSMAILCfg->ulFlags;

    if (iDoUnlock)
        ShbUnlock(hShbSMAIL);

    return ((ulFlags & SMAILF_LOG_ENABLED) ? 1 : 0);

}



unsigned int    SMAILThreadProc(void *pThreadData)
{

    SHB_HANDLE      hShbSMAIL = ShbConnectBlock(SHB_SMAILSvr);

    if (hShbSMAIL == SHB_INVALID_HANDLE)
    {
        ErrorPush();
        SysLogMessage(LOG_LEV_ERROR, "%s\n", ErrGetErrorString());
        return (ErrorPop());
    }

    SYS_SEMAPHORE   SemSpoolID = SysConnectSemaphore(0, MAX_SPOOL_FILES, SemSMAILSpoolName);

    if (SemSpoolID == SYS_INVALID_SEMAPHORE)
    {
        ErrorPush();
        SysLogMessage(LOG_LEV_ERROR, "%s\n", ErrGetErrorString());
        ShbCloseBlock(hShbSMAIL);
        return (ErrorPop());
    }


    SMAILConfig    *pSMAILCfg = (SMAILConfig *) ShbLock(hShbSMAIL);

    if (pSMAILCfg == NULL)
    {
        ErrorPush();
        SysLogMessage(LOG_LEV_ERROR, "%s\n", ErrGetErrorString());
        SysCloseSemaphore(SemSpoolID);
        ShbCloseBlock(hShbSMAIL);
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Get retry timeout and thread id
///////////////////////////////////////////////////////////////////////////////
    int             iRetryTimeout = pSMAILCfg->iRetryTimeout;
    long            lThreadId = pSMAILCfg->lThreadCount;

///////////////////////////////////////////////////////////////////////////////
//  Increase thread count
///////////////////////////////////////////////////////////////////////////////
    SMAILThreadCountAdd(+1, hShbSMAIL, pSMAILCfg);

    ShbUnlock(hShbSMAIL);


    SysLogMessage(LOG_LEV_MESSAGE, "SMAIL thread [%02ld] started\n", lThreadId);

    for (;;)
    {
///////////////////////////////////////////////////////////////////////////////
//  Wait for signaled semaphore or retry timeout
///////////////////////////////////////////////////////////////////////////////
        SysWaitSemaphore(SemSpoolID, iRetryTimeout);


        SysLogMessage(LOG_LEV_MESSAGE, "SMAIL thread [%02ld] released\n", lThreadId);


        pSMAILCfg = (SMAILConfig *) ShbLock(hShbSMAIL);

        if ((pSMAILCfg == NULL) || (pSMAILCfg->ulFlags & SMAILF_STOP_SERVER))
        {
            SysLogMessage(LOG_LEV_MESSAGE, "SMAIL thread [%02ld] exiting\n", lThreadId);

            if (pSMAILCfg != NULL)
                ShbUnlock(hShbSMAIL);
            break;
        }

///////////////////////////////////////////////////////////////////////////////
//  Refresh retry timeout
///////////////////////////////////////////////////////////////////////////////
        iRetryTimeout = pSMAILCfg->iRetryTimeout;


        int             iMsg_x_Wakeup = pSMAILCfg->iMsg_x_Wakeup;

        ShbUnlock(hShbSMAIL);

///////////////////////////////////////////////////////////////////////////////
//  Process spool messages
///////////////////////////////////////////////////////////////////////////////
        for (int ii = 0; ii < iMsg_x_Wakeup; ii++)
            SMAILTryProcessSpool(hShbSMAIL);


        SysLogMessage(LOG_LEV_MESSAGE, "SMAIL thread [%02ld] sleeping\n", lThreadId);
    }

///////////////////////////////////////////////////////////////////////////////
//  Decrease thread count
///////////////////////////////////////////////////////////////////////////////
    SMAILThreadCountAdd(-1, hShbSMAIL);


    SysCloseSemaphore(SemSpoolID);

    ShbCloseBlock(hShbSMAIL);

    SysLogMessage(LOG_LEV_MESSAGE, "SMAIL thread [%02ld] stopped\n", lThreadId);

    return (0);

}



static int      SMAILTryProcessSpool(SHB_HANDLE hShbSMAIL)
{

    SMAILConfig    *pSMAILCfg = SMAILGetConfigCopy(hShbSMAIL);

    if (pSMAILCfg == NULL)
    {
        ErrorPush();
        SysLogMessage(LOG_LEV_ERROR, "%s\n", ErrGetErrorString());
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Get a spool file to process
///////////////////////////////////////////////////////////////////////////////
    char            szSpoolFileName[SYS_MAX_PATH] = "";

    if (SvrGetSpoolFileLock(szSpoolFileName, pSMAILCfg->iRetryTimeout,
                    pSMAILCfg->iMaxRetry) < 0)
    {
        ErrorPush();
        SysFree(pSMAILCfg);
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Build the full file pathname
///////////////////////////////////////////////////////////////////////////////
    char            szSpoolFilePath[SYS_MAX_PATH] = "";

    SvrGetSpoolFilePath(szSpoolFileName, szSpoolFilePath);

///////////////////////////////////////////////////////////////////////////////
//  Filter message
///////////////////////////////////////////////////////////////////////////////
    if (SMAILFilterMessage(hShbSMAIL, szSpoolFilePath) < 0)
    {
        ErrorPush();
        SysFree(pSMAILCfg);
        SvrUnlockSpoolFile(szSpoolFileName);
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Create the handle to manage the spool file
///////////////////////////////////////////////////////////////////////////////
    SPLF_HANDLE     hFSpool = USmlCreateHandle(szSpoolFilePath);

    if (hFSpool == INVALID_SPLF_HANDLE)
    {
        ErrorPush();
        SysLogMessage(LOG_LEV_ERROR, "%s\n", ErrGetErrorString());
        SysFree(pSMAILCfg);
        SvrSpoolMoveToErrorsFile(szSpoolFileName);
        SvrUnlockSpoolFile(szSpoolFileName);
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Process spool file
///////////////////////////////////////////////////////////////////////////////
    if (SMAILProcessFile(hShbSMAIL, hFSpool) < 0)
    {
        ErrorPush();
        USmlCloseHandle(hFSpool);
        SysFree(pSMAILCfg);
        SvrUnlockSpoolFile(szSpoolFileName);
        return (ErrorPop());
    }


    USmlCloseHandle(hFSpool);


///////////////////////////////////////////////////////////////////////////////
//  Remove spool file
///////////////////////////////////////////////////////////////////////////////
    SvrSpoolRemoveFile(szSpoolFileName);

///////////////////////////////////////////////////////////////////////////////
//  Unlock spool file
///////////////////////////////////////////////////////////////////////////////
    SvrUnlockSpoolFile(szSpoolFileName);


    SysFree(pSMAILCfg);

    return (0);

}



static int      SMAILProcessFile(SHB_HANDLE hShbSMAIL, SPLF_HANDLE hFSpool)
{

    char const     *pszSMTPDomain = USmlGetSMTPDomain(hFSpool);
    char const     *pszSmtpMessageID = USmlGetSmtpMessageID(hFSpool);
    char const     *pszSpoolFile = USmlGetSpoolFile(hFSpool);
    char const     *const * ppszFrom = USmlGetMailFrom(hFSpool);
    char const     *const * ppszRcpt = USmlGetRcptTo(hFSpool);

    int             iFromDomains = StrStringsCount(ppszFrom),
                    iRcptDomains = StrStringsCount(ppszRcpt);

    char            szDestUser[MAX_ADDR_NAME] = "",
                    szDestDomain[MAX_ADDR_NAME] = "";

    if ((iRcptDomains < 1) ||
            (USmtpSplitEmailAddr(ppszRcpt[0], szDestUser, szDestDomain) < 0))
        return (ErrGetErrorCode());

///////////////////////////////////////////////////////////////////////////////
//  Check if we are at home
///////////////////////////////////////////////////////////////////////////////
    UserInfo       *pUI = UsrGetUserByNameOrAlias(szDestDomain, szDestUser);

    if (pUI != NULL)
    {
        SysLogMessage(LOG_LEV_MESSAGE, "SMAIL local SMTP = \"%s\" From = <%s> To = <%s>\n",
                pszSMTPDomain, ppszFrom[iFromDomains - 1], ppszRcpt[0]);

        if (UsrGetUserType(pUI) == usrTypeUser)
        {
///////////////////////////////////////////////////////////////////////////////
//  Local user case
///////////////////////////////////////////////////////////////////////////////
            LocalMailProcConfig LMPC;

            ZeroData(LMPC);
            LMPC.ulFlags = (SMAILLogEnabled(hShbSMAIL)) ? LMPCF_LOG_ENABLED : 0;

            if (USmlProcessLocalUserMessage(pUI, hFSpool, LMPC) < 0)
            {
                ErrorPush();
                UsrFreeUserInfo(pUI);
                return (ErrorPop());
            }
        }
        else
        {
///////////////////////////////////////////////////////////////////////////////
//  Local mailing list case
///////////////////////////////////////////////////////////////////////////////
            if (SMAILMailingListExplode(pUI, hFSpool) < 0)
            {
                ErrorPush();
                UsrFreeUserInfo(pUI);
                return (ErrorPop());
            }
        }

        UsrFreeUserInfo(pUI);
    }
    else
    {
///////////////////////////////////////////////////////////////////////////////
//  Remote user case ( or custom domain user )
///////////////////////////////////////////////////////////////////////////////
        if (SMAILHandleRemoteUserMessage(hShbSMAIL, hFSpool, szDestDomain) < 0)
            return (ErrGetErrorCode());

    }

    return (0);

}




static int      SMAILMailingListExplode(UserInfo * pUI, SPLF_HANDLE hFSpool)
{

    char const     *const * ppszFrom = USmlGetMailFrom(hFSpool);
    char const     *const * ppszRcpt = USmlGetRcptTo(hFSpool);

    char            szDestUser[MAX_ADDR_NAME] = "",
                    szDestDomain[MAX_ADDR_NAME] = "";

    if (USmtpSplitEmailAddr(ppszRcpt[0], szDestUser, szDestDomain) < 0)
        return (ErrGetErrorCode());


    USRML_HANDLE    hUsersDB = UsrMLOpenDB(pUI);

    if (hUsersDB == INVALID_USRML_HANDLE)
        return (ErrGetErrorCode());

///////////////////////////////////////////////////////////////////////////////
//  Mailing list scan
///////////////////////////////////////////////////////////////////////////////
    char const     *pszUser = UsrMLGetFirstUser(hUsersDB);

    for (; pszUser != NULL; pszUser = UsrMLGetNextUser(hUsersDB))
    {
        char            szSpoolFile[SYS_MAX_PATH] = "";

        SysGetTmpFile(szSpoolFile);

        if (USmlCreateSpoolFile(hFSpool, NULL, pszUser, szSpoolFile) < 0)
        {
            ErrorPush();
            UsrMLCloseDB(hUsersDB);
            return (ErrorPop());
        }

///////////////////////////////////////////////////////////////////////////////
//  Transfer file to the spool
///////////////////////////////////////////////////////////////////////////////
        char            szMessageId[256] = "";

        if (USmtpMoveToSpool(szDestDomain, szSpoolFile, szMessageId) < 0)
        {
            ErrorPush();
            SysRemove(szSpoolFile);
            UsrMLCloseDB(hUsersDB);
            return (ErrorPop());
        }
    }

    UsrMLCloseDB(hUsersDB);


    return (0);

}




static int      SMAILRemoteMsgSMTPSend(SHB_HANDLE hShbSMAIL, SPLF_HANDLE hFSpool,
                        char const * pszDestDomain, SMTPError * pSMTPE)
{

    char const     *pszSMTPDomain = USmlGetSMTPDomain(hFSpool);
    char const     *pszSmtpMessageID = USmlGetSmtpMessageID(hFSpool);
    char const     *pszSpoolFile = USmlGetSpoolFile(hFSpool);
    char const     *pszMailFrom = USmlMailFrom(hFSpool);
    char const     *pszSendMailFrom = USmlSendMailFrom(hFSpool);
    char const     *pszRcptTo = USmlRcptTo(hFSpool);
    char const     *pszSendRcptTo = USmlSendRcptTo(hFSpool);
    char const     *pszMailFile = USmlGetMailFile(hFSpool);
    char const     *pszRelayDomain = USmlGetRelayDomain(hFSpool);

///////////////////////////////////////////////////////////////////////////////
//  If it's a relayed message use the associated relay
///////////////////////////////////////////////////////////////////////////////
    if (pszRelayDomain != NULL)
    {
        SysLogMessage(LOG_LEV_MESSAGE, "SMAIL SMTP-Send CMX = \"%s\" SMTP = \"%s\" From = \"%s\" To = \"%s\"\n",
                pszRelayDomain, pszSMTPDomain, pszMailFrom, pszRcptTo);

        if (pSMTPE != NULL)
            USmtpCleanupError(pSMTPE);

        if (USmtpSendMail(pszRelayDomain, pszSMTPDomain, pszSendMailFrom, pszSendRcptTo,
                        pszMailFile, 0, pSMTPE) < 0)
        {
            ErrorPush();

            ErrLogMessage(LOG_LEV_MESSAGE,
                    "SMAIL SMTP-Send CMX = \"%s\" SMTP = \"%s\" From = \"%s\" To = \"%s\" Failed !\n",
                    pszRelayDomain, pszSMTPDomain, pszMailFrom, pszRcptTo);

            SvrSpoolErrLogMessage(pszSpoolFile,
                    "SMAIL SMTP-Send CMX = \"%s\" SMTP = \"%s\" From = \"%s\" To = \"%s\" Failed !\n",
                    pszRelayDomain, pszSMTPDomain, pszMailFrom, pszRcptTo);

            return (ErrorPop());
        }

        if (SMAILLogEnabled(hShbSMAIL))
            USmlLogMessage(hFSpool, "SMTP", pszRelayDomain);

        return (0);
    }

///////////////////////////////////////////////////////////////////////////////
//  Try to get custom mail exchangers or DNS mail exchangers and if booth tests
//  fails try direct ( I don't know if this is a standard but exist domains
//  that does not have MXs )
///////////////////////////////////////////////////////////////////////////////
    SVRCFG_HANDLE   hSvrConfig = SvrGetConfigHandle();

    if (hSvrConfig == INVALID_SVRCFG_HANDLE)
        return (ErrGetErrorCode());

    char          **ppszMXGWs = USmtpGetMailExchangers(hSvrConfig, pszDestDomain);

    if (ppszMXGWs == NULL)
    {
        char            szDomainMXHost[256] = "";
        MXS_HANDLE      hMXSHandle = USmtpGetMXFirst(hSvrConfig, pszDestDomain,
                szDomainMXHost);

        SvrReleaseConfigHandle(hSvrConfig);

        if (hMXSHandle != INVALID_MXS_HANDLE)
        {
            int             iSendErrorCode = 0;

            do
            {
                SysLogMessage(LOG_LEV_MESSAGE, "SMAIL SMTP-Send MX = \"%s\" SMTP = \"%s\" From = \"%s\" To = \"%s\"\n",
                        szDomainMXHost, pszSMTPDomain, pszMailFrom, pszRcptTo);

                if (pSMTPE != NULL)
                    USmtpCleanupError(pSMTPE);

                if ((iSendErrorCode = USmtpSendMail(szDomainMXHost, pszSMTPDomain,
                                        pszSendMailFrom, pszSendRcptTo, pszMailFile, 0, pSMTPE)) == 0)
                {
///////////////////////////////////////////////////////////////////////////////
//  Log Mailer operation
///////////////////////////////////////////////////////////////////////////////
                    if (SMAILLogEnabled(hShbSMAIL))
                        USmlLogMessage(hFSpool, "SMTP", szDomainMXHost);

                    break;
                }


                ErrLogMessage(LOG_LEV_MESSAGE,
                        "SMAIL SMTP-Send MX = \"%s\" SMTP = \"%s\" From = \"%s\" To = \"%s\" Failed !\n",
                        szDomainMXHost, pszSMTPDomain, pszMailFrom, pszRcptTo);

                SvrSpoolErrLogMessage(pszSpoolFile,
                        "SMAIL SMTP-Send MX = \"%s\" SMTP = \"%s\" From = \"%s\" To = \"%s\" Failed !\n",
                        szDomainMXHost, pszSMTPDomain, pszMailFrom, pszRcptTo);

                if ((pSMTPE != NULL) && USmtpIsFatalError(pSMTPE))
                    break;


            } while (USmtpGetMXNext(hMXSHandle, szDomainMXHost) == 0);

            USmtpMXSClose(hMXSHandle);

            if (iSendErrorCode < 0)
                return (iSendErrorCode);

        }
        else
        {
///////////////////////////////////////////////////////////////////////////////
//  MX records for destination domain not found, try direct !
///////////////////////////////////////////////////////////////////////////////
            SysLogMessage(LOG_LEV_MESSAGE,
                    "MX records for domain \"%s\" not found, trying direct.\n", pszDestDomain);

            SysLogMessage(LOG_LEV_MESSAGE, "SMAIL SMTP-Send FF = \"%s\" SMTP = \"%s\" From = \"%s\" To = \"%s\"\n",
                    pszDestDomain, pszSMTPDomain, pszMailFrom, pszRcptTo);


            if (pSMTPE != NULL)
                USmtpCleanupError(pSMTPE);

            if (USmtpSendMail(pszDestDomain, pszSMTPDomain, pszSendMailFrom, pszSendRcptTo,
                            pszMailFile, 0, pSMTPE) < 0)
            {
                ErrorPush();

                ErrLogMessage(LOG_LEV_MESSAGE,
                        "SMAIL SMTP-Send FF = \"%s\" SMTP = \"%s\" From = \"%s\" To = \"%s\" Failed !\n",
                        pszDestDomain, pszSMTPDomain, pszMailFrom, pszRcptTo);

                SvrSpoolErrLogMessage(pszSpoolFile,
                        "SMAIL SMTP-Send FF = \"%s\" SMTP = \"%s\" From = \"%s\" To = \"%s\" Failed !\n",
                        pszDestDomain, pszSMTPDomain, pszMailFrom, pszRcptTo);

                return (ErrorPop());
            }

///////////////////////////////////////////////////////////////////////////////
//  Log Mailer operation
///////////////////////////////////////////////////////////////////////////////
            if (SMAILLogEnabled(hShbSMAIL))
                USmlLogMessage(hFSpool, "SMTP", pszDestDomain);
        }
    }
    else
    {
        SvrReleaseConfigHandle(hSvrConfig);

        int             iSendErrorCode = 0;

        for (int ss = 0; ppszMXGWs[ss] != NULL; ss++)
        {
            SysLogMessage(LOG_LEV_MESSAGE, "SMAIL SMTP-Send MX = \"%s\" SMTP = \"%s\" From = \"%s\" To = \"%s\"\n",
                    ppszMXGWs[ss], pszSMTPDomain, pszMailFrom, pszRcptTo);

            if (pSMTPE != NULL)
                USmtpCleanupError(pSMTPE);

            if ((iSendErrorCode = USmtpSendMail(ppszMXGWs[ss], pszSMTPDomain,
                                    pszSendMailFrom, pszSendRcptTo, pszMailFile, 0, pSMTPE)) == 0)
            {
///////////////////////////////////////////////////////////////////////////////
//  Log Mailer operation
///////////////////////////////////////////////////////////////////////////////
                if (SMAILLogEnabled(hShbSMAIL))
                    USmlLogMessage(hFSpool, "SMTP", ppszMXGWs[ss]);

                break;
            }


            ErrLogMessage(LOG_LEV_MESSAGE,
                    "SMAIL SMTP-Send MX = \"%s\" SMTP = \"%s\" From = \"%s\" To = \"%s\" Failed !\n",
                    ppszMXGWs[ss], pszSMTPDomain, pszMailFrom, pszRcptTo);

            SvrSpoolErrLogMessage(pszSpoolFile,
                    "SMAIL SMTP-Send MX = \"%s\" SMTP = \"%s\" From = \"%s\" To = \"%s\" Failed !\n",
                    ppszMXGWs[ss], pszSMTPDomain, pszMailFrom, pszRcptTo);

            if ((pSMTPE != NULL) && USmtpIsFatalError(pSMTPE))
                break;
        }

        StrFreeStrings(ppszMXGWs);

        if (iSendErrorCode < 0)
            return (iSendErrorCode);
    }

    return (0);

}



static int      SMAILHandleRemoteUserMessage(SHB_HANDLE hShbSMAIL, SPLF_HANDLE hFSpool,
                        char const * pszDestDomain)
{

///////////////////////////////////////////////////////////////////////////////
//  If not exist domain custom processing use standard SMTP delivery
///////////////////////////////////////////////////////////////////////////////
    char            szCustFilePath[SYS_MAX_PATH] = "";

    if (USmlGetDomainMsgCustomFile(hFSpool, pszDestDomain, szCustFilePath) < 0)
    {
        SMTPError       SMTPE;

        USmtpInitError(&SMTPE);

        if (SMAILRemoteMsgSMTPSend(hShbSMAIL, hFSpool, pszDestDomain, &SMTPE) < 0)
        {
            ErrorPush();
///////////////////////////////////////////////////////////////////////////////
//  If a permanent SMTP error has been detected, then notify the message
//  sender and remove the spool file
///////////////////////////////////////////////////////////////////////////////
            if (USmtpIsFatalError(&SMTPE))
            {
                char const     *pszSpoolFile = USmlGetSpoolFile(hFSpool);

                SvrSpoolRemoveNotify(pszSpoolFile, USmtpGetErrorMessage(&SMTPE));
            }

            USmtpCleanupError(&SMTPE);

            return (ErrorPop());
        }

        USmtpCleanupError(&SMTPE);

        return (0);
    }


///////////////////////////////////////////////////////////////////////////////
//  Do custom message processing
///////////////////////////////////////////////////////////////////////////////

    return (SMAILCustomProcessMessage(hShbSMAIL, hFSpool, pszDestDomain, szCustFilePath));

}




static int      SMAILCustomProcessMessage(SHB_HANDLE hShbSMAIL, SPLF_HANDLE hFSpool,
                        char const * pszDestDomain, char const * pszCustFilePath)
{

    FILE           *pCPFile = fopen(pszCustFilePath, "rt");

    if (pCPFile == NULL)
    {
        ErrSetErrorCode(ERR_FILE_OPEN);
        return (ERR_FILE_OPEN);
    }

///////////////////////////////////////////////////////////////////////////////
//  Create pushback command file
///////////////////////////////////////////////////////////////////////////////
    char            szTmpFile[SYS_MAX_PATH] = "";

    SysGetTmpFile(szTmpFile);

    FILE           *pPushBFile = fopen(szTmpFile, "wt");

    if (pPushBFile == NULL)
    {
        fclose(pCPFile);

        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }


    int             iPushBackCmds = 0;
    char            szCmdLine[CUSTOM_PROC_LINE_MAX] = "";

    while (MscGetConfigLine(szCmdLine, sizeof(szCmdLine) - 1, pCPFile) != NULL)
    {
        char          **ppszCmdTokens = StrGetTabLineStrings(szCmdLine);

        if (ppszCmdTokens == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszCmdTokens);

        if (iFieldsCount > 0)
        {
///////////////////////////////////////////////////////////////////////////////
//  Do command line macro substitution
///////////////////////////////////////////////////////////////////////////////
            SMAILCmdMacroSubstitutes(ppszCmdTokens, hFSpool);


            int             iCmdResult = 0;

            if (stricmp(ppszCmdTokens[0], "external") == 0)
                iCmdResult = SMAILCmd_external(hShbSMAIL, pszDestDomain, ppszCmdTokens,
                        iFieldsCount, hFSpool);
            else if (stricmp(ppszCmdTokens[0], "wait") == 0)
                iCmdResult = SMAILCmd_wait(hShbSMAIL, pszDestDomain, ppszCmdTokens,
                        iFieldsCount, hFSpool);
            else if (stricmp(ppszCmdTokens[0], "smtp") == 0)
                iCmdResult = SMAILCmd_smtp(hShbSMAIL, pszDestDomain, ppszCmdTokens,
                        iFieldsCount, hFSpool);
            else if (stricmp(ppszCmdTokens[0], "redirect") == 0)
                iCmdResult = SMAILCmd_redirect(hShbSMAIL, pszDestDomain, ppszCmdTokens,
                        iFieldsCount, hFSpool);
            else if (stricmp(ppszCmdTokens[0], "lredirect") == 0)
                iCmdResult = SMAILCmd_lredirect(hShbSMAIL, pszDestDomain, ppszCmdTokens,
                        iFieldsCount, hFSpool);

///////////////////////////////////////////////////////////////////////////////
//  Test if We must save a failed command
//  <0 = Error ; ==0 = Success ; >0 = Transient error ( save the command )
///////////////////////////////////////////////////////////////////////////////
            if (iCmdResult > 0)
            {
                fprintf(pPushBFile, "%s\n", szCmdLine);

                ++iPushBackCmds;
            }
        }

        StrFreeStrings(ppszCmdTokens);
    }

    fclose(pPushBFile);
    fclose(pCPFile);

    SysRemove(pszCustFilePath);

    if (iPushBackCmds > 0)
    {
///////////////////////////////////////////////////////////////////////////////
//  If commands left out of processing, push them into the custom file
///////////////////////////////////////////////////////////////////////////////
        if (MscMoveFile(szTmpFile, pszCustFilePath) < 0)
            return (ErrGetErrorCode());

        ErrSetErrorCode(ERR_INCOMPLETE_PROCESSING);
        return (ERR_INCOMPLETE_PROCESSING);
    }

    SysRemove(szTmpFile);

    return (0);

}




static int      SMAILCmdMacroSubstitutes(char **ppszCmdTokens, SPLF_HANDLE hFSpool)
{

    char const     *pszSMTPDomain = USmlGetSMTPDomain(hFSpool);
    char const     *const * ppszFrom = USmlGetMailFrom(hFSpool);
    char const     *const * ppszRcpt = USmlGetRcptTo(hFSpool);
    char const     *pszSmtpMessageID = USmlGetSmtpMessageID(hFSpool);
    char const     *pszMessageID = USmlGetSpoolFile(hFSpool);
    char const     *pszMailFile = USmlGetMailFile(hFSpool);
    int             iFromDomains = StrStringsCount(ppszFrom),
                    iRcptDomains = StrStringsCount(ppszRcpt);

    for (int ii = 0; ppszCmdTokens[ii] != NULL; ii++)
    {
        if (strcmp(ppszCmdTokens[ii], "@@FROM") == 0)
        {
            char           *pszNewValue = SysStrDup((iFromDomains > 0) ? ppszFrom[iFromDomains - 1] : "");

            if (pszNewValue == NULL)
                return (ErrGetErrorCode());

            SysFree(ppszCmdTokens[ii]);

            ppszCmdTokens[ii] = pszNewValue;
        }
        else if (strcmp(ppszCmdTokens[ii], "@@RCPT") == 0)
        {
            char           *pszNewValue = SysStrDup((iRcptDomains > 0) ? ppszRcpt[iRcptDomains - 1] : "");

            if (pszNewValue == NULL)
                return (ErrGetErrorCode());

            SysFree(ppszCmdTokens[ii]);

            ppszCmdTokens[ii] = pszNewValue;
        }
        else if (strcmp(ppszCmdTokens[ii], "@@FILE") == 0)
        {
            char           *pszNewValue = SysStrDup(pszMailFile);

            if (pszNewValue == NULL)
                return (ErrGetErrorCode());

            SysFree(ppszCmdTokens[ii]);

            ppszCmdTokens[ii] = pszNewValue;
        }
        else if (strcmp(ppszCmdTokens[ii], "@@MSGID") == 0)
        {
            char           *pszNewValue = SysStrDup(pszMessageID);

            if (pszNewValue == NULL)
                return (ErrGetErrorCode());

            SysFree(ppszCmdTokens[ii]);

            ppszCmdTokens[ii] = pszNewValue;
        }
        else if (strcmp(ppszCmdTokens[ii], "@@MSGREF") == 0)
        {
            char           *pszNewValue = SysStrDup(pszSmtpMessageID);

            if (pszNewValue == NULL)
                return (ErrGetErrorCode());

            SysFree(ppszCmdTokens[ii]);

            ppszCmdTokens[ii] = pszNewValue;
        }
        else if (strcmp(ppszCmdTokens[ii], "@@TMPFILE") == 0)
        {
            char            szTmpFile[SYS_MAX_PATH] = "";

            SysGetTmpFile(szTmpFile);

            if (MscCopyFile(szTmpFile, pszMailFile) < 0)
            {
                ErrorPush();
                CheckRemoveFile(szTmpFile);
                return (ErrorPop());
            }


            char           *pszNewValue = SysStrDup(szTmpFile);

            if (pszNewValue == NULL)
                return (ErrGetErrorCode());

            SysFree(ppszCmdTokens[ii]);

            ppszCmdTokens[ii] = pszNewValue;
        }

    }

    return (0);

}




static int      SMAILCmd_external(SHB_HANDLE hShbSMAIL, char const * pszDestDomain, char **ppszCmdTokens,
                        int iNumTokens, SPLF_HANDLE hFSpool)
{

    if (iNumTokens < 5)
    {
        ErrSetErrorCode(ERR_BAD_DOMAIN_PROC_CMD_SYNTAX);
        return (ERR_BAD_DOMAIN_PROC_CMD_SYNTAX);
    }

    int             iPriority = atoi(ppszCmdTokens[1]),
                    iWaitTimeout = atoi(ppszCmdTokens[2]),
                    iExitStatus = 0;

    if (SysExec(ppszCmdTokens[3], &ppszCmdTokens[3], iWaitTimeout, iPriority,
                    &iExitStatus) < 0)
    {
        ErrorPush();

        char const     *pszSpoolFile = USmlGetSpoolFile(hFSpool);
        char const     *pszMailFrom = USmlMailFrom(hFSpool);
        char const     *pszRcptTo = USmlRcptTo(hFSpool);

        SvrSpoolErrLogMessage(pszSpoolFile,
                "SMAIL EXTRN-Send Prg = \"%s\" Domain = \"%s\" From = \"%s\" To = \"%s\" Failed !\n",
                ppszCmdTokens[3], pszDestDomain, pszMailFrom, pszRcptTo);

        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Log Mailer operation
///////////////////////////////////////////////////////////////////////////////
    if (SMAILLogEnabled(hShbSMAIL))
        USmlLogMessage(hFSpool, "EXTRN", ppszCmdTokens[3]);

    return (0);

}




static int      SMAILCmd_wait(SHB_HANDLE hShbSMAIL, char const * pszDestDomain, char **ppszCmdTokens,
                        int iNumTokens, SPLF_HANDLE hFSpool)
{

    if (iNumTokens != 2)
    {
        ErrSetErrorCode(ERR_BAD_DOMAIN_PROC_CMD_SYNTAX);
        return (ERR_BAD_DOMAIN_PROC_CMD_SYNTAX);
    }

    int             iWaitTimeout = atoi(ppszCmdTokens[1]);

    SysSleep(iWaitTimeout);

    return (0);

}



static int      SMAILCmd_smtp(SHB_HANDLE hShbSMAIL, char const * pszDestDomain, char **ppszCmdTokens,
                        int iNumTokens, SPLF_HANDLE hFSpool)
{

    if (iNumTokens != 1)
    {
        ErrSetErrorCode(ERR_BAD_DOMAIN_PROC_CMD_SYNTAX);
        return (ERR_BAD_DOMAIN_PROC_CMD_SYNTAX);
    }


    SMTPError       SMTPE;

    USmtpInitError(&SMTPE);

    if (SMAILRemoteMsgSMTPSend(hShbSMAIL, hFSpool, pszDestDomain, &SMTPE) < 0)
    {
///////////////////////////////////////////////////////////////////////////////
//  If We get an SMTP fatal error We must return <0 , otherwise >0 to give
//  XMail to ability to resume the command
///////////////////////////////////////////////////////////////////////////////
        int             iReturnCode = USmtpIsFatalError(&SMTPE) ? ErrGetErrorCode() : -ErrGetErrorCode();

        USmtpCleanupError(&SMTPE);

        return (iReturnCode);
    }

    USmtpCleanupError(&SMTPE);

    return (0);

}




static int      SMAILCmd_redirect(SHB_HANDLE hShbSMAIL, char const * pszDestDomain, char **ppszCmdTokens,
                        int iNumTokens, SPLF_HANDLE hFSpool)
{

    if (iNumTokens < 2)
    {
        ErrSetErrorCode(ERR_BAD_DOMAIN_PROC_CMD_SYNTAX);
        return (ERR_BAD_DOMAIN_PROC_CMD_SYNTAX);
    }


    char const     *pszSMTPDomain = USmlGetSMTPDomain(hFSpool);
    char const     *const * ppszFrom = USmlGetMailFrom(hFSpool);
    char const     *const * ppszRcpt = USmlGetRcptTo(hFSpool);

    int             iFromDomains = StrStringsCount(ppszFrom),
                    iRcptDomains = StrStringsCount(ppszRcpt);

    char            szLocalUser[MAX_ADDR_NAME] = "",
                    szLocalDomain[MAX_ADDR_NAME] = "";

    if ((iRcptDomains < 1) ||
            (USmtpSplitEmailAddr(ppszRcpt[iRcptDomains - 1], szLocalUser, szLocalDomain) < 0))
        return (ErrGetErrorCode());


    for (int ii = 1; ppszCmdTokens[ii] != NULL; ii++)
    {
        char            szSpoolFile[SYS_MAX_PATH] = "",
                        szAliasAddr[MAX_ADDR_NAME] = "";

        SysGetTmpFile(szSpoolFile);

        sprintf(szAliasAddr, "%s@%s", szLocalUser, ppszCmdTokens[ii]);

        if (USmlCreateSpoolFile(hFSpool, NULL, szAliasAddr, szSpoolFile) < 0)
        {
            CheckRemoveFile(szSpoolFile);
            continue;
        }

///////////////////////////////////////////////////////////////////////////////
//  Transfer file to the spool
///////////////////////////////////////////////////////////////////////////////
        char            szMessageId[256] = "";

        if (USmtpMoveToSpool(pszSMTPDomain, szSpoolFile, szMessageId) < 0)
        {
            ErrorPush();
            SysRemove(szSpoolFile);
            return (ErrorPop());
        }
    }

    return (0);

}




static int      SMAILCmd_lredirect(SHB_HANDLE hShbSMAIL, char const * pszDestDomain, char **ppszCmdTokens,
                        int iNumTokens, SPLF_HANDLE hFSpool)
{

    if (iNumTokens < 2)
    {
        ErrSetErrorCode(ERR_BAD_DOMAIN_PROC_CMD_SYNTAX);
        return (ERR_BAD_DOMAIN_PROC_CMD_SYNTAX);
    }


    char const     *const * ppszFrom = USmlGetMailFrom(hFSpool);
    char const     *const * ppszRcpt = USmlGetRcptTo(hFSpool);

    int             iFromDomains = StrStringsCount(ppszFrom),
                    iRcptDomains = StrStringsCount(ppszRcpt);

    char            szLocalUser[MAX_ADDR_NAME] = "",
                    szLocalDomain[MAX_ADDR_NAME] = "";

    if ((iRcptDomains < 1) ||
            (USmtpSplitEmailAddr(ppszRcpt[iRcptDomains - 1], szLocalUser, szLocalDomain) < 0))
        return (ErrGetErrorCode());


    for (int ii = 1; ppszCmdTokens[ii] != NULL; ii++)
    {
        char            szSpoolFile[SYS_MAX_PATH] = "",
                        szAliasAddr[MAX_ADDR_NAME] = "";

        SysGetTmpFile(szSpoolFile);

        sprintf(szAliasAddr, "%s@%s", szLocalUser, ppszCmdTokens[ii]);

        if (USmlCreateSpoolFile(hFSpool, ppszRcpt[iRcptDomains - 1], szAliasAddr,
                        szSpoolFile) < 0)
        {
            CheckRemoveFile(szSpoolFile);
            continue;
        }

///////////////////////////////////////////////////////////////////////////////
//  Transfer file to the spool
///////////////////////////////////////////////////////////////////////////////
        char            szMessageId[256] = "";

        if (USmtpMoveToSpool(szLocalDomain, szSpoolFile, szMessageId) < 0)
        {
            ErrorPush();
            SysRemove(szSpoolFile);
            return (ErrorPop());
        }
    }

    return (0);

}




static int      SMAILFilterMessage(SHB_HANDLE hShbSMAIL, char const * pszSpoolFilePath)
{

///////////////////////////////////////////////////////////////////////////////
//  Load spool file header
///////////////////////////////////////////////////////////////////////////////
    SpoolFileHeader SFH;

    if (USmlLoadSpoolFileHeader(pszSpoolFilePath, SFH) < 0)
        return (ErrGetErrorCode());

///////////////////////////////////////////////////////////////////////////////
//  Extract target domain and user
///////////////////////////////////////////////////////////////////////////////
    char            szDestUser[MAX_ADDR_NAME] = "",
                    szDestDomain[MAX_ADDR_NAME] = "";

    if ((StrStringsCount(SFH.ppszRcpt) < 1) ||
            (USmtpSplitEmailAddr(SFH.ppszRcpt[0], szDestUser, szDestDomain) < 0))
    {
        USmlCleanupSpoolFileHeader(SFH);
        return (ErrGetErrorCode());
    }

///////////////////////////////////////////////////////////////////////////////
//  If no filter is defined message pass through
///////////////////////////////////////////////////////////////////////////////
    char            szFilterFilePath[SYS_MAX_PATH] = "";

    if (USmlGetMessageFilterFile(szDestDomain, szDestUser, szFilterFilePath) < 0)
    {
        USmlCleanupSpoolFileHeader(SFH);
        return (0);
    }

///////////////////////////////////////////////////////////////////////////////
//  Filter this message
///////////////////////////////////////////////////////////////////////////////
    FILE           *pFiltFile = fopen(szFilterFilePath, "rt");

    if (pFiltFile == NULL)
    {
        USmlCleanupSpoolFileHeader(SFH);

        ErrSetErrorCode(ERR_FILE_OPEN, szFilterFilePath);
        return (ERR_FILE_OPEN);
    }

    char            szFiltLine[FILTER_LINE_MAX] = "";

    while (MscGetConfigLine(szFiltLine, sizeof(szFiltLine) - 1, pFiltFile) != NULL)
    {
        char          **ppszCmdTokens = StrGetTabLineStrings(szFiltLine);

        if (ppszCmdTokens == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszCmdTokens);

        if (iFieldsCount > 0)
        {
///////////////////////////////////////////////////////////////////////////////
//  Do filter line macro substitution
///////////////////////////////////////////////////////////////////////////////
            SMAILFilterMacroSubstitutes(ppszCmdTokens, pszSpoolFilePath, SFH);


            int             iExitCode = 0;

            if (SysExec(ppszCmdTokens[0], &ppszCmdTokens[0], FILTER_TIMEOUT,
                            FILTER_PRIORITY, &iExitCode) == 0)
            {
                if (iExitCode == FILTER_OUT_EXITCODE)
                {
                    StrFreeStrings(ppszCmdTokens);
                    fclose(pFiltFile);

///////////////////////////////////////////////////////////////////////////////
//  Filter out message
///////////////////////////////////////////////////////////////////////////////
                    SvrSpoolRemoveNotify(SFH.szSpoolFile, ErrGetErrorString(ERR_FILTERED_MESSAGE));


                    USmlCleanupSpoolFileHeader(SFH);

                    ErrSetErrorCode(ERR_FILTERED_MESSAGE);
                    return (ERR_FILTERED_MESSAGE);
                }
                else if (iExitCode == MODIFY_EXITCODE)
                {


                }
            }
            else
                SysLogMessage(LOG_LEV_MESSAGE, "Filter error for domain \"%s\" (%s)\n",
                        szDestDomain, ppszCmdTokens[0]);

        }

        StrFreeStrings(ppszCmdTokens);
    }

    fclose(pFiltFile);

    USmlCleanupSpoolFileHeader(SFH);

    return (0);

}




static int      SMAILFilterMacroSubstitutes(char **ppszCmdTokens, char const * pszSpoolFilePath,
                        SpoolFileHeader const & SFH)
{

    int             iFromDomains = StrStringsCount(SFH.ppszFrom),
                    iRcptDomains = StrStringsCount(SFH.ppszRcpt);

    for (int ii = 0; ppszCmdTokens[ii] != NULL; ii++)
    {
        if (strcmp(ppszCmdTokens[ii], "@@FROM") == 0)
        {
            char           *pszNewValue = SysStrDup((iFromDomains > 0) ? SFH.ppszFrom[iFromDomains - 1] : "");

            if (pszNewValue == NULL)
                return (ErrGetErrorCode());

            SysFree(ppszCmdTokens[ii]);

            ppszCmdTokens[ii] = pszNewValue;
        }
        else if (strcmp(ppszCmdTokens[ii], "@@RCPT") == 0)
        {
            char           *pszNewValue = SysStrDup((iRcptDomains > 0) ? SFH.ppszRcpt[iRcptDomains - 1] : "");

            if (pszNewValue == NULL)
                return (ErrGetErrorCode());

            SysFree(ppszCmdTokens[ii]);

            ppszCmdTokens[ii] = pszNewValue;
        }
        else if (strcmp(ppszCmdTokens[ii], "@@FILE") == 0)
        {
            char           *pszNewValue = SysStrDup(pszSpoolFilePath);

            if (pszNewValue == NULL)
                return (ErrGetErrorCode());

            SysFree(ppszCmdTokens[ii]);

            ppszCmdTokens[ii] = pszNewValue;
        }
        else if (strcmp(ppszCmdTokens[ii], "@@MSGID") == 0)
        {
            char           *pszNewValue = SysStrDup(SFH.szSpoolFile);

            if (pszNewValue == NULL)
                return (ErrGetErrorCode());

            SysFree(ppszCmdTokens[ii]);

            ppszCmdTokens[ii] = pszNewValue;
        }
        else if (strcmp(ppszCmdTokens[ii], "@@MSGREF") == 0)
        {
            char           *pszNewValue = SysStrDup(SFH.szMessageID);

            if (pszNewValue == NULL)
                return (ErrGetErrorCode());

            SysFree(ppszCmdTokens[ii]);

            ppszCmdTokens[ii] = pszNewValue;
        }
        else if (strcmp(ppszCmdTokens[ii], "@@TMPFILE") == 0)
        {
            char            szTmpFile[SYS_MAX_PATH] = "";

            SysGetTmpFile(szTmpFile);

            if (MscCopyFile(szTmpFile, pszSpoolFilePath) < 0)
            {
                ErrorPush();
                CheckRemoveFile(szTmpFile);
                return (ErrorPop());
            }


            char           *pszNewValue = SysStrDup(szTmpFile);

            if (pszNewValue == NULL)
                return (ErrGetErrorCode());

            SysFree(ppszCmdTokens[ii]);

            ppszCmdTokens[ii] = pszNewValue;
        }

    }

    return (0);

}
