/*
 *  MailSvr by Davide Libenzi ( Intranet and Internet mail server )
 *  Copyright (C) 1999  Davide Libenzi
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Davide Libenzi <davidel@maticad.it>
 *
 */


#include "SysInclude.h"
#include "SysDep.h"
#include "SvrDefines.h"
#include "ShBlocks.h"
#include "SWMR.h"
#include "ResLocks.h"
#include "StrUtils.h"
#include "SList.h"
#include "MailConfig.h"
#include "UsrUtils.h"
#include "SMAILUtils.h"
#include "SMAILSvr.h"
#include "AppDefines.h"
#include "MailSvr.h"
#include "MiscUtils.h"
#include "SvrUtils.h"






#define SVR_PROFILE_FILE            "server.tab"
#define MESSAGEID_FILE              "message.id"
#define SMTP_SPOOL_DIR              "spool"
#define SMTP_SPOOL_ERROR_DIR        "errors"
#define SMTP_SPOOL_LOCKS_DIR        "locks"
#define SMTP_SPOOL_LOGS_DIR         "logs"
#define SMTP_LOGS_DIR               "logs"
#define SVR_PROFILE_LINE_MAX        2048
#define SVR_SMTP_MAILER_ERROR_HDR   "X-MailerError"
#define SVR_MAILER_HDR              "X-MailerServer"








struct ServerInfoVar
{
    LISTLINK        LL;
    char           *pszName;
    char           *pszValue;
};

struct ServerConfigData
{
    int             iWriteLock;
    HSLIST          hConfigList;

};




static char    *SvrGetProfileFilePath(char *pszFilePath);
static char   **SvrGetLineStrings(const char *pszSvrLine);
static ServerInfoVar *SvrAllocVar(const char *pszName, const char *pszValue);
static void     SvrFreeVar(ServerInfoVar * pSIV);
static void     SvrFreeInfoList(HSLIST & hConfigList);
static ServerInfoVar *SvrGetUserVar(HSLIST & hConfigList, const char *pszName);
static int      SvrWriteInfoList(HSLIST & hConfigList, FILE * pProfileFile);
static int      SvrLoadServerConfig(HSLIST & hConfigList, const char *pszFilePath);
static char    *SvrGetSpoolLogFile(char const * pszSpoolFileName, char *pszSpoolLogFile);
static int      SvrReadyToProcess(char const * pszSpoolFileName, int iRetryTimeout,
                        int iMaxRetry);
static bool     SvrRemoveSpoolErrors(void);
static int      SvrSpoolMoveToErrorsFile_LK(const char *pszSpoolFileName);
static int      SvrSpoolRemoveFile_LK(const char *pszSpoolFileName);
static int      SvrCopyToSpool_LK(const char *pszFileName, const char *pszSpoolFileName);
static int      SvrMoveToSpool_LK(const char *pszFileName, const char *pszSpoolFileName);
static char    *SvrCreateMsgFileName(const char *pszDomain, SYS_UINT64 ullMessageID,
                        char *pszMsgFileName);
static int      SvrTXErrorNotifySender_LK(char const * pszMsgFileName, char const * pszReason);
static int      SvrBuildErrorRespose(char const * pszSMTPDomain, SPLF_HANDLE hFSpool,
                        char const * pszMsgFileName, char const * pszFrom,
                        char const * pszTo, char const * pszResponseFile,
                        char const * pszReason);







static char    *SvrGetProfileFilePath(char *pszFilePath)
{

    CfgGetRootPath(pszFilePath);

    strcat(pszFilePath, SVR_PROFILE_FILE);

    return (pszFilePath);

}



static char   **SvrGetLineStrings(const char *pszSvrLine)
{

    char          **ppszStrings = StrTokenize(pszSvrLine, "\t");

    if (ppszStrings == NULL)
        return (NULL);

    for (int ii = 0; ppszStrings[ii] != NULL; ii++)
        StrDeQuote(ppszStrings[ii], '"');

    return (ppszStrings);

}



SVRCFG_HANDLE   SvrGetConfigHandle(int iWriteLock)
{

    char            szProfilePath[SYS_MAX_PATH] = "";

    SvrGetProfileFilePath(szProfilePath);

    if (iWriteLock && (SysLockFile(szProfilePath) < 0))
        return (INVALID_SVRCFG_HANDLE);

    ServerConfigData *pSCD = (ServerConfigData *) SysAlloc(sizeof(ServerConfigData));

    if (pSCD == NULL)
    {
        if (iWriteLock)
            SysUnlockFile(szProfilePath);
        return (INVALID_SVRCFG_HANDLE);
    }

    pSCD->iWriteLock = iWriteLock;

    ListInit(pSCD->hConfigList);

    if (SvrLoadServerConfig(pSCD->hConfigList, szProfilePath) < 0)
    {
        if (iWriteLock)
            SysUnlockFile(szProfilePath);
        SysFree(pSCD);
        return (INVALID_SVRCFG_HANDLE);
    }

    return ((SVRCFG_HANDLE) pSCD);

}



void            SvrReleaseConfigHandle(SVRCFG_HANDLE hSvrConfig)
{

    ServerConfigData *pSCD = (ServerConfigData *) hSvrConfig;

    if (pSCD->iWriteLock)
    {
        char            szProfilePath[SYS_MAX_PATH] = "";

        SvrGetProfileFilePath(szProfilePath);

        SysUnlockFile(szProfilePath);
    }

    SvrFreeInfoList(pSCD->hConfigList);

    SysFree(pSCD);

}



char           *SvrGetConfigVar(SVRCFG_HANDLE hSvrConfig, const char *pszName,
                        const char *pszDefault)
{

    ServerConfigData *pSCD = (ServerConfigData *) hSvrConfig;

    ServerInfoVar  *pSIV = SvrGetUserVar(pSCD->hConfigList, pszName);

    if (pSIV != NULL)
        return (SysStrDup(pSIV->pszValue));

    return ((pszDefault != NULL) ? SysStrDup(pszDefault) : NULL);

}



bool            SvrTestConfigFlag(char const * pszName, bool bDefault, SVRCFG_HANDLE hSvrConfig)
{

    char            szValue[64] = "";

    SvrConfigVar(pszName, szValue, sizeof(szValue) - 1, hSvrConfig,
            (bDefault) ? "1" : "0");

    return ((atoi(szValue) != 0) ? true : false);

}



int             SysFlushConfig(SVRCFG_HANDLE hSvrConfig)
{

    ServerConfigData *pSCD = (ServerConfigData *) hSvrConfig;

    if (!pSCD->iWriteLock)
    {
        ErrSetErrorCode(ERR_SVR_PRFILE_NOT_LOCKED);
        return (ERR_SVR_PRFILE_NOT_LOCKED);
    }

    char            szProfilePath[SYS_MAX_PATH] = "";

    SvrGetProfileFilePath(szProfilePath);


    SHB_HANDLE      hSWMRProfile = SWMRCreateWriteLock(SWMR_Profile);

    if (hSWMRProfile == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pProfileFile = fopen(szProfilePath, "wt");

    if (pProfileFile == NULL)
    {
        SWMRCloseWriteUnlock(hSWMRProfile);
        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }


    int             iFlushResult = SvrWriteInfoList(pSCD->hConfigList, pProfileFile);


    fclose(pProfileFile);

    SWMRCloseWriteUnlock(hSWMRProfile);

    return (iFlushResult);

}



static ServerInfoVar *SvrAllocVar(const char *pszName, const char *pszValue)
{

    ServerInfoVar  *pSIV = (ServerInfoVar *) SysAlloc(sizeof(ServerInfoVar));

    if (pSIV == NULL)
        return (NULL);

    ListLinkInit(pSIV);
    pSIV->pszName = SysStrDup(pszName);
    pSIV->pszValue = SysStrDup(pszValue);

    return (pSIV);

}



static void     SvrFreeVar(ServerInfoVar * pSIV)
{

    SysFree(pSIV->pszName);
    SysFree(pSIV->pszValue);

    SysFree(pSIV);

}



static void     SvrFreeInfoList(HSLIST & hConfigList)
{

    ServerInfoVar  *pSIV;

    while ((pSIV = (ServerInfoVar *) ListRemove(hConfigList)) != INVALID_SLIST_PTR)
        SvrFreeVar(pSIV);

}



static ServerInfoVar *SvrGetUserVar(HSLIST & hConfigList, const char *pszName)
{

    ServerInfoVar  *pSIV = (ServerInfoVar *) ListFirst(hConfigList);

    for (; pSIV != INVALID_SLIST_PTR; pSIV = (ServerInfoVar *)
            ListNext(hConfigList, (PLISTLINK) pSIV))
        if (strcmp(pSIV->pszName, pszName) == 0)
            return (pSIV);

    return (NULL);

}



static int      SvrWriteInfoList(HSLIST & hConfigList, FILE * pProfileFile)
{

    ServerInfoVar  *pSIV = (ServerInfoVar *) ListFirst(hConfigList);

    for (; pSIV != INVALID_SLIST_PTR; pSIV = (ServerInfoVar *)
            ListNext(hConfigList, (PLISTLINK) pSIV))
    {
///////////////////////////////////////////////////////////////////////////////
//  Write variabile name
///////////////////////////////////////////////////////////////////////////////
        char           *pszQuoted = StrQuote(pSIV->pszName, '"');

        if (pszQuoted == NULL)
            return (ErrGetErrorCode());

        fprintf(pProfileFile, "%s\t", pszQuoted);

        SysFree(pszQuoted);

///////////////////////////////////////////////////////////////////////////////
//  Write variabile value
///////////////////////////////////////////////////////////////////////////////
        pszQuoted = StrQuote(pSIV->pszValue, '"');

        if (pszQuoted == NULL)
            return (ErrGetErrorCode());

        fprintf(pProfileFile, "%s\n", pszQuoted);

        SysFree(pszQuoted);
    }

    return (0);

}



static int      SvrLoadServerConfig(HSLIST & hConfigList, const char *pszFilePath)
{

    SHB_HANDLE      hSWMRProfile = SWMRCreateReadLock(SWMR_Profile);

    if (hSWMRProfile == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pProfileFile = fopen(pszFilePath, "rt");

    if (pProfileFile == NULL)
    {
        SWMRCloseReadUnlock(hSWMRProfile);

        ErrSetErrorCode(ERR_NO_USER_PRFILE);
        return (ERR_NO_USER_PRFILE);
    }

    char            szProfileLine[SVR_PROFILE_LINE_MAX] = "";

    while (MscGetConfigLine(szProfileLine, sizeof(szProfileLine) - 1, pProfileFile) != NULL)
    {
        char          **ppszStrings = SvrGetLineStrings(szProfileLine);

        if (ppszStrings == NULL)
            continue;

        int             iFieldsCount = StrStringsCount(ppszStrings);

        if (iFieldsCount == 2)
        {
            ServerInfoVar  *pSIV = SvrAllocVar(ppszStrings[0], ppszStrings[1]);

            if (pSIV != NULL)
                ListAddTail(hConfigList, (PLISTLINK) pSIV);
        }

        StrFreeStrings(ppszStrings);
    }

    fclose(pProfileFile);

    SWMRCloseReadUnlock(hSWMRProfile);

    return (0);

}



int             SvrGetMessageID(SYS_UINT64 * pullMessageID)
{

    char            szMsgIDFile[SYS_MAX_PATH] = "";

    CfgGetRootPath(szMsgIDFile);
    strcat(szMsgIDFile, MESSAGEID_FILE);


    SHB_HANDLE      hSWMRMsgID = SWMRCreateWriteLock(SWMR_MsgID);

    if (hSWMRMsgID == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    FILE           *pMsgIDFile = fopen(szMsgIDFile, "r+b");

    if (pMsgIDFile == NULL)
    {
        SWMRCloseWriteUnlock(hSWMRMsgID);

        ErrSetErrorCode(ERR_FILE_OPEN, szMsgIDFile);
        return (ERR_FILE_OPEN);
    }

    char            szMessageID[128] = "";

    if ((MscGetString(pMsgIDFile, szMessageID, sizeof(szMessageID) - 1) == NULL) ||
            !isdigit(szMessageID[0]))
    {
        fclose(pMsgIDFile);
        SWMRCloseWriteUnlock(hSWMRMsgID);

        ErrSetErrorCode(ERR_INVALID_FILE, szMsgIDFile);
        return (ERR_INVALID_FILE);
    }

    if (sscanf(szMessageID, SYS_LLU_FMT, pullMessageID) != 1)
    {
        fclose(pMsgIDFile);
        SWMRCloseWriteUnlock(hSWMRMsgID);

        ErrSetErrorCode(ERR_INVALID_FILE, szMsgIDFile);
        return (ERR_INVALID_FILE);
    }

    ++*pullMessageID;

    fseek(pMsgIDFile, 0, SEEK_SET);

    fprintf(pMsgIDFile, SYS_LLU_FMT "\r\n", *pullMessageID);

    fclose(pMsgIDFile);

    SWMRCloseWriteUnlock(hSWMRMsgID);

    return (0);

}



char           *SvrGetLogsDir(char *pszLogsPath)
{

    CfgGetRootPath(pszLogsPath);
    strcat(pszLogsPath, SMTP_LOGS_DIR);

    return (pszLogsPath);

}



char           *SvrGetSpoolDir(char *pszSpoolPath)
{

    CfgGetRootPath(pszSpoolPath);
    strcat(pszSpoolPath, SMTP_SPOOL_DIR);

    return (pszSpoolPath);

}



char           *SvrGetSpoolErrorDir(char *pszSpoolErrPath)
{

    SvrGetSpoolDir(pszSpoolErrPath);

    AppendSlash(pszSpoolErrPath);
    strcat(pszSpoolErrPath, SMTP_SPOOL_ERROR_DIR);

    return (pszSpoolErrPath);

}



char           *SvrGetSpoolFilePath(const char *pszSpoolFileName, char *pszSpoolFilePath)
{

    SvrGetSpoolDir(pszSpoolFilePath);

    AppendSlash(pszSpoolFilePath);
    strcat(pszSpoolFilePath, pszSpoolFileName);

    return (pszSpoolFilePath);

}



char           *SvrGetSpoolLocksDir(char *pszSpoolLocksPath)
{

    SvrGetSpoolDir(pszSpoolLocksPath);

    AppendSlash(pszSpoolLocksPath);
    strcat(pszSpoolLocksPath, SMTP_SPOOL_LOCKS_DIR);

    return (pszSpoolLocksPath);

}



int             SvrLockSpoolFile(const char *pszFileName)
{

    char            szSpoolLocksPath[SYS_MAX_PATH] = "";

    SvrGetSpoolLocksDir(szSpoolLocksPath);

    AppendSlash(szSpoolLocksPath);
    strcat(szSpoolLocksPath, pszFileName);

    if (SysLockFile(szSpoolLocksPath) < 0)
        return (ErrGetErrorCode());

    return (0);

}



void            SvrUnlockSpoolFile(const char *pszFileName)
{

    char            szSpoolLocksPath[SYS_MAX_PATH] = "";

    SvrGetSpoolLocksDir(szSpoolLocksPath);

    AppendSlash(szSpoolLocksPath);
    strcat(szSpoolLocksPath, pszFileName);

    SysUnlockFile(szSpoolLocksPath);

}



int             SvrClearSpoolLocksDir(void)
{

    char            szSpoolLocksPath[SYS_MAX_PATH] = "";

    SvrGetSpoolLocksDir(szSpoolLocksPath);

    return (MscClearDirectory(szSpoolLocksPath));

}



int             SvrGetSpoolFileLock(char *pszSpoolFileName, int iRetryTimeout, int iMaxRetry)
{

    char            szSpoolPath[SYS_MAX_PATH] = "";

    SvrGetSpoolDir(szSpoolPath);


    SHB_HANDLE      hSWMRSpool = SWMRCreateWriteLock(SWMR_Spool);

    if (hSWMRSpool == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    char            szMsgFileName[SYS_MAX_PATH] = "";
    FSCAN_HANDLE    hFileScan = MscFirstFile(szSpoolPath, 0, szMsgFileName);

    if (hFileScan != INVALID_FSCAN_HANDLE)
    {
        do
        {
            if (SvrLockSpoolFile(szMsgFileName) == 0)
            {
                int             iReadyResult = SvrReadyToProcess(szMsgFileName,
                        iRetryTimeout, iMaxRetry);

                if (iReadyResult == 0)
                {
                    strcpy(pszSpoolFileName, szMsgFileName);

                    MscCloseFindFile(hFileScan);
                    SWMRCloseWriteUnlock(hSWMRSpool);
                    return (0);
                }

///////////////////////////////////////////////////////////////////////////////
//  Check spool file removing ( max number of retries )
///////////////////////////////////////////////////////////////////////////////
                if (iReadyResult == ERR_SPOOL_FILE_EXPIRED)
                {
///////////////////////////////////////////////////////////////////////////////
//  Send a mail error notify to the sender. "SvrTXErrorNotifySender_LK" must be
//  called with the spool lock _ON_ !!
///////////////////////////////////////////////////////////////////////////////
                    SvrTXErrorNotifySender_LK(szMsgFileName,
                            "The maximum number of tentatives has been reached.");

///////////////////////////////////////////////////////////////////////////////
//  Be advised that "SvrSpoolRemoveFile_LK" and "SvrSpoolMoveToErrorsFile_LK"
//  must be used only with the spool lock _ON_ !!
///////////////////////////////////////////////////////////////////////////////
                    if (SvrRemoveSpoolErrors())
                        SvrSpoolRemoveFile_LK(szMsgFileName);
                    else
                        SvrSpoolMoveToErrorsFile_LK(szMsgFileName);
                }

                SvrUnlockSpoolFile(szMsgFileName);
            }

        } while (MscNextFile(hFileScan, szMsgFileName));

        MscCloseFindFile(hFileScan);
    }


    SWMRCloseWriteUnlock(hSWMRSpool);

    ErrSetErrorCode(ERR_NO_SMTP_SPOOL_FILES);
    return (ERR_NO_SMTP_SPOOL_FILES);

}



static char    *SvrGetSpoolLogFile(char const * pszSpoolFileName, char *pszSpoolLogFile)
{

    char            szSpoolPath[SYS_MAX_PATH] = "";

    SvrGetSpoolDir(szSpoolPath);

    AppendSlash(szSpoolPath);

    strcat(szSpoolPath, SMTP_SPOOL_LOGS_DIR);

    AppendSlash(szSpoolPath);


    sprintf(pszSpoolLogFile, "%s%s.log", szSpoolPath, pszSpoolFileName);

    return (pszSpoolLogFile);

}




int             SvrSpoolErrLogMessage(char const * pszSpoolFileName, char const * pszFormat,...)
{

    char            szSpoolLogFile[SYS_MAX_PATH] = "";

    SvrGetSpoolLogFile(pszSpoolFileName, szSpoolLogFile);


    va_list         Args;

    va_start(Args, pszFormat);

    if (ErrFileVLogMessage(szSpoolLogFile, pszFormat, Args) < 0)
    {
        va_end(Args);
        return (ErrGetErrorCode());
    }

    va_end(Args);

    return (0);

}




static int      SvrReadyToProcess(char const * pszSpoolFileName, int iRetryTimeout,
                        int iMaxRetry)
{

    char            szSpoolLogFile[SYS_MAX_PATH] = "";

    SvrGetSpoolLogFile(pszSpoolFileName, szSpoolLogFile);


    time_t          tCurr;

    time(&tCurr);


    FILE           *pLogFile = fopen(szSpoolLogFile, "r+t");

    if (pLogFile != NULL)
    {
        int             iRetryCount = 0;
        unsigned long   ulPrevTime = 0;
        char            szLogLine[1024] = "";

        while (MscFGets(szLogLine, sizeof(szLogLine) - 1, pLogFile) != NULL)
        {
            if (sscanf(szLogLine, "[PeekTime] %lu", &ulPrevTime) == 1)
                ++iRetryCount;
        }

        if (iRetryCount > iMaxRetry)
        {
            fclose(pLogFile);
            ErrSetErrorCode(ERR_SPOOL_FILE_EXPIRED);
            return (ERR_SPOOL_FILE_EXPIRED);
        }

        unsigned long   ulElapsed = (unsigned long) tCurr - ulPrevTime;

        if ((unsigned long) iRetryTimeout > ulElapsed)
        {
            fclose(pLogFile);

            ErrSetErrorCode(ERR_SPOOL_FILE_NOT_READY);
            return (ERR_SPOOL_FILE_NOT_READY);
        }
    }
    else
    {
        pLogFile = fopen(szSpoolLogFile, "w+t");

        if (pLogFile == NULL)
        {
            ErrSetErrorCode(ERR_FILE_CREATE, szSpoolLogFile);
            return (ERR_FILE_CREATE);
        }
    }

    fseek(pLogFile, 0, SEEK_END);


    fprintf(pLogFile, "[PeekTime] %lu\n", (unsigned long) tCurr);


    fclose(pLogFile);

    return (0);

}



static bool     SvrRemoveSpoolErrors(void)
{

    return (SvrTestConfigFlag("RemoveSpoolErrors", false));

}



static int      SvrSpoolMoveToErrorsFile_LK(const char *pszSpoolFileName)
{

    char            szCleanupFile[SYS_MAX_PATH] = "";

    SvrGetSpoolFilePath(pszSpoolFileName, szCleanupFile);


    char            szSpoolErrorPath[SYS_MAX_PATH] = "";

    SvrGetSpoolErrorDir(szSpoolErrorPath);

    AppendSlash(szSpoolErrorPath);
    strcat(szSpoolErrorPath, pszSpoolFileName);

///////////////////////////////////////////////////////////////////////////////
//  Move the spool file
///////////////////////////////////////////////////////////////////////////////
    if (MscMoveFile(szCleanupFile, szSpoolErrorPath) < 0)
        return (ErrGetErrorCode());

///////////////////////////////////////////////////////////////////////////////
//  Move the log file ( same name of spool file plus  .log )
///////////////////////////////////////////////////////////////////////////////
    SvrGetSpoolLogFile(pszSpoolFileName, szCleanupFile);

    strcat(szSpoolErrorPath, ".log");

    if (MscMoveFile(szCleanupFile, szSpoolErrorPath) < 0)
        return (ErrGetErrorCode());

///////////////////////////////////////////////////////////////////////////////
//  Check if exist a spooled copy of custom domain processing file
///////////////////////////////////////////////////////////////////////////////
    USmlGetDomainCustomSpoolFile(pszSpoolFileName, szCleanupFile);

    CheckRemoveFile(szCleanupFile);

    return (0);

}



int             SvrSpoolMoveToErrorsFile(const char *pszSpoolFileName)
{

    SHB_HANDLE      hSWMRSpool = SWMRCreateWriteLock(SWMR_Spool);

    if (hSWMRSpool == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    int             iMoveResult = SvrSpoolMoveToErrorsFile_LK(pszSpoolFileName);


    SWMRCloseWriteUnlock(hSWMRSpool);

    return (iMoveResult);

}



static int      SvrSpoolRemoveFile_LK(const char *pszSpoolFileName)
{

    char            szCleanupFile[SYS_MAX_PATH] = "";

    SvrGetSpoolFilePath(pszSpoolFileName, szCleanupFile);

///////////////////////////////////////////////////////////////////////////////
//  Remove spool file
///////////////////////////////////////////////////////////////////////////////
    if (SysRemove(szCleanupFile) < 0)
        return (ErrGetErrorCode());

///////////////////////////////////////////////////////////////////////////////
//  Remove log file if exist
///////////////////////////////////////////////////////////////////////////////
    SvrGetSpoolLogFile(pszSpoolFileName, szCleanupFile);

    CheckRemoveFile(szCleanupFile);

///////////////////////////////////////////////////////////////////////////////
//  Check if exist a spooled copy of custom domain processing file
///////////////////////////////////////////////////////////////////////////////
    USmlGetDomainCustomSpoolFile(pszSpoolFileName, szCleanupFile);

    CheckRemoveFile(szCleanupFile);

    return (0);

}



int             SvrSpoolRemoveFile(const char *pszSpoolFileName)
{

    SHB_HANDLE      hSWMRSpool = SWMRCreateWriteLock(SWMR_Spool);

    if (hSWMRSpool == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());

    if (SvrSpoolRemoveFile_LK(pszSpoolFileName) < 0)
    {
        SWMRCloseWriteUnlock(hSWMRSpool);
        return (ErrGetErrorCode());
    }

    SWMRCloseWriteUnlock(hSWMRSpool);

    return (0);

}



static int      SvrCopyToSpool_LK(const char *pszFileName, const char *pszSpoolFileName)
{

    char            szSpoolFile[SYS_MAX_PATH] = "";

    SvrGetSpoolFilePath(pszSpoolFileName, szSpoolFile);


    if (MscCopyFile(szSpoolFile, pszFileName) < 0)
        return (ErrGetErrorCode());


///////////////////////////////////////////////////////////////////////////////
//  Release SMAIL semaphore by 1
///////////////////////////////////////////////////////////////////////////////
    SYS_SEMAPHORE   SemSpoolID = SysConnectSemaphore(0, MAX_SPOOL_FILES, SemSMAILSpoolName);

    if (SemSpoolID == SYS_INVALID_SEMAPHORE)
        return (ErrGetErrorCode());

    SysReleaseSemaphore(SemSpoolID, 1);

    SysCloseSemaphore(SemSpoolID);

    return (0);

}



int             SvrCopyToSpool(const char *pszFileName, const char *pszSpoolFileName)
{

    SHB_HANDLE      hSWMRSpool = SWMRCreateWriteLock(SWMR_Spool);

    if (hSWMRSpool == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    int             iCopyResult = SvrCopyToSpool_LK(pszFileName, pszSpoolFileName);


    SWMRCloseWriteUnlock(hSWMRSpool);

    return (iCopyResult);

}



static int      SvrMoveToSpool_LK(const char *pszFileName, const char *pszSpoolFileName)
{

    char            szSpoolFile[SYS_MAX_PATH] = "";

    SvrGetSpoolFilePath(pszSpoolFileName, szSpoolFile);


    if (MscMoveFile(pszFileName, szSpoolFile) < 0)
        return (ErrGetErrorCode());


///////////////////////////////////////////////////////////////////////////////
//  Release SMAIL semaphore by 1
///////////////////////////////////////////////////////////////////////////////
    SYS_SEMAPHORE   SemSpoolID = SysConnectSemaphore(0, MAX_SPOOL_FILES, SemSMAILSpoolName);

    if (SemSpoolID == SYS_INVALID_SEMAPHORE)
        return (ErrGetErrorCode());


    SysReleaseSemaphore(SemSpoolID, 1);


    SysCloseSemaphore(SemSpoolID);

    return (0);

}



int             SvrMoveToSpool(const char *pszFileName, const char *pszSpoolFileName)
{

    SHB_HANDLE      hSWMRSpool = SWMRCreateWriteLock(SWMR_Spool);

    if (hSWMRSpool == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    int             iMoveResult = SvrMoveToSpool_LK(pszFileName, pszSpoolFileName);


    SWMRCloseWriteUnlock(hSWMRSpool);

    return (iMoveResult);

}



int             SvrSpoolRemoveNotify(const char *pszSpoolFileName, char const * pszReason)
{

    SHB_HANDLE      hSWMRSpool = SWMRCreateWriteLock(SWMR_Spool);

    if (hSWMRSpool == SHB_INVALID_HANDLE)
        return (ErrGetErrorCode());


    SvrTXErrorNotifySender_LK(pszSpoolFileName, pszReason);

    if (SvrRemoveSpoolErrors())
        SvrSpoolRemoveFile_LK(pszSpoolFileName);
    else
        SvrSpoolMoveToErrorsFile_LK(pszSpoolFileName);


    SWMRCloseWriteUnlock(hSWMRSpool);

    return (0);

}



int             SvrChargeSMAILSpool(void)
{

    char            szSpoolPath[SYS_MAX_PATH] = "";

    SvrGetSpoolDir(szSpoolPath);


    SYS_SEMAPHORE   SemSpoolID = SysConnectSemaphore(0, MAX_SPOOL_FILES, SemSMAILSpoolName);

    if (SemSpoolID == SYS_INVALID_SEMAPHORE)
        return (ErrGetErrorCode());

    char            szMsgFileName[SYS_MAX_PATH] = "";
    SYS_HANDLE      hFind = SysFirstFile(szSpoolPath, szMsgFileName);

    if (hFind != SYS_INVALID_HANDLE)
    {
        do
        {
            if (!SysIsDirectory(hFind))
                SysReleaseSemaphore(SemSpoolID, 1);

        } while (SysNextFile(hFind, szMsgFileName));

        SysFindClose(hFind);
    }


    SysCloseSemaphore(SemSpoolID);

    return (0);

}



static char    *SvrCreateMsgFileName(const char *pszDomain, SYS_UINT64 ullMessageID,
                        char *pszMsgFileName)
{

    time_t          tMessage;

    time(&tMessage);

    struct tm       tmMessage = *localtime(&tMessage);


    sprintf(pszMsgFileName, "msg%04d%02d%02d%02d%02d-" SYS_LLX_FMT "@%s",
            tmMessage.tm_year + 1900,
            tmMessage.tm_mon + 1,
            tmMessage.tm_mday,
            tmMessage.tm_hour,
            tmMessage.tm_min,
            ullMessageID,
            pszDomain);

    return (pszMsgFileName);

}



int             SvrGetMsgFileName(const char *pszDomain, char *pszMsgFile)
{

    SYS_UINT64      ullMessageID = 0;

    if (SvrGetMessageID(&ullMessageID) < 0)
        return (ErrGetErrorCode());

    if (SvrCreateMsgFileName(pszDomain, ullMessageID, pszMsgFile) == NULL)
        return (ErrGetErrorCode());

    return (0);

}



static int      SvrTXErrorNotifySender_LK(char const * pszMsgFileName, char const * pszReason)
{

///////////////////////////////////////////////////////////////////////////////
//  Build the full file pathname
///////////////////////////////////////////////////////////////////////////////
    char            szSpoolFilePath[SYS_MAX_PATH] = "";

    SvrGetSpoolFilePath(pszMsgFileName, szSpoolFilePath);


    SPLF_HANDLE     hFSpool = USmlCreateHandle(szSpoolFilePath);

    if (hFSpool == INVALID_SPLF_HANDLE)
        return (ErrGetErrorCode());


    char const     *pszSMTPDomain = USmlGetSMTPDomain(hFSpool);
    char const     *const * ppszFrom = USmlGetMailFrom(hFSpool);
    char const     *const * ppszRcpt = USmlGetRcptTo(hFSpool);
    char const     *pszMailFile = USmlGetMailFile(hFSpool);


    SVRCFG_HANDLE   hSvrConfig = SvrGetConfigHandle();

    if (hSvrConfig == INVALID_SVRCFG_HANDLE)
    {
        USmlCloseHandle(hFSpool);
        return (ErrGetErrorCode());
    }


    int             iFromDomains = StrStringsCount(ppszFrom);
    char            szPMAddress[MAX_ADDR_NAME] = "",
                    szMailDomain[MAX_HOST_NAME] = "";

    if ((SvrConfigVar("PostMaster", szPMAddress, sizeof(szPMAddress), hSvrConfig) < 0) ||
            (SvrConfigVar("RootDomain", szMailDomain, sizeof(szMailDomain), hSvrConfig) < 0))
    {
        SvrReleaseConfigHandle(hSvrConfig);
        USmlCloseHandle(hFSpool);

        ErrSetErrorCode(ERR_INCOMPLETE_CONFIG);
        return (ERR_INCOMPLETE_CONFIG);
    }

///////////////////////////////////////////////////////////////////////////////
//  Build error response mail file
///////////////////////////////////////////////////////////////////////////////
    char            szResponseFile[SYS_MAX_PATH] = "";

    SysGetTmpFile(szResponseFile);

    if (SvrBuildErrorRespose(szMailDomain, hFSpool, pszMsgFileName, szPMAddress,
                    ppszFrom[iFromDomains - 1], szResponseFile, pszReason) < 0)
    {
        SvrReleaseConfigHandle(hSvrConfig);
        USmlCloseHandle(hFSpool);
        return (ErrGetErrorCode());
    }

    SvrReleaseConfigHandle(hSvrConfig);

    USmlCloseHandle(hFSpool);


///////////////////////////////////////////////////////////////////////////////
//  Send error response mail file. Be advised that "SvrMoveToSpool_LK" must be
//  called with the spool lock _ON_ !!
///////////////////////////////////////////////////////////////////////////////
    char            szSpoolFile[SYS_MAX_PATH] = "";

    SvrGetMsgFileName(szMailDomain, szSpoolFile);

    if (SvrMoveToSpool_LK(szResponseFile, szSpoolFile) < 0)
    {
        SysRemove(szResponseFile);
        return (ErrGetErrorCode());
    }

    return (0);

}



int             SvrConfigVar(char const * pszVarName, char *pszVarValue, int iMaxVarValue,
                        SVRCFG_HANDLE hSvrConfig, char const * pszDefault)
{

    int             iReleaseConfig = 0;

    if (hSvrConfig == INVALID_SVRCFG_HANDLE)
    {
        if ((hSvrConfig = SvrGetConfigHandle()) == INVALID_SVRCFG_HANDLE)
            return (ErrGetErrorCode());

        ++iReleaseConfig;
    }


    char           *pszValue = SvrGetConfigVar(hSvrConfig, pszVarName, pszDefault);


    if (pszValue == NULL)
    {
        if (iReleaseConfig)
            SvrReleaseConfigHandle(hSvrConfig);

        ErrSetErrorCode(ERR_CFG_VAR_NOT_FOUND);
        return (ERR_CFG_VAR_NOT_FOUND);
    }

    strncpy(pszVarValue, pszValue, iMaxVarValue - 1);
    pszVarValue[iMaxVarValue - 1] = '\0';

    SysFree(pszValue);

    if (iReleaseConfig)
        SvrReleaseConfigHandle(hSvrConfig);

    return (0);

}



static int      SvrBuildErrorRespose(char const * pszSMTPDomain, SPLF_HANDLE hFSpool,
                        char const * pszMsgFileName, char const * pszFrom,
                        char const * pszTo, char const * pszResponseFile,
                        char const * pszReason)
{

    SYS_UINT64      ullMessageID = 0;

    if (SvrGetMessageID(&ullMessageID) < 0)
        return (ErrGetErrorCode());


    FILE           *pRespFile = fopen(pszResponseFile, "wb");

    if (pRespFile == NULL)
    {
        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }

///////////////////////////////////////////////////////////////////////////////
//  Try to remap target user address
///////////////////////////////////////////////////////////////////////////////
    char            szDomain[MAX_ADDR_NAME] = "",
                    szName[MAX_ADDR_NAME] = "",
                    szTo[MAX_ADDR_NAME] = "";

    if (USmlMapAddress(pszTo, szDomain, szName) < 0)
        strcpy(szTo, pszTo);
    else
        sprintf(szTo, "%s@%s", szName, szDomain);

///////////////////////////////////////////////////////////////////////////////
//  Write domain
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, "%s\r\n", pszSMTPDomain);

///////////////////////////////////////////////////////////////////////////////
//  Write message ID
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, SYS_LLX_FMT "\r\n", ullMessageID);

///////////////////////////////////////////////////////////////////////////////
//  Write MAIL FROM
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, "MAIL FROM:<%s>\r\n", pszFrom);

///////////////////////////////////////////////////////////////////////////////
//  Write RCPT TO
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, "RCPT TO:<%s>\r\n", szTo);

///////////////////////////////////////////////////////////////////////////////
//  Write SPOOL_FILE_DATA_START
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, "%s\r\n", SPOOL_FILE_DATA_START);


///////////////////////////////////////////////////////////////////////////////
//  Write Date ( mail data )
///////////////////////////////////////////////////////////////////////////////
    char            szTime[256] = "";

    MscGetTimeStr(szTime, sizeof(szTime) - 1);

    fprintf(pRespFile, "Date:   %s\r\n", szTime);

///////////////////////////////////////////////////////////////////////////////
//  Write Message-Id ( mail data )
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, "Message-Id: <%s>\r\n", pszMsgFileName);

///////////////////////////////////////////////////////////////////////////////
//  Write From ( mail data )
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, "From:   %s PostMaster <%s>\r\n", pszSMTPDomain, pszFrom);

///////////////////////////////////////////////////////////////////////////////
//  Write To ( mail data )
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, "To:     %s\r\n", pszTo);

///////////////////////////////////////////////////////////////////////////////
//  Write Subject ( mail data )
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, "Subject: Error sending message [%s] from [%s]\r\n",
            pszMsgFileName, pszSMTPDomain);

///////////////////////////////////////////////////////////////////////////////
//  Write X-MailerServer ( mail data )
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, "%s: %s\r\n", SVR_MAILER_HDR, APP_NAME_VERSION_OS_STR);

///////////////////////////////////////////////////////////////////////////////
//  Write X-SMTP-Mailer-Error ( mail data )
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, "%s: Message = [%s] Server = [%s]\r\n",
            SVR_SMTP_MAILER_ERROR_HDR, pszMsgFileName, pszSMTPDomain);

///////////////////////////////////////////////////////////////////////////////
//  Write blank line ( mail data )
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, "\r\n");

///////////////////////////////////////////////////////////////////////////////
//  Write error message ( mail data )
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, "Error sending message [%s] from [%s].\r\n\r\n"
            "<Failure Reason>\r\n"
            "%s\r\n"
            "</Failure Reason>\r\n\r\n"
            "Below is reported the message header:\r\n"
            "\r\n", pszMsgFileName, pszSMTPDomain, pszReason);


///////////////////////////////////////////////////////////////////////////////
//  Write message header ( mail data )
///////////////////////////////////////////////////////////////////////////////
    char const     *pszMailFile = USmlGetMailFile(hFSpool);
    FILE           *pMsgFile = fopen(pszMailFile, "rb");

    if (pMsgFile == NULL)
    {
        fclose(pRespFile);

        ErrSetErrorCode(ERR_FILE_OPEN);
        return (ERR_FILE_OPEN);
    }

    char            szBuffer[1024] = "";

    while (MscGetString(pMsgFile, szBuffer, sizeof(szBuffer)) != NULL)
    {
///////////////////////////////////////////////////////////////////////////////
//  Mail error loop deteced
///////////////////////////////////////////////////////////////////////////////
        if (StrNComp(szBuffer, SVR_SMTP_MAILER_ERROR_HDR) == 0)
        {
            fclose(pMsgFile);
            fclose(pRespFile);
            SysRemove(pszResponseFile);

            ErrSetErrorCode(ERR_MAIL_ERROR_LOOP);
            return (ERR_MAIL_ERROR_LOOP);
        }

        if (strlen(szBuffer) == 0)
            break;

        fprintf(pRespFile, ">> %s\r\n", szBuffer);
    }

    fclose(pMsgFile);


///////////////////////////////////////////////////////////////////////////////
//  Write end of mail ( mail data )
///////////////////////////////////////////////////////////////////////////////
    fprintf(pRespFile, ".\r\n");

    fclose(pRespFile);

    return (0);

}
