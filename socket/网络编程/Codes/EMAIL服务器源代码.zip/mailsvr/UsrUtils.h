/*
 *  MailSvr by Davide Libenzi ( Intranet and Internet mail server )
 *  Copyright (C) 1999  Davide Libenzi
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Davide Libenzi <davidel@maticad.it>
 *
 */


#ifndef _USRUTILS_H
#define _USRUTILS_H




#define INVALID_USRF_HANDLE         ((USRF_HANDLE) 0)
#define INVALID_ALSF_HANDLE         ((ALSF_HANDLE) 0)




struct UserInfo
{
    char           *pszDomain;
    unsigned int    uUserID;
    char           *pszName;
    char           *pszPassword;
    char           *pszPath;
    char           *pszType;
    HSLIST          InfoList;
};

struct AliasInfo
{
    char           *pszDomain;
    char           *pszAlias;
    char           *pszName;
};

enum UserType
{
    usrTypeError = -1,
    usrTypeUser = 0,
    usrTypeML,

    usrTypeMax
};

typedef struct USRF_HANDLE_struct
{
}              *USRF_HANDLE;

typedef struct ALSF_HANDLE_struct
{
}              *ALSF_HANDLE;






char           *UsrGetMLTableFilePath(UserInfo * pUI, char *pszMLTablePath);
UserType        UsrGetUserType(UserInfo * pUI);
UserInfo       *UsrCreateDefaultUser(char const * pszDomain, char const * pszName,
                        char const * pszPassword, UserType TypeUser);
void            UsrFreeUserInfo(UserInfo * pUI);
char           *UsrGetUserInfoVar(UserInfo * pUI, const char *pszName,
                        const char *pszDefault = NULL);
int             UsrSetUserInfoVar(UserInfo * pUI, const char *pszName,
                        const char *pszValue);
char          **UsrGetProfileVars(UserInfo * pUI);
int             UsrAliasLookupName(const char *pszDomain, const char *pszAlias,
                        char *pszName = NULL);
AliasInfo      *UsrAllocAlias(const char *pszDomain, const char *pszAlias,
                        const char *pszName);
void            UsrFreeAlias(AliasInfo * pAI);
int             UsrAddAlias(AliasInfo * pAI);
int             UsrRemoveAlias(const char *pszDomain, const char *pszAlias);
int             UsrRemoveDomainAliases(const char *pszDomain);
UserInfo       *UsrGetUserByName(const char *pszDomain, const char *pszName);
UserInfo       *UsrGetUserByNameOrAlias(const char *pszDomain, const char *pszName,
                        char *pszRealUser = NULL);
UserInfo       *UsrGetUserByID(const char *pszDomain, unsigned int uUserID);
int             UsrRemoveUser(const char *pszDomain, const char *pszName,
                        unsigned int uUserID);
int             UsrModifyUser(UserInfo * pUI);
int             UsrRemoveDomainUsers(const char *pszDomain);
int             UsrAddUser(UserInfo * pUI);
int             UsrFlushUserVars(UserInfo * pUI);
int             UsrGetDBFileSnapShot(const char *pszFileName);
USRF_HANDLE     UsrOpenDB(void);
void            UsrCloseDB(USRF_HANDLE hUsersDB);
UserInfo       *UsrGetFirstUser(USRF_HANDLE hUsersDB);
UserInfo       *UsrGetNextUser(USRF_HANDLE hUsersDB);
int             UsrPOP3Lock(UserInfo * pUI);
void            UsrPOP3Unlock(UserInfo * pUI);
int             UsrPOP3UnlockAllUsers(void);
char           *UsrGetUserPath(UserInfo * pUI, char *pszUserPath, int iFinalSlash = 1);
char           *UsrGetMailboxPath(UserInfo * pUI, char *pszMBPath, int iFinalSlash = 1);
int             UsrMoveToMailBox(UserInfo * pUI, const char *pszFileName,
                        const char *pszMBFileName = NULL);
int             UsrGetMailProcessFile(UserInfo * pUI, char *pszMPPath);
char           *UsrGetAddress(UserInfo * pUI, char *pszAddress);
int             UsrGetAliasDBFileSnapShot(char const * pszFileName);
ALSF_HANDLE     UsrAliasOpenDB(void);
void            UsrAliasCloseDB(ALSF_HANDLE hAliasDB);
AliasInfo      *UsrAliasGetFirst(ALSF_HANDLE hAliasDB);
AliasInfo      *UsrAliasGetNext(ALSF_HANDLE hAliasDB);




#endif
