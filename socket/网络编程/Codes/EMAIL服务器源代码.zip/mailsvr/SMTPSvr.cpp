/*
 *  MailSvr by Davide Libenzi ( Intranet and Internet mail server )
 *  Copyright (C) 1999  Davide Libenzi
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Davide Libenzi <davidel@maticad.it>
 *
 */


#include "SysInclude.h"
#include "SysDep.h"
#include "SvrDefines.h"
#include "SList.h"
#include "ShBlocks.h"
#include "BuffSock.h"
#include "ResLocks.h"
#include "StrUtils.h"
#include "SvrUtils.h"
#include "MiscUtils.h"
#include "UsrUtils.h"
#include "UsrMailList.h"
#include "SMTPSvr.h"
#include "SMTPUtils.h"
#include "SMAILUtils.h"
#include "MailDomains.h"
#include "POP3Utils.h"
#include "MailConfig.h"
#include "AppDefines.h"
#include "MailSvr.h"





#define SMTP_MAX_LINE_SIZE      2048
#define SMTPSRV_ACCEPT_TIMEOUT  4
#define STD_SMTP_TIMEOUT        30
#define SMTP_LISTEN_SIZE        8
#define SMTP_WAIT_SLEEP         2
#define MAX_CLIENTS_WAIT        300
#define SMTP_IPMAP_FILE         "smtp.ipmap.tab"
#define SMTP_LOG_FILE           "smtp"
#define SMTP_SERVER_NAME        "[" APP_NAME_VERSION_OS_STR " SMTP Server]"

#define SMTPF_AUTHENTICATED     (1 << 0)







enum SMTPStates
{
    stateInit,
    stateMail,
    stateRcpt,

    stateExit
};

struct SMTPSession
{
    int             iSMTPState;
    SHB_HANDLE      hShbSMTP;
    SMTPConfig     *pSMTPCfg;
    SVRCFG_HANDLE   hSvrConfig;
    SYS_INET_ADDR   PeerInfo;
    char            szSvrFQDN[MAX_ADDR_NAME];
    char            szSvrDomain[MAX_ADDR_NAME];
    char            szClientFQDN[MAX_ADDR_NAME];
    char            szClientDomain[MAX_ADDR_NAME];
    char            szDestDomain[MAX_ADDR_NAME];
    char            szMsgFile[SYS_MAX_PATH];
    FILE           *pMsgFile;
    char           *pszFrom;
    char           *pszRcpt;
    char           *pszSendRcpt;
    SYS_UINT64      ullMessageID;
    char            szMessageID[128];
    char            szTimeStamp[256];
    unsigned long   ulFlags;

};





static SMTPConfig *SMTPGetConfigCopy(SHB_HANDLE hShbSMTP);
static int      SMTPLogEnabled(SHB_HANDLE hShbSMTP, SMTPConfig * pSMTPCfg = NULL);
static int      SMTPCheckPeerIP(SYS_SOCKET SockFD);
static int      SMTPThreadCountAdd(long lCount, SHB_HANDLE hShbSMTP,
                        SMTPConfig * pSMTPCfg = NULL);
static unsigned int SMTPClientThread(void *pThreadData);
static int      SMTPInitSession(SHB_HANDLE hShbSMTP, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS);
static int      SMTPLogSession(SMTPSession & SMTPS);
static int      SMTPHandleSession(SHB_HANDLE hShbSMTP, BSOCK_HANDLE hBSock);
static void     SMTPClearSession(SMTPSession & SMTPS);
static void     SMTPResetSession(SMTPSession & SMTPS);
static int      SMTPHandleCommand(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS);
static int      SMTPCheckReturnPath(char **ppszRetDomains, SMTPSession & SMTPS,
                        char *&pszSMTPError);
static int      SMTPHandleCmd_MAIL(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS);
static int      SMTPCheckForwardPath(char **ppszFwdDomains, SMTPSession & SMTPS,
                        char *&pszSMTPError);
static int      SMTPHandleCmd_RCPT(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS);
static int      SMTPAddReceived(SMTPSession & SMTPS);
static int      SMTPHandleCmd_DATA(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS);
static int      SMTPHandleCmd_HELO(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS);
static int      SMTPHandleCmd_RSET(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS);
static int      SMTPHandleCmd_NOOP(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS);
static int      SMTPHandleCmd_QUIT(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS);
static int      SMTPHandleCmd_VRFY(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS);








static SMTPConfig *SMTPGetConfigCopy(SHB_HANDLE hShbSMTP)
{

    SMTPConfig     *pSMTPCfg = (SMTPConfig *) ShbLock(hShbSMTP);

    if (pSMTPCfg == NULL)
        return (NULL);

    SMTPConfig     *pSMTPCfgCopy = (SMTPConfig *) SysAlloc(sizeof(SMTPConfig));

    if (pSMTPCfgCopy != NULL)
        memcpy(pSMTPCfgCopy, pSMTPCfg, sizeof(SMTPConfig));

    ShbUnlock(hShbSMTP);

    return (pSMTPCfgCopy);

}



static int      SMTPLogEnabled(SHB_HANDLE hShbSMTP, SMTPConfig * pSMTPCfg)
{

    int             iDoUnlock = 0;

    if (pSMTPCfg == NULL)
    {
        if ((pSMTPCfg = (SMTPConfig *) ShbLock(hShbSMTP)) == NULL)
            return (ErrGetErrorCode());

        ++iDoUnlock;
    }

    unsigned long   ulFlags = pSMTPCfg->ulFlags;

    if (iDoUnlock)
        ShbUnlock(hShbSMTP);

    return ((ulFlags & SMTPF_LOG_ENABLED) ? 1 : 0);

}



static int      SMTPCheckPeerIP(SYS_SOCKET SockFD)
{

    char            szIPMapFile[SYS_MAX_PATH] = "";

    CfgGetRootPath(szIPMapFile);
    strcat(szIPMapFile, SMTP_IPMAP_FILE);

    if (SysExistFile(szIPMapFile))
    {
        SYS_INET_ADDR   PeerInfo;

        if (SysGetPeerInfo(SockFD, PeerInfo) < 0)
            return (ErrGetErrorCode());

        if (MscCheckAllowedIP(szIPMapFile, PeerInfo, true) < 0)
            return (ErrGetErrorCode());
    }

    return (0);

}



static int      SMTPThreadCountAdd(long lCount, SHB_HANDLE hShbSMTP,
                        SMTPConfig * pSMTPCfg)
{

    int             iDoUnlock = 0;

    if (pSMTPCfg == NULL)
    {
        if ((pSMTPCfg = (SMTPConfig *) ShbLock(hShbSMTP)) == NULL)
            return (ErrGetErrorCode());

        ++iDoUnlock;
    }

    if ((pSMTPCfg->lThreadCount + lCount) > pSMTPCfg->lMaxThreads)
    {
        if (iDoUnlock)
            ShbUnlock(hShbSMTP);

        ErrSetErrorCode(ERR_SERVER_BUSY);
        return (ERR_SERVER_BUSY);
    }

    pSMTPCfg->lThreadCount += lCount;

    if (iDoUnlock)
        ShbUnlock(hShbSMTP);

    return (0);

}



static unsigned int SMTPClientThread(void *pThreadData)
{

    SYS_SOCKET      SockFD = (SYS_SOCKET) (unsigned int) pThreadData;

///////////////////////////////////////////////////////////////////////////////
//  Create handle to the shared memory configuration
///////////////////////////////////////////////////////////////////////////////
    SHB_HANDLE      hShbSMTP = ShbConnectBlock(SHB_SMTPSvr);

    if (hShbSMTP == SHB_INVALID_HANDLE)
    {
        ErrorPush();
        SysCloseSocket(SockFD);
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Link socket to the bufferer
///////////////////////////////////////////////////////////////////////////////
    BSOCK_HANDLE    hBSock = BSckAttach(SockFD);

    if (hBSock == INVALID_BSOCK_HANDLE)
    {
        ErrorPush();
        SMTPThreadCountAdd(-1, hShbSMTP);
        SysCloseSocket(SockFD);
        ShbCloseBlock(hShbSMTP);
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Check IP permission
///////////////////////////////////////////////////////////////////////////////
    if (SMTPCheckPeerIP(SockFD) < 0)
    {
        ErrorPush();

        BSckVSendString(hBSock, STD_SMTP_TIMEOUT, "421 %s - %s",
                SMTP_SERVER_NAME, ErrGetErrorString(ErrorFetch()));

        BSckDetach(hBSock, 1);
        ShbCloseBlock(hShbSMTP);
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Increase threads count
///////////////////////////////////////////////////////////////////////////////
    if (SMTPThreadCountAdd(+1, hShbSMTP) < 0)
    {
        ErrorPush();

        BSckVSendString(hBSock, STD_SMTP_TIMEOUT, "421 %s - %s",
                SMTP_SERVER_NAME, ErrGetErrorString(ErrorFetch()));

        BSckDetach(hBSock, 1);
        ShbCloseBlock(hShbSMTP);
        return (ErrorPop());
    }


///////////////////////////////////////////////////////////////////////////////
//  Handle client session
///////////////////////////////////////////////////////////////////////////////
    SMTPHandleSession(hShbSMTP, hBSock);


///////////////////////////////////////////////////////////////////////////////
//  Decrease threads count
///////////////////////////////////////////////////////////////////////////////
    SMTPThreadCountAdd(-1, hShbSMTP);

///////////////////////////////////////////////////////////////////////////////
//  Unlink socket from the bufferer and close it
///////////////////////////////////////////////////////////////////////////////
    BSckDetach(hBSock, 1);


    ShbCloseBlock(hShbSMTP);

    return (0);

}



unsigned int    SMTPThreadProc(void *pThreadData)
{

    SHB_HANDLE      hShbSMTP = ShbConnectBlock(SHB_SMTPSvr);

    if (hShbSMTP == SHB_INVALID_HANDLE)
    {
        ErrorPush();
        SysLogMessage(LOG_LEV_ERROR, "%s\n", ErrGetErrorString());
        return (ErrorPop());
    }

    SMTPConfig     *pSMTPCfg = (SMTPConfig *) ShbLock(hShbSMTP);

    if (pSMTPCfg == NULL)
    {
        ErrorPush();
        SysLogMessage(LOG_LEV_ERROR, "%s\n", ErrGetErrorString());
        ShbCloseBlock(hShbSMTP);
        return (ErrorPop());
    }


    int             iNumSockFDs = 0;
    SYS_SOCKET      SockFDs[MAX_SMTP_ACCEPT_ADDRESSES];

    if (MscCreateServerSockets(pSMTPCfg->iNumAddr, pSMTPCfg->SvrAddr, pSMTPCfg->iPort,
                    SMTP_LISTEN_SIZE, SockFDs, iNumSockFDs) < 0)
    {
        ErrorPush();
        SysLogMessage(LOG_LEV_ERROR, "%s\n", ErrGetErrorString());
        ShbUnlock(hShbSMTP);
        ShbCloseBlock(hShbSMTP);
        return (ErrorPop());
    }

    ShbUnlock(hShbSMTP);

    SysIgnoreThreadsExit();


    SysLogMessage(LOG_LEV_MESSAGE, "%s started\n", SMTP_SERVER_NAME);

    for (;;)
    {
        int             iNumConnSockFD = 0;
        SYS_SOCKET      ConnSockFD[MAX_SMTP_ACCEPT_ADDRESSES];

        if (MscAcceptServerConnection(SockFDs, iNumSockFDs, ConnSockFD,
                        iNumConnSockFD, SMTPSRV_ACCEPT_TIMEOUT) < 0)
        {
            unsigned long   ulFlags = SMTPF_STOP_SERVER;

            pSMTPCfg = (SMTPConfig *) ShbLock(hShbSMTP);

            if (pSMTPCfg != NULL)
                ulFlags = pSMTPCfg->ulFlags;

            ShbUnlock(hShbSMTP);

            if (ulFlags & SMTPF_STOP_SERVER)
                break;
            else
                continue;
        }


        for (int ss = 0; ss < iNumConnSockFD; ss++)
        {
            SYS_THREAD      hClientThread = SysCreateServiceThread(SMTPClientThread, ConnSockFD[ss]);

            if (hClientThread != SYS_INVALID_THREAD)
                SysCloseThread(hClientThread, 0);

        }
    }

    for (int ss = 0; ss < iNumSockFDs; ss++)
        SysCloseSocket(SockFDs[ss]);

///////////////////////////////////////////////////////////////////////////////
//  Wait for client completion
///////////////////////////////////////////////////////////////////////////////
    for (int iTotalWait = 0; (iTotalWait < MAX_CLIENTS_WAIT); iTotalWait += SMTP_WAIT_SLEEP)
    {
        pSMTPCfg = (SMTPConfig *) ShbLock(hShbSMTP);

        if (pSMTPCfg == NULL)
            break;

        long            lThreadCount = pSMTPCfg->lThreadCount;

        ShbUnlock(hShbSMTP);

        if (lThreadCount == 0)
            break;

        SysSleep(SMTP_WAIT_SLEEP);
    }

    ShbCloseBlock(hShbSMTP);

    SysLogMessage(LOG_LEV_MESSAGE, "%s stopped\n", SMTP_SERVER_NAME);

    return (0);

}



static int      SMTPInitSession(SHB_HANDLE hShbSMTP, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS)
{

    ZeroData(SMTPS);
    SMTPS.iSMTPState = stateInit;
    SMTPS.hShbSMTP = hShbSMTP;
    SMTPS.hSvrConfig = INVALID_SVRCFG_HANDLE;
    SMTPS.pSMTPCfg = NULL;
    SMTPS.pMsgFile = NULL;
    SMTPS.pszFrom = NULL;
    SMTPS.pszRcpt = NULL;
    SMTPS.pszSendRcpt = NULL;
    SetEmptyString(SMTPS.szDestDomain);
    SetEmptyString(SMTPS.szClientFQDN);
    SMTPS.ulFlags = 0;

    SysGetTmpFile(SMTPS.szMsgFile);

    if ((SMTPS.hSvrConfig = SvrGetConfigHandle()) == INVALID_SVRCFG_HANDLE)
        return (ErrGetErrorCode());

    if (SysGetPeerInfo(BSckGetAttachedSocket(hBSock), SMTPS.PeerInfo) < 0)
    {
        ErrorPush();
        SvrReleaseConfigHandle(SMTPS.hSvrConfig);
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Check if SMTP client is in "spammers.tab" file
///////////////////////////////////////////////////////////////////////////////
    if (USmtpSpammerCheck(SMTPS.PeerInfo) < 0)
    {
        ErrorPush();
        SvrReleaseConfigHandle(SMTPS.hSvrConfig);
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  RARP client check
///////////////////////////////////////////////////////////////////////////////
    if (SvrTestConfigFlag("SMTP-RARPCheck", false, SMTPS.hSvrConfig) &&
            (SysGetHostByAddr(SMTPS.PeerInfo, SMTPS.szClientFQDN) < 0))
    {
        ErrorPush();
        SvrReleaseConfigHandle(SMTPS.hSvrConfig);
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  RBL-MAPS client check (rbl.maps.vix.com.)
///////////////////////////////////////////////////////////////////////////////
    if (SvrTestConfigFlag("RBL-MAPSCheck", false, SMTPS.hSvrConfig) &&
            (USmtpRBLCheck(SMTPS.PeerInfo) < 0))
    {
        ErrorPush();
        SvrReleaseConfigHandle(SMTPS.hSvrConfig);
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  RSS-MAPS client check (relays.mail-abuse.org.)
///////////////////////////////////////////////////////////////////////////////
    if (SvrTestConfigFlag("RSS-MAPSCheck", false, SMTPS.hSvrConfig) &&
            (USmtpRSSCheck(SMTPS.PeerInfo) < 0))
    {
        ErrorPush();
        SvrReleaseConfigHandle(SMTPS.hSvrConfig);
        return (ErrorPop());
    }


    if (MscGetSockHost(BSckGetAttachedSocket(hBSock), SMTPS.szSvrFQDN) < 0)
        strcpy(SMTPS.szSvrFQDN, SysInetNToA(SMTPS.PeerInfo));
    else
        MscSplitFQDN(SMTPS.szSvrFQDN, NULL, SMTPS.szSvrDomain);

    if (strlen(SMTPS.szSvrDomain) == 0)
    {
        char           *pszDefDomain = SvrGetConfigVar(SMTPS.hSvrConfig, "RootDomain");

        if (pszDefDomain == NULL)
        {
            SvrReleaseConfigHandle(SMTPS.hSvrConfig);
            ErrSetErrorCode(ERR_NO_DOMAIN);
            return (ERR_NO_DOMAIN);
        }

        strcpy(SMTPS.szSvrDomain, pszDefDomain);

        SysFree(pszDefDomain);
    }

///////////////////////////////////////////////////////////////////////////////
//  Create timestamp
///////////////////////////////////////////////////////////////////////////////
    sprintf(SMTPS.szTimeStamp, "<%lu.%lu@%s>",
            (unsigned long) time(NULL), SysGetCurrentThreadId(), SMTPS.szSvrDomain);

    if ((SMTPS.pSMTPCfg = SMTPGetConfigCopy(hShbSMTP)) == NULL)
    {
        ErrorPush();
        SvrReleaseConfigHandle(SMTPS.hSvrConfig);
        return (ErrorPop());
    }

    return (0);

}



static int      SMTPLogSession(SMTPSession & SMTPS)
{

    char            szTime[256] = "";

    MscGetLogTimeStr(szTime, sizeof(szTime) - 1);


    RLCK_HANDLE     hLock = RLckLockEX(MAIL_USER, RES_SMTP_LOGFILE);

    if (hLock == INVALID_RLCK_HANDLE)
        return (ErrGetErrorCode());


    MscFileLog(SMTP_LOG_FILE, "\"%s\""
            "\t\"%s\""
            "\t\"%s\""
            "\t\"%s\""
            "\t\"%s\""
            "\t\"%s\""
            "\t\"%s\""
            "\t\"%s\""
            "\t\"%s\""
            "\n", SMTPS.szSvrFQDN, SMTPS.szSvrDomain, SysInetNToA(SMTPS.PeerInfo),
            szTime, SMTPS.szClientDomain, SMTPS.szDestDomain, SMTPS.pszFrom, SMTPS.pszRcpt,
            SMTPS.szMessageID);


    RLckUnlockEX(hLock);

    return (0);

}



static int      SMTPHandleSession(SHB_HANDLE hShbSMTP, BSOCK_HANDLE hBSock)
{

///////////////////////////////////////////////////////////////////////////////
//  Session structure declaration and init
///////////////////////////////////////////////////////////////////////////////
    SMTPSession     SMTPS;

    if (SMTPInitSession(hShbSMTP, hBSock, SMTPS) < 0)
    {
        BSckVSendString(hBSock, STD_SMTP_TIMEOUT,
                "421 %s service not available, closing transmission channel", SMTP_SERVER_NAME);

        return (ErrGetErrorCode());
    }

    SysLogMessage(LOG_LEV_MESSAGE, "SMTP client connection from [%s]\n",
            SysInetNToA(SMTPS.PeerInfo));

///////////////////////////////////////////////////////////////////////////////
//  Send welcome message
///////////////////////////////////////////////////////////////////////////////
    if (BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
                    "220 %s %s service ready", SMTPS.szTimeStamp, SMTP_SERVER_NAME) < 0)
    {
        ErrorPush();
        SMTPClearSession(SMTPS);
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Command loop
///////////////////////////////////////////////////////////////////////////////
    char            szCommand[2048] = "";

    while (!SvrInShutdown() && (SMTPS.iSMTPState != stateExit) &&
            (BSckGetString(hBSock, szCommand, sizeof(szCommand), SMTPS.pSMTPCfg->iSessionTimeout) != NULL))
    {
///////////////////////////////////////////////////////////////////////////////
//  Retrieve a fresh new configuration copy and test shutdown flag
///////////////////////////////////////////////////////////////////////////////
        SysFree(SMTPS.pSMTPCfg);

        SMTPS.pSMTPCfg = SMTPGetConfigCopy(hShbSMTP);

        if ((SMTPS.pSMTPCfg == NULL) || (SMTPS.pSMTPCfg->ulFlags & SMTPF_STOP_SERVER))
            break;

///////////////////////////////////////////////////////////////////////////////
//  Handle command
///////////////////////////////////////////////////////////////////////////////
        SMTPHandleCommand(szCommand, hBSock, SMTPS);

    }

    SysLogMessage(LOG_LEV_MESSAGE, "SMTP client exit [%s]\n",
            SysInetNToA(SMTPS.PeerInfo));

    SMTPClearSession(SMTPS);

    return (0);

}



static void     SMTPClearSession(SMTPSession & SMTPS)
{

    if (SMTPS.pMsgFile != NULL)
        fclose(SMTPS.pMsgFile), SMTPS.pMsgFile = NULL;

    SysRemove(SMTPS.szMsgFile);

    if (SMTPS.hSvrConfig != INVALID_SVRCFG_HANDLE)
        SvrReleaseConfigHandle(SMTPS.hSvrConfig), SMTPS.hSvrConfig = INVALID_SVRCFG_HANDLE;

    if (SMTPS.pSMTPCfg != NULL)
        SysFree(SMTPS.pSMTPCfg), SMTPS.pSMTPCfg = NULL;

    if (SMTPS.pszFrom != NULL)
        SysFree(SMTPS.pszFrom), SMTPS.pszFrom = NULL;

    if (SMTPS.pszRcpt != NULL)
        SysFree(SMTPS.pszRcpt), SMTPS.pszRcpt = NULL;

    if (SMTPS.pszSendRcpt != NULL)
        SysFree(SMTPS.pszSendRcpt), SMTPS.pszSendRcpt = NULL;

}



static void     SMTPResetSession(SMTPSession & SMTPS)
{

    SMTPS.ulFlags = 0;
    SMTPS.ullMessageID = 0;
    SetEmptyString(SMTPS.szMessageID);

    if (SMTPS.pMsgFile != NULL)
        fclose(SMTPS.pMsgFile), SMTPS.pMsgFile = NULL;

    SysRemove(SMTPS.szMsgFile);

    SetEmptyString(SMTPS.szDestDomain);

    if (SMTPS.pszFrom != NULL)
        SysFree(SMTPS.pszFrom), SMTPS.pszFrom = NULL;

    if (SMTPS.pszRcpt != NULL)
        SysFree(SMTPS.pszRcpt), SMTPS.pszRcpt = NULL;

    if (SMTPS.pszSendRcpt != NULL)
        SysFree(SMTPS.pszSendRcpt), SMTPS.pszSendRcpt = NULL;


    SMTPS.iSMTPState = stateInit;

}



static int      SMTPHandleCommand(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS)
{

    int             iCmdResult = -1;

    if (StrINComp(pszCommand, MAIL_FROM_STR) == 0)
        iCmdResult = SMTPHandleCmd_MAIL(pszCommand, hBSock, SMTPS);
    else if (StrINComp(pszCommand, RCPT_TO_STR) == 0)
        iCmdResult = SMTPHandleCmd_RCPT(pszCommand, hBSock, SMTPS);
    else if (StrINComp(pszCommand, "DATA") == 0)
        iCmdResult = SMTPHandleCmd_DATA(pszCommand, hBSock, SMTPS);
    else if (StrINComp(pszCommand, "HELO") == 0)
        iCmdResult = SMTPHandleCmd_HELO(pszCommand, hBSock, SMTPS);
    else if (StrINComp(pszCommand, "RSET") == 0)
        iCmdResult = SMTPHandleCmd_RSET(pszCommand, hBSock, SMTPS);
    else if (StrINComp(pszCommand, "VRFY") == 0)
        iCmdResult = SMTPHandleCmd_VRFY(pszCommand, hBSock, SMTPS);
    else if (StrINComp(pszCommand, "NOOP") == 0)
        iCmdResult = SMTPHandleCmd_NOOP(pszCommand, hBSock, SMTPS);
    else if (StrINComp(pszCommand, "QUIT") == 0)
        iCmdResult = SMTPHandleCmd_QUIT(pszCommand, hBSock, SMTPS);
    else
        BSckSendString(hBSock, "500 Syntax error, command unrecognized", SMTPS.pSMTPCfg->iTimeout);

    return (iCmdResult);

}



static int      SMTPCheckReturnPath(char **ppszRetDomains, SMTPSession & SMTPS,
                        char *&pszSMTPError)
{

    int             iDomainCount = StrStringsCount(ppszRetDomains);

    if (iDomainCount == 0)
    {
        pszSMTPError = SysStrDup("501 Syntax error in return path");

        ErrSetErrorCode(ERR_BAD_RETURN_PATH);
        return (ERR_BAD_RETURN_PATH);
    }

    char            szMailerUser[MAX_ADDR_NAME] = "",
                    szMailerDomain[MAX_ADDR_NAME] = "";

    if (USmtpSplitEmailAddr(ppszRetDomains[0], szMailerUser, szMailerDomain) < 0)
    {
        ErrorPush();

        pszSMTPError = SysStrDup("501 Syntax error in return path");

        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Setup From string
///////////////////////////////////////////////////////////////////////////////
    if (SMTPS.pszFrom != NULL)
        SysFree(SMTPS.pszFrom);

    SMTPS.pszFrom = SysStrDup(ppszRetDomains[0]);

    return (0);

}


static int      SMTPHandleCmd_MAIL(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS)
{

    if (SMTPS.iSMTPState != stateInit)
    {
        SMTPResetSession(SMTPS);

        BSckSendString(hBSock, "503 Bad sequence of commands", SMTPS.pSMTPCfg->iTimeout);

        ErrSetErrorCode(ERR_SMTP_BAD_CMD_SEQUENCE);
        return (ERR_SMTP_BAD_CMD_SEQUENCE);
    }

    char          **ppszRetDomains = USmtpGetPathStrings(pszCommand);

    if (ppszRetDomains == NULL)
    {
        ErrorPush();
        SMTPResetSession(SMTPS);

        BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
                "451 Requested action aborted: (%d) local error in processing", ErrorFetch());
        return (ErrorPop());
    }
///////////////////////////////////////////////////////////////////////////////
//  Check RETURN PATH
///////////////////////////////////////////////////////////////////////////////
    char           *pszSMTPError = NULL;

    if (SMTPCheckReturnPath(ppszRetDomains, SMTPS, pszSMTPError) < 0)
    {
        ErrorPush();
        StrFreeStrings(ppszRetDomains);
        SMTPResetSession(SMTPS);

        BSckSendString(hBSock, pszSMTPError, SMTPS.pSMTPCfg->iTimeout);
        SysFree(pszSMTPError);
        return (ErrorPop());
    }

    StrFreeStrings(ppszRetDomains);

///////////////////////////////////////////////////////////////////////////////
//  Prepare mail file
///////////////////////////////////////////////////////////////////////////////
    if ((SMTPS.pMsgFile = fopen(SMTPS.szMsgFile, "wb")) == NULL)
    {
        SMTPResetSession(SMTPS);

        BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
                "451 Requested action aborted: (%d) local error in processing", ERR_FILE_CREATE);

        ErrSetErrorCode(ERR_FILE_CREATE);
        return (ERR_FILE_CREATE);
    }

///////////////////////////////////////////////////////////////////////////////
//  Write domain
///////////////////////////////////////////////////////////////////////////////
    if (StrWriteCRLFString(SMTPS.pMsgFile, SMTPS.szSvrDomain) < 0)
    {
        ErrorPush();
        SMTPResetSession(SMTPS);

        BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
                "451 Requested action aborted: (%d) local error in processing", ErrorFetch());
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Get SMTP message ID and write it to the file
///////////////////////////////////////////////////////////////////////////////
    if (SvrGetMessageID(&SMTPS.ullMessageID) < 0)
    {
        ErrorPush();
        SMTPResetSession(SMTPS);

        BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
                "451 Requested action aborted: (%d) local error in processing", ErrorFetch());
        return (ErrorPop());
    }

    sprintf(SMTPS.szMessageID, "S" SYS_LLX_FMT, SMTPS.ullMessageID);

    if (StrWriteCRLFString(SMTPS.pMsgFile, SMTPS.szMessageID) < 0)
    {
        ErrorPush();
        SMTPResetSession(SMTPS);

        BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
                "451 Requested action aborted: (%d) local error in processing", ErrorFetch());
        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Write MAIL FROM
///////////////////////////////////////////////////////////////////////////////
    if (StrWriteCRLFString(SMTPS.pMsgFile, pszCommand) < 0)
    {
        ErrorPush();
        SMTPResetSession(SMTPS);

        BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
                "451 Requested action aborted: (%d) local error in processing", ErrorFetch());
        return (ErrorPop());
    }

    BSckSendString(hBSock, "250 OK", SMTPS.pSMTPCfg->iTimeout);

    SMTPS.iSMTPState = stateMail;

    return (0);

}




static int      SMTPCheckForwardPath(char **ppszFwdDomains, SMTPSession & SMTPS,
                        char *&pszSMTPError)
{

    int             iDomainCount = StrStringsCount(ppszFwdDomains);

    if (iDomainCount == 0)
    {
        pszSMTPError = SysStrDup("501 Syntax error in forward path");

        ErrSetErrorCode(ERR_BAD_FORWARD_PATH);
        return (ERR_BAD_FORWARD_PATH);
    }

    char            szDestUser[MAX_ADDR_NAME] = "",
                    szDestDomain[MAX_ADDR_NAME] = "";

    if (USmtpSplitEmailAddr(ppszFwdDomains[0], szDestUser, szDestDomain) < 0)
    {
        ErrorPush();

        pszSMTPError = SysStrDup("501 Syntax error in forward path");

        return (ErrorPop());
    }

    if (iDomainCount == 1)
    {
        if (MDomIsHandledDomain(szDestDomain) == 0)
        {
///////////////////////////////////////////////////////////////////////////////
//  Check user existance
///////////////////////////////////////////////////////////////////////////////
            UserInfo       *pUI = UsrGetUserByNameOrAlias(szDestDomain, szDestUser);

            if (pUI == NULL)
            {
                pszSMTPError = StrSprint("550 Mailbox unavailable <%s@%s>",
                        szDestUser, szDestDomain);

                ErrSetErrorCode(ERR_USER_NOT_LOCAL);
                return (ERR_USER_NOT_LOCAL);
            }

            if (UsrGetUserType(pUI) == usrTypeUser)
            {
///////////////////////////////////////////////////////////////////////////////
//  Target is a normal user
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//  Check user mailbox size
///////////////////////////////////////////////////////////////////////////////
                if (UPopCheckMailboxSize(pUI) < 0)
                {
                    ErrorPush();
                    UsrFreeUserInfo(pUI);

                    pszSMTPError = StrSprint("452 Mailbox full <%s@%s>",
                            szDestUser, szDestDomain);

                    return (ErrorPop());
                }

            }
            else
            {
///////////////////////////////////////////////////////////////////////////////
//  Target is a mailing list
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//  Check if client can post to this mailing list
///////////////////////////////////////////////////////////////////////////////
                if (UsrMLCheckUserPost(pUI, SMTPS.pszFrom) < 0)
                {
                    ErrorPush();
                    UsrFreeUserInfo(pUI);

                    pszSMTPError = StrSprint("557 Access denied <%s@%s> for user <%s>",
                            szDestUser, szDestDomain, SMTPS.pszFrom);

                    return (ErrorPop());
                }

            }


            UsrFreeUserInfo(pUI);
        }
        else
        {
///////////////////////////////////////////////////////////////////////////////
//  Check relay permission
///////////////////////////////////////////////////////////////////////////////
            if (((SMTPS.ulFlags & SMTPF_AUTHENTICATED) == 0) &&
                    (USmlCustomizedDomain(szDestDomain) < 0) &&
                    (USmtpIsAllowedRelay(SMTPS.PeerInfo, SMTPS.hSvrConfig) < 0))
            {
                ErrorPush();

                pszSMTPError = SysStrDup("550 Relay denied");

                return (ErrorPop());
            }
        }
    }
    else
    {
///////////////////////////////////////////////////////////////////////////////
//  Check relay permission
///////////////////////////////////////////////////////////////////////////////
        if (((SMTPS.ulFlags & SMTPF_AUTHENTICATED) == 0) &&
                (USmlCustomizedDomain(szDestDomain) < 0) &&
                (USmtpIsAllowedRelay(SMTPS.PeerInfo, SMTPS.hSvrConfig) < 0))
        {
            ErrorPush();

            pszSMTPError = SysStrDup("550 Relay denied");

            return (ErrorPop());
        }
    }

///////////////////////////////////////////////////////////////////////////////
//  Retrieve destination domain
///////////////////////////////////////////////////////////////////////////////
    if (USmtpSplitEmailAddr(ppszFwdDomains[0], NULL, SMTPS.szDestDomain) < 0)
    {
        ErrorPush();

        pszSMTPError = SysStrDup("501 Syntax error in forward path");

        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Setup SendRcpt string ( it'll be used to build "RCPT TO:<>" line into
//  the message file
///////////////////////////////////////////////////////////////////////////////
    if ((SMTPS.pszSendRcpt = USmtpBuildRcptPath(ppszFwdDomains, SMTPS.hSvrConfig)) == NULL)
    {
        ErrorPush();

        pszSMTPError = SysStrDup("501 Syntax error in forward path");

        return (ErrorPop());
    }

///////////////////////////////////////////////////////////////////////////////
//  Setup Rcpt string
///////////////////////////////////////////////////////////////////////////////
    if (SMTPS.pszRcpt != NULL)
        SysFree(SMTPS.pszRcpt);

    SMTPS.pszRcpt = SysStrDup(ppszFwdDomains[0]);

    return (0);

}



static int      SMTPHandleCmd_RCPT(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS)
{

    if ((SMTPS.iSMTPState != stateMail) && (SMTPS.iSMTPState != stateRcpt))
    {
        SMTPResetSession(SMTPS);

        BSckSendString(hBSock, "503 Bad sequence of commands", SMTPS.pSMTPCfg->iTimeout);

        ErrSetErrorCode(ERR_SMTP_BAD_CMD_SEQUENCE);
        return (ERR_SMTP_BAD_CMD_SEQUENCE);
    }

    char          **ppszFwdDomains = USmtpGetPathStrings(pszCommand);

    if (ppszFwdDomains == NULL)
    {
        ErrorPush();
        SMTPResetSession(SMTPS);

        BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
                "451 Requested action aborted: (%d) local error in processing", ErrorFetch());
        return (ErrorPop());
    }
///////////////////////////////////////////////////////////////////////////////
//  Check FORWARD PATH
///////////////////////////////////////////////////////////////////////////////
    char           *pszSMTPError = NULL;

    if (SMTPCheckForwardPath(ppszFwdDomains, SMTPS, pszSMTPError) < 0)
    {
        ErrorPush();
        StrFreeStrings(ppszFwdDomains);

        BSckSendString(hBSock, pszSMTPError, SMTPS.pSMTPCfg->iTimeout);
        SysFree(pszSMTPError);
        return (ErrorPop());
    }

    StrFreeStrings(ppszFwdDomains);

///////////////////////////////////////////////////////////////////////////////
//  Log SMTP session
///////////////////////////////////////////////////////////////////////////////
    if (SMTPLogEnabled(SMTPS.hShbSMTP, SMTPS.pSMTPCfg))
        SMTPLogSession(SMTPS);

///////////////////////////////////////////////////////////////////////////////
//  Write RCPT TO
///////////////////////////////////////////////////////////////////////////////
    fprintf(SMTPS.pMsgFile, "RCPT TO:<%s>\r\n", SMTPS.pszSendRcpt);


    BSckSendString(hBSock, "250 OK", SMTPS.pSMTPCfg->iTimeout);

    SMTPS.iSMTPState = stateRcpt;

    return (0);

}



static int      SMTPAddReceived(SMTPSession & SMTPS)
{

    char            szTime[256] = "";

    MscGetTimeStr(szTime, sizeof(szTime) - 1);


    char            szReceived[2048] = "";

    sprintf(szReceived,
            "Received: from %s [%s]\r\n"
            "\tby %s running %s;\r\n"
            "\t%s", SMTPS.szClientDomain, SysInetNToA(SMTPS.PeerInfo),
            SMTPS.szSvrDomain, SMTP_SERVER_NAME, szTime);

    if (StrWriteCRLFString(SMTPS.pMsgFile, szReceived) < 0)
        return (ErrGetErrorCode());

    return (0);

}



static int      SMTPHandleCmd_DATA(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS)
{

    if (SMTPS.iSMTPState != stateRcpt)
    {
        SMTPResetSession(SMTPS);

        BSckSendString(hBSock, "503 Bad sequence of commands", SMTPS.pSMTPCfg->iTimeout);

        ErrSetErrorCode(ERR_SMTP_BAD_CMD_SEQUENCE);
        return (ERR_SMTP_BAD_CMD_SEQUENCE);
    }

///////////////////////////////////////////////////////////////////////////////
//  Write data begin marker and Received string
///////////////////////////////////////////////////////////////////////////////
    if ((StrWriteCRLFString(SMTPS.pMsgFile, SPOOL_FILE_DATA_START) < 0) ||
            (SMTPAddReceived(SMTPS) < 0))
    {
        ErrorPush();
        SMTPResetSession(SMTPS);

        BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
                "451 Requested action aborted: (%d) local error in processing", ErrorFetch());
        return (ErrorPop());
    }


    BSckSendString(hBSock, "354 Start mail input; end with <CRLF>.<CRLF>", SMTPS.pSMTPCfg->iTimeout);

///////////////////////////////////////////////////////////////////////////////
//  Write data
///////////////////////////////////////////////////////////////////////////////
    int             iErrorCount = 0;
    char            szBuffer[SMTP_MAX_LINE_SIZE];

    while (BSckGetString(hBSock, szBuffer, sizeof(szBuffer), SMTPS.pSMTPCfg->iTimeout) != NULL)
    {
        if (strcmp(szBuffer, ".") == 0)
            break;

        if (StrWriteCRLFString(SMTPS.pMsgFile, szBuffer) < 0)
            ++iErrorCount;

        if (SvrInShutdown())
        {
            fclose(SMTPS.pMsgFile), SMTPS.pMsgFile = NULL;
            SMTPResetSession(SMTPS);

            ErrSetErrorCode(ERR_SERVER_SHUTDOWN);
            return (ERR_SERVER_SHUTDOWN);
        }
    }

    fclose(SMTPS.pMsgFile), SMTPS.pMsgFile = NULL;

    if (iErrorCount == 0)
    {
///////////////////////////////////////////////////////////////////////////////
//  Transfer spool file
///////////////////////////////////////////////////////////////////////////////
        if (USmtpSubmitPackedFile(SMTPS.szDestDomain, SMTPS.szMsgFile) < 0)
            BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
                    "451 Requested action aborted: (%d) local error in processing", ErrGetErrorCode());
        else
            BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout, "250 OK <%s>", SMTPS.szMessageID);
    }
    else
        BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
                "451 Requested action aborted: (%d) local error in processing", ErrGetErrorCode());


    SMTPResetSession(SMTPS);

    return (0);

}



static int      SMTPHandleCmd_HELO(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS)
{

    if (SMTPS.iSMTPState != stateInit)
    {
        SMTPResetSession(SMTPS);

        BSckSendString(hBSock, "503 Bad sequence of commands", SMTPS.pSMTPCfg->iTimeout);

        ErrSetErrorCode(ERR_SMTP_BAD_CMD_SEQUENCE);
        return (ERR_SMTP_BAD_CMD_SEQUENCE);
    }


    char          **ppszTokens = StrTokenize(pszCommand, " ");

    if ((ppszTokens == NULL) || (StrStringsCount(ppszTokens) != 2))
    {
        if (ppszTokens != NULL)
            StrFreeStrings(ppszTokens);

        BSckSendString(hBSock, "501 Syntax error in parameters or arguments", SMTPS.pSMTPCfg->iTimeout);
        return (-1);
    }


    StrSNCpy(SMTPS.szClientDomain, ppszTokens[1]);


    StrFreeStrings(ppszTokens);


    char           *pszDomain = SvrGetConfigVar(SMTPS.hSvrConfig, "RootDomain");

    if (pszDomain == NULL)
    {
        BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
                "451 Requested action aborted: (%d) local error in processing", ERR_NO_ROOT_DOMAIN_VAR);

        ErrSetErrorCode(ERR_NO_ROOT_DOMAIN_VAR);
        return (ERR_NO_ROOT_DOMAIN_VAR);
    }


    BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout, "250 %s", pszDomain);


    SysFree(pszDomain);

    return (0);

}



static int      SMTPHandleCmd_RSET(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS)
{

    SMTPResetSession(SMTPS);

    BSckSendString(hBSock, "250 OK", SMTPS.pSMTPCfg->iTimeout);

    return (0);

}



static int      SMTPHandleCmd_NOOP(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS)
{

    BSckSendString(hBSock, "250 OK", SMTPS.pSMTPCfg->iTimeout);

    return (0);

}



static int      SMTPHandleCmd_QUIT(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS)
{

    SMTPS.iSMTPState = stateExit;


    BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
            "221 %s service closing transmission channel", SMTP_SERVER_NAME);

    return (0);

}




static int      SMTPHandleCmd_VRFY(const char *pszCommand, BSOCK_HANDLE hBSock,
                        SMTPSession & SMTPS)
{

    char          **ppszTokens = StrTokenize(pszCommand, " ");

    if ((ppszTokens == NULL) || (StrStringsCount(ppszTokens) != 2))
    {
        if (ppszTokens != NULL)
            StrFreeStrings(ppszTokens);

        BSckSendString(hBSock, "501 Syntax error in parameters or arguments", SMTPS.pSMTPCfg->iTimeout);
        return (-1);
    }


    char            szVrfyUser[MAX_ADDR_NAME] = "",
                    szVrfyDomain[MAX_ADDR_NAME] = "";

    if (USmtpSplitEmailAddr(ppszTokens[1], szVrfyUser, szVrfyDomain) < 0)
    {
        ErrorPush();
        StrFreeStrings(ppszTokens);

        BSckSendString(hBSock, "501 Syntax error in parameters or arguments", SMTPS.pSMTPCfg->iTimeout);
        return (ErrorPop());
    }

    StrFreeStrings(ppszTokens);


    UserInfo       *pUI = UsrGetUserByNameOrAlias(szVrfyDomain, szVrfyUser);

    if (pUI == NULL)
    {
        BSckSendString(hBSock, "550 String does not match anything", SMTPS.pSMTPCfg->iTimeout);

        ErrSetErrorCode(ERR_USER_NOT_LOCAL);
        return (ERR_USER_NOT_LOCAL);
    }


    char           *pszRealName = UsrGetUserInfoVar(pUI, "RealName", "Unknown");


    BSckVSendString(hBSock, SMTPS.pSMTPCfg->iTimeout,
            "250 %s <%s@%s>", pszRealName, pUI->pszName, pUI->pszDomain);


    SysFree(pszRealName);

    UsrFreeUserInfo(pUI);

    return (0);

}
