/*
 *  MailSvr by Davide Libenzi ( Intranet and Internet mail server )
 *  Copyright (C) 1999  Davide Libenzi
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Davide Libenzi <davidel@maticad.it>
 *
 */


#include "SysInclude.h"
#include "SysDep.h"
#include "SvrDefines.h"
#include "BuffSock.h"
#include "MiscUtils.h"
#include "StrUtils.h"
#include "MD5.h"
#include "Errors.h"






#define STD_CTRL_PORT               6017
#define STD_CTRL_TIMEOUT            60
#define CTRL_LISTFOLLOW_RESULT      100






///////////////////////////////////////////////////////////////////////////////
//  Needed by library functions ( START )
///////////////////////////////////////////////////////////////////////////////
unsigned int    uKeyMagic = 0x0904;
bool            bServerDebug = false;
int             iLogRotateDays = 1;





char           *SvrGetLogsDir(char *pszLogsDir)
{

    sprintf(pszLogsDir, ".");

    return (pszLogsDir);

}

///////////////////////////////////////////////////////////////////////////////
//  Needed by library functions ( END )
///////////////////////////////////////////////////////////////////////////////






int             CClnGetResponse(BSOCK_HANDLE hBSock, char *pszError, int iMaxError,
                        int *piErrorCode, int iTimeout)
{

    char            szRespBuffer[2048] = "";

    if (BSckGetString(hBSock, szRespBuffer, sizeof(szRespBuffer), iTimeout) == NULL)
        return (ErrGetErrorCode());

    if ((szRespBuffer[0] != '+') && (szRespBuffer[0] != '-'))
    {
        ErrSetErrorCode(ERR_CCLN_INVALID_RESPONSE, szRespBuffer);
        return (ERR_CCLN_INVALID_RESPONSE);
    }

    char           *pszToken = szRespBuffer + 1;

    if (piErrorCode != NULL)
        *piErrorCode = atoi(pszToken) * ((szRespBuffer[0] == '-') ? -1 : +1);

    for (; isdigit(*pszToken); pszToken++);

    if (*pszToken != ' ')
    {
        ErrSetErrorCode(ERR_CCLN_INVALID_RESPONSE, szRespBuffer);
        return (ERR_CCLN_INVALID_RESPONSE);
    }

    for (; *pszToken == ' '; pszToken++);

    if (pszError != NULL)
    {
        strncpy(pszError, pszToken, iMaxError);
        pszError[iMaxError - 1] = '\0';
    }

    return (0);

}





int             CClnSubmitCommand(BSOCK_HANDLE hBSock, char const * pszCommand,
                        char *pszError, int iMaxError, FILE * pDumpFile, int iTimeout)
{

    if (BSckSendString(hBSock, pszCommand, iTimeout) < 0)
        return (ErrGetErrorCode());

    int             iErrorCode = 0;

    if (CClnGetResponse(hBSock, pszError, iMaxError, &iErrorCode, iTimeout) < 0)
        return (ErrGetErrorCode());

    if (iErrorCode < 0)
    {
        ErrSetErrorCode(ERR_CCLN_ERROR_RESPONSE, pszError);
        return (ERR_CCLN_ERROR_RESPONSE);
    }

    if (iErrorCode == CTRL_LISTFOLLOW_RESULT)
    {
        char            szRespBuffer[2048] = "";

        while (BSckGetString(hBSock, szRespBuffer, sizeof(szRespBuffer), iTimeout) != NULL)
        {
            if (strcmp(szRespBuffer, ".") == 0)
                break;

            if (pDumpFile != NULL)
                fprintf(pDumpFile, "%s\n", szRespBuffer);
        }
    }

    return (0);

}



BSOCK_HANDLE    CClnConnectServer(char const * pszServer, int iPortNo,
                        char const * pszUsername, char const * pszPassword,
                        bool bUseMD5Auth, int iTimeout)
{
///////////////////////////////////////////////////////////////////////////////
//  Get server address
///////////////////////////////////////////////////////////////////////////////
    NET_ADDRESS     NetAddr;

    if (MscGetServerAddress(pszServer, NetAddr) < 0)
        return (INVALID_BSOCK_HANDLE);

///////////////////////////////////////////////////////////////////////////////
//  Try connect to server
///////////////////////////////////////////////////////////////////////////////
    SYS_SOCKET      SockFD = SysCreateSocket(AF_INET, SOCK_STREAM, 0);

    if (SockFD == SYS_INVALID_SOCKET)
        return (INVALID_BSOCK_HANDLE);

    SYS_INET_ADDR   SvrAddr;

    SysSetupAddress(SvrAddr, AF_INET, NetAddr, htons((short) iPortNo));

    if (SysConnect(SockFD, &SvrAddr, sizeof(SvrAddr), iTimeout) < 0)
    {
        SysCloseSocket(SockFD);
        return (INVALID_BSOCK_HANDLE);
    }

    BSOCK_HANDLE    hBSock = BSckAttach(SockFD);

    if (hBSock == INVALID_BSOCK_HANDLE)
    {
        SysCloseSocket(SockFD);
        return (INVALID_BSOCK_HANDLE);
    }

///////////////////////////////////////////////////////////////////////////////
//  Read welcome message
///////////////////////////////////////////////////////////////////////////////
    int             iErrorCode = 0;
    char            szRTXBuffer[2048] = "";

    if (CClnGetResponse(hBSock, szRTXBuffer, sizeof(szRTXBuffer), &iErrorCode,
                    iTimeout) < 0)
    {
        BSckDetach(hBSock, 1);
        return (INVALID_BSOCK_HANDLE);
    }

    if (iErrorCode < 0)
    {
        BSckDetach(hBSock, 1);

        ErrSetErrorCode(ERR_CCLN_ERROR_RESPONSE, szRTXBuffer);
        return (INVALID_BSOCK_HANDLE);
    }

///////////////////////////////////////////////////////////////////////////////
//  Prepare login
///////////////////////////////////////////////////////////////////////////////
    char            szTimeStamp[256] = "";

    if (!bUseMD5Auth ||
            (MscExtractServerTimeStamp(szRTXBuffer, szTimeStamp, sizeof(szTimeStamp)) == NULL))
        sprintf(szRTXBuffer, "\"%s\"\t\"%s\"", pszUsername, pszPassword);
    else
    {
///////////////////////////////////////////////////////////////////////////////
//  Perform MD5 authentication
///////////////////////////////////////////////////////////////////////////////
        char           *pszHash = StrSprint("%s%s", szTimeStamp, pszPassword);

        if (pszHash == NULL)
        {
            BSckDetach(hBSock, 1);
            return (INVALID_BSOCK_HANDLE);
        }

        char            szMD5[128] = "";

        do_md5_string(pszHash, strlen(pszHash), szMD5);

        SysFree(pszHash);

///////////////////////////////////////////////////////////////////////////////
//  Add a  #  char in head of password field
///////////////////////////////////////////////////////////////////////////////
        sprintf(szRTXBuffer, "\"%s\"\t\"#%s\"", pszUsername, szMD5);
    }

///////////////////////////////////////////////////////////////////////////////
//  Send login
///////////////////////////////////////////////////////////////////////////////
    if (BSckSendString(hBSock, szRTXBuffer, iTimeout) < 0)
    {
        BSckDetach(hBSock, 1);
        return (INVALID_BSOCK_HANDLE);
    }

    if (CClnGetResponse(hBSock, szRTXBuffer, sizeof(szRTXBuffer), &iErrorCode,
                    iTimeout) < 0)
    {
        BSckDetach(hBSock, 1);
        return (INVALID_BSOCK_HANDLE);
    }

    if (iErrorCode < 0)
    {
        BSckDetach(hBSock, 1);

        ErrSetErrorCode(ERR_CCLN_ERROR_RESPONSE, szRTXBuffer);
        return (INVALID_BSOCK_HANDLE);
    }


    return (hBSock);

}



int             CClnQuitConnection(BSOCK_HANDLE hBSock, int iTimeout)
{

    CClnSubmitCommand(hBSock, "\"quit\"", NULL, 0, NULL, iTimeout);

    BSckDetach(hBSock, 1);

    return (0);

}




int             CClnLogError(void)
{

    char           *pszError = ErrGetErrorStringInfo(ErrGetErrorCode());

    if (pszError == NULL)
        return (ErrGetErrorCode());

    fprintf(stderr, "%s\n", pszError);

    SysFree(pszError);

    return (0);

}




void            CClnShowUsage(char const * pszProgName)
{

    fprintf(stderr,
            "use :  %s  [-snuptfc]  ...\n"
            "options :\n"
            "       -s server        = set server address\n"
            "       -n port          = set server port [%d]\n"
            "       -u user          = set username\n"
            "       -p pass          = set password\n"
            "       -t timeout       = set timeout [%d]\n"
            "       -f filename      = set dump filename [stdout]\n"
            "       -c               = disable MD5 authentication\n",
            pszProgName, STD_CTRL_PORT, STD_CTRL_TIMEOUT);


}





int             main(int iArgCount, char *pszArgs[])
{

    int             ii,
                    iPortNo = STD_CTRL_PORT,
                    iTimeout = STD_CTRL_TIMEOUT;
    bool            bUseMD5Auth = true;
    FILE           *pDumpFile = stdout;
    char            szServer[MAX_HOST_NAME] = "",
                    szUsername[256] = "",
                    szPassword[256] = "",
                    szDumpFile[SYS_MAX_PATH] = "";

    if (SysInitLibrary() < 0)
    {
        CClnLogError();
        return (1);
    }


    for (ii = 1; ii < iArgCount; ii++)
    {
        if (pszArgs[ii][0] != '-')
            break;

        switch (pszArgs[ii][1])
        {
            case ('s'):
                if (++ii < iArgCount)
                    strcpy(szServer, pszArgs[ii]);
                break;

            case ('n'):
                if (++ii < iArgCount)
                    iPortNo = atoi(pszArgs[ii]);
                break;

            case ('u'):
                if (++ii < iArgCount)
                    strcpy(szUsername, pszArgs[ii]);
                break;

            case ('p'):
                if (++ii < iArgCount)
                    strcpy(szPassword, pszArgs[ii]);
                break;

            case ('t'):
                if (++ii < iArgCount)
                    iTimeout = atoi(pszArgs[ii]);
                break;

            case ('f'):
                if (++ii < iArgCount)
                    strcpy(szDumpFile, pszArgs[ii]);
                break;

            case ('c'):
                bUseMD5Auth = false;
                break;

            default:
                CClnShowUsage(pszArgs[0]);
                return (3);
        }
    }

    if ((strlen(szServer) == 0) || (strlen(szUsername) == 0) ||
            (strlen(szPassword) == 0) || (ii == iArgCount))
    {
        CClnShowUsage(pszArgs[0]);
        SysCleanupLibrary();
        return (4);
    }

    int             iFirstParam = ii,
                    iCmdLength = 0;

    for (; ii < iArgCount; ii++)
        iCmdLength += strlen(pszArgs[ii]) + 4;


    char           *pszCommand = (char *) SysAlloc(iCmdLength + 1);

    if (pszCommand == NULL)
    {
        fprintf(stderr, "memory allocation failed : %d bytes\n", iCmdLength + 1);
        SysCleanupLibrary();
        return (5);
    }

    for (ii = iFirstParam; ii < iArgCount; ii++)
    {
        if (ii == iFirstParam)
            sprintf(pszCommand, "\"%s\"", pszArgs[ii]);
        else
            sprintf(pszCommand + strlen(pszCommand), "\t\"%s\"", pszArgs[ii]);
    }


    BSOCK_HANDLE    hBSock = CClnConnectServer(szServer, iPortNo, szUsername, szPassword,
            bUseMD5Auth, iTimeout);

    if (hBSock == INVALID_BSOCK_HANDLE)
    {
        CClnLogError();
        SysFree(pszCommand);
        SysCleanupLibrary();
        return (5);
    }

    if ((strlen(szDumpFile) > 0) && ((pDumpFile = fopen(szDumpFile, "wt")) == NULL))
    {
        perror(szDumpFile);
        CClnQuitConnection(hBSock, iTimeout);
        SysFree(pszCommand);
        SysCleanupLibrary();
        return (6);
    }


    char            szRTXBuffer[2048] = "";

    if (CClnSubmitCommand(hBSock, pszCommand, szRTXBuffer, sizeof(szRTXBuffer),
                    pDumpFile, iTimeout) < 0)
    {
        CClnLogError();
        if (pDumpFile != stdout)
            fclose(pDumpFile);
        CClnQuitConnection(hBSock, iTimeout);
        SysFree(pszCommand);
        SysCleanupLibrary();
        return (7);
    }


    SysFree(pszCommand);

    if (pDumpFile != stdout)
        fclose(pDumpFile);

    CClnQuitConnection(hBSock, iTimeout);

    SysCleanupLibrary();

    return (0);

}
