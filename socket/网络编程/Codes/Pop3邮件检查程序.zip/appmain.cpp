// by Andrew Heinlein [Mouse]
// www.mouseindustries.com / www.theblackhand.net
// mouse@mouseindustries.com / mouse@theblackhand.net
// Simple program to check mail thru the POP3 protocol (port 110)

#include <windows.h>	// just to make everything that much easier :)
#include <winsock.h>	// socket functions
#include <stdio.h>		// for FILE operations
#include <mmsystem.h>	// for wav playing
#include "resource.h"	// for our dialog/icons

// defines
#define EVENT_CHECKMAIL 0x00ABCDEF
#define EVENT_NEWMSG	0x00BACDFE
#define WM_TRAYNOTIFY	0x0000A44C
#define ONE_SECOND		0x000003E8
#define POP3_PORT		0x006E
#define MAX_RECV		0x255
#define SETTING_FILE	"POP3CHECKER.SET"

// decos
HWND hWnd = NULL;
HINSTANCE hInst;
SOCKET sock = 0x0;
int current_ticks = 0;
HANDLE t_handle = NULL;
fd_set read_list;
bool Stages[3];
bool doblink = false;
HICON main_icon = NULL;
HICON blank_icon = NULL;
static char szFileBuff[266];
NOTIFYICONDATA nid;
// params to send mail
int timetowait = 0;
char* server = NULL;
char* password = NULL;
char* account = NULL;
char* wavfile = NULL;

// function prototypes
BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
DWORD WINAPI ThreadProc(LPVOID lpParameter);

	// methods
void OnInitDialog();
void OnClose();
void OnOK();
void OnTimer(unsigned int EventID);
void OnSocketMsg();
void OnCheckNow();
void OnSaveSettings();
void OnTrayClick();
void OnBrowse();

	// general functions
bool CreateTCPSocket(SOCKET* sock);
int errbox(const char* msg, int type = MB_OK | MB_ICONHAND);
bool CheckMail(SOCKET* sock);
void CloseDownSocket(SOCKET* sock);
bool InitCheckMail();
void HandleDataRecv(unsigned char* data, int datalen);
void HandleErrorMessage(unsigned char* data, int datalen);
void HandleStage(int stage);
void HandleStatsRecv(unsigned char* data, int datalen);
void CenterWindow();
void CheckSettings();
int GetSettingsFile(char* buffer, int bufflen);
unsigned int gfs(FILE* f);
char* GetFile(char* title, char* ext);
void PlayWav();

//////////////////////////////////////////////////////////////////////////////////////////////////////
// Program entry point ///////////////////////////////////////////////////////////////////////////////
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd){
	hInst = hInstance;
	return DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOGMAIN), NULL, DialogProc, 0);
}

BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam){
	int wmId, wmEvent;

	switch(uMsg){
		case WM_INITDIALOG:
			hWnd = hwndDlg;
			OnInitDialog();
			return TRUE;
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 

			switch(wmId){
				case IDOK:
					OnOK();
					break;
				case IDCANCEL:
					OnClose();
					EndDialog(hwndDlg, IDCANCEL);
					break;
				case IDC_CHECKNOW:
					OnCheckNow();
					break;
				case IDC_SAVESETTINGS:
					OnSaveSettings();
					break;
				case IDC_BROWSE:
					OnBrowse();
					break;
			}
			break;
		case WM_TIMER:
			OnTimer(wParam);
			break;
		case WM_TRAYNOTIFY:
			switch(LOWORD(lParam)){
				case WM_LBUTTONDBLCLK:
				case WM_LBUTTONDOWN:
				case WM_LBUTTONUP:
				case WM_RBUTTONDBLCLK:
				case WM_RBUTTONDOWN:
				case WM_RBUTTONUP:
					OnTrayClick();
					break;
			}
			break;
	}
	return FALSE;
}

// methods
void OnInitDialog(){
	
	CheckSettings();

	WSAData wsad;
	WSAStartup(0x0101, &wsad);
	
	main_icon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICONMAIN));
	blank_icon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICONBLANK));
	if(main_icon)
		SendMessage(hWnd, WM_SETICON, ICON_SMALL, (LPARAM)(HICON)main_icon);

	nid.cbSize = sizeof(nid);
	nid.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE;
	nid.uCallbackMessage = WM_TRAYNOTIFY;
	nid.hIcon = main_icon;
	nid.hWnd = hWnd;
	nid.uID = (int)hWnd;
	strcpy(nid.szTip, "POP3 Email Checker [Loaded...]");
	Shell_NotifyIcon(NIM_ADD, &nid);

	if(InitCheckMail()){
		if(IsDlgButtonChecked(hWnd, IDC_CHECKMAIL))
			SetTimer(hWnd, EVENT_CHECKMAIL, ONE_SECOND, NULL);
	}else{
		SetWindowText(GetDlgItem(hWnd, IDC_STATUS), "Please set up account!");
	}

	CenterWindow();
}

void OnClose(){
	KillTimer(hWnd, EVENT_CHECKMAIL);
	CloseDownSocket(&sock);
	Shell_NotifyIcon(NIM_DELETE, &nid);
	WSACleanup();
	if(main_icon)
		FreeResource(main_icon);
	if(server)
		free(server);
	if(password)
		free(password);
	if(account)
		free(account);
	if(wavfile)
		free(wavfile);
}

void OnOK(){
	ShowWindow(hWnd, SW_HIDE);
}

void OnSaveSettings(){

	if(!InitCheckMail()){
		errbox("Missing parameters!  Make sure you filled in all settings!");
		return;
	}
	current_ticks = 0;

	if(IsDlgButtonChecked(hWnd, IDC_CHECKMAIL))
		SetTimer(hWnd, EVENT_CHECKMAIL, ONE_SECOND, NULL);
	else{
		KillTimer(hWnd, EVENT_CHECKMAIL);
		SetWindowText(GetDlgItem(hWnd, IDC_TIME), "[Timer Not Set]");
	}

	char sfile[MAX_PATH];
	GetSettingsFile(sfile, MAX_PATH);
	FILE* s = fopen(sfile, "wb");
	if(!s){
		errbox("Could not open settings file!");
		return;
	}
	fprintf(s, "%s%c%c", server, 0x0d, 0x0a);
	fprintf(s, "%s%c%c", account, 0x0d, 0x0a);
	fprintf(s, "%s%c%c", password, 0x0d, 0x0a);
	fprintf(s, "%d%c%c", IsDlgButtonChecked(hWnd, IDC_CHECKMAIL), 0x0d, 0x0a);
	fprintf(s, "%d%c%c", timetowait, 0x0d, 0x0a);
	if(wavfile)
		fprintf(s, "%s%c%c", wavfile, 0x0d, 0x0a);
	else
		fprintf(s, "%c%c", 0x0d, 0x0a);

	fclose(s);

	MessageBox(hWnd, "Settings have been saved.", "Saved", MB_OK);
}

void OnTrayClick(){

	ShowWindow(hWnd, SW_SHOW);
	SetForegroundWindow(hWnd);
	SetActiveWindow(hWnd);

	nid.hIcon = main_icon;
	Shell_NotifyIcon(NIM_MODIFY, &nid);
	doblink = false;
}

void OnTimer(unsigned int EventID){
	// check mail
	if(EventID != EVENT_CHECKMAIL)
		return;

	if(doblink){
		if(nid.hIcon == main_icon)
			nid.hIcon = blank_icon;
		else
			nid.hIcon = main_icon;
	}else{
		nid.hIcon = main_icon;
	}
	
	Shell_NotifyIcon(NIM_MODIFY, &nid);

	current_ticks++;
	
	char buff[25];
	wsprintf(buff, "(Time: %d seconds)", (timetowait * 60) - current_ticks);
	SetWindowText(GetDlgItem(hWnd, IDC_TIME), buff);

	if(current_ticks / 60 < timetowait)
		return;

	current_ticks = 0;

	CheckMail(&sock);
}

void OnSocketMsg(){
	
	unsigned char buff[MAX_RECV];
	memset(&buff[0], 0x0, MAX_RECV);

	int total = recv(sock, (char*)&buff[0], MAX_RECV, 0);
	if(total == -1)
		return;

	int pos = 0;
	// this will parce a packet by carrage return and line feed, or just line feed
	// also changes all spaces to nulls
	for(int i = 0; i < total; i++){
		if(buff[i] == 0x20)
			buff[i] = 0x0;
		if((buff[i] == 0x0A) || (buff[i] == 0x0D)){
			buff[i] = 0x0;
			HandleDataRecv(&buff[pos], i);
			pos = i;
			if(buff[pos + 1] == 0x0A){
				pos += 2;
				i++;
			}
		}
	}
}

void OnCheckNow(){
	CheckMail(&sock);
}

void OnBrowse(){
	char* wav = GetFile("Find WAV Sound File...", "WAV");
	if(wavfile)
		free(wavfile);
	wavfile = (char*)malloc(strlen(wav) + 1);
	strcpy(wavfile, wav);
	SetWindowText(GetDlgItem(hWnd, IDC_WAV), wavfile);
}

// general functions
void HandleDataRecv(unsigned char* data, int datalen){

	if(strcmp((char*)data, "-ERR") == 0){
		HandleErrorMessage(data, datalen);
		return;
	}
	if(!Stages[0]){
		Stages[0] = true;
		HandleStage(0);
	}else if(!Stages[1]){
		Stages[1] = true;
		HandleStage(1);
	}else if(!Stages[2]){
		Stages[2] = true;
		HandleStage(2);
	}else{
		HandleStatsRecv(data, datalen);
	}
}

void HandleStatsRecv(unsigned char* data, int datalen){

	char* p_data = (char*)data;
	p_data += strlen(p_data) + 1;
	int msgs = atoi(p_data);
	p_data += strlen(p_data) + 1;
	int size = atoi(p_data);
	
	char buff[255];
	wsprintf(buff, "Messages Waiting: %d - Total Data in Box: %d k.", msgs, size / 1024);
	SetWindowText(GetDlgItem(hWnd, IDC_STATUS), buff);

	EnableWindow(GetDlgItem(hWnd, IDC_CHECKNOW), TRUE);

	if(msgs){
		doblink = true;
		PlayWav();
	}else{
		nid.hIcon = main_icon;
		doblink = false;
	}

	strcpy(nid.szTip, buff);
	Shell_NotifyIcon(NIM_MODIFY, &nid);
	
	CloseDownSocket(&sock);
}

void HandleStage(int stage){
	char sdata[255];
	sdata[0] = 0x0;
	if(stage == 0){
		wsprintf(sdata, "USER %s%c%c", account, 0x0d, 0x0a);
	}else if(stage == 1){
		wsprintf(sdata, "PASS %s%c%c", password, 0x0d, 0x0a);
	}else if(stage == 2){
		wsprintf(sdata, "STAT%c%c", 0x0d, 0x0a);
	}
	if(strlen(sdata))
		send(sock, sdata, strlen(sdata), 0);
}

void HandleErrorMessage(unsigned char* data, int datalen){
	for(int i = 0; i < datalen; i++){
		if(data[i] == 0)
			data[i] = 0x20;
	}
	
	SetWindowText(GetDlgItem(hWnd, IDC_STATUS), (char*)data);
	EnableWindow(GetDlgItem(hWnd, IDC_CHECKNOW), TRUE);

	strcpy(nid.szTip, (char*)data);
	Shell_NotifyIcon(NIM_MODIFY, &nid);

	CloseDownSocket(&sock);
}

bool CreateTCPSocket(SOCKET* sock){
	*sock = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
	
	if(*sock == SOCKET_ERROR)
		return false;
	
	FD_ZERO(&read_list);
	FD_SET(*sock, &read_list);

	return true;
}

int errbox(const char* msg, int type/*= MB_OK | MB_ICONHAND*/){
	return MessageBox(hWnd, msg, "Error!", MB_OK | MB_ICONHAND);
}

bool CheckMail(SOCKET* sock){

	if(!sock)
		return false;

	if(!CreateTCPSocket(sock)){
		errbox("Could not create a TCP socket!");
		return false;
	}

	if(!InitCheckMail()){
		errbox("Missing parameters!  Make sure you have filled in all parameters!");
		return false;
	}

	hostent* h_entity;
	sockaddr_in addr;

	unsigned long ip = inet_addr(server);
	if(ip == 0xFFFFFFFF){
		h_entity = gethostbyname(server);
		if(!h_entity)
			return false;
		memcpy(&ip, h_entity->h_addr_list[0], sizeof(int));
	}

	memcpy(&addr.sin_addr, &ip, sizeof(int));
	addr.sin_port = htons(POP3_PORT);
	addr.sin_family = AF_INET;
	memset(&addr.sin_zero, 0x0, 0x08);
	
	DWORD id;
	
	if(t_handle){
		DWORD ec;
		GetExitCodeThread(t_handle, &ec);
		if(ec == STILL_ACTIVE)
			TerminateThread(t_handle, 0x03);
		CloseHandle(t_handle);
		t_handle = NULL;
	}

	t_handle = CreateThread(NULL, 0, ThreadProc, 0, 0, &id); 
	if(!t_handle)
		return false;
	
	SetWindowText(GetDlgItem(hWnd, IDC_STATUS), "Checking Mail...");
	EnableWindow(GetDlgItem(hWnd, IDC_CHECKNOW), FALSE);

	return (connect(*sock, (sockaddr*)&addr, sizeof(addr)) != -1);
}

void CloseDownSocket(SOCKET* sock){
	if(!sock)
		return;
	closesocket(*sock);
	*sock = 0;
	DWORD ec;
	GetExitCodeThread(t_handle, &ec);
	if(ec == STILL_ACTIVE)
		TerminateThread(t_handle, 0x03);
}

void CenterWindow(){
	RECT rect, rect2;
	GetWindowRect(GetDesktopWindow(), &rect);
	GetClientRect(hWnd, &rect2);
	int left, right, top, bottom;
	left = rect.right / 2 - rect2.right / 2;
	top  = rect.bottom / 2 - rect2.bottom / 2;
	right = rect2.right + (GetSystemMetrics(SM_CXFRAME) * 2);
	bottom = rect2.bottom + GetSystemMetrics(SM_CYCAPTION) + GetSystemMetrics(SM_CXFRAME);
	SetWindowPos(hWnd, NULL, left, top, right, bottom, SWP_NOZORDER | SWP_NOACTIVATE);
}

DWORD WINAPI ThreadProc(LPVOID lpParameter){
	
	while(true){
		int d = select(sock + 1, &read_list, NULL, NULL, NULL);
		if(d <= 0)
			break;
		if(FD_ISSET(sock, &read_list)){
			OnSocketMsg();
		}
	}
	
	return 0;
}

bool InitCheckMail(){
	for(int i = 0; i < 3; i++){Stages[i] = false;}
	
	if(server)
		free(server);
	if(password)
		free(password);
	if(account)
		free(account);
	if(wavfile)
		free(wavfile);

	int len;
	len = GetWindowTextLength(GetDlgItem(hWnd, IDC_SERVER));
	if(!len)
		return false;
	server = (char*)malloc(len + 1);
	if(!server)
		return false;
	GetWindowText(GetDlgItem(hWnd, IDC_SERVER), server, len + 1);
	
	len = GetWindowTextLength(GetDlgItem(hWnd, IDC_PASSWORD));
	if(!len)
		return false;
	password = (char*)malloc(len + 1);
	if(!password)
		return false;
	GetWindowText(GetDlgItem(hWnd, IDC_PASSWORD), password, len + 1);

	char temp[10];
	GetWindowText(GetDlgItem(hWnd, IDC_TIMEWAIT), temp, 10);
	timetowait = atoi(temp);

	len = GetWindowTextLength(GetDlgItem(hWnd, IDC_ACCOUNT));
	if(!len)
		return false;
	account = (char*)malloc(len + 1);
	if(!account)
		return false;
	GetWindowText(GetDlgItem(hWnd, IDC_ACCOUNT), account, len + 1);
	
	len = GetWindowTextLength(GetDlgItem(hWnd, IDC_WAV));
	if(!len){
		wavfile = NULL;
		return true;
	}
	wavfile = (char*)malloc(len + 1);
	if(!wavfile)
		return true;
	GetWindowText(GetDlgItem(hWnd, IDC_WAV), wavfile, len + 1);

	return true;
}

int GetSettingsFile(char* buffer, int bufflen){

	GetWindowsDirectory(buffer, bufflen);
	if(buffer[strlen(buffer) - 1] != '\\')
		strcat(buffer, "\\");
	strcat(buffer, SETTING_FILE);
	return strlen(buffer);

}

unsigned int gfs(FILE* f){
	if(!f)
		return 0;

	fseek(f, 0, SEEK_END);
	unsigned int fLen = ftell(f);
	rewind(f);

	return fLen;
}

void CheckSettings(){
	char sfile[MAX_PATH];
	GetSettingsFile(sfile, MAX_PATH);
	
	FILE* s = fopen(sfile, "rb");
	if(!s)
		return;
	int fsize = gfs(s);
	if(!fsize)
		return;
	char* pguts = (char*)malloc(fsize);
	char* guts = pguts;
	if(!guts){
		fclose(s);
		return;
	}
	if(fread((void*)guts, fsize, 1, s) != 1){
		fclose(s);
		free(guts);
		return;
	}
	fclose(s);
	for(int i = 0; i < fsize; i++){
		if((guts[i] == 0x0D) || (guts[i] == 0x0A))
			guts[i] = 0x0;
	}
	for(i = 0; i < 6; i++){
		if(strlen(guts)){
			if(i == 0){
				SetWindowText(GetDlgItem(hWnd, IDC_SERVER), guts);
			}else if(i == 1){
				SetWindowText(GetDlgItem(hWnd, IDC_ACCOUNT), guts);
			}else if(i == 2){
				SetWindowText(GetDlgItem(hWnd, IDC_PASSWORD), guts);
			}else if(i == 3){
				CheckDlgButton(hWnd, IDC_CHECKMAIL, atoi(guts));
			}else if(i == 4){
				SetWindowText(GetDlgItem(hWnd, IDC_TIMEWAIT), guts);
			}else if(i == 5){
				SetWindowText(GetDlgItem(hWnd, IDC_WAV), guts);
			}
		}
		guts += strlen(guts) + 2;
	}
	free(pguts);
}

char* GetFile(char* title, char* ext){
	OPENFILENAME ofn;
	char exten[55];

	wsprintf(exten, "%s Files%c*.%s%cAll Files%c*.*%c", ext, 0, ext, 0, 0, 0);

	szFileBuff[0] = 0x0;
	ZeroMemory(&ofn, sizeof(OPENFILENAME));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hWnd;
	ofn.lpstrFile = szFileBuff;
	ofn.lpstrTitle = title;
	ofn.nMaxFile = sizeof(szFileBuff);
	ofn.lpstrFilter = exten;
	ofn.nFilterIndex = 1;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrInitialDir = NULL;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | 4;

	if(!GetOpenFileName(&ofn)){szFileBuff[0] = 0x0;}

	return szFileBuff;
}

void PlayWav(){
	sndPlaySound(wavfile, SND_ASYNC);
}
