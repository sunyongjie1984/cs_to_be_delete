#if !defined(_CInputBar_H__)
#define _CInputBar_H__



class CInputBar : public CEdit
{
protected:
	//??DECLARE_DYNCREATE(CInputBar)
public:
	CInputBar();

// Attributes
public:

// Operations
public:

// Implementation
public:
	virtual ~CInputBar();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

//	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	
	DECLARE_MESSAGE_MAP()


};

/////////////////////////////////////////////////////////////////////////////
#endif //_CInputBar_H__