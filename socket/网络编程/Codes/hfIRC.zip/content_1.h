#if !defined(_CContent_H__)
#define _CContent_H__



class CContent : public CEdit
{
protected:
	DECLARE_DYNCREATE(CContent)
public:
	CContent();

// Attributes
public:

// Operations
public:

// Implementation
public:
	virtual ~CContent();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	
	DECLARE_MESSAGE_MAP()


};

/////////////////////////////////////////////////////////////////////////////
#endif //_CContent_H__