// ChannelMember.cpp : implementation file
//

#include "stdafx.h"
#include "hfIRC.h"
#include "ChannelMember.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChannelMember

CChannelMember::CChannelMember()
{
}

CChannelMember::~CChannelMember()
{
}


BEGIN_MESSAGE_MAP(CChannelMember, CEdit)
	//{{AFX_MSG_MAP(CChannelMember)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChannelMember message handlers
