#if !defined(_CMyStatusBar_H__)
#define _CMyStatusBar_H__

class CHfIRCView;

class CMyStatusBar : public CStatusBar
{
protected:
	DECLARE_DYNCREATE(CMyStatusBar)
public:
	CMyStatusBar();

// Attributes
public:

// Operations
public:
	
// Implementation
public:
	virtual ~CMyStatusBar();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	//hf_added:
	//int	m_iPaneCount;
	int	m_iActive;
	CArray<UINT,UINT> m_aIndicators;

	CHfIRCView* m_pView;

	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);

	void MySetView( CHfIRCView* pView );
	BOOL MySetIndicators();

	//??
	//afx_msg void OnPaint();

	
	DECLARE_MESSAGE_MAP()


};

/////////////////////////////////////////////////////////////////////////////
#endif //_CMyStatusBar_H__