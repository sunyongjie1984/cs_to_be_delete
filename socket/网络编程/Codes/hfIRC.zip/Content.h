#if !defined(AFX_CONTENT_H__309D8524_278C_11D2_A8C9_0080C8560A58__INCLUDED_)
#define AFX_CONTENT_H__309D8524_278C_11D2_A8C9_0080C8560A58__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Content.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CContent window

class CContent : public CEdit
{
// Construction
public:
	CContent();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContent)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CContent();

	// Generated message map functions
protected:
	//{{AFX_MSG(CContent)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTENT_H__309D8524_278C_11D2_A8C9_0080C8560A58__INCLUDED_)
