#if !defined(_IRCCLIENT_H__)
#define _IRCCLIENT_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CIrcClient.h : header file
//

class CClientSocket;
class CHfIRCView;
//class CHfIRCDoc;


/////////////////////////////////////////////////////////////////////////////
// CIrcClient command target

class CIrcClient : public CObject
{

// Attributes
private:


public:
	CHfIRCView*		m_pView;
	//CHfIRCDoc*		m_pDoc;
	CString			m_strServerName;
	CString			m_strHostIPAddress;
	CString			m_strMyNickName;
	CClientSocket*	m_pSocket;
	CString			m_strCurChannel; // can join into serveral channels

	CString			m_strClientMsg;

	CString			m_strRecvMsg;
	
	//hf_added:
	CStringList		m_strlstDisplay;


// Operations
public:
	//CIrcClient();           // protected constructor used by dynamic creation
	CIrcClient(CHfIRCView* pView);
	//CIrcClient(CHfIRCDoc* pDoc);
	virtual ~CIrcClient();
	void ParseRecvedStr(CString strMsg);
	void ParseInputCommandStr(CString strMsg);

	void Init();
	void DoClear();

	
	//1.Connection Registration
	//void DoPass();
	void DoNick();
	//void DoUser();
	//void DoServer();
	//void DoOper();
	//void DoQuit();
	//void DoSquit();

	//2.Channel operations
	void DoJoin(LPCSTR lpszChannel);
	//void DoPart();
	//void DoMode();
	//void DoTopic();
	void DoNames();
	void DoList();
	//void DoInvite();
	//void DoKick();

	//3.Server queries and commands
	//void DoVersion();
	//void DoStats();
	//void DoLinks();
	//void DoTime();
	//void DoCinnect();
	//void DoTrace();
	//void DoAdmin();
	//void DoInfo();

	
	//4.Sending messages
	void DoPrivmsg(LPCSTR lpszWho,LPCSTR lpszMessage);
	//void DoNotice();
	
	//5.User-based queries
	//void DoQuery();
	//void DoWho();
	void DoWhois();
	//void DoWhowas();
	
	//6.Miscellaneous messages
	//void DoKill();
	//void DoPing();
	void DoPong(LPCSTR lpszServerName);
	//void DoError();
	
	
	//OPTIONAL MESSAGES
	//void DoAway();
	//void DoRehash();
	//void DoRestart();
	//void DoSummon();
	//void DoUsers();
	//void DoWallops();
	//void DoUserHost();
	//void DoIson();


private:
	BOOL ClientConnectSocket(LPCTSTR lpszHostname = DEFAULTSERVER,UINT nPort = DEFAULTPORT);


// Implementation
protected:
	//virtual ~CIrcClient();

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(_IRCCLIENT_H__)
