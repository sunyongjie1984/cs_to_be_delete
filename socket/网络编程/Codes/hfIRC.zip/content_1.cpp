
#include "stdafx.h"
#include "content.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CContent

IMPLEMENT_DYNCREATE(CContent, CEdit)

BEGIN_MESSAGE_MAP(CContent, CEdit)
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CContent construction/destruction

CContent::CContent()
{
}

CContent::~CContent()
{
}

/////////////////////////////////////////////////////////////////////////////
// CContent Operations


/////////////////////////////////////////////////////////////////////////////
// CContent diagnostics

#ifdef _DEBUG
void CContent::AssertValid() const
{
	CObject::AssertValid();
}

void CContent::Dump(CDumpContext& dc) const
{
	CObject::Dump(dc);
}
#endif //_DEBUG

////////////////////////////////////////////////////////
void CContent::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	CEdit::OnLButtonDown(nFlags, point);
}

