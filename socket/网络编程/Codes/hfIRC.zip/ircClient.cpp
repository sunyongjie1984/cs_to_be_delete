// CIrcClient.cpp : implementation file
//

#include "stdafx.h"
#include "hfIRC.h"
#include "ircClient.h"

#include "hfIRCView.h"
//#include "hfIRCDoc.h"
#include "Clientsocket.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIrcClient

CIrcClient::CIrcClient(CHfIRCView* pView)
//CIrcClient::CIrcClient(CHfIRCDoc* pDoc)
{
	m_pView		= pView;
	//m_pDoc		= pDoc;
	m_pSocket	= NULL;
	m_strCurChannel =	CString("");
	m_strHostIPAddress = CString("");
	m_strServerName =		CString("");
	m_strMyNickName =		CString("");

	m_strClientMsg =  CString("");
	m_strRecvMsg = CString("NULL");

	m_strlstDisplay.RemoveAll();

}

CIrcClient::~CIrcClient()
{
	if(m_pSocket != NULL) 
	{
		m_pSocket->ShutDown(2);
		m_pSocket->Close();
		delete m_pSocket;
		m_pSocket = NULL;
	}

}

void CIrcClient::Init()
{

	//Get the Nickname, Hostname, ....


	//build the socket link
	if( !ClientConnectSocket(m_strServerName) )  //connect the default server
	{
		//something is wrong 
	}

	if(m_pSocket == NULL) return;
	DoList();

	DoJoin("#cbkmis");
	DoNames();
	//DoJoin("#cbk");
	//DoTopic();
	//DoInfo();
	//DoWhois();
	DoPrivmsg("cbkmis","Hi I am the machine, auto send the Message.");	
	//DoQuit("I am send the Message Automaticly");

}


/////////////////////////////////////////////////////////////////////////////
// CIrcClient message handlers


void CIrcClient::DoJoin(LPCSTR lpszChannel)
{
	char	buf[50];
	int		iTem;

	if(m_pSocket == NULL) return;
	sprintf(buf, "JOIN %s",lpszChannel);
	iTem = strlen(buf);
	buf[iTem] = 0x0d;
	buf[iTem+1] = 0x0a;
	buf[iTem+2] = 0x00;
	m_pSocket->Send( (void*)buf, strlen(buf));
	
}

void CIrcClient::DoList()
{
	char	buf[50];
	int		iTem;

	if(m_pSocket == NULL) return;
	strcpy(buf,"LIST");
	iTem = strlen(buf);
	buf[iTem] = 0x0d;
	buf[iTem+1] = 0x0a;
	buf[iTem+2] = 0x00;
	m_pSocket->Send( (void*)buf, strlen(buf));

}

void CIrcClient::DoNick()
{

}


void CIrcClient::DoPrivmsg(LPCSTR lpszWho,LPCSTR lpszMessage)
{
	char	buf[512];
	int		iTem;

	//the message len is must less 510
	if(strlen(lpszMessage) > 510)
	{
		buf[510] = '\0';
		buf[511] = '\0';
	}

	//check the lpszWho , if the string is: "#chinese"  --> "chinese"

	if(m_pSocket == NULL) return;
	sprintf(buf, "PRIVMSG %s :%s",lpszWho,lpszMessage);
	iTem = strlen(buf);
	buf[iTem] = 0x0d;
	buf[iTem+1] = 0x0a;
	buf[iTem+2] = 0x00;
	m_pSocket->Send( (void*)buf, strlen(buf));

}

void CIrcClient::DoWhois()
{


}

void CIrcClient::DoPong(LPCSTR lpszServerName)
{
	char	buf[50];
	int		iTem;

	//the message len is must less 510
	if(strlen(lpszServerName) > 50)
	{
		//something wrong
		return;
	}

	if(m_pSocket == NULL) return;
	sprintf(buf, "PONG %s",lpszServerName);
	iTem = strlen(buf);
	buf[iTem] = 0x0d;
	buf[iTem+1] = 0x0a;
	buf[iTem+2] = 0x00;
	m_pSocket->Send( (void*)buf, strlen(buf));

}




BOOL CIrcClient::ClientConnectSocket(LPCTSTR lpszHostname,UINT nPort)
//BOOL CHfIRCDoc::ClientConnectSocket(LPCTSTR lpszHandle, LPCTSTR lpszAddress, UINT nPort)
{
	char	buf[512];
	int		iTem;
	
	m_pSocket = new CClientSocket(this);

	if (!m_pSocket->Create())
	{
		//??
		m_pSocket->Close();

		//??? 1998-07-21 closesocket();
		delete m_pSocket;
		m_pSocket = NULL;
		AfxMessageBox("Socket Create Error");
		return FALSE;
	}

	while(!m_pSocket->Connect(lpszHostname, nPort) )
	{
		//һ�����ɹ�,server �˵� nPort �ھͱ�ռ�ö� cbkcomsrv cannot startup ?????
		if (AfxMessageBox("ReConnect again?",MB_YESNO) == IDNO)
		{
			m_pSocket->Close();

			//??? 1998-07-21 closesocket();
			delete m_pSocket;
			m_pSocket = NULL;
			AfxMessageBox("Socket connect fail");
		
			return FALSE;
		}

	}

	//AfxMessageBox("Socket connect successfully");

	//Init:
	m_pSocket->m_pFile = new CSocketFile(m_pSocket);
	m_pSocket->m_pArchiveIn = new CArchive(m_pSocket->m_pFile,CArchive::load);
	m_pSocket->m_pArchiveOut = new CArchive(m_pSocket->m_pFile,CArchive::store);


	//Connect the host:
	//send the nickname:
	sprintf( buf,"NICK %s",LPCSTR(m_strMyNickName) );
	iTem = strlen(buf);
	buf[iTem] = 0x0d;
	buf[iTem+1] = 0x0a;
	buf[iTem+2] = 0x00;
	m_pSocket->Send( (void*)buf, strlen(buf));

	//send the username, hostname ,....
	////Command: USER
	//Parameters: <username> <hostname> <servername> <realname>
	//sprintf(buf, "USER %s * * %s\n", userinfo->pw_name,userinfo->pw_gecos);
	sprintf(buf, "USER %s \"intl-1\" \"23.150.0.1\" :%s",LPCSTR(m_strMyNickName),LPCSTR(m_strMyNickName));
	//sprintf(buf, "USER tempHF \"intl-1\" \"23.150.0.1\" :tempHF");
	iTem = strlen(buf);
	buf[iTem] = 0x0d;
	buf[iTem+1] = 0x0a;
	buf[iTem+2] = 0x00;
	m_pSocket->Send( (void*)buf, strlen(buf));

	
	CString strTemp;
	//m_pSocket->GetSockName( m_pSocket->m_strIPAddress, m_pSocket->m_uPort );
	

	return TRUE;
}


void CIrcClient::ParseRecvedStr(CString strMsg)
{
	int iEnd;
	//int iTem;
	char cTem;
	BOOL bTem;
	CString strPrefix,strCommand,strParams;
	CString strTem,strTem2;
	CString strChannel,strWhoTalkToMe;


	//format is: ":<prefix>[ ]<command>[ ]<params><CRLF>" 
	//<prefix>   ::= <servername> | <nick> [ '!' <user> ] [ '@' <host> ]
	//<params>   ::= <SPACE> [ ':' <trailing> | <middle> <params> ]

	//":irc2.cbkmis.boc 001 tempHF :Welcome to the Internet Relay Chat network, tempHF!tempHF@INTL_1"
	//":tempHF!tempHF@INTL_1 JOIN :#cbkmis"
	//":cbkmis!mIRC@23.150.0.1 PRIVMSG tempHF :asdkf"



	cTem = strMsg[0];
	if(cTem == ':')
	{
		//get the prefix:
		iEnd   = strMsg.Find(_T(' '));
		if(iEnd == -1)
		{
			//this is not a command
			m_pView->m_roomStatus.m_strContent += CString(_T("\r\nThis message is not a right command: "));
			m_pView->m_roomStatus.m_strContent += strMsg;
			m_pView->MyUpdateView();
			return;
		}
		strPrefix = strMsg.Mid(1,iEnd);
		
		//get the command:
		strTem = strMsg.Mid( iEnd+1,strMsg.GetLength() );
		iEnd   = strTem.Find(_T(' '));
		if(iEnd == -1)
		{
			//this is not a command
			return;
		}
		strCommand = strTem.Mid(0,iEnd);

		//get the params:
		strParams = strTem.Mid( iEnd+1,strTem.GetLength() );


		//according the command to process this message:
		if( strCommand == CString("001") )
		{
			m_strServerName = strPrefix;

			m_pView->m_roomStatus.m_strContent += CString(_T("\r\n"));
			m_pView->m_roomStatus.m_strContent += CString("The Server Name is: ");
			m_pView->m_roomStatus.m_strContent += LPCTSTR(m_strServerName);
			m_pView->MyUpdateView();


		}
		else if( strCommand == CString("002") )
		{

		}
		else if( strCommand == CString("003") )
		{

		}
		else if( strCommand == CString("004") )
		{

		}
		else if( strCommand == CString("005") )
		{

		}
		//LIST:
		else if( strCommand == CString("321") )
		{
		}
		else if( strCommand == CString("322") )
		{
			//response to the 'LIST'
			//have two channel #cbkmis #cbk2:
			//":irc2.cbkmis.boc 321 Guest3 Channel :Users Name"
			//":irc2.cbkmis.boc 322 Guest3 #cbkmis 3 :"
			//":irc2.cbkmis.boc 322 Guest3 #cbk2 3 :"
			//":irc2.cbkmis.boc 323 Guest3 :End of /LIST"
			
		}
		else if( strCommand == CString("333") )
		{
		}
		//NAMES:
		else if( strCommand == CString("353") )
		{
			//response to the 'NAMES'
			//only one channel:
			//":irc2.cbkmis.boc 353 Guest1 = #cbkmis :Guest1 Guest2 @cbkmis"
			//":irc2.cbkmis.boc 366 Guest1 * :End of /NAMES list."

			//have two channel: #cbkmis #cbk2
			//":irc2.cbkmis.boc 353 Guest1 = #cbkmis :Guest1 Guest2 @cbkmis"
			//":irc2.cbkmis.boc 353 Guest1 = #cbk2 :Guest1 @cbkmis"
			//":irc2.cbkmis.boc 366 Guest1 * :End of /NAMES list."


			//find the channel name:
			iEnd   = strParams.Find(_T('#'));
			if(iEnd == -1)
			{
				//this is something wrong 
			}
			strTem = strParams.Mid( iEnd,strParams.GetLength() );

			iEnd   = strTem.Find(_T(' '));
			if(iEnd == -1)
			{
				//this is something wrong
			}
			strChannel = strTem.Mid(0,iEnd);//??
			strTem = strTem.Mid( iEnd+2,strTem.GetLength() );
			//now strTem = ":Guest1 Guest2 @cbkmis"
			strTem.TrimLeft();

			//find the channel Room:
///////////////////
			//find the correspond room
			CRoom* proomTem;
			//bTem = FALSE;
			for(int i=0; i< m_pView->m_objlstRoomPtr.GetCount(); i++)
			{

				proomTem = (CRoom*) m_pView->m_objlstRoomPtr.GetAt(
					m_pView->m_objlstRoomPtr.FindIndex(i) );
					
				if(proomTem->m_iRoomType == HF_ROOM_TYPE_CHANNEL_PUBLIC &&
					proomTem->m_strRoomName == strChannel )
				{
					//clear the old data:
					proomTem->m_strChannelMember = CString(_T(""));

					
					//add the member to the Channel:
					for(;;)
					{
						iEnd   = strTem.Find(_T(' '));
						if(iEnd == -1)
						{
							proomTem->m_strChannelMember += strTem;
							proomTem->m_strChannelMember += CString(_T(""));
							break;
						}
						strTem2 = strTem.Mid(0,iEnd);//now strTem2 is contain the nickname
						strTem.TrimLeft();
						proomTem->m_strChannelMember += strTem2;
						proomTem->m_strChannelMember += CString(_T("\r\n"));
						strTem = strTem.Mid( iEnd+1,strTem.GetLength() );

					}
					m_pView->MyUpdateView();
					break;
				}

			}

		}
		else if( strCommand == CString("366") )
		{
		}
		else if( strCommand == CString("PRIVMSG") )
		{
			//someone send the message

			//get the NickName from the strPrefix
			//strPrefix == "cbkmis!mIRC@23.150.0.1"

			//get the sender nick name
			iEnd   = strPrefix.Find(_T('!'));
			if(iEnd != -1)
				strWhoTalkToMe = strPrefix.Mid(0,iEnd);
			else
				strWhoTalkToMe = strPrefix;
			
			
			/*iEnd   = strPrefix.Find(_T('!'));
			if(iEnd == -1)
			{
				strNickName = strPrefix;
			}
			strNickName = strPrefix.Mid(0,iEnd);
			*/

			//there are 2 case:
			//1. is in the channel
			//2. is someone send message to me

			if( strParams[0] == '#' )
			{
				//1.the strParams format is: "#cbkmis :asdf"
				iEnd   = strParams.Find(_T(' '));
				if(iEnd == -1)
				{
					//this is something wrong 
					return;
				}
				strChannel = strParams.Mid(0,iEnd);//??
				
				//the words is:
				strTem = strParams.Mid( iEnd+2,strParams.GetLength() );

				//m_pView->m_ChannelRoom.m_strChannelMember = strChannel;
				//m_pView->m_ChannelRoom.m_strContent = CString(_T("\r\n"))+strChannel;

			#ifdef HF_DEBUG
				m_pView->m_roomStatus.m_strContent += CString(_T("\r\n[#"));
				m_pView->m_roomStatus.m_strContent += strChannel;
				m_pView->m_roomStatus.m_strContent += CString("]");
				m_pView->m_roomStatus.m_strContent += strTem;
				m_pView->MyUpdateView();
			#endif

				//find the correspond room
				CRoom* proomTem;
				bTem = FALSE;
				for(int i=0; i< m_pView->m_objlstRoomPtr.GetCount(); i++)
				{

					proomTem = (CRoom*) m_pView->m_objlstRoomPtr.GetAt(
						m_pView->m_objlstRoomPtr.FindIndex(i) );
					
					if(proomTem->m_iRoomType == HF_ROOM_TYPE_CHANNEL_PUBLIC &&
						proomTem->m_strRoomName == strChannel )
					{
						//the room is already exist
						proomTem->m_strContent += CString(_T("<"));
						proomTem->m_strContent += strWhoTalkToMe;
						proomTem->m_strContent += CString(_T(">"));

						proomTem->m_strContent += strTem;
						proomTem->m_strContent += CString(_T("\r\n"));
						m_pView->MyUpdateView();

						bTem = TRUE;
						break;
					}

				}
				if( bTem == FALSE)
				{
					//the room is not exist, and build one:
					proomTem = new CRoom;
					m_pView->m_objlstRoomPtr.AddHead( proomTem );
					proomTem->m_iRoomType = HF_ROOM_TYPE_CHANNEL_PUBLIC;
					proomTem->m_strRoomName = strChannel;
					if(!m_pView->m_wndStatusBar.MySetIndicators())
					{
						TRACE0("Failed to set status bar indicators\n");
					}

					//write down the words
					proomTem->m_strContent += CString(_T("<"));
					proomTem->m_strContent += strWhoTalkToMe;
					proomTem->m_strContent += CString(_T(">"));
					proomTem->m_strContent += strTem;
					proomTem->m_strContent += CString(_T("\r\n"));
					m_pView->MyUpdateView();

				}
			}
			else
			{
				//2.the strParams format is: "tempHF :asdf"
				//<prefix>   ::= <servername> | <nick> [ '!' <user> ] [ '@' <host> ]

				/*/get the sender nick name
				iEnd   = strPrefix.Find(_T('!'));
				if(iEnd != -1)
					strWhoTalkToMe = strPrefix.Mid(0,iEnd);
				else
					strWhoTalkToMe = strPrefix;
				*/
				iEnd   = strParams.Find(_T(' '));
				if(iEnd == -1)
				{
					//this is something wrong 
					return;
				}
					
				strTem = strParams.Mid(1,iEnd);
				//if(strTem == m_strMyNickName)
				
				//the words is:
				strTem = strParams.Mid( iEnd+2,strParams.GetLength() );

			#ifdef HF_DEBUG
				m_pView->m_roomStatus.m_strContent += CString(_T("\r\n<"));
				m_pView->m_roomStatus.m_strContent += strWhoTalkToMe;
				m_pView->m_roomStatus.m_strContent += CString(">");
				m_pView->m_roomStatus.m_strContent += strTem;
				m_pView->MyUpdateView();
			#endif
				//find the correspond room
				CRoom* proomTem;
				bTem = FALSE;
				for(int i=0; i< m_pView->m_objlstRoomPtr.GetCount(); i++)
				{

					proomTem = (CRoom*) m_pView->m_objlstRoomPtr.GetAt(
						m_pView->m_objlstRoomPtr.FindIndex(i) );
					
					if(proomTem->m_iRoomType == HF_ROOM_TYPE_PRIVATE &&
						proomTem->m_strRoomName == strWhoTalkToMe )
					{
						//the room is already exist
						proomTem->m_strContent += CString(_T("<"));
						proomTem->m_strContent += strWhoTalkToMe;
						proomTem->m_strContent += CString(_T(">"));

						proomTem->m_strContent += strTem;
						proomTem->m_strContent += CString(_T("\r\n"));
						m_pView->MyUpdateView();

						bTem = TRUE;
						break;
					}

				}
				if( bTem == FALSE)
				{
					//the room is not exist, and build one:
					proomTem = new CRoom;
					m_pView->m_objlstRoomPtr.AddHead( proomTem );
					proomTem->m_iRoomType = HF_ROOM_TYPE_PRIVATE;
					proomTem->m_strRoomName = strWhoTalkToMe;
					if(!m_pView->m_wndStatusBar.MySetIndicators())
					{
						TRACE0("Failed to set status bar indicators\n");
					}


					//write down the words
					proomTem->m_strContent += CString(_T("<"));
					proomTem->m_strContent += strWhoTalkToMe;
					proomTem->m_strContent += CString(_T(">"));
					proomTem->m_strContent += strTem;
					proomTem->m_strContent += CString(_T("\r\n"));
					m_pView->MyUpdateView();
				}
			}
			
			//CString strHere;
			//strHere = CString("<") + LPCTSTR(strPrefix) + CString(">") + strParams;
			//m_pDoc->DisplayMsg( strHere );

		}
		else if( strCommand == CString("JOIN") )
		{
			//two case:
			//1. I join one channel room the server ack 
			//2. Someone join the channel room , the server inform me

			//get the sender nick name
			iEnd   = strPrefix.Find(_T('!'));
			if(iEnd != -1)
				strTem = strPrefix.Mid(0,iEnd);
			else
				strTem = strPrefix;


			strParams = strParams.Mid(1,strParams.GetLength());
			#ifdef HF_DEBUG
				m_pView->m_roomStatus.m_strContent += CString(_T("\r\n***"));
				m_pView->m_roomStatus.m_strContent += strPrefix;
				m_pView->m_roomStatus.m_strContent += CString(" Has Joined the channel:");
				m_pView->m_roomStatus.m_strContent += strParams;
				m_pView->m_roomStatus.m_strContent += CString(_T("\r\n-"));
				m_pView->MyUpdateView();
			#endif

			strParams.TrimRight();
			strChannel = strParams;

			if(strTem == m_strMyNickName)
			{
				//1. I join one channel room the server ack 

				//build one new Room:
				//find the correspond room
				CRoom* proomTem;
				bTem = FALSE;
				for(int i=0; i< m_pView->m_objlstRoomPtr.GetCount(); i++)
				{
					proomTem = (CRoom*) m_pView->m_objlstRoomPtr.GetAt(
						m_pView->m_objlstRoomPtr.FindIndex(i) );
					
					if(proomTem->m_iRoomType == HF_ROOM_TYPE_CHANNEL_PUBLIC &&
						proomTem->m_strRoomName == strChannel )
					{
						//the room is already exist
							bTem = TRUE;
							break;
					}
				}
				if( bTem == FALSE)
				{
						//the room is not exist, and build one:
						proomTem = new CRoom;
						m_pView->m_objlstRoomPtr.AddHead( proomTem );
						proomTem->m_iRoomType = HF_ROOM_TYPE_CHANNEL_PUBLIC;
						proomTem->m_strRoomName = strChannel;
						if(!m_pView->m_wndStatusBar.MySetIndicators())
						{
							TRACE0("Failed to set status bar indicators\n");
						}
				}
			}
			else
			{
				//2. Someone join the channel room , the server inform me
				//add the name to the channelMember
				CRoom* proomTem;
				//bTem = FALSE;
				for(int i=0; i< m_pView->m_objlstRoomPtr.GetCount(); i++)
				{
					proomTem = (CRoom*) m_pView->m_objlstRoomPtr.GetAt(
						m_pView->m_objlstRoomPtr.FindIndex(i) );
					
					if(proomTem->m_iRoomType == HF_ROOM_TYPE_CHANNEL_PUBLIC &&
						proomTem->m_strRoomName == strChannel )
					{
						proomTem->m_strChannelMember += CString(_T("\r\n"));
						proomTem->m_strChannelMember += strTem;
						break;
					}
				}
			}
		}
		else if( strCommand == CString("QUIT") )
		{
			//quit and disconnect
				m_pView->m_roomStatus.m_strContent += CString(_T("\r\n*** "));
				m_pView->m_roomStatus.m_strContent += strPrefix;
				m_pView->m_roomStatus.m_strContent += CString("Has Quit the channel.\r\n-");
				m_pView->MyUpdateView();

		}
		else if( strCommand == CString("MODE") )
		{

		}
		else if( strCommand == CString("TOPIC") )
		{
			m_pView->m_roomStatus.m_strContent += CString(_T("\r\n- The Topic is:"));
			m_pView->m_roomStatus.m_strContent += strParams;
			m_pView->m_roomStatus.m_strContent += CString("\r\n-");
			m_pView->MyUpdateView();
		}
		else if( strCommand == CString("PART") )
		{
			//someone left the irc room
		}

	}
	else
	{
		//"PING :irc2.cbkmis.boc"
		//get the COMMAND:
		iEnd   = strMsg.Find(_T(' '));
		if(iEnd == -1)
		{
			//this is not a command
			return;
		}
		strCommand = strMsg.Mid(0,iEnd);
		
		strParams = strMsg.Mid( iEnd+2,strMsg.GetLength() );

		if( strCommand == CString("PING") )
		{
			//the server has send a ping messge, must send a pong messege back
			DoPong( LPCSTR(strParams.Mid(0,strParams.GetLength())) );

			m_pView->m_roomStatus.m_strContent += CString(_T("\r\nPING?  PONG!\r\n-"));
			m_pView->MyUpdateView();
		}
		else if( strCommand == CString("ERROR") )
		{
			//the server has send error message
			m_pView->m_roomStatus.m_strContent += CString(_T("\r\nError!--"));
			m_pView->m_roomStatus.m_strContent += strParams;
			m_pView->m_roomStatus.m_strContent += CString("\r\n-");
			m_pView->MyUpdateView();

		}
	}
}


void CIrcClient::ParseInputCommandStr(CString strText)
{

	int iEnd;
	CString strCommand,strParams;
	
	//this input is a command
	//get the command:
	iEnd   = strText.Find(_T(' '));
	if(iEnd == -1)
	{
		//the input command like: '/list'
		strCommand = strText.Mid(1,strText.GetLength());
		strParams = CString(_T(""));
	}
	else
	{
		strCommand = strText.Mid(1,iEnd);
		strParams = strText.Mid(iEnd+1,strText.GetLength());
		strParams.TrimLeft();
		strParams.TrimRight();
	}

	strCommand.MakeUpper();
	strCommand.TrimLeft();
	strCommand.TrimRight();

	if( strCommand == CString(_T("JOIN")) )
	{
		DoJoin( LPCSTR(strParams) );
	}
	if( strCommand == CString(_T("LIST")) )
	{
		DoList();
	}
	if( strCommand == CString(_T("CLEAR")) || strCommand == CString(_T("CLS")) )
	{
		DoClear();
	}

}

void CIrcClient::DoClear()
{
		if(0 == m_pView->m_wndStatusBar.m_iActive )
		{
			//now the active room is 'Status'
			m_pView->m_roomStatus.m_strContent = CString(_T(""));
			m_pView->MyUpdateView();
		}
		else
		{
			//find the correspond room
			CRoom* proomTem;
			proomTem = (CRoom*) m_pView->m_objlstRoomPtr.GetAt(
				m_pView->m_objlstRoomPtr.FindIndex(m_pView->m_wndStatusBar.m_iActive - 1) ); //!! the list 0, (0, 1, 2, ....)
				//m_pView->m_objlstRoomPtr.FindIndex(pView->m_wndStatusBar.m_iActive) );

			proomTem->m_strContent = CString(_T(""));
			m_pView->MyUpdateView();

		}
}

void CIrcClient::DoNames()
//void CIrcClient::DoNames(LPCSTR lpszChannel)
{
	char	buf[50];
	int		iTem;

	if(m_pSocket == NULL) return;
	sprintf(buf, "NAMES");
	//sprintf(buf, "NAMES %s",lpszChannel);
	iTem = strlen(buf);
	buf[iTem] = 0x0d;
	buf[iTem+1] = 0x0a;
	buf[iTem+2] = 0x00;
	m_pSocket->Send( (void*)buf, strlen(buf));
	
}
