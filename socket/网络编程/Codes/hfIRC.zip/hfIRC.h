// hfIRC.h : main header file for the HFIRC application
//

#if !defined(AFX_HFIRC_H__B62703F8_26D7_11D2_A8C9_0080C8560A58__INCLUDED_)
#define AFX_HFIRC_H__B62703F8_26D7_11D2_A8C9_0080C8560A58__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CHfIRCApp:
// See hfIRC.cpp for the implementation of this class
//

class CHfIRCApp : public CWinApp
{
public:
	CHfIRCApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHfIRCApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CHfIRCApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HFIRC_H__B62703F8_26D7_11D2_A8C9_0080C8560A58__INCLUDED_)
