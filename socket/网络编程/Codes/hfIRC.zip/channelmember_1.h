#if !defined(_CChannelMember_H__)
#define _CChannelMember_H__



class CChannelMember : public CEdit
{
protected:
	DECLARE_DYNCREATE(CChannelMember)
public:
	CChannelMember();

// Attributes
public:

// Operations
public:

// Implementation
public:
	virtual ~CChannelMember();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	
	DECLARE_MESSAGE_MAP()


};

/////////////////////////////////////////////////////////////////////////////
#endif //_CChannelMember_H__