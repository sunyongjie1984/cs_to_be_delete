// hfIRCView.cpp : implementation of the CHfIRCView class
//

#include "stdafx.h"
#include "hfIRC.h"

#include "hfIRCDoc.h"
#include "hfIRCView.h"

#include "logdg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static UINT view_indicators[] =
{
	ID_INDICATOR_MY,
	//ID_SEPARATOR,
	//ID_INDICATOR_CAPS,
	//ID_INDICATOR_NUM,
};



/////////////////////////////////////////////////////////////////////////////
// CHfIRCView

IMPLEMENT_DYNCREATE(CHfIRCView, CView)

BEGIN_MESSAGE_MAP(CHfIRCView, CView)
	//{{AFX_MSG_MAP(CHfIRCView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_MENUITEM_CONN, OnMenuitemConn)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHfIRCView construction/destruction

CHfIRCView::CHfIRCView()
{
	m_pClient = NULL;	
	//m_strStatusWnd = CString(_T(""));
	m_wndStatusBar.MySetView(this);
	m_wndInputBar.MySetView(this);

	m_objlstRoomPtr.RemoveAll();
}

CHfIRCView::~CHfIRCView()
{
	
	POSITION pos = m_objlstRoomPtr.GetHeadPosition();
	while( pos != NULL )
	{
		!delete the room ??  1998-09-11
		delete m_objlstRoomPtr.GetNext( pos );
	}
	m_objlstRoomPtr.RemoveAll();

	if(m_pClient != NULL)
		delete m_pClient;
	m_pClient = NULL;


}

BOOL CHfIRCView::PreCreateWindow(CREATESTRUCT& cs)
{
	BOOL ret = CView::PreCreateWindow(cs);
	cs.style = AFX_WS_DEFAULT_VIEW  ;
	//cs.style = AFX_WS_DEFAULT_VIEW | WS_VSCROLL | ES_AUTOHSCROLL |  WS_HSCROLL |
		//ES_AUTOVSCROLL | ES_MULTILINE | ES_NOHIDESEL;
	return ret;

	//return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CHfIRCView drawing

void CHfIRCView::OnDraw(CDC* pDC)
{
	CHfIRCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CHfIRCView printing

BOOL CHfIRCView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CHfIRCView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CHfIRCView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CHfIRCView diagnostics

#ifdef _DEBUG
void CHfIRCView::AssertValid() const
{
	CView::AssertValid();
}

void CHfIRCView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CHfIRCDoc* CHfIRCView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CHfIRCDoc)));
	return (CHfIRCDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHfIRCView message handlers


int CHfIRCView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	CRect r,r1;
	GetClientRect(&r);
	
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	//statusbar:
	if (!m_wndStatusBar.Create(this,WS_CHILD | WS_VISIBLE |	 WS_BORDER) )
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	//if(	!m_wndStatusBar.MySetIndicators())
	if(	!m_wndStatusBar.SetIndicators(view_indicators,
		  sizeof(view_indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to set status bar indicators\n");
		return -1;      // fail to create
	}
	m_wndStatusBar.SetPaneText(0,"Status", TRUE);
	m_wndStatusBar.SetPaneInfo(0,0,SBPS_POPOUT,MY_STATUS_PANE_WIDTH);
	m_wndStatusBar.SetPaneInfo(0,0,SBPS_NORMAL,MY_STATUS_PANE_WIDTH);
	m_wndStatusBar.m_iActive = 0;


	//build a StatusRoom:
	//inputbar:
	r1.bottom = r.bottom - MY_STATUSBAR_HEIGHT;
	r1.top = r.bottom - MY_STATUSBAR_HEIGHT - MY_INPUTBAR_HEIGHT;
	//m_wndInputBar = new CInputBar;
	if (!m_wndInputBar.Create(ES_AUTOHSCROLL | WS_CHILD | WS_VISIBLE | WS_BORDER ,
				 r1,this,1) )
	{
		TRACE0("Failed to create input bar\n");
		return -1;      // fail to create
	}

	//channelmember edit:
	r1.top = r.top;
	r1.bottom = r.bottom - MY_STATUSBAR_HEIGHT - MY_INPUTBAR_HEIGHT;
	r1.left = r1.right; // is inviseble
	//r1.left = r.right - MY_CHANNEL_MEMBER_WIDTH;
	if (!m_wndChannelMember.Create(ES_AUTOHSCROLL | WS_CHILD | WS_VISIBLE 
			| ES_MULTILINE, r1,this,2) )
	{
		TRACE0("Failed to create channelmember\n");
		return -1;      // fail to create
	}
	

	//content edit:
	r1 = r;
	//r1.top = r.top;
	r1.bottom = r.bottom - MY_STATUSBAR_HEIGHT - MY_INPUTBAR_HEIGHT;
	//r1.right = r.right;
		//r1.right = r.right - MY_CHANNEL_MEMBER_WIDTH;
	//r1.left = r.left;
	//m_roomStatus.m_pwndContent = new CContent;
	if (!m_wndContent.Create(ES_AUTOHSCROLL | WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE,
				 r1,this,2) )
	{
		TRACE0("Failed to create content\n");
		return -1;      // fail to create
	}

	return 0;
}

void CHfIRCView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	CRect r,r1;
	GetClientRect(&r);
	
	//status bar:
	r1 = r;
	r1.top = r.bottom - MY_STATUSBAR_HEIGHT;
	//r.bottom = 25;
	m_wndStatusBar.MoveWindow(&r1);
	m_wndStatusBar.MySetIndicators();

	
	UINT nID,nStyle;
	int cxWidth;
	m_wndStatusBar.GetPaneInfo(0,nID,nStyle,cxWidth);
	m_wndStatusBar.SetPaneInfo(0,nID,SBPS_STRETCH,cxWidth);
	m_wndStatusBar.SetPaneInfo(0,0,SBPS_POPOUT,cxWidth);

	//input bar:
	r1.bottom = r.bottom - MY_STATUSBAR_HEIGHT;
	r1.top = r.bottom - MY_STATUSBAR_HEIGHT - MY_INPUTBAR_HEIGHT;
	m_wndInputBar.MoveWindow(&r1);

	//move the content Edit and channelMember Edit to the right locations
	MyMoveWnd();

}


void CHfIRCView::Connect()
{
	//Get the nickname and servername:
	CLogDg dg;
	CString strNickName,strServerName;

	dg.m_strServerName = DEFAULTSERVER;
	dg.m_strNickName = DEFAULTNICK;
	if (dg.DoModal() != IDOK)
		return;

	strNickName = dg.m_strNickName;
	strServerName = dg.m_strServerName;


	//build a client
	if(m_pClient == NULL)
	{
		m_pClient = new CIrcClient(this);
		if( m_pClient == NULL )
		{
			//something is wrong here
			//return FALSE;
		}
		m_pClient->m_strMyNickName = strNickName;
		m_pClient->m_strServerName = strServerName;
		m_pClient->Init();
	}
}

void CHfIRCView::OnMenuitemConn() 
{
	Connect();		
}

void CHfIRCView::MyUpdateView()
{
	//m_roomStatus.m_pwndContent->SetSel(0,-1,FALSE);
	//m_roomStatus.m_pwndContent->ReplaceSel(m_strStatusWnd);

	MyMoveWnd();

	if(m_wndStatusBar.m_iActive == 0)
	{
		m_wndContent.SetSel(0,-1,FALSE);
		m_wndContent.ReplaceSel(m_roomStatus.m_strContent);
		m_wndInputBar.SetFocus();
	}
	else
	{
		if(m_objlstRoomPtr.GetCount() <= 0)  return;


		CRoom* proomTem = (CRoom*)m_objlstRoomPtr.GetAt(
			m_objlstRoomPtr.FindIndex(m_wndStatusBar.m_iActive - 1) );

		m_wndContent.SetSel(0,-1,FALSE);
		m_wndContent.ReplaceSel(proomTem->m_strContent);

		m_wndChannelMember.SetSel(0,-1,FALSE);
		m_wndChannelMember.ReplaceSel(proomTem->m_strChannelMember);

		if( HF_ROOM_TYPE_CHANNEL_LIST != proomTem->m_iRoomType )
			m_wndInputBar.SetFocus();

	}

}

void CHfIRCView::MyMoveWnd()
{

	CRect r,r1;
	GetClientRect(&r);

	if(m_wndStatusBar.m_iActive == 0)
	{
		// this is the Status Room
		//channelmember:
		//is inviseble
		r1 = r;
		r1.left = r1.right;
		//r1.top = r.top;
		r1.bottom = r.bottom - MY_STATUSBAR_HEIGHT - MY_INPUTBAR_HEIGHT;
		//r1.left = r.right - MY_CHANNEL_MEMBER_WIDTH;
		m_wndChannelMember.MoveWindow(&r1);
	
		//content:
		r1 = r;
		//r1.top = r.top;
		r1.bottom = r.bottom - MY_STATUSBAR_HEIGHT - MY_INPUTBAR_HEIGHT;
		//if(r.Width > 200)
		//r1.right = r1.left;
		//r1.left = r.left;
		m_wndContent.MoveWindow(&r1);
	}
	else
	{
		//find the correspond room
		CRoom* proomTem;
		proomTem = (CRoom*) m_objlstRoomPtr.GetAt(
			m_objlstRoomPtr.FindIndex(m_wndStatusBar.m_iActive - 1) ); //!! the list 0, (0, 1, 2, ....)

		// this is the Channel Room
		//channelmember:
		if( proomTem->m_iRoomType == HF_ROOM_TYPE_CHANNEL_PUBLIC)
		{
			r1 = r;
			//r1.top = r.top;
			r1.bottom = r.bottom - MY_STATUSBAR_HEIGHT - MY_INPUTBAR_HEIGHT;
			r1.left = r.right - MY_CHANNEL_MEMBER_WIDTH;
			m_wndChannelMember.MoveWindow(&r1);
		}
	
		//content:
		r1 = r;
		//r1.top = r.top;
		r1.bottom = r.bottom - MY_STATUSBAR_HEIGHT - MY_INPUTBAR_HEIGHT;
		//if(r.Width > 200)
		if( proomTem->m_iRoomType == HF_ROOM_TYPE_CHANNEL_PUBLIC)
			r1.right = r.right - MY_CHANNEL_MEMBER_WIDTH;
		//r1.left = r.left;
		m_wndContent.MoveWindow(&r1);
	}
}

