
#include "stdafx.h"
#include "hfIRC.h"
#include "InputBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CInputBar

//IMPLEMENT_DYNCREATE(CInputBar, CEdit)

//BEGIN_MESSAGE_MAP(CInputBar, CEdit)
//	ON_WM_LBUTTONDOWN()
//END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CInputBar construction/destruction

CInputBar::CInputBar()
{
}

CInputBar::~CInputBar()
{
}

/////////////////////////////////////////////////////////////////////////////


BEGIN_MESSAGE_MAP(CInputBar, CEdit)
	//{{AFX_MSG_MAP(CInputBar)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInputBar message handlers


/////////////////////////////////////////////////////////////////////////////
// CInputBar Operations


/////////////////////////////////////////////////////////////////////////////
// CInputBar diagnostics

#ifdef _DEBUG
void CInputBar::AssertValid() const
{
	CObject::AssertValid();
}

void CInputBar::Dump(CDumpContext& dc) const
{
	CObject::Dump(dc);
}
#endif //_DEBUG

////////////////////////////////////////////////////////


