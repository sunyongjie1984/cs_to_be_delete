// Client.cpp : implementation file
//

#include "stdafx.h"
#include "hfIRC.h"
#include "Clientsocket.h"
#include "hfIRCView.h"
//#include "hfIRCDoc.h"
#include "ircClient.h"

//#include "RecvDg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClientSocket

CClientSocket::CClientSocket()
{
}


CClientSocket::CClientSocket(CIrcClient* pClient)
{
	m_pClient = pClient;

	m_pFile = NULL;
	m_pArchiveIn = NULL;
	m_pArchiveOut = NULL;

}

CClientSocket::~CClientSocket()
{
	/*  ???  1998-07-24
	if( m_pFile != NULL )
	{
		delete m_pFile;
		m_pFile = NULL;
	}
	if( m_pArchiveIn != NULL)
	{
		delete m_pArchiveIn;
		m_pArchiveIn = NULL;
	}
	if( m_pArchiveOut != NULL)
	{
		delete m_pArchiveOut;
		m_pArchiveOut = NULL;
	}
	*/
	//delete m_pRecvDg;
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CClientSocket, CSocket)
	//{{AFX_MSG_MAP(CClientSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CClientSocket member functions


void CClientSocket::OnReceive(int nErrorCode)
{
	char bufRecv[512];

	//char bufTem[512];
	int  iTem;
	int  iLen;
	int	 iStart, iEnd;
	char  cTem;
	CString strTem1,strTem2;
	int  i;

	do
	{
		iLen = this->Receive( bufRecv, 512 );
 		if (iLen >= 511 )
					iLen = 511;
		bufRecv[iLen] = 0x00;
		if(m_pClient != NULL)
		{
			//process the recved Message:
			iStart = iEnd = 0;
			cTem = bufRecv[0];
			iTem = strTem1.GetLength();
		
			strTem1 = CString(bufRecv);
			
			//Lstrim:
			for( i=0; i < iTem; i++)
			{
				if(strTem1[0] == ' ')
				{
					strTem1 = strTem1.Mid(1,iTem);
				}
				else
					break;
			}
			
			iTem = strTem1.GetLength();

			i = 0;
			for(;iEnd < iTem;)
			{
				iEnd   = strTem1.Find(_T("\r\n"));  //?? CR LF?
				if(iEnd == -1)
					iEnd = strTem1.GetLength();

				strTem2 = strTem1.Mid(0,iEnd);
				//strTem2 = strTem1.Mid(iStart,iEnd);

				m_pClient->ParseRecvedStr(strTem2);
				
			//#ifdef HF_DEBUG
				m_pClient->m_pView->m_roomStatus.m_strContent += CString(_T("\r\n"));
				//m_pClient->m_pView->m_roomStatus.m_strContent += CString(_T("\r\n"));
				m_pClient->m_pView->m_roomStatus.m_strContent += strTem2;
				m_pClient->m_pView->MyUpdateView();
				//m_pClient->m_pView->DisplayMsg(LPCTSTR(strTem2));
			//#endif

				//m_pClient->m_strlstDisplay.AddTail(strTem2);
				
				iTem = strTem1.GetLength();
				if(iEnd+2 >= iTem)		break;
				strTem1 = strTem1.Mid(iEnd+2,iTem);
				i++;
			}
		
				 //display in the view
				//if(m_pClient != NULL)
				//	m_pClient->m_strRecvMsg = m_pClient->m_strRecvMsg + CString(bufRecv);
				//m_pClient->m_pDoc->DisplayMsg();
				
				/*
				if(m_pRecvDg->GetSafeHwnd() == 0)
				{
					m_pRecvDg->Create();//displays dialog
					m_pRecvDg->ShowWindow(SW_SHOWNORMAL);
				}
				else
				{
					//m_pRecvDg->UpdateDisplay();
					m_pRecvDg->ShowWindow(SW_RESTORE);
					::BringWindowToTop( m_pRecvDg->GetSafeHwnd() );
				}
				*/
//			AfxMessageBox(m_pClient->m_strRecvMsg);


			//iTem = strlen(bufRecv);
			//sprintf(bufTem,"Recv:%s,the tail =%d,%d.",bufRecv,bufRecv[iTem-2],bufRecv[iTem-1] );
			//AfxMessageBox(bufTem);

		}

		
	
	}
	while(!this->m_pArchiveIn->IsBufferEmpty());
	
	CSocket::OnReceive(nErrorCode);
}

/*

int	dopacket(cptr, buffer, length)
Reg	aClient *cptr;
char	*buffer;
Reg	int	length;
{
	Reg	char	*ch1;
	Reg	char	*ch2, *bufptr;
	aClient	*acpt = cptr->acpt;
	int	r = 1;
 
	me.receiveB += length; / * Update bytes received * /
	cptr->receiveB += length;
	if (cptr->receiveB > 1023)
	    {
		cptr->receiveK += (cptr->receiveB >> 10);
		cptr->receiveB &= 0x03ff;	/ * 2^10 = 1024, 3ff = 1023 * /
	    }
	if (acpt != &me)
	    {
		acpt->receiveB += length;
		if (acpt->receiveB > 1023)
		    {
			acpt->receiveK += (acpt->receiveB >> 10);
			acpt->receiveB &= 0x03ff;
		    }
	    }
	else if (me.receiveB > 1023)
	    {
		me.receiveK += (me.receiveB >> 10);
		me.receiveB &= 0x03ff;
	    }
	bufptr = cptr->buffer;
	ch1 = bufptr + cptr->count;
	ch2 = buffer;
	while (--length >= 0)
	    {
		Reg	char	c;

		c = (*ch1 = *ch2++);
		/ *
		 * Yuck.  Stuck.  To make sure we stay backward compatible,
		 * we must assume that either CR or LF terminates the message
		 * and not CR-LF.  By allowing CR or LF (alone) into the body
		 * of messages, backward compatibility is lost and major
		 * problems will arise. - Avalon
		 * /
		if ((c <= '\r') && (c == '\n' || c == '\r'))
		    {
			if (ch1 == bufptr)
				continue; / * Skip extra LF/CR's * /
			*ch1 = '\0';
			me.receiveM += 1; / * Update messages received * /
			cptr->receiveM += 1;
			if (cptr->acpt != &me)
				cptr->acpt->receiveM += 1;
			cptr->count = 0; / * ...just in case parse returns with
					 ** FLUSH_BUFFER without removing the
					 ** structure pointed by cptr... --msa
					 * /
			if ((r = parse(cptr, bufptr, ch1)) ==
			    FLUSH_BUFFER)
				/ *
				** FLUSH_BUFFER means actually that cptr
				** structure *does* not exist anymore!!! --msa
				* /
				return FLUSH_BUFFER;
#ifndef CLIENT_COMPILE
			/ *
			** Socket is dead so exit (which always returns with
			** FLUSH_BUFFER here).  - avalon
			* /
			if (cptr->flags & FLAGS_DEADSOCKET)
			    {
				if (cptr->exitc == EXITC_REG)
					cptr->exitc = EXITC_DEAD;
				return exit_client(cptr, cptr, &me,
						   "Dead Socket");
			    }
#endif
			ch1 = bufptr;
		    }
		else if (ch1 < bufptr + (sizeof(cptr->buffer)-1))
			ch1++; / * There is always room for the null * /
	    }
	cptr->count = ch1 - bufptr;
	return r;
}
*/


