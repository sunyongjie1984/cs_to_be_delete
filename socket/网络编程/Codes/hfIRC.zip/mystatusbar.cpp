// msg.cpp : implementation of the CMyStatusBar class
//
// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (C) 1992-1995 Microsoft Corporation
// All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.

#include "stdafx.h"
#include "mystatusbar.h"

#include "hfIRCView.h"


#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyStatusBar

IMPLEMENT_DYNCREATE(CMyStatusBar, CStatusBar)

BEGIN_MESSAGE_MAP(CMyStatusBar, CStatusBar)
	ON_WM_LBUTTONDOWN()
	//ON_WM_PAINT()
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CMyStatusBar construction/destruction

CMyStatusBar::CMyStatusBar()
{
	//m_pView = pView;
	//m_iPaneCount = 3;
	//m_iPaneCount = 1;
	m_iActive = 0;
	m_aIndicators.RemoveAll();
	//m_aIndicators.Add(ID_INDICATOR_MY);
	m_aIndicators.Add(ID_SEPARATOR);
}

void CMyStatusBar::MySetView(CHfIRCView* pView)
{
	m_pView = pView;
}
CMyStatusBar::~CMyStatusBar()
{
}

/////////////////////////////////////////////////////////////////////////////
// CMyStatusBar Operations


/////////////////////////////////////////////////////////////////////////////
// CMyStatusBar diagnostics

#ifdef _DEBUG
void CMyStatusBar::AssertValid() const
{
	CObject::AssertValid();
}

void CMyStatusBar::Dump(CDumpContext& dc) const
{
	CObject::Dump(dc);
}
#endif //_DEBUG

////////////////////////////////////////////////////////
void CMyStatusBar::OnLButtonDown(UINT nFlags, CPoint point) 
{
	//UINT nID,nStyle;
	int cxWidth;
	int iTem,i;
	int iPaneCount;

	CRect r,r1;
	GetClientRect(&r);

	iPaneCount = m_pView->m_objlstRoomPtr.GetCount() + 1;
	if((r.right-r.left) < iPaneCount * MY_STATUS_PANE_WIDTH)
	//if((r.right-r.left) < m_iPaneCount * MY_STATUS_PANE_WIDTH)
	{
		cxWidth = (int)((r.right-r.left)/iPaneCount);
		//cxWidth = (int)((r.right-r.left)/m_iPaneCount);
	}
	else
		cxWidth = MY_STATUS_PANE_WIDTH;

	iTem = (int)(point.x/cxWidth);
	
	if(iTem < iPaneCount)
	{
		for(i = 0; i< iPaneCount; i++)
		{
			//this->GetPaneInfo(i,nID,nStyle,iTem);
			this->SetPaneInfo(i,0,SBPS_POPOUT,cxWidth);
		}

		if(m_iActive == iTem)
			iTem = (m_iActive+1)%iPaneCount;
		//this->GetPaneInfo((int)(point.x / iTem ),nID,nStyle,iTem);
		this->SetPaneInfo(iTem,0,SBPS_NORMAL,cxWidth);
		m_iActive = iTem;

		/*
		this->GetPaneInfo(1,nID,nStyle,cxWidth);
		if(nStyle == SBPS_NORMAL)
			this->SetPaneInfo(1,nID,SBPS_POPOUT,cxWidth);
		else
			this->SetPaneInfo(1,nID,SBPS_NORMAL,cxWidth);
		*/
	}

	if(m_pView != NULL)
		m_pView->MyUpdateView();


	CStatusBar::OnLButtonDown(nFlags, point);
}

void CMyStatusBar::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
/*
	UINT nID,nStyle;
	int cxWidth;

	this->GetPaneInfo(0,nID,nStyle,cxWidth);
	if(nStyle == SBPS_NORMAL)
		this->SetPaneInfo(0,nID,SBPS_POPOUT,cxWidth);
	else
		this->SetPaneInfo(0,nID,SBPS_NORMAL,cxWidth);

*/	
	CStatusBar::OnLButtonDblClk(nFlags, point);
}


BOOL CMyStatusBar::MySetIndicators()
{
	int iTem = 1;
	CString strTem;
	BOOL bResult;

	if(m_pView != NULL)
		iTem = m_pView->m_objlstRoomPtr.GetCount() + 1;
	
	if(m_aIndicators.GetSize() != iTem)
	{
		m_aIndicators.RemoveAll();
		for(int i=0; i< iTem; i++)
			//m_aIndicators.Add(ID_INDICATOR_MY);
			m_aIndicators.Add(ID_SEPARATOR);
	}
	if(	SetIndicators(m_aIndicators.GetData(),
		  m_aIndicators.GetSize()) )
	{

		//Get the width:
		int cxWidth;
		int iPaneCount;

		CRect r;
		GetClientRect(&r);
		iPaneCount = m_pView->m_objlstRoomPtr.GetCount() + 1;
		if((r.right-r.left) < iPaneCount * MY_STATUS_PANE_WIDTH)
		{
			cxWidth = (int)((r.right-r.left)/iPaneCount);
		}
		else
			cxWidth = MY_STATUS_PANE_WIDTH;

		//set the first room 'status'
		SetPaneText(0,"Status", TRUE);
		SetPaneInfo(0,0,SBPS_POPOUT,cxWidth);
		if(0 == m_iActive)
			SetPaneInfo(0,0,SBPS_NORMAL,cxWidth);

		CRoom* proomTem;
		for(int i=1; i< iTem; i++)
		{
			proomTem = (CRoom*) m_pView->m_objlstRoomPtr.GetAt(
				m_pView->m_objlstRoomPtr.FindIndex(i-1) );
			strTem = proomTem->m_strRoomName;
		
			SetPaneText(i,strTem, TRUE);
			SetPaneInfo(i,0,SBPS_POPOUT,cxWidth);
			if(i == m_iActive)
				SetPaneInfo(i,0,SBPS_NORMAL,cxWidth);
		}
		bResult = TRUE;
	}
	else
		bResult = FALSE;
	return bResult;

}
/*
void CMyStatusBar::OnPaint() 
{
	//CPaintDC dc(this); // device context for painting

	int iTem;
	CString strTem;

}
*/


