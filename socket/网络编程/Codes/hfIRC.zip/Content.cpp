// Content.cpp : implementation file
//

#include "stdafx.h"
#include "hfIRC.h"
#include "Content.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CContent

CContent::CContent()
{
}

CContent::~CContent()
{
}


BEGIN_MESSAGE_MAP(CContent, CEdit)
	//{{AFX_MSG_MAP(CContent)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CContent message handlers
