#if !defined(AFX_INPUTBAR_H__309D8522_278C_11D2_A8C9_0080C8560A58__INCLUDED_)
#define AFX_INPUTBAR_H__309D8522_278C_11D2_A8C9_0080C8560A58__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CHfIRCView;


// InputBar.h : header file
//


/////////////////////////////////////////////////////////////////////////////
// CInputBar window

class CInputBar : public CEdit
{
// Construction
public:
	CInputBar();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInputBar)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CInputBar();

	//hf_added:
	CHfIRCView* m_pView;
	void MySetView( CHfIRCView* pView );




	// Generated message map functions
protected:
	//{{AFX_MSG(CInputBar)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INPUTBAR_H__309D8522_278C_11D2_A8C9_0080C8560A58__INCLUDED_)
