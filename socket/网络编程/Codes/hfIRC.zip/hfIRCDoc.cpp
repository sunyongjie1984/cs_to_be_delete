// hfIRCDoc.cpp : implementation of the CHfIRCDoc class
//

#include "stdafx.h"
#include "hfIRC.h"

#include "hfIRCDoc.h"
#include "ircclient.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHfIRCDoc

IMPLEMENT_DYNCREATE(CHfIRCDoc, CDocument)

BEGIN_MESSAGE_MAP(CHfIRCDoc, CDocument)
	//{{AFX_MSG_MAP(CHfIRCDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHfIRCDoc construction/destruction

CHfIRCDoc::CHfIRCDoc()
{
	// TODO: add one-time construction code here

}

CHfIRCDoc::~CHfIRCDoc()
{
}

BOOL CHfIRCDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CHfIRCDoc serialization

void CHfIRCDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CHfIRCDoc diagnostics

#ifdef _DEBUG
void CHfIRCDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CHfIRCDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHfIRCDoc commands
