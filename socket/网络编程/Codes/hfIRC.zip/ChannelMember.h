#if !defined(AFX_CHANNELMEMBER_H__309D8523_278C_11D2_A8C9_0080C8560A58__INCLUDED_)
#define AFX_CHANNELMEMBER_H__309D8523_278C_11D2_A8C9_0080C8560A58__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ChannelMember.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CChannelMember window

class CChannelMember : public CEdit
{
// Construction
public:
	CChannelMember();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChannelMember)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CChannelMember();

	// Generated message map functions
protected:
	//{{AFX_MSG(CChannelMember)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHANNELMEMBER_H__309D8523_278C_11D2_A8C9_0080C8560A58__INCLUDED_)
