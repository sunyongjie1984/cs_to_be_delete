#if !defined(AFX_LOGDG_H__F7638262_2726_11D2_A8C9_0080C8560A58__INCLUDED_)
#define AFX_LOGDG_H__F7638262_2726_11D2_A8C9_0080C8560A58__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// LogDg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLogDg dialog

class CLogDg : public CDialog
{
// Construction
public:
	CLogDg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLogDg)
	enum { IDD = IDD_DIALOG1 };
	CString	m_strNickName;
	CString	m_strServerName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLogDg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLogDg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOGDG_H__F7638262_2726_11D2_A8C9_0080C8560A58__INCLUDED_)
