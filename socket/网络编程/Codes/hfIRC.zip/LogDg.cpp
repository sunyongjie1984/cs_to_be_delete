// LogDg.cpp : implementation file
//

#include "stdafx.h"
#include "hfIRC.h"
#include "LogDg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLogDg dialog


CLogDg::CLogDg(CWnd* pParent /*=NULL*/)
	: CDialog(CLogDg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLogDg)
	m_strNickName = _T("");
	m_strServerName = _T("");
	//}}AFX_DATA_INIT
}


void CLogDg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLogDg)
	DDX_Text(pDX, IDC_EDIT1, m_strNickName);
	DDX_Text(pDX, IDC_EDIT2, m_strServerName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLogDg, CDialog)
	//{{AFX_MSG_MAP(CLogDg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLogDg message handlers

