
#include "stdafx.h"
#include "channelmember.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChannelMember

IMPLEMENT_DYNCREATE(CChannelMember, CEdit)

BEGIN_MESSAGE_MAP(CChannelMember, CEdit)
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChannelMember construction/destruction

CChannelMember::CChannelMember()
{
}

CChannelMember::~CChannelMember()
{
}

/////////////////////////////////////////////////////////////////////////////
// CChannelMember Operations


/////////////////////////////////////////////////////////////////////////////
// CChannelMember diagnostics

#ifdef _DEBUG
void CChannelMember::AssertValid() const
{
	CObject::AssertValid();
}

void CChannelMember::Dump(CDumpContext& dc) const
{
	CObject::Dump(dc);
}
#endif //_DEBUG

////////////////////////////////////////////////////////
void CChannelMember::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	CEdit::OnLButtonDown(nFlags, point);
}

