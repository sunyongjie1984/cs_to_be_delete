// InputBar.cpp : implementation file
//

#include "stdafx.h"
#include "hfIRC.h"
#include "InputBar.h"
#include "hfIRCView.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInputBar

CInputBar::CInputBar()
{
}

CInputBar::~CInputBar()
{
}


BEGIN_MESSAGE_MAP(CInputBar, CEdit)
	//{{AFX_MSG_MAP(CInputBar)
	ON_WM_CHAR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInputBar message handlers

void CInputBar::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	int i,iTem;

	if ((nChar != VK_RETURN) || (nRepCnt!=1))
	{
		CEdit::OnChar(nChar, nRepCnt, nFlags);
		return;
	}
	else
	{
		CString strText;
		//CString strCommand;
		
		CHfIRCView* pView = (CHfIRCView*)GetParent();
		ASSERT_VALID(pView);

		if(pView->m_pClient == NULL)
		{
			strText=_T("");
			this->SetWindowText(strText);
			return;
		}

		this->GetWindowText(strText);

		iTem = strText.GetLength();

		//Lstrim:
		for( i=0; i < iTem; i++)
		{
			if(strText[0] == ' ')
			{
				strText = strText.Mid(1,iTem);
			}
			else
				break;
		}


		if( strText[0] == CString(_T('/')) )
		{
			m_pView->m_pClient->ParseInputCommandStr(strText);
		}
		else
		{
			CString strSendToWho;

			//Get now which ROOM is active:
			if(0 == pView->m_wndStatusBar.m_iActive )
			{
				//now the active room is 'Status'

			}
			else
			{
				//find the correspond room
				CRoom* proomTem;
				proomTem = (CRoom*) m_pView->m_objlstRoomPtr.GetAt(
					m_pView->m_objlstRoomPtr.FindIndex(pView->m_wndStatusBar.m_iActive - 1) ); //!! the list 0, (0, 1, 2, ....)
					//m_pView->m_objlstRoomPtr.FindIndex(pView->m_wndStatusBar.m_iActive) );
				strSendToWho = proomTem->m_strRoomName;
				
				//send the message
				pView->m_pClient->DoPrivmsg(strSendToWho,LPCSTR(strText));

				//display the message myself
				proomTem->m_strContent += CString(_T("<"));
				proomTem->m_strContent += pView->m_pClient->m_strMyNickName;
				proomTem->m_strContent += CString(_T(">"));
				proomTem->m_strContent += strText;
				proomTem->m_strContent += CString(_T("\r\n"));
				m_pView->MyUpdateView();


			}
			//pView->m_pClient->DoPrivmsg("#cbkmis",LPCSTR(strText));
			
		}

		//pDoc->SendMsg(strText);

		strText=_T("");
		this->SetWindowText(strText);
	}
//////////////////////	
//	CEdit::OnChar(nChar, nRepCnt, nFlags);
}

void CInputBar::MySetView(CHfIRCView* pView)
{
	m_pView = pView;
}

