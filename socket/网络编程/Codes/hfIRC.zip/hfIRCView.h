// hfIRCView.h : interface of the CHfIRCView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_HFIRCVIEW_H__B6270402_26D7_11D2_A8C9_0080C8560A58__INCLUDED_)
#define AFX_HFIRCVIEW_H__B6270402_26D7_11D2_A8C9_0080C8560A58__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "ircClient.h"
#include "hfIRCDoc.h"

#include "mystatusbar.h"

#include "channelmember.h"
#include "inputbar.h"
#include "content.h"


////////////////////////////////////////////////////////////

class CRoom : public CObject
{
public:
	CString			m_strContent;
	CString			m_strChannelMember;
	//CStringList		m_strlstChannelMember;
	CStringList		m_strlstInput;
	//CInputBar*		m_pwndInputBar;
	//CChannelMember*	m_pwndChannelMember;
	//CContent*		m_pwndContent;
	int				m_iRoomType;
	CString			m_strRoomTopic;
	CString			m_strRoomName;

	CRoom()
	{
		m_strContent =			CString(_T(""));
		//m_strlstChannelMember.RemoveAll();
		m_strlstInput.RemoveAll();
		m_iRoomType = HF_ROOM_TYPE_STATUS;
		//m_pwndInputBar =		NULL;
		//m_pwndChannelMember =	NULL;
		//m_pwndContent =			NULL;
	
	};
	~CRoom(){};


/*	CRoom& CRoom::operator=(const CRoom& roomSrc)
	{
		
		if (this != &roomSrc)
		{
		LPDISPATCH lpTemp = m_lpDispatch;
		m_lpDispatch = dispatchSrc.m_lpDispatch;
		if (m_lpDispatch != NULL)
			m_lpDispatch->AddRef();
		if (lpTemp != NULL && m_bAutoRelease)
			lpTemp->Release();
		m_bAutoRelease = TRUE;
		}
		return *this;
	}
*/

};


/*
class CRoomList : public CObList
{
public:

    void AddHead( CRoom* room )
		{CObList::AddHead( (CObject*)room );}
    void AddTail( CRoom* room )
		{CObList::AddTail( (CObject*)room );}

    CRoom& GetHead()
		{return (CRoom&)CObList::GetHead();}
    //CRoom*& GetRoomHead()
	//	{return (CRoom*&)CObList::GetHead();}
    CRoom*& GetTail()
		{return (CRoom*&)CObList::GetTail();}
    //CRoom*& GetRoomTail()
	//	{return (CRoom*&)CObList::GetTail();}
	
	POSITION Find( CRoom* searchValue, POSITION startAfter = NULL )
		{return CObList::Find( (CObject*)searchValue,startAfter);}

	//CRoom*& GetRoomAt( POSITION position )
	//	{return (CRoom*&)GetAt(position );}
	CRoom& GetAt( POSITION position )
		{return (CRoom&)GetAt(position );}
	void SetAt( POSITION pos, CRoom* newElement )
		{ CObList::SetAt(pos, (CObject*) newElement );}	
};
*/

////////////////////////////////////////////////////////////
class CHfIRCView : public CView
{
protected: // create from serialization only
	CHfIRCView();
	DECLARE_DYNCREATE(CHfIRCView)

// Attributes
public:
	CHfIRCDoc* GetDocument();
	//CScrollBar* m_pscrollBar;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHfIRCView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CHfIRCView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	
	//hf_added:
	CIrcClient*		m_pClient;
	CString			m_strStatusWnd;
	//int				m_iActiveView;

	CRoom			m_roomStatus;
	//CList<CRoom,CRoom&> m_roomlstAll;
	CObList			m_objlstRoomPtr;
/*
	class CPerson : public CObject {...};

CPerson* p1 = new CPerson(...);
CObList myList;

myList.AddHead( p1 );   // No cast needed
CPerson* p2 = ( CPerson* )myList.GetHead();
*/
	
	void Connect();
	void MyMoveWnd();
	void MyUpdateView();


	//hf_added:
	CMyStatusBar	m_wndStatusBar;

	CInputBar		m_wndInputBar;
	CChannelMember	m_wndChannelMember;
	CContent		m_wndContent;
	
protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CHfIRCView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMenuitemConn();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in hfIRCView.cpp
inline CHfIRCDoc* CHfIRCView::GetDocument()
   { return (CHfIRCDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////



//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_HFIRCVIEW_H__B6270402_26D7_11D2_A8C9_0080C8560A58__INCLUDED_)
