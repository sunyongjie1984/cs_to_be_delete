// mfcftp3Dlg.h : ͷ�ļ�
//
#include "afxinet.h"

#pragma once


// Cmfcftp3Dlg �Ի���
class Cmfcftp3Dlg : public CDialog
{
// ����
public:
	Cmfcftp3Dlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_MFCFTP3_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

	

// ʵ��
protected:
	HICON m_hIcon;

	CInternetSession *m_pInetSession;
	CFtpConnection *m_pFtpConnection;
	CString m_ftpinfo;
 	//CFtpFileFind   finder();
   int n;
	
		// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeEdit1();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnDestroy();
    afx_msg void List();


	CString m_host;
	CString m_username;
	CString m_password;
	int m_port;
};
