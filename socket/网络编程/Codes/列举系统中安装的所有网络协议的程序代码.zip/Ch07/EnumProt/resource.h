//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EnumProt.rc
//
#define IDI_ICON                        101
#define IDR_MENU                        102
#define IDD_ABOUT                       103
#define IDB_WINSOCK2                    104
#define IDB_WS2_BITMAP                  105
#define IDB_BITMAP1                     106
#define IDM_ABOUT                       40001
#define IDM_EXIT                        40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
