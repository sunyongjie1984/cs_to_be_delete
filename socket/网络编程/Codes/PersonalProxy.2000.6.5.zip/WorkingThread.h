/*
*	File name:		WorkingThread.h
*	Version:		1.0.0.1
*	Programmer:		A.George
*	Organization:	
*	Date(start):	5.23.2000
*	Date(finish):	
*	Description:
					Working thread header file
*/
#ifndef _WORKING_THREAD_AG_INCLUDED_
#define _WORKING_THREAD_AG_INCLUDED_

#include <winsock.h>

// macros for constant definition
#define AGM_OUTPUT				0x500
#define REQUEST_UNAUTHORIZED	1
#define VIRTUAL_RESOURCE		2
#define PARTIAL_CONTENT			4
#define BUFFER_SIZE				2048

// string constant
#define STRCONTENT	"\
<HTML>\
<HEAD><TITLE>\
Connection limit exceeded\
</TITLE></HEAD>\
<BODY>\
<H1>Connection limit exceeded</H1>\
Please change to another proxy server or wait for decreasing of connections number.<P>\
<ADDRESS>Proxy server at %d.%d.%d.%d:%d ag</ADDRESS>\
</BODY>\
</HTML>\
"

#define STR407 "\
<HTML>\
<HEAD><TITLE>\
Proxy authorization required\
</TITLE></HEAD>\
<BODY>\
<H1>Proxy authorization required</H1>\
Username authentication is required for using this proxy.\
Either your browser does not perform proxy authorization, or your\
authorization has failed.<P>\
<ADDRESS>Proxy server at %d.%d.%d.%d:%d ag</ADDRESS>\
</BODY>\
</HTML>\
"
#define VIRTUAL_MAIN_PAGE "\
<HTML>\
<TITLE>Ag Virtual Home Page</TITLE>\
<BODY BACKGROUND=\"http://www.PersonalProxy.com/image/background.jpg\">\
<FONT COLOR=#00ffff>\
<H1>Personal Proxy</H1> by Ag<br><br>\
This is Virtual Page of site www.PersonalProxy.com<P>\
</BODY>\
</HTML>"


// structures
typedef struct tagTHREADPARAM{
	char pszUrl[512];

	BYTE	b1;
	BYTE	b2;
	BYTE	b3;
	BYTE	b4;
	int		nPort;
	char	pszUser[16];
	char	pszPasswd[16];
}THREADPARAM;

//typedef struct tagLISTENPARAM{
//	int		nPortProxy;
//}LISTENPARAM;

typedef struct tagWORKPARAM{
	SOCKET		sckClient;
	sockaddr_in	addr;
}WORKPARAM;

typedef struct tagHTTPHEADER{
	DWORD dwHttpStatus;
	int nVerMajor;
	int nVerMinor;
	char pszStatus[256];
	char pszType[256];
	char pszLocation[256];
	DWORD dwContSize;
	char * pContBegin;
}HTTPHEADER;

typedef struct tagREQUESTHEADER{
	DWORD dwFlag;

	char*		pszAuthBegin;
	char*		pszAuthEnd;
	char*		pszVirtualRes;
	char		pszUrl[512];
	char		pszUserPass[16];
	char*		pszContBegin;

	DWORD		dwRange;
	DWORD		dwContSize;
}REQUESTHEADER;

typedef struct tagGLOBAL{
	HWND	hWnd;

	BYTE	b1;
	BYTE	b2;
	BYTE	b3;
	BYTE	b4;
	int		nPort2nd;
	char	pszUser[64];
	char	pszPasswd[64];

	BYTE	_b1;
	BYTE	_b2;
	BYTE	_b3;
	BYTE	_b4;
	int		nPort;	// local
}GLOBAL;

// global variables
extern int		g_nConnectionCount;
extern HANDLE	g_hConnectionCount;
extern GLOBAL	globalInfo;
extern unsigned long	g_ulIpRefused[100];
extern int		g_nRefused;

// functions
#define OUTPUT(pszMsg) ::SendMessage(globalInfo.hWnd, AGM_OUTPUT, 0, (LPARAM)(LPCTSTR)(pszMsg))
UINT ListeningThread(LPVOID lpVoid);

#endif  //_WORKING_THREAD_AG_INCLUDED_