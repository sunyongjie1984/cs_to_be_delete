// PersonalProxyDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PersonalProxy.h"
#include "PersonalProxyDlg.h"
#include "winsock.h"
#include "WorkingThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About dumpout.cpp
#include "WorkingThread.h"

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPersonalProxyDlg dialog

CPersonalProxyDlg::CPersonalProxyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPersonalProxyDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPersonalProxyDlg)
	m_strPasswd = _T("263");
	m_nPort = 8080;
	m_nProxyPort = 2000;
	m_strUser = _T("user");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CPersonalProxyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPersonalProxyDlg)
	DDX_Control(pDX, IDC_OUTPUT, m_editOutput);
	DDX_Control(pDX, IDC_IPADDRESS1, m_ip);
	DDX_Text(pDX, IDC_PASSWORD, m_strPasswd);
	DDX_Text(pDX, IDC_PORT, m_nPort);
	DDX_Text(pDX, IDC_PROXY_PORT, m_nProxyPort);
	DDX_Text(pDX, IDC_USER, m_strUser);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPersonalProxyDlg, CDialog)
	//{{AFX_MSG_MAP(CPersonalProxyDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_START_LISTEN, OnStartListen)
	ON_WM_CLOSE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_MESSAGE(AGM_OUTPUT, OnOutput)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPersonalProxyDlg message handlers

BOOL CPersonalProxyDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	WSADATA data;
	int iRet;

	iRet = WSAStartup(MAKEWORD(2,2), &data);
	m_ip.SetAddress(202,198,47,21);

	g_hConnectionCount = CreateSemaphore(NULL, 1, 1, NULL);
	m_dwCount = 0;

	m_pFile = fopen("g:\\ag\\log\\proxy.log", "ab");

	BYTE b1, b2, b3, b4;
	int nRet;
	FILE * pFile = fopen("g:\\ag\\personalproxy\\refuse.txt", "r");
	while(!feof(pFile))
	{
		nRet = fscanf(pFile, "%d.%d.%d.%d", &b1, &b2, &b3, &b4);
		if(nRet!=4)break;
		g_ulIpRefused[g_nRefused] = b4<<24 | b3<<16 | b2<<8 | b1;
		g_nRefused++;
	}

	// HKEY_CURRENT_USER\Software\Max Studio
	HKEY hKey;
	DWORD dwType, dwSize;
	char pszPassword[16];
	dwSize = 16;
	dwType = REG_SZ;
	if(RegCreateKey(HKEY_CURRENT_USER, "Software\\Max Studio\\PersonalProxy", &hKey)==ERROR_SUCCESS)
	{
		if(RegQueryValueEx(hKey, "pszPassword", 0, &dwType, (BYTE*)pszPassword, &dwSize)!=ERROR_SUCCESS)
		{
			m_strPasswd = "66";
		}
		{
			m_strPasswd = (CString)pszPassword;
		}
		RegCloseKey(hKey);
	}

	UpdateData(false);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPersonalProxyDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPersonalProxyDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPersonalProxyDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CPersonalProxyDlg::OnStartListen() 
{
	UpdateData();
	BYTE b1, b2, b3, b4;
	
	m_ip.GetAddress(b1, b2, b3, b4);
	globalInfo.hWnd = GetSafeHwnd();
	globalInfo.nPort = m_nProxyPort;	// local
	globalInfo._b1 = b1;
	globalInfo._b2 = b2;
	globalInfo._b3 = b3;
	globalInfo._b4 = b4;

	strcpy(globalInfo.pszPasswd, m_strPasswd);
	strcpy(globalInfo.pszUser, m_strUser);

	globalInfo.b1 = b1;	// second proxy
	globalInfo.b2 = b2;
	globalInfo.b3 = b3;
	globalInfo.b4 = b4;
	globalInfo.nPort2nd = m_nPort;

	AfxBeginThread(ListeningThread, NULL, THREAD_PRIORITY_BELOW_NORMAL);
}

UINT CPersonalProxyDlg::OnOutput(WPARAM wParam, LPARAM lParam)
{
	char* pszStr = (char*)lParam;
//	m_dwCount += dwCount;
	m_editOutput.ReplaceSel(pszStr);
//	TRACE(pszStr);
	fputs(pszStr, m_pFile);
	fflush(m_pFile);
	return 0;
}

void CPersonalProxyDlg::OnClose() 
{
	CDialog::OnClose();
}

void CPersonalProxyDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// HKEY_CURRENT_USER\Software\Max Studio
	HKEY hKey;
	if(RegCreateKey(HKEY_CURRENT_USER, "Software\\Max Studio\\PersonalProxy", &hKey)==ERROR_SUCCESS)
	{
		RegSetValueEx(hKey, "pszPassword", 0, REG_SZ, (BYTE*)(LPCTSTR)m_strPasswd, m_strPasswd.GetLength());
		RegCloseKey(hKey);
	}
	// TODO: Add your message handler code here
	
}
