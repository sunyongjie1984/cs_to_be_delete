// client1.cpp : Defines the class behaviors for the application.
//*************************************************************
//���ߣ�����
//EMAIL:zmpapaya@hotmail.com;papaya_zm@sina.com
//��ҳ��http://h2osky.126.com
/********************************************************/
#include "stdafx.h"
#include "client1.h"
#include "linkctrl.h"
#include "MainFrm.h"
#include "client1Doc.h"
#include "client1View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClient1App

BEGIN_MESSAGE_MAP(CClient1App, CWinApp)
	//{{AFX_MSG_MAP(CClient1App)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClient1App construction

CClient1App::CClient1App()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CClient1App object

CClient1App theApp;
//��ɽ���
DWORD WINAPI notify(LPVOID lpparam)
{
  CMainFrame*  pthis=(CMainFrame	*)lpparam;
	
	return pthis->finish();
}
DWORD WINAPI timethread(LPVOID lpparam)
{
	//��¼����
  cdownload*  pthis=(cdownload	*)lpparam;
	
	return pthis->finish1();
}

int readn(SOCKET fd,char *bp,int len)
{
	//��
	int cnt;
	int rc;
	cnt=len;
	while(cnt>0)
	{
		rc=recv(fd,bp,cnt,0);
		if(rc<0){

	 CString aaa;
aaa="���մ���\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	aaa.ReleaseBuffer();
	
return -1;
  //return 0;
		}
		if(rc==0)return len-cnt;
	bp+=rc;
	cnt-=rc;


	}
	return len;
}
int sendn(SOCKET fd,char *bp,int len)
{
 //д
	int cnt;
	int rc;
	cnt=len;
	while(cnt>0)
	{
		rc=send(fd,bp,cnt,0);

	if(rc<0){

 CString aaa;
aaa="���ʹ���\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	aaa.ReleaseBuffer();
	
 return -1;
		}
		if(rc==0)return len-cnt;
	//	AfxMessageBox("send error");
	bp+=rc;
	cnt-=rc;


	}
	return len;
}
CString ip;
//char name1[10][255];
//���ؽ���
DWORD WINAPI downthread(LPVOID lpparam)
{
	cdownload* pthis=(cdownload*)lpparam;
	InterlockedIncrement(&pthis->m_index);
	pthis->threadfunc(pthis->m_index-1);
	return 1;
}
 
int filedono[10];
filesendinfo zmfile[10];
 

BOOL CClient1App::InitInstance()
{
	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

	// Initialize OLE libraries
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CClient1Doc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CClient1View));
	pDocTemplate->SetContainerInfo(IDR_CNTR_INPLACE);
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The one and only window has been initialized, so show and update it.
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->CenterWindow();
	m_pMainWnd->SetWindowText("��ʥ(���԰�) 1.0----�ͻ���δ����");
	m_pMainWnd->UpdateWindow();
	
    
	//pList.RemoveAll();
	WORD wVersionRequested;
    WSADATA wsaData;
   // char name[255];
    //PHOSTENT hostinfo;
    wVersionRequested = MAKEWORD( 2, 0 );

    if ( WSAStartup( wVersionRequested, &wsaData ) == 0 )
    {
       
            
         WSACleanup( );
     } 
	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
	CLinkCtrl	m_mail;
	CLinkCtrl	m_http;
// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX); 
	virtual BOOL OnInitDialog();
	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MAIL, m_mail);
	DDX_Control(pDX, IDC_HTTP, m_http);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_mail.SetLinkString("mailto:zmpapaya@hotmail.com");
	m_http.SetLinkString("http://h2osky.126.com");
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
// App command to run the dialog
void CClient1App::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CClient1App message handlers

