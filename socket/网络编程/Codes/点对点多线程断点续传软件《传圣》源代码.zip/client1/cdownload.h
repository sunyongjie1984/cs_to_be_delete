// cdownload.h: interface for the cdownload class.
//
//////////////////////////////////////////////////////////////////////
//#include "MainFrm.h"
//*************************************************************
//���ߣ�����
//EMAIL:zmpapaya@hotmail.com;papaya_zm@sina.com
//��ҳ��http://h2osky.126.com
/********************************************************/
#if !defined(AFX_CDOWNLOAD_H__9D039885_5200_4E69_A6DF_13A277F53A04__INCLUDED_)
#define AFX_CDOWNLOAD_H__9D039885_5200_4E69_A6DF_13A277F53A04__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
int readn(SOCKET fd,char *bp,int len);
//extern int totle;
//extern long filelen;
extern char name1[10][255];
//extern int size;
//extern int black;
//extern struct downinfo;
int sendn(SOCKET fd,char *bp,int len);
struct fileinfo
{
	//�ļ���Ϣ
    int fileno;
	int type;
long len;
	int seek;
char name[100];
};
struct downinfo
{
	//������Ϣ
	int totle;
    int black;
	int filelen;
int threadno;
CString name;
};

//extern CString name;
extern	CString ip;
DWORD WINAPI timethread(LPVOID lpparam);
class cdownload  
{
public:

//	int size;
	void createthread();
	DWORD finish1();
int sendlist();
	downinfo doinfo;
int startask(int n);
long m_index;
BOOL good[BLACK];
	int  filerange[100];
	CString fname;
	CString fnametwo;
//	CString fnametwo1;
//	CString name;
//	int downno;
	UINT threadfunc(long index);

	int sendrequest(int n);
	cdownload(int thno1);
	virtual ~cdownload();

};

#endif // !defined(AFX_CDOWNLOAD_H__9D039885_5200_4E69_A6DF_13A277F53A04__INCLUDED_)
