// cdownload.cpp: implementation of the cdownload class.
//
//////////////////////////////////////////////////////////////////////
//*************************************************************
//���ߣ�����
//EMAIL:zmpapaya@hotmail.com;papaya_zm@sina.com
//��ҳ��http://h2osky.126.com
/********************************************************/
#include "stdafx.h"
#include "client1.h"
#include "cdownload.h"
#include "MainFrm.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

cdownload::cdownload(int thno1)
{
fname="zm.zip";
m_index=0;

doinfo.totle=0;
doinfo.threadno=thno1;
}

cdownload::~cdownload()
{

}


int cdownload::sendrequest(int n)
{
	//��ȡ��������Ϣ
	sockaddr_in local;
	SOCKET m_socket;

	int rc=0;
 
	local.sin_family=AF_INET;
	local.sin_port=htons(1028);
	local.sin_addr.S_un.S_addr=inet_addr(ip);
	m_socket=socket(AF_INET,SOCK_STREAM,0);
 
int ret;
ret=connect(m_socket,(LPSOCKADDR)&local,sizeof(local));
if(ret<0){
	AfxMessageBox("���Ӵ���");
closesocket(m_socket);
return -1;
}
fileinfo fileinfo1;
	fileinfo1.len=n;
	fileinfo1.seek=50;
	fileinfo1.type=1;
 
	int aa=sendn(m_socket,(char*)&fileinfo1,100);
	if(aa<0){	closesocket(m_socket);
	return -1;}
 aa=readn(m_socket,(char*)&fileinfo1,100);
	if(aa<0)	{closesocket(m_socket);
	return -1;}
shutdown(m_socket,2);
closesocket(m_socket);
 
return 1;
}

UINT cdownload::threadfunc(long index)
{
	//���ؽ���
	sockaddr_in local;
	SOCKET m_socket;

	int rc=0;
 
	local.sin_family=AF_INET;
	local.sin_port=htons(1028);
	local.sin_addr.S_un.S_addr=inet_addr(ip);
	m_socket=socket(AF_INET,SOCK_STREAM,0);
 
int ret;
	char* m_buf=new char[SIZE];
		int re,len2;
		fileinfo fileinfo1;
ret=connect(m_socket,(LPSOCKADDR)&local,sizeof(local));
fileinfo1.len=filerange[index*2+1];
	fileinfo1.seek=filerange[index*2];
	fileinfo1.type=2;
	fileinfo1.fileno=doinfo.threadno;
 
	re=fileinfo1.len;
 
CFile destFile;
FILE* fp=NULL;
if((fp=fopen(fname,"r"))==NULL)

destFile.Open(fname, CFile::modeCreate|CFile::modeWrite | CFile::typeBinary|CFile::shareDenyNone);

else
destFile.Open(fname,CFile::modeWrite | CFile::typeBinary|CFile::shareDenyNone);
destFile.Seek(filerange[index*2],CFile::begin);
sendn(m_socket,(char*)&fileinfo1,100);

CFile myfile;
 
	CString m_temp;
 
	CString temp;
temp.Format(".down%d",index);
	m_temp=fname+temp;

 
	myfile.Open(m_temp,CFile::modeWrite | CFile::typeBinary|CFile::shareDenyNone);
 
	while(re>0){
 

len2=re>SIZE?SIZE:re;
 
 int len1=readn(m_socket,m_buf,len2);
 if(len1<0){
	 closesocket(m_socket);
	 break;
 }
 

destFile.Write(m_buf, len1);	




filerange[index*2+1]-=len1;
filerange[index*2]+=len1;
myfile.Seek(0,CFile::begin);

	myfile.Write(&filerange[index*2],sizeof(int));
	myfile.Write(&filerange[index*2+1],sizeof(int));

 
		

re=re-len1;

 
 doinfo.totle=doinfo.totle+len1;
 

};
 
myfile.Close();
destFile.Close();
delete [] m_buf;
shutdown(m_socket,2);
 
if(re<=0)good[index]=TRUE;
return 1;
}

int cdownload::startask(int n)
{
//��ʼ�����ļ�
 
doinfo.filelen=zmfile[n].length;
 
fname=zmfile[n].name;
CString tmep;
 
	
 
tmep.Format("\\temp\\%s",fname);


 
 
CString aaa;
	
	aaa="���ڶ�ȡ "+fname+" ��Ϣ�����Ͽ�ʼ���ء�����\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	aaa.ReleaseBuffer();
 
	if(doinfo.filelen<=0)return -1;
	CString m_temp;
	m_temp=fname+".dwon";
	
	doinfo.name=m_temp;
	FILE* fp=NULL;
	CFile myfile;
	if((fp=fopen(m_temp,"r"))==NULL){
 

	filerange[0]=0;
	for(int i=0;i<BLACK;i++)
	{
		if(i>0)
filerange[i*2]=i*(doinfo.filelen/BLACK+1);
 
filerange[i*2+1]=doinfo.filelen/BLACK+1;
 
	}
	filerange[BLACK*2-1]=doinfo.filelen-filerange[BLACK*2-2];

	myfile.Open(m_temp,CFile::modeCreate|CFile::modeWrite | CFile::typeBinary);

 
myfile.Write(&doinfo.filelen,sizeof(int));
myfile.Close();
 
	CString temp;
	for(int ii=0;ii<BLACK;ii++){

temp.Format(".down%d",ii);
	m_temp=fname+temp;
	myfile.Open(m_temp,CFile::modeCreate|CFile::modeWrite | CFile::typeBinary);
	myfile.Write(&filerange[ii*2],sizeof(int));
	myfile.Write(&filerange[ii*2+1],sizeof(int));
		myfile.Close();
	CString temp;
temp.Format("the seek is %d,the len is %d",filerange[ii*2],filerange[ii*2+1]);
 
	}
((CMainFrame*)::AfxGetMainWnd())->m_work.m_ListCtrl->AddItemtwo(n,2,0,0,0,doinfo.threadno);

	
	}
	else
	{
 

fread(&doinfo.filelen,sizeof(int),1,fp);

fclose(fp);

	CString temp;
 
	m_temp=fname+".down0";
	if((fp=fopen(m_temp,"r"))==NULL)
	
		return 1;
	else fclose(fp);
int bb;
bb=0;
for(int ii=0;ii<BLACK;ii++)
{
	temp.Format(".down%d",ii);
	m_temp=fname+temp;
 
	myfile.Open(m_temp,CFile::modeRead | CFile::typeBinary);
	myfile.Read(&filerange[ii*2],sizeof(int));
	myfile.Read(&filerange[ii*2+1],sizeof(int));
		myfile.Close();
 

		bb=	bb+filerange[ii*2+1];
	CString temp;
temp.Format(" aa the seek is %d,the len is %d",filerange[ii*2],filerange[ii*2+1]);
 


}
if(bb==0)return 1;
doinfo.totle=doinfo.filelen-bb;
 
temp.Format("the value is %d,totle is %d,filelen is %d",BLACK,doinfo.totle,doinfo.filelen);
 


temp.Format("the totle is %d,filelen is %d",doinfo.totle,doinfo.filelen);
 

((CMainFrame*)::AfxGetMainWnd())->m_work.m_ListCtrl->AddItemtwo(n,2,doinfo.totle,1,0,doinfo.threadno);

	}

 
 DWORD dwthread;
	::CreateThread(NULL,0,timethread,(LPVOID)this,0,&dwthread);

	return 0;
}

int cdownload::sendlist()
{
	//����LIST����
	sockaddr_in local;
	SOCKET m_socket;

	int rc=0;
 
	local.sin_family=AF_INET;
	local.sin_port=htons(1028);
	local.sin_addr.S_un.S_addr=inet_addr(ip);
	m_socket=socket(AF_INET,SOCK_STREAM,0);

 
int ret;

ret=connect(m_socket,(LPSOCKADDR)&local,sizeof(local));
if(ret<0)
{
CString aaa;
 
	aaa="�������Ӳ��ϣ�\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	aaa.ReleaseBuffer();
 
closesocket(m_socket);
return -1;
}
fileinfo fileinfo1;
	fileinfo1.len=100;
	fileinfo1.seek=50;
	fileinfo1.type=0;
 
	sendn(m_socket,(char*)&fileinfo1,100);
 
readn(m_socket,(char*)zmfile,1080);
 
shutdown(m_socket,2);
closesocket(m_socket);
 
if(strcmp(zmfile[0].name,"none")==0){
 
	CString aaa;
		aaa="������û���ļ������أ�\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	aaa.ReleaseBuffer();
		return -2;
}
::SendMessage(::AfxGetApp()->m_pMainWnd->m_hWnd,CLT_ON,(WPARAM)&zmfile,0);
return 1;
}

DWORD cdownload::finish1()
{
	//��ɿ۵Ĵ���
	int pos,pos1;
	int now;
	int totle1;
	totle1=doinfo.totle;
	char* posbye;
	posbye=new char[100];
	CString posname;
	BOOL aaa;
	aaa=0;
		pos1=0;
while(1)
{
	if(aaa==0){

		now=GetTickCount();
		aaa=1;}
	if(GetTickCount()-now>1000)
	{
totle1=doinfo.totle-totle1;
posname.Format("%d k/s",totle1/1000);
strcpy(&posbye[20],posname.GetBuffer(0));
totle1=doinfo.totle;

 pos=doinfo.totle/(doinfo.filelen/100);
 if(pos>pos1)
 {
posname.Format("%d k",doinfo.totle/1000);
strcpy(posbye,posname.GetBuffer(0));
posname="|";
while(pos>0)
{
posname=posname+'|';
pos-=2;
}
 }
 else
 {
	 posname="zm";
 }
pos1=pos;
strcpy(&posbye[40],posname.GetBuffer(0));

AfxGetMainWnd()->SendMessage(CLT_ONSETWO,(WPARAM)&doinfo.threadno,(LPARAM)posbye);
	if(doinfo.totle>=doinfo.filelen)return 1;
		//AfxMessageBox("aaa");
		aaa=0;

	}


}

	return 1;
}



void cdownload::createthread()
{
	
}
