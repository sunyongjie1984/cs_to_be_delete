// MainFrm.cpp : implementation of the CMainFrame class
//
//*************************************************************
//���ߣ�����
//EMAIL:zmpapaya@hotmail.com;papaya_zm@sina.com
//��ҳ��http://h2osky.126.com
/********************************************************/
#include "stdafx.h"
#include "client1.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
//extern afx_msg LRESULT ontwo(WPARAM wParam,LPARAM lParam);
/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
ON_WM_CREATE()
ON_MESSAGE(CLT_ON,on)
ON_MESSAGE(CLT_ONSETWO,OnSetwo)
ON_MESSAGE(CLT_ONSE,OnClient)
ON_MESSAGE(AA,Onright)
ON_MESSAGE(BB,Onclick)
//	ON_WM_ACTIVATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
for(int i=0;i<10;i++)down[i]=NULL;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{

	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

//if(!m_ip1.Create(WS_CHILD|WS_VISIBLE|WS_TABSTOP,rect,&m_wndToolBar,ID_IP))
//return -1;
if (!m_wndOnline.Create(this, IDD_DIALOG1, WS_CHILD | WS_VISIBLE | CBRS_TOP
 | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC,IDD_DIALOG1))
	{
		TRACE0("Failed to create Dialog bar\n");
		return -1;      // fail to create
	}
if (!m_work.Create(this, IDD_DIALOG3, WS_CHILD | WS_VISIBLE | CBRS_TOP
 | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC,IDD_DIALOG3))
	{
		TRACE0("Failed to create Dialog bar\n");
		return -1;      // fail to create
	}

	if (!m_wndSend.Create(this, IDD_DIALOG4, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC,IDD_DIALOG4))
	{
		TRACE0("Failed to create Dialog bar\n");
		return -1;      // fail to create
	}
int i,j;

	static struct
	{
		LPSTR psztext;
		int ui;
	}columns[]={
		_T("�ļ���"),LVCFMT_LEFT,
_T("��С"),LVCFMT_CENTER,
_T("ʱ��"),LVCFMT_CENTER,
	};
	for( i=0,j=260;i<sizeof(columns)/sizeof(columns[0])-1;i++,j-=10)
		m_wndOnline.m_ListCtrl->InsertColumn(i,columns[i].psztext,columns[i].ui,j);
	m_wndOnline.m_ListCtrl->SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
	m_wndOnline.	m_ListCtrl->ModifyStyleEx(0, WS_EX_CLIENTEDGE);
	static struct
	{
		LPSTR psztext;
		int ui;
	}columns1[]={
		_T("�����ļ�"),LVCFMT_LEFT,
_T("|0%                          | 50%                       | 100%"),LVCFMT_LEFT,
_T("���� k/s"),LVCFMT_CENTER,
_T("������/k"),LVCFMT_LEFT,
_T("״̬"),LVCFMT_CENTER,
	};
	for( i=0,j=254;i<sizeof(columns1)/sizeof(columns1[0]);i++,j-=5)
	{
		if(i>1)		m_work.m_ListCtrl->InsertColumn(i,columns1[i].psztext,columns1[i].ui,80);
else
		m_work.m_ListCtrl->InsertColumn(i,columns1[i].psztext,columns1[i].ui,j);
	}
	m_work.	m_ListCtrl->ModifyStyleEx(0, WS_EX_CLIENTEDGE);
	
/*if (!m_ipbar.Create(this, IDD_DIALOG2, WS_CHILD | WS_VISIBLE | CBRS_TOP
,IDD_ABOUTBOX))
	{
		TRACE0("Failed to create Dialog bar\n");
		return -1;      // fail to create
	}
*/
	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable


	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
//m_ipbar.EnableDocking(CBRS_ALIGN_TOP);
//	DockControlBar(&m_ipbar, AFX_IDW_DOCKBAR_TOP);
//	m_wndOnline.SetWindowText(_TEXT("�����б�"));
m_wndOnline.EnableDocking(CBRS_ALIGN_TOP);
	DockControlBar(&m_wndOnline, AFX_IDW_DOCKBAR_TOP);
	m_wndOnline.SetWindowText(_TEXT("�����б�"));
	m_work.EnableDocking(CBRS_ALIGN_TOP);
	DockControlBar(&m_work, AFX_IDW_DOCKBAR_TOP);
	m_wndOnline.SetWindowText(_TEXT("�����б�"));
#define PU 3
m_wndToolBar.SetButtonInfo(PU,ID_IP,TBBS_SEPARATOR,160);
CRect rect=NULL;
rect.left+=6;
rect.bottom-=6;rect.right+=6;rect.top-=6;
m_wndToolBar.GetItemRect(PU,&rect);
if(!m_ip1.Create(WS_CHILD|WS_VISIBLE|WS_TABSTOP,rect,&m_wndToolBar,ID_IP))
return -1;
//m_ip1.SetWindowText("10.1.40.23"	);
	m_wndSend.EnableDocking(CBRS_ALIGN_BOTTOM);
	DockControlBar(&m_wndSend, AFX_IDW_DOCKBAR_BOTTOM);
	m_wndSend.SetWindowText(_TEXT("���ʹ���"));
ShowControlBar(&m_wndSend,TRUE,TRUE);
//((CButton*)	m_wndSend.GetDlgItem(IDC_SEND))->;
//	ShowWindow(SW_SHOWMAXIMIZED);

	return 0;
}
LRESULT CMainFrame::OnSetwo(WPARAM wParam, LPARAM lParam)
{
	//���½���
 
	char* dat2;
	int * dat;
 
dat=(int *)wParam;
dat2=(char*)lParam;
int noth;
noth=*dat;
 

m_work.m_ListCtrl->SetItemText(filedono[noth],3,dat2);
m_work.m_ListCtrl->SetItemText(filedono[noth],2,&dat2[20]);
if(strcmp(&dat2[40],"zm"))m_work.m_ListCtrl->SetItemText(filedono[noth],1,&dat2[40]);
 
	return 1;
}
LRESULT CMainFrame::on(WPARAM wParam,LPARAM lParam)
{
	//��ʾ�ļ�
	m_wndOnline.m_ListCtrl->DeleteAllItems();
	int i;
	i=0;
	while(strcmp(zmfile[i].name,"none"))
	{
 
	m_wndOnline.m_ListCtrl->AddItem(&zmfile[i]);
 
		i++;
	}

	return 1;
}
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	//cs.style = WS_OVERLAPPED | WS_CAPTION | FWS_ADDTOTITLE
	//	| WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_MAXIMIZE;
//cs.style &= ~WS_MAXIMIZEBOX;
//	cs.style &= ~WS_SIZEBOX;
cs.cx=GetSystemMetrics(SM_CXSCREEN);
cs.cy=GetSystemMetrics(SM_CYSCREEN);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}
 
void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


DWORD CMainFrame::finish()
{
//��ɺ�Ĵ���
	int thno;
	thno=clno;
CString aaa;
 
	aaa=zmfile[thno].name;
		aaa=aaa+"���ļ������������ء�������\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	aaa.ReleaseBuffer();

	now=GetTickCount();

HRESULT ret=WaitForMultipleObjects(BLACK,m_thread[thno],TRUE,INFINITE);
int i;
i=0;
for(int j=0;j<BLACK;j++)i+=down[thno]->good[j];

down[thno]=NULL;
			
end=GetTickCount();
 
if(i==BLACK){
	aaa=zmfile[thno].name;
		aaa=aaa+"���ļ�������ϣ�\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	aaa.ReleaseBuffer();
CString temp;
m_work.m_ListCtrl->SetItemText(filedono[thno],1,"|||||||||||||||||||||||||||||||||||||||||||||||||||");
 
m_work.m_ListCtrl->SetItemText(filedono[thno],4,"�����");


temp.Format("�ļ�������ϣ���ʱ  %d  ��\n",((end-now)/1000));
temp=zmfile[thno].name+temp;
AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)temp.GetBuffer(0),1);
 
temp.ReleaseBuffer();
 	
	for(j=0;j<BLACK;j++)
{
	CString bbb;
	bbb.Format("%s.down%d",zmfile[thno].name,j);
	DeleteFile(bbb.GetBuffer(0));
	bbb.ReleaseBuffer();
}
}




	return 1;
}

void CMainFrame::createthread(int threadno)
{
	DWORD dwthread;
	for(int i=0;i<BLACK;i++)
	{
	m_thread[threadno][i]=	::CreateThread(NULL,0,downthread,(LPVOID)down[threadno],0,&dwthread);
//	((CWinThread*)m_thread[threadno][i])->SetThreadPriority(THREAD_PRIORITY_HIGHEST);
	::SetThreadPriority(m_thread[threadno][i],THREAD_PRIORITY_HIGHEST);
//Sleep(300);
	}


::CreateThread(NULL,0,notify,(LPVOID)this,0,&dwthread);
}

int CMainFrame::OnClient(WPARAM wParam,LPARAM lParam) 
{
 
//�����ļ�
CString str;
int jj;
jj=0;
	for(int i = 0; i <m_work.m_ListCtrl-> GetItemCount(); i++){
		str =m_work.m_ListCtrl->GetItemText(i,4 );
		if(strcmp(str, "������") == 0){
			jj++;
			
		}
	}

if(jj>2)
{AfxMessageBox("���ͬʱֻ������3���ļ���");
return 0;
}
	now=GetTickCount();
	//	UpdateData(TRUE);
		CString temp1;
int type;
//	int alldone;
	
//ip=temp1;

//black=this->m_black;
	int* dat;
dat=(int *)lParam;
CString temp;
int noth;
noth=*dat;
//temp.Format("the cleek is %d",noth);
//threadno=noth;
//	AfxMessageBox(temp);
clno=noth;

if(down[clno]!=NULL){
	AfxMessageBox("�������ػ��������꣡");
return 0;

}
CString aaa;
	
	aaa.Format("���ڳ�ʹ�� %s",zmfile[clno].name);
		aaa=aaa+" ��Ϣ������\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	aaa.ReleaseBuffer();
//	Sleep(300);
down[clno]=new cdownload(clno);

type=down[clno]->startask(clno);

if(type==1)
{
	AfxMessageBox("�������ػ��������꣡");
return 0;
}
 if(type==-1)
{
	AfxMessageBox("���ļ�����Ϊ��򲻿ɶ���");
return 0;
}
 if(type==-2)
 {
	 AfxMessageBox("���������ϣ�");
	 return 0;
 }

createthread(clno);
	return 1;
	// TODO: Add your message handler code here
	
}
int CMainFrame::Onright(WPARAM wParam,LPARAM lParam) 
{
 //��ʼ����
CString str;
int jj;
jj=0;
	for(int i = 0; i <m_work.m_ListCtrl-> GetItemCount(); i++){
		str =m_work.m_ListCtrl->GetItemText(i,4 );
		if(strcmp(str, "������") == 0){
			jj++;
			
		}
	}

if(jj>2)
{AfxMessageBox("���ͬʱֻ������3���ļ���");
return 0;
}
	now=GetTickCount();
 
		CString temp1;
 
	int* dat;
dat=(int *)lParam;
CString temp;
int noth;
noth=*dat;
temp.Format("the cleek is %d",noth);
 
//	AfxMessageBox(temp);
clno=noth;

if(down[clno]==NULL){
	AfxMessageBox("no");
return 0;
}
for( i=0;i<BLACK;i++)
::ResumeThread(m_thread[clno][i]);
 
	return 1;
	// TODO: Add your message handler code here
	
}
int CMainFrame::Onclick(WPARAM wParam,LPARAM lParam) 
{
//ͣ����
CString str;
int jj;
jj=0;
	for(int i = 0; i <m_work.m_ListCtrl-> GetItemCount(); i++){
		str =m_work.m_ListCtrl->GetItemText(i,4 );
		if(strcmp(str, "������") == 0){
			jj++;
			
		}
	}

if(jj>2)
{AfxMessageBox("���ͬʱֻ������3���ļ���");
return 0;
}
	now=GetTickCount();
 
		CString temp1;
 
	int* dat;
dat=(int *)lParam;
CString temp;
int noth;
noth=*dat;
temp.Format("the cleek is %d",noth);
 
//	AfxMessageBox(temp);
clno=noth;

if(down[clno]==NULL){
	AfxMessageBox("no");
return 0;
}
for( i=0;i<BLACK;i++)
::SuspendThread(m_thread[clno][i]);
 
	return 1;
 
 
}
