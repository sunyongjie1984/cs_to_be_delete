#if !defined(AFX_CHARBAR_H__1C4960F0_8CC5_41D8_B2DA_0A049080F862__INCLUDED_)
#define AFX_CHARBAR_H__1C4960F0_8CC5_41D8_B2DA_0A049080F862__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// charbar.h : header file
/*****************************************************************

//���ߣ�����
//EMAIL:zmpapaya@hotmail.com;papaya_zm@sina.com

/****************************************************************/
/////////////////////////////////////////////////////////////////////////////
// charbar window

class charbar : public CDialogBar
{
// Construction
public:
	charbar();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(charbar)
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~charbar();

	// Generated message map functions
protected:
	//{{AFX_MSG(charbar)

		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHARBAR_H__1C4960F0_8CC5_41D8_B2DA_0A049080F862__INCLUDED_)
