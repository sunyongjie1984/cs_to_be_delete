// server1View.cpp : implementation of the CServer1View class
//
/*********************************************************************
//���ߣ�����
//EMAIL:zmpapaya@hotmail.com;papaya_zm@sina.com
��ҳ��http://h2osky.126.com
*********************************************************************/
#include "stdafx.h"
#include "server1.h"
//#include "OnlineList.h"
#include "server1Doc.h"
#include "CntrItem.h"
#include "server1View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServer1View

IMPLEMENT_DYNCREATE(CServer1View, CRichEditView)

BEGIN_MESSAGE_MAP(CServer1View, CRichEditView)
	//{{AFX_MSG_MAP(CServer1View)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	ON_WM_DESTROY()
ON_COMMAND(ID_STAR, OnServerStart)
ON_COMMAND(ID_ADD, addfile)
	ON_MESSAGE(WM_AGE1, addmessage)
ON_COMMAND(IDC_SEND, OnSend)
	ON_MESSAGE(WM_KSEND,OnKSend)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServer1View construction/destruction
LRESULT CServer1View::OnKSend(WPARAM wParam,LPARAM lParam)
{
	OnSend();
	return 0;
}
void CServer1View::OnSend() 
{//����Ϣ
     CMainFrame* pWnd=(CMainFrame*)AfxGetMainWnd();
	CEdit* pEdit=(CEdit*)pWnd->m_sendbar.GetDlgItem(IDC_EDIT1);
	CString temp;
	pEdit->GetWindowText(temp);
	if(temp.IsEmpty())
	{
		MessageBox("���ܷ��Ϳ���Ϣ!!!","����");
		pEdit->SetFocus();
		return;
	}
	
if(!m_chat)
{
	MessageBox("û�пͻ����룡����","����");
		pEdit->SetFocus();
		return;
}
		temp="�����: "+temp;
		temp=temp+"\n";
Message((LPCTSTR)temp,RGB(255,0,0));
chatsocket->Send(temp.GetBuffer(0),255);

temp.ReleaseBuffer();
pWnd->m_sendbar.GetDlgItem(IDC_EDIT1)->SetFocus();
	pEdit->SetWindowText("");
}
CServer1View::CServer1View()
{
	m_chat=FALSE;
	m_start=TRUE;
	// TODO: add construction code here
strcpy(zmfile[0].name,"none");
count=0;
}
//��ʾ��Ϣ
LRESULT CServer1View::addmessage(WPARAM wParam, LPARAM lParam)
{
//	MessageBox("aaa");
	LPCTSTR pStr = (LPCTSTR)wParam;

Message(pStr,RGB(0,0,0));
return 1;
}
CServer1View::~CServer1View()
{
}

BOOL CServer1View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRichEditView::PreCreateWindow(cs);
}

void CServer1View::OnInitialUpdate()
{
	CRichEditView::OnInitialUpdate();
	cfm.cbSize=sizeof(cfm);
	cfm.bCharSet=GB2312_CHARSET;
	cfm.crTextColor=RGB(0,0,0);
	cfm.dwMask=CFM_CHARSET | CFM_COLOR ;
	cfm.dwEffects=0;
	GetRichEditCtrl().SetDefaultCharFormat(cfm);
 
	SetMargins(CRect(720, 720, 720, 720));
}

void CServer1View::OnDestroy()
{
	// Deactivate the item on destruction; this is important
	// when a splitter view is being used.
   CRichEditView::OnDestroy();
  COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
   if (pActiveItem != NULL && pActiveItem->GetActiveView() == this)
   {
      pActiveItem->Deactivate();
      ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
   }
   
}


/////////////////////////////////////////////////////////////////////////////
// CServer1View diagnostics

#ifdef _DEBUG
void CServer1View::AssertValid() const
{
	CRichEditView::AssertValid();
}

void CServer1View::Dump(CDumpContext& dc) const
{
	CRichEditView::Dump(dc);
}
CServer1Doc* CServer1View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CServer1Doc)));
	return (CServer1Doc*)m_pDocument;
}
#endif //_DEBUG
void CServer1View::Message(LPCTSTR lpszMessage,COLORREF clr)
{
	//�ڴ�������ʾ������Ϣ
	cfm.cbSize=sizeof(cfm);
	cfm.crTextColor=clr;
	cfm.dwMask=CFM_COLOR;
	CString strTemp = lpszMessage;
	
	int len = GetWindowTextLength();
	GetRichEditCtrl().SetSel(len,len);
	
	GetRichEditCtrl().SetSelectionCharFormat(cfm);
	GetRichEditCtrl().ReplaceSel(strTemp);
}
BOOL  CServer1View::PreTranslateMessage(MSG* pMsg) 
{

if (pMsg->message==WM_KEYDOWN && pMsg->wParam==VK_RETURN)
	
		if(GetFocus()->GetDlgCtrlID()==IDC_SEND ||GetFocus()->GetDlgCtrlID()==IDC_EDIT1)
		{
		//	AfxGetMainWnd()->SendMessageToDescendants(WM_KSEND);
			AfxMessageBox("down");
			return TRUE;
			}
	   
	return CRichEditView::PreTranslateMessage(pMsg);
}
//���ļ�����������
int CServer1View::addfile()
{
	if(((CMainFrame*)::AfxGetMainWnd())->m_wndOnline.m_ListCtrl->GetItemCount()>8){
		AfxMessageBox("ͬʱ���ֻ֧��9���ļ�");
return 0;		
	}

CFileDialog cfiledlg(TRUE,NULL,NULL);
	 cfiledlg.DoModal();
	 
	 fnamepath=cfiledlg.GetPathName();
 
	 CFile myFile;
myFile.Open(fnamepath, CFile::modeRead | CFile::typeBinary|CFile::shareDenyNone); 
zmfile[count].length=myFile.GetLength();
 myFile.Close();
 
 
 for(int j=0;j<((CMainFrame*)::AfxGetMainWnd())->m_wndOnline.m_ListCtrl->GetItemCount();j++)
 {
if(nameph[j]==fnamepath)break;
 }
 if((j+1)<=((CMainFrame*)::AfxGetMainWnd())->m_wndOnline.m_ListCtrl->GetItemCount()){
 AfxMessageBox("�ļ�ͬ�������ɼ��룡");
return 0;
 }
 if(zmfile[count].length<=0){
	 AfxMessageBox("�ļ���СΪ�㣬���ɼ��룡");
return 0;
 }

 if(m_start){
	listensocket=new mysocket(this);
	 listensocket->Create(8888);
 listensocket->Listen();
 CMainFrame* pWnd=(CMainFrame*)AfxGetMainWnd();
	CServer1App* pApp=(CServer1App*)AfxGetApp();
		DWORD dwthread;
	sockaddr_in local;
	SOCKET m_socket;

	int rc=0;
	//char buf[1];
	local.sin_family=AF_INET;
	local.sin_port=htons(1028);
	local.sin_addr.S_un.S_addr=INADDR_ANY;
	m_socket=socket(AF_INET,SOCK_STREAM,0);

		rc=bind(m_socket,(LPSOCKADDR)&local,sizeof(local));
		if(rc==SOCKET_ERROR){
	CString aaa;
	aaa="Bind����\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	aaa.ReleaseBuffer();
	//return 0;
//	break;
		}
	::CreateThread(NULL,0,listenthread,(LPVOID)m_socket,0,&dwthread);
	CString aaa;
	aaa="������������\n";
    //AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	Message(aaa.GetBuffer(0),RGB(0,0,0));
	aaa.ReleaseBuffer();
	CString strT;
	strT="��ʥ(���԰�)----�������Ѿ���������ǰIPΪ"+pApp->m_strIp+" ���Ŷ˿ں�Ϊ1028";
	pApp->m_pMainWnd->SetWindowText(strT);
	m_start=FALSE;
 }
	strcpy(zmfile[count].name,cfiledlg.GetFileName());
	 
   		AfxGetMainWnd()->SendMessage(WM_ADDLIST, (LPARAM)&zmfile[count],1);
	
	CString aaa;
	aaa.Format("�����ļ�  %s",zmfile[count].name);
		aaa+='\n';
	Message(aaa,RGB(0,0,0));
 
strcpy(zmfile[count+1].name,"none");
strcpy(nameph[count],fnamepath);
	count++;
 
	return 1;
}

void CServer1View::OnServerStart() 
{ 
//����������
	if(m_start){
		listensocket=new mysocket(this);
	 listensocket->Create(8888);
 listensocket->Listen();
	
		CMainFrame* pWnd=(CMainFrame*)AfxGetMainWnd();
	CServer1App* pApp=(CServer1App*)AfxGetApp();
		DWORD dwthread;
	sockaddr_in local;
	SOCKET m_socket;

	int rc=0;
 
	local.sin_family=AF_INET;
	local.sin_port=htons(1028);
	local.sin_addr.S_un.S_addr=INADDR_ANY;
	m_socket=socket(AF_INET,SOCK_STREAM,0);

		rc=bind(m_socket,(LPSOCKADDR)&local,sizeof(local));
		if(rc==SOCKET_ERROR){
	CString aaa;
	aaa="Bind����\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	aaa.ReleaseBuffer();
 
		}
	::CreateThread(NULL,0,listenthread,(LPVOID)m_socket,0,&dwthread);
	CString aaa;
	aaa="������������\n";
 
	Message(aaa.GetBuffer(0),RGB(0,0,0));
	aaa.ReleaseBuffer();
	CString strT;
	strT="��ʥ(���԰�)----�������Ѿ���������ǰIPΪ"+pApp->m_strIp+" ���Ŷ˿ں�Ϊ1028";
	pApp->m_pMainWnd->SetWindowText(strT);
	m_start=FALSE;
	}
	else
	{
	CString aaa;
	aaa="�������Ѿ������ˣ�\n";
 
	Message(aaa.GetBuffer(0),RGB(0,0,0));
	aaa.ReleaseBuffer();
	}

 

}



/////////////////////////////////////////////////////////////////////////////
// CServer1View message handlers
//�����û�
void CServer1View::accept()
{
chatsocket=new mysocket(this);
listensocket->Accept(*chatsocket);
m_chat=TRUE;
}

void CServer1View::recevied()
{

}
