// server1.cpp : Defines the class behaviors for the application.
//���ߣ�����
//EMAIL:zmpapaya@hotmail.com;papaya_zm@sina.com
//��ҳ��http://h2osky.126.com

#include "stdafx.h"
#include "server1.h"
#include "mysocket.h"
#include "MainFrm.h"
#include "server1Doc.h"
#include "server1View.h"
#include "linkctrl.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServer1App
#define SIZE                            20480
BEGIN_MESSAGE_MAP(CServer1App, CWinApp)
	//{{AFX_MSG_MAP(CServer1App)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServer1App construction

CServer1App::CServer1App()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CServer1App object
DWORD WINAPI clientthread(LPVOID lpparam);
 
char nameph[10][255];
 
CServer1App theApp;
 //�ļ���Ϣ
 struct fileinfo
{
int fileno;//�ļ���
	int type;//��Ϣ���
	long len;//�ļ�����
	int seek;//��ʼλ��

char name[100];//�ļ���
};



 int sendn(SOCKET fd,char *bp,int len);
 


//��������
DWORD WINAPI listenthread(LPVOID lpparam)
{	SOCKET  pthis=(SOCKET)lpparam;
	

	int rc=listen(pthis,30);
if(rc<0){
	CString aaa;
	aaa="listen����\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	aaa.ReleaseBuffer();

	return 0;
		}
	while(1){

	SOCKET s1;
	s1=accept(pthis,NULL,NULL);
	CString aa;
aa="һ�����룡\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aa.GetBuffer(0),1);
	aa.ReleaseBuffer();
	DWORD dwthread;

	::CreateThread(NULL,0,clientthread,(LPVOID)s1,0,&dwthread);	
	}
	return 0;

}
//������
int readn(SOCKET fd,char *bp,int len)
{
	int cnt;
	int rc;
	cnt=len;
	while(cnt>0)
	{
		rc=recv(fd,bp,cnt,0);
	if(rc<0){

	CString aa;
aa="���մ���\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aa.GetBuffer(0),1);
	aa.ReleaseBuffer();
 
  return -1;
		}
		if(rc==0)return len-cnt;
	bp+=rc;
	cnt-=rc;


	}
	return len;
}


filesendinfo zmfile[10];//��¼�ļ�
//���ͺ���
int sendn(SOCKET fd,char *bp,int len)
{
	int cnt;
	int rc;
	cnt=len;
	while(cnt>0)
	{
		rc=send(fd,bp,cnt,0);
		if(rc<0){

	CString aa;
aa="���ʹ���\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aa.GetBuffer(0),1);
	aa.ReleaseBuffer();
 

return -1;
		}
		if(rc==0)return len-cnt;
	bp+=rc;
	cnt-=rc;


	}
	return len;
}
 //���ļ���Ϣ����
void readfile(SOCKET  so,int seek,int len,int fino)
 
{

	 CString myname;
 
	 myname.Format("%s",nameph[fino]);
	CFile myFile;
 

	myFile.Open(myname, CFile::modeRead | CFile::typeBinary|CFile::shareDenyNone); 
	
	myFile.Seek(seek,CFile::begin);
	 char m_buf[SIZE];
	 int len2;
	 int len1;
len1=len;
	 while(len1>0){
len2=len>SIZE?SIZE:len;
myFile.Read(m_buf, len2);
int aa=sendn(so,m_buf,len2);
if(aa<0){	
	closesocket (so);
	break;
}
len1=len1-aa;
len=len-aa;
 
	 }
	  myFile.Close();

 }

//�ͻ�����
DWORD WINAPI clientthread(LPVOID lpparam)
{

	fileinfo* fiinfo;
char* m_buf;
m_buf=new char[100];

	SOCKET  pthis=(SOCKET)lpparam;
 
	int aa=readn(pthis,m_buf,100);
	if(aa<0){
		closesocket (pthis);
		return -1;
	}

fiinfo=(fileinfo*)m_buf;
 
	CString temp;
		temp.Format("re %d from there",aa);
 
	CString aaa;
switch(fiinfo->type)
{
case 0:
aa=sendn(pthis,(char*)zmfile,1080);
if(aa<0){	
	closesocket (pthis);
		return -1;
}
aaa="�յ�LIST����\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	break;

 
case 2:
	aaa.Format("%s  �ļ�������%s\n",zmfile[fiinfo->fileno].name,nameph[fiinfo->fileno]);
   AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);

readfile(pthis,fiinfo->seek,fiinfo->len,fiinfo->fileno);
 
		break;
default:
	aaa="����Э�����\n";
    AfxGetMainWnd()->SendMessageToDescendants(WM_AGE1,(LPARAM)aaa.GetBuffer(0),1);
	break;
}

	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CServer1App initialization

BOOL CServer1App::InitInstance()
{
	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

	// Initialize OLE libraries
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CServer1Doc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CServer1View));
	pDocTemplate->SetContainerInfo(IDR_CNTR_INPLACE);
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The one and only window has been initialized, so show and update it.
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->CenterWindow();
	m_pMainWnd->SetWindowText("��ʥ(���԰�)----��������δ����----");
	m_pMainWnd->UpdateWindow();
	
    
	//pList.RemoveAll();
	WORD wVersionRequested;
    WSADATA wsaData;
    char name[255];
    PHOSTENT hostinfo;
    wVersionRequested = MAKEWORD( 2, 0 );

    if ( WSAStartup( wVersionRequested, &wsaData ) == 0 )
    {
        if( gethostname ( name, sizeof(name)) == 0)
        {
            if((hostinfo = gethostbyname(name)) != NULL)
               {
                    m_strIp = inet_ntoa (*(struct in_addr *)*hostinfo->h_addr_list);
               }
         }
            
         WSACleanup( );
     } 
	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
	CLinkCtrl	m_mail;
	CLinkCtrl	m_http;
// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual BOOL OnInitDialog();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
//	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MAIL, m_mail);
	DDX_Control(pDX, IDC_HTTP, m_http);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
//	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CServer1App::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CServer1App message handlers

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_mail.SetLinkString("mailto:zmpapaya@hotmail.com");
	m_http.SetLinkString("http://h2osky.126.com");
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
