#if !defined(AFX_WEBVIEW_H__D818E8A4_2B65_11D5_92C9_00E04C39F1E2__INCLUDED_)
#define AFX_WEBVIEW_H__D818E8A4_2B65_11D5_92C9_00E04C39F1E2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WebView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWebView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CWebView : public CFormView
{
protected:
	CWebView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CWebView)

// Form Data
public:
	//{{AFX_DATA(CWebView)
	enum { IDD = IDD_WEBLIST };
	CListCtrl	m_WebList;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void OnWebToLocal(WPARAM wParam, LPARAM lParam);
	void OnDeleteAllList(WPARAM wParam, LPARAM lParam);
	volatile char m_csPath[256];
	volatile char m_csAttrib[256];
	volatile char m_csName[256];
	volatile char m_csTime[256];
	volatile char m_csSize[256];
	volatile char m_csSerchBase[256];
	volatile HANDLE m_hPostEvent;
	void OnWebInsert(WPARAM wParam, LPARAM lParam);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWebView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CWebView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CWebView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDblclkWeblist(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WEBVIEW_H__D818E8A4_2B65_11D5_92C9_00E04C39F1E2__INCLUDED_)
