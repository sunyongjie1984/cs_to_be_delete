#if !defined(AFX_PROJECTTREE_H__4470EEA0_2CCC_11D5_92C9_00E04C39F1E2__INCLUDED_)
#define AFX_PROJECTTREE_H__4470EEA0_2CCC_11D5_92C9_00E04C39F1E2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProjectTree.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CProjectTree form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CProjectTree : public CFormView
{
protected:
	CProjectTree();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CProjectTree)

// Form Data
public:
	//{{AFX_DATA(CProjectTree)
	enum { IDD = IDD_PROJECTTREE };
	CTreeCtrl	m_ProjectTree;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void OnProjectDelete(WPARAM wParam, LPARAM lParam);
	void OnProjectAdd(WPARAM wParam, LPARAM lParam);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProjectTree)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CProjectTree();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CProjectTree)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnClickProjecttree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangedProjecttree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBeginlabeleditProjecttree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEndlabeleditProjecttree(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROJECTTREE_H__4470EEA0_2CCC_11D5_92C9_00E04C39F1E2__INCLUDED_)
