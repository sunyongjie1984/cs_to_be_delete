// EasyFtpDoc.cpp : implementation of the CEasyFtpDoc class
//

#include "stdafx.h"
#include "EasyFtp.h"

#include "EasyFtpDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEasyFtpDoc

IMPLEMENT_DYNCREATE(CEasyFtpDoc, CDocument)

BEGIN_MESSAGE_MAP(CEasyFtpDoc, CDocument)
	//{{AFX_MSG_MAP(CEasyFtpDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEasyFtpDoc construction/destruction

CEasyFtpDoc::CEasyFtpDoc()
{
	// TODO: add one-time construction code here

}

CEasyFtpDoc::~CEasyFtpDoc()
{
}

BOOL CEasyFtpDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CEasyFtpDoc serialization

void CEasyFtpDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CEasyFtpDoc diagnostics

#ifdef _DEBUG
void CEasyFtpDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CEasyFtpDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CEasyFtpDoc commands

void CEasyFtpDoc::SetTitle(LPCTSTR lpszTitle) 
{
	// TODO: Add your specialized code here and/or call the base class
	CDocument::SetTitle("jzZSoftware�I ��Ʒ  ��ӭ����http://ccus.myrice.com��ҳ");
	//CDocument::SetTitle(lpszTitle);
}
