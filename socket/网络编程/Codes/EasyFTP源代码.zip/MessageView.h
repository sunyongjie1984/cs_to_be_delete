#if !defined(AFX_MESSAGEVIEW_H__BB977DC1_2CE8_11D5_92C9_00E04C39F1E2__INCLUDED_)
#define AFX_MESSAGEVIEW_H__BB977DC1_2CE8_11D5_92C9_00E04C39F1E2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MessageView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMessageView view

class CMessageView : public CEditView
{
protected:
	CMessageView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMessageView)

// Attributes
public:

// Operations
public:
	bool OnMessageUpdate(WPARAM wParam, LPARAM lParam);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMessageView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMessageView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	CFont m_TextFont;
	//{{AFX_MSG(CMessageView)
	afx_msg void OnDestroy();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MESSAGEVIEW_H__BB977DC1_2CE8_11D5_92C9_00E04C39F1E2__INCLUDED_)
