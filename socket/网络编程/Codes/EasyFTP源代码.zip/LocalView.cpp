// LocalView.cpp : implementation file
//

#include "stdafx.h"
#include "EasyFtp.h"

#include "LocalView.h"
#include "mainfrm.h"
#include "MessageView.h"
#include "WorkView.h"
#include "io.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



LV_ITEM lvi;
extern volatile bool bExitApp;
CLocalView *pLocalView;
extern CMessageView *pMessageView;
CWinThread *MySerchDirThread;
UINT MySerchDirThreadFunction(LPVOID lpParam);
//void MySerchDirThreadEnd(void);
bool AddOneDir(char *cPath, char *cBasePath);
bool bAddDir=true;		//��������

extern bool bAutoLoad;
extern bool bCmpNow;
extern int iNowProjectNo;
extern CMainFrame *pMainFrame;
extern CWorkView *pWorkView;
extern char sProjectAttrib[256][6][256];

int iTotalLocalFile=0;
int iTotalLocalDir=0;
DWORD dwTotalLocalFileLong=0;


/////////////////////////////////////////////////////////////////////////////
// CLocalView

IMPLEMENT_DYNCREATE(CLocalView, CFormView)

CLocalView::CLocalView()
	: CFormView(CLocalView::IDD)
{
	//{{AFX_DATA_INIT(CLocalView)
	m_Localpath = _T("");
	//}}AFX_DATA_INIT
	m_hPostEvent=NULL;
	pLocalView=this;
}

CLocalView::~CLocalView()
{
	if(m_hPostEvent)
	{
		CloseHandle(m_hPostEvent);
		m_hPostEvent=NULL;
	}
	pLocalView=NULL;
	//MySerchDirThreadEnd();
}

void CLocalView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLocalView)
	DDX_Control(pDX, IDC_LOCAL_BROWS, m_LocalButton);
	DDX_Control(pDX, IDC_LOCAL_PATH, m_LocalPath);
	DDX_Control(pDX, IDC_LOCAL_LIST, m_LocalList);
	DDX_Text(pDX, IDC_LOCAL_PATH, m_Localpath);
	DDV_MaxChars(pDX, m_Localpath, 256);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLocalView, CFormView)
	//{{AFX_MSG_MAP(CLocalView)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_LOCAL_BROWS, OnLocalBrows)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_MY_LOCALLIST_INSERT,OnLocalInsert)
	ON_MESSAGE(WM_MY_PROJECT_PATH,OnProjectPath)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLocalView diagnostics

#ifdef _DEBUG
void CLocalView::AssertValid() const
{
	CFormView::AssertValid();
}

void CLocalView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLocalView message handlers

void CLocalView::OnDraw(CDC* pDC) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	//AfxMessageBox("OK");
}

void CLocalView::OnSize(UINT nType, int cx, int cy) 
{
//	CFormView::OnSize(nType, cx, cy);
	// TODO: Add your message handler code here
	if(m_LocalPath.m_hWnd)
		m_LocalPath.SetWindowPos(this,0,0,cx-80,20,SWP_NOZORDER|SWP_NOMOVE);
	if(m_LocalButton.m_hWnd)
		m_LocalButton.SetWindowPos(this,cx-80,0,80,20,SWP_NOZORDER);
	if(m_LocalList.m_hWnd)
	{
		m_LocalList.ShowWindow(SW_HIDE);
		m_LocalList.SetWindowPos(this,0,0,cx,cy-20,SWP_NOZORDER|SWP_NOMOVE);
		m_LocalList.ShowWindow(SW_SHOW);
	}		//������С
}

void CLocalView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	// TODO: Add your specialized code here and/or call the base class
	RECT rct;
	GetClientRect(&rct);			//�õ��ͻ������С
	if(m_LocalPath.m_hWnd)
		m_LocalPath.SetWindowPos(this,0,0,rct.right-80,20,SWP_NOZORDER|SWP_NOMOVE);
	if(m_LocalButton.m_hWnd)
		m_LocalButton.SetWindowPos(this,rct.right-80,0,80,20,SWP_NOZORDER);
	if(m_LocalList.m_hWnd)
	{
		m_LocalList.ShowWindow(SW_HIDE);
		m_LocalList.SetWindowPos(this,0,0,rct.right,rct.bottom-20,SWP_NOZORDER|SWP_NOMOVE);
		m_LocalList.ShowWindow(SW_SHOW);
	}		//��ʼ����С
	//******************
	//��д�б���
	static struct
	{
		LPSTR pszText;
		int uiFormat;
	}columns[]={
		_T("�����ļ�����"),LVCFMT_LEFT,
		_T("�ļ�����"),LVCFMT_CENTER,
		_T("�ļ���С"),LVCFMT_RIGHT,
		_T("�ļ�Ŀ¼"),LVCFMT_LEFT,
		_T("״̬"),LVCFMT_CENTER
	};
	int j;
	for(int i=0;i<sizeof(columns)/sizeof(columns[0]);i++)
	{
		switch(i)
		{
		case 0:
			j=100;
			break;
		case 1:
			j=100;
			break;
		case 2:
			j=60;
			break;
		case 3:
			j=60;
			break;
		default:
			j=50;
			break;
		}
		m_LocalList.InsertColumn(i,columns[i].pszText,columns[i].uiFormat,j);
	}
	m_LocalList.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
	//�������
}

void CLocalView::OnLocalBrows() 
{
	// TODO: Add your control notification handler code here
	if(!bAddDir)
		return;
	char pszDisplayName[256];
	bool bYes=false;
	BROWSEINFO BrowseInfo;
	LPITEMIDLIST pidlBrowse;
	LPMALLOC pMalloc;
	if( !SUCCEEDED(SHGetMalloc(&pMalloc)) )
		return ;
	BrowseInfo.hwndOwner = m_hWnd;
	BrowseInfo.pidlRoot = NULL;
	BrowseInfo.pszDisplayName = pszDisplayName;
	BrowseInfo.lpszTitle = "��ָ��һ��Ŀ¼:";
	BrowseInfo.ulFlags = BIF_DONTGOBELOWDOMAIN;
	BrowseInfo.lpfn = NULL;
	BrowseInfo.lParam = 0;
	BrowseInfo.iImage = 0;
	pidlBrowse = SHBrowseForFolder(&BrowseInfo);
	char temp[256];
	bYes=false;
	if( pidlBrowse!=NULL )
	{
		if( SHGetPathFromIDList(pidlBrowse,pszDisplayName) )
		{
			//m_Ed1 = pszDisplayName;
			strcpy(temp,pszDisplayName);
			bYes=true;
			bAddDir=false;		//��ֹ�ٴ�����
			((CButton *)GetDlgItem(IDC_LOCAL_BROWS))->EnableWindow(false);
		}
		pMalloc->Free(pidlBrowse);
	}
	pMalloc->Release();
	if(bYes)		//ѡ��
	{
		
		bExitApp=false;
		m_Localpath.Format("%s",temp);
		if(m_LocalList.GetItemCount()>0)
		{
			m_LocalList.DeleteAllItems();
		}
		strcpy(sProjectAttrib[iNowProjectNo][5],temp);
		pMainFrame->PostMessage(WM_MY_PROJECT_UPDATE);
		strcpy((char *)m_csSerchBase,temp);
		UpdateData(false);
		if((MySerchDirThread = AfxBeginThread(MySerchDirThreadFunction,0)) == NULL)
		{
			//����ʧ�ܴ���
			return;
		}
		else    //�����Ὠ��һ�������̲߳���ʱ�������
		{
			MySerchDirThread->SetThreadPriority(THREAD_PRIORITY_BELOW_NORMAL);
			MySerchDirThread->ResumeThread();//����CWinThread:: ResumeThreadʹ�߳̿�ʼ����
		}
	}
}



void CLocalView::OnLocalInsert(WPARAM wParam, LPARAM lParam)
{
	lvi.iItem=m_LocalList.GetItemCount();
	lvi.pszText="";
	lvi.lParam=(LPARAM)lvi.iItem;
	m_LocalList.InsertItem(&lvi);
	m_LocalList.SetItemText(lvi.iItem,0,(char *)m_csName);
	m_LocalList.SetItemText(lvi.iItem,1,(char *)m_csTime);
	m_LocalList.SetItemText(lvi.iItem,2,(char *)m_csSize);
	m_LocalList.SetItemText(lvi.iItem,3,(char *)m_csPath);
	m_LocalList.SetItemText(lvi.iItem,4,(char *)m_csAttrib);
	m_LocalList.SetHotItem(lvi.iItem);			//��ע��ǰ��Ŀ
	m_LocalList.EnsureVisible(lvi.iItem,true);	//����Ӱ��ľ���
	m_LocalList.Update(lvi.iItem);				//�ػ�List����,��ֹ����
	SetEvent(m_hPostEvent);		//�����ٴμ���
}



UINT MySerchDirThreadFunction(LPVOID lpParam)
{
	iTotalLocalFile=0;
	iTotalLocalDir=0;
	dwTotalLocalFileLong=0;
	AddOneDir((char*)pLocalView->m_csSerchBase,(char*)pLocalView->m_csSerchBase);
	CString te;
	te.Format("������ɣ��ļ���%d����Ŀ¼��%d������%ld�ֽ�\r\n",
		iTotalLocalFile,iTotalLocalDir,dwTotalLocalFileLong);
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)te);
	bAddDir=true;		//��ֹ�ٴ�����
	((CButton *)pLocalView->GetDlgItem(IDC_LOCAL_BROWS))->EnableWindow(true);

	if(bAutoLoad)//�Զ���ʼ����������
	{
		pMainFrame->PostMessage(WM_MY_AUTO_LINK);//OnButton1();
	}
	else//�����Զ�ģʽ,���Ƿ�Ϊ�Ƚ�ģʽ
	{
		if(bCmpNow)
		{
			bCmpNow=false;
			pWorkView->PostMessage(WM_MY_WORK_LISTNEW);	
		}
	}
	return true;
}


bool AddOneDir(char cPath[256], char cBasePath[256])
{
	struct tm *thefiletime;
	long dofile=0;
	struct _finddata_t bFile;
	char temp1[256];//��ǰ·��
	char temp2[256];//�ҵ����ļ���
	char temp3[256];//�����ԭʼ·��
	char temp4[256];//Ŀ¼����
	char *pTemp;	//�ַ���ָ��
	int done=0;
	CString te;
	strcpy(temp1,cPath);	//�õ���ǰĿ¼����temp1
	int i=strlen(temp1);
	if(temp1[i-1]!='\\')
	{
		temp1[i]='\\';
		temp1[i+1]=0x00;
	}
	if(strlen(temp1)==strlen(cPath)+1)
	{
		strcat(cBasePath,"\\");
	}
	if(strcmp(cPath,cBasePath)==0)
	{
		strcpy(temp4,"");
	}
	else
	{
		strcpy(temp4,cPath);
		pTemp=cPath;
		pTemp+=strlen(cBasePath);
		strcpy(temp4,pTemp);
	}
	strcpy(temp3,temp1);
	strcat(temp1,"*.*");	//�ڵ�ǰĿ¼�²���*.*
	dofile=_findfirst(temp1,&bFile);
	if(dofile==-1)//Ŀ¼�ļ�ʧ��
	{
		AfxMessageBox("����Ŀ¼ʧ��!");
		return false;//break;
	}
	done=0;
	while(done!=-1)
	{
		if(bExitApp)
		{
			return false;
		}
		//loopmessage();
		strcpy(temp2,bFile.name);//�ҵ����ļ���д��temp2
		if(bFile.attrib&_A_SUBDIR)//strcmp(temp2,".")==0||strcmp(temp2,"..")==0)
		{
			if(strcmp(temp2,".")==0||strcmp(temp2,"..")==0)
			{
				done=_findnext(dofile,&bFile);
				continue;///�����.��..��Ŀ¼,������һ��
			}//�ҵ���Ŀ¼
			iTotalLocalDir+=1;
			strcpy(temp1,temp3);
			strcat(temp1,bFile.name);
			strcat(temp1,"\\");
			if(AddOneDir(temp1,cBasePath)==false)
			{
				//AfxMessageBox("����ʧ��!");
				return false;
			}
		}
		else		//���ļ�,������
		{
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"�����ļ���");
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)temp2);
			iTotalLocalFile+=1;
			dwTotalLocalFileLong+=bFile.size;
			strcpy((char *)pLocalView->m_csAttrib,"δ֪");
			strcpy((char *)pLocalView->m_csName,temp2);
			strcpy((char *)pLocalView->m_csPath,temp4);
			thefiletime=localtime(&(bFile.time_write));
			if(thefiletime!=NULL)
			{
				te.Format("%04d-%02d-%02d %02d:%02d",thefiletime->tm_year+1900,thefiletime->tm_mon+1,thefiletime->tm_mday,thefiletime->tm_hour,thefiletime->tm_min);
				strcpy((char *)pLocalView->m_csTime,te);
			}
			else
			{
				strcpy((char *)pLocalView->m_csTime,"��Ч��ʱ��"); //��ʾʱ��
			}
			te.Format("%d",bFile.size);
			strcpy((char *)pLocalView->m_csSize,te);
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"\r\n");
			ResetEvent(pLocalView->m_hPostEvent);
			pLocalView->PostMessage(WM_MY_LOCALLIST_INSERT,0,0);
			if(WaitForSingleObject(pLocalView->m_hPostEvent,0xffffffff)==WAIT_TIMEOUT)
			{
				pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"�ȴ������б���ʱ..");
			}
		}
		done=_findnext(dofile,&bFile);
		//�ļ�����,����һ���ļ�
	}
	return true;
}

BOOL CLocalView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	return CFormView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
}

void CLocalView::OnProjectPath(WPARAM wParam, LPARAM lParam)
{
	if(!bAddDir)
		return;
	bAddDir=false;
	char sPath[256];
	strcpy(sPath,(char*)lParam);
//	bExitApp=false;
	m_Localpath.Format("%s",sPath);
	if(m_LocalList.GetItemCount()>0)
	{
		m_LocalList.DeleteAllItems();
	}
	UpdateData(false);
	strcpy((char *)m_csSerchBase,sPath);
	if((MySerchDirThread = AfxBeginThread(MySerchDirThreadFunction,0)) == NULL)
	{
		//����ʧ�ܴ���
		return;
	}
	else    //�����Ὠ��һ�������̲߳���ʱ�������
	{
		MySerchDirThread->SetThreadPriority(THREAD_PRIORITY_BELOW_NORMAL);
		MySerchDirThread->ResumeThread();//����CWinThread:: ResumeThreadʹ�߳̿�ʼ����
	}
}

int CLocalView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFormView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	if((m_hPostEvent=CreateEvent(NULL,TRUE,TRUE,NULL))==NULL)
		return -1;


	return 0;
}
