// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "EasyFtp.h"

#include "MainFrm.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame
#include "EasyFtpDoc.h"
#include "LocalView.h"
#include "WorkView.h"
#include "ProjectTree.h"
#include "WebView.h"
#include "MessageView.h"
#include "SettingBox.h"
#include "ProjectName.h"

#include "wininet.h"
#include "ras.h"


HICON m_hIcon;		//����ͼ��

int iPathNo=0;		//·����ջ������
int iPathPoint=0;	//·����ջ��ָ��
char sWebPathNeedSerch[1024][256];//·����ջ
char sNowWebPath[256];

RECT rectMainWindowsRect;	//���ڴ�С

CMainFrame *pMainFrame;
extern CLocalView *pLocalView;
extern CWebView *pWebView;
extern CMessageView *pMessageView;
extern CWorkView *pWorkView;
extern CProjectTree *pProjectTree;
extern int iNowProjectNo;

int iIconNumber=0;			//ͼ����
bool bLinkDataGood=false;	//���ݴ�������ñ�־
bool bWebTry=false;			//��������״̬
BOOL bAutoDial=false;		//�Զ�����
BOOL bAutoHangUp=false;		//�Զ��Ҷ�
BOOL bCmpTime=false;		//�Ƚ�ʱ��
BOOL bAutoDialAgain=false;	//����ʧ�ܼ����ز�
BOOL bDialWhenHangUp=false;	//��Ҫʱ�򲦺�
BOOL bWebAgain=false;		//������ʧ������
BOOL bMUpThread=false;		//��������ϴ��߳�
BOOL bQuitWhenFinish=false;	//��ɺ��˳�
BOOL bShutDownWhenFinish=false;//��ɺ�رռ����
BOOL bWebToLocal=true;		//ֱ�ӱȽϼ�¼�ļ�
int iMThreadMax=3;			//�������߳����ֵ
int iWebLoop=0;				//������ʧ�����Դ���
int iWebTryLoop=0;			//���÷�����ʧ�����Դ���
int iDialDelay=5;			//����ʧ���ӳ�
int iDialLoop=0;			//����ʧ�ܴ���
volatile int iMThreadWorkTotal=0;	//�������
volatile int iMThreadWorkNowNo=0;	//��ǰ�Ѿ�������������
volatile bool bMThreadWorkReady[5]=
{true,true,true,true,true};//�߳̿���
char sDialNumber[256],sDialUser[256],sDialPassword[256];

//����һ���߳�ָ�벢����һ���̺߳�������
CWinThread *MyFtpLogoThread;             //���������߳�
CWinThread *MyFtpUpThread;				//�ϴ��߳�
CWinThread *MyDialThread;
CWinThread *MyMUpThread[10];
UINT MyMUpThreadFunction(LPVOID lpParam);
//void MyMUpThreadEnd(void);
UINT MyDialThreadFunction(LPVOID lpParam);
///void MyDialThreadEnd(void);
UINT MyFtpLogoThreadFunction(LPVOID lpParam);
//void MyFtpLogoThreadEnd(void);
UINT MyFtpUpThreadFunction(LPVOID lpParam);
//void MyFtpUpThreadEnd(void);
bool Dial();
bool HangUp();
bool bAutoLoad=false;
bool bCmpNow=false;


CString csName,csUser,csPassword,csWebPath,csLocalPath;

int iTotalProject=0;		//��Ŀ����
int iTotalWebFile=0;
int iTotalWebDir=0;
DWORD dwTotalWebFileLong=0;

volatile bool bExitApp=false;

char sProjectAttrib[256][6][256];
//��Ŀ��
//�û���
//��ַ
//����
//������·��
//����·��


IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_COMMAND(ID_CTL_BREAK, OnCtlBreak)
	ON_COMMAND(ID_BUTTON_EXIT, OnButtonExit)
	ON_COMMAND(ID_CTL_HUANGUP, OnCtlHuangup)
	ON_EN_CHANGE(IDC_FTPADD, OnChangeFtpadd)
	ON_EN_CHANGE(IDC_FTPUSER, OnChangeFtpuser)
	ON_EN_CHANGE(IDC_FTPPASSWORD, OnChangeFtppassword)
	ON_EN_CHANGE(IDC_LOCALPATH, OnChangeLocalpath)
	ON_EN_CHANGE(IDC_WEBPATH, OnChangeWebpath)
	ON_COMMAND(ID_CTL_FTPUP, OnCtlFtpup)
	ON_COMMAND(ID_CTL_DIAL, OnCtlDial)
	ON_COMMAND(ID_CTL_SETTING, OnCtlSetting)
	ON_COMMAND(ID_CTL_AUTOLOAD, OnCtlAutoload)
	ON_COMMAND(ID_CTL_CMP, OnCtlCmp)
	ON_COMMAND(ID_PROJECT_ADD, OnProjectAdd)
	ON_COMMAND(ID_PROJECT_DELETE, OnProjectDelete)
	ON_WM_TIMER()
	ON_COMMAND(ID_QUICK_WEBTOLOCAL, OnQuickWebtolocal)
	ON_UPDATE_COMMAND_UI(ID_QUICK_WEBTOLOCAL, OnUpdateQuickWebtolocal)
	ON_COMMAND(ID_QUICK_SHUTDOWN, OnQuickShutdown)
	ON_UPDATE_COMMAND_UI(ID_QUICK_SHUTDOWN, OnUpdateQuickShutdown)
	ON_COMMAND(ID_QUICK_QUITWHENFINISH, OnQuickQuitwhenfinish)
	ON_UPDATE_COMMAND_UI(ID_QUICK_QUITWHENFINISH, OnUpdateQuickQuitwhenfinish)
	ON_COMMAND(ID_QUICK_AUTODIAL, OnQuickAutodial)
	ON_UPDATE_COMMAND_UI(ID_QUICK_AUTODIAL, OnUpdateQuickAutodial)
	ON_COMMAND(ID_QUICK_HANGUP, OnQuickHangup)
	ON_UPDATE_COMMAND_UI(ID_QUICK_HANGUP, OnUpdateQuickHangup)
	ON_COMMAND(ID_QUICK_TIMECMP, OnQuickTimecmp)
	ON_UPDATE_COMMAND_UI(ID_QUICK_TIMECMP, OnUpdateQuickTimecmp)
	ON_EN_UPDATE(IDC_WEBPATH, OnUpdateWebpath)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_MY_PROJECT_UPDATE,OnUpdateProject)
	ON_MESSAGE(WM_MY_AUTO_LOAD,OnAutoLoad)
	ON_MESSAGE(WM_MY_AUTO_LINK,OnAutoLink)
	ON_MESSAGE(WM_MY_WEBLOOP_LOGO,OnWebLogoLoop)
	ON_MESSAGE(WM_MY_WEBLOOP_UP,OnWebUpLoop)
	ON_MESSAGE(WM_MY_APP_EXIT,OnMyExit)
	ON_MESSAGE(WM_MY_SHUTDOWN,OnMyShutDown)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	MyDialThread=NULL;
	pMainFrame=this;
	iTotalProject=0;
	int iNo;
	int i,j,k;
	char ctemp;
	FILE *fo;
	bAutoDial=false;
	bAutoHangUp=false;
	bCmpTime=false;
	bAutoDialAgain=false;	//����ʧ�ܼ����ز�
	bDialWhenHangUp=false;	//��Ҫʱ�򲦺�
	bMUpThread=false;		//��������ϴ��߳�
	bQuitWhenFinish=false;	//��ɺ��˳�
	bShutDownWhenFinish=false;//��ɺ�رռ����
	bWebToLocal=true;		//ֱ�ӱȽϼ�¼�ļ�
	iDialDelay=5;			//����ʧ���ӳ�
	iDialLoop=0;			//����ʧ�ܴ���
	
	strcpy(sDialUser,"anybody");
	strcpy(sDialNumber,"999");
	strcpy(sDialPassword,"easyftp");
	fo=fopen("set.sys","rb");
	if(fo!=NULL)
	{
		fscanf(fo,"%d",&iNo);
		if(iNo==1)
			bAutoDial=true;
		fscanf(fo,"%d",&iNo);
		if(iNo==1)
			bAutoHangUp=true;
		fscanf(fo,"%d",&iNo);
		if(iNo==1)
			bCmpTime=true;
		fscanf(fo,"%d",&iNo);
		fscanf(fo,"%c%c",&ctemp,&ctemp);
		for(i=0;i<iNo;i++)
		{
			fscanf(fo,"%c",&sDialNumber[i]);
		}
		sDialNumber[i]=0x00;
		fscanf(fo,"%d",&iNo);
		fscanf(fo,"%c%c",&ctemp,&ctemp);
		for(i=0;i<iNo;i++)
		{
			fscanf(fo,"%c",&sDialUser[i]);
		}
		sDialUser[i]=0x00;
		fscanf(fo,"%d",&iNo);
		fscanf(fo,"%c%c",&ctemp,&ctemp);
		for(i=0;i<iNo;i++)
		{
			fscanf(fo,"%c",&sDialPassword[i]);
		}
		sDialPassword[i]=0x00;
		fscanf(fo,"%d",&iNo);
		if(iNo==1)
			bAutoDialAgain=true;	//����ʧ�ܼ����ز�
		fscanf(fo,"%d",&iNo);
		if(iNo==1)
			bAutoDialAgain=true;	//����ʧ�ܼ����ز�
		fscanf(fo,"%d",&iNo);
		if(iNo==1)
			bDialWhenHangUp=true;	//��Ҫʱ�򲦺�
		fscanf(fo,"%d",&iDialDelay);//����ʧ���ӳ�
		fscanf(fo,"%d",&iDialLoop);//����ʧ�ܴ���
		fscanf(fo,"%d",&iNo);
		if(iNo==1)
			bWebAgain=true;		//������ʧ������
		fscanf(fo,"%d",&iWebLoop);//������ʧ�����Դ���
		fscanf(fo,"%d",&iNo);
		if(iNo==1)
			bMUpThread=true;		//��������ϴ��߳�
		fscanf(fo,"%d",&iNo);
		if(iNo==1)
			bQuitWhenFinish=true;	//��ɺ��˳�
		fscanf(fo,"%d",&iNo);
		if(iNo==1)
			bShutDownWhenFinish=true;//��ɺ�رռ����
		fscanf(fo,"%d",&iMThreadMax);//�������߳����ֵ
		if(iMThreadMax<1||iMThreadMax>10)
			iMThreadMax=3;
		fscanf(fo,"%d",&iNo);
		if(iNo==0)
			bWebToLocal=false;		//ֱ�ӱȽϼ�¼�ļ�
		fclose(fo);
	}
	fo=fopen("save.dat","rb");
	if(fo==NULL)
	{
		//AfxMessageBox("�޷���ȡ����");
		return;
	}
	fscanf(fo,"%d",&iTotalProject);
	if(iTotalProject<=0||iTotalProject>256)
	{
		iTotalProject=0;
		fclose(fo);
		return;
	}
	for(i=0;i<iTotalProject;i++)
	{
		for(k=0;k<6;k++)
		{
			fscanf(fo,"%d",&iNo);
			fscanf(fo,"%c%c",&ctemp,&ctemp);
			for(j=0;j<iNo;j++)
			{
				fscanf(fo,"%c",&sProjectAttrib[i][k][j]);
			}
			sProjectAttrib[i][k][j]=0x00;
		}
	}	
	fclose(fo);
}

CMainFrame::~CMainFrame() 
{
	//MyFtpLogoThreadEnd();
	pMainFrame=NULL;
	FILE *fo;
	int i,j;
	fo=fopen("set.sys","wb");
	if(fo!=NULL)
	{
		if(bAutoDial)
		{
			fprintf(fo,"1\r\n");
		}
		else
		{
			fprintf(fo,"0\r\n");
		}
		if(bAutoHangUp)
		{
			fprintf(fo,"1\r\n");
		}
		else
		{
			fprintf(fo,"0\r\n");
		}
		if(bCmpTime)
		{
			fprintf(fo,"1\r\n");
		}
		else
		{
			fprintf(fo,"0\r\n");
		}
		fprintf(fo,"%d\r\n",strlen(sDialNumber));
		fprintf(fo,"%s\r\n",sDialNumber);
		fprintf(fo,"%d\r\n",strlen(sDialUser));
		fprintf(fo,"%s\r\n",sDialUser);
		fprintf(fo,"%d\r\n",strlen(sDialPassword));
		fprintf(fo,"%s\r\n",sDialPassword);
		if(bAutoDialAgain)//����ʧ�ܼ����ز�
			fprintf(fo,"1\r\n");
		else
			fprintf(fo,"0\r\n");
		if(bAutoDialAgain)	//����ʧ�ܼ����ز�
			fprintf(fo,"1\r\n");
		else
			fprintf(fo,"0\r\n");
		if(bDialWhenHangUp)//��Ҫʱ�򲦺�
			fprintf(fo,"1\r\n");
		else
			fprintf(fo,"0\r\n");
		fprintf(fo,"%d\r\n",iDialDelay);//����ʧ���ӳ�
		fprintf(fo,"%d\r\n",iDialLoop);//����ʧ�ܴ���
		if(bWebAgain)//������ʧ������
			fprintf(fo,"1\r\n");
		else
			fprintf(fo,"0\r\n");
		fprintf(fo,"%d\r\n",iWebLoop);//������ʧ�����Դ���
		if(bMUpThread)//��������ϴ��߳�
			fprintf(fo,"1\r\n");
		else
			fprintf(fo,"0\r\n");
		if(bQuitWhenFinish)//��ɺ��˳�
			fprintf(fo,"1\r\n");
		else
			fprintf(fo,"0\r\n");
		if(bShutDownWhenFinish)//��ɺ�رռ����
			fprintf(fo,"1\r\n");
		else
			fprintf(fo,"0\r\n");
		fprintf(fo,"%d\r\n",iMThreadMax);//�������߳����ֵ
		if(bWebToLocal)	//ֱ�ӱȽϼ�¼�ļ�
			fprintf(fo,"1\r\n");
		else
			fprintf(fo,"0\r\n");
		fclose(fo);
	}
	fo=fopen("save.dat","wb");
	if(fo==NULL)
	{
		AfxMessageBox("�޷�����");
		return;
	}
	fprintf(fo,"%d\r\n",iTotalProject);
	for(i=0;i<iTotalProject;i++)
	{
		for(j=0;j<6;j++)
		{
			fprintf(fo,"%d\r\n",strlen(sProjectAttrib[i][j]));
			fprintf(fo,"%s\r\n",sProjectAttrib[i][j]);
		}
	}
	fclose(fo);
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
//	m_wndToolBar.SetButtonStyle(1,TBBS_CHECKBOX);
//	m_wndToolBar.SetHeight(50);
//	m_wndToolBar.SetButtonText(1,"CKBOX");
	//����Ϊ��ѡģʽ
	if (!m_wndDlgBar.Create(this, IDR_MAINFRAME, 
		CBRS_ALIGN_TOP, AFX_IDW_DIALOGBAR))
	{
		TRACE0("Failed to create dialogbar\n");
		return -1;		// fail to create
	}

	if (!m_wndReBar.Create(this) ||
		!m_wndReBar.AddBar(&m_wndToolBar) ||
		!m_wndReBar.AddBar(&m_wndDlgBar))
	{
		TRACE0("Failed to create rebar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);

	//*****************��������ʾͼ��
	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON1);
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	NOTIFYICONDATA tnid; 
    tnid.cbSize = sizeof(NOTIFYICONDATA); 
    tnid.hWnd = GetSafeHwnd();
    tnid.uID = WM_SCNOTIFYICON; 
    tnid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP; 
    tnid.uCallbackMessage = WM_SCNOTIFYICON; 
	tnid.hIcon = m_hIcon; 
    memset(tnid.szTip, 0, 32);
	lstrcpy(tnid.szTip, "EasyFtp�I");//��ʾ������ʾ
    Shell_NotifyIcon(NIM_ADD, &tnid);
	//-----------------------------
	SetTimer(101,500,NULL);		//���ö�ʱ��101�����ڸ���ͼ��
	return 0;
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT /*lpcs*/,
	CCreateContext* pContext)
{
/*	return m_wndSplitter.Create(this,
		2, 2,               // TODO: adjust the number of rows, columns
		CSize(10, 10),      // TODO: adjust the minimum pane size
		pContext);*/
	ShowWindow(SW_SHOWMAXIMIZED);
	GetClientRect(&rectMainWindowsRect);
	//�õ��ͻ����򴰿ڴ�С
	if(!m_wndSplitter1.CreateStatic(this,3,1))
		return FALSE;		//����3��
	m_wndSplitter1.SetRowInfo(0,rectMainWindowsRect.bottom*3/10,0);
	if(m_wndSplitter2.CreateStatic(&m_wndSplitter1,1,2,WS_CHILD|WS_VISIBLE,m_wndSplitter1.IdFromRowCol(0,0))==NULL)
		return FALSE;		//�ڵ�1���н���2��
	if(!m_wndSplitter2.CreateView(0,0,RUNTIME_CLASS(CProjectTree),CSize(rectMainWindowsRect.right*1/3,rectMainWindowsRect.bottom*3/10),pContext)||
		!m_wndSplitter2.CreateView(0,1,RUNTIME_CLASS(CWorkView),CSize(rectMainWindowsRect.right*2/3,rectMainWindowsRect.bottom*3/10),pContext))
		return FALSE;		//���õ�1����2��
	m_wndSplitter1.SetRowInfo(1,rectMainWindowsRect.bottom*3/10,0);
	if(m_wndSplitter3.CreateStatic(&m_wndSplitter1,1,2,WS_CHILD|WS_VISIBLE,m_wndSplitter1.IdFromRowCol(1,0))==NULL)
		return FALSE;		//�ڵ�2���н���2��
	if(!m_wndSplitter3.CreateView(0,0,RUNTIME_CLASS(CLocalView),CSize(rectMainWindowsRect.right*1/2,rectMainWindowsRect.bottom*3/10),pContext)||
		!m_wndSplitter3.CreateView(0,1,RUNTIME_CLASS(CWebView),CSize(rectMainWindowsRect.right*1/2,rectMainWindowsRect.bottom*3/10),pContext))
		return FALSE;		//���õ�2����2��
	if(!m_wndSplitter1.CreateView(2,0,RUNTIME_CLASS(CMessageView),
		CSize(rectMainWindowsRect.right,rectMainWindowsRect.bottom*4/10),pContext))
		return FALSE;		//���õ�����
	return TRUE;
	
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	cs.style = WS_OVERLAPPED | WS_CAPTION | FWS_ADDTOTITLE
		| WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_MAXIMIZE;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnButton1() 
{
	// TODO: Add your control notification handler code here
	int i;
	char temp[256];
	bLinkDataGood=false;
	bExitApp=false;
	iWebTryLoop=0;
	m_wndDlgBar.GetDlgItemText(IDC_FTPADD,csName);
	m_wndDlgBar.GetDlgItemText(IDC_FTPUSER,csUser);
	m_wndDlgBar.GetDlgItemText(IDC_FTPPASSWORD,csPassword);
	m_wndDlgBar.GetDlgItemText(IDC_WEBPATH,csWebPath);
	strcpy(temp,csWebPath);
	if(temp[0]=='\\'||temp[0]=='/')
	{
		for(i=0;i<255;i++)
		{
			temp[i]=temp[i+1];
		}
	}
	if(temp[strlen(temp)-1]=='\\'||temp[strlen(temp)-1]=='/')
	{
		temp[strlen(temp)-1]=0x00;
	}//ǿ�ƹ淶·��
	csWebPath.Format("%s",temp);
	strcpy(sProjectAttrib[iNowProjectNo][4],temp);
	m_wndDlgBar.SetDlgItemText(IDC_WEBPATH,temp);
	m_wndDlgBar.GetDlgItemText(IDC_LOCALPATH,csLocalPath);
	if(iTotalProject==0)
	{
		strcpy(sProjectAttrib[0][0],csName);
		strcpy(sProjectAttrib[0][1],csUser);
		strcpy(sProjectAttrib[0][2],csName);
		strcpy(sProjectAttrib[0][3],csPassword);
		strcpy(sProjectAttrib[0][4],csWebPath);
		strcpy(sProjectAttrib[0][5],csLocalPath);
		iTotalProject=1;
	}
	if((MyFtpLogoThread = AfxBeginThread(MyFtpLogoThreadFunction,this)) == NULL)
	{
		//����ʧ�ܴ���
		return;
	}
	else    //�����Ὠ��һ�������̲߳���ʱ�������
	{
		MyFtpLogoThread->SetThreadPriority(THREAD_PRIORITY_BELOW_NORMAL);
		MyFtpLogoThread->ResumeThread();//����CWinThread:: ResumeThreadʹ�߳̿�ʼ����
	}
}
 
void CMainFrame::OnCtlBreak() 
{
	// TODO: Add your command handler code here
	bExitApp=true;
	bAutoLoad=false;
	SetEvent(pLocalView->m_hPostEvent);//֪ͨLocalView�˳�ѭ��
}

BOOL CMainFrame::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	bLinkDataGood=false;
	bExitApp=true;
	if(pLocalView!=NULL)
	{
		if(pLocalView->m_hPostEvent)
		{
			SetEvent(pLocalView->m_hPostEvent);//֪ͨLocalView�˳�ѭ��
		}
	}
	if(pWebView!=NULL)
	{
		if(pWebView->m_hPostEvent)
		{
			SetEvent(pWebView->m_hPostEvent);//֪ͨWebView�˳�ѭ��
		}
	}

	//***************ȥ��������ͼ��
	NOTIFYICONDATA tnid; 
 	tnid.cbSize = sizeof(NOTIFYICONDATA); 
	tnid.hWnd = GetSafeHwnd();
	tnid.uID = WM_SCNOTIFYICON; 
	Shell_NotifyIcon(NIM_DELETE, &tnid); 
	//--------------------
	KillTimer(101);

	return CFrameWnd::DestroyWindow();
}

void CMainFrame::OnButtonExit() 
{
	// TODO: Add your command handler code here
	DestroyWindow();
	//PostMessage(WM_QUIT,0,0);
}


UINT MyFtpLogoThreadFunction(LPVOID lpParam)//char *cPath, char *cBasePath)
{
	bLinkDataGood=false;
	char temp[256];
	int i,j,k;
	if(bWebToLocal)//����Ǽ�¼�Ƚ�ģʽ
	{
		iTotalWebFile=0;
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"����������б�...");
		ResetEvent(pWebView->m_hPostEvent);
		pWebView->PostMessage(WM_MY_WEBLIST_DELETE,0,0);
		if(WaitForSingleObject(pWebView->m_hPostEvent,0xffffffff)==WAIT_TIMEOUT)
		{
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"��ʱ");
		}
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"\r\n");
		FILE *fo;
		int i,j,k,iTotal;
		strcpy(temp,sProjectAttrib[iNowProjectNo][2]);//�õ���ַ
		strcat(temp,sProjectAttrib[iNowProjectNo][1]);//�õ�����
		strcat(temp,".lst");
		fo=fopen(temp,"rb");
		if(fo==NULL)
		{
			//strcat(temp,"��ȡʧ��\r\n");
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"��ȡ��¼ʧ��,������ʷ�����\r\n");
		}
		else
		{
			fscanf(fo,"%d",&iTotal);
			for(i=0;i<iTotal;i++)
			{
				fscanf(fo,"%d",&k);
				fscanf(fo,"%c%c",&temp[0],&temp[1]);
				for(j=0;j<k;j++)
				{
					fscanf(fo,"%c",&temp[j]);
				}
				temp[j]=0x00;
				strcpy((char *)pWebView->m_csName,temp);
				//�õ�����
				fscanf(fo,"%d",&k);
				fscanf(fo,"%c%c",&temp[0],&temp[1]);
				for(j=0;j<k;j++)
				{
					fscanf(fo,"%c",&temp[j]);
				}
				temp[j]=0x00;
				strcpy((char *)pWebView->m_csTime,temp);
				//�õ�ʱ��
				fscanf(fo,"%d",&k);
				fscanf(fo,"%c%c",&temp[0],&temp[1]);
				for(j=0;j<k;j++)
				{
					fscanf(fo,"%c",&temp[j]);
				}
				temp[j]=0x00;
				strcpy((char *)pWebView->m_csSize,temp);
				//�õ���С
				fscanf(fo,"%d",&k);
				fscanf(fo,"%c%c",&temp[0],&temp[1]);
				for(j=0;j<k;j++)
				{
					fscanf(fo,"%c",&temp[j]);
				}
				temp[j]=0x00;
				strcpy((char *)pWebView->m_csPath,temp);
				//�õ�·��
				strcpy((char *)pWebView->m_csAttrib,"δ֪");
				//�õ�����
				iTotalWebFile++;
				ResetEvent(pWebView->m_hPostEvent);
				pWebView->PostMessage(WM_MY_WEBLIST_INSERT,0,0);
				if(WaitForSingleObject(pWebView->m_hPostEvent,0xffffffff)==WAIT_TIMEOUT)
				{
					pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"\r\n��ʱ");
				}
			}
			fclose(fo);
			sprintf(temp,"\r\n�����ļ��������ļ���%d��\r\n",
				iTotalWebFile);
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)temp);
			if(bAutoLoad)//�Զ�ģʽ
			{
				pWorkView->PostMessage(WM_MY_WORK_LISTNEW);
			}
			return 1;		 //�������������ʲ��˳��߳�
		}

	}
	CMainFrame *pMain=(CMainFrame*)lpParam;
	CString csMessage;
	bool bIsDir=false;
	bWebTry=false;
	if(bAutoDial)	//������Զ�����ģʽ
	{
		if(!Dial())//����ʧ��ѭ��
		{
			if(bAutoDialAgain)//ʧ���ز�ģʽ
			{
				for(i=0;i<iDialLoop;i++)
				{
					HangUp();
					csMessage.Format("\r\n����ʧ��,�ӳ�%d�����е�%d��(��%d��)����\r\n",iDialDelay,i+1,iDialLoop);
					pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
					::Sleep(iDialDelay*1000);
					if(Dial())
						break;
					if(bExitApp)
						break;
				}
				if(i>=iDialLoop)//��������
				{
					bAutoLoad=false;//�ر��Զ�ģʽ
					pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"����ʧ��");
					return 0;//�ر��˳��߳�
				}
			}
			else
			{
				bAutoLoad=false;//�ر��Զ�ģʽ
				pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"����ʧ��");
				return 0;//�ر��˳��߳�
			}
		}//���ųɹ�
	}
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"����������б�...");
	ResetEvent(pWebView->m_hPostEvent);
	pWebView->PostMessage(WM_MY_WEBLIST_DELETE,0,0);
	if(WaitForSingleObject(pWebView->m_hPostEvent,0xffffffff)==WAIT_TIMEOUT)
	{
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"��ʱ");
	}
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"\r\n");
	iTotalWebFile=0;
	iTotalWebDir=0;
	dwTotalWebFileLong=0;
	bWebTry=true;		//��������������
	HINTERNET hInetSession=InternetOpen("EasyFtp-SerchWeb",INTERNET_OPEN_TYPE_PRECONFIG,NULL,NULL,0);
	csMessage="��������->";
	csMessage+=csName;
	csMessage+="������\r\n";
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
	HINTERNET hFtpConn=InternetConnect(hInetSession,csName,21,
		csUser,csPassword,INTERNET_SERVICE_FTP,INTERNET_FLAG_PASSIVE,0);
	if(!hFtpConn)
	{
		csMessage=csName;
		csMessage+="������δ����\r\n";
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
		InternetCloseHandle(hInetSession);
		if(bWebAgain)//������ʧ������ģʽ
		{
			pMainFrame->PostMessage(WM_MY_WEBLOOP_LOGO);
		}
		else
		{
			bAutoLoad=false;	//�ر��Զ�ģʽ
		}
		return 0;//�ر��˳��߳�
	}
	bLinkDataGood=true;
	csMessage=csUser;
	csMessage+="�Ѿ��ɹ���¼";
	csMessage+=csName;
	csMessage+="������\r\n";
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
	
	::Sleep(1000);

	/////////////////////////
	//strcpy(sNowWebPath,"\\");
	//strcat(sNowWebPath,csWebPath);
	char cWebTruePath[256];
	//char temp[256];
	char temp2[256];
	char *ptemp;
	char tempPath[256];
	strcpy(tempPath,csWebPath);
loop:
	strcpy(sNowWebPath,tempPath);
	strcpy(temp,tempPath);
	if(temp[0]!='\\')
	{
		strcpy(temp,"\\");
		strcat(temp,tempPath);
	}
	ptemp=temp;
	strcpy(temp2,ptemp+1);
	if(strcmp(temp2,"")!=0)
	{
		int kkk=strlen(temp2);
		temp2[kkk]='\\';
		temp2[kkk+1]=0x00;
	}
	strcpy(cWebTruePath,temp2);
	strcpy(temp2,csWebPath);
	if(strcmp(temp2,"")==0)//û��·����ָ�
	{
		strcpy(temp2,cWebTruePath);
	}
	else	//ȥ������·��
	{
		i=strlen(temp2);
		j=strlen(cWebTruePath);
		for(k=0;k<(j-i-1);k++)
		{
			cWebTruePath[k]=cWebTruePath[k+i+1];
		}
		cWebTruePath[k]=0x00;
		strcpy(temp2,cWebTruePath);
	}
	strcpy((char *)pWebView->m_csPath,temp2);
	if(strcmp(temp,"\\")!=0)
	{
		csMessage="\r\n����Ŀ¼->";
		csMessage+=temp;
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
		for(unsigned int i=0;i<(strlen(temp)+1);i++)
		{
			cWebTruePath[i]=temp[i];
			if(cWebTruePath[i]=='\\')
			{
				cWebTruePath[i]='/';
			}
		}
		if(FtpSetCurrentDirectory(hFtpConn,cWebTruePath))
		{
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)" �ɹ�\r\n");;
			ptemp=temp;
			strcpy(sNowWebPath,temp);
			strcat(sNowWebPath,"\\");
		}
		else//����������ʧ��
		{
			bLinkDataGood=false;
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"ʧ��\r\n���ӹر�\r\n");
			InternetCloseHandle(hFtpConn);
			InternetCloseHandle(hInetSession);//�ر�����
			if(bWebAgain)//������ʧ������ģʽ
			{
				pMainFrame->PostMessage(WM_MY_WEBLOOP_LOGO);
			}
			else
			{
				bAutoLoad=false;	//�ر��Զ�ģʽ
			}
			return 0;//�ر��˳��߳�
		}
		/*
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"ĿǰĿ¼:");
		if(FtpGetCurrentDirectory(hFtpConn,temp,&dwLength))
		{
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)temp);
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"\r\n");
		}
		else
		{
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"δ֪\r\n");
		}*/
	}
	FILETIME fileTime;
	HINTERNET hFind;
	WIN32_FIND_DATA findData;
	CString szFile;
//	DWORD dwLength;
	//FtpGetCurrentDirectory(hFtpConn,NULL,&dwLength);
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"���ڼ��������ļ�...");
	strcpy((char *)pWebView->m_csAttrib,"δ֪");
	hFind=FtpFindFirstFile(hFtpConn,_T("*"),&findData,
		INTERNET_FLAG_RELOAD,0);
	if(!(hFind))
	{
		if (GetLastError()  == ERROR_NO_MORE_FILES) 
		{
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"Ŀ¼Ϊ�գ�û�ж��������");
			goto end;
		}
		else		//��ֹ���ļ�����
		{
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"�ļ����ҳ�����δ֪ԭ��\r\n");
			InternetCloseHandle(hFind);
			if(bWebAgain)//����������ģʽ
			{
				InternetCloseHandle(hFtpConn);
				InternetCloseHandle(hInetSession);//�ر�����
				pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"�����Ѿ��ر�\r\n");
				bLinkDataGood=false;
				pMainFrame->PostMessage(WM_MY_WEBLOOP_LOGO);
				return 0;
			}
			else
			{
				bAutoLoad=false;
				goto ok;
			}
		}
	}
	do{
		if(bExitApp)
			break;
		szFile=findData.cFileName;
		csMessage="\r\n�ļ���";
		csMessage+=szFile;
		strcpy((char *)pWebView->m_csName,szFile);
		fileTime=findData.ftLastWriteTime;
		CTime time=CTime(fileTime);
		CString str;
		str.Format("%04d-%02d-%02d %02d:%02d",time.GetYear(),
			time.GetMonth(),time.GetDay(),time.GetHour()-8,time.GetMinute());
		csMessage+="�ļ�ʱ��";
		csMessage+=str;
		strcpy((char *)pWebView->m_csTime,str);
		bIsDir=false;
		if(findData.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)
		{
			bIsDir=true;
			iTotalWebDir+=1;
			csMessage+=" <Ŀ¼>";
			strcpy(sWebPathNeedSerch[iPathNo],sNowWebPath);
			//AfxMessageBox(findData.cFileName);
			//AfxMessageBox(sNowWebPath);
			strcat(sWebPathNeedSerch[iPathNo++],findData.cFileName);
			//AfxMessageBox(sWebPathNeedSerch[iPathNo-1]);
		}
		else//�ҵ��ļ�
		{
			iTotalWebFile+=1;
			dwTotalWebFileLong+=findData.nFileSizeLow;
			DWORD i=findData.nFileSizeLow;
			str.Format("%ld",i);
			csMessage+="�ļ���С";
			csMessage+=str;
			strcpy((char *)pWebView->m_csSize,str);
		}
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);

		if(!bIsDir)
		{
			ResetEvent(pWebView->m_hPostEvent);
			pWebView->PostMessage(WM_MY_WEBLIST_INSERT,0,0);
			if(WaitForSingleObject(pWebView->m_hPostEvent,0xffffffff)==WAIT_TIMEOUT)
			{
				pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"\r\n��ʱ");
			}
		}
	}
	while(InternetFindNextFile(hFind,&findData));
end:InternetCloseHandle(hFind);
	if(iPathNo>0)
	{
		if(bExitApp)
		{
			goto ok;
		}
		else
		{
			strcpy(tempPath,sWebPathNeedSerch[--iPathNo]);
			goto loop;
		}
	}
ok:
	csMessage.Format("\r\n�����ļ��������ļ���%d����Ŀ¼��%d������%ld�ֽ�\r\n",
		iTotalWebFile,iTotalWebDir,dwTotalWebFileLong);
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
	::Sleep(1000);
	InternetCloseHandle(hFtpConn);
	InternetCloseHandle(hInetSession);//�ر�����
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"�����Ѿ��ر�\r\n");
	bLinkDataGood=false;
	if(bAutoLoad)//�Զ�ģʽ
	{
		pWorkView->PostMessage(WM_MY_WORK_LISTNEW);
	}
	return 1;
}


void CMainFrame::OnCtlHuangup() 
{
	// TODO: Add your command handler code here
	HangUp();
}

void CMainFrame::OnUpdateProject(WPARAM wParam, LPARAM lParam)
{
	m_wndDlgBar.SetDlgItemText(IDC_FTPADD,sProjectAttrib[iNowProjectNo][2]);
	m_wndDlgBar.SetDlgItemText(IDC_FTPUSER,sProjectAttrib[iNowProjectNo][1]);
	m_wndDlgBar.SetDlgItemText(IDC_FTPPASSWORD,sProjectAttrib[iNowProjectNo][3]);
	m_wndDlgBar.SetDlgItemText(IDC_WEBPATH,sProjectAttrib[iNowProjectNo][4]);
	m_wndDlgBar.SetDlgItemText(IDC_LOCALPATH,sProjectAttrib[iNowProjectNo][5]);
}

void CMainFrame::OnChangeFtpadd() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFrameWnd::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	CString te;
	m_wndDlgBar.GetDlgItemText(IDC_FTPADD,te);
	strcpy(sProjectAttrib[iNowProjectNo][2],te);
	// TODO: Add your control notification handler code here
}

void CMainFrame::OnChangeFtpuser() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFrameWnd::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	CString te;
	m_wndDlgBar.GetDlgItemText(IDC_FTPUSER,te);
	strcpy(sProjectAttrib[iNowProjectNo][1],te);
	// TODO: Add your control notification handler code here
	
}

void CMainFrame::OnChangeFtppassword() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFrameWnd::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	CString te;
	m_wndDlgBar.GetDlgItemText(IDC_FTPPASSWORD,te);
	strcpy(sProjectAttrib[iNowProjectNo][3],te);
	// TODO: Add your control notification handler code here
}

void CMainFrame::OnChangeLocalpath() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFrameWnd::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	CString te;
	m_wndDlgBar.GetDlgItemText(IDC_LOCALPATH,te);
	strcpy(sProjectAttrib[iNowProjectNo][5],te);
	// TODO: Add your control notification handler code here
}

void CMainFrame::OnChangeWebpath() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFrameWnd::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	CString te;
	m_wndDlgBar.GetDlgItemText(IDC_WEBPATH,te);
	strcpy(sProjectAttrib[iNowProjectNo][4],te);
	// TODO: Add your control notification handler code here
}



UINT MyFtpUpThreadFunction(LPVOID lpParam)//char *cPath, char *cBasePath)
{
	int iTotal;
	CString csMessage;
	int i,iError=0;
	char temp1[256],temp2[256],temp[256],*ptemp;
	if(!bMUpThread)//�Ƕ��߳�ģʽ
	{
		HINTERNET hInetSession;
		HINTERNET hFtpConn;
		bLinkDataGood=false;
		bWebTry=false;		//�������������
		iTotal=pWorkView->m_WorkList.GetItemCount();
		if(iTotal<=0)
		{
			if(bAutoLoad)
			{
				if(bAutoHangUp)
				{
					HangUp();
				}
				bAutoLoad=false;
			}
			//MyFtpUpThreadEnd();
			return 0;
		}
		bWebTry=true;		//��������������
		hInetSession=InternetOpen("EasyFtp-UpData",INTERNET_OPEN_TYPE_PRECONFIG,NULL,NULL,0);
		csMessage="��������->";
		csMessage+=csName;
		csMessage+="������\r\n";
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
		hFtpConn=InternetConnect(hInetSession,csName,21,
			csUser,csPassword,INTERNET_SERVICE_FTP,INTERNET_FLAG_PASSIVE,0);
		if(!hFtpConn)
		{
			csMessage=csName;
			csMessage+="������δ����\r\n";
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
			InternetCloseHandle(hInetSession);
			::Sleep(10);
			//MyFtpUpThreadEnd();
			return 0;
		}
		csMessage=csUser;
		csMessage+="�Ѿ��ɹ���¼";
		csMessage+=csName;
		csMessage+="������\r\n";
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
		bLinkDataGood=true;
		::Sleep(1000);
		for(i=0;i<iTotal;i++)
		{
			strcpy(temp1,csLocalPath);
			strcat(temp1,"\\");
			strcat(temp1,pWorkView->m_WorkList.GetItemText(i,3));
			strcat(temp1,pWorkView->m_WorkList.GetItemText(i,0));
			///AfxMessageBox(temp1);
			strcpy(temp2,"/");
			strcat(temp2,csWebPath);
			if(strcmp(temp2,"/")==0)
			{
			}
			else
			{
				strcat(temp2,"/");
			}
			strcat(temp2,pWorkView->m_WorkList.GetItemText(i,3));
			strcat(temp2,pWorkView->m_WorkList.GetItemText(i,0));
			for(unsigned int j=0;j<(strlen(temp2)+1);j++)
			{
				if(temp2[j]=='\\')
				{
					temp2[j]='/';
				}
			}
			strcpy(temp,strlwr(temp1));
			strcpy(temp1,temp);
			//ǿ��Сд
			strcpy(temp,strlwr(temp2));
			strcpy(temp2,temp);
			//ǿ��Сд
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"���ڷ����ļ�:");
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)temp1);
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"->");
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)temp2);
			//AfxMessageBox(temp2);
putfileagain:
			bLinkDataGood=true;
			if(FtpPutFile(hFtpConn,temp1,temp2,INTERNET_FLAG_TRANSFER_BINARY ,0))
			{
				pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"--OK\r\n");
				pWorkView->m_WorkList.SetItemText(i,5,"���");
			}
			else
			{
				if(GetLastError()==12003)//·���Ƿ�
				{
					strcpy(temp,temp2);
					ptemp=strrchr(temp,'/');
					if(ptemp)
					{
						temp[strlen(temp)-strlen(ptemp)]=0x00;
						if(FtpCreateDirectory(hFtpConn,temp))
							goto putfileagain;
						//����Ŀ¼
					}
					
				}
				else//����Ŀ¼����
				{		//ʧ������
					if((iError++)<iWebTryLoop)
					{
						pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"\r\n����  ");
						goto putfileagain;
					}
				}
				bLinkDataGood=false;
				pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"--ʧ��\r\n");
				pWorkView->m_WorkList.SetItemText(i,5,"ʧ��");
			}
		}
		bLinkDataGood=false;
		InternetCloseHandle(hFtpConn);
		////////////////////////////////
		InternetCloseHandle(hInetSession);//�ر�����
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"�����Ѿ��ر�\r\n");
		bWebTry=false;
		iTotal=pWorkView->m_WorkList.GetItemCount();
		if(bWebAgain&&iTotal>0)//��������
		{
			for(i=0;i<iTotal;i++)
			{
				strcpy(temp,pWorkView->m_WorkList.GetItemText(i,5));
				if(strcmp("���",temp)!=0)
				{
					bWebTry=true;
				}
				else//����ɵ�ȥ��
				{
					pWorkView->m_WorkList.DeleteItem(i);
					iTotal-=1;
					i-=1;
				}
			}
		}
		if(bWebTry)//��Ҫ����
		{
			//MyFtpUpThreadEnd();
			return 0;
		}
		bLinkDataGood=false;
		if(bAutoHangUp)
		{
			HangUp();
		}
		bAutoLoad=false;
		bWebTry=false;		//�������������
//		MyFtpUpThreadEnd();
		return 1;
	}//��ͨģʽ
	else//���߳�ģʽ*******************!!!!!!!!!!!!!
	{
		iMThreadWorkTotal=pWorkView->m_WorkList.GetItemCount();
		//�õ������������
		bLinkDataGood=false;
		if(bAutoDial&&(iMThreadWorkTotal>0))
			//������Զ�����ģʽ��������
		{
			if(!Dial())//����ʧ��ѭ��
			{
				int i;
				if(bAutoDialAgain)//ʧ���ز�ģʽ
				{
					for(i=0;i<iDialLoop;i++)
					{
						HangUp();
						csMessage.Format("\r\n����ʧ��,�ӳ�%d�����е�%d��(��%d��)����\r\n",iDialDelay,i+1,iDialLoop);
						pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
						::Sleep(iDialDelay*1000);
						if(Dial())
							break;
						if(bExitApp)
							break;
					}
					if(i>=iDialLoop)//��������
					{
						bAutoLoad=false;//�ر��Զ�ģʽ
						pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"����ʧ��");
						return 0;//�ر��˳��߳�
					}
				}
				else
				{
					bAutoLoad=false;//�ر��Զ�ģʽ
					pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"����ʧ��");
					return 0;//�ر��˳��߳�
				}
			}//���ųɹ�
		}//���Ŵ������
		for(i=0;i<5;i++)
		{
			bMThreadWorkReady[i]=true;//��ʼ���߳̿���
		}
		iMThreadWorkNowNo=0;	//��ǰ�Ѿ�������������
		if(iMThreadWorkTotal<=0)//û�и��������
		{
			bLinkDataGood=false;
			//�����������********************
			pWebView->PostMessage(WM_MY_WEB_TOLOCAL,0,(LPARAM)-1);
			//****************************
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"\r\n�ϴ����\r\n");
			if(bAutoHangUp)//��Ҫ�Զ��Ҷ�
			{
				HangUp();
			}
			::Sleep(iDialDelay*1000);//�ȴ������

			if(bShutDownWhenFinish)//��ɺ�رռ����
			{
				pMainFrame->PostMessage(WM_MY_SHUTDOWN);
			}
			if(bQuitWhenFinish)	//��ɺ��˳�
			{
				pMainFrame->PostMessage(WM_MY_APP_EXIT);
			}
			return 0;
		}
		//��������Ҫ���
		for(i=0;i<iMThreadMax;i++)
		{
			if(bMThreadWorkReady[i]&&(iMThreadWorkNowNo<iMThreadWorkTotal))
			//������,�ҹ����߳��п�
			{
				bMThreadWorkReady[i]=false;//��д�߳�æ��־
				//��ʼ����,�����ݹ���������̺߳���(Ԥ��10��)
				if((MyMUpThread[i] = AfxBeginThread(MyMUpThreadFunction,(LPVOID)((iMThreadWorkNowNo++)*10+i))) == NULL)
				{
					AfxMessageBox("�߳�ʧ�ܴ���");
					//����ʧ�ܴ���
					return 0;
				}
				else    //��������һ�������̲߳���ʱ�������
				{
					MyMUpThread[i]->SetThreadPriority(THREAD_PRIORITY_BELOW_NORMAL);
					MyMUpThread[i]->ResumeThread();//����CWinThread:: ResumeThreadʹ�߳̿�ʼ����
				}
			}
		}
		return 1;
	}
}


void CMainFrame::OnCtlFtpup() 
{
	// TODO: Add your command handler code here
	iWebTryLoop=0;
	bExitApp=false;
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"\r\n׼���ϴ�\r\n");
	if((MyFtpUpThread = AfxBeginThread(MyFtpUpThreadFunction,this)) == NULL)
	{
		//����ʧ�ܴ���
		return;
	}
	else    //�����Ὠ��һ�������̲߳���ʱ�������
	{
		MyFtpUpThread->SetThreadPriority(THREAD_PRIORITY_BELOW_NORMAL);
		MyFtpUpThread->ResumeThread();//����CWinThread:: ResumeThreadʹ�߳̿�ʼ����
	}
}

void CMainFrame::OnCtlDial() 
{
	// TODO: Add your command handler code here
	if((MyDialThread = AfxBeginThread(MyDialThreadFunction,0)) == NULL)
	{
		//����ʧ�ܴ���
		return ;
	}
	else    //�����Ὠ��һ�������̲߳���ʱ�������
	{
		MyDialThread->SetThreadPriority(THREAD_PRIORITY_BELOW_NORMAL);
		MyDialThread->ResumeThread();//����CWinThread:: ResumeThreadʹ�߳̿�ʼ����
	}
}

bool Dial()
{
	CString csMessage;
	DWORD dwLength=MAX_PATH;
	RASCONN ras[20];
	DWORD  dSize, dNumber;
	char  szBuf[256];
	ras[0].dwSize = sizeof( RASCONN );
	dSize = sizeof( ras );   // Get active RAS - Connection
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"�������״̬...");
	DWORD  dwRet = RasEnumConnections( ras, &dSize, &dNumber );
	if ( dwRet != 0 )
	{
		if ( RasGetErrorString( (UINT)dwRet, (LPSTR)szBuf, 256 ) != 0 )
			wsprintf( (LPSTR)szBuf, "�Ҷ�ʱ����δ֪�Ĵ���(%ld).", dwRet );
		csMessage=szBuf;
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
		return false;
	}//�о����ߵ�����
	if(dNumber==0)
	{
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"������\r\n���ڽ��в�������...");
		RASDIALPARAMS rdParams;			//������������
		rdParams.dwSize = sizeof(RASDIALPARAMS);
		rdParams.szEntryName[0] = '\0';
		lstrcpy( rdParams.szPhoneNumber, sDialNumber);//��д�绰����
		rdParams.szCallbackNumber[0] = '\0';
		lstrcpy( rdParams.szUserName, sDialUser);//��д�û���
		lstrcpy( rdParams.szPassword, sDialPassword);//��д�������
		rdParams.szDomain[0] = '\0';
		HRASCONN hRasConn = NULL;
		DWORD dwRet = RasDial( NULL, NULL, &rdParams, 0L, NULL, &hRasConn );
		if ( dwRet == 0 )
		{
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"������������ɹ�\r\n");
		}	//���ӳɹ�
		else
		{
			if ( RasGetErrorString( (UINT)dwRet, (LPSTR)szBuf, 256 ) != 0 )
				wsprintf( (LPSTR)szBuf, "����ʱ����δ֪�Ĵ���(%ld).", dwRet );
			RasHangUp( hRasConn );
			//MessageBox( (LPSTR)szBuf, "����", MB_OK | MB_ICONSTOP );
			csMessage=szBuf;
			csMessage+="\r\n";
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
			return false;
		}
		
	}
	else
	{
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"�Ѿ�����\r\n");
		return true;
	}
	return true;
}

bool HangUp()
{
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"׼���Ҷϲ�������");
	//bExitApp=true;
	//MyFtpLogoThreadEnd();
	RASCONN ras[20];
	DWORD  dSize, dNumber,dwRet;
	char  szBuf[256];
	ras[0].dwSize = sizeof( RASCONN );
	dSize = sizeof( ras );   // Get active RAS - Connection
	dwRet = RasEnumConnections( ras, &dSize, &dNumber );
	if ( dwRet != 0 )
	{
		if ( RasGetErrorString( (UINT)dwRet, (LPSTR)szBuf, 256 ) != 0 )
			wsprintf( (LPSTR)szBuf, "�Ҷ�ʱ����δ֪�Ĵ���(%ld).", dwRet );
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)szBuf);
		return false;
	}//�о����ߵ�����
	if(dNumber==0)
	{
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"�������Ӳ�����");
		return false;
	}
	for( DWORD dCount = 0;  dCount < dNumber;  dCount++ )
	{    // Hang up that connection
		HRASCONN hRasConn = ras[dCount].hrasconn;
		DWORD dwRet = RasHangUp( hRasConn );
		if ( dwRet != 0 )
		{
			char  szBuf[256];
			if ( RasGetErrorString( (UINT)dwRet, (LPSTR)szBuf, 256 ) != 0 )
				wsprintf( (LPSTR)szBuf, "�Ҷ�ʱ����δ֪�Ĵ���(%ld).", dwRet );
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)szBuf);
			return false;
		}
	}//�Ҷ���������
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"���������Ѿ��Ҷ�");
	return true;
}


void CMainFrame::OnCtlSetting() 
{
	// TODO: Add your command handler code here
	CSettingBox setbox;
	setbox.m_AutoDial=bAutoDial;
	setbox.m_AutoHangUp=bAutoHangUp;
	setbox.m_DialAgain=bAutoDialAgain;//����ʧ�ܼ����ز�
	setbox.m_DialWhenHangUp=bDialWhenHangUp;//��Ҫʱ�򲦺�
	setbox.m_DialLoop=iDialLoop;			//����ʧ�ܴ���
	setbox.m_DialDelay=iDialDelay;			//����ʧ���ӳ�
	setbox.m_WebAgain=bWebAgain;		//������ʧ������
	setbox.m_WebLoop=iWebLoop;				//������ʧ�����Դ���
	setbox.m_MUpThread=bMUpThread;		//��������ϴ��߳�
	setbox.m_MThreadNo=iMThreadMax;//�������߳����ֵ
	setbox.m_WebToLocal=bWebToLocal;	//ֱ�Ӽ�¼�Ƚ�
	setbox.m_AutoQuit=bQuitWhenFinish;
	setbox.m_AutoShutDown=bShutDownWhenFinish;
	setbox.m_CmpTime=bCmpTime;
	setbox.m_Number.Format("%s",sDialNumber);
	setbox.m_User.Format("%s",sDialUser);
	setbox.m_Passwrod.Format("%s",sDialPassword);
	if(setbox.DoModal()==IDOK)
	{
		bAutoDial=setbox.m_AutoDial;
		bAutoHangUp=setbox.m_AutoHangUp;
		bCmpTime=setbox.m_CmpTime;
		strcpy(sDialNumber,setbox.m_Number);
		strcpy(sDialUser,setbox.m_User);
		strcpy(sDialPassword,setbox.m_Passwrod);
		bAutoDialAgain=setbox.m_DialAgain;//����ʧ�ܼ����ز�
		bDialWhenHangUp=setbox.m_DialWhenHangUp;//��Ҫʱ�򲦺�
		iDialLoop=setbox.m_DialLoop;			//����ʧ�ܴ���
		iDialDelay=setbox.m_DialDelay;			//����ʧ���ӳ�
		bWebAgain=setbox.m_WebAgain;		//������ʧ������
		iWebLoop=setbox.m_WebLoop;			//������ʧ�����Դ���
		bMUpThread=setbox.m_MUpThread;		//��������ϴ��߳�
		iMThreadMax=setbox.m_MThreadNo;//�������߳����ֵ
		bWebToLocal=setbox.m_WebToLocal;	//ֱ�Ӽ�¼�Ƚ�
		bQuitWhenFinish=setbox.m_AutoQuit;
		bShutDownWhenFinish=setbox.m_AutoShutDown;
	}
}

void CMainFrame::OnCtlAutoload() 
{
	// TODO: Add your command handler code here
	iWebTryLoop=0;
	bAutoLoad=true;
	bCmpNow=false;
	pLocalView->PostMessage(WM_MY_PROJECT_PATH,0,(LPARAM)sProjectAttrib[iNowProjectNo][5]);
	//OnButton1();
}

void CMainFrame::OnAutoLoad(WPARAM wParam, LPARAM lParam)
{
	bExitApp=false;
	OnCtlFtpup();
}

void CMainFrame::OnAutoLink(WPARAM wParam, LPARAM lParam)
{
	OnButton1();
}

void CMainFrame::OnCtlCmp() 
{
	// TODO: Add your command handler code here
	bAutoLoad=false;
	bCmpNow=true;
	pLocalView->PostMessage(WM_MY_PROJECT_PATH,0,(LPARAM)sProjectAttrib[iNowProjectNo][5]);	
}


UINT MyDialThreadFunction(LPVOID lpParam)
{
	CString csMessage;
	int i;
	if((!Dial())&&bAutoDialAgain)
	{
		for(i=0;i<iDialLoop;i++)
		{
			HangUp();
			csMessage.Format("\r\n����ʧ��,�ӳ�%d�����е�%d��(��%d��)����\r\n",iDialDelay,i+1,iDialLoop);
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
			::Sleep(iDialDelay*1000);
			if(Dial())
				break;
			if(bExitApp)
				break;
		}
		if(i>=iDialLoop)
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"\r\n����ʧ��\r\n");
		else//���ųɹ�
		{
			if(bAutoLoad)
			{
				pMainFrame->PostMessage(WM_MY_WEBLOOP_LOGO);
			}
		}
	}
	return 0;//�ر��˳��߳�
}

void CMainFrame::OnProjectAdd() 
{
	// TODO: Add your command handler code here
	CProjectName NameBox;
	NameBox.m_Name.Format("�½���Ŀ���%02d",iTotalProject+1);
	NameBox.m_WebAdd="ftp.your.com";
	NameBox.m_WebPath="";
	NameBox.m_User="webmastername";
	NameBox.m_Passwrod="12345678";
	NameBox.m_LocalPath="c:\\temp";
	if(NameBox.DoModal()==IDOK)
	{
		iNowProjectNo=iTotalProject++;
		strcpy(sProjectAttrib[iNowProjectNo][0],NameBox.m_Name);
		strcpy(sProjectAttrib[iNowProjectNo][1],NameBox.m_User);
		strcpy(sProjectAttrib[iNowProjectNo][2],NameBox.m_WebAdd);
		strcpy(sProjectAttrib[iNowProjectNo][3],NameBox.m_Passwrod);
		strcpy(sProjectAttrib[iNowProjectNo][4],NameBox.m_WebPath);
		strcpy(sProjectAttrib[iNowProjectNo][5],NameBox.m_LocalPath);
//		m_wndDlgBar.SetDlgItemText(IDC_FTPADD,sProjectAttrib[iNowProjectNo][2]);
//		m_wndDlgBar.SetDlgItemText(IDC_FTPUSER,sProjectAttrib[iNowProjectNo][1]);
//		m_wndDlgBar.SetDlgItemText(IDC_FTPPASSWORD,sProjectAttrib[iNowProjectNo][3]);
//		m_wndDlgBar.SetDlgItemText(IDC_WEBPATH,sProjectAttrib[iNowProjectNo][4]);
//		m_wndDlgBar.SetDlgItemText(IDC_LOCALPATH,sProjectAttrib[iNowProjectNo][5]);
		pProjectTree->PostMessage(WM_MY_PROJECT_ADD);
	}
}

void CMainFrame::OnProjectDelete() 
{
	// TODO: Add your command handler code here
	if(MessageBox("ȷʵҪ����ǰ��ѡ����Ŀɾ��?","ȷ��ɾ����Ŀ",MB_YESNO)==IDYES)
	{
		pProjectTree->PostMessage(WM_MY_PROJECT_DELETE);
	}
}

void CMainFrame::OnMyExit(WPARAM wParam, LPARAM lParam)
{
	DestroyWindow();
}

void CMainFrame::OnWebLogoLoop(WPARAM wParam, LPARAM lParam)
{
	CString csMessage;
	csMessage.Format("��������%d������(��%d��)\r\n",iWebTryLoop,iWebLoop);
	if((iWebTryLoop++)<iWebLoop)
	{
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
		if((MyFtpLogoThread = AfxBeginThread(MyFtpLogoThreadFunction,0)) == NULL)
		{
			//����ʧ�ܴ���
			return;
		}
		else    //�����Ὠ��һ�������̲߳���ʱ�������
		{
			MyFtpLogoThread->SetThreadPriority(THREAD_PRIORITY_BELOW_NORMAL);
			MyFtpLogoThread->ResumeThread();//����CWinThread:: ResumeThreadʹ�߳̿�ʼ����
		}
	}
	else//�������
	{
		bAutoLoad=false;
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"����������ʧ��\r\n");
		if(bAutoHangUp)//��Ҫ�Զ��Ҷ�
		{
			HangUp();
		}
		if(bShutDownWhenFinish)//��ɺ�رռ����
		{
			PostMessage(WM_MY_SHUTDOWN);
		}
		///�����ʱ���˳�����
		//if(bQuitWhenFinish)	//��ɺ��˳�
		//{
		//	pMainFrame->PostMessage(WM_MY_APP_EXIT);
		//}
	}
}


void CMainFrame::OnWebUpLoop(WPARAM wParam, LPARAM lParam)
{
	CString csMessage;
	csMessage.Format("��������%d������(��%d��)\r\n",iWebTryLoop,iWebLoop);
	if((iWebTryLoop++)<iWebLoop)
	{
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
		
		if((MyFtpUpThread = AfxBeginThread(MyFtpUpThreadFunction,0)) == NULL)
		{
			//����ʧ�ܴ���
			return;
		}
		else    //�����Ὠ��һ�������̲߳���ʱ�������
		{
			MyFtpUpThread->SetThreadPriority(THREAD_PRIORITY_BELOW_NORMAL);
			MyFtpUpThread->ResumeThread();//����CWinThread:: ResumeThreadʹ�߳̿�ʼ����
		}
	}
	else//�������
	{
		bAutoLoad=false;
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"����������ʧ��\r\n");
		if(bAutoHangUp)//��Ҫ�Զ��Ҷ�
		{
			HangUp();
		}
		if(bShutDownWhenFinish)//��ɺ�رռ����
		{
			PostMessage(WM_MY_SHUTDOWN);
		}
		///�����ʱ���˳�����
		//if(bQuitWhenFinish)	//��ɺ��˳�
		//{
		//	pMainFrame->PostMessage(WM_MY_APP_EXIT);
		//}
	}
}


void CMainFrame::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	switch(nIDEvent)
	{
	case 101:
		///��������ͼ��****************
		if((!bLinkDataGood))
		{
			if(iIconNumber!=99)
			{
				iIconNumber=99;
				NOTIFYICONDATA tnid; 
				tnid.cbSize = sizeof(NOTIFYICONDATA); 
				tnid.hWnd = GetSafeHwnd();
				tnid.uID = WM_SCNOTIFYICON; 
				tnid.uFlags = NIF_TIP|NIF_ICON; 
				memset(tnid.szTip, 0, 32);
				lstrcpy(tnid.szTip, "EasyFtp�I");//��ʾ������ʾ
				tnid.hIcon = AfxGetApp()->LoadIcon(IDI_ICON1);
				Shell_NotifyIcon(NIM_MODIFY, &tnid); 
			}
		}
		else
		{
			NOTIFYICONDATA tnid; 
			tnid.cbSize = sizeof(NOTIFYICONDATA); 
			tnid.hWnd = GetSafeHwnd();
			tnid.uID = WM_SCNOTIFYICON; 
			tnid.uFlags = NIF_TIP|NIF_ICON; 
			memset(tnid.szTip, 0, 32);
			lstrcpy(tnid.szTip, "EasyFtp�I");//��ʾ������ʾ
			switch(iIconNumber)
			{
			case 0:
				tnid.hIcon = AfxGetApp()->LoadIcon(IDI_ICON2);
				iIconNumber++;
				break;
			case 1:
				tnid.hIcon = AfxGetApp()->LoadIcon(IDI_ICON3);
				iIconNumber++;
				break;
			case 2:
				tnid.hIcon = AfxGetApp()->LoadIcon(IDI_ICON4);
				iIconNumber=0;
				break;
			default:
				tnid.hIcon = AfxGetApp()->LoadIcon(IDI_ICON2);
				iIconNumber=0;
				break;
			}
			Shell_NotifyIcon(NIM_MODIFY, &tnid); 
		}
		////***********���
		break;
	default:
		break;
	}
	CFrameWnd::OnTimer(nIDEvent);
}


UINT MyMUpThreadFunction(LPVOID lpParam)
{
	HINTERNET hInetSession;
	HINTERNET hFtpConn;
	CString csMessage;
	unsigned int j;
	int i;
	int iNowNo=(int)lpParam/10;	//ȡ���������
	int iThreadNo=(int)lpParam%10;//ȡ���̺߳���
	int iErrorLoopTime=0;		//ÿ������ʧ����������
	char temp1[256],temp2[256],temp[256],*ptemp;
	csMessage.Format("�߳�%d��ʼ%s�ļ����ϴ�����\r\n",iThreadNo,pWorkView->m_WorkList.GetItemText(iNowNo,0));
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
	pWorkView->m_WorkList.SetItemText(iNowNo,5,"�ϴ�");
MThreadLink:
	csMessage.Format("EasyFtp-UpThread%02d-%02d",iThreadNo,iErrorLoopTime);
	hInetSession=InternetOpen(csMessage,INTERNET_OPEN_TYPE_PRECONFIG,NULL,NULL,0);
	csMessage="";
	hFtpConn=InternetConnect(hInetSession,csName,21,
		csUser,csPassword,INTERNET_SERVICE_FTP,INTERNET_FLAG_PASSIVE,0);
	if(!hFtpConn)
	{
		while(!(InternetCloseHandle(hInetSession)))
		{
			csMessage.Format("�߳�%d����û�йر�,�ȴ�...\r\n",iThreadNo);
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
			if(bExitApp)
				return 0;
		}
		if(iErrorLoopTime<iWebLoop)
		{
			iErrorLoopTime++;
			csMessage.Format("�߳�%d����ʧ��,���ڵ�%d��(��%d��)����\r\n",iThreadNo,iErrorLoopTime,iWebLoop);
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
			goto MThreadLink;
		}
		//csMessage.Format("�߳�%d���ӷ���,������һ������\r\n",iThreadNo);
		csMessage.Format("�߳�%d���ӷ���,�������ڷ�����æ,���߳���ͣ\r\n",iThreadNo);
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
		pWorkView->m_WorkList.SetItemText(iNowNo,5,"����");
		//if(iMThreadWorkNowNo<iMThreadWorkTotal)//��������û�з���
		//{
		//	iNowNo=iMThreadWorkNowNo++;
		//	pWorkView->m_WorkList.SetItemText(iNowNo,5,"�ϴ�");
		//	iErrorLoopTime=0;		//����������
		//	goto MThreadLink;	//�½���������
		//}
		//else//û��������Է���
		//{
			bMThreadWorkReady[iThreadNo]=true;	//�߳̿���
			goto MThreadOK;
		//}
	}
	bLinkDataGood=true;
MThreadSendNext:
	strcpy(temp1,csLocalPath);
	strcat(temp1,"\\");
	strcat(temp1,pWorkView->m_WorkList.GetItemText(iNowNo,3));
	strcat(temp1,pWorkView->m_WorkList.GetItemText(iNowNo,0));
	strcpy(temp2,"/");
	strcat(temp2,csWebPath);
	if(strcmp(temp2,"/")==0)
	{
	}
	else
	{
		strcat(temp2,"/");
	}
	strcat(temp2,pWorkView->m_WorkList.GetItemText(iNowNo,3));
	strcat(temp2,pWorkView->m_WorkList.GetItemText(iNowNo,0));
	for(j=0;j<(strlen(temp2)+1);j++)
	{
		if(temp2[j]=='\\')
		{
			temp2[j]='/';
		}
	}
	strcpy(temp,strlwr(temp1));
	strcpy(temp1,temp);
	//ǿ��Сд
	strcpy(temp,strlwr(temp2));
	strcpy(temp2,temp);
	//ǿ��Сд
mtputfileagain:
	bLinkDataGood=true;
	if(FtpPutFile(hFtpConn,temp1,temp2,INTERNET_FLAG_TRANSFER_BINARY ,0))
	{
		csMessage.Format("�߳�%d����",iThreadNo);
		csMessage+=temp1;
		csMessage+="->";
		csMessage+=temp2;
		csMessage+="�ɹ�\r\n";
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
		pWorkView->m_WorkList.SetItemText(iNowNo,5,"���");
		//�����������********************
		pWebView->PostMessage(WM_MY_WEB_TOLOCAL,0,(LPARAM)iNowNo);
		//****************************
		if(iMThreadWorkNowNo<iMThreadWorkTotal)
			//��������û�з���
		{
			iNowNo=iMThreadWorkNowNo++;
			csMessage.Format("�߳�%d��ʼִ���µ�%s�ļ��ϴ�����\r\n",iThreadNo,pWorkView->m_WorkList.GetItemText(iNowNo,0));
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
			pWorkView->m_WorkList.SetItemText(iNowNo,5,"�ϴ�");
			goto MThreadSendNext;
		}
		else
		{
			bMThreadWorkReady[iThreadNo]=true;	//�߳̿���
			goto mtend;
		}
	}
	else
	{
		if(GetLastError()==12003)//·���Ƿ�
		{
			strcpy(temp,temp2);
			ptemp=strrchr(temp,'/');
			if(ptemp)
			{
				temp[strlen(temp)-strlen(ptemp)]=0x00;
				if(FtpCreateDirectory(hFtpConn,temp))
					goto mtputfileagain;
				//����Ŀ¼
			}
			
		}
		else//����Ŀ¼����
		{		//ʧ������
			if((iErrorLoopTime++)<iWebTryLoop)
			{
				csMessage.Format("�߳�%d����",iThreadNo);
				csMessage+=temp1;
				csMessage+="->";
				csMessage+=temp2;
				csMessage+="ʧ��,��������\r\n";
				pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
				goto mtputfileagain;
			}
			csMessage.Format("�߳�%d����",iThreadNo);
			csMessage+=temp1;
			csMessage+="->";
			csMessage+=temp2;
			csMessage+="ʧ��\r\n";
			pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
			pWorkView->m_WorkList.SetItemText(iNowNo,5,"ʧ��");
			if(iMThreadWorkNowNo<iMThreadWorkTotal)
				//��������û�з���
			{
				iErrorLoopTime=0;
				iNowNo=iMThreadWorkNowNo++;
				goto MThreadSendNext;
			}
			else
			{
				bMThreadWorkReady[iThreadNo]=true;	//�߳̿���
				goto mtend;
			}
		}
	}
mtend:	
	while(!(InternetCloseHandle(hFtpConn)))	//�ر�����
	{
		csMessage.Format("�߳�%d����û�йر�,�ȴ�...\r\n",iThreadNo);
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
		if(bExitApp)
			return 0;
	}
	while(!(InternetCloseHandle(hInetSession)))	//�ر�����
	{
		csMessage.Format("�߳�%d����û�йر�,�ȴ�...\r\n",iThreadNo);
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)csMessage);
		if(bExitApp)
			return 0;
	}
MThreadOK:
	if(bMThreadWorkReady[0]&&
		bMThreadWorkReady[1]&&
		bMThreadWorkReady[2]&&
		bMThreadWorkReady[3]&&
		bMThreadWorkReady[4])//ȫ������
	{
		//::Sleep(iDialDelay*1000);//�ȴ������
		bLinkDataGood=false;
		bool bFinish=true;
		int iTotal=pWorkView->m_WorkList.GetItemCount();
		for(i=0;i<iTotal;i++)
		{
			strcpy(temp,pWorkView->m_WorkList.GetItemText(i,5));
			if(strcmp("���",temp)!=0)
			{
				bFinish=false;
			}
			else//����ɵ�ȥ��
			{
				pWorkView->m_WorkList.DeleteItem(i);
				iTotal-=1;
				i-=1;
			}
		}
		if((!bFinish)&&bWebAgain)//��Ҫ����
		{
			pMainFrame->PostMessage(WM_MY_WEBLOOP_UP);
		}
		else
		{
			//�����������********************
			pWebView->PostMessage(WM_MY_WEB_TOLOCAL,0,(LPARAM)-1);
			//****************************
			if(bAutoHangUp)//��Ҫ�Զ��Ҷ�
			{
				HangUp();
			}
			::Sleep(iDialDelay*1000);//�ȴ������
			if(bFinish)
			{
				pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"�ϴ����\r\n");
				if(bShutDownWhenFinish)//��ɺ�رռ����
				{
					pMainFrame->PostMessage(WM_MY_SHUTDOWN);
				}
				if(bQuitWhenFinish)	//��ɺ��˳�
				{
					pMainFrame->PostMessage(WM_MY_APP_EXIT);
				}
			}
		}
	}
	return 1;
}

void CMainFrame::OnQuickWebtolocal() 
{
	// TODO: Add your command handler code here
	bWebToLocal=!bWebToLocal;
}

void CMainFrame::OnUpdateQuickWebtolocal(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(bWebToLocal)
	{
		pCmdUI->SetCheck(1);
	}
	else
	{
		pCmdUI->SetCheck(0);
	}
}

void CMainFrame::OnQuickShutdown() 
{
	// TODO: Add your command handler code here
	bShutDownWhenFinish=!bShutDownWhenFinish;
}

void CMainFrame::OnUpdateQuickShutdown(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(bShutDownWhenFinish)
	{
		pCmdUI->SetCheck(1);
	}
	else
	{
		pCmdUI->SetCheck(0);
	}
}

void CMainFrame::OnQuickQuitwhenfinish() 
{
	// TODO: Add your command handler code here
	bQuitWhenFinish=!bQuitWhenFinish;
	
}

void CMainFrame::OnUpdateQuickQuitwhenfinish(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(bQuitWhenFinish)
	{
		pCmdUI->SetCheck(1);
	}
	else
	{
		pCmdUI->SetCheck(0);
	}
}

void CMainFrame::OnQuickAutodial() 
{
	// TODO: Add your command handler code here
	bAutoDial=!bAutoDial;		
}

void CMainFrame::OnUpdateQuickAutodial(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(bAutoDial)
	{
		pCmdUI->SetCheck(1);
	}
	else
	{
		pCmdUI->SetCheck(0);
	}
}

void CMainFrame::OnQuickHangup() 
{
	// TODO: Add your command handler code here
	bAutoHangUp=!bAutoHangUp;
}

void CMainFrame::OnUpdateQuickHangup(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(bAutoHangUp)
	{
		pCmdUI->SetCheck(1);
	}
	else
	{
		pCmdUI->SetCheck(0);
	}
}

void CMainFrame::OnQuickTimecmp() 
{
	// TODO: Add your command handler code here
	bCmpTime=!bCmpTime;
}

void CMainFrame::OnUpdateQuickTimecmp(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(bCmpTime)
	{
		pCmdUI->SetCheck(1);
	}
	else
	{
		pCmdUI->SetCheck(0);
	}	
}


void CMainFrame::OnMyShutDown(WPARAM wParam, LPARAM lParam)
{
	ExitWindowsEx(EWX_SHUTDOWN,0);
}

void CMainFrame::OnUpdateWebpath() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFrameWnd::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_UPDATE flag ORed into the lParam mask.

	// TODO: Add your control notification handler code here
	
}
