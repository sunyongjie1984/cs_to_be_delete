#if !defined(AFX_LOCALVIEW_H__95CAF440_25D7_11D5_92C9_00E04C39F1E2__INCLUDED_)
#define AFX_LOCALVIEW_H__95CAF440_25D7_11D5_92C9_00E04C39F1E2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LocalView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLocalView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif


class CLocalView : public CFormView
{
protected:
	CLocalView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CLocalView)

// Form Data
public:
	//{{AFX_DATA(CLocalView)
	enum { IDD = IDD_LOCALVIEW };
	CButton	m_LocalButton;
	CEdit	m_LocalPath;
	CListCtrl	m_LocalList;
	CString	m_Localpath;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void OnProjectPath(WPARAM wParam, LPARAM lParam);
	volatile char m_csPath[256];
	volatile char m_csAttrib[256];
	volatile char m_csName[256];
	volatile char m_csTime[256];
	volatile char m_csSize[256];
	volatile char m_csSerchBase[256];
	volatile HANDLE m_hPostEvent;
	void OnLocalInsert(WPARAM wParam, LPARAM lParam);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLocalView)
	public:
	virtual void OnInitialUpdate();
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnDraw(CDC* pDC);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CLocalView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CLocalView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLocalBrows();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOCALVIEW_H__95CAF440_25D7_11D5_92C9_00E04C39F1E2__INCLUDED_)
