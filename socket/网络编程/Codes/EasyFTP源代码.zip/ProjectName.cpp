// ProjectName.cpp : implementation file
//

#include "stdafx.h"
#include "EasyFtp.h"
#include "ProjectName.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProjectName dialog


CProjectName::CProjectName(CWnd* pParent /*=NULL*/)
	: CDialog(CProjectName::IDD, pParent)
{
	//{{AFX_DATA_INIT(CProjectName)
	m_Name = _T("");
	m_LocalPath = _T("");
	m_Passwrod = _T("");
	m_User = _T("");
	m_WebAdd = _T("");
	m_WebPath = _T("");
	//}}AFX_DATA_INIT
}


void CProjectName::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProjectName)
	DDX_Text(pDX, IDC_NAME, m_Name);
	DDV_MaxChars(pDX, m_Name, 255);
	DDX_Text(pDX, IDC_LOCALPATH, m_LocalPath);
	DDV_MaxChars(pDX, m_LocalPath, 255);
	DDX_Text(pDX, IDC_PASSWORD, m_Passwrod);
	DDV_MaxChars(pDX, m_Passwrod, 255);
	DDX_Text(pDX, IDC_USER, m_User);
	DDV_MaxChars(pDX, m_User, 255);
	DDX_Text(pDX, IDC_WEBADD, m_WebAdd);
	DDV_MaxChars(pDX, m_WebAdd, 255);
	DDX_Text(pDX, IDC_WEBPATH, m_WebPath);
	DDV_MaxChars(pDX, m_WebPath, 255);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CProjectName, CDialog)
	//{{AFX_MSG_MAP(CProjectName)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProjectName message handlers

void CProjectName::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	CDialog::OnOK();
}
