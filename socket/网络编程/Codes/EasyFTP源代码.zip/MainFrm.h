// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__D51370E9_25BF_11D5_92C9_00E04C39F1E2__INCLUDED_)
#define AFX_MAINFRM_H__D51370E9_25BF_11D5_92C9_00E04C39F1E2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
protected:
	CSplitterWnd m_wndSplitter1;
	CSplitterWnd m_wndSplitter2;
	CSplitterWnd m_wndSplitter3;
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	void OnMyShutDown(WPARAM wParam, LPARAM lParam);
	void OnAutoLoad(WPARAM wParam, LPARAM lParam);
	void OnAutoLink(WPARAM wParam, LPARAM lParam);
	void OnUpdateProject(WPARAM wParam, LPARAM lParam);
	void OnWebLogoLoop(WPARAM wParam, LPARAM lParam);
	void OnWebUpLoop(WPARAM wParam, LPARAM lParam);
	void OnMyExit(WPARAM wParam, LPARAM lParam);
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CReBar      m_wndReBar;
	CDialogBar      m_wndDlgBar;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnButton1();
	afx_msg void OnCtlBreak();
	afx_msg void OnButtonExit();
	afx_msg void OnCtlHuangup();
	afx_msg void OnChangeFtpadd();
	afx_msg void OnChangeFtpuser();
	afx_msg void OnChangeFtppassword();
	afx_msg void OnChangeLocalpath();
	afx_msg void OnChangeWebpath();
	afx_msg void OnCtlFtpup();
	afx_msg void OnCtlDial();
	afx_msg void OnCtlSetting();
	afx_msg void OnCtlAutoload();
	afx_msg void OnCtlCmp();
	afx_msg void OnProjectAdd();
	afx_msg void OnProjectDelete();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnQuickWebtolocal();
	afx_msg void OnUpdateQuickWebtolocal(CCmdUI* pCmdUI);
	afx_msg void OnQuickShutdown();
	afx_msg void OnUpdateQuickShutdown(CCmdUI* pCmdUI);
	afx_msg void OnQuickQuitwhenfinish();
	afx_msg void OnUpdateQuickQuitwhenfinish(CCmdUI* pCmdUI);
	afx_msg void OnQuickAutodial();
	afx_msg void OnUpdateQuickAutodial(CCmdUI* pCmdUI);
	afx_msg void OnQuickHangup();
	afx_msg void OnUpdateQuickHangup(CCmdUI* pCmdUI);
	afx_msg void OnQuickTimecmp();
	afx_msg void OnUpdateQuickTimecmp(CCmdUI* pCmdUI);
	afx_msg void OnUpdateWebpath();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__D51370E9_25BF_11D5_92C9_00E04C39F1E2__INCLUDED_)
