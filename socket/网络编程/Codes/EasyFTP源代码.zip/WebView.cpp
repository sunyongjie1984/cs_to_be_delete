// WebView.cpp : implementation file
//

#include "stdafx.h"
#include "EasyFtp.h"
#include "WebView.h"
#include "WorkView.h"
#include "MessageView.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWebView

LV_COLUMN lvcWeb;
LV_ITEM lviWeb;

CWebView *pWebView;
extern CWorkView *pWorkView;
extern CMessageView *pMessageView;
extern int iNowProjectNo;

extern CString csWebPath;

extern char sProjectAttrib[256][6][256];

IMPLEMENT_DYNCREATE(CWebView, CFormView)

CWebView::CWebView()
	: CFormView(CWebView::IDD)
{
	//{{AFX_DATA_INIT(CWebView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hPostEvent=NULL;
	pWebView=this;
}

CWebView::~CWebView()
{
	if(m_hPostEvent)
	{
		CloseHandle(m_hPostEvent);
		m_hPostEvent=NULL;
	}
	pWebView=NULL;
}

void CWebView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWebView)
	DDX_Control(pDX, IDC_WEBLIST, m_WebList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWebView, CFormView)
	//{{AFX_MSG_MAP(CWebView)
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_NOTIFY(NM_DBLCLK, IDC_WEBLIST, OnDblclkWeblist)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_MY_WEBLIST_INSERT,OnWebInsert)
	ON_MESSAGE(WM_MY_WEBLIST_DELETE,OnDeleteAllList)
	ON_MESSAGE(WM_MY_WEB_TOLOCAL,OnWebToLocal)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWebView diagnostics

#ifdef _DEBUG
void CWebView::AssertValid() const
{
	CFormView::AssertValid();
}

void CWebView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWebView message handlers

void CWebView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	RECT rct;
	GetClientRect(&rct);			//�õ��ͻ������С
	if(m_WebList.m_hWnd)
	{
		m_WebList.ShowWindow(SW_HIDE);
		m_WebList.SetWindowPos(this,0,0,rct.right,rct.bottom,SWP_NOZORDER|SWP_NOMOVE);
		m_WebList.ShowWindow(SW_SHOW);
	}		//��ʼ����С
	//******************
	//��д�б���
	static struct
	{
		LPSTR pszText;
		int uiFormat;
	}columns[]={
		_T("�������ļ�����"),LVCFMT_LEFT,
		_T("�ļ�����"),LVCFMT_CENTER,
		_T("�ļ���С"),LVCFMT_RIGHT,
		_T("�ļ�Ŀ¼"),LVCFMT_LEFT,
		_T("״̬"),LVCFMT_CENTER
	};
	int j;
	for(int i=0;i<sizeof(columns)/sizeof(columns[0]);i++)
	{
		switch(i)
		{
		case 0:
			j=100;
			break;
		case 1:
			j=100;
			break;
		case 2:
			j=60;
			break;
		case 3:
			j=60;
			break;
		default:
			j=50;
			break;
		}
		m_WebList.InsertColumn(i,columns[i].pszText,columns[i].uiFormat,j);
	}
	m_WebList.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
	//�������
}

void CWebView::OnSize(UINT nType, int cx, int cy) 
{
	//CFormView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if(m_WebList.m_hWnd)
	{
		m_WebList.ShowWindow(SW_HIDE);
		m_WebList.SetWindowPos(this,0,0,cx,cy,SWP_NOZORDER|SWP_NOMOVE);
		m_WebList.ShowWindow(SW_SHOW);
	}		//������С
}

void CWebView::OnWebInsert(WPARAM wParam, LPARAM lParam)
{
	lviWeb.iItem=m_WebList.GetItemCount();
	lviWeb.pszText="";
	lviWeb.lParam=(LPARAM)lviWeb.iItem;
	m_WebList.InsertItem(&lviWeb);
	m_WebList.SetItemText(lviWeb.iItem,0,(char *)m_csName);
	m_WebList.SetItemText(lviWeb.iItem,1,(char *)m_csTime);
	m_WebList.SetItemText(lviWeb.iItem,2,(char *)m_csSize);
	m_WebList.SetItemText(lviWeb.iItem,3,(char *)m_csPath);
	m_WebList.SetItemText(lviWeb.iItem,4,(char *)m_csAttrib);
	m_WebList.SetHotItem(lviWeb.iItem);			//��ע��ǰ��Ŀ
	m_WebList.EnsureVisible(lviWeb.iItem,true);	//����Ӱ��ľ���
	m_WebList.Update(lviWeb.iItem);				//�ػ�List����,��ֹ����
	SetEvent(m_hPostEvent);		//�����ٴμ���
}

int CWebView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFormView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	if((m_hPostEvent=CreateEvent(NULL,TRUE,TRUE,NULL))==NULL)
		return -1;

	return 0;
}

void CWebView::OnDeleteAllList(WPARAM wParam, LPARAM lParam)
{
	if(m_WebList.GetItemCount()>0)
	{
		m_WebList.DeleteAllItems();
	}
	SetEvent(m_hPostEvent);		//����
}

void CWebView::OnDblclkWeblist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CWebView::OnWebToLocal(WPARAM wParam, LPARAM lParam)
{
	int iNo=(int)lParam;
	int i,j,k;
	char temp[256],*end;
	if(iNo>=0)
	{
		strcpy(temp,pWorkView->m_WorkList.GetItemText(iNo,6));//�õ�����
		if(strcmp(temp,"��")==0)//��Ҫ����
		{
			lviWeb.iItem=m_WebList.GetItemCount();
			lviWeb.pszText="";
			lviWeb.lParam=(LPARAM)lviWeb.iItem;
			m_WebList.InsertItem(&lviWeb);
			m_WebList.SetItemText(lviWeb.iItem,0,pWorkView->m_WorkList.GetItemText(iNo,0));
			m_WebList.SetItemText(lviWeb.iItem,1,pWorkView->m_WorkList.GetItemText(iNo,1));
			m_WebList.SetItemText(lviWeb.iItem,2,pWorkView->m_WorkList.GetItemText(iNo,2));
			m_WebList.SetItemText(lviWeb.iItem,3,pWorkView->m_WorkList.GetItemText(iNo,3));
			m_WebList.SetItemText(lviWeb.iItem,4,pWorkView->m_WorkList.GetItemText(iNo,4));
			m_WebList.SetHotItem(lviWeb.iItem);			//��ע��ǰ��Ŀ
			m_WebList.EnsureVisible(lviWeb.iItem,true);	//����Ӱ��ľ���
			m_WebList.Update(lviWeb.iItem);				//�ػ�List����,��ֹ����
		}
		else		//���·������б�
		{
			i=strtol(temp,&end,10);
			m_WebList.SetItemText(i,0,pWorkView->m_WorkList.GetItemText(iNo,0));
			m_WebList.SetItemText(i,1,pWorkView->m_WorkList.GetItemText(iNo,1));
			m_WebList.SetItemText(i,2,pWorkView->m_WorkList.GetItemText(iNo,2));
			m_WebList.SetItemText(i,3,pWorkView->m_WorkList.GetItemText(iNo,3));
			m_WebList.SetItemText(i,4,pWorkView->m_WorkList.GetItemText(iNo,4));
		}
	}
	FILE *fo;
	strcpy(temp,sProjectAttrib[iNowProjectNo][2]);//�õ���ַ
	strcat(temp,sProjectAttrib[iNowProjectNo][1]);//�õ�����
	strcat(temp,".lst");
	fo=fopen(temp,"wb");
	if(fo==NULL)
	{
		strcat(temp,"����ʧ��\r\n");
		pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)temp);
	}
	else
	{
		iNo=m_WebList.GetItemCount();
		fprintf(fo,"%d\r\n",iNo);
		for(i=0;i<iNo;i++)
		{
			for(j=0;j<4;j++)
			{
				strcpy(temp,m_WebList.GetItemText(i,j));
				k=strlen(temp);
				fprintf(fo,"%d\r\n",k);
				fprintf(fo,"%s\r\n",temp);
			}
		}
		fclose(fo);
	}
}
