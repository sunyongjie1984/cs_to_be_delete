// ProjectTree.cpp : implementation file
//

#include "stdafx.h"
#include "EasyFtp.h"
#include "ProjectTree.h"
#include "LocalView.H"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CProjectTree *pProjectTree;
int iOldNo=999;
int iNowProjectNo=0;
extern CMainFrame *pMainFrame;
extern CLocalView *pLocalView;
extern char sProjectAttrib[256][6][256];
extern int iTotalProject;


HTREEITEM hItem;
/////////////////////////////////////////////////////////////////////////////
// CProjectTree

IMPLEMENT_DYNCREATE(CProjectTree, CFormView)

CProjectTree::CProjectTree()
	: CFormView(CProjectTree::IDD)
{
	//{{AFX_DATA_INIT(CProjectTree)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	pProjectTree=this;
}

CProjectTree::~CProjectTree()
{
	pProjectTree=NULL;
}

void CProjectTree::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProjectTree)
	DDX_Control(pDX, IDC_PROJECTTREE, m_ProjectTree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CProjectTree, CFormView)
	//{{AFX_MSG_MAP(CProjectTree)
	ON_WM_SIZE()
	ON_NOTIFY(NM_CLICK, IDC_PROJECTTREE, OnClickProjecttree)
	ON_NOTIFY(TVN_SELCHANGED, IDC_PROJECTTREE, OnSelchangedProjecttree)
	ON_NOTIFY(TVN_BEGINLABELEDIT, IDC_PROJECTTREE, OnBeginlabeleditProjecttree)
	ON_NOTIFY(TVN_ENDLABELEDIT, IDC_PROJECTTREE, OnEndlabeleditProjecttree)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_MY_PROJECT_ADD,OnProjectAdd)
	ON_MESSAGE(WM_MY_PROJECT_DELETE,OnProjectDelete)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProjectTree diagnostics

#ifdef _DEBUG
void CProjectTree::AssertValid() const
{
	CFormView::AssertValid();
}

void CProjectTree::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CProjectTree message handlers

void CProjectTree::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	RECT rct;
	GetClientRect(&rct);			//�õ��ͻ������С
	if(m_ProjectTree.m_hWnd)
	{
		m_ProjectTree.ShowWindow(SW_HIDE);
		m_ProjectTree.SetWindowPos(this,0,0,rct.right,rct.bottom,SWP_NOZORDER|SWP_NOMOVE);
		m_ProjectTree.ShowWindow(SW_SHOW);
	}		//��ʼ����С
	//******************
	int nRegion;
	//int nDistrict;
	HTREEITEM RegionParent;
	HTREEITEM DistrictParent;
	HTREEITEM TerritoryParent;
	TV_INSERTSTRUCT InsertItem;
	char szBuffer[255];
	//char *szDistrict[5]=
	//{"�û���","��������ַ","����","������·��","����·��"};
	for(nRegion=0;nRegion<iTotalProject;nRegion++)
	{
		InsertItem.item.mask=TVIF_TEXT;
		sprintf(szBuffer,"��Ŀ%02d:%s",nRegion+1,sProjectAttrib[nRegion][0]);
		InsertItem.item.pszText=szBuffer;
		InsertItem.item.cchTextMax=255;
		InsertItem.item.iImage=0;
		InsertItem.hParent=NULL;
		InsertItem.hInsertAfter=TVI_SORT;
		RegionParent=m_ProjectTree.InsertItem(&InsertItem);
		
		InsertItem.item.pszText="˳���";
		InsertItem.item.cchTextMax=255;
		InsertItem.hParent=RegionParent;
		InsertItem.hInsertAfter=TVI_SORT;
		DistrictParent=m_ProjectTree.InsertItem(&InsertItem);
		sprintf(szBuffer,"%d",nRegion);
		InsertItem.item.pszText=szBuffer;
		InsertItem.item.cchTextMax=255;
		InsertItem.hParent=DistrictParent;
		InsertItem.hInsertAfter=TVI_SORT;
		TerritoryParent=m_ProjectTree.InsertItem(&InsertItem);
	}
}

void CProjectTree::OnSize(UINT nType, int cx, int cy) 
{
	//CFormView::OnSize(nType, cx, cy);
	// TODO: Add your message handler code here
	if(m_ProjectTree.m_hWnd)
	{
		m_ProjectTree.ShowWindow(SW_HIDE);
		m_ProjectTree.SetWindowPos(this,0,0,cx,cy,SWP_NOZORDER|SWP_NOMOVE);
		m_ProjectTree.ShowWindow(SW_SHOW);
	}		//������С
}

void CProjectTree::OnClickProjecttree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	*pResult = 0;
}

void CProjectTree::OnSelchangedProjecttree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	char temp[256],*end;
	HTREEITEM hMItem;
	hMItem=m_ProjectTree.GetSelectedItem();
	hItem=m_ProjectTree.GetNextItem(hMItem,TVGN_CHILD);
	while(1)
	{
		strcpy(temp,m_ProjectTree.GetItemText(hItem));
		if(strcmp(temp,"˳���")==0)
		{
			break;
		}
		hMItem=hItem;
		hItem=m_ProjectTree.GetNextItem(hMItem,TVGN_NEXT);
		if(hItem==NULL)
			break;
	}
	if(hItem!=NULL)
	{
		hMItem=m_ProjectTree.GetNextItem(hItem,TVGN_CHILD);
		strcpy(temp,m_ProjectTree.GetItemText(hMItem));
		iNowProjectNo=strtol(temp,&end,10);
		if(iOldNo!=iNowProjectNo)
		{
			pMainFrame->PostMessage(WM_MY_PROJECT_UPDATE);
			iOldNo=iNowProjectNo;
		}
	}
	*pResult = 0;
}

void CProjectTree::OnBeginlabeleditProjecttree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CProjectTree::OnEndlabeleditProjecttree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;

	///pTVDispInfo->
	// TODO: Add your control notification handler code here
	
	
	//char temp[256];
	//HTREEITEM hItem;
	//hItem=m_ProjectTree.GetSelectedItem();
	//strcpy(temp,m_ProjectTree.UpdateData();//.GetItemText(hItem));
	//m_ProjectTree.UpdateData(false);
	//AfxMessageBox("temp");
	

	*pResult = 0;
}

void CProjectTree::OnProjectAdd(WPARAM wParam, LPARAM lParam)
{
	HTREEITEM RegionParent;
	HTREEITEM DistrictParent;
	HTREEITEM TerritoryParent;
	TV_INSERTSTRUCT InsertItem;
	char szBuffer[255];
	InsertItem.item.mask=TVIF_TEXT;
	sprintf(szBuffer,"��Ŀ%02d:%s",iNowProjectNo+1,sProjectAttrib[iNowProjectNo][0]);
	InsertItem.item.pszText=szBuffer;
	InsertItem.item.cchTextMax=255;
	InsertItem.item.iImage=0;
	InsertItem.hParent=NULL;
	InsertItem.hInsertAfter=TVI_SORT;
	RegionParent=m_ProjectTree.InsertItem(&InsertItem);

	InsertItem.item.pszText="˳���";
	InsertItem.item.cchTextMax=255;
	InsertItem.hParent=RegionParent;
	InsertItem.hInsertAfter=TVI_SORT;
	DistrictParent=m_ProjectTree.InsertItem(&InsertItem);
	sprintf(szBuffer,"%d",iNowProjectNo);
	InsertItem.item.pszText=szBuffer;
	InsertItem.item.cchTextMax=255;
	InsertItem.hParent=DistrictParent;
	InsertItem.hInsertAfter=TVI_SORT;
	TerritoryParent=m_ProjectTree.InsertItem(&InsertItem);

	PostMessage(TVN_SELCHANGED);
}

void CProjectTree::OnProjectDelete(WPARAM wParam, LPARAM lParam)
{
	if((hItem!=NULL)&&(iTotalProject>0))
	{
		char szBuffer[256];
		HTREEITEM hMItem;
		for(int i=iNowProjectNo;i<iTotalProject;i++)
		{
			strcpy(sProjectAttrib[i][0],sProjectAttrib[i+1][0]);
			strcpy(sProjectAttrib[i][1],sProjectAttrib[i+1][1]);
			strcpy(sProjectAttrib[i][2],sProjectAttrib[i+1][2]);
			strcpy(sProjectAttrib[i][3],sProjectAttrib[i+1][3]);
			strcpy(sProjectAttrib[i][4],sProjectAttrib[i+1][4]);
			strcpy(sProjectAttrib[i][5],sProjectAttrib[i+1][5]);
			hMItem=m_ProjectTree.GetNextItem(hItem,TVGN_CHILD);
			sprintf(szBuffer,"%d",i-1);
			m_ProjectTree.SetItemText(hMItem,szBuffer);
			hMItem=m_ProjectTree.GetNextItem(hItem,TVGN_PARENT);
			hItem=m_ProjectTree.GetNextItem(hMItem,TVGN_NEXT);
			hMItem=m_ProjectTree.GetNextItem(hItem,TVGN_CHILD);
			hItem=hMItem;
		}
		iTotalProject--;
		m_ProjectTree.DeleteItem(m_ProjectTree.GetNextItem(hItem,TVGN_CARET));
	}
	PostMessage(TVN_SELCHANGED);
}
