// SettingBox.cpp : implementation file
//

#include "stdafx.h"
#include "EasyFtp.h"
#include "SettingBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSettingBox dialog


CSettingBox::CSettingBox(CWnd* pParent /*=NULL*/)
	: CDialog(CSettingBox::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSettingBox)
	m_AutoDial = FALSE;
	m_AutoHangUp = FALSE;
	m_Passwrod = _T("");
	m_User = _T("");
	m_Number = _T("");
	m_CmpTime = FALSE;
	m_DialAgain = FALSE;
	m_DialWhenHangUp = FALSE;
	m_DialLoop = 0;
	m_DialDelay = 0;
	m_WebAgain = FALSE;
	m_WebLoop = 0;
	m_MUpThread = FALSE;
	m_AutoShutDown = FALSE;
	m_AutoQuit = FALSE;
	m_MThreadNo = 0;
	m_WebToLocal = FALSE;
	//}}AFX_DATA_INIT
}


void CSettingBox::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSettingBox)
	DDX_Check(pDX, IDC_AUTODIAL, m_AutoDial);
	DDX_Check(pDX, IDC_AUTOHANGUP, m_AutoHangUp);
	DDX_Text(pDX, IDC_PASSWORD, m_Passwrod);
	DDV_MaxChars(pDX, m_Passwrod, 256);
	DDX_Text(pDX, IDC_USER, m_User);
	DDV_MaxChars(pDX, m_User, 256);
	DDX_Text(pDX, IDC_NUMBER, m_Number);
	DDV_MaxChars(pDX, m_Number, 256);
	DDX_Check(pDX, IDC_CMPTIME, m_CmpTime);
	DDX_Check(pDX, IDC_DIALAGAIN, m_DialAgain);
	DDX_Check(pDX, IDC_DIALWHENHANGUP, m_DialWhenHangUp);
	DDX_Text(pDX, IDC_DIALLOOP, m_DialLoop);
	DDV_MinMaxInt(pDX, m_DialLoop, 0, 9999);
	DDX_Text(pDX, IDC_DIALDELAY, m_DialDelay);
	DDV_MinMaxInt(pDX, m_DialDelay, 3, 100);
	DDX_Check(pDX, IDC_WEBAGAIN, m_WebAgain);
	DDX_Text(pDX, IDC_WEBLOOP, m_WebLoop);
	DDV_MinMaxInt(pDX, m_WebLoop, 0, 999);
	DDX_Check(pDX, IDC_MUPTHREAD, m_MUpThread);
	DDX_Check(pDX, IDC_AUTOSHUTDOWN, m_AutoShutDown);
	DDX_Check(pDX, IDC_AUTOQUIT, m_AutoQuit);
	DDX_Text(pDX, IDC_MTHREADNO, m_MThreadNo);
	DDV_MinMaxInt(pDX, m_MThreadNo, 1, 5);
	DDX_Check(pDX, IDC_WEBTOLOCAL, m_WebToLocal);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSettingBox, CDialog)
	//{{AFX_MSG_MAP(CSettingBox)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSettingBox message handlers

void CSettingBox::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	CDialog::OnOK();
}
