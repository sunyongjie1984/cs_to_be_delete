// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__D51370E7_25BF_11D5_92C9_00E04C39F1E2__INCLUDED_)
#define AFX_STDAFX_H__D51370E7_25BF_11D5_92C9_00E04C39F1E2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WM_MY_LOCALLIST_INSERT	WM_USER+1000
#define WM_MY_MESSAGE_UPDATE	WM_USER+1001
#define WM_MY_WEBLIST_INSERT	WM_USER+1002
#define WM_MY_PROJECT_UPDATE	WM_USER+1003
#define WM_MY_PROJECT_PATH		WM_USER+1004
#define WM_MY_WEBLIST_DELETE	WM_USER+1005
#define WM_MY_WORK_LISTNEW		WM_USER+1006
#define WM_MY_AUTO_LOAD			WM_USER+1007
#define WM_MY_AUTO_LINK			WM_USER+1008
#define WM_MY_WEBLOOP_LOGO		WM_USER+1009
#define WM_MY_WEBLOOP_UP		WM_USER+1010
#define WM_MY_APP_EXIT			WM_USER+1011
#define WM_MY_PROJECT_ADD		WM_USER+1012
#define WM_MY_PROJECT_DELETE	WM_USER+1013
#define WM_MY_WEB_TOLOCAL		WM_USER+1014
#define WM_MY_SHUTDOWN			WM_USER+1015
#define WM_SCNOTIFYICON			WM_USER+101

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.


#endif // !defined(AFX_STDAFX_H__D51370E7_25BF_11D5_92C9_00E04C39F1E2__INCLUDED_)
