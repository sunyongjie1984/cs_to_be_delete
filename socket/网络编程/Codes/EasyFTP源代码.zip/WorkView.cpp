// WorkView.cpp : implementation file
//

#include "stdafx.h"
#include "EasyFtp.h"
#include "WorkView.h"
#include "LocalView.h"
#include "WebView.h"
#include "MessageView.h"
#include "mainfrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CMainFrame *pMainFrame;
extern CMessageView *pMessageView;
extern CLocalView *pLocalView;
extern CWebView *pWebView;
CWorkView *pWorkView;

extern CString csWebPath;
LV_ITEM lviWork;
extern bool bAutoLoad;
extern BOOL bCmpTime;

CWinThread *MyWorkListThread;
UINT MyWorkListThreadFunction(LPVOID lpParam);

/////////////////////////////////////////////////////////////////////////////
// CWorkView

IMPLEMENT_DYNCREATE(CWorkView, CFormView)

CWorkView::CWorkView()
	: CFormView(CWorkView::IDD)
{
	//{{AFX_DATA_INIT(CWorkView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	MyWorkListThread=NULL;
	pWorkView=this;
}

CWorkView::~CWorkView()
{
	pWorkView=NULL;
}

void CWorkView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWorkView)
	DDX_Control(pDX, IDC_WORKLIST, m_WorkList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWorkView, CFormView)
	//{{AFX_MSG_MAP(CWorkView)
	ON_WM_SIZE()
	ON_NOTIFY(NM_DBLCLK, IDC_WORKLIST, OnDblclkWorklist)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_MY_WORK_LISTNEW,OnListNew)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWorkView diagnostics

#ifdef _DEBUG
void CWorkView::AssertValid() const
{
	CFormView::AssertValid();
}

void CWorkView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWorkView message handlers

void CWorkView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	RECT rct;
	GetClientRect(&rct);			//�õ��ͻ������С
	if(m_WorkList.m_hWnd)
	{
		m_WorkList.ShowWindow(SW_HIDE);
		m_WorkList.SetWindowPos(this,0,0,rct.right,rct.bottom,SWP_NOZORDER|SWP_NOMOVE);
		m_WorkList.ShowWindow(SW_SHOW);
	}		//��ʼ����С
	//******************
	//��д�б���
	static struct
	{
		LPSTR pszText;
		int uiFormat;
	}columns[]={
		_T("�ļ�����"),LVCFMT_LEFT,
		_T("�ļ�����"),LVCFMT_CENTER,
		_T("�ļ���С"),LVCFMT_RIGHT,
		_T("�ļ�Ŀ¼"),LVCFMT_LEFT,
		_T("״̬"),LVCFMT_CENTER,
		_T("����"),LVCFMT_CENTER,
		_T("����"),LVCFMT_CENTER
	};
	int j;
	for(int i=0;i<sizeof(columns)/sizeof(columns[0]);i++)
	{
		switch(i)
		{
		case 0:
			j=100;
			break;
		case 1:
			j=100;
			break;
		case 2:
			j=60;
			break;
		case 3:
			j=60;
			break;
		case 4:
			j=50;
			break;
		case 5:
			j=50;
			break;
		default:
			j=50;
			break;
		}
		m_WorkList.InsertColumn(i,columns[i].pszText,columns[i].uiFormat,j);
	}
	m_WorkList.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
	//�������
}

void CWorkView::OnSize(UINT nType, int cx, int cy) 
{
	//CFormView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if(m_WorkList.m_hWnd)
	{
		m_WorkList.ShowWindow(SW_HIDE);
		m_WorkList.SetWindowPos(this,0,0,cx,cy,SWP_NOZORDER|SWP_NOMOVE);
		m_WorkList.ShowWindow(SW_SHOW);
	}		//������С
}

void CWorkView::OnListNew(WPARAM wParam, LPARAM lParam)
{
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"���ڱȽ��ļ��б�...");
	
	if((MyWorkListThread = AfxBeginThread(MyWorkListThreadFunction,this)) == NULL)
	{
		//����ʧ�ܴ���
		return;
	}
	else    //�����Ὠ��һ�������̲߳���ʱ�������
	{
		MyWorkListThread->SetThreadPriority(THREAD_PRIORITY_BELOW_NORMAL);
		MyWorkListThread->ResumeThread();//����CWinThread:: ResumeThreadʹ�߳̿�ʼ����
	}
}


UINT MyWorkListThreadFunction(LPVOID lpParam)//char *cPath, char *cBasePath)
{

	if(pWorkView->m_WorkList.GetItemCount()>0)
	{
		pWorkView->m_WorkList.DeleteAllItems();
	}
	bool bFind=false;
	int iOK=0;
	int i,j,iRec;
	int iLocalTotal,iWebTotal;
	char temp1[3][256],temp2[3][256],temp[256];
	iLocalTotal=pLocalView->m_LocalList.GetItemCount();
	iWebTotal=pWebView->m_WebList.GetItemCount();
	for(i=0;i<iLocalTotal;i++)
	{
		strcpy(temp1[0],pLocalView->m_LocalList.GetItemText(i,3));
		strcat(temp1[0],pLocalView->m_LocalList.GetItemText(i,0));
		//�ļ�ȫ��
		strcpy(temp,strlwr(temp1[0]));
		strcpy(temp1[0],temp);
		//ǿ��Сд
		//pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"\r\n�Ƚ��ļ�");
		//pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)temp1[0]);
		strcpy(temp1[1],pLocalView->m_LocalList.GetItemText(i,1));
		//�ļ�ʱ��
		strcpy(temp1[2],pLocalView->m_LocalList.GetItemText(i,2));
		//�ļ���С
		for(j=0;j<iWebTotal;j++)
		{
			bFind=false;
			iOK=0;
			strcpy(temp2[0],pWebView->m_WebList.GetItemText(j,3));
			strcat(temp2[0],pWebView->m_WebList.GetItemText(j,0));
			//�ļ�ȫ��
			strcpy(temp,strlwr(temp2[0]));
			strcpy(temp2[0],temp);
			//ǿ��Сд
			if(strcmp(temp1[0],temp2[0])==0)
			{
				iRec=j;
				pWebView->m_WebList.SetItemText(j,4,"OK");
				bFind=true;
				if(bCmpTime)
				{
					strcpy(temp2[1],pWebView->m_WebList.GetItemText(j,1));
					//�ļ�ʱ��
					if(strcmp(temp1[1],temp2[1])>0)
					{
						iOK+=1;
						pWebView->m_WebList.SetItemText(j,4,"��ʱ");
					}
				}
				strcpy(temp2[2],pWebView->m_WebList.GetItemText(j,2));
				//�ļ���С
				if(strcmp(temp1[2],temp2[2])!=0)
				{
					iOK+=8;
					pWebView->m_WebList.SetItemText(j,4,"��ͬ");
				}
				break;
			}
		}
		if(!bFind)
		{
			pLocalView->m_LocalList.SetItemText(i,4,"��");
		}
		else
		{
			switch(iOK)
			{
			case 0:	//һ��
				pLocalView->m_LocalList.SetItemText(i,4,"OK");
				break;
			case 1://ʱ�䲻ͬ
				pLocalView->m_LocalList.SetItemText(i,4,"����");
				break;
			case 8://��С��ͬ
				pLocalView->m_LocalList.SetItemText(i,4,"��ͬ");
				break;
			case 9://ʱ��ʹ�С��ͬ
				pLocalView->m_LocalList.SetItemText(i,4,"�滻");
				break;
			default:
				break;
			}
		}
		if(!(bFind&&(iOK==0)))
		{
			lviWork.iItem=pWorkView->m_WorkList.GetItemCount();
			lviWork.pszText="";
			lviWork.lParam=(LPARAM)lviWork.iItem;
			pWorkView->m_WorkList.InsertItem(&lviWork);
			pWorkView->m_WorkList.SetItemText(lviWork.iItem,0,pLocalView->m_LocalList.GetItemText(i,0));
			pWorkView->m_WorkList.SetItemText(lviWork.iItem,1,pLocalView->m_LocalList.GetItemText(i,1));
			pWorkView->m_WorkList.SetItemText(lviWork.iItem,2,pLocalView->m_LocalList.GetItemText(i,2));
			pWorkView->m_WorkList.SetItemText(lviWork.iItem,3,pLocalView->m_LocalList.GetItemText(i,3));
			pWorkView->m_WorkList.SetItemText(lviWork.iItem,4,pLocalView->m_LocalList.GetItemText(i,4));
			//��д����
			if(!bFind)//���ļ�
			{
				sprintf(temp,"��");
			}
			else
			{
				sprintf(temp,"%d",iRec);
			}
			pWorkView->m_WorkList.SetItemText(lviWork.iItem,6,temp);//��д����
			pWorkView->m_WorkList.SetHotItem(lviWork.iItem);			//��ע��ǰ��Ŀ
			pWorkView->m_WorkList.EnsureVisible(lviWork.iItem,true);	//����Ӱ��ľ���
			pWorkView->m_WorkList.Update(lviWork.iItem);				//�ػ�List����,��ֹ����
		}
	}
	pMessageView->PostMessage(WM_MY_MESSAGE_UPDATE,0,(LPARAM)(LPCTSTR)"ok\r\n");
	if(bAutoLoad)//�Զ�ģʽ
	{
		pMainFrame->PostMessage(WM_MY_AUTO_LOAD);
	}
	return true;
}


void CWorkView::OnDblclkWorklist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int i=m_WorkList.GetNextItem(-1,LVNI_SELECTED);
	if(i!=-1)
	{
		m_WorkList.DeleteItem(i);
	}
	*pResult = 0;
}
