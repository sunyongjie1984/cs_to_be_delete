// MessageView.cpp : implementation file
//

#include "stdafx.h"
#include "EasyFtp.h"
#include "MessageView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



CMessageView *pMessageView;
/////////////////////////////////////////////////////////////////////////////
// CMessageView

IMPLEMENT_DYNCREATE(CMessageView, CEditView)

CMessageView::CMessageView()
{
	pMessageView=this;
}

CMessageView::~CMessageView()
{
	m_TextFont.DeleteObject();
	pMessageView=NULL;
}


BEGIN_MESSAGE_MAP(CMessageView, CEditView)
	//{{AFX_MSG_MAP(CMessageView)
	ON_WM_DESTROY()
	ON_WM_CREATE()
	ON_CONTROL_REFLECT(EN_CHANGE, OnChange)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_MY_MESSAGE_UPDATE,OnMessageUpdate)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMessageView drawing

void CMessageView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CMessageView diagnostics

#ifdef _DEBUG
void CMessageView::AssertValid() const
{
	CEditView::AssertValid();
}

void CMessageView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMessageView message handlers

bool CMessageView::OnMessageUpdate(WPARAM wParam, LPARAM lParam)
{
	CEdit& edit=GetEditCtrl();
	CString str=(LPCTSTR)lParam;
	int nLine=edit.GetLineCount();
	int nStart=edit.LineIndex(nLine);
	edit.SetSel(nStart,str.GetLength()+nStart);
	edit.ReplaceSel(str);
	return true;
}

void CMessageView::OnDestroy() 
{
	CEditView::OnDestroy();
	
	// TODO: Add your message handler code here
	
}

int CMessageView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CEditView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	m_TextFont.CreatePointFont(100,"����",NULL);
	GetEditCtrl().SetFont(&m_TextFont,true);
	return 0;
}

void CMessageView::OnChange() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CEditView::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	
}
