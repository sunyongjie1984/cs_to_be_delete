#if !defined(AFX_WORKVIEW_H__D818E8A5_2B65_11D5_92C9_00E04C39F1E2__INCLUDED_)
#define AFX_WORKVIEW_H__D818E8A5_2B65_11D5_92C9_00E04C39F1E2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WorkView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWorkView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CWorkView : public CFormView
{
protected:
	CWorkView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CWorkView)

// Form Data
public:
	//{{AFX_DATA(CWorkView)
	enum { IDD = IDD_WORKVIEW };
	CListCtrl	m_WorkList;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void OnListNew(WPARAM wParam, LPARAM lParam);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWorkView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CWorkView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CWorkView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDblclkWorklist(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WORKVIEW_H__D818E8A5_2B65_11D5_92C9_00E04C39F1E2__INCLUDED_)
