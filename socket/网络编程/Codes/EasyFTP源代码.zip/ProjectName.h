#if !defined(AFX_PROJECTNAME_H__96030FE0_34AC_11D5_92C9_00E04C39F1E2__INCLUDED_)
#define AFX_PROJECTNAME_H__96030FE0_34AC_11D5_92C9_00E04C39F1E2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProjectName.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CProjectName dialog

class CProjectName : public CDialog
{
// Construction
public:
	CProjectName(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CProjectName)
	enum { IDD = IDD_PROJECT_NAME };
	CString	m_Name;
	CString	m_LocalPath;
	CString	m_Passwrod;
	CString	m_User;
	CString	m_WebAdd;
	CString	m_WebPath;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProjectName)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CProjectName)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROJECTNAME_H__96030FE0_34AC_11D5_92C9_00E04C39F1E2__INCLUDED_)
