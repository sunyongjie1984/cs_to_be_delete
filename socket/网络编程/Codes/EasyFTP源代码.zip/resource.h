//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EasyFtp.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_EFTPTYPE                    129
#define IDD_LOCALVIEW                   130
#define IDD_WEBLIST                     131
#define IDD_WORKVIEW                    132
#define IDD_PROJECTTREE                 133
#define IDD_SETTING                     134
#define IDC_CURSOR1                     135
#define IDI_ICON1                       136
#define IDI_ICON2                       137
#define IDI_ICON3                       138
#define IDI_ICON4                       139
#define IDD_PROJECT_NAME                140
#define IDC_LOCAL_LIST                  1001
#define IDC_FTPADD                      1002
#define IDC_FTPUSER                     1003
#define IDC_FTPPASSWORD                 1004
#define IDC_BUTTON1                     1005
#define IDC_LOCAL_PATH                  1006
#define IDC_WEBPATH                     1006
#define IDC_LOCAL_BROWS                 1007
#define IDC_LOCALPATH                   1007
#define IDC_WEBLIST                     1009
#define IDC_WORKLIST                    1010
#define IDC_PROJECTTREE                 1011
#define IDC_AUTODIAL                    1012
#define IDC_AUTOHANGUP                  1013
#define IDC_NUMBER                      1014
#define IDC_USER                        1015
#define IDC_PASSWORD                    1016
#define IDC_CMPTIME                     1017
#define IDC_HTTP                        1018
#define IDC_DIALWHENHANGUP              1018
#define IDC_EMAIL                       1019
#define IDC_DIALAGAIN                   1019
#define IDC_DIALLOOP                    1022
#define IDC_DIALLOOPSPIN                1023
#define IDC_DIALDELAY                   1024
#define IDC_WEBAGAIN                    1025
#define IDC_WEBLOOP                     1026
#define IDC_MUPTHREAD                   1027
#define IDC_AUTOQUIT                    1028
#define IDC_AUTOSHUTDOWN                1029
#define IDC_NAME                        1029
#define IDC_MTHREADNO                   1030
#define IDC_WEBADD                      1030
#define IDC_WEBTOLOCAL                  1031
#define ID_CTL_BREAK                    32771
#define ID_BUTTON_EXIT                  32775
#define ID_CTL_HUANGUP                  32777
#define ID_CTL_DIAL                     32778
#define ID_CTL_FTPUP                    32779
#define ID_CTL_SETTING                  32787
#define ID_CTL_AUTOLOAD                 32789
#define ID_CTL_CMP                      32790
#define ID_PROJECT_ADD                  32792
#define ID_PROJECT_DELETE               32793
#define ID_QUICK_WEBTOLOCAL             32797
#define ID_QUICK_QUITWHENFINISH         32799
#define ID_QUICK_SHUTDOWN               32802
#define ID_QUICK_AUTODIAL               32803
#define ID_QUICK_HANGUP                 32804
#define ID_QUICK_TIMECMP                32807

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32809
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
