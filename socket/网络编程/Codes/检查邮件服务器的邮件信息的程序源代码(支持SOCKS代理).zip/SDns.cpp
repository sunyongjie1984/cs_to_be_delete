// SDns.cpp: implementation of the CSDns class.
//
//////////////////////////////////////////////////////////////////////

#include "SDns.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSDns::CSDns()
{

}

CSDns::~CSDns()
{

}

struct in_addr CSDns::GetIpByHost(char *szHost)
{
	struct in_addr in;
	if (szHost == NULL)
	{
		in.s_addr = INADDR_NONE;
	}
	else
	{
		unsigned long addr = inet_addr(szHost);
		if (addr == INADDR_NONE)
		{
			LPHOSTENT lphost;
			lphost = gethostbyname(szHost);
			if (lphost != NULL)
				in = *(LPIN_ADDR)*(lphost->h_addr_list);
			else
				in.s_addr = INADDR_NONE;
		}
		else
			in.s_addr = addr;
	}
	return in;

}
