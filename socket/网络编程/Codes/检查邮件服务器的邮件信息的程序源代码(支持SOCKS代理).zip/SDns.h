// SDns.h: interface for the CSDns class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SDNS_H__B9D73729_F726_11D4_96BF_5254AB1C29C8__INCLUDED_)
#define AFX_SDNS_H__B9D73729_F726_11D4_96BF_5254AB1C29C8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifdef WIN32
#include <winsock2.h>
#endif

class CSDns  
{
public:
	struct in_addr GetIpByHost(char* szHost);
	CSDns();
	virtual ~CSDns();

};

#endif // !defined(AFX_SDNS_H__B9D73729_F726_11D4_96BF_5254AB1C29C8__INCLUDED_)
