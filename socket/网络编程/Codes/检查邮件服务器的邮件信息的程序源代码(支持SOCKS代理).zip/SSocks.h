//Ŀǰ��֧�ּ򵥼�������,AUTH_NO

#ifndef __SSOCKS_H__
#define __SSOCKS_H__

#ifdef WIN32
#include <winsock2.h>
#endif

#define SOCKS_VER5	0x05
#define AUTH_NO		0x00
#define CMD_CONNECT	0x01
#define RSV_DEFAULT	0x00
#define ATYP_DN		0x03
#define REP_SUCCESS	0x00
#define ATYP_IPV4	0x01



class CSSocks  
{
public:
	BOOL Connect(int socket,const struct sockaddr_in sa);
	BOOL Auth(int socket,const unsigned char auth);
	CSSocks();
	virtual ~CSSocks();

};

#endif 
