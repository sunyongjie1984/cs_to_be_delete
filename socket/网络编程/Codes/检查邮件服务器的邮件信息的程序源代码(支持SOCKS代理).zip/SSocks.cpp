// SSocks.cpp: implementation of the CSSocks class.
//
//////////////////////////////////////////////////////////////////////

#include "SSocks.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSSocks::CSSocks()
{

}

CSSocks::~CSSocks()
{

}

BOOL CSSocks::Auth(int socket, const unsigned char auth)
{

	char buf[257];
	buf[0] = SOCKS_VER5;	//VER (1 Byte)
	buf[1] = 0x01;		//NMETHODS (1 Byte)
	buf[2] = auth;		//METHODS (allow 1 - 255 bytes, current 1 byte)
	int res;
	switch (auth)
	{
	case AUTH_NO:
		res = send(socket, buf, 3, 0);
		if (res == -1)
			return FALSE;
		else
		{
			res = recv(socket, buf, 257, 0);
			if (res < 2)
				return FALSE;
			else if (buf[1] != AUTH_NO)
				return FALSE;
			else
				return TRUE;
		}
	default:
		return FALSE;
	}

}

BOOL CSSocks::Connect(int socket, const sockaddr_in sa)
{

	char buf[1024];
	buf[0] = SOCKS_VER5;
	buf[1] = CMD_CONNECT;
	buf[2] = RSV_DEFAULT;
	buf[3] = ATYP_IPV4;
	memcpy(buf+4, &sa.sin_addr, 4);
	memcpy(buf+8, &sa.sin_port, 2);
	int res = send(socket, buf, 10, 0);
	if (res == -1)
		return FALSE;
	else
	{
		res = recv(socket, buf, 1024, 0);
		if (res == -1)
			return FALSE;
		else
		{
			if (buf[1] != REP_SUCCESS)
				return FALSE;
			else
				return TRUE;
		}
	}

}
