// MessagerDlg.h : header file
//

#if !defined(AFX_MESSAGERDLG_H__B8800766_1EE4_485B_AD0D_EBBC041011F9__INCLUDED_)
#define AFX_MESSAGERDLG_H__B8800766_1EE4_485B_AD0D_EBBC041011F9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BtnST.h"
#include "FLATCOMBOBOX.H"
#include "IniFile.h"


/////////////////////////////////////////////////////////////////////////////
// CMessagerDlg dialog

class CMessagerDlg : public CDialog
{
// Construction
public:
	CMessagerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMessagerDlg)
	enum { IDD = IDD_MESSAGER_DIALOG };
	CButtonST		m_btnFAINT;
	CButtonST		m_btnPIN;
	CFlatComboBox	m_boxWhom;
	CButtonST		m_btnSEND;
	CButtonST		m_btnCANCEL;
	CString	say;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMessagerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON		m_hIcon;
	CBitmap		m_Skin;

	CIniFile	m_inifile;

	// Generated message map functions
	//{{AFX_MSG(CMessagerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg UINT OnNcHitTest(CPoint point);
	afx_msg void OnSend();
	afx_msg void OnPin();
	virtual void OnCancel();
	afx_msg void OnFaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MESSAGERDLG_H__B8800766_1EE4_485B_AD0D_EBBC041011F9__INCLUDED_)
