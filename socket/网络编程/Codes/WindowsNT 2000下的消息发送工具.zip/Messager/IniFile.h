// IniFile.h: interface for the CIniFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INIFILE_H__B248B7D1_AF92_4C5E_B6E2_177EB74EB2BE__INCLUDED_)
#define AFX_INIFILE_H__B248B7D1_AF92_4C5E_B6E2_177EB74EB2BE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <Afxtempl.h>

// used to operate the .INI file
class CIniFile  
{
public:
	BOOL Exist(CString name);
	void ClearList();
	void AddToList(CString usrname);
	BOOL WriteIniFile();
	BOOL ReadIniFile();
	//void SetPath(CString newpath);
	CIniFile(CString path);
	CIniFile( );
	virtual ~CIniFile();

	CArray<CString, CString> m_namelist;
	CString m_strSender;

protected:
	CString m_strPath;
};

#endif // !defined(AFX_INIFILE_H__B248B7D1_AF92_4C5E_B6E2_177EB74EB2BE__INCLUDED_)
