// MessagerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Messager.h"
#include "MessagerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMessagerDlg dialog

CMessagerDlg::CMessagerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMessagerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMessagerDlg)
	say = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMessagerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMessagerDlg)
	DDX_Control(pDX, IDC_FAINT, m_btnFAINT);
	DDX_Control(pDX, IDC_PIN, m_btnPIN);
	DDX_Control(pDX, IDC_COMBO_RECEIVER, m_boxWhom);
	DDX_Control(pDX, IDC_SEND, m_btnSEND);
	DDX_Control(pDX, IDCANCEL, m_btnCANCEL);
	DDX_Text(pDX, IDC_EDIT_SAY, say);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMessagerDlg, CDialog)
	//{{AFX_MSG_MAP(CMessagerDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_ERASEBKGND()
	ON_WM_NCHITTEST()
	ON_BN_CLICKED(IDC_SEND, OnSend)
	ON_BN_CLICKED(IDC_PIN, OnPin)
	ON_BN_CLICKED(IDC_FAINT, OnFaint)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMessagerDlg message handlers

BOOL CMessagerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// set the size of the window
	m_Skin.LoadBitmap(IDB_BITMAP_SKIN);
	BITMAP csBitmapSize;
	m_Skin.GetObject(sizeof(csBitmapSize), &csBitmapSize);
	int width = csBitmapSize.bmWidth+2;
	int height = csBitmapSize.bmHeight+2;
	MoveWindow(0, 0, width, height);
	
	m_btnFAINT.MoveWindow(62, 12, 32, 16);
	m_btnSEND.MoveWindow(12,  12, 32, 16);
	m_btnPIN.MoveWindow(112,  12, 32, 16);
	m_btnCANCEL.MoveWindow(csBitmapSize.bmWidth-48, 12, 32, 16);


	// ---------- exist message revievers
	m_inifile.ReadIniFile();
	CFlatComboBox *pbox = (CFlatComboBox*)GetDlgItem(IDC_COMBO_RECEIVER);
	for (int itera=0; itera<=m_inifile.m_namelist.GetUpperBound(); itera++)
	{
		CString na = m_inifile.m_namelist[itera];
		if (!na.IsEmpty())
			pbox->AddString(m_inifile.m_namelist[itera]);
	}
	pbox->SetCurSel(0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMessagerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMessagerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


BOOL CMessagerDlg::OnEraseBkgnd(CDC* pDC) 
{
	HBITMAP m_hBmp = (HBITMAP)m_Skin.GetSafeHandle();
	if(m_hBmp)
	{
		BITMAP bm;
		GetObject(m_hBmp,sizeof(bm),&bm);
		HDC hMemdc=CreateCompatibleDC(pDC->m_hDC); 
		if(hMemdc)
		{
		   HBITMAP hOldBmp=(HBITMAP)SelectObject(hMemdc,m_hBmp);
		   if(hOldBmp)
		   {
			   BitBlt(pDC->m_hDC,0,0,bm.bmWidth,bm.bmHeight,hMemdc,0,0,SRCCOPY);
			   SelectObject(hMemdc,hOldBmp);
			   DeleteDC(hMemdc);
			   DeleteObject(hOldBmp);
			   return TRUE;
		   }
		   else
			 DeleteDC(hMemdc);
		}
	}
	//pDC->DrawIcon(88,88,LoadIcon(NULL,IDI_INFORMATION));//ϵͳͼ��������

	return CDialog::OnEraseBkgnd(pDC);
}

UINT CMessagerDlg::OnNcHitTest(CPoint point) 
{
	//UINT nHitTest = CDialog :: OnNcHitTest (point);
	//return (nHitTest == HTCLIENT)? HTCAPTION: nHitTest;
	return	HTCAPTION;
	//return CDialog::OnNcHitTest(point);
}


void CMessagerDlg::OnSend() 
{
	UpdateData(TRUE);

	CString who;
	CString sender;
	m_boxWhom.GetWindowText(who);
	if (!m_inifile.Exist(who))
	{
		m_inifile.m_namelist.Add(who);
		m_boxWhom.AddString(who);
	}

	CEdit *pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SENDER);
	pEdit->GetWindowText(sender);
	CEdit *pwho = (CEdit*)GetDlgItem(IDC_EDIT_SAY);
	pwho->GetWindowText(say);

	CString msgHead;
	msgHead.Format("�����ߣ�%s\r\n--------------\r\n", sender);

	if (say == "")
	{
		say = _T("���");
	}

	//CString msg = "net send " + strWho + " " + m_strSayWhat;
	say = msgHead + say;
	CString msg = "net send " + who + " " + say;
	WinExec(msg, NULL);

	say = _T("");
	UpdateData(FALSE);	
}

void CMessagerDlg::OnPin() 
{
	CRect rect;
	GetWindowRect( rect );
	
	::SetWindowPos(m_hWnd ,       // handle to window
		HWND_TOPMOST,  // placement-order handle
		rect.left,     // horizontal position
		rect.top,      // vertical position
		rect.Width(),  // width
		rect.Height(), // height
		SWP_SHOWWINDOW); // window-positioning options);
}

void CMessagerDlg::OnCancel() 
{
	m_inifile.WriteIniFile();
	CDialog::OnCancel();
}

void CMessagerDlg::OnFaint() 
{
	UpdateData(TRUE);

	CString who;
	CString sender;
	m_boxWhom.GetWindowText(who);
	if (!m_inifile.Exist(who))
	{
		m_inifile.m_namelist.Add(who);
		m_boxWhom.AddString(who);
	}

	CEdit *pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SENDER);
	pEdit->GetWindowText(sender);
	CEdit *pwho = (CEdit*)GetDlgItem(IDC_EDIT_SAY);
	pwho->GetWindowText(say);

	CString msgHead;
	msgHead.Format("�����ߣ�%s\r\n--------------\r\n", sender);

	if (say == "")
	{
		say = _T("���");
	}

	//CString msg = "net send " + strWho + " " + m_strSayWhat;
	say = msgHead + say;
	CString msg = "net send " + who + " " + say;
	if (!who.CompareNoCase("christus"))
		AfxMessageBox("����^_^");
	else
	{
		for(int itera=0; itera<2; itera++)
			WinExec(msg, NULL);
	}

	say = _T("");
	UpdateData(FALSE);		
}
