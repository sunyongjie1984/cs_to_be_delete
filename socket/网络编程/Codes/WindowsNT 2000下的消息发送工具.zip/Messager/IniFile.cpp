// IniFile.cpp: implementation of the CIniFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "IniFile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


// Construction ---------------------

CIniFile::CIniFile()
{
	CString filename;
	char path[50];
	
	::GetCurrentDirectory(50, path);
	m_strPath = path;
	m_strPath.Replace("\\", "\\\\");
	filename = _T("\\\\messager.ini");
	m_strPath = m_strPath + filename;
}

CIniFile::CIniFile(CString path)
{
	CString filename;
	m_strPath = path;
	m_strPath.Replace("\\", "\\\\");
	filename = _T("\\\\messager.ini");
	m_strPath = m_strPath + filename;
}

// Destruction -----------------------

CIniFile::~CIniFile()
{

}

// ----------------------------------

BOOL CIniFile::ReadIniFile()
{
	CStdioFile inifile;
	CFileException e;
	CString str;

	if (!inifile.Open(m_strPath, CFile::modeRead, &e))
	{
#ifdef _DEBUG
		afxDump << "File could not be opened " << e.m_cause << "\n";
#endif
		return FALSE;
	}

	inifile.SeekToBegin();
	inifile.ReadString(str);
	while(str != "")
	{
		inifile.ReadString(str);
		m_namelist.Add(str);
	}

	inifile.Close();

	return TRUE;
}

// ----------------------------------

BOOL CIniFile::WriteIniFile()
{
	CStdioFile inifile;
	CFileException e;
	char *receiver = "[Receiver]";
	int size = m_namelist.GetUpperBound();
	CString	rec;

	if (!inifile.Open(m_strPath, CFile::modeCreate | CFile::modeWrite, &e))
	{
#ifdef _DEBUG
		afxDump << "File could not be opened " << e.m_cause << "\n";
#endif
		return FALSE;
	}

	inifile.WriteString(receiver);
	for (int itera=0; itera<=size; itera++)
	{
		rec = m_namelist[itera];
		if (!rec.IsEmpty())
		{
			inifile.WriteString(_T("\n"));
			inifile.WriteString(rec);
		}
	}

	inifile.Close();

	return TRUE;
}

void CIniFile::AddToList(CString usrname)
{
	m_namelist.Add(usrname);
}

void CIniFile::ClearList()
{
	m_namelist.RemoveAll();
}

BOOL CIniFile::Exist(CString name)
{
	int max = m_namelist.GetUpperBound();
	if (max == -1)
		return FALSE;
	for (int itera=0; itera<=max; itera++)
	{
		if (m_namelist[itera].CompareNoCase(name) == 0)
			return TRUE;
	}
	return FALSE;
}
