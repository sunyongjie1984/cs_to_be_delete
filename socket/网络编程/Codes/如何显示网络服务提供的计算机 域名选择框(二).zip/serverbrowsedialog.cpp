// serverbrowsedialog.cpp (Windows NT/2000)
//
// This example will show how you can display the choose Server dialog
// provided by network services.  
// 
// (c)1999 Ashot Oganesyan K, SmartLine, Inc
// mailto:ashot@aha.ru, http://www.protect-me.com, http://www.codepile.com

#include <windows.h>
#include <stdio.h>


// ntlanman!ServerBrowseDialogA0 (NT specific!)
// 
// The ServerBrowseDialogA0 function creates a dialog box that lets the user
// select the computer.
//
//
// DWORD ServerBrowseDialogA0(
//   HWND   hwndOwner,       // Handle to the owner window for the dialog box.
//   LPSTR  szName,          // Address of a buffer to receive the display name
//                           // of the computer selected by the user (ANSI!).
//   DWORD  dwBufSize,       // The size of the buffer szName in characters.
// );



typedef DWORD (WINAPI *PROCSERVERBROWSEIALOG)(HWND,LPSTR,DWORD);


BOOL ServerBrowser(HWND hWndParent,LPSTR CompName,DWORD dwBufLen);


void main(int argc, char* argv[])
{
    CHAR CompName[MAX_COMPUTERNAME_LENGTH + 1];

    if (ServerBrowser(NULL,CompName,sizeof(CompName)/sizeof(CHAR)))
       printf(CompName);
}

BOOL ServerBrowser(HWND hWndParent,LPSTR CompName,DWORD dwBufLen)
{
    PROCSERVERBROWSEIALOG ServerBrowseDialog;
    BOOL                  bOK;
    HINSTANCE             hLibrary;
    DWORD                 dwError;

    hLibrary = LoadLibrary(TEXT("ntlanman.dll"));
    if (!hLibrary)
       return FALSE;

    ServerBrowseDialog = (PROCSERVERBROWSEIALOG)
                         GetProcAddress(hLibrary,"ServerBrowseDialogA0");

    if (!ServerBrowseDialog)
	{
        FreeLibrary(hLibrary);
        return FALSE;
	}


	dwError = ServerBrowseDialog( hWndParent,
                                  CompName,
                                  dwBufLen );
    FreeLibrary(hLibrary);

    if (dwError!=NO_ERROR)
        return FALSE;

	if(CompName[0] == '\\' && CompName[1] == '\\')
		bOK = TRUE;
	else
		bOK = FALSE;

	return bOK;
}