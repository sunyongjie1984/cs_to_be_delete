/*! 
 ************************************************************************
 * \file   TsbDevInterfaceGuids.h
 * \brief  Toshiba��USB�g�ѓd�b�̓Ǝ��f�o�C�X�C���^�[�t�F�C�XGUID���`����
 * 
 * \author hfukaya
 *********************************************************************
 * \date   2004/09/24 Created
 *         2005/02/08 Added Interfaces for Toshiba Proprietary Device 
 *********************************************************************
 */
#ifndef _TSBDEVINTERFACEGUIDS_H
#define _TSBDEVINTERFACEGUIDS_H

#include "initguid.h"

// WMC(Wireless Mobile Communication) Driver
// tsbenum.sys, tsbvfmdm.sys, tsbvfatc.sys, tsbvfobe.sys
// {5A5CAAC7-4A14-4aa5-A616-97BD8D0F6B2F}
DEFINE_GUID(GUID_DEVINTERFACE_TSBWMC, 
			0x5a5caac7, 0x4a14, 0x4aa5, 0xa6, 0x16, 0x97, 0xbd, 0x8d, 0xf, 0x6b, 0x2f);

// WMC Bus Driver: tsbenum.sys
// {B3F7EB58-AA53-45cd-9429-246A0079F0DB}
DEFINE_GUID(GUID_DEVINTERFACE_TSBWMC_WHCM, 
			0xb3f7eb58, 0xaa53, 0x45cd, 0x94, 0x29, 0x24, 0x6a, 0x0, 0x79, 0xf0, 0xdb);

// WMC Modem Driver: tsbvfmdm.sys
// {306C78FB-0599-44ee-9D57-F73B57BEB76D}
DEFINE_GUID(GUID_DEVINTERFACE_TSBWMC_MDM, 
			0x306c78fb, 0x599, 0x44ee, 0x9d, 0x57, 0xf7, 0x3b, 0x57, 0xbe, 0xb7, 0x6d);

// WMC AT Command Driver: tsbvbatc.sys
// {F8C1A5C6-E68E-407b-9CEE-99F65A295C01}
DEFINE_GUID(GUID_DEVINTERFACE_TSBWMC_ATC, 
			0xf8c1a5c6, 0xe68e, 0x407b, 0x9c, 0xee, 0x99, 0xf6, 0x5a, 0x29, 0x5c, 0x1);

// WMC OBEX Driver: tsbvfobe.sys
// {3E536C23-3B20-40b2-8F98-39016CDBC80F}
DEFINE_GUID(GUID_DEVINTERFACE_TSBWMC_OBEX, 
			0x3e536c23, 0x3b20, 0x40b2, 0x8f, 0x98, 0x39, 0x1, 0x6c, 0xdb, 0xc8, 0xf);

/////////////////////////////////////////////////////////////////////////////////////////

// Toshiba USB Download mode: tsbdload.sys
// {FC2E767E-5AD9-4717-BA39-91A5C9F083A9}
DEFINE_GUID(GUID_DEVINTERFACE_TSBDLOAD, 
			0xfc2e767e, 0x5ad9, 0x4717, 0xba, 0x39, 0x91, 0xa5, 0xc9, 0xf0, 0x83, 0xa9);

/////////////////////////////////////////////////////////////////////////////////////////

// Toshiba Proprietary Modem Driver
// {EC2CFBC3-7CA1-4b7c-A9A8-7B14FC515491}
DEFINE_GUID(GUID_DEVINTERFACE_TSB_MDM, 
			0xec2cfbc3, 0x7ca1, 0x4b7c, 0xa9, 0xa8, 0x7b, 0x14, 0xfc, 0x51, 0x54, 0x91);

// Toshiba Proprietary Serial Driver
// {5394304E-A8DD-4d35-B3DC-AE5DBED1AB55}
DEFINE_GUID(GUID_DEVINTERFACE_TSB_SER, 
			0x5394304e, 0xa8dd, 0x4d35, 0xb3, 0xdc, 0xae, 0x5d, 0xbe, 0xd1, 0xab, 0x55);

#endif