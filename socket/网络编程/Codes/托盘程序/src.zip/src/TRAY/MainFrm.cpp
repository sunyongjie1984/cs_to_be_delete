// MainFrm.cpp : CMainFrame �N���X�̓���̒�`���s���܂��B
//

#include "stdafx.h"
#include "dbt.h"

#include "tuopan.h"
#include "MainFrm.h"
#include "TsbDevInterfaceGuids.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define WM_NOTIFYICON	WM_USER+5
/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_MENUITEM32771, OnMenuitem32771)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
//------->>Add by haoyue
	ON_MESSAGE(WM_NOTIFYICON, OnNotifyIcon)
	ON_WM_SYSCOMMAND( )
//<<------Add by haoyue
// --> add by liaor
	ON_WM_DEVICECHANGE()
// <-- add by liaor
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // �X�e�[�^�X ���C�� �C���W�P�[�^
	ID_INDICATOR_KANA,
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame �N���X�̍\�z/����

CMainFrame::CMainFrame()
{
	// TODO: ���̈ʒu�Ƀ����o�̏����������R�[�h��ǉ����Ă��������B
// --> add by liaor
	m_hDevNotify = NULL;
// <-- add by liaor
}

CMainFrame::~CMainFrame()
{
	
}
/*void CMainFrame::DeleteIcon()
{
	::Shell_NotifyIcon (NIM_DELETE,&tnd);
}*/
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{

	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // �쐬�Ɏ��s
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // �쐬�Ɏ��s
	}

//----->Add by haoyue 2004/12/24
//	NOTIFYICONDATA tnd;
	tnd.cbSize =sizeof(NOTIFYICONDATA);
	tnd.hWnd =this->m_hWnd ;
	tnd.uID =IDR_MAINFRAME ;
	tnd.uFlags =NIF_MESSAGE|NIF_ICON|NIF_TIP;
	
	tnd.uCallbackMessage =WM_NOTIFYICON;
	tnd.hIcon =LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDR_MAINFRAME));
	strcpy(tnd.szTip ,"test");
	Shell_NotifyIcon(NIM_ADD,&tnd);
//<-----Add by haoyue 2004/12/24	

// --> add by liaor
    DEV_BROADCAST_DEVICEINTERFACE filter = {0};
    filter.dbcc_size = sizeof(DEV_BROADCAST_DEVICEINTERFACE);
    filter.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
    filter.dbcc_classguid = GUID_DEVINTERFACE_TSB_SER;
	HDEVNOTIFY m_hDevNotify = ::RegisterDeviceNotification(m_hWnd, &filter, DEVICE_NOTIFY_WINDOW_HANDLE);
    if(NULL != m_hDevNotify) {
		TRACE("Registered for notification: %08x-%04x-%04x-...\n", GUID_DEVINTERFACE_TSB_SER.Data1, 
																   GUID_DEVINTERFACE_TSB_SER.Data2,
																   GUID_DEVINTERFACE_TSB_SER.Data3);
	} else {
		TRACE("RegisterDeviceNotification failed: 0x%lx.\n", GetLastError());
		return FALSE;
    }
// <-- add by liaor

	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
	
	return 0;
}

void CMainFrame::OnDestroy() 
{
// --> add by liaor
	if (m_hDevNotify != NULL) {
		if (::UnregisterDeviceNotification(m_hDevNotify)) {
			TRACE("Unregistered for notification: %08x-%04x-%04x-...\n", GUID_DEVINTERFACE_TSB_SER.Data1, 
																		 GUID_DEVINTERFACE_TSB_SER.Data2,
																		 GUID_DEVINTERFACE_TSB_SER.Data3);
		} else {
			TRACE("UnregisterDeviceNotification failed: 0x%lx.\n", GetLastError());
		}
	}
// <-- add by liaor

	CFrameWnd::OnDestroy();
	// TODO: ���̈ʒu�Ƀ��b�Z�[�W �n���h���p�̃R�[�h��ǉ����Ă�������
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) ) 
		return FALSE;
//----->>Add by haoyue 2005/05/11
	cs.style =WS_POPUP;
	cs.dwExStyle |=WS_EX_TOOLWINDOW;
	return CFrameWnd::PreCreateWindow (cs);
//<<-----Add by haoyue 2005/05/11

}

//--> Add haoyue 2004/12/23
afx_msg void CMainFrame::OnNotifyIcon(WPARAM wParam, LPARAM lParam)
{

	UINT uID;
	UINT uMouseMsg;
	uID=(UINT)wParam;
	uMouseMsg=(UINT)lParam;
	CMenu menu;
/*
	if(uMouseMsg==WM_LBUTTONDBLCLK )
	{	 
		if(uID==IDR_MAINFRAME)
		{	
			GetCursorPos(&pt);	
	
			//AfxGetApp()-> m_pMainWnd->ShowWindow(SW_SHOWNORMAL);	
			ShowWindow(SW_SHOWNORMAL);
		}	
	}
*/
	if(uMouseMsg==WM_RBUTTONDOWN )
		{
			if(uID==IDR_MAINFRAME)
			{	
				BOOL bRet=SetForegroundWindow();
			//	GetCursorPos(&pt);
				menu.LoadMenu(IDR_MENU1);
				CMenu* pMenu=menu.GetSubMenu(0);
				CPoint pos;
				GetCursorPos(&pos);
				pMenu->TrackPopupMenu
				(TPM_LEFTALIGN|TPM_RIGHTBUTTON,
				pos.x,pos.y,AfxGetMainWnd());
			}

		}


}
//<-- Add haoyue 2004/12/23

//------�rAdd By haoyue 2004/12/24
void CMainFrame::OnSysCommand(UINT nID, LPARAM lParam)
{
	
	//if (nID == SC_MAXIMIZE)
	//	return;
	//if (nID == SC_MINIMIZE)
	//	{	
	//		ShowWindow(SW_HIDE);
	//	}
	if(nID==SC_CLOSE)
		{
			
			ShowWindow(SW_HIDE);
		}
	else

		CWnd::OnSysCommand(nID, lParam);
	
}

//<------Add By haoyue 2004/12/24
/*LRESULT CMainFrame::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{	
	switch(message)
	{ 
	case	WM_LBUTTONDBLCLK:
		UINT uID;
		UINT uMouseMsg;
		POINT pt;
		uID=(UINT)wParam;
		uMouseMsg=(UINT)lParam;

		if(uMouseMsg==WM_LBUTTONDBLCLK )
		{	 
			if(uID==IDR_MAINFRAME)
			{	
				GetCursorPos(&pt);		
				AfxGetApp()-> m_pMainWnd->ShowWindow(SW_SHOWNORMAL);	
			}	
		}
	}
	return 0;
}*/

/////////////////////////////////////////////////////////////////////////////
// CMainFrame �N���X�̐f�f

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame ���b�Z�[�W �n���h��


void CMainFrame::OnMenuitem32771() 
{	
	
	::Shell_NotifyIcon (NIM_DELETE,&tnd);
	SendMessage(WM_CLOSE);	


	
}

// --> add by liaor
BOOL CMainFrame::OnDeviceChange( UINT nEventType, DWORD_PTR dwData )
{
	BOOL bRet = FALSE;
	DEV_BROADCAST_HDR *pBCHDR = (DEV_BROADCAST_HDR*)dwData;
	DEV_BROADCAST_DEVICEINTERFACE *pBCDevIF = (DEV_BROADCAST_DEVICEINTERFACE*)dwData;

	if (nEventType == DBT_DEVICEARRIVAL 
		&& pBCHDR->dbch_devicetype == DBT_DEVTYP_DEVICEINTERFACE ) {
		TRACE("/DBT_DEVTYP_DEVICEINTERFACE\n");
		if (memcmp(&(pBCDevIF->dbcc_classguid), &GUID_DEVINTERFACE_TSB_SER, sizeof(GUID)) == 0) {
			TRACE("pBCDevIF->dbcc_name: %s\n", pBCDevIF->dbcc_name);
			::ShellExecute( ::GetDesktopWindow(), "open", "notepad.exe", "", "", SW_SHOW );
			bRet = TRUE;
		} else {
			TRACE("unknown device interface detected...\n");
		}
	} 

	return bRet;
}
// <-- add by liaor

//void CMainFrame::OnMenuitem32773() 
//{
//	ShowWindow(SW_SHOWNORMAL);
	
//}

