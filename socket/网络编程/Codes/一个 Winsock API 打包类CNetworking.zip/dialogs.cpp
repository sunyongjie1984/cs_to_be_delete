#include "main.h"

 
BOOL CALLBACK SendString(
  HWND hwndDlg,  // handle to dialog box
  UINT uMsg,     // message
  WPARAM wParam, // first message parameter
  LPARAM lParam  // second message parameter
)
{
	switch (uMsg)
	{
		case WM_INITDIALOG:
		{
			SetFocus (GetDlgItem (hwndDlg, IDC_MESSAGE));
			hWndDialog = hwndDlg;
			return TRUE;
		}
		case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
				case IDC_SENDBTN:
				{
					char szBuff[64];
					GetDlgItemText (hwndDlg, IDC_MESSAGE, szBuff, 64);

					Connection->Send (szBuff, strlen (szBuff));
					EndDialog (hwndDlg, 0);
					break;
				}
				default:
				{
					return FALSE;
				}
			}
			return TRUE;
		}
		case WM_CLOSE:
		{
			EndDialog (hwndDlg, 0);
			hWndDialog = NULL;
			break;
		}
	}
	return FALSE;
}

BOOL CALLBACK ConnectToIP(
  HWND hwndDlg,  // handle to dialog box
  UINT uMsg,     // message
  WPARAM wParam, // first message parameter
  LPARAM lParam  // second message parameter
)
{
	switch (uMsg)
	{
		case WM_INITDIALOG:
		{
			SetFocus (GetDlgItem (hwndDlg, IDC_IPADDRESS));
			hWndDialog = hwndDlg;
			return TRUE;
		}
		case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
				case IDC_CONNECT:
				{
					char szBuff[64];
					GetDlgItemText (hwndDlg, IDC_IPADDRESS, szBuff, 64);

					if (Connection)
						delete Connection;

					Connection = new CConnection ();
					Connection->SetReceiveFunc (ReceiveCallback);
					Connection->SetCloseFunc (CloseCallback);

					if (Connection->Connect (szBuff, CONNECT_PORT))
					{
						ShowWindow (hwndDlg, SW_HIDE);
						MessageBox (hwndDlg, "Now connected!", "Information", MB_OK | MB_ICONINFORMATION);
					}
					else
					{
						delete Connection;
						Connection = NULL;
					}

					EndDialog (hwndDlg, 0);
					break;
				}
				default:
				{
					return FALSE;
				}
			}
			return TRUE;
		}
		case WM_CLOSE:
		{
			EndDialog (hwndDlg, 0);
			hWndDialog = NULL;
			break;
		}
	}
	return FALSE;
}
