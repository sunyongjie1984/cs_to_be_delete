
#include "main.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
HWND hWnd, hWndDialog;								// handle of the dialog
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// The title bar text

CNetworking Networking;
CConnection* Connection = NULL;

int connections[8];								// holds our connection slots...

// Foward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);

void ReceiveCallback (DWORD ptr)
{
	char buff[1024] = "";
	CConnection* c = reinterpret_cast <CConnection*> (ptr);

	c->Receive (buff, 1024);
	MessageBox (hWnd, buff, "Information", MB_OK | MB_ICONINFORMATION);
}

void CloseCallback (DWORD ptr)
{
	MessageBox (hWnd, "The connection was closed.", "Information", MB_OK | MB_ICONINFORMATION);
}

void AcceptCallback (DWORD ptr)
{
	char			cip[15];
	unsigned int	cp = 0;
	CNetworking*	net = reinterpret_cast <CNetworking*> (ptr);

	if (Connection && Connection->IsConnected ())
	{
		CConnection* c = net->GetAccepted ();
		while (c)
		{
			char nocon[] = "The host can not accept your connection at this time.";
			c->Send (nocon, sizeof (nocon));
			c->Disconnect ();
			delete c;

			c = net->GetAccepted ();
		};
	}
	else
	{
		if (Connection)
			delete Connection;

		Connection = net->GetAccepted ();
		Connection->PeerInfo (&cip[0], 15, &cp);

		Connection->SetReceiveFunc (ReceiveCallback);
		Connection->SetCloseFunc (CloseCallback);

		char			ci[128];
		sprintf (ci, "A connection was accepted.\n\nClient Information:\n   %s:%i\n\n", cip, cp);
		MessageBox (hWnd, ci, "Client Info", MB_OK | MB_ICONINFORMATION);
	}
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	MSG msg;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDS_NETWORKING, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage is only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_NETWORKING);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW);
	wcex.lpszMenuName	= (LPCSTR)IDM_NETWORKING;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;

	switch (message) 
	{
		case WM_CREATE:
		{
			hWndDialog = NULL;
			SetWindowPos (hWnd, HWND_TOP, 0, 0, 200, 44, SWP_NOOWNERZORDER | SWP_NOMOVE);

			char jakobIP[225] = "";
			Networking.GetLocalIPs (jakobIP, 225);
			MessageBox(NULL, jakobIP, "Info", NULL);

			Networking.SetAcceptFunc (AcceptCallback);
 			break;
		}
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 

			// Parse the menu selections:
			switch (wmId)
			{
				case IDM_EXIT:
				   DestroyWindow (hWnd);
				   break;
				case IDM_LISTEN:
					if (Connection)
					{
						if (MessageBox (hWnd, "You are still connected to a computer.\nPress Yes if you want to disconnect and No to abort.\n\nSince this is just a demonstration of what you can\ndo with Networking I kept things simple.", NULL, MB_YESNO | MB_ICONSTOP) == IDNO)
							break;

						delete Connection;
						Connection = NULL;
					}

					if (!Networking.Listen (CONNECT_PORT))
					{
						char cPort[1024] = "";
						sprintf (cPort, "Unable to listen at port %i", CONNECT_PORT);
						MessageBox (hWnd, cPort, NULL, MB_OK | MB_ICONSTOP);
					}
					else
					{
						char cPort[1024] = "";
						sprintf (cPort, "Now listening at port %i!\nPress 'Ok' to accept incoming connections.", CONNECT_PORT);
						MessageBox (hWnd, cPort, "Listening", MB_OK | MB_ICONINFORMATION);
					}
					break;
				case IDM_CANCELLISTEN:
					if (Networking.IsListening ())
						Networking.StopListen ();
					else
						MessageBox (hWnd, "Unable to cancel listen-process!\nMake sure you are listening.", NULL, MB_OK | MB_ICONINFORMATION);
					break;
				case IDM_CONNECT:
				{
					if (Connection)
					{
						Connection->Disconnect ();
					}
					DialogBox (hInst, "CONNECTIP", hWnd, ConnectToIP);

					break;
				}
				case IDM_SENDMSG:
					if (!Connection)
						MessageBox(hWnd, "Please connect before sending data.", NULL, MB_OK | MB_ICONINFORMATION);
					else
						DialogBox(hInst, "SENDMSG", hWnd, SendString);
					break;
				case IDM_DISCONNECT:
					if (Connection)
						Connection->Disconnect ();
					else
						MessageBox (hWnd, "Unable to close connection!\nMake sure you are connected.", NULL, MB_OK | MB_ICONINFORMATION);
					break;
				case IDM_LISTLAN:
				{
					char lanlist[1024] = "";
					Networking.GetNeighborhood (lanlist, 1024);
					MessageBox (hWnd, lanlist, "Information", MB_OK | MB_ICONINFORMATION);
				}
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc (hWnd, message, wParam, lParam);
	}
	return 0;
}

