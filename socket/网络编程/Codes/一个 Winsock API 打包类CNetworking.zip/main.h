#include <windows.h>
#include "resource.h"
#include "CConnection.h"

extern HWND			hWndDialog;		// used to pass the handle of the dialog the main.cpp
extern CConnection*	Connection;
extern CNetworking	Networking;

#define CONNECT_PORT 10205

void ReceiveCallback (DWORD ptr);
void CloseCallback (DWORD ptr);
void AcceptCallback (DWORD ptr);

BOOL CALLBACK SendString(
  HWND hwndDlg,  // handle to dialog box
  UINT uMsg,     // message
  WPARAM wParam, // first message parameter
  LPARAM lParam  // second message parameter
);

BOOL CALLBACK SendFile(
  HWND hwndDlg,  // handle to dialog box
  UINT uMsg,     // message
  WPARAM wParam, // first message parameter
  LPARAM lParam  // second message parameter
);

BOOL CALLBACK ConnectToIP(
  HWND hwndDlg,  // handle to dialog box
  UINT uMsg,     // message
  WPARAM wParam, // first message parameter
  LPARAM lParam  // second message parameter
);
