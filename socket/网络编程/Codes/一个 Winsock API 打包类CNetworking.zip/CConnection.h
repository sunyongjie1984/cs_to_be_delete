
#ifndef CCONNECTION_H
#define CCONNECTION_H

#include <winsock.h>
#include <stdio.h>

#pragma comment(lib, "wsock32.lib")		// search for wsock32 lib at compile time
#pragma comment(lib, "mpr.lib")			// search for mpr lib at compile time

typedef void (*CALLBACKFUNC)(DWORD ptr);

//	little class to make code more readable
class CSync
{
	HANDLE		m_sync;

public:
	CSync ();
	~CSync ();

	CSync (CSync& s);
	CSync& operator= (CSync& s);

	void Enter () const;
	void Leave () const;
};

//	another little class :)
//	(class itself is not thread-safe)
class CError
{
	long		m_number;

	CError (long err);

	friend class CNetworking;
	friend class CConnection;
	friend class CSync;

public:

	long GetErrorString (char* str, long len);
};

//	class definition for CNetworking
//	this class is thread-safe!
//	access to Tag is NOT synchronized!
class CNetworking
{
public:

	//	a FIFO style list
	class CConnectionList
	{
		class Node
		{
		public:
			CConnection*	m_con;
			Node*			m_next;

			Node ();
		};

		Node*		m_first;
		Node*		m_last;
		int			m_length;

	public:
		CConnectionList ();
		~CConnectionList ();

		void			Add (CConnection* con);
		CConnection*	Remove ();
		CConnection*	Remove (int i);
		CConnection*	Item (int i);
		CConnection*	operator [] (int i);
		long			Length ();
	};

private:
	static long		m_count;

	CSync			m_sync;
	CConnectionList	m_accepted;

	SOCKET			m_socket;
	sockaddr_in		m_addr;

	HANDLE			hAcceptEvent;
	CALLBACKFUNC	hAcceptFunc;

	HANDLE			hAcceptThread;
	DWORD			dwAcceptThreadID;

	CError			m_lasterror;

	int AcceptWait ();
	static int AcceptThread (void* pThis);

	void			SetLastError (long err);

	//	allow CConnection to do stuff with this class
	//	actually, it should only check if Winsock is
	//	already intialized or not
	friend class CConnection;

public:
	CNetworking ();
	~CNetworking ();

	bool			Listen (int port);

	void			StopListen ();
	CConnection*	GetAccepted ();

	void			SetAcceptEvent (HANDLE hEvent);
	void			SetAcceptFunc (CALLBACKFUNC hFunc);

	int				HasAccepted ();
	bool			IsListening ();

	bool			GetLocalName(char *localname, int len);
	bool			GetLocalIP(char *localip, int len);
	bool			GetLocalIPs(char *localips, int len);
	bool			ResolveName(char *hostip, char *hostname, int len);
	bool			ResolveIP(char *hostname, char *hostip, int len);
	bool			ResolveIPs(char *hostname, char *hostips, int len);

	bool			GetNeighborhood(char* names, int len);

	void			GetLastError (char* str, long len);

	DWORD			Tag;
};

//	class definition for CConnection
//	this class is thread-safe!
//	access to Tag is NOT synchronized!
class CConnection
{
	//	used to cache the received data
	//	this class is thread-safe!
	class CDataStack
	{
		char*		m_buffer;
		long		m_length;
		CSync		m_sync;

	public:
		CDataStack ();
		~CDataStack ();

		void Append (const char* data, int len);
		int Remove (char* data, int len);
		int Length ();
	};

	static long		m_count;

	HANDLE			m_event;
	CSync			m_sync;
	CDataStack		m_data;

	SOCKET			m_socket;
	sockaddr_in		m_addr;

	HANDLE			hRecvEvent;
	CALLBACKFUNC	hRecvFunc;
	HANDLE			hCloseEvent;
	CALLBACKFUNC	hCloseFunc;

	HANDLE			hRecvThread;
	DWORD			dwRecvThreadID;

	CError			m_lasterror;

	int RecvWait ();
	static int RecvThread (void* pThis);

	void SetLastError (long err);

	//	allow CNetworking to do stuff with this class
	friend class CNetworking;

public:

	CConnection ();
	CConnection (const char* host, unsigned short port);
	~CConnection ();

	bool	Connect (const char* host, unsigned short port);
	void	Disconnect ();

	bool	PeerInfo (char* host, int host_len, unsigned int* port);

	int		Send (const char* buffer, int bufferlen);
	int		Receive (char* buffer, int bufferlen);

	void	SetReceiveEvent (HANDLE hEvent);
	void	SetReceiveFunc (CALLBACKFUNC hFunc);
	void	SetCloseEvent (HANDLE hEvent);
	void	SetCloseFunc (CALLBACKFUNC hFunc);

	bool	IsConnected ();
	int		HasReceived ();

	void	GetLastError (char* str, long len);

	DWORD	Tag;
};

#endif