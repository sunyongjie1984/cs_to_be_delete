// asdfasdfas.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "asdfasdfas.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;
#define PORT 34000

void GetFile(LPCTSTR strFilename)
{
	AfxSocketInit(NULL);
	CSocket sockClient;
	sockClient.Create();
	sockClient.Connect("127.0.0.1", PORT); // "127.0.0.1" is the IP to your server, same port

	int dataLength;
	sockClient.Receive(&dataLength, 4); //Now we get the File Size first
		
	byte* data = new byte[dataLength];
	sockClient.Receive(data, dataLength); //Get the whole thing

	CFile destFile(strFilename, CFile::modeCreate | CFile::modeWrite | CFile::typeBinary);

	destFile.Write(data, dataLength); // Write it

	destFile.Close();

	delete data;
	sockClient.Close();
}


int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
		GetFile("C:\\temp\\autoexec.bat");
	return nRetCode;
}


