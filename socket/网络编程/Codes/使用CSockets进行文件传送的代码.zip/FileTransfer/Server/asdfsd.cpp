// asdfsd.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "asdfsd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;

#define PORT 34000 /// Select any free port you wish

void SendFile(LPCTSTR strFilename)
{
	AfxSocketInit(NULL);
	CSocket sockSrvr; 
	sockSrvr.Create(PORT); // Creates our server socket
	sockSrvr.Listen(); // Start listening for the client at PORT
	CSocket sockRecv;
	sockSrvr.Accept(sockRecv); // Use another CSocket to accept the connection

	CFile myFile;
	if(!myFile.Open(strFilename, CFile::modeRead | CFile::typeBinary))
		return;

	int myFileLength = myFile.GetLength(); // Going to send the correct File Size

	sockRecv.Send(&myFileLength, 4); // 4 bytes long
		
	byte* data = new byte[myFileLength]; 

	myFile.Read(data, myFileLength);

	sockRecv.Send(data, myFileLength); //Send the whole thing now

	myFile.Close();
	delete data;

	sockRecv.Close();
}

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
		SendFile("C:\\autoexec.bat");
	return nRetCode;
}


