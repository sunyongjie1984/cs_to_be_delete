#ifndef __key_formatter__flex
#define __key_formatter__flex
#ifdef __cplusplus
extern "C" {
#endif

int key_formatter(char *format, char *key, int key_len, char *output, int output_len);
#ifdef __cplusplus
}
#endif

#endif
