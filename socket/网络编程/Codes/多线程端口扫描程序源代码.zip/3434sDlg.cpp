// 3434sDlg.cpp : implementation file
//

#include "stdafx.h"
#include "3434s.h"
#include "3434sDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
int iCounter=0;


class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)

	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy3434sDlg dialog

CMy3434sDlg::CMy3434sDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMy3434sDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMy3434sDlg)
	m_Eport = 0;
	m_IP = _T("");
	m_Sport = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMy3434sDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMy3434sDlg)
	DDX_Control(pDX, IDC_LIST1, m_List);
	DDX_Text(pDX, IDC_EPORT, m_Eport);
	DDX_Text(pDX, IDC_IP, m_IP);
	DDX_Text(pDX, IDC_SPORT, m_Sport);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMy3434sDlg, CDialog)
ON_MESSAGE(WM_USER_RECALC_DONE, OnRecalcDone)
	//{{AFX_MSG_MAP(CMy3434sDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy3434sDlg message handlers

BOOL CMy3434sDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMy3434sDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMy3434sDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMy3434sDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

UINT threadA(LPVOID pParam)
{

	thread *threada=(thread*)pParam;
	//���ڲ����´�
	HANDLE hCounterIn=OpenMutex(MUTEX_ALL_ACCESS,FALSE,"sam sp 44");
	WaitForSingleObject(hCounterIn,INFINITE);
	int v=iCounter;
	iCounter++;
	ReleaseMutex(hCounterIn);
	CloseHandle(hCounterIn);
/*
	CSocket m_socket;
	if(m_socket.Create(0,SOCK_STREAM,NULL)==TRUE)
	{
		::PostMessage(threada->m_hwnd,WM_USER_RECALC_DONE,v,0);
	}
	if(m_socket.Connect(threada->m_IP,v)==TRUE)
		::PostMessage(threada->m_hwnd,WM_USER_RECALC_DONE,v,0);
	m_socket.Close();
*/
    struct sockaddr_in sin;
	WSADATA wsaData;    
	SOCKET sd;
    int IpPort;
	char *IpAddr;
	IpAddr=threada->m_IP.GetBuffer(threada->m_IP.GetLength());
	IpPort=v;
    /* Init the Winsock */
    if(WSAStartup(0x0101, &wsaData ))
    {
        printf("Init TCP/IP stack error!");
        return 1;
    }
    if(wsaData.wVersion != 0x0101)
    {
        printf("Winsock version is incorrect!");
        WSACleanup();
        return 1;
    }

    /* Create the local socket */
    if ((sd = socket (PF_INET, SOCK_STREAM, IPPROTO_IP)) == INVALID_SOCKET) {
        printf("Create socket error!");
        return 1;
    }

    /* Connect to the victim IP Address */
    sin.sin_family=AF_INET;
    sin.sin_addr.s_addr=inet_addr(IpAddr);
    sin.sin_port=htons((short)IpPort);
    if (connect (sd, (struct sockaddr *)&sin, sizeof (sin)) == SOCKET_ERROR) {
        printf("Connect the remote IP error!");
        closesocket (sd);
        WSACleanup();
        return 1;
    }
	else
		::PostMessage(threada->m_hwnd,WM_USER_RECALC_DONE,v,0);
    closesocket (sd);

    WSACleanup();

	return 0;

}


void CMy3434sDlg::OnButton1() 
{
	m_List.ResetContent();
	GetDlgItem(IDC_BUTTON1)->EnableWindow(FALSE);
	UpdateData(TRUE);
	HANDLE hCounter=NULL;
	if( (hCounter=OpenMutex(MUTEX_ALL_ACCESS,FALSE,"sam sp 44"))==NULL)
	{
		//���û���������̴�������������������´���
		hCounter = CreateMutex(NULL,FALSE,"sam sp 44");
	}
	int v;
	if(m_Eport==m_Sport)
		v=1;
	else{
	v=(m_Eport-m_Sport)/100;
	if(((m_Eport-m_Sport)%100)>0)
		v++;
	}
	HANDLE hThread[100];
	CWinThread *pT[100];
	m_thread.m_hwnd=this->m_hWnd;
	m_thread.m_IP=m_IP;
	iCounter=m_Sport;
	//�����߳�
	for(int i=0;i<v;i++){
		int a=0;
		for(int k=0;k<100;k++)
		{
			a++;
			if(iCounter>=m_Eport)
				break;
			pT[k]=AfxBeginThread((AFX_THREADPROC)threadA,&m_thread);
//			iCounter++;
			hThread[k]=pT[k]->m_hThread;
//	        Sleep(100);
	//		break;
		}
		WaitForMultipleObjects(a,hThread,TRUE,INFINITE);
//		MessageBox("a");
		//�ȴ��߳̽���
	}
	//�رվ��
	CloseHandle(hCounter);	
	GetDlgItem(IDC_BUTTON1)->EnableWindow(TRUE);

}

LRESULT  CMy3434sDlg::OnRecalcDone(WPARAM wParam, LPARAM lParam)
{
//1	MessageBox("a");
	int a=(int)wParam;
	char bb[10];
	memset(bb,0,10);
	itoa(a,bb,10);
	m_List.AddString(bb);
	return 0;

}
