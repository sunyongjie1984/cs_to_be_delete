// 3434sDlg.h : header file
//

#if !defined(AFX_3434SDLG_H__D552B107_6FF3_11D5_8EDC_0000E84E8D09__INCLUDED_)
#define AFX_3434SDLG_H__D552B107_6FF3_11D5_8EDC_0000E84E8D09__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define WM_USER_RECALC_DONE (WM_USER + 2)
/////////////////////////////////////////////////////////////////////////////
// CMy3434sDlg dialog
#define WM_USER_RECALC_DONE (WM_USER + 2)
struct thread{
	HWND m_hwnd;
	CString m_IP;

};
class CMy3434sDlg : public CDialog
{
// Construction
public:
	thread m_thread;
	CMy3434sDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMy3434sDlg)
	enum { IDD = IDD_MY3434S_DIALOG };
	CListBox	m_List;
	int		m_Eport;
	CString	m_IP;
	int		m_Sport;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy3434sDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	LRESULT OnRecalcDone(WPARAM wParam, LPARAM lParam);
	// Generated message map functions
	//{{AFX_MSG(CMy3434sDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_3434SDLG_H__D552B107_6FF3_11D5_8EDC_0000E84E8D09__INCLUDED_)
