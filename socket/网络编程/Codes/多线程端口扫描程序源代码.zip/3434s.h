// 3434s.h : main header file for the 3434S application
//

#if !defined(AFX_3434S_H__D552B105_6FF3_11D5_8EDC_0000E84E8D09__INCLUDED_)
#define AFX_3434S_H__D552B105_6FF3_11D5_8EDC_0000E84E8D09__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMy3434sApp:
// See 3434s.cpp for the implementation of this class
//

class CMy3434sApp : public CWinApp
{
public:
	CMy3434sApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy3434sApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMy3434sApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_3434S_H__D552B105_6FF3_11D5_8EDC_0000E84E8D09__INCLUDED_)
