// Windy.cpp : Defines the entry point for the application.

#include "stdafx.h"
#include "resource.h"
#include <winsock.h>
#include <string.h>
#include <memory.h>
#include <commctrl.h>

#define MAX_LOADSTRING 100
#define UM_SOCK             WM_USER+100

// Global Variables:
TCHAR szTitle[MAX_LOADSTRING];				// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];
int Port;								
SOCKET s=0,ns=0;
struct hostent FAR *hostaddr,hostnm;
WSADATA wsaData;
in_addr FAR inaddr;
struct sockaddr_in soin,from,to;

char hostname[255]={0},Buffer[255]={0},ipStr[255]={0},FAR *lpBuffer;
int fromlength=0,recvlength=0,namelen=5;
unsigned long ipValue=0;

BOOL optval=TRUE;
HINSTANCE hInst;
HWND hWnd,hStatusBar,hedit,hClient;
HDC hdc;
RECT rc;
TEXTMETRIC tm;
int cxChar=0,cyChar=0,iVscrollPos=0;
int flag=0,spec=0;

ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK    BroadCast(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK    SendAndReceive(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK    ClientHandle(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK    ClientSendAndReceive(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK    ServerHandle(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK    ServerSendAndReceive(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK    GetInformationByHostName(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK    ScanPortByConnection(HWND,UINT,WPARAM,LPARAM);
void Handle_RecvString(char *);

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	MSG msg;
	HACCEL hAccelTable;
	lpBuffer=(char FAR *)&Buffer;

	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_WINDY, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_WINDY);
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return msg.wParam;
}
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_WINDY);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_3DSHADOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_WINDY;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }
   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	TCHAR szHello[MAX_LOADSTRING];
	LoadString(hInst, IDS_HELLO, szHello, MAX_LOADSTRING);
	int iStatusWidths[] = {200, 300, -1};


	switch (message) 
	{
	    case WM_CREATE:
			hClient=CreateWindow("EDIT", "",WS_CHILD | WS_VISIBLE | WS_VSCROLL|WS_HSCROLL| ES_MULTILINE |ES_WANTRETURN,CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,hWnd, (HMENU)ID_CLIENT,hInst, NULL);
            ShowWindow(hClient, SW_SHOW);
			hStatusBar = CreateWindowEx(0, STATUSCLASSNAME, NULL,WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP, 0, 0, 0,0,hWnd, (HMENU)ID_STATUSBAR,hInst,NULL);
			SendMessage(hStatusBar, SB_SETPARTS, 3, (LPARAM)iStatusWidths);
            SendMessage(hStatusBar, SB_SETTEXT, 2, (LPARAM)"Toolbar & Statusbar Example");			
		    return 0;
		case WM_SIZE:
			SendMessage(hStatusBar, WM_SIZE, 0, 0);
			if(wParam != SIZE_MINIMIZED)
            MoveWindow(GetDlgItem(hWnd, ID_CLIENT), 0, 0, LOWORD(lParam),HIWORD(lParam)-20, TRUE);
			break;
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			switch (wmId)
			{
				case IDM_ABOUT:
				   DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				   break;
				case IDM_EXIT:
				   DestroyWindow(hWnd);
				   break;
				case ID_GETINFORMATIONBYHOSTNAME:
					DialogBox(hInst,(LPCSTR)IDD_GETINFORMATIONBYHOSTNAME,hWnd,(DLGPROC)GetInformationByHostName);
					break;
				case ID_NET_BROADCAST:
					DialogBox(hInst,(LPCSTR)IDD_BROADCAST,hWnd,(DLGPROC)BroadCast);
					break;
				case ID_NET_CONNECTIONMANER_CLIENT:
					DialogBox(hInst,(LPCSTR)IDD_CLIENT,hWnd,(DLGPROC)ClientHandle);
					break;
				case ID_NET_CONNECTIONMANER:
					DialogBox(hInst,(LPCSTR)IDD_SERVER,hWnd,(DLGPROC)ServerHandle);
					break;
				case ID_CRACKER_SCANPORTBYCONNECTION:
					DialogBox(hInst,(LPCSTR)IDD_SCANPORT,hWnd,(DLGPROC)ScanPortByConnection);
					break;
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;
		case WM_PAINT:
			hdc = BeginPaint(hWnd, &ps);
			GetTextMetrics(hdc,&tm);
			cxChar=tm.tmAveCharWidth;
			cyChar=tm.tmHeight+tm.tmExternalLeading;
			SetBkMode(hdc,TRANSPARENT);
			SetTextColor(hdc,RGB(200,0,200));
			RECT rt;
			GetClientRect(hWnd, &rt);
			DrawText(hdc, szHello, strlen(szHello), &rt, DT_CENTER);
			EndPaint(hWnd, &ps);
			break;
		case WM_DESTROY:
			closesocket(s);
			WSACleanup();
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}
//handle the scan port function
LRESULT CALLBACK ScanPortByConnection(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	int i=0,count=0;
	switch (message)
	{
		case WM_INITDIALOG:	
			WSAStartup(0x101,&wsaData);
			gethostname(hostname,255);
			hostaddr=gethostbyname(hostname);
			if(hostaddr!=NULL)
			{
				inaddr.S_un.S_addr=*((unsigned long *)hostaddr->h_addr_list[0]);
				lpBuffer=inet_ntoa(inaddr);
				strcpy(ipStr,lpBuffer);
				lpBuffer=(char FAR *)&Buffer;
				SetDlgItemText(hDlg,1017,ipStr);
			}
				return TRUE;
		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK)
			{
				memset(ipStr,'\0',255);
				GetDlgItemText(hDlg,1017,ipStr,255);
				ipValue=inet_addr((char FAR *)ipStr);				
				EndDialog(hDlg,LOWORD(wParam));				
				
				from.sin_family=AF_INET;
		        from.sin_addr.S_un.S_addr=ipValue;
				for(i=0;i<=1024;i++)
				{  s=socket(AF_INET,SOCK_STREAM,0);				   
		           from.sin_port=htons(i);
		           fromlength=connect(s,(struct sockaddr FAR *)&from,sizeof(from));
				   if(fromlength==0)
				   {  
				      wsprintf(Buffer,"%d",i);
				      hdc=GetDC(hClient);
					  count++;
				      TextOut(hdc,0,count*cyChar,Buffer,10);
				      ReleaseDC(hClient,hdc);					  
				   }
				   shutdown(s,2);
				   closesocket(s);
				}
				
				
				WSACleanup();
			}
			if (LOWORD(wParam) == IDCANCEL) 
			{
				closesocket(s);
				WSACleanup();
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}
//Message handler for Get Infromation by host name or host addres
LRESULT CALLBACK GetInformationByHostName(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParamM)
{
	switch (message)
	{
		case WM_INITDIALOG:	
		WSAStartup(0x101,&wsaData);
		gethostname(hostname,255);
		SetDlgItemText(hDlg,1013,hostname);	
		hostaddr=gethostbyname(hostname);
			if(hostaddr!=NULL)
			{
				inaddr.S_un.S_addr=*((unsigned long *)hostaddr->h_addr_list[0]);
				lpBuffer=inet_ntoa(inaddr);
				strcpy(ipStr,lpBuffer);
				lpBuffer=(char FAR *)&Buffer;
				SetDlgItemText(hDlg,1016,ipStr);
			}
		return TRUE;
		case WM_COMMAND:
			if (LOWORD(wParam) ==IDOK)
			{
				if(GetDlgItemText(hDlg,1013,hostname,255)>0)
				{			
				hostaddr=gethostbyname(hostname);
				if(hostaddr!=NULL)
				{
				   inaddr.S_un.S_addr=*((unsigned long *)hostaddr->h_addr_list[0]);				
				   lpBuffer=inet_ntoa(inaddr);
				   strcpy(ipStr,lpBuffer);
				   lpBuffer=(char FAR *)&Buffer;
				   SetDlgItemText(hDlg,1016,ipStr);
				}
				}
				else
					if(GetDlgItemText(hDlg,1016,ipStr,255)>0)
					{
						ipValue=inet_addr((char FAR*)ipStr);
						hostaddr=gethostbyaddr((char *)&ipValue,4,PF_INET);
						strcpy(hostname,hostaddr->h_name);
						SetDlgItemText(hDlg,1013,hostname);
					}
			}
			if ( LOWORD(wParam) == IDCANCEL||LOWORD(wParam)==IDC_GETINFORMATIONBYHOSTNAME_BROWSE) 
			{
				WSACleanup();
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}

// Mesage handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:		   
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}
//Handle the BroadCast message
LRESULT CALLBACK BroadCast(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
			SetDlgItemInt(hDlg,1000,1100,TRUE);
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK) 
			{
				Port=GetDlgItemInt(hDlg,1000,NULL,TRUE);
				EndDialog(hDlg,LOWORD(wParam));
				DialogBox(hInst,(LPCSTR)IDD_SENDANDRECEIVE,hWnd,(DLGPROC)SendAndReceive);
				return TRUE;
			}
			if (LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg,LOWORD(wParam));
			}
			break;
	}
    return FALSE;
}

LRESULT CALLBACK SendAndReceive(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{	
	WSADATA wsaData;
	switch(message)
	{
	case WM_INITDIALOG:
		WSAStartup(0x101,&wsaData);
		s=socket(AF_INET,SOCK_DGRAM,0);

		soin.sin_family=AF_INET;
		soin.sin_addr.S_un.S_addr=0;
		soin.sin_port=htons(Port);
		bind(s,(LPSOCKADDR)&soin,sizeof(soin));
		setsockopt(s,SOL_SOCKET,SO_BROADCAST,(char FAR *)&optval,sizeof(optval));
		WSAAsyncSelect(s,hDlg,UM_SOCK,FD_READ|FD_WRITE);
		return TRUE;
	case UM_SOCK:
		switch(lParam)
		{
		case FD_READ:
			from.sin_family=AF_INET;
			from.sin_addr.S_un.S_addr=INADDR_BROADCAST;
			from.sin_port=htons(Port);
			fromlength=sizeof(SOCKADDR);
	        recvlength=recvfrom(s,lpBuffer,255,0,(struct sockaddr FAR *)&from,(int FAR *)&fromlength);

			hedit=GetDlgItem(hDlg,1001);
			hdc=GetDC(hedit);
			GetClientRect(hedit,&rc);
			InvalidateRect(hedit,&rc,FALSE);
			SetWindowText(hedit, lpBuffer);
			ReleaseDC(hDlg,hdc);

			break;
		case FD_WRITE:
			to.sin_family=AF_INET;
            to.sin_addr.S_un.S_addr=INADDR_BROADCAST;
            to.sin_port=htons(Port);
			hedit=GetDlgItem(hDlg,1001);
			GetWindowText(hedit,Buffer,255);
			sendto(s,lpBuffer,GetWindowTextLength(hedit),0,(struct sockaddr FAR *)&to,sizeof(SOCKADDR));
			break;
		case FD_CLOSE:
			closesocket(s);
			break;
		}
		break;
	case WM_COMMAND:
		if(LOWORD(wParam)==IDOK)
		{
			SendMessage(hDlg,UM_SOCK,(WPARAM)0,(LPARAM)FD_WRITE);
		}
		if(LOWORD(wParam)==IDCANCEL)
		{
			closesocket(s);
			WSACleanup();
			EndDialog(hDlg,LOWORD(wParam));
		}
		break;
	}
	return FALSE;
}
//finish the client function
LRESULT CALLBACK ClientHandle(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
			SetDlgItemInt(hDlg,1002,1100,TRUE);
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK) 
			{
				Port=GetDlgItemInt(hDlg,1002,NULL,TRUE);
				GetDlgItemText(hDlg,1010,ipStr,GetWindowTextLength(GetDlgItem(hDlg,1010))+1);
				ipValue=inet_addr((char FAR*)ipStr);  			
				EndDialog(hDlg,LOWORD(wParam));
				DialogBox(hInst,(LPCSTR)IDD_CLIENTSENDANDRECEIVE,hWnd,(DLGPROC)ClientSendAndReceive);				
				return TRUE;
			}
			if (LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg,LOWORD(wParam));
			}
			break;
	}
	return  FALSE;
}
RECT rect;
LRESULT CALLBACK ClientSendAndReceive(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch(message)
	{
	case WM_INITDIALOG:		
		WSAStartup(0x101,&wsaData);
		s=socket(AF_INET,SOCK_STREAM,0);
        WSAAsyncSelect(s,hDlg,UM_SOCK,FD_CONNECT|FD_READ|FD_WRITE);
		from.sin_family=AF_INET;
		from.sin_addr.S_un.S_addr=ipValue;
		from.sin_port=htons(Port);
		connect(s,(struct sockaddr FAR *)&from,sizeof(from));
	return TRUE;
	case UM_SOCK:
		switch(lParam)
		{
		case FD_READ:
			fromlength=recv(s,lpBuffer,1024,0);
			hedit=GetDlgItem(hDlg,1009);
			GetClientRect(hedit,&rect);
			InvalidateRect(hedit,&rect,FALSE);
			SetWindowText(hedit,lpBuffer);
			UpdateWindow(hedit);
			break;
		case FD_CONNECT:
			hdc=GetDC(hDlg);
			TextOut(hdc,0,0,"okok",4);
			ReleaseDC(hDlg,hdc);
			break;
		case FD_WRITE:			
			hedit=GetDlgItem(hDlg,1009);
			GetWindowText(hedit,Buffer,255);
			send(s,lpBuffer,GetWindowTextLength(hedit),0);
			break;
		case FD_CLOSE:
			closesocket(s);
			break;
		}
		break;
	case WM_COMMAND:
		if(LOWORD(wParam)==IDOK)
		{
			SendMessage(hDlg,UM_SOCK,(WPARAM)0,(LPARAM)FD_WRITE);
		}
		if(LOWORD(wParam)==IDCANCEL)
		{
			WSAAsyncSelect(s,hDlg,0,0);
			closesocket(s);
			WSACleanup();
			EndDialog(hDlg,LOWORD(wParam));
		}
		break;
	}
	return FALSE;
}
//handle the server
LRESULT CALLBACK ServerHandle(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
			SetDlgItemInt(hDlg,1011,1100,TRUE);
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK) 
			{
				Port=GetDlgItemInt(hDlg,1011,NULL,TRUE);
				EndDialog(hDlg,LOWORD(wParam));
				DialogBox(hInst,(LPCSTR)IDD_SERVERRECEIVEANDSEND,hWnd,(DLGPROC)ServerSendAndReceive);				
				return TRUE;
			}
			if (LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg,LOWORD(wParam));
			}
			if (LOWORD(wParam)==IDC_SPECIFICOPERATION)
				spec=1;
			break;
	}
	return  FALSE;
}

LRESULT CALLBACK ServerSendAndReceive(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{		
	switch(message)
	{
	case WM_INITDIALOG:	
		WSAStartup(0x101,&wsaData);
		gethostname(hostname,255);	
		hostaddr=gethostbyname(hostname);
		s=socket(AF_INET,SOCK_STREAM,0);
		WSAAsyncSelect(s,hDlg,UM_SOCK,FD_READ|FD_WRITE|FD_ACCEPT);
		soin.sin_family=AF_INET;
		soin.sin_port=htons(Port);
		soin.sin_addr.S_un.S_addr=*((unsigned long *)hostaddr->h_addr_list[0]);
		bind(s,(struct sockaddr FAR*)&soin,sizeof(soin));
		listen(s,5);		
		namelen=sizeof(from);		
		return TRUE;
	case UM_SOCK:
		switch(lParam)
		{
		case FD_ACCEPT:	
			ns=accept(s,(struct sockaddr *)&from,&namelen);		    
			break;
		case FD_READ:
			memset(Buffer,0,255);
			fromlength=recv(ns,lpBuffer,2048,0);
			hedit=GetDlgItem(hDlg,1012);
			InvalidateRect(hedit,NULL,FALSE);
			SetWindowText(hedit,lpBuffer);
			if(spec==1)
				Handle_RecvString(Buffer);
			break;
		case FD_WRITE:			
			hedit=GetDlgItem(hDlg,1012);
			GetWindowText(hedit,Buffer,255);
			send(ns,lpBuffer,GetWindowTextLength(hedit),0);
			break;
		case FD_CLOSE:
			closesocket(ns);
			closesocket(s);
			break;
		}
		break;
	case WM_COMMAND:
		if(LOWORD(wParam)==IDOK)
		{
			SendMessage(hDlg,UM_SOCK,(WPARAM)0,(LPARAM)FD_WRITE);
		}
		if(LOWORD(wParam)==IDCANCEL)
		{
			WSAAsyncSelect(s,hDlg,0,0);
			closesocket(ns);
			closesocket(s);
			WSACleanup();
			EndDialog(hDlg,LOWORD(wParam));
		}
		break;
	}
	return FALSE;
}
//handle the received string(ServerSendAndReceive()),this part is blong to above part programe
void Handle_RecvString(char *Buffer)
{         
	    flag=-1;
		if(strcmpi(Buffer,"exit")==0)
		  flag=0;
		if(strcmpi(Buffer,"ok")==0)
		  flag=1;
         
        switch(flag) 
		{
		case 0:ExitWindows(EWX_REBOOT);   break;
		case 1:MessageBox(GetDesktopWindow(),"OK","1",MB_OK);     break;
		}
	
}
