//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Windy.rc
//
#define IDC_MYICON                      2
#define IDD_WINDY_DIALOG                102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_WINDY                       107
#define IDI_SMALL                       108
#define IDC_WINDY                       109
#define IDR_MAINFRAME                   128
#define IDD_BROADCAST                   129
#define IDD_SENDANDRECEIVE              130
#define IDD_CLIENT                      133
#define IDD_CLIENTSENDANDRECEIVE        134
#define IDD_SERVER                      135
#define IDD_SERVERRECEIVEANDSEND        136
#define IDD_GETINFORMATIONBYHOSTNAME    137
#define IDD_SCANPORT                    138
#define IDC_PORT                        1000
#define IDC_SENDANDRECEIVE              1001
#define IDC_CLIENTPORT                  1002
#define IDC_CLIENT                      1009
#define IDC_IP                          1010
#define IDC_SERVERPORT                  1011
#define IDC_SERVER1                     1012
#define IDC_GETINFORMATIONBYHOSTNAME_HOSTNAME 1013
#define IDC_GETINFORMATIONBYHOSTNAME_BROWSE 1014
#define IDC_GETINFORMATIONBYHOSTNAME_HOSTIP 1016
#define IDC_SCANPORT_IP                 1017
#define IDC_SPECIFICOPERATION           1019
#define ID_STATUSBAR                    5000
#define ID_CLIENT                       5001
#define ID_MENUITEM32773                32773
#define ID_NET_BROADCAST                32774
#define ID_NET_CONNECTIONMANER_CLIENT   32775
#define ID_NET_CONNECTIONMANER          32776
#define ID_GETINFORMATIONBYHOSTNAME     32777
#define ID_CRACKER_SCANPORTBYCONNECTION 32778
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
