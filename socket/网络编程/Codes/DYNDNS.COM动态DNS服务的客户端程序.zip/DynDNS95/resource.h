//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DynDNS95.rc
//
#define SmallIcon                       129
#define IDD_DynDNS                      132
#define IDD_DIALOG1                     133
#define IDD_DynDNSSetup                 134
#define IDD_DynDNSAdvanced              135
#define IDD_Log                         139
#define IDC_HIDE                        1000
#define IDC_SETUP                       1001
#define IDC_UPDATE                      1002
#define IDC_START                       1003
#define IDC_QUIT                        1005
#define IDC_MESSAGE                     1007
#define IDC_STATIC_SUCCESS              1008
#define IDC_OK                          1008
#define IDC_STATIC_SinceUpdate          1008
#define IDC_STATIC_ATTEMPT              1009
#define IDC_CONCEL                      1009
#define IDC_CANCEL                      1009
#define IDC_STATIC_ToUpdate             1009
#define IDC_STATIC_STATUS               1010
#define IDC_ADVANCED                    1010
#define IDC_STATIC_DOMAIN               1011
#define IDC_UNAME                       1011
#define IDC_STATIC_IP                   1012
#define IDC_PASSWD                      1012
#define IDC_STATIC_MODE                 1013
#define IDC_DOMAIN                      1013
#define IDC_IP                          1014
#define IDC_RADIO1                      1015
#define IDC_Original                    1015
#define IDC_Dot51                       1016
#define IDC_MULTIPLE                    1017
#define IDC_MUILTIPLE                   1021
#define IDC_STATIC_MULTIPLE             1022
#define IDC_STATIC_CIP                  1023
#define IDC_STATIC_CMX1                 1024
#define IDC_STATIC_CMX2                 1025
#define IDC_STATIC_RIP                  1026
#define IDC_STATIC_RMX1                 1027
#define IDC_STATIC_RMX2                 1028
#define IDC_CIP                         1030
#define IDC_CMX1                        1031
#define IDC_CMX2                        1032
#define IDC_RIP                         1033
#define IDC_RMX1                        1034
#define IDC_RMX2                        1035
#define IDC_ORIGSLEEP                   1036
#define IDC_DOT51SLEEP                  1037
#define IDC_CHECKTIME                   1038
#define IDC_AUTOUPDATE                  1042
#define IDC_SHOWMESSAGES                1043
#define IDC_EDIT1                       1044
#define IDC_EDIT_LOG                    1045
#define IDC_INFO                        1046

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1047
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
