#define WM_NOTIFYICON		(WM_USER+100)
#define SmallIcon 129
#define SecondCount	10324
