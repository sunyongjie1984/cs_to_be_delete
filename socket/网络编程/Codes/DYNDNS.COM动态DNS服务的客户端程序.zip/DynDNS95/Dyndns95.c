/* TO DO:								*/
/*		Randomize local connection port	*/

#include <windowsx.h>   
#include <windows.h>   
#include <winsock.h>
#include <stdio.h>
#include <shellapi.h>
#include <winsock.h>
#include <string.h>
#include "resource.h"
#include "DynDNS95.h"

#define REMOTEPORT 50
#define REMOTEHOST "master.dyndns.com"

#define NAME "DYNDNS.COM Win95/NT Client BETA"
#define VERSION "4.95-client-a"
#define AUTHOR "Gus Hurwitz"
#define CONTACT "ghurwitz@dyndns.com"

#define RegDynDNSKey "Software\\DynDNS2000"

#define DUMMYPORT 2454  // This should be changed to something random

NOTIFYICONDATA tnid;
HINSTANCE gInstance;
HWND mDlg;
SOCKET s_internal_connect;
SOCKET s_internal_bind;
SOCKET s_dyndns;

int hidden=0;
int update=0;
int WSAStarted=0;
int AccountStatus=0;
int RunningUpdate=0;
int DEBUG2=0;

DWORD i;

char uname[64], passwd[64], domain[64], IP[20], MBuf[8192], MRec[2048], *RBuf;
char fulldomain[64];
char scratchpad[64], bigpad[1024];
static DWORD ToUpdate, IPCheckDelay, SinceUpdate, RetryDelay;

int UpdateIP(HWND, char *, char *, char *, char *);
char FAR *Name2Addr(char *);
int IPCurrent(HWND);
BOOL CALLBACK DynDNSProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DynDNSSetupProc(HWND, UINT, WPARAM, LPARAM);
BOOL MySetDlgItemText(HWND, int, LPCTSTR, BOOL);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    MSG msg;
    HICON hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(SmallIcon));
	gInstance=hInstance;

	IP  [0] = '\0';
    memset(MBuf, 0, 8192);
    memset(MRec, 0, 2048);

    tnid.cbSize = sizeof(NOTIFYICONDATA);
    tnid.uID = 3265;
    tnid.hWnd = NULL;
    tnid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
    tnid.uCallbackMessage = WM_NOTIFYICON;
    tnid.hIcon = hIcon;
    strcpy(tnid.szTip, "DynDNS.com Updater");  

	tnid.hWnd = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_DynDNS), NULL, DynDNSProc);
	Shell_NotifyIcon(NIM_ADD, &tnid);

    while (GetMessage(&msg, NULL, 0, 0))
        {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
		}
    return (msg.wParam);
}

BOOL CALLBACK DynDNSSetupProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	HKEY hKey;
	DWORD cbData;
	char debug[64];

	switch(uMsg)
	{
	case WM_INITDIALOG:
	case WM_CREATE:
		{
		if(RegOpenKeyEx(HKEY_CURRENT_USER, RegDynDNSKey, 0, KEY_QUERY_VALUE,&hKey)!=ERROR_SUCCESS)
			{
			}
		else
			{
			cbData=64;	RegQueryValueEx(hKey, "domain", NULL, NULL, scratchpad, &cbData);scratchpad[cbData]='\0';
			MySetDlgItemText(hDlg, IDC_DOMAIN, scratchpad, 0);
			cbData=64;	RegQueryValueEx(hKey, "passwd", NULL, NULL, scratchpad, &cbData);scratchpad[cbData]='\0';
			MySetDlgItemText(hDlg, IDC_PASSWD, scratchpad, 0);
			RegCloseKey(hKey);
			}
		}
		break;

	case WM_DESTROY:
		break;

	case WM_COMMAND:
		switch(wParam)
		{
		case IDC_OK:
			if(RegCreateKeyEx(HKEY_CURRENT_USER, RegDynDNSKey, 0, NULL, REG_OPTION_NON_VOLATILE, 
												 KEY_SET_VALUE, NULL, &hKey, &cbData)!=ERROR_SUCCESS)
				{
				MessageBox(hDlg, "Unable to access registry! Quiting.", "Fatal Error", MB_OK);
				exit(-1);
				}
			cbData = GetDlgItemText(hDlg, IDC_PASSWD,passwd, sizeof(scratchpad))+1;
			RegSetValueEx(hKey, "passwd", 0, REG_SZ, passwd, cbData);
			cbData = GetDlgItemText(hDlg, IDC_DOMAIN,domain, sizeof(scratchpad))+1;
			RegSetValueEx(hKey, "domain", 0, REG_SZ, domain, cbData);

			IPCheckDelay=300;
			RetryDelay=60;
			RegSetValueEx(hKey,        "uname", 0,    REG_SZ,"postmaster", strlen("postmaster"));
			RegSetValueEx(hKey,           "IP", 0,    REG_SZ,      "AUTO", strlen("AUTO"));
			RegSetValueEx(hKey, "IPCheckDelay", 0, REG_DWORD, (LPBYTE)&IPCheckDelay, sizeof(DWORD));
			RegSetValueEx(hKey,   "RetryDelay", 0, REG_DWORD,   (LPBYTE)&RetryDelay, sizeof(DWORD));
			
			RegCloseKey(hKey);
			EndDialog(hDlg, 0);
			break;
		case IDC_CANCEL:
			cbData = GetDlgItemText(hDlg, IDC_DOMAIN,debug, sizeof(scratchpad))+1;
			if(!strncmp("debug--1", debug, 8))
				{
				MessageBox(hDlg, MRec, "Debug", MB_OK);
				}
			else
			if(!strncmp("debug--2", debug, 8))
				{
				DEBUG2=(DEBUG2?0:1);
				MessageBox(hDlg, "Debug level 2 toggeled", "Debug", MB_OK);
				}
			EndDialog(hDlg, 0);
			break;
		}
		break;

	default:
		return(FALSE);
		break;
	}
	return(TRUE);
}

BOOL CALLBACK DynDNSProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_INITDIALOG:
	case WM_CREATE:
		{
			WSADATA WSAdata;
			HKEY hKey;
			DWORD cbData;

			if(RegOpenKeyEx(HKEY_CURRENT_USER, RegDynDNSKey, 0, KEY_QUERY_VALUE,&hKey)!=ERROR_SUCCESS)
				{
				DialogBox(gInstance, MAKEINTRESOURCE(IDD_DynDNSSetup), hDlg, DynDNSSetupProc);
				if(!strncmp("postmaster", uname, 10))
					{
					sprintf(fulldomain, "%s", domain);
					}
				else
					{
					sprintf(fulldomain, "%s.%s", uname, domain);
					}
				MySetDlgItemText(hDlg, IDC_STATIC_DOMAIN, fulldomain, 0);
				MySetDlgItemText(hDlg, IDC_STATIC_IP, IP, 0);
				MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Setup Complete", 1);
				if(RegOpenKeyEx(HKEY_CURRENT_USER, RegDynDNSKey, 0, KEY_QUERY_VALUE,&hKey)!=ERROR_SUCCESS)
					{
					MessageBox(hDlg, "Key Creation Failed! Quiting.", "Fatal Error", MB_OK);
					exit(-1);
					}
				}

			cbData=64; RegQueryValueEx(hKey,  "uname", NULL, NULL,  uname, &cbData);
			cbData=64; RegQueryValueEx(hKey, "passwd", NULL, NULL, passwd, &cbData);
			cbData=64; RegQueryValueEx(hKey, "domain", NULL, NULL, domain, &cbData);
			cbData=20; RegQueryValueEx(hKey,     "IP", NULL, NULL,     IP, &cbData);
			cbData=sizeof(DWORD); RegQueryValueEx(hKey,   "IPCheckDelay", NULL, NULL, (LPBYTE)&IPCheckDelay,   &cbData);
			cbData=sizeof(DWORD); RegQueryValueEx(hKey,   "RetryDelay", NULL, NULL, (LPBYTE)&RetryDelay,   &cbData);
			ToUpdate=IPCheckDelay;
			sprintf(scratchpad, "%.2d:%.2d:%.2d", ToUpdate/3600, ToUpdate/60, ToUpdate%60);
			MySetDlgItemText(hDlg, IDC_STATIC_ToUpdate, scratchpad, 0);
			RegCloseKey(hKey);

			MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Initializing...", 1);
			if(WSAStartup(0x0101, &WSAdata))
			{
				MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "WSAStartup Error", 1);
			}
			else
			{
				WSAStarted=1;
			}
			if(!strncmp("postmaster", uname, 10))
				{
				sprintf(fulldomain, "%s", domain);
				}
			else
				{
				sprintf(fulldomain, "%s.%s", uname, domain);
				}
			MySetDlgItemText(hDlg, IDC_STATIC_DOMAIN, fulldomain, 0);
			MySetDlgItemText(hDlg, IDC_STATIC_IP, IP, 0);
			MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Client Initialized", 1);
		}
		SetTimer(hDlg, SecondCount, 1000, NULL);
		mDlg = hDlg;
		break;

	case WM_DESTROY:
		Shell_NotifyIcon(NIM_DELETE, &tnid);
		WSACleanup();
		WSAStarted=0;
		break;

	case WM_TIMER:
		switch(wParam)
		{
		case SecondCount:
			if(!RunningUpdate)
				{
				ToUpdate--;
				sprintf(scratchpad, "%.2d:%.2d:%.2d", ToUpdate/3600, ToUpdate/60, ToUpdate%60);
				MySetDlgItemText(hDlg, IDC_STATIC_ToUpdate, scratchpad, 0);
				}
			SinceUpdate++;
			sprintf(scratchpad, "%.2d:%.2d:%.2d", SinceUpdate/3600, SinceUpdate/60, SinceUpdate%60);
			MySetDlgItemText(hDlg, IDC_STATIC_SinceUpdate, scratchpad, 0);

			if((!ToUpdate) && (!RunningUpdate))
				{
				MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Checking IP", 1);
				if(update)
					{
					MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Forced IP Update", 1);
					if(UpdateIP(hDlg, uname, passwd, domain, IP))
						{
						ToUpdate=IPCheckDelay;
						sprintf(scratchpad, "%.2d:%.2d:%.2d", ToUpdate/3600, ToUpdate/60, ToUpdate%60);
						MySetDlgItemText(hDlg, IDC_STATIC_ToUpdate, scratchpad, 0);
						SinceUpdate=0;
						sprintf(scratchpad, "%.2d:%.2d:%.2d", SinceUpdate/3600, SinceUpdate/60, SinceUpdate%60);
						MySetDlgItemText(hDlg, IDC_STATIC_SinceUpdate, scratchpad, 0);
						RunningUpdate=0;
						}
					else
						{
						ToUpdate=RetryDelay;
						sprintf(scratchpad, "%.2d:%.2d:%.2d", ToUpdate/3600, ToUpdate/60, ToUpdate%60);
						MySetDlgItemText(hDlg, IDC_STATIC_ToUpdate, scratchpad, 0);
						RunningUpdate=0;
						}
					}
				else
				if(!IPCurrent(hDlg))
					{
					MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Updating IP", 1);
					if(UpdateIP(hDlg, uname, passwd, domain, IP))
						{
						ToUpdate=IPCheckDelay;
						sprintf(scratchpad, "%.2d:%.2d:%.2d", ToUpdate/3600, ToUpdate/60, ToUpdate%60);
						MySetDlgItemText(hDlg, IDC_STATIC_ToUpdate, scratchpad, 0);
						SinceUpdate=0;
						sprintf(scratchpad, "%.2d:%.2d:%.2d", SinceUpdate/3600, SinceUpdate/60, SinceUpdate%60);
						MySetDlgItemText(hDlg, IDC_STATIC_SinceUpdate, scratchpad, 0);
						RunningUpdate=0;
						}
					else
						{
						ToUpdate=RetryDelay;
						sprintf(scratchpad, "%.2d:%.2d:%.2d", ToUpdate/3600, ToUpdate/60, ToUpdate%60);
						MySetDlgItemText(hDlg, IDC_STATIC_ToUpdate, scratchpad, 0);
						RunningUpdate=0;
						}
					}
				else
					{
					ToUpdate=IPCheckDelay;
					sprintf(scratchpad, "%.2d:%.2d:%.2d", ToUpdate/3600, ToUpdate/60, ToUpdate%60);
					MySetDlgItemText(hDlg, IDC_STATIC_ToUpdate, scratchpad, 0);
					RunningUpdate=0;
					}
				if(!ToUpdate)
					{
					RunningUpdate=1;
					}
				}
		break;
		}
		break;

	case WM_COMMAND:
		switch(wParam)
		{
		case IDC_HIDE:
			ShowWindow(hDlg, SW_HIDE);
			hidden=0;
			break;
		case IDC_SETUP:
			DialogBox(gInstance, MAKEINTRESOURCE(IDD_DynDNSSetup), hDlg, DynDNSSetupProc);
			if(!strncmp("postmaster", uname, 10))
				{
				sprintf(fulldomain, "%s", domain);
				}
			else
				{
				sprintf(fulldomain, "%s.%s", uname, domain);
				}
			MySetDlgItemText(hDlg, IDC_STATIC_DOMAIN, fulldomain, 0);
			MySetDlgItemText(hDlg, IDC_STATIC_IP, IP, 0);
			MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Setup Complete", 1);
			break;
		case IDC_UPDATE:
			ToUpdate=1;
			update=1;
			break;
		case IDC_QUIT:
			closesocket(s_dyndns);
			closesocket(s_internal_connect);
			closesocket(s_internal_bind);
			WSACleanup();
			Shell_NotifyIcon(NIM_DELETE, &tnid);
			exit(0);
			break;
		case IDC_INFO:
			sprintf(bigpad, "DYNDNS.COM IP Updater Version %s\n\nCopyright 2000 DYNDNS.COM\n\nRunning Dot50 Protocol\nConfiguration Stored in Registry (Software\\DynDNS2000)\n\nReport bugs to %s\n", VERSION, CONTACT);
			MessageBox(hDlg, bigpad, "DYNDNS.COM IP Updater", MB_OK);
			break;
		}
		break;

	case WM_NOTIFYICON:
		switch(lParam)
		{
		case WM_LBUTTONDBLCLK:
			hidden = 1;
			ShowWindow(hDlg, SW_SHOW);
			SetForegroundWindow(mDlg);
			break;
		}
		break;

	default:
		return(FALSE);
		break;
	}
	return(TRUE);
}


char FAR *Name2Addr(char *nm)
{
LPHOSTENT lphe;
char FAR *IAD;

if(!(lphe = gethostbyname(nm)))
	{
	return NULL;
	}
IAD = inet_ntoa(*(LPIN_ADDR)*(lphe->h_addr_list));
return(IAD);
}

int IPCurrent(HWND hDlg)
{
SOCKADDR_IN in_sin, out_sin;
	
	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Creating bind() socket", 1);
	if((s_internal_bind=socket(AF_INET, SOCK_STREAM,0)) == INVALID_SOCKET)
		{
/**/    sprintf(scratchpad, "Can't create bind() socket (%d)", WSAGetLastError());
		MySetDlgItemText(hDlg, IDC_STATIC_STATUS, scratchpad, 1);
		return 0;
		}

	in_sin.sin_family = AF_INET;
 	in_sin.sin_addr.s_addr=INADDR_ANY;
	in_sin.sin_port=htons(DUMMYPORT);

	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Binding bind() socket", 1);
	if(bind(s_internal_bind, (struct sockaddr FAR*) &in_sin, sizeof(in_sin)) == SOCKET_ERROR)
		{
/**/    sprintf(scratchpad, "Can't bind() socket (%d)", WSAGetLastError());
		MySetDlgItemText(hDlg, IDC_STATIC_STATUS, scratchpad, 1);
		return 0;
		}

	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Listening to bind() socket", 1);
	if(listen(s_internal_bind, 1) == SOCKET_ERROR)
		{
/**/    sprintf(scratchpad, "Can't listen() socket (%d)", WSAGetLastError());
		MySetDlgItemText(hDlg, IDC_STATIC_STATUS, scratchpad, 1);
		return 0;
		}

	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Creating connect() socket", 1);
	if((s_internal_connect=socket(AF_INET, SOCK_STREAM,0)) == INVALID_SOCKET)
		{
/**/    sprintf(scratchpad, "Can't create connect() socket (%d)", WSAGetLastError());
		MySetDlgItemText(hDlg, IDC_STATIC_STATUS, scratchpad, 1);
		return 0;
		}

	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Resolving our IP", 1);

	out_sin.sin_family = AF_INET;
	sprintf(scratchpad, "%s", Name2Addr(fulldomain));
//	strncpy(scratchpad, "127.0.0.1", 20);				// Use this line for local testing
	out_sin.sin_addr.s_addr=inet_addr(scratchpad);;
	out_sin.sin_port=htons(DUMMYPORT);

	if(!out_sin.sin_addr.s_addr)
		{
/**/    sprintf(scratchpad, "Can't resolve our IP (%d)", WSAGetLastError() );
		MySetDlgItemText(hDlg, IDC_STATIC_STATUS, scratchpad, 1);
		return 0;
		}

	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Connecting to ourself", 1);
	if(connect(s_internal_connect, (struct sockaddr*) &out_sin, sizeof(SOCKADDR_IN)) < 0)
		{
/**/    sprintf(scratchpad, "Can't connect to ourself (%d)", WSAGetLastError() );
		MySetDlgItemText(hDlg, IDC_STATIC_STATUS, scratchpad, 1);
		return 0;
		}

	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "IP is up to date", 1);

	closesocket(s_internal_bind);
	closesocket(s_internal_connect);

	return 1;
}


int UpdateIP(HWND hDlg, char *uname, char *passwd, char *domain, char *IP)
{
struct CliData
        {
        char UName[20];
        char PWord[20];
        char NewIP[16];
        char Doman[64];
        };

struct CliData *Datum;
struct sockaddr_in sin;

sin.sin_family = AF_INET;                               
sin.sin_port = htons( REMOTEPORT );
sin.sin_addr.s_addr = inet_addr(Name2Addr(REMOTEHOST));

Datum = malloc(sizeof(struct CliData));
strcpy(Datum->NewIP, IP);
strcpy(Datum->UName, uname);
strcpy(Datum->PWord, passwd);
strcpy(Datum->Doman, domain);

if ((s_dyndns = socket(PF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) 
	{
	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Socket Creation Error", 1);
	return 0;
	}
if (connect(s_dyndns, (struct sockaddr *)&sin, sizeof(sin))==SOCKET_ERROR)
	{
	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Connect Error", 1);
	return 0;
	}

send(s_dyndns, (char *)Datum, sizeof(struct CliData), 0);

recv(s_dyndns, MBuf, 8192, 0);

closesocket(s_dyndns);

if(DEBUG2)
	{
	MessageBox(hDlg, MBuf, "Server Response", MB_OK);
	}
MySetDlgItemText(hDlg, IDC_STATIC_STATUS, MBuf, 1);

if(strstr(MBuf, "Authorization"))
	{
	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Invalid Login", 1);
	return 0;
	}
else
if(strstr(MBuf, "Internal"))
	{
	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Server Error", 1);
	return 0;
	}
else
if(strstr(MBuf, "Invalid"))
	{
	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Invalid Domain", 1);
	return 0;
	}
else
if(strstr(MBuf, "SUCCES"))
	{
	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Update Successful", 1);
	return 1;
	}
else
	{
	MySetDlgItemText(hDlg, IDC_STATIC_STATUS, "Unknown Response", 1);
	return 0;
	}
}


BOOL MySetDlgItemText(HWND hDlg, int nIDDlgItem, LPCTSTR lpString, BOOL rec)
{
	char tBuf[1536];

	if(rec)
		{
		sprintf(MRec, "%s\n%s", MRec, lpString);
		if(strlen(MRec)>1536)
			{
			strncpy(tBuf, MRec+512, 1536);
			strncpy(MRec, tBuf, 1536);
			}
		}
	return SetDlgItemText(hDlg, nIDDlgItem, lpString);
}
 