/* used by libtool*/
#define PACKAGE 0
#define WIN32 
/* used by libtool*/
#define VERSION 0

/* Define if getopt_long() available */
#undef HAVE_GETOPT_LONG

/* Define if alarm() available */
#undef HAVE_ALARM

/* Define if netinet/in.h header available */
#undef HAVE_NETINET_IN_H

/* Define if string.h header available */
#undef HAVE_STRING_H

/* Define for NLS */
#undef ENABLE_NLS
#undef HAVE_CATGETS
#undef HAVE_GETTEXT
#undef HAVE_LC_MESSAGES
#undef HAVE_STPCPY

/* Define LOCALEDIR */
#define LOCALEDIR "/usr/share/locale"

/* Define if libintl.h header available */
#undef HAVE_LIBINTL_H

/* Define if vsnprintf() function available */
#undef HAVE_VSNPRINTF
