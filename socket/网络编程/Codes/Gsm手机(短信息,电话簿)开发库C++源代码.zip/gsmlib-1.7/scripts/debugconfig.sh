#! /bin/sh

CXXFLAGS="-g -Wall" ./configure --disable-shared
