#if !defined(AFX_DSOCKET_H__009B445A_7B6A_47F1_B329_B17E4F194A86__INCLUDED_)
#define AFX_DSOCKET_H__009B445A_7B6A_47F1_B329_B17E4F194A86__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DSocket.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CDSocket command target

class CDSocket : public CSocket
{
// Attributes
public:

// Operations
public:
	CDSocket();
	virtual ~CDSocket();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDSocket)
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CDSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSOCKET_H__009B445A_7B6A_47F1_B329_B17E4F194A86__INCLUDED_)
