// DSocket.cpp : implementation file
//

#include "stdafx.h"
#include "Fason.h"
#include "DSocket.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDSocket

CDSocket::CDSocket()
{
}

CDSocket::~CDSocket()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CDSocket, CSocket)
	//{{AFX_MSG_MAP(CDSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CDSocket member functions
