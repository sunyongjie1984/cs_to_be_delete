/*******************************************
 * winSocket.h - Header file for winSocket * 
 *      Winsock API wrapper class          *
 *    Ryan Lederman ryan@winprog.org       *
 *            January 2002                 *
 *          THIS CODE IS FREE              *
 *                                         *
 *******************************************/

#ifndef _WINSOCKET_H
#define _WINSOCKET_H

#include "winsock.h"
#include "winbase.h"

#define ERR_SUCCESS  0x00000000	// Successful
#define ERR_BADPARAM 0x80000001	// Bad argument passed
#define ERR_WSAERROR 0x80000002	// Need to get_LastError()
#define ERR_MAXLENGTH 512

class winSocket	// Definition of winSocket
{
public:	// Public Methods
	winSocket::winSocket();		// Constructor
	winSocket::~winSocket();	// Destructor

	int Create( void );												// Creates the socket
	int Close( void );												// Closes the socket
	int Connect( char* strRemote, unsigned int iPort );				// Connects the socket to a remote site
	int Send( SOCKET s, char* strData, int iLen );					// Sends data
	int Send( char* strData, int iLen );	
	int Receive( SOCKET s, char* strData, int iLen );				// Receives data
	int Receive( char* strData, int iLen );
	int Listen( int iQueuedConnections );							// Listen for connections
	int Bind( char* strIP, unsigned int iPort );					// Binds to a port
	int Accept( SOCKET s );											// Accepts a connection
	int asyncSelect( HWND hWnd,										// Allows calling window to receive 
		unsigned int wMsg, long lEvent );							// notifications (non-blocking sockets)										
	int get_LocalIP( char* strIP );									// Returns local IP address			
	int get_LocalPort( int* iPort );								// Returns local Port number
	int get_RemoteIP( char* strIP );								// Returns remote side IP
	int get_RemotePort( int* iPort );								// Returns remote side Port number
	int get_LocalHost( char* strBuffer, int iBufLen );				// Returns local host name
	int get_RemoteHost( char* strBuffer, int iBufLen );				// Returns remote host name
	void get_LastError( char* strBuffer, int* iErrNum );			// Returns error information
	int set_SendTimeout( int ms );									// Sets send timeout, in milliseconds
	int set_RecvTimeout( int ms );									// Sets recv timeout, in milliseconds
	void longToDottedQuad( unsigned long ulLong, char* cBuffer );	// 32-bit long -> dotted quad
private:	// Private Methods
	void winSocket::set_LastError( char* newError, int errNum );	// Sets last error information
private:	// Private Members
	struct sockaddr_in m_sockaddr;		// Holds all data associated with socket
	struct sockaddr_in m_rsockaddr;		// Holds data associated with remote side
	WORD m_wVersion;					// Version to use when calling WSAStartup
	char m_LastError[ERR_MAXLENGTH+1];	// Buffer that holds last error
	int	 m_ErrorNumber;					// Last error number
public:		// Public Members
	SOCKET m_hSocket;					// Underlying SOCKET object
};

#endif /* _WINSOCKET_H */