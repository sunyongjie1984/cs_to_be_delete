/// *************************************************************************************************** ///
///	�T�v		:	MDI�p �����ꗗCMDITabFrame�׽	����̧��											///
///	̧�ٖ�		:	MDITabFrame.cpp																		///
///	�S������	:	���ſح����(��)	�������Ə�															///
/// *************************************************************************************************** ///
///	Rev.01.00	:	2006.07.12	Taibs	�V�K�쐬														///
///					2006.08.08	Liz		�\���ݒ�					                                    ///
///          	:	2006.08.01 Wuk   ��������MENU: �����ݒ� �\���X�V									///
///          	:	2006.08.02 Wuk   ��������MENU: �����������폜 ���������̓\��t��					///
///												   ���������̃R�s�[��ǉ�����							///	
///          	:	2006.08.03 Wuk   ��������MENU: ���������̃C���|�[�g ���������̃G�N�X�|�[�g			///
///												   �������R�s�[����										///
/// Rev.01.01	:	2006.09.11	Wanggl	�\���X�^�C��(ReWrite to INI)									///
/// Rev.01.02   :   2006.09.21  Wanggl	ReDefine INI_METFOLDERINFO_LOCTAB			                    ///
/// Rev.01.03	:	2006.09.26	ZhangZg	cP�ϐ����폜	
/// Rev.02.00	:	2006.10.16	ZhangZg	�֘A�t���\��													///
/// 			:	2006.11.20	Huangyz	Remove the control that make the menu items disabled.
/// *************************************************************************************************** ///
///	������		:	�{���̓��e�̈ꕔ�܂��͑S���𖳒f�Ŏg�p��]�ڂ��邱�Ƃ͋֎~����Ă��܂�				///
/// *************************************************************************************************** ///
#include	"stdafx.h"
#include	"METSLList.h"
#include	"MDITabFrame.h"
#include	"TabKjWuView.h"																				/// MDI �L���ėp�ꗗView�׽
#include	"TabGazoView.h"																				/// MDI �摜�ꗗView�׽
#include	"TabKjWuGazoView.h"
// 2006-10-16 ZhangZG Insert Start Rev.02.00 �֘A�t���\��
#include	"TabKjCorrelationView.h"
#include	"TabKjCorrelationGazoView.h"
// 2006-10-16 ZhangZG Insert End
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �� ��۰��ٗ̈��` =================================================================================///
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
_ST_MDICFRM_ENV		*GpstMdiMFrmEnv;																	/// MDI������Frame�׽���ʏ��
int					nGMemoListAddType, nGKijiListAddType, nGGazoListAddType;							/// �ǉ�����

// CMDITabFrame

IMPLEMENT_DYNCREATE(CMDITabFrame, CBaseTabFrame)

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	CMDITabFrame�׽�\�z����
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
CMDITabFrame::CMDITabFrame()
{
	/// �� �����ݒ� =======================================================================================
	m_pApp				=	(CMETSLListApp *)AfxGetApp();
	if( m_pApp == NULL )
	{
		return;
	}
	m_pgstComInf		=	&m_pApp->m_stComInf;
	m_pgstEnv			=	&m_pApp->m_stEnv;
	m_pgstAuthInfo		=	&m_pApp->m_stAuthInfo;

	m_bTitleChanged     =   true;
	m_iDefautTab		=	0;
	m_bAutoMenuEnable   =	FALSE;
	m_pMDISrhWaitDlg		=	NULL;
	m_pTabKjWuGazoView  =	NULL;
	// 2006-10-16 ZhangZG Insert Start Rev.02.00 �֘A�t���\��
	m_pTabKjCorrelationGazoView = NULL;
	// 2006-10-16 ZhangZG Insert End

	m_iLastTabIndex     =   -1;

	/// �� MDI�q�ڰя��ݒ� ==============================================================================
	m_pgstEnv->bReSrhSiji		=	FALSE;
	if( m_pgstEnv == NULL )
	{
		return;
	}
	this->m_strFolderInfoINI	=	m_pgstEnv->szFolderInfoINI;
	this->m_iFolderType			=	m_pgstEnv->iFolderType;
	this->m_strFolderPath		=	m_pgstEnv->szFolderPath;
	this->m_strFolder			=	m_pgstEnv->szFolder;
	this->m_strFName			=	m_pgstEnv->szFName;
	this->m_bReSrhSiji			=	m_pgstEnv->bReSrhSiji;
	this->m_bIsAutoFolder		=	m_pgstEnv->bIsAutoFolder;
	this->m_hTreeItem			=	m_pgstEnv->hTreeItem;
	this->m_pstTreeLevelInfo	=	m_pgstEnv->pstTreeLevelInfo;

	/// �� �ڰ�ү���ޏo�͸׽������ı��� ===================================================================
	m_cTrsMsg.InitSetUp( m_pgstComInf->szTopDir );

// 2006-10-19 ZhangZG Insert Start Rev.01.00
//	m_strTabFolders[0] = _T("�S�Ă̑f��");
//	m_strTabFolders[1] = _T("�L��");
//	m_strTabFolders[2] = _T("�摜");
//	m_strTabFolders[3] = _T("�����^�v1");
//	m_strTabFolders[4] = _T("�����^�v2");
//	m_strTabFolders[5] = _T("�����^�v3");
//	m_strTabFolders[6] = _T("�����^�v4");
	m_strTabFolders[0] = _T("�S�Ă̑f��");
	m_strTabFolders[1] = _T("�L��");
	m_strTabFolders[2] = _T("�摜");
	m_strTabFolders[3] = _T("�\");
	m_strTabFolders[4] = _T("�l���f��");
	m_strTabFolders[5] = _T("�����^�v1");
	m_strTabFolders[6] = _T("�����^�v2");
	m_strTabFolders[7] = _T("�����^�v3");
	m_strTabFolders[8] = _T("�����^�v4");
// 2006-10-19 ZhangZG Insert End
	//2006-08-02 Wuk Insert Start Rev.01.00
	this->bFlag = FALSE;
	this->bAttchFlag = FALSE;
	//2006-08-02 Wuk Insert End
}

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	CMDITabFrame�׽���ŏ���
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
CMDITabFrame::~CMDITabFrame()
{
	DestroyWnds();

	while(!m_docItems.IsEmpty())
	{
		CMDITabDoc *pDoc=m_docItems.RemoveHead();
        delete pDoc;  
		pDoc = NULL;
	}

	m_bInitCreateFlags	=	FALSE;

	m_stMdiCFrmEnv.bBaseFrmIsClose = TRUE;

	m_stMdiCFrmEnv.KDKRMLList.RemoveAll();

	if( m_pMDISrhWaitDlg != NULL)
	{
		m_pMDISrhWaitDlg->DestroyWindow();
		delete m_pMDISrhWaitDlg; 
		m_pMDISrhWaitDlg = NULL;
	}

#ifdef _DEBUG
	TRACE( _T("<<<<<=================================>>>>>\n") );
	TRACE( _T("<<<<< CBaseVarFrame::~CBaseVarFrame() >>>>>\n") );
	TRACE( _T("<<<<<=================================>>>>>\n") );
#endif
}


BEGIN_MESSAGE_MAP(CMDITabFrame, CBaseTabFrame)
	ON_WM_CREATE()
	ON_WM_PAINT()
	ON_MESSAGE(IDU_METSLLIST_PRETREEDBCLICK,OnTreePreDbClickRequest)	
	ON_COMMAND(ID_LTAB_SEARCHSET, OnLtabSearchset)
	ON_MESSAGE(IDU_METSZILIST_TRAN_WAIT_REQ,OnTranWaitRequest)
    // 2006-08-01 Bianf Insert Start Rev.01.00      -------�ꗗ���CSV��
	ON_MESSAGE			( IDU_METSZILIST_CSV_DISP_REQ,						OnCsvDispRequest		)
	// 2006-08-01 Bianf Insert End                  -------�ꗗ���CSV��
	ON_COMMAND(ID_LTAB_UPDATE, OnLtabUpdate)
	ON_COMMAND(ID_LTAB_SEARCHDEL, OnLtabSearchdel)
	ON_COMMAND(ID_LTAB_ATTACH, OnLtabAttach)
	ON_COMMAND(ID_LTAB_IMPORT, OnLtabImport)
	ON_COMMAND(ID_LTAB_EXPORT, OnLtabExport)
	ON_UPDATE_COMMAND_UI(ID_LTAB_ATTACH, OnUpdateLtabAttach)
	ON_COMMAND(ID_LTAB_COPY, OnLtabCopy)
	ON_WM_DESTROY()
END_MESSAGE_MAP()


// CMDITabFrame ���b�Z�[�W �n���h��
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �� CMDITabFrame �f�f ================================================================================///
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
#ifdef _DEBUG
void CMDITabFrame::AssertValid	(						)	const	{	CMDIChildWnd::AssertValid	(		);	}
void CMDITabFrame::Dump		(	CDumpContext& dc	)	const	{	CMDIChildWnd::Dump			(	dc	);	}
#endif //_DEBUG

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	̫��ޏ��INI̧�َ擾
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::ReadMetListInfoINI( void )
{
	/// �� �����y�я����� =================================================================================
	CComPIOEx	cPIO;
	CString		strMETSrhInfoINI,strSec;

	strSec=_T("���ʏ��");

	int i;
// 2006-10-16 ZhangZG Insert Start Rev.02.00 �֘A�t���\��
	AfxMessageBox(L"zhangzhiguo");
// 2006-07-11 ZhangZG Insert End
	for(i=0;i<TAB_MAXCOUNT;++i)
	{
		/// �� INI̧�ٖ����̫��ޖ��擾 =======================================================================
		strMETSrhInfoINI.Format(_T("%s\\%s\\%s"),m_strTabFrameInfoPath,m_strTabFolders[i],TAB_SRCHINFOINIFILE);
		
		/// �� INI̧�ٖ��Œ�ݒ� ==============================================================================
		cPIO.SetProfName( strMETSrhInfoINI ); 
		
		/// �� ���擾 ===========================================================================================
		cPIO.GetInt ( strSec, _T("�\���X�^�C��"), m_iTabStyles[i]);
	}

	return;
}
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	�Ǝ�INI̧�َ擾
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::ReadINI( void )
{
	/// �� �����y�я����� =================================================================================
	int			iR, iG, iB;
	int         iPos;
	CString     strTabNo;
	CString     strTabTitle;
	CString		strTabFrameInfoINI,strSec, strSec1, strStr;
	
	/// �� INI̧�ٖ����̫��ޖ��擾 =======================================================================
	strTabFrameInfoINI.Format( _T("%s\\%s"), m_pgstComInf->szUsrHomeDir,TAB_FRAMEINFOINIFILE);
	
	iPos = strTabFrameInfoINI.ReverseFind( _T('\\') );
	m_strTabFrameInfoPath = strTabFrameInfoINI.Mid( 0, iPos );
	
	/// �� �擾 ===========================================================================================
	m_cZBPIO.SetProfName( strTabFrameInfoINI ); 
	strSec = _T("�ꗗ����WaitDialog");
	m_cZBPIO.GetInt ( strSec, _T("������������TraceOut"	), m_stMdiCFrmEnv.nMemoSrhInfTraceOut									);
	m_cZBPIO.GetInt ( strSec, _T("�L����������TraceOut"	), m_stMdiCFrmEnv.nKijiSrhInfTraceOut									);
	m_cZBPIO.GetInt ( strSec, _T("�摜��������TraceOut"	), m_stMdiCFrmEnv.nGazoSrhInfTraceOut									);
	m_cZBPIO.GetInt ( strSec, _T("Memoү���������"		), m_stMdiCFrmEnv.nMemoPumpMsg											);
	m_cZBPIO.GetInt ( strSec, _T("Kijiү���������"		), m_stMdiCFrmEnv.nKijiPumpMsg											);
	m_cZBPIO.GetInt ( strSec, _T("Gazoү���������"		), m_stMdiCFrmEnv.nGazoPumpMsg											);
	m_cZBPIO.GetInt ( strSec, _T("ү��������߽ذ��mm�b"	), m_stMdiCFrmEnv.nPumpSleepMMSec										);
	m_cZBPIO.GetStr ( strSec, _T("FontName"				), m_stMdiCFrmEnv.szSrhWait_FontName									);
	m_cZBPIO.GetInt ( strSec, _T("FontSize"				), m_stMdiCFrmEnv.nSrhWait_FontSize										);
	m_cZBPIO.GetStr ( strSec, _T("WindowTitle"			), m_stMdiCFrmEnv.szSrhWait_WinTitle									);
	m_cZBPIO.GetStr ( strSec, _T("TextString"			), m_stMdiCFrmEnv.szSrhWait_StcTitle									);
	m_cZBPIO.GetInt3( strSec, _T("TextColor1"			), iR, iG, iB	);	m_stMdiCFrmEnv.crSrhWait_TextCr1=RGB( iR, iG, iB	);
	m_cZBPIO.GetInt3( strSec, _T("TextColor2"			), iR, iG, iB	);	m_stMdiCFrmEnv.crSrhWait_TextCr2=RGB( iR, iG, iB	);
	m_cZBPIO.GetInt ( strSec, _T("BlinkTime"				), m_stMdiCFrmEnv.nBlinkTime											);
	m_cZBPIO.GetStr ( strSec, _T("AnimationFile01"		), strStr																);
	m_stMdiCFrmEnv.szSrhWait_AnimationFile1.Format( _T("%s\\%s"), m_pgstComInf->szTopDir, strStr								);
	m_cZBPIO.GetStr ( strSec, _T("AnimationFile02"		), strStr																);
	m_stMdiCFrmEnv.szSrhWait_AnimationFile2.Format( _T("%s\\%s"), m_pgstComInf->szTopDir, strStr								);
	m_cZBPIO.GetStr ( strSec, _T("AnimationFile03"		), strStr																);
	m_stMdiCFrmEnv.szSrhWait_AnimationFile3.Format( _T("%s\\%s"), m_pgstComInf->szTopDir, strStr								);
	m_cZBPIO.GetDtTm( strSec, _T("�����X�V������FromDate"), m_stMdiCFrmEnv.nFAutoFromYear,
													   m_stMdiCFrmEnv.nFAutoFromMonth,
													   m_stMdiCFrmEnv.nFAutoFromDay,
													   m_stMdiCFrmEnv.nFAutoFromHour,
													   m_stMdiCFrmEnv.nFAutoFromMin,
													   m_stMdiCFrmEnv.nFAutoFromSec											);
	m_cZBPIO.GetDtTm( strSec, _T("�����X�V������ToDate"),   m_stMdiCFrmEnv.nFAutoToYear,
													   m_stMdiCFrmEnv.nFAutoToMonth,
													   m_stMdiCFrmEnv.nFAutoToDay,
													   m_stMdiCFrmEnv.nFAutoToHour,
													   m_stMdiCFrmEnv.nFAutoToMin,
													   m_stMdiCFrmEnv.nFAutoToSec											);
	m_cZBPIO.GetDtTm( strSec, _T("�����X�V������ToDate"),   m_stMdiCFrmEnv.nSAutoToYear,
													   m_stMdiCFrmEnv.nSAutoToMonth,
													   m_stMdiCFrmEnv.nSAutoToDay,
													   m_stMdiCFrmEnv.nSAutoToHour,
													   m_stMdiCFrmEnv.nSAutoToMin,
													   m_stMdiCFrmEnv.nSAutoToSec											);

	strSec1 = _T("�^�v���ʏ��");
	m_cZBPIO.GetInt ( strSec1, _T("DefaultIndex" ), m_iDefautTab);

	for( iPos = 0; iPos < TAB_MAXCOUNT; iPos++ )
	{
        strTabNo.Format( _T("Tab%dRow0"), iPos+1 );
		m_cZBPIO.GetInt ( strSec1, strTabNo, m_iTextThumbRowH[iPos]);
		strTabTitle.Format( _T("Tab%dTitle"), iPos+1 );
		m_cZBPIO.GetStr ( strSec1, strTabTitle, m_strTabTitles[iPos]);
	}

	if( m_stMdiCFrmEnv.nPumpSleepMMSec < 0 || m_stMdiCFrmEnv.nPumpSleepMMSec > 10 )
		m_stMdiCFrmEnv.nPumpSleepMMSec = 3;
}

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	����ލ쐬�O����
/// ����	:	LPCREATESTRUCT	lpCreateStruct	��	CREATESTRUCT�\����
/// �ԋp�l	:	0(����)	-1(�ُ�)
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
int CMDITabFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CBaseTabFrame::OnCreate(lpCreateStruct) == -1)
		return -1;

	/// �� �����y�я����� =================================================================================
	BOOL	bRet	=	FALSE;
	_ST_SLLIST_PVINF	*pstSLListPvInf	=	NULL;	//// 2005.01.18 .Add ZEBEC T.Nakamura
	_ST_SLLIST_DLTBL	*pstSLListDLTbl	=	NULL;	//// 2005.01.18 .Add ZEBEC T.Nakamura

	/// �� MDI������Frame�׽���ʏ�񏉊��� ================================================================
	m_bInitCreateFlags					=	FALSE;
	m_stMdiCFrmEnv.bInitFlags			=	TRUE;
	m_stMdiCFrmEnv.cWndBase				=	NULL;
	m_stMdiCFrmEnv.hWndBase				=	NULL;
	m_stMdiCFrmEnv.cWndKiji				=	NULL;
	m_stMdiCFrmEnv.hWndKiji				=	NULL;
	m_stMdiCFrmEnv.bIsTranKiji			=	FALSE;
	m_stMdiCFrmEnv.cWndGazo				=	NULL;
	m_stMdiCFrmEnv.hWndGazo				=	NULL;
	m_stMdiCFrmEnv.bIsTranGazo			=	FALSE;
	m_stMdiCFrmEnv.cWndMemo				=	NULL;
	m_stMdiCFrmEnv.hWndMemo				=	NULL;
	m_stMdiCFrmEnv.bIsTranMemo			=	FALSE;
	m_stMdiCFrmEnv.cWndPrev				=	NULL;
	m_stMdiCFrmEnv.hWndPrev				=	NULL;
	m_stMdiCFrmEnv.bIsTranPrev			=	FALSE;
	m_stMdiCFrmEnv.pstComInf			=	NULL;
	m_stMdiCFrmEnv.pstEnv				=	NULL;
	m_stMdiCFrmEnv.pMemoMLList			=	NULL;
	m_stMdiCFrmEnv.pKijiMLList			=	NULL;

	m_stMdiCFrmEnv.pCurDlgKDKR          =	NULL;
	m_stMdiCFrmEnv.KDKRMLList.RemoveAll();
	m_stMdiCFrmEnv.bBaseFrmIsClose = FALSE;
	
	m_stMdiCFrmEnv.pGazoMLList			=	NULL;
	m_stMdiCFrmEnv.nTranBitInfo			=	(int)0x00000000;
	m_stMdiCFrmEnv.bIsAuto				=	FALSE;
	m_stMdiCFrmEnv.pstRefExtInfoMemo	=	NULL;
	m_stMdiCFrmEnv.pstRefExtInfoKiji	=	NULL;
	m_stMdiCFrmEnv.pstRefExtInfoGazo	=	NULL;

	/// �� Drag & Drop��񏉊��� ==========================================================================
	m_stMdiCFrmEnv.stMemoDDInf.nDragTarget	=	0;
	m_stMdiCFrmEnv.stMemoDDInf.pDragWnd		=	NULL;
	m_stMdiCFrmEnv.stMemoDDInf.pDragImage	=	NULL;
	m_stMdiCFrmEnv.stKijiDDInf.nDragTarget	=	0;
	m_stMdiCFrmEnv.stKijiDDInf.pDragWnd		=	NULL;
	m_stMdiCFrmEnv.stKijiDDInf.pDragImage	=	NULL;
	m_stMdiCFrmEnv.stGazoDDInf.nDragTarget	=	0;
	m_stMdiCFrmEnv.stGazoDDInf.pDragWnd		=	NULL;
	m_stMdiCFrmEnv.stGazoDDInf.pDragImage	=	NULL;

	/// �� ���񌟍��׸ޏ����� =============================================================================
	m_stMdiCFrmEnv.nSrhFirstFlgMemo	=	FALSE;
	m_stMdiCFrmEnv.nSrhFirstFlgKiji	=	FALSE;
	m_stMdiCFrmEnv.nSrhFirstFlgGazo	=	FALSE;

	/// �� ���Ǐ�񏉊��� =================================================================================
	m_stMdiCFrmEnv.stMidokuInfo.hTreeItem			=	NULL;
	m_stMdiCFrmEnv.stMidokuInfo.pstTreeLevelInfo	=	NULL;
	m_stMdiCFrmEnv.stMidokuInfo.nMemoCnt			=	0;
	m_stMdiCFrmEnv.stMidokuInfo.nKijiCnt			=	0;
	m_stMdiCFrmEnv.stMidokuInfo.nGazoCnt			=	0;

	/// �� �����X�V�Ώ��׸� ===============================================================================
	m_stMdiCFrmEnv.bIsAuto = m_pgstEnv->bIsAutoFolder;

	/// �� �ꗗ������WaitDialog�׽������ ==================================================================
	m_pMDISrhWaitDlg				=	NULL;

	/// �� MDI������Frame�׽���ʏ�񥎩�g���ݒ� =========================================================
	m_stMdiCFrmEnv.cWndBase		=	this;
	m_stMdiCFrmEnv.hWndBase		=	this->m_hWnd;

	/// �� ��ٰ��ٗ̈�ݒ� ================================================================================
	m_stMdiCFrmEnv.pstComInf	=	m_pgstComInf;
	m_stMdiCFrmEnv.pstEnv		=	m_pgstEnv;
	m_stMdiCFrmEnv.szFolderPath	=	m_strFolderPath;
	m_stMdiCFrmEnv.szFolder		=	m_strFolder;
	m_stMdiCFrmEnv.szFName		=	m_strFName;
	/*GpstComInf					=	m_pgstComInf;
	GpstEnv						=	m_pgstEnv;
	GpstAuthInfo				=	m_pgstAuthInfo;*/
	GpstMdiMFrmEnv				=	&m_stMdiCFrmEnv;

	m_stMdiCFrmEnv.bIsAutoFolder	=	m_bIsAutoFolder;
	m_stMdiCFrmEnv.hTreeItem		=	m_hTreeItem;
	//m_stMdiCFrmEnv.pstTreeLevelInfo	=	m_pstTreeLevelInfo;

	//m_pstTreeLevelInfo->hWnd                =	this->m_hWnd;	/// 2005.07.13 Rev.00.04
	//m_stMdiCFrmEnv.pstTreeLevelInfo->hWnd	=	this->m_hWnd;

	if( m_stMdiCFrmEnv.bIsAutoFolder == TRUE ){
		m_stMdiCFrmEnv.bAutoUpDateFlags = TRUE;
	}
	else{
		m_stMdiCFrmEnv.bAutoUpDateFlags = FALSE;
	}

	/// �� �f�ތ�����񏉊��� =============================================================================
	m_stMdiCFrmEnv.stSozaiCntInfo.nMemoCnt			=	0;
	m_stMdiCFrmEnv.stSozaiCntInfo.nKijiCnt			=	0;
	m_stMdiCFrmEnv.stSozaiCntInfo.nGazoCnt			=	0;
	m_stMdiCFrmEnv.stSozaiCntInfo.nNoReadMemoCnt	=	0;
	m_stMdiCFrmEnv.stSozaiCntInfo.nNoReadKijiCnt	=	0;
	m_stMdiCFrmEnv.stSozaiCntInfo.nNoReadGazoCnt	=	0;
	m_stMdiCFrmEnv.stSozaiCntInfo.nSelectMemoCnt	=	0;
	m_stMdiCFrmEnv.stSozaiCntInfo.nSelectKijiCnt	=	0;
	m_stMdiCFrmEnv.stSozaiCntInfo.nSelectGazoCnt	=	0;

	///���ð���ްү��ޏ�����
	m_stMdiCFrmEnv.nSozaiMsgNo                      =   0;
	/// �� �ڰ�ү���ޏo�͸׽������ı��� ===================================================================
	m_cTrsMsg.InitSetUp( m_pgstComInf->szTopDir );
#ifdef _DEBUG
	m_cTrsMsg.ListOut( TM_ERR, __LINE__, (TCHAR *)__FILE__, (LPCSTR)_T("�y%s�z�� CMDITabFrame::OnCreate() �ײ��ė̈�쐬�J�n"), m_strMyClassName );
#endif

	/// �� �Ǝ�INI̧�َ擾 ================================================================================
	this->ReadINI();

	/// �� ��������INI̧�ٖ��ݒ� ==========================================================================
	m_strSrhINI.Format( _T("%s\\%s"), m_strFolderPath, INI_METSRHINFO ); 
	m_stMdiCFrmEnv.szSrhINIFileName = m_strSrhINI;
	m_cRefINIIO.InitSetUp( m_pgstComInf, m_pgstEnv, &m_stRefExtInfo, m_strSrhINI	);
	m_cTrsMsg.ListOut( TM_APL, __LINE__, (TCHAR *)__FILE__, (LPCSTR)_T("�y%s�z��������INI̧�ٖ�     :[%s]"), m_strMyClassName, m_strSrhINI );
	m_cTrsMsg.ListOut( TM_APL, __LINE__, (TCHAR *)__FILE__, (LPCSTR)_T("�y%s�zm_stRefExtInfo Address:[0x%08x]"), m_strMyClassName, &m_stRefExtInfo );
	m_cTrsMsg.ListOut( TM_APL, __LINE__, (TCHAR *)__FILE__, (LPCSTR)_T("�y%s�zm_stMdiCFrmEnv Address:[0x%08x]"), m_strMyClassName, &m_stMdiCFrmEnv );

	/// �� ̫��ޏ��INI̧�َ擾 ===========================================================================
	this->ReadMetListInfoINI();

	/// �� �ʐM����Ұ��ݶ��ُ��� ==========================================================================
	m_hcWait	=	LoadCursorFromFile( m_pgstEnv->szWaitAniCur );

	/// �� �[���ݒ�INI̧��IO�׽������ı��� ================================================================
	m_cTrmSetPFIO.InitSetUp( m_pgstComInf );

	/// �� �[���ݒ��{���擾 ===========================================================================
	m_cTrmSetPFIO.GetKihon( m_stMdiCFrmEnv.stTrmInfKihon );

	/// �� LDAP���������׽������ı��� =====================================================================
	m_cLDAPCK.InitSetUp( m_pgstComInf, FALSE );

	/// �� �[���ݒ���y��LDAPհ�����̧�ُ��ݒ� ========================================================
	m_stMdiCFrmEnv.szCom_BusyoName		=	m_stMdiCFrmEnv.stTrmInfKihon.szSykbName;
	m_stMdiCFrmEnv.szCom_KengenSyaName	=	m_cLDAPCK.GetKGName();
	m_stMdiCFrmEnv.szCom_LoginUserName	=	m_cLDAPCK.m_szFullNameKanji;
	m_stMdiCFrmEnv.szCom_UserId			=	m_cLDAPCK.m_szUserID;
	m_stMdiCFrmEnv.szCom_PassWd			=	m_cLDAPCK.m_szPassWD;

	// Added by Neusoft 2006-04-24 Start --- NS1137
	m_pgstEnv->szBusyoName		=	m_stMdiCFrmEnv.stTrmInfKihon.szSykbName;
	// Added by Neusoft 2006-04-24  End  --- NS1137

// 2006-10-19 ZhangZG Insert Start Rev.01.00
//	if(!AddTabItem(m_strTabTitles[0]))
//		return -1;
//
//	if(!AddTabItem(m_strTabTitles[1]))
//		return -1;
//
//	if(!AddTabItem(m_strTabTitles[2]))
//		return -1;
//
//	if(!AddTabItem(m_strTabTitles[3]))
//		return -1;
//
//	if(!AddTabItem(m_strTabTitles[4]))
//		return -1;
//
//	if(!AddTabItem(m_strTabTitles[5]))
//		return -1;
//
//	if(!AddTabItem(m_strTabTitles[6]))
//		return -1;

	if(!AddTabItem(m_strTabTitles[0]))
		return -1;

	if(!AddTabItem(m_strTabTitles[1]))
		return -1;

	if(!AddTabItem(m_strTabTitles[2]))
		return -1;

	if(!AddTabItem(m_strTabTitles[3]))
		return -1;

	if(!AddTabItem(m_strTabTitles[4]))
		return -1;

	if(!AddTabItem(m_strTabTitles[5]))
		return -1;

	if(!AddTabItem(m_strTabTitles[6]))
		return -1;

	if(!AddTabItem(m_strTabTitles[7]))
		return -1;

	if(!AddTabItem(m_strTabTitles[8]))
		return -1;
// 2006-10-19 ZhangZG Insert End

	m_iLastTabIndex         = m_iDefautTab;
	m_pApp->m_pCurrentTabDoc = GetTabDoc(m_iDefautTab);	

	if(m_pApp->m_pCurrentTabDoc ==NULL)
		return -1;
	
// 2006-10-16 ZhangZG Insert Start Rev.02.00 �֘A�t���\��
	if(!AddView(L"CTabKjCorrelationView",RUNTIME_CLASS(CTabKjCorrelationView)))
		return -1;

	m_pTabKjCorrelationGazoView = (CTabKjCorrelationGazoView*)AddWnd(_T("CTabKjCorrelationGazoView"),RUNTIME_CLASS(CTabKjCorrelationGazoView),WS_CHILD | WS_VISIBLE);

	if(m_pTabKjCorrelationGazoView==NULL)
		return -1;
// 2006-10-16 ZhangZG Insert End

	if(!AddView(L"CTabKjWuView",RUNTIME_CLASS(CTabKjWuView)))
		return -1;
	
	if(!AddView(L"CTabGazoView",RUNTIME_CLASS(CTabGazoView)))
		return -1;

	m_pTabKjWuGazoView = (CTabKjWuGazoView*)AddWnd(_T("CTabKjWuGazoView"),RUNTIME_CLASS(CTabKjWuGazoView),WS_CHILD | WS_VISIBLE);

	if(m_pTabKjWuGazoView==NULL)
		return -1;

	TabActivate(m_iDefautTab);
	

	return 0;
}

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	Tree����ٸد��O����
/// ����	:	UINT	wParam	��	����
///				LONG	lParam	��	����
/// �ԋp�l	:	0(����)	-1(�ُ�)
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///

LRESULT CMDITabFrame::OnTreePreDbClickRequest( WPARAM wParam, LPARAM lParam )
{
	m_bTitleChanged = true;
	OnPaint();

	return 0;
}

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	�`�揈��
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	
	if(m_bTitleChanged)
	{
		CString strTitle,strFolder;
		
		strFolder = m_pgstEnv->szFName;

		strTitle.Format(_T("%s-%s"),strFolder,m_pApp->m_pCurrentTabDoc->GetTabTitle());

		SetWindowText(strTitle);
		m_bTitleChanged = false;
	}
}

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	�}�E�X�E���݉���
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::OnTabRBtnClick()
{
	CMenu cMenu;
	if (cMenu.LoadMenu(IDR_PDMENU_LOC_TABFRAME) == 0)
		return;
	
	CMenu *pSubMenu = cMenu.GetSubMenu(0);
	if(pSubMenu == NULL)
		return;	

	/// �� �ƭ����� =======================================================================================
	// 2006-11-20 HANGYZ Delete Start Rev.02.00 
	/*if(GetSelTab()==TAB_SEARCHALL||GetSelTab()==TAB_KIJI||GetSelTab()==TAB_GAZO)
	{
		pSubMenu->EnableMenuItem(ID_LTAB_SEARCHSET,MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
		pSubMenu->EnableMenuItem(ID_LTAB_SEARCHDEL,MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
		pSubMenu->EnableMenuItem(ID_LTAB_COPY,MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
		pSubMenu->EnableMenuItem(ID_LTAB_ATTACH,MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
		pSubMenu->EnableMenuItem(ID_LTAB_IMPORT,MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
		pSubMenu->EnableMenuItem(ID_LTAB_EXPORT,MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	}
	else*/
	// 2006-11-20 HANGYZ Delete End Rev.02.00
	{
		pSubMenu->EnableMenuItem(ID_LTAB_SEARCHSET,MF_BYCOMMAND | MF_ENABLED);
		pSubMenu->EnableMenuItem(ID_LTAB_SEARCHDEL,MF_BYCOMMAND | MF_ENABLED);
		pSubMenu->EnableMenuItem(ID_LTAB_COPY,MF_BYCOMMAND | MF_ENABLED);
		pSubMenu->EnableMenuItem(ID_LTAB_ATTACH,MF_BYCOMMAND | MF_ENABLED);
		pSubMenu->EnableMenuItem(ID_LTAB_IMPORT,MF_BYCOMMAND | MF_ENABLED);
		pSubMenu->EnableMenuItem(ID_LTAB_EXPORT,MF_BYCOMMAND | MF_ENABLED);
	}

	/// �� �ƭ��\�� =======================================================================================
	POINT p;
	GetCursorPos(&p);
	UINT	PmStyle = TPM_LEFTALIGN | TPM_RIGHTBUTTON | TPM_LEFTBUTTON;
	pSubMenu->TrackPopupMenu(PmStyle,p.x,p.y,this,NULL);

	cMenu.DestroyMenu();
}

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	�^�v�ǉ�
/// ����	:	CString strTitle	��	�^�v�̖��O
/// �ԋp�l	:	TRUE(����)	FALSE(�ُ�)
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
BOOL CMDITabFrame::AddTabItem(CString strTitle)
{
	BOOL bResult = false;

	bResult = CBaseTabFrame::AddTabItem(strTitle);
	
	if(!bResult)
		return false;

	CMDITabDoc *pDoc = NULL;
	try
	{
		pDoc=new CMDITabDoc(this);
		bResult = true;
	}
	catch(CException* e)
	{
		bResult = false;
		e->Delete();		
	}
		
    if(!bResult)
		return false;

	CString strTabSrhINI,strTabListINIFolder;
	
	int iCount = (int)m_docItems.GetCount();
	strTabSrhINI.Format(_T("%s\\%s\\%s"),m_strTabFrameInfoPath,m_strTabFolders[iCount],TAB_SRCHINFOINIFILE);
	strTabListINIFolder.Format(_T("%s\\%s"),m_strTabFrameInfoPath,m_strTabFolders[iCount]);
	
	pDoc->SetTabStyle(m_iTabStyles[iCount]);
	pDoc->SetTabTitle(m_strTabTitles[iCount]);
	pDoc->SetTabSrhINI(strTabSrhINI);
	pDoc->SetTabListINIFolder(strTabListINIFolder);
	m_docItems.AddTail(pDoc);

	return bResult;
}

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	: �q����ޒǉ�
/// ����	: CString strLabel�@			��	�q����ނ̖��O
/// ����	: CRuntimeClass *pViewClass		��	CRuntimeClass�N���X
/// ����	: DWORD dwStyle�@				��	�q����ރX�^�C��
/// �ԋp�l	: �q��݃h�߲��										
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
CWnd*  CMDITabFrame::AddWnd(CString strTitle, CRuntimeClass * pWndClass, DWORD dwStyle)
{
	#ifdef _DEBUG
	ASSERT_VALID(this);
	ASSERT(pWndClass != NULL);
	ASSERT(pWndClass->IsDerivedFrom(RUNTIME_CLASS(CWnd)));
	ASSERT(AfxIsValidAddress(pWndClass, sizeof(CRuntimeClass), FALSE));
#endif

	if(pWndClass==NULL)
		return NULL;

	CWnd* pWnd=NULL;
    dwStyle |= WS_CHILD | WS_VISIBLE;
	CRect rect;
	BOOL bCreate = FALSE;

	CString strClass( pWndClass->m_lpszClassName );
	
	// // �q����ނ�n������
    if( strClass==TEXT("CTabKjWuGazoView"))
	{
		try
		{
			pWnd = new CTabKjWuGazoView();
			bCreate = pWnd->Create(0, 0, dwStyle, rect, this, 0);
		}
		catch(CException* e)
		{
			bCreate = FALSE;
			e->Delete();
		}
	}
// 2006-10-16 ZhangZG Insert Start Rev.02.00 �֘A�t���\��
	else if( strClass==TEXT("CTabKjCorrelationGazoView") )
	{
		try
		{
			pWnd = new CTabKjCorrelationGazoView();
			bCreate = pWnd->Create(0, 0, dwStyle, rect, this, 0);
		}
		catch(CException* e)
		{
			bCreate = FALSE;
			e->Delete();
		}
	}
// 2006-10-16 ZhangZG Insert End
	else 
	{
		try
		{
			pWnd = new CWnd();;
			bCreate = pWnd->Create(0, 0, dwStyle, rect, this, 0);
		}
		catch(CException* e)
		{
			bCreate = FALSE;
			e->Delete();
		}
	}
	
	if( !pWnd ) return 0;
	if( !bCreate ) { delete pWnd; return NULL; }
	
	// �q����ނ�ǉ�����
	WND_ITEM *pMember=new WND_ITEM;
	pMember->pWnd=pWnd;
	pMember->strLabel = strTitle;
	m_wndItems.AddTail(pMember);

	// �q����ނ̈ʒu��ύX����
	CRect clientRect;
	GetClientRect(clientRect);  
	pWnd->MoveWindow(4, 30, clientRect.Width()-8, clientRect.Height()-36);
	
	int iWnds = (int)m_wndItems.GetCount();
	if (iWnds!=1)
	{
		pWnd->EnableWindow(FALSE);
		pWnd->ShowWindow(SW_HIDE);
	}
	else
	{
		//// ��è�ގq��݃h��ݒ肷��
		m_pActiveWnd = pWnd;
		m_pActiveWnd->ShowWindow( SW_SHOW );
	}
	
	return pWnd;
}
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	: �^�C�g���ݒ�
/// ����	: CString strTitle	��	�^�v�̖��O
/// �ԋp�l	: �Ȃ�										
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::SetCurTabTitle(CString strTitle)
{
	//�^�C�g���ݒ�
	SetSelItemTitle(strTitle);
	m_pApp->m_pCurrentTabDoc->SetTabTitle(strTitle);
}

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	�ʐM��Wait�v��ү����
/// ����	:	WPARAM	wParam	��	P_KIJI:�L�� P_GAZO:�摜 P_MEMO:����
///				LPARAM	lParam	��	TRUE(�ʐM��)	FALSE(�ȊO)
/// �ԋp�l	:	0(����)	-1(�ُ�)
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
LRESULT CMDITabFrame::OnTranWaitRequest( WPARAM wParam, LPARAM lParam )
{
	/// �� �����y�я����� =================================================================================
	int		nType	=	(int)wParam;
	BOOL	bIsTran	=	(BOOL)lParam;
	BOOL	bIsOK	=	TRUE;
	CString	szTitle	=	_T("");

	BOOL    bWaitDlgNew = FALSE;
	/// �� �ʐM��Ԑݒ� ===================================================================================
	switch( nType ){
		case	P_KIJI	:	
			m_stMdiCFrmEnv.bIsTranKiji	=	bIsTran;	
			break;	//// �L��
		case	P_GAZO	:	
			m_stMdiCFrmEnv.bIsTranGazo	=	bIsTran;	
			break;	//// �摜
		case	P_MEMO	:	
			m_stMdiCFrmEnv.bIsTranMemo	=	bIsTran;	
			break;	//// ����
		default			:	
			bIsOK						=	FALSE;		
			break;	//// �ȊO
	}

	/// �� ���� ===========================================================================================
	if( m_pMDISrhWaitDlg != NULL && bIsOK == FALSE )
	{
		m_pMDISrhWaitDlg->DestroyWindow(); 
		delete m_pMDISrhWaitDlg; 
		m_pMDISrhWaitDlg = NULL; 
		return (LRESULT)(0);
	}

	/// �� �ʐM��WaitDialog�\������ =======================================================================
	if( m_stMdiCFrmEnv.bIsAutoFolder != TRUE )
	{
		if( m_stMdiCFrmEnv.nSrhFirstFlgMemo == TRUE || m_stMdiCFrmEnv.nSrhFirstFlgKiji == TRUE || m_stMdiCFrmEnv.nSrhFirstFlgGazo == TRUE )
		{
			if( m_pMDISrhWaitDlg == NULL && ( m_stMdiCFrmEnv.bIsTranKiji == TRUE || m_stMdiCFrmEnv.bIsTranGazo == TRUE || m_stMdiCFrmEnv.bIsTranMemo == TRUE ) )
			{
				try
				{
					m_pMDISrhWaitDlg = new CMDIListSrhWaitDlg( NULL, &m_stMdiCFrmEnv, m_pgstComInf ); 
					bWaitDlgNew = TRUE;
				}
				catch(CException* e)
				{
					bWaitDlgNew = FALSE;
					e->Delete();
				}

				if(!bWaitDlgNew)
					return (LRESULT)(-1);

				this->PumpMsg(); 
				return (LRESULT)(0);
			}
		}
	}
	else
	{
		if( m_stMdiCFrmEnv.nSrhFirstFlgMemo == TRUE || m_stMdiCFrmEnv.nSrhFirstFlgKiji == TRUE || m_stMdiCFrmEnv.nSrhFirstFlgGazo == TRUE )
		{
			if( m_pMDISrhWaitDlg == NULL && ( m_stMdiCFrmEnv.bIsTranKiji == TRUE || m_stMdiCFrmEnv.bIsTranGazo == TRUE || m_stMdiCFrmEnv.bIsTranMemo == TRUE ) )
			{
				try
				{
					m_pMDISrhWaitDlg = new CMDIListSrhWaitDlg( NULL, &m_stMdiCFrmEnv, m_pgstComInf ); 
					bWaitDlgNew = TRUE;
				}
				catch(CException* e)
				{
					bWaitDlgNew = FALSE;
					e->Delete();
				}

				if(!bWaitDlgNew)
					return (LRESULT)(-1);

				this->PumpMsg(); 
				return (LRESULT)(0);
			}
		}
		else
		{
		}
	}

	/// �� �ʐM��WaitDialog�������� =======================================================================
	if( m_pMDISrhWaitDlg != NULL && ( m_stMdiCFrmEnv.bIsTranKiji == FALSE && m_stMdiCFrmEnv.bIsTranGazo == FALSE && m_stMdiCFrmEnv.bIsTranMemo == FALSE ) )
	{
		m_pMDISrhWaitDlg->DestroyWindow(); 
		delete m_pMDISrhWaitDlg; 
		m_pMDISrhWaitDlg = NULL; 
		return (LRESULT)(0);
	}

	return (LRESULT)(0);
}

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	ү��������ߏ���
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::PumpMsg( void )
{
	/// �� �����y�я����� =================================================================================
	MSG	msg;

	/// �� ү��������ߏ��� ================================================================================
	while( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
	{ 
		if( !IsDialogMessage( &msg ) )
		{ 
			TranslateMessage( &msg ); 
			DispatchMessage( &msg ); 
		} 
	}

	/// �� �x�� ===========================================================================================
	Sleep( 10 );
	return;
}

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	�^�v��CMDITabDoc�Ώ�
/// ����	:	int iTab	��	�^�v�̍���
/// �ԋp�l	:	CMDITabDoc
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
CMDITabDoc* CMDITabFrame::GetTabDoc(int iTab)
{	
	POSITION pos = m_docItems.FindIndex(iTab);

	if(pos)
		return m_docItems.GetAt(pos);
	else
		return NULL;
}

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	�^�v�I������
/// ����	:	int iNewTab	��	�^�v�̍���
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::OnTabSel(int iNewTab)
{
	if(m_pTabKjWuGazoView!=NULL&&m_iLastTabIndex>=0&&m_iLastTabIndex<TAB_MAXCOUNT
		&&m_iLastTabIndex!=iNewTab)
        m_iTextThumbRowH[m_iLastTabIndex] = m_pTabKjWuGazoView->GetRowHeight(0);

	m_bTitleChanged = true;
	if( m_pApp == NULL || m_pApp->m_pCurrentTabDoc == NULL )
	{
		return;
	}
	m_pApp->m_pCurrentTabDoc = GetTabDoc(iNewTab);

	int iStyle = m_pApp->m_pCurrentTabDoc->GetTabStyle();
	
	if(iStyle == S_TEXTTHUMB&&m_pTabKjWuGazoView!=NULL)
	{
		m_pTabKjWuGazoView->ShowWindow(SW_HIDE);	
		m_pTabKjWuGazoView->SetRowHeight(0,m_iTextThumbRowH[iNewTab]);
	}
	
	SetActiveWnd(iStyle);

	UpdateTabView(iStyle);

	m_iLastTabIndex = iNewTab;
}

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	�q����ލX�V
/// ����	:	int iStyle	��	�q����ލ���
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::UpdateTabView(int iStyle)
{
	SetActiveWnd(iStyle);

	CWnd* pWnd = GetActiveWnd();

	if(pWnd==NULL||m_pgstEnv==NULL||m_pApp==NULL||m_pApp->m_pCurrentTabDoc==NULL)
		return;

	m_strFolderPath = m_pgstEnv->szFolderPath;
	m_strSrhINI.Format( _T("%s\\%s"), m_strFolderPath, INI_METSRHINFO ); 
	m_stMdiCFrmEnv.szSrhINIFileName = m_strSrhINI;
	m_cRefINIIO.InitSetUp( m_pgstComInf, m_pgstEnv, &m_stRefExtInfo, m_strSrhINI	);
	
	m_pApp->m_pCurrentTabDoc->ClearAllViews();
	switch(iStyle)
	{
// 2006-10-19 ZhangZG Insert Start Rev.02.00
	case S_CORRELATION://�֘A�t���\��
		{
			//CTabKjCorrelationView�q����ލX�V
			if(pWnd->IsKindOf(RUNTIME_CLASS(CTabKjCorrelationView)))
			{
				CTabKjCorrelationView* pTabKjCorrelationView = (CTabKjCorrelationView*)pWnd;
				if( pTabKjCorrelationView == NULL || m_pApp == NULL )
				{
					return;
				}
				pTabKjCorrelationView->SetDocument(m_pApp->m_pCurrentTabDoc);
				pTabKjCorrelationView->ClearData();
                pTabKjCorrelationView->Update();				
			}
		}
		break;
	case S_CORRELATIONTHUMB://�֘A�t���\���{�T���l�C���\��
			//pTabKjCorrelationView�q����ލX�V
			if(pWnd->IsKindOf(RUNTIME_CLASS(CTabKjCorrelationGazoView)))
			{
				CTabKjCorrelationGazoView* pTabKjCorrelationView = (CTabKjCorrelationGazoView*)pWnd;
				if( pTabKjCorrelationView == NULL || m_pApp == NULL )
				{
					return;
				}
				pTabKjCorrelationView->SetDocument(m_pApp->m_pCurrentTabDoc);
				pTabKjCorrelationView->ClearData();
                pTabKjCorrelationView->Update();				
			}
		break;
// 2006-10-19 ZhangZG Insert End
	case S_TEXT:
		{		
			//CTabKjWuView�q����ލX�V
			if(pWnd->IsKindOf(RUNTIME_CLASS(CTabKjWuView)))
			{
				CTabKjWuView* pTabKjWuView = (CTabKjWuView*)pWnd;
				if( pTabKjWuView == NULL || m_pApp == NULL )
				{
					return;
				}
				pTabKjWuView->SetDocument(m_pApp->m_pCurrentTabDoc);
				pTabKjWuView->ClearData();
                pTabKjWuView->Update();				
			}
		}
		break;
	case S_THUMB:
		{
			//CTabGazoView�q����ލX�V
			if(pWnd->IsKindOf(RUNTIME_CLASS(CTabGazoView)))
			{
				CTabGazoView* pTabGazoView = (CTabGazoView*)pWnd;
				if( pTabGazoView == NULL || m_pApp == NULL )
				{
					return;
				}
				pTabGazoView->SetDocument(m_pApp->m_pCurrentTabDoc);
				pTabGazoView->ClearData();
                pTabGazoView->Update();				
			}
		}
		break;
	case S_TEXTTHUMB:
		{
			//CTabKjWuGazoView�q����ލX�V
			if(pWnd->IsKindOf(RUNTIME_CLASS(CTabKjWuGazoView)))
			{
				CTabKjWuGazoView* pTabKjWuGazoView = (CTabKjWuGazoView*)pWnd;
				if( pTabKjWuGazoView == NULL || m_pApp == NULL )
				{
					return;
				}
				pTabKjWuGazoView->SetDocument(m_pApp->m_pCurrentTabDoc);
                pTabKjWuGazoView->Update();	
			}
		}
		break;
	}
}

// 2006-08-01 Wuk Insert Start Rev.01.00
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	�w�����ݒ�x����������
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::OnLtabSearchset()
{
	if( m_pgstEnv->hFSWnd ){
		::PostMessage( m_pgstEnv->hFSWnd, IDU_METSLLIST_SRHDLG_REQ, (WPARAM)(NULL), (LPARAM)(NULL) );
	}	
}
// 2006-08-01 Wuk Insert End
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	�ꗗ���CSV�������v��(�e�ڰт��ʒm�����)
/// ����	:	WPARAM	wParam	��	���ݑI���̃r���[
///				LPARAM	lParam	��	�ꗗ���CSV�����͈ꗗ���
/// �ԋp�l	:	0(����)	-1(�ُ�)
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
LRESULT CMDITabFrame::OnCsvDispRequest( WPARAM wParam, LPARAM lParam )
{
	int		iType		=	(int)wParam;
	int     iGmnNo      =   (int)lParam;
	CString	strTitle	=	_T("");

    if( iGmnNo == SZI_PRINT ) // �ꗗ���
    {
        if( iType == METSLLIST_MLLIST_KIJI ) 
		{
		    if( m_stMdiCFrmEnv.hWndKiji != NULL )
			{
				::PostMessage( m_stMdiCFrmEnv.hWndKiji, IDU_METSZILIST_CSV_REQ, (WPARAM)(iGmnNo), (LPARAM)(0) );
			}
		}
		else if( iType == METSLLIST_MLLIST_GAZO ) 
		{
	        if( m_stMdiCFrmEnv.hWndGazo != NULL )
			{
				::PostMessage( m_stMdiCFrmEnv.hWndGazo, IDU_METSZILIST_CSV_REQ, (WPARAM)(iGmnNo), (LPARAM)(0) );
			}
		}
    }
    else                      // �ꗗ�ۑ�
    {
	    if( iType == METSLLIST_MLLIST_KIJI ) 
		{
		    if( m_stMdiCFrmEnv.hWndKiji != NULL )
			{
				::SendMessage( m_stMdiCFrmEnv.hWndKiji, IDU_METSZILIST_CSV_REQ, (WPARAM)(iGmnNo), (LPARAM)(0) );
			}
		}
		else if( iType == METSLLIST_MLLIST_GAZO ) 
		{
            if( m_stMdiCFrmEnv.hWndGazo != NULL )
			{
				::SendMessage( m_stMdiCFrmEnv.hWndGazo, IDU_METSZILIST_CSV_REQ, (WPARAM)(iGmnNo), (LPARAM)(0) );
			}
		}
    }

	return (LRESULT)(0);
}

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	: ��è�ގq������߲���擾
/// ����	: �Ȃ�
/// �ԋp�l	: �q�����										
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
CView*  CMDITabFrame::GetActiveView( ) const
{
	CWnd* pWnd = this->GetActiveWnd();

	if(pWnd!=NULL)
	{
		//CTabKjWuView�q�����
		if(pWnd->IsKindOf(RUNTIME_CLASS(CTabKjWuView))||pWnd->IsKindOf(RUNTIME_CLASS(CTabGazoView)))
		{
			return (CView*)pWnd;
		}
		//CTabKjWuGazoView�q�����
		if(pWnd->IsKindOf(RUNTIME_CLASS(CTabKjWuGazoView)))
		{
			CTabKjWuGazoView* pTabKjWuGazoView = (CTabKjWuGazoView*)pWnd;
			return pTabKjWuGazoView->GetActiveView();	
		}
	}

	return NULL;
}
// 2006-08-01 Wuk Insert Start Rev.01.00
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	�w�\���X�V�x����������
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::OnLtabUpdate()
{
	if( m_pgstEnv->hFSWnd ){
		::SendMessage( m_pgstEnv->hFSWnd, IDU_METSZILIST_SELECT_FOLD_SRHREQ, (WPARAM)(NULL), (LPARAM)(NULL) );
	}
}

// 2006-08-01 Wuk Insert End
// 2006-08-02 Wuk Insert Start Rev.01.00
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	�����������폜���܂�
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::OnLtabSearchdel()
{	
	CString strSrhPathName = _T("");
	CString strSrhINI	   = _T("");
	_ST_SLLIST_REFLOCAL_INFO	stRefLocalInfo;
	strSrhPathName = m_pApp->m_pCurrentTabDoc->GetTabListINIFolder();
	strSrhINI	=	strSrhPathName + _T("\\") + INI_METSRHINFO;
	m_cRefINIIO.InitLocalSetUp( m_pgstComInf, m_pgstEnv, &stRefLocalInfo, strSrhINI	);
	if(  m_cRefINIIO.GetRefLocalInfo( TREE_FOLDTYPE_NORMAL, &stRefLocalInfo ) != TRUE )
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00290") ) ); 
	}

	stRefLocalInfo.iSozaiLocalSaveSiji = 0;
	stRefLocalInfo.iSozaiLocalSvDtType = 0;

	stRefLocalInfo.iSozailocalSozaiTypeSiji = 0;
	stRefLocalInfo.iSozaiLocalKijiSiji = 0;
	stRefLocalInfo.iSozaiLocalSyasinSiji = 0;
	stRefLocalInfo.iSozaiLocalZuSiji = 0;
	stRefLocalInfo.iSozaiLocalHyouSiji = 0;
	stRefLocalInfo.iSozaiLocalGurabuSiji = 0;
	stRefLocalInfo.iSozaiLocalHanyouSiji = 0;

	stRefLocalInfo.iSozaiLocalKarimiSiji = 0;
	stRefLocalInfo.iSozaiLocalHonbunSiji = 0;
//2006-09-26 ZhangZg Delete Start Rev 01.03
//	stRefLocalInfo.iSozaiLocalPsetuSiji = 0;
//2006-09-26 ZhangZg Delete End
	stRefLocalInfo.iSozaiLocalCaptionSiji = 0;

	stRefLocalInfo.strSozaiLocalKarimi = _T("");
	stRefLocalInfo.	strSozaiLocalHobun = _T("");
//2006-09-26 ZhangZg Delete Start Rev 01.03
//	stRefLocalInfo.	strSozaiLocalPsetu = _T("");
//2006-09-26 ZhangZg Delete End
	
	if( ( cComMsg.Toiawase( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00452") ) ) ) != IDYES )
	{
		return;
	}
	if( ( m_cRefINIIO.SetRefLocalInfo( TREE_FOLDTYPE_NORMAL, &stRefLocalInfo ) ) != TRUE )
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00290") ) ); 
	}

}
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	���������̓\��t��
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::OnLtabAttach()
{
	CString strSrhPathName = _T("");
	CString strSrhINI	   = _T("");
	CString strTempTabName = _T("");
	_ST_SLLIST_REFLOCAL_INFO	stRefLocalInfo;
	strSrhPathName = m_pApp->m_pCurrentTabDoc->GetTabListINIFolder();
	strSrhINI	=	strSrhPathName + _T("\\") + INI_METSRHINFO;
	m_cRefINIIO.InitLocalSetUp( m_pgstComInf, m_pgstEnv, &stRefLocalInfo, strSrhINI	);
	if(  m_cRefINIIO.GetRefLocalInfo( TREE_FOLDTYPE_NORMAL, &stRefLocalInfo ) != TRUE )
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00290") ) ); 
	}
	strTempTabName = stRefLocalInfo.strComTabName;
	if( ( cComMsg.Toiawase( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00415") ) ) ) != IDYES )
	{
		return;
	}
	m_stRefLocalInfo.strComTabName = strTempTabName;
	if( ( m_cRefINIIO.SetRefLocalInfo( TREE_FOLDTYPE_NORMAL, &m_stRefLocalInfo ) ) != TRUE )
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00290") ) ); 
	}
	if( m_pgstEnv->hFSWnd ){
		::SendMessage( m_pgstEnv->hFSWnd, IDU_METSZILIST_SELECT_FOLD_SRHREQ, (WPARAM)(NULL), (LPARAM)(NULL) );
	}
}

void CMDITabFrame::OnUpdateLtabAttach(CCmdUI *pCmdUI)
{
	if( pCmdUI == NULL )
	{
		return;
	}
// 2006-10-27 Mod Start K.Sekiya ST-061025-007:���[�J���ꗗ�F�S�Ă̑f�ށA�L���A�摜�^�u�Ƀ^�u��񂪓\��t���ł��Ă��܂�
	// �S�Ẵ^�u�A�L���^�u�A�摜�^�u�I�����͓\��t�����j���[��W�F��
	if(GetSelTab()==TAB_SEARCHALL||GetSelTab()==TAB_KIJI||GetSelTab()==TAB_GAZO)
	{
		pCmdUI->Enable(FALSE);
		return;
	}
// 2006-10-27 Mod End
	pCmdUI->Enable( this->bAttchFlag );
}
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	���������̃R�s�[
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::OnLtabCopy()
{
	CString strSrhPathName = _T("");
	CString strSrhINI	   = _T("");
	if( m_pApp->m_pCurrentTabDoc == NULL )
	{
		return;
	}
	strSrhPathName = m_pApp->m_pCurrentTabDoc->GetTabListINIFolder();
	strSrhINI	=	strSrhPathName + _T("\\") + INI_METSRHINFO;
	m_cRefINIIO.InitLocalSetUp( m_pgstComInf, m_pgstEnv, &m_stRefLocalInfo, strSrhINI	);
	if(  m_cRefINIIO.GetRefLocalInfo( TREE_FOLDTYPE_NORMAL, &m_stRefLocalInfo ) != TRUE )
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00416") ) ); 
	}
	if( this->bFlag == FALSE )
	{
		this->bAttchFlag = TRUE;
	}
	else
	{
		this->bAttchFlag = FALSE;
	}
}
// 2006-08-02 Wuk Insert End
// 2006-08-03 Wuk Insert Start Rev.01.00
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	���������̃C���|�[�g
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::OnLtabImport()
{
	CString			szPathNameList, szExtList;
	CString			strFileName,strTitleName;
	CString			strFinf;
	FILE			*fp;
	TCHAR			cStr[ MAX_PATH ];
	CString			strWork = _T("");
	CString strSrhPathName	= _T("");
	CString strSrcSrhINI	= _T("");
	CString strSrcFInfoINI	= _T("");
	CString strSrcMLListINI = _T("");
	CString strDstSrhINI    = _T("");
	CString	strDstFInfoINI  = _T("");
	CString strDstMLListINI = _T("");
	CString strTempPathName = _T("");
	memset( cStr, 0, sizeof( cStr ) );

	CString			szDefExtList	=	_T("*.zip|*.zip|");
	CFileDialog		cFDlgList( TRUE, _T("zip"), _T(""), OFN_OVERWRITEPROMPT | OFN_EXPLORER, szDefExtList, NULL, sizeof(OPENFILENAME) );

	/// �� OPENFILENAME(m_ofn)�ݒ� ========================================================================
	cFDlgList.m_ofn.lStructSize	=	sizeof(OPENFILENAME);
	cFDlgList.m_ofn.lpstrTitle	=	_T("���������C���|�[�g[���[�J���ꗗ�̃C���|�[�g�t�@�C�������w�肵�ĉ������B]");

	/// �� �t�@�C���_�C�A���O�i�f�ވꗗ�j�\�� =========================================================================
	if( ( cFDlgList.DoModal() ) != IDOK )	return;
	szPathNameList  = cFDlgList.GetPathName();
	strFileName		= cFDlgList.GetFileName();
	strTitleName	= cFDlgList.GetFileTitle();
	szExtList       = cFDlgList.GetFileExt();

	/// �� �g���q��"zip"�Ŗ����ꍇ =================================================================
	if ( szExtList.Find( _T("zip"), 0 ) == -1 ) 
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00342") ) ); 
		return;
	}

	/// �� �t�@�C�����ɃX�y�[�X���܂܂�Ă���ꍇ�̓G���[ =================================================================
	if ( strFileName.Find( _T(" "), 0 ) != -1 )
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00455") ) ); 
		return;
	}
	if( m_pApp->m_pCurrentTabDoc != NULL )
	{
		strSrhPathName = m_pApp->m_pCurrentTabDoc->GetTabListINIFolder();
	}
	CString strFileDir = m_pgstComInf->szUsrHomeDir;

	CFileFind tempFind; 
	BOOL bFileFind = tempFind.FindFile(szPathNameList);
	tempFind.Close();

	if (!(bFileFind))
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00345") ) ); 
		return;
	}

	CString strPathName = strFileDir + _T("\\tempSozai");	
	if( CreateDirectory(strPathName, NULL) == 0 ) 
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00454") ) ); 
		return;
	}
	
	strTempPathName = strPathName + _T("\\") + strFileName;
	if( ( CopyFile( szPathNameList, strTempPathName, FALSE ) ) != TRUE )
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00206") ), strSrcSrhINI, strDstSrhINI );
		DeleteDir(strPathName);
		return ;
	}

	CString sSziRelPath = _T("x -aoa ") + strTempPathName + _T(" -o") + strPathName + _T("\\");

	USES_CONVERSION;
	LPCSTR cSziRelPath = T2A( sSziRelPath );

	BOOL bSziRel = FuncToZip(cSziRelPath);
	if (bSziRel == 1)
	{
		strFinf = strPathName + _T("\\") + strTitleName + _T(".Finf"); 
		if( ( fp = _wfopen( strFinf, _T("r+t") ) ) == NULL )
		{
			cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00199") ), strPathName ); 
			DeleteDir(strPathName);
			return ;
		}
		memset( cStr, NULL, sizeof(cStr) ); 
		fwscanf( fp, _T("%s"), cStr ); 
		strWork = cStr; 
		fclose( fp );

		if( m_pgstEnv != NULL && m_pgstEnv->iType == METSLLIST_TYPE_SZI )
		{	//// �f�ވꗗ�̏ꍇ
			if( ( strWork.Find( _T("SziList") ) ) < 0 )
			{
				cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00200") ), strFinf ); 
				DeleteDir(strPathName);
				return;
			}
		}
		else
		{	
			//// ���[�J���ꗗ�̏ꍇ
			if( ( strWork.Find( _T("LocList") ) ) < 0 )
			{
				cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00201") ), strFinf );
				DeleteDir(strPathName);
				return;
			}
		}
		/// �� �C���|�[�g���쐬 =============================================================================
		/// ���ʌ�
		strSrcSrhINI.Format		( _T("%s\\%s_%s"	), strPathName, strTitleName, INI_METSRHINFO		);
		// 2006-09-21 Wanggl Modify Start Rev.01.02 ReDefine INI_METFOLDERINFO_LOCTAB
		//strSrcFInfoINI.Format	( _T("%s\\%s_%s"	), strPathName, strTitleName, INI_METFOLDERINFO		);
		if ( m_pgstEnv->iType == METSLLIST_TYPE_LOC ) {
			strSrcFInfoINI.Format	( _T("%s\\%s_%s"	), strPathName, strTitleName, INI_METFOLDERINFO_LOCTAB		);
		} else {
			strSrcFInfoINI.Format	( _T("%s\\%s_%s"	), strPathName, strTitleName, INI_METFOLDERINFO		);
		}
		// 2006-09-21 Wanggl Modify End
		strSrcMLListINI.Format	( _T("%s\\%s_%s"	), strPathName, strTitleName, MLLIST_INI_FILENAME	);

		if( ( m_cZBPEx.IsFileExist( strSrcSrhINI ) ) != TRUE )
		{
			cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00203") ) );
			DeleteDir(strPathName);
			return;
		}
		if( ( m_cZBPEx.IsFileExist( strSrcFInfoINI ) ) != TRUE )
		{
			cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00204") ) );
			DeleteDir(strPathName);
			return;
		}
		if( ( m_cZBPEx.IsFileExist( strSrcMLListINI ) ) != TRUE )
		{
			cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00205") ) );
			DeleteDir(strPathName);
			return;
		}
		/// ���ʐ�
		strDstSrhINI.Format		( _T("%s\\%s"	), strSrhPathName, INI_METSRHINFO		);		
		// 2006-09-21 Wanggl Modify Start Rev.01.02 ReDefine INI_METFOLDERINFO_LOCTAB
		//strDstFInfoINI.Format	( _T("%s\\%s"	), strSrhPathName, INI_METFOLDERINFO	);
		if ( m_pgstEnv->iType == METSLLIST_TYPE_LOC ) {
			strDstFInfoINI.Format	( _T("%s\\%s"	), strSrhPathName, INI_METFOLDERINFO_LOCTAB	);
		} else {
			strDstFInfoINI.Format	( _T("%s\\%s"	), strSrhPathName, INI_METFOLDERINFO	);
		}
		// 2006-09-21 Wanggl Modify End
		strDstMLListINI.Format	( _T("%s\\%s"	), strSrhPathName, MLLIST_INI_FILENAME	);

		/// ���������ݒ�INI̧�ق̗L���̂�����
		if( ( m_cZBPEx.IsFileExist( strDstSrhINI ) ) == TRUE )
		{
			if( ( cComMsg.Toiawase( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00094") ) ) ) != IDYES )
			{
				return ;
			}
		}

		/// �� �C���|�[�g���� =================================================================================
		/// �E �����������
		if( ( CopyFile( strSrcSrhINI,    strDstSrhINI   , FALSE ) ) != TRUE )
		{
			cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00206") ), strSrcSrhINI, strDstSrhINI );
			DeleteDir(strPathName);
			return ;
		}
		/// �E �t�H���_�[���
		if( ( CopyFile( strSrcFInfoINI,  strDstFInfoINI , FALSE ) ) != TRUE )
		{
			cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00207") ), strSrcFInfoINI, strDstFInfoINI );
			DeleteDir(strPathName);
			return ;
		}
		/// �E ���X�g���
		if( ( CopyFile( strSrcMLListINI, strDstMLListINI, FALSE ) ) != TRUE )
		{
			cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00208") ), strSrcMLListINI, strDstMLListINI );
			DeleteDir(strPathName);
			return ;
		}
	}

	DeleteDir(strPathName);


	if (!bSziRel)
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00350") ) ); 
	}
	
	_ST_SLLIST_REFLOCAL_INFO	stRefLocalInfo;

	m_cRefINIIO.InitLocalSetUp( m_pgstComInf, m_pgstEnv, &stRefLocalInfo, strDstSrhINI	);
	if(  m_cRefINIIO.GetRefLocalInfo( TREE_FOLDTYPE_NORMAL, &stRefLocalInfo ) != TRUE )
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00290") ) ); 
	}

	if( stRefLocalInfo.strComTabName.IsEmpty() != TRUE )
	{
		this->SetCurTabTitle( stRefLocalInfo.strComTabName );
	}

	if( m_pgstEnv != NULL && m_pgstEnv->hFSWnd )
	{
		::SendMessage( m_pgstEnv->hFSWnd, IDU_METSZILIST_SELECT_FOLD_SRHREQ, (WPARAM)(NULL), (LPARAM)(NULL) );
	}
}
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	���������̃G�N�X�|�[�g
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::OnLtabExport()
{
	/// �� �����y�я����� =================================================================================
	FILE			*fp;
	CString			szPathName, szFileName, szTitleName, szFName, szExt, szTemp;
	CString			szSrcSrhINI, szSrcFInfoINI, szSrcMLListINI;
	CString			szDstSrhINI, szDstFInfoINI, szDstMLListINI;
	CString			strFinf;
	CString			szFolderName;
	CString			strTempFrameFlod;
	CString			strTempPathName;
	CString			szDefExt	=	_T("*.zip|*.zip|");
	CFileDialog		cFDlg( FALSE, _T("FInf"), NULL, OFN_OVERWRITEPROMPT | OFN_EXPLORER, szDefExt, NULL, sizeof(OPENFILENAME) );

	/// �� ���O���� [ ̫��ް���L������(���������ݒ�INI̧�ق̂�����) ] ===================================
	if( m_pApp->m_pCurrentTabDoc != NULL )
	{
		szFolderName = m_pApp->m_pCurrentTabDoc->GetTabListINIFolder(); 
	}

	szSrcSrhINI.Format( _T("%s\\%s"	), szFolderName, INI_METSRHINFO );
	if( ( m_cZBPEx.IsFileExist( szSrcSrhINI ) ) != TRUE )
	{
		cComMsg.Kakunin( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00065") ) ); 
		return ;

	}

	/// �� OPENFILENAME(m_ofn)�ݒ� ========================================================================
	cFDlg.m_ofn.lStructSize	=	sizeof(OPENFILENAME);
	cFDlg.m_ofn.lpstrTitle	=	_T("�t�H���_�[���G�N�X�|�[�g[�G�N�X�|�[�g�t�@�C�������w�肵�ĉ������B]");

	/// �� �t�@�C���_�C�A���O�\�� =========================================================================
	if( ( cFDlg.DoModal() ) != IDOK )
	{
		return ;
	}
	szPathName  = cFDlg.GetPathName();
	szFileName  = cFDlg.GetFileName();
	szTitleName = cFDlg.GetFileTitle();
	szExt       = cFDlg.GetFileExt();
	/// �� �g���q��"zip"�Ŗ����ꍇ =================================================================
	if ( szExt.Find( _T("zip"), 0 ) == -1 )
	{
		/// �� �t�@�C�����쐬 ===========================================================================
		szPathName.Replace( szFileName, _T("") );
		szFileName = szPathName + szTitleName + _T(".zip");
	} 
	// �� �t�@�C�����ɃX�y�[�X���܂܂�Ă���ꍇ�̓G���[ =================================================================
	if ( szFileName.Find( _T(" "), 0 ) != -1 ) {
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00456") ) );
		return;
	}

	/// �� �G�N�X�|�[�g���쐬 ===========================================================================
	szTemp.Format( _T("\\%s"), szFileName ); szFName = szPathName; szFName.Replace( szTemp, _T("") );
	strTempFrameFlod = m_pgstComInf->szUsrHomeDir + _T("\\") + _T("tempTabFrameFlod");
	CreateDirectory( strTempFrameFlod, NULL );
	/// ���ʌ�
	szSrcSrhINI.Format		( _T("%s\\%s"	), szFolderName, INI_METSRHINFO			);	
	// 2006-09-21 Wanggl Modify Start Rev.01.02 ReDefine INI_METFOLDERINFO_LOCTAB
	//szSrcFInfoINI.Format	( _T("%s\\%s"	), szFolderName, INI_METFOLDERINFO		);
	if ( m_pgstEnv->iType == METSLLIST_TYPE_LOC ) {
		szSrcFInfoINI.Format	( _T("%s\\%s"	), szFolderName, INI_METFOLDERINFO_LOCTAB		);
	} else {
		szSrcFInfoINI.Format	( _T("%s\\%s"	), szFolderName, INI_METFOLDERINFO		);
	}
	// 2006-09-21 Wanggl Modify End
	szSrcMLListINI.Format	( _T("%s\\%s"	), szFolderName, MLLIST_INI_FILENAME	);
	/// ���ʐ�
	szDstSrhINI.Format		( _T("%s\\%s_%s"	), strTempFrameFlod, szTitleName, INI_METSRHINFO		);	
	// 2006-09-21 Wanggl Modify Start Rev.01.02 ReDefine INI_METFOLDERINFO_LOCTAB
	//szDstFInfoINI.Format	( _T("%s\\%s_%s"	), strTempFrameFlod, szTitleName, INI_METFOLDERINFO		);
	if ( m_pgstEnv->iType == METSLLIST_TYPE_LOC ) {
		szDstFInfoINI.Format	( _T("%s\\%s_%s"	), strTempFrameFlod, szTitleName, INI_METFOLDERINFO_LOCTAB		);
	} else {
		szDstFInfoINI.Format	( _T("%s\\%s_%s"	), strTempFrameFlod, szTitleName, INI_METFOLDERINFO		);
	}
	// 2006-09-21 Wanggl Modify End
	szDstMLListINI.Format	( _T("%s\\%s_%s"	), strTempFrameFlod, szTitleName, MLLIST_INI_FILENAME	);
	strFinf.Format			( _T("%s\\%s.Finf"	), strTempFrameFlod, szTitleName );

	/// �� �G�N�X�|�[�g���� ===============================================================================
	/// �E �G�N�X�|�[�g���t�@�C���쐬
	if( ( fp = _wfopen( strFinf, _T("w+t") ) ) == NULL )
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00210") ) ); 
		return;
	}
	if( m_pgstEnv != NULL && m_pgstEnv->iType == METSLLIST_TYPE_SZI )
	{	//// �f�ވꗗ�̏ꍇ
		fwprintf( fp, _T("SziList\n") );
	}
	else
	{	//// ���[�J���ꗗ�̏ꍇ
		fwprintf( fp, _T("LocList\n") );
	}
	fclose( fp );
	/// �E �����������
	if( ( CopyFile( szSrcSrhINI,    szDstSrhINI   , FALSE ) ) != TRUE )
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00211") ), szSrcSrhINI, szDstSrhINI );
		DeleteFile( szDstSrhINI ); DeleteFile( szDstFInfoINI ); DeleteFile( szDstMLListINI );
		return;
	}
	/// �E �t�H���_�[���
	if( ( CopyFile( szSrcFInfoINI,  szDstFInfoINI , FALSE ) ) != TRUE )
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00212") ), szSrcFInfoINI, szDstFInfoINI );
		DeleteFile( szDstSrhINI ); DeleteFile( szDstFInfoINI ); DeleteFile( szDstMLListINI );
		return;
	}
	/// �E ���X�g���
	if( ( CopyFile( szSrcMLListINI, szDstMLListINI, FALSE ) ) != TRUE )
	{
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00213") ), szSrcMLListINI, szDstMLListINI );
		DeleteFile( szDstSrhINI ); DeleteFile( szDstFInfoINI ); DeleteFile( szDstMLListINI );
		return;
	}
	
	CString sSziZipComLine = _T("a -tzip ") + strTempFrameFlod + _T("\\") + szFileName + _T(" -r ") + strTempFrameFlod + _T("\\");
	USES_CONVERSION;
	LPCSTR cSziFilePath = T2A( sSziZipComLine );

	// �f�ވꗗzip
	BOOL bSziRet;
	bSziRet = FuncToZip(cSziFilePath);

	if ( bSziRet )
	{
		strTempPathName = strTempFrameFlod + _T("\\") + szFileName;
		if( ( CopyFile( strTempPathName,  szPathName , FALSE ) ) != TRUE )
		{
			cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00212") ), szSrcFInfoINI, szDstFInfoINI );
			this->DeleteDir( strTempFrameFlod );
			return;
		}
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00357") ) ); 
	} 
	else
	{
		CFileFind tempFind; 

		BOOL bSziFind = tempFind.FindFile( szPathName );
		if (bSziFind)
		{
			DeleteFile( szPathName );
		}
		tempFind.Close(); 
		cComMsg.Error( this, (LPCSTR)(LPCTSTR)cComMsg.GetMsg( MESSAGE_LOCALLIST, _T("00058") ) ); 
	}
	DeleteDir( strTempFrameFlod );
}
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	���k�𓀏���
/// ����	:	���k�𓀑Ώۃp�X�y�уI�v�V�����R�}���h���C��
/// �ԋp�l	:	TRUE�i�����j�@FALSE�i���s�j
/// �𓀗p�R�}���h���C��
/// LPCSTR			sPath="e -w C:\\ziptest\\ test.zip";
/// 
/// //���k�p�R�}���h���C��
/// LPCSTR			sPath="a -tzip test.zip C:\\ziptest\\ test.xml Book1.xml";
/// a -tzip 		���̂܂܂ɂ��ĉ�����
/// test.zip		���k�t�@�C���̖��̂ł�
/// C:\\ziptest\\		���k�t�@�C��������ƂȂ�t�H���_�A
/// 			�܂����k�Ώۃt�@�C�������Ɏw�肵�Ȃ���΂��̃t�H���_�ɂ���ƌ��Ȃ��܂�
/// test.xml Book1.xml	���k�Ώۃt�@�C���A���̏ꍇ��2�̃t�@�C�����w�肵�Ă��܂�
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
BOOL CMDITabFrame::FuncToZip(LPCSTR sPath)
{

	HINSTANCE		hInstance	=	NULL;
	int			nResult = -1;
	WORD w = 1024;
	char       buffer[1024];

	typedef int (WINAPI *SZIP)(const HWND , LPCSTR ,LPSTR , const DWORD );
	SZIP ss;

	if( ( hInstance = LoadLibrary( _T("7-zip32.DLL") ) ) != NULL ){

			ss = (SZIP)(::GetProcAddress(hInstance, "SevenZip"));
			if( ss != NULL ){

				nResult = ss(NULL, sPath, buffer, 1024);
			}
	}

	FreeLibrary(hInstance);
	
	if(nResult == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	�t�@�C�����폜����
/// ����	:	LPCTSTR		strDirName
/// �ԋp�l	:	TRUE(����)	FALSE(�ُ�)
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
BOOL CMDITabFrame::DeleteDir(CString strDirName)
{
	strDirName = strDirName + _T("?");
	strDirName.SetAt(strDirName.GetLength() - 1, 0);
	SHFILEOPSTRUCT shfileDelete;

	memset(&shfileDelete, 0, sizeof(shfileDelete));
	shfileDelete.wFunc = FO_DELETE; 
	shfileDelete.fFlags = FOF_SILENT|FOF_NOCONFIRMATION; 
	shfileDelete.fAnyOperationsAborted = TRUE;

	shfileDelete.pFrom = strDirName;
	INT iRet = SHFileOperation(&shfileDelete);
	if(iRet)
	{
		return FALSE;
	}
	return TRUE;
}
// 2006-08-03 Wuk Insert End

///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
/// �T�v	:	����ޔj��
/// ����	:	����
/// �ԋp�l	:	����
///+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+///
void CMDITabFrame::OnDestroy()
{
	CBaseTabFrame::OnDestroy();

	if(m_pTabKjWuGazoView!=NULL&&m_iLastTabIndex>=0&&m_iLastTabIndex<TAB_MAXCOUNT)
        m_iTextThumbRowH[m_iLastTabIndex] = m_pTabKjWuGazoView->GetRowHeight(0);

	/// �� �����y�я����� =================================================================================
	int         iPos;
	CComPIOEx	cPIO;
	CString     strTabNo;
	CString     strTabTitle;
	CString		strSec,strTabFrameInfoINI;

	/// �� INI̧�ٖ����̫��ޖ��擾 =======================================================================
	strTabFrameInfoINI.Format( _T("%s\\%s"), m_pgstComInf->szUsrHomeDir,TAB_FRAMEINFOINIFILE);
	
	/// �� ���ݒ� ===========================================================================================
	cPIO.SetProfName( strTabFrameInfoINI ); 

	/// �� �^�v���ʏ��擾 =======================================================================
	strSec = _T("�^�v���ʏ��");
    for( iPos = 0; iPos < TAB_MAXCOUNT; iPos++ )
	{
	    if( m_iTextThumbRowH[iPos] >= m_pApp->m_iViewMinHeight )
	    {
	        strTabNo.Format( _T("Tab%dRow0"), iPos+1 );
			cPIO.SetInt ( strSec, strTabNo, m_iTextThumbRowH[iPos]);
	    }
		if( iPos >= TAB_FIXSEARCHCOUNT ) 
		{
			strTabTitle.Format( _T("Tab%dTitle"), iPos+1 );
			cPIO.SetStr ( strSec, strTabTitle, GetTabDoc(iPos)->GetTabTitle());
		}
	}
}
