// systemfocusdialog.cpp (Windows NT/2000)
//
// This example will show how you can display the choose Domain/Computer
// dialog provided by network services.  
// 
// (c)1999 Ashot Oganesyan K, SmartLine, Inc
// mailto:ashot@aha.ru, http://www.protect-me.com, http://www.codepile.com

#include <windows.h>
#include <stdio.h>


#define FOCUSDLG_DOMAINS_ONLY             1
#define FOCUSDLG_SERVERS_ONLY             2
#define FOCUSDLG_SERVERS_DOMAINS          3
#define FOCUSDLG_BROWSE_LOGON_DOMAIN      0x00010000
#define FOCUSDLG_BROWSE_WKSTA_DOMAIN      0x00020000
#define FOCUSDLG_BROWSE_OTHER_DOMAINS     0x00040000
#define FOCUSDLG_BROWSE_TRUSTING_DOMAINS  0x00080000
#define FOCUSDLG_BROWSE_WORKGROUP_DOMAINS 0x00100000
#define FOCUSDLG_BROWSE_ALL_DOMAINS       (  \
        FOCUSDLG_BROWSE_LOGON_DOMAIN       | \
        FOCUSDLG_BROWSE_WKSTA_DOMAIN       | \
        FOCUSDLG_BROWSE_OTHER_DOMAINS      | \
        FOCUSDLG_BROWSE_TRUSTING_DOMAINS   | \
        FOCUSDLG_BROWSE_WORKGROUP_DOMAINS )

// ntlanman!I_SystemFocusDialog (NT specific!)
// 
// The I_SystemFocusDialog function creates a dialog box that lets the user select
// the computer or domain.
//
//
// DWORD I_SystemFocusDialog(
//   HWND   hwndOwner,       // Handle to the owner window for the dialog box.
//   UINT   dwSelectionFlag, // Flags specifying the options for the dialog box.
//   LPWSTR wszName,         // Address of a buffer to receive the display name.
//                           // of the computer selected by the user (UNICODE!).
//   DWORD  dwBufSize,       // The size of the buffer wszName in characters.
//   LPBOOL pbOKPressed,     // Pointer to a boolean variable that receives TRUE
//                           // if the OK button was pressed by the user.
//   LPWSTR wszHelpFile,     // Address of an unicode string containing the path,
//                           // if necessary, and the name of the Help file.
//   DWORD  dwContextHelpId  // Help context identifier.
// );


typedef DWORD (WINAPI *PROCSYSTEMFOCUSDIALOG)(HWND,UINT,LPWSTR,DWORD,LPBOOL,LPWSTR,DWORD);


BOOL ComputerBrowser(HWND hWndParent,LPWSTR wCompName,DWORD dwBufLen);


void main(int argc, char* argv[])
{
    WCHAR wCompName[MAX_COMPUTERNAME_LENGTH + 1];

    if (ComputerBrowser(NULL,wCompName,sizeof(wCompName)/sizeof(WCHAR)))
       wprintf(wCompName);
}

BOOL ComputerBrowser(HWND hWndParent,LPWSTR wCompName,DWORD dwBufLen)
{
    PROCSYSTEMFOCUSDIALOG SystemFocusDialog;
    BOOL                  bOK;
    HINSTANCE             hLibrary;
    DWORD                 dwError;

    hLibrary = LoadLibrary(TEXT("ntlanman.dll"));
    if (!hLibrary)
       return FALSE;

    SystemFocusDialog = (PROCSYSTEMFOCUSDIALOG)
                        GetProcAddress(hLibrary,"I_SystemFocusDialog");

    if (!SystemFocusDialog)
	{
        FreeLibrary(hLibrary);
        return FALSE;
	}


	dwError = SystemFocusDialog( hWndParent,
                                 FOCUSDLG_SERVERS_DOMAINS|FOCUSDLG_BROWSE_ALL_DOMAINS,
                                 wCompName,
                                 dwBufLen,
                                 &bOK,
                                 NULL,
                                 0 );
    FreeLibrary(hLibrary);

    if (dwError!=NO_ERROR)
        return FALSE;

	return bOK;
}