// �ļ������Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "�ļ������.h"
#include "�ļ������Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyDlg dialog

CMyDlg::CMyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyDlg)
	DDX_Control(pDX, IDC_COMBO1, m_Combox);
	DDX_Control(pDX, IDC_LIST1, m_List);
	DDX_Control(pDX, IDC_TREE1, m_tree);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMyDlg, CDialog)
	//{{AFX_MSG_MAP(CMyDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelchangeCombo1)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE1, OnSelchangedTree1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyDlg message handlers

BOOL CMyDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
 /*   int nPos=0;
    iIndex=::GetLogicalDrives();
	TRACE("%d\n",iIndex);
	CString str;
	str=_T("?:");
	while(iIndex)
	{
		if(iIndex & 1)
		{
           str.SetAt(0,_T('A')+nPos);
		   m_Combox.AddString(str);
		}
		nPos++;
	}
*/	
	CString path;
	path="E:";
	m_Root=path;
	HTREEITEM TreeItem=m_tree.InsertItem(m_Root,TVI_ROOT,TVI_SORT);
	m_Combox.SetCurSel(3);
	path+="\\*.*";
	FindFile(path,TreeItem);
	DeleteListItem();
	FindFileName(path);
	m_tree.Expand(TreeItem,TVE_EXPAND);
	m_iIndex=0;

	for(int i=0;i<20;i++)
		strName[i]=_T("");
    m_Expand=TRUE;
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMyDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMyDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMyDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

//////////////////////////////////////////////////////////////////
void CMyDlg::FindFile(CString pszPath,HTREEITEM TreeItem)
{
	CString str;
	HANDLE hFind;
	WIN32_FIND_DATA fd ;
	hFind=::FindFirstFile((LPCTSTR)pszPath,&fd);
	if(hFind!=INVALID_HANDLE_VALUE)
	{
		do
		{
			if((fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ))
			{
				str=(LPCTSTR)&fd.cFileName;
				if((str!=_T(".")) && (str!=_T("..")))
				{
					m_tree.InsertItem(str,TreeItem,TVI_SORT);
				}
			}
		}
		while(::FindNextFile(hFind,&fd));
	}
	else
	{
		m_tree.DeleteAllItems();
		DeleteListItem();
		MessageBox("·�����Ի����豸û׼����!����!","Error",MB_OK|MB_OKCANCEL|MB_ICONERROR);
	}
	FindClose(hFind);
}

///////////////////////////////////////////////////////////////////

void CMyDlg::FindFileName(CString pszPath)
{
	CString str;
   HANDLE hFind;
   WIN32_FIND_DATA fd ;
   hFind=::FindFirstFile((LPCTSTR)pszPath,&fd);
   if(hFind!=INVALID_HANDLE_VALUE)
   {
	   do
	   {
		   if(!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ))
		   {
               str=(LPCTSTR)&fd.cFileName;
			   m_List.AddString(str);
		   }

	   }
	   while(::FindNextFile(hFind,&fd));
   }
   FindClose(hFind);
   for(int i=0;i<20;i++)
	   strName[i]=_T("");
   m_iIndex=0;
}

///////////////////////////////////////////////////////////////////

CString CMyDlg::GetParentName(HTREEITEM TreeItem)
{
	HTREEITEM ParentTreeItem;
	ParentTreeItem=m_tree.GetParentItem(TreeItem);
	CString str=m_tree.GetItemText(ParentTreeItem);

	return str;
}

///////////////////////////////////////////////////////////////////

void CMyDlg::DeleteListItem()
{
	int m_Count=m_List.GetCount();
	while(m_Count>=0)
	{
		m_List.SetCurSel(0);
		m_Count=m_List.DeleteString(0);
	}
}

///////////////////////////////////////////////////////////////////

void CMyDlg::OnSelchangeCombo1() 
{
	// TODO: Add your control notification handler code here
    int iIndex=m_Combox.GetCurSel();
	CString str;
	m_Combox.GetLBText(iIndex,str);
	if(str!=m_Root)
	{
		m_tree.DeleteAllItems();
		m_Root=str;
		str+="\\*.*";
		HTREEITEM TreeItem=m_tree.InsertItem(m_Root,TVI_ROOT,TVI_SORT);
		FindFile(str,TreeItem);
		DeleteListItem();
		FindFileName(str);
		m_tree.Expand(TreeItem,TVE_EXPAND);
	}
}

///////////////////////////////////////////////////////////////////

void CMyDlg::OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
    //HTREEITEM ChildTreeItem;
	CString str,Path,PathName;
	PathName=_T("");
	Path=_T("");
    HTREEITEM ParentTreeItem;
	HTREEITEM TreeItem=m_tree.GetSelectedItem();
    //ChildTreeItem=m_tree.GetChildItem(TreeItem);
	if(!m_tree.Expand(TreeItem,TVE_EXPAND))
	{
      m_Expand=TRUE;
	}
	else
		m_Expand=FALSE;

	ParentTreeItem=TreeItem;
	str=m_tree.GetItemText(TreeItem);
	while(str!=m_Root)
	{
		Path=GetParentName(ParentTreeItem);
		ParentTreeItem=m_tree.GetParentItem(ParentTreeItem);
		strName[m_iIndex]=Path;
		if(Path==m_Root)
		{
			for(int i=m_iIndex;i>=0;i--)
				PathName+=strName[i]+"\\";
			PathName+=str;
			PathName+="\\*.*";
			DeleteListItem();
			if(m_Expand)
			   FindFile(PathName,TreeItem);
			FindFileName(PathName);
			m_tree.Expand(TreeItem,TVE_EXPAND);
			break;
		}
		m_iIndex++;
	}
		
	if(str==m_Root)
	{
		
		str=str+"\\*.*";
		DeleteListItem();
		
		FindFileName(str);
		m_tree.Expand(TreeItem,TVE_EXPAND);
	}

	
	*pResult = 0;
}
