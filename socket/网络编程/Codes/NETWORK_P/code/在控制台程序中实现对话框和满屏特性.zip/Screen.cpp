// Dialog.cpp : Defines the entry point for the application.
//

#include <windows.h>

LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
inline int SetDefaultFont(int identifier, HWND hwnd);
int full();

//Global Vars:
HDC			hDC=NULL;		// Private GDI Device Context
HGLRC		hRC=NULL;		// Permanent Rendering Context
HWND		hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application

HINSTANCE hInst;
HINSTANCE hPrevInstance; 
LPSTR lpCmdLine; 
int nCmdShow;

HWND btn_hwnd[1];
bool	keys[256];
bool	active=TRUE;
bool	fullscreen=TRUE;

//Constants:
const char ClassName[ ] = "Dialog";

#define szHello "Hello"

const int	btn_id_0 = 0,
			btn_id_1 = 1;

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
HWND hwnd; //Handle to the main window
	MSG messages; //Here we save the messages to our window	 	
	WNDCLASSEX wincl; //Data Structure for the window class
	// copy the local var hInstance into the global hInst:
	hInst = hInstance;
	//Configure the window class:
	wincl.hInstance = hInst;
	wincl.lpszClassName = ClassName;
	wincl.lpfnWndProc = WindowProcedure; //This Function is called by windows
	wincl.style = CS_VREDRAW | CS_HREDRAW; //Redraw the entire window if it is moved or resized 
	wincl.cbSize = sizeof(WNDCLASSEX);
	//Use default icon and mouse pointer:
	wincl.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wincl.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
	wincl.hCursor = LoadCursor(NULL, IDC_ARROW);
	wincl.lpszMenuName = NULL; //No menu
	wincl.cbClsExtra = 0; //No extra bytes after the window class
	wincl.cbWndExtra = 0; //Structure of the window instance
	//use default window background color:
	wincl.hbrBackground = (HBRUSH) COLOR_BACKGROUND;
	//Register the window class. If fail, quit the program
	if(!RegisterClassEx(&wincl))
	{
		MessageBox(NULL,"Could not register the window class","ERROR",MB_OK | MB_ICONERROR);
		return 0;
	}
	//the class is registered, let's create the window:
	hwnd = CreateWindowEx(
		0, //Extended possibilities for variation
		ClassName,//Class name
		"Dialog",//title text
		WS_OVERLAPPED | WS_CAPTION | WS_POPUPWINDOW | WS_SYSMENU,// Default window; no maximize or minimize button
		CW_USEDEFAULT,//Windows decides the position
		CW_USEDEFAULT,//where the window ends up on the screen
		175,//the window's width
		130,//and height in pixels
		HWND_DESKTOP,//The window is a child window to the Desktop
		NULL,//No menu
		hInst,//Program instance
		NULL);//No window creation data
	//Make the window visible on the screen:
	ShowWindow(hwnd,nCmdShow);
	//Run the Message loop. It will run until GetMessage() return 0:
	while(GetMessage(&messages,NULL,0,0))
	{
		//Translate virtual-key messages into character messages:
		TranslateMessage(&messages);
		//Dispatch mesage to WindowProcedure:
		DispatchMessage(&messages);
	}
	//The program's return value is 0 - the value that PostQuitMessage() gave us:
	return messages.wParam;
}

//This function is called by the Windows function DispatchMessage():
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	int            i = 0;

    switch (message)
    {
	case WM_CREATE:
		LoadCursor(NULL, IDC_CROSS);
		
		//Create the child windows(controls) here:
		btn_hwnd[0] = CreateWindow("Button","Full-Screen",WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,45,24,74,22,hwnd,(HMENU) btn_id_0,hInst,NULL);
		btn_hwnd[1] = CreateWindow("Button","Quit",WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,45,63,74,22,hwnd,(HMENU) btn_id_1,hInst,NULL);
		
		for(i = 0; i <= 17; i++) SetDefaultFont(i,hwnd);
		
	break;
	case WM_COMMAND:
		
		if(HIWORD(wParam) == BN_CLICKED) //that's the only message we need to handle
		{
			switch(LOWORD(wParam))
			{
			case btn_id_0:
			PostQuitMessage(0);
			return full();
			break;
			
			case btn_id_1:
			PostQuitMessage(0);
			break;
			}
		break;
		}
	case WM_KEYDOWN:
		{
		switch(wParam)
			{
			case VK_ESCAPE:
				DestroyWindow(hWnd);
				PostQuitMessage(0);
			return true;
			}
		}
	case WM_DESTROY:
		PostQuitMessage(0);//Send a WM_QUIT message to the message queue
	break;
	default://for messages that we don't deal with
		return DefWindowProc(hwnd,message,wParam,lParam);
	break;
	}
return 0;
}

inline int SetDefaultFont(int identifier, HWND hwnd)
{
    SendDlgItemMessage(
    hwnd,
    identifier,
    WM_SETFONT,
    (WPARAM)GetStockObject(DEFAULT_GUI_FONT),
    MAKELPARAM(true, 0));
    return 0;
}

int full()
{
		WNDCLASSEX wc;

        // Register the window class for the main window
        wc.cbSize        = sizeof(WNDCLASSEX);
        wc.style         = CS_CLASSDC;
        wc.lpfnWndProc   = WndProc;
        wc.cbClsExtra    = 0l;
        wc.cbWndExtra    = 0l;
        wc.hInstance     = GetModuleHandle(NULL);
		wc.hIcon         = LoadIcon(hInstance, IDI_APPLICATION);
        wc.hCursor       = LoadCursor(NULL, IDC_CROSS);
        wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
        wc.lpszMenuName  = NULL;
        wc.lpszClassName = "Full-Screen";
        wc.hIconSm       = NULL;

        if (!RegisterClassEx(&wc))
        {
            return 0;
        }

        // Create the main window
        HWND hWnd = CreateWindow(
            wc.lpszClassName,
            "Full-Screen",
            WS_POPUPWINDOW,
            CW_USEDEFAULT,
            CW_USEDEFAULT,
            9999, // Big Enough To Make Full Screen
            9999, // Big Enough To Make Full Screen
            GetDesktopWindow(),
            NULL,
            wc.hInstance,
            NULL);

        if (hWnd == NULL)
        {
            return 0;
        }

		            ShowWindow(hWnd, SW_SHOWNORMAL);
                    UpdateWindow(hWnd);

                    MSG msg;
                    ZeroMemory(&msg, sizeof(msg));

					while (msg.message != WM_QUIT)
                    {
                        if (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
                        {
                            TranslateMessage(&msg);
                            DispatchMessage(&msg);
                        }
					}
return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static HDC hDC = NULL;
	static PAINTSTRUCT ps = {NULL};
	static int xpos, ypos;

    switch (uMsg)
    {
        case WM_CREATE:
            return 0;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
		case WM_PAINT:
			xpos = GetSystemMetrics(SM_CXSCREEN) / 2;
			ypos = GetSystemMetrics(SM_CYSCREEN) / 2;
			
			hDC = BeginPaint(hWnd, &ps);
		
			SetBkColor(hDC, RGB(0, 0, 0));
			SetTextColor(hDC, RGB(120, 120, 120));
			TextOut(hDC, 0, ypos * 2 - 25, szHello, strlen(szHello));

			EndPaint(hWnd, &ps);
			return 0;
		case WM_SYSCOMMAND:							// Intercept System Commands
		{
			switch (wParam)							// Check System Calls
			{
				case SC_SCREENSAVE:					// Screensaver Trying To Start?
				case SC_MONITORPOWER:				// Monitor Trying To Enter Powersave?
				return 0;							// Prevent From Happening
			}
		}
		case WM_KEYDOWN:
		{
			switch(wParam)
			{
			case VK_ESCAPE:
				DestroyWindow(hWnd);
				PostQuitMessage(0);
			return true;
			}
		}
        case WM_SETCURSOR:
			SetCursor(LoadCursor(NULL, IDC_CROSS));
            return true;
        default:
            return DefWindowProc(hWnd, uMsg, wParam, lParam);
    }
return 0;
}