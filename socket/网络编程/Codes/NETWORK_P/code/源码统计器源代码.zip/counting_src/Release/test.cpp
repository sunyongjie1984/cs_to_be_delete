//result: total: 45; code: 18; comment: 18; blank: 9
/************************************
//test

	homepage: http://xiaogi.diy.163.com

**************************************/
////////////////////*////////////////////////////
#include "stdio.h" //test1 */

#include "windows.h" //test2 /*

main(/**/)
{
	int i=0, j=1; // test /*/
		
	printf("welcome to http://xiaogi.diy.163.com ");
	printf("test /*");  // just for*/ testing

	j++;
	printf("test */ ");

/*
test
*
/

hide it/*/ i++; printf("test "); //test
/*
*
*/		//test
/*
*
*/	printf("/*");	//test
/*
*
*/	printf("//");

	i=i*j/*test
		 test // */;
	i=i+j;/*test
		 test // */
	i=0;
	exit(i);/*test;*/
}
