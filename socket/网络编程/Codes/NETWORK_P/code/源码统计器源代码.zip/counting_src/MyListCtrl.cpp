// MyListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "Counting.h"
#include "MyListCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyListCtrl

CMyListCtrl::CMyListCtrl()
{
}

CMyListCtrl::~CMyListCtrl()
{
}


BEGIN_MESSAGE_MAP(CMyListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CMyListCtrl)
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyListCtrl message handlers

void CMyListCtrl::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	POSITION pos = GetFirstSelectedItemPosition();
	int nSelectedItem = GetNextSelectedItem(pos);

	CString strFileName;
	strFileName = GetItemText(nSelectedItem, 0);
	CString strPathName;
	strPathName = GetItemText(nSelectedItem, 1);

	HINSTANCE hInst = ShellExecute(this->GetSafeHwnd(), _T("open"),
		strPathName+"\\"+strFileName, NULL, NULL, SW_MAXIMIZE);
    if((int)hInst<32) //���ϵͳû����Ӧ�ĳ���򿪸����͵��ļ�������Notepad��
	{
		hInst = ShellExecute(this->GetSafeHwnd(), _T("open"), "notepad.exe",
			strPathName+"\\"+strFileName, NULL, SW_MAXIMIZE);
		if((int)hInst < 32)
		{
			CString str1, str2;
			str1.LoadString(IDS_OPENFAILURE);
			str2.LoadString(IDS_MESSAGE);
			MessageBox(str1, str2);
		}
	}

	CListCtrl::OnLButtonDblClk(nFlags, point);
}


