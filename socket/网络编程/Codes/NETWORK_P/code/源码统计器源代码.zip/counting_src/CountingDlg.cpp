/*************************************************************
*��Դ��ͳ����1.0��
*�������ߣ�κ��
*����Email: xiaogi@sohu.com
*����homepage: http://xiaogi.diy.163.com
*������Ȩ����(C) 2002.11.
**************************************************************/
// CountingDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Counting.h"
#include "CountingDlg.h"
#include "FolderDialog.h"
#include "HyperLink.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#include "CreditStatic.h"

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

private:
	UINT m_nCreditTimer;
	UINT m_nIconTimer;
	CCreditStatic m_static;

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CHyperLink	m_ctrlMyEmail;
	CHyperLink	m_ctrlMyHomepage;
	CStatic	m_ctlCount;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	afx_msg void OnTimer(UINT nIDEvent);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
	m_nIconTimer = NULL;
	m_nCreditTimer = NULL;
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_MYEMAIL, m_ctrlMyEmail);
	DDX_Control(pDX, IDC_MYHOMEPAGE, m_ctrlMyHomepage);
	DDX_Control(pDX, IDC_COUNTICON, m_ctlCount);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

char *pArrCredit = {
"IDB_COUNT^|"
"Դ��ͳ����1.0\t|"
"��Ȩ����(c) 2002.11.\r|"
"���������\t|κ��\r|"
"E-mail: xiaogi@sohu.com\r||"
"��ҳ: http://xiaogi.diy.163.com\r||"
"IDB_COUNT^|"

"�� ��Դ��ͳ������ʹ��˵�� ��\t|"
"���¸������أ�http://xiaogi.diy.163.com\r||"

"����˵����������������������������������\t||"

"�ڹ����У����Ǿ��������ͻ�Ҫ���֮��д��\r|"
"������������������С�ע���кͿհ��еȡ�\r|"
"����������Ϊ����һĿ�ı�д�ģ�����������\r|"
"�����Լ�д��C��C++��VC++�����������ͳ��\r|"
"��������׼ȷ�ؼ����Դ�����еĸ���������\r|"
"�����������ϸĽ��������˶�VB, Java, ASP,\r|"
"JSP��SQL�ȳ����Դ�����ͳ�ƣ�ʹ��������\r|"
"Ӧ�÷�Χ���ӹ㷺��������Ҳ�в�������ͳ��\r|"
"����������������ĿǰΪֹ���ҷ����ҵ����\r|"
"Դ��ͳ����ͳ���ٶ������ģ�������ȽϷ�\r|"
"�ָ���׼ȷ�����ǵ���Դ���е������������\r|"
"��������֮����/*����/*֮����//����//֮��\r|"
"��/*�ȣ���������������������������������\r||"

"ʹ�÷�����������������������������������\t||"

"�ڡ��ļ������ļ����͡���Ͽ�����������Ҫ\r|"
"����ͳ�Ƶ��ļ����ͣ���:*.cpp;*.c;*.h����\r|"
"��չ��֮����;,:�ָ�����Ҳ����ֱ�������� \r|"
"Ҫͳ�Ƶ��ļ�������:a.cpp;b.c;c.h����ͬ��\r|"
"�ģ��ļ���֮��Ҳ��;,:�ָ������������� \r|"
"��ѡ������ȱʡΪ���ṩ�ļ����ļ����ͣ���\r|"
"���ұߵİ�ť����ѡ����Ҫ����ͳ���ļ�����\r|"
"��ѡ�����������Զ���ѡ���ļ�����Ŀ¼����\r|"
"�������ļ��С���Ͽ��У�����������������\r||"

"�ڡ������ļ��С���Ͽ�����������Ҫ����ͳ\r|"
"�Ƶ��ļ����ڵ��ļ��У���:d:\\study������\r|"
"�����������ѡ�������ѡ����ļ��С����\r|"
"���ֶ�������ļ��в����������У���������\r|"
"ͳ�ƿ�ʼ���Զ����롣����ұߵİ�ť����\r|"
"ѡ���ļ��С�����������������������������\r||"

"�����ѡ��ͳ��ʱ�Ƿ�Ҳ��Ҫͳ�����ļ�����\r|"
"������ļ�������������������������������\r||"

"�����ͳ�ơ���ť��ʼ���ٴε���ð�ťֹͣ\r|"
"ͳ�ơ�����������������������������������\r||"

"������Ҫ����ͳ�ƽ�������������桱��ť\r|"
"�������ѡ�����ı��ļ���csv�ļ����ָ�ʽ \r|"
"���档����csv�ļ��ɱ��������е�ͳ������ \r|"
"ʶ�𣬰���΢��Officeϵ�е�Excel.��������\r||"

"�������ȶ���������MS Windowsϵ�в���ϵͳ\r|"
"�ϡ�������������������������������������\r||"

"����������������������������������������\t||"

"������Ϊ����������Դ������ȫ�����������\r|"
"������Ҫ���������Ƶ����ã������뱣������\r|"
"�İ�Ȩ��Ϣ��������ñ����������а�������\r|"
"��Ҫ�����в��ֵĴ����õ��Լ��������У���\r|"
"���������Ÿ�֪�������Ա������кõĽ���\r|"
"��bug ���֣�Ҳ�����Ÿ�֪����������������\r|"
"�ҵ�Email��xiaogi@sohu.com������������ \r|"
"������ҳ:http://xiaogi.diy.163.com���� \r||"

"������������������������xiaogi����������\r|"
"������������������������2002��11�¡�����\r|||"
};

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_ctrlMyEmail.SetURL("mailto:xiaogi@sohu.com");
	m_ctrlMyHomepage.SetURL("http://xiaogi.diy.163.com");


	m_static.SubclassDlgItem(IDC_DISPLAY_HELP,this);
	m_static.SetCredits(pArrCredit,'|');
	m_static.SetColor(BACKGROUND_COLOR, RGB(0,0,255));
	m_static.SetTransparent();
	m_static.StartScrolling();
	m_nCreditTimer = SetTimer(ABOUT_CREDIT_TIMER,5000,NULL);
    ASSERT(m_nCreditTimer != 0);

	m_nIconTimer = SetTimer(ABOUT_ICON_TIMER, 200, NULL);
    ASSERT(m_nIconTimer != 0);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/*****************************************************************
	��̬��ʾAbout�Ի����е�ͼ��
*****************************************************************/

void CAboutDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent != (UINT)m_nIconTimer)
		return;
	static int big_icons[] =
	{ IDI_BIG_ICON1, IDI_BIG_ICON2, IDI_BIG_ICON3, IDI_BIG_ICON4,
	IDI_BIG_ICON5, IDI_BIG_ICON6, IDI_BIG_ICON7};
	
	static long big_index = 0;

	HICON hIcon = (HICON)::LoadImage(AfxGetInstanceHandle(),
		MAKEINTRESOURCE(big_icons[big_index++%7]),
		IMAGE_ICON, 32, 32, LR_DEFAULTCOLOR);//SM_CXICON 
	m_ctlCount.SendMessage(STM_SETICON, (WPARAM)hIcon, 0);
//	CDialog::OnTimer(nIDEvent);
}

/////////////////////////////////////////////////////////////////////////////
// CCountingDlg dialog

CCountingDlg::CCountingDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCountingDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCountingDlg)
	m_strFiles = _T("");
	m_bIncludeSubfolder = TRUE;
	m_strComboExt = _T("");
	m_strComboFolder = _T("");
	m_strSize = _T("");
	m_strCommentLines = _T("");
	m_strBlankLines = _T("");
	m_strCodeLines = _T("");
	m_strTotalLines = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_CountingStatus = STOP;
	m_nTimer = NULL;
}

CCountingDlg::~CCountingDlg()
{
}

void CCountingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCountingDlg)
//	DDX_Control(pDX, IDC_SAVE, m_ctrlSave);
	DDX_Control(pDX, IDC_COUNTINGICON, m_ctrlCountingIcon);
	DDX_Control(pDX, IDC_SIZES, m_ctrlSize);
	DDX_Control(pDX, IDC_RESULT, m_ctlResult);
	DDX_Control(pDX, IDC_COMBO_FOLDER, m_ctlFolder);
	DDX_Control(pDX, IDC_COMBO_EXTENSION, m_ctlExtension);
	DDX_Text(pDX, IDC_FILES, m_strFiles);
	DDX_Check(pDX, IDC_INCLUDE_SUBFOLDER, m_bIncludeSubfolder);
	DDX_CBString(pDX, IDC_COMBO_EXTENSION, m_strComboExt);
	DDX_CBString(pDX, IDC_COMBO_FOLDER, m_strComboFolder);
	DDX_Text(pDX, IDC_SIZES, m_strSize);
	DDX_Text(pDX, IDC_COMMENT, m_strCommentLines);
	DDX_Text(pDX, IDC_BLANK, m_strBlankLines);
	DDX_Text(pDX, IDC_CODE, m_strCodeLines);
	DDX_Text(pDX, IDC_TOTAL, m_strTotalLines);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_COUNT, m_btnCount);
	DDX_Control(pDX, IDC_SAVE, m_btnSave);
	DDX_Control(pDX, IDC_ABOUT, m_btnAbout);
	DDX_Control(pDX, IDC_QUIT, m_btnQuit);
}

BEGIN_MESSAGE_MAP(CCountingDlg, CDialog)
	//{{AFX_MSG_MAP(CCountingDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	ON_BN_CLICKED(IDC_COUNT, OnCount)
	ON_BN_CLICKED(IDC_BROWSE_FOLDER, OnBrowseFolder)
	ON_BN_CLICKED(IDC_BROWSE_EXT, OnBrowseExt)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_QUIT, OnQuit)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	//}}AFX_MSG_MAP
//	ON_NOTIFY_EX( TTN_NEEDTEXT, 0, OnNeedText)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCountingDlg message handlers

BOOL CCountingDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	HICON hIcon = AfxGetApp()->LoadIcon(IDI_SMALLICON);
	SetIcon(hIcon, FALSE);		// Set small icon

	m_structExtention.arrayType.Add("cpp");//1
	m_structExtention.arrayType.Add("c");	//2
	m_structExtention.arrayType.Add("h");	//3
	m_structExtention.arrayType.Add("txt");	//4
	m_structExtention.arrayType.Add("wri");	//5
	m_structExtention.arrayType.Add("tli");	//6
	m_structExtention.arrayType.Add("tlh");	//7
	m_structExtention.arrayType.Add("rc");	//8
	m_structExtention.arrayType.Add("dsw");	//9
	m_structExtention.arrayType.Add("hpj");	//10
	m_structExtention.arrayType.Add("htm");	//11
	m_structExtention.arrayType.Add("html");	//12
	m_structExtention.arrayType.Add("cxx");	//13
	m_structExtention.arrayType.Add("hpp");	//14
	m_structExtention.arrayType.Add("def");	//15
	m_structExtention.arrayType.Add("java");	//16
	m_structExtention.arrayType.Add("frm");	//17
	m_structExtention.arrayType.Add("bas");	//18
	m_structExtention.arrayType.Add("ctl");	//19
	m_structExtention.arrayType.Add("cls");	//20
	m_structExtention.arrayType.Add("asp");	//21
	m_structExtention.arrayType.Add("jsp");	//22
	m_structExtention.arrayType.Add("sql");	//23
	m_structExtention.arrayType.Add("*");	//24

	m_structExtention.nType[0] = TYPE_CPP;
	m_structExtention.nType[1] = TYPE_C;
	m_structExtention.nType[2] = TYPE_H;
	m_structExtention.nType[3] = TYPE_TXT;
	m_structExtention.nType[4] = TYPE_WRI;
	m_structExtention.nType[5] = TYPE_H;
	m_structExtention.nType[6] = TYPE_H;
	m_structExtention.nType[7] = TYPE_RC;
	m_structExtention.nType[8] = TYPE_DSW;
	m_structExtention.nType[9] = TYPE_HPJ;
	m_structExtention.nType[10] = TYPE_HTM;
	m_structExtention.nType[11] = TYPE_HTM;
	m_structExtention.nType[12] = TYPE_CPP;
	m_structExtention.nType[13] = TYPE_H;
	m_structExtention.nType[14] = TYPE_OTHER;
	m_structExtention.nType[15] = TYPE_JAVA;
	m_structExtention.nType[16] = TYPE_VB;
	m_structExtention.nType[17] = TYPE_VB;
	m_structExtention.nType[18] = TYPE_VB;
	m_structExtention.nType[19] = TYPE_VB;
	m_structExtention.nType[20] = TYPE_ASP;
	m_structExtention.nType[21] = TYPE_JSP;
	m_structExtention.nType[22] = TYPE_SQL;
	m_structExtention.nType[23] = TYPE_OTHER;

	for(int i=0; i<TOTAL_TYPE; i++)
		m_nIconIndex[i] = -1;

	//���ð�ťͼ���
	m_btnCount.SetIcon(IDI_COUNT);
	m_btnCount.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, 30);
	m_btnCount.SetRounded(TRUE);
	m_btnCount.SetSound(MAKEINTRESOURCE(IDR_WAVEHOVER), ::GetModuleHandle(NULL));
	m_btnCount.SetBtnCursor(IDC_HAND);

	m_btnSave.SetIcon(IDI_SAVE);
	m_btnSave.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, 30);
	m_btnSave.SetRounded(TRUE);
	m_btnSave.SetSound(MAKEINTRESOURCE(IDR_WAVEHOVER), ::GetModuleHandle(NULL));
	m_btnSave.SetBtnCursor(IDC_HAND);

	m_btnAbout.SetIcon(IDI_ABOUT);
	m_btnAbout.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, 30);
	m_btnAbout.SetRounded(TRUE);
	m_btnAbout.SetSound(MAKEINTRESOURCE(IDR_WAVEHOVER), ::GetModuleHandle(NULL));
	m_btnAbout.SetBtnCursor(IDC_HAND);

	m_btnQuit.SetIcon(IDI_QUIT);
	m_btnQuit.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, 30);
	m_btnQuit.SetRounded(TRUE);
	m_btnQuit.SetSound(MAKEINTRESOURCE(IDR_WAVEHOVER), ::GetModuleHandle(NULL));
	m_btnQuit.SetBtnCursor(IDC_HAND);

	//�ļ���ѡ�������MRU
	m_ctlFolder.SetMRURegKey ( _T("Combobox MRU folder") );
	m_ctlFolder.SetMRUValueFormat ( _T("String #%d") );

	m_ctlFolder.SetAutoRefreshAfterAdd ( TRUE );
	m_ctlFolder.SetAutoSaveAfterAdd ( TRUE );

	m_ctlFolder.LoadMRU();
	m_ctlFolder.RefreshCtrl();

	//����ListCtrl����
	DWORD oldStyle = m_ctlResult.GetExtendedStyle();
	m_ctlResult.SetExtendedStyle(oldStyle |LVS_EX_FULLROWSELECT|LVS_EX_TRACKSELECT|LVS_EX_UNDERLINEHOT|LVS_EX_GRIDLINES);

	CString str;
	str.LoadString(IDS_FILENAME);
	m_ctlResult.InsertColumn(0,  str, LVCFMT_LEFT, 120, -1);
	str.LoadString(IDS_PATHNAME);
	m_ctlResult.InsertColumn(1,  str, LVCFMT_LEFT, 120, -1);
	str.LoadString(IDS_TOTALLINE);
	m_ctlResult.InsertColumn(2,  str, LVCFMT_RIGHT, 70, -1);
	str.LoadString(IDS_CODELINE);
	m_ctlResult.InsertColumn(3,  str, LVCFMT_RIGHT, 70, -1);
	str.LoadString(IDS_COMMENTLINE);
	m_ctlResult.InsertColumn(4,  str, LVCFMT_RIGHT, 70, -1);
	str.LoadString(IDS_BLANKLINE);
	m_ctlResult.InsertColumn(5,  str, LVCFMT_RIGHT, 70, -1);
	str.LoadString(IDS_FILETYPE);
	m_ctlResult.InsertColumn(6,  str, LVCFMT_LEFT, 120, -1);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCountingDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCountingDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCountingDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

/***********************************************************
* ������ESC��ʱ��ȷ���Ƿ��˳�
***********************************************************/
void CCountingDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	CString str1, str2;
	str1.LoadString(IDS_TOQUIT);
	str2.LoadString(IDS_MESSAGE);
	if(MessageBox(str1, str2, MB_YESNO)==IDNO)
	{
		return ;
	}
	CDialog::OnCancel();
}

/***********************************************************
* ��ͳ�Ʊ���Ϊ�ı��ļ���csv�ļ�
***********************************************************/
void CCountingDlg::OnSave() 
{
	// TODO: Add your control notification handler code here
	if(0==m_ctlResult.GetItemCount())
	{
		CString str1, str2;
		str1.LoadString(IDS_UNSTARTED);
		str2.LoadString(IDS_MESSAGE);
		MessageBox(str1, str2);
		return;
	}

	if(m_CountingStatus == COUNTING)
	{
		CString str1, str2;
		str1.LoadString(IDS_WAITING);
		str2.LoadString(IDS_MESSAGE);
		MessageBox(str1, str2);
		return;
	}

	CString str3;
	str3.LoadString(IDS_SAVETYPE);
	CFileDialog dlgFile(
		FALSE, _T("*.txt"), NULL,
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		((LPCTSTR)str3));
	if (dlgFile.DoModal() == IDCANCEL)
		return ;

	CString sPath = dlgFile.GetPathName();
	CString sExt = dlgFile.GetFileExt();
	sExt.MakeLower();

	if(sExt == "txt")
		SaveAsTextFile((LPCTSTR)sPath);
	else if(sExt == "csv")
		SaveAsCSVFile((LPCTSTR)sPath);
	else
	{
		CString str1, str2;
		str1.LoadString(IDS_WRONGTYPE);
		str2.LoadString(IDS_MESSAGE);
		MessageBox(str1, str2);
	}

	CString str1, str2;
	str1.LoadString(IDS_SAVEOVER);
	str2.Format("%s:%s", str1, sPath);
	GetDlgItem(IDC_PATH_COUNTING)->SetWindowText(str2);
}

/*******************************************************
�����ͳ�ơ���ť����ʼͳ��
********************************************************/
void CCountingDlg::OnCount() 
{
	// TODO: Add your control notification handler code here
	if(m_CountingStatus == COUNTING)
	{
		m_CountingStatus = STOP;
		return;
	}
	UpdateData(TRUE);

	if(m_strComboExt.Find(_T("**")) != -1||m_strComboFolder.Find(_T("**")) != -1)
	{
		CString str1, str2;
		str1.LoadString(IDS_INVALIDFILE);
		str2.LoadString(IDS_MESSAGE);
		MessageBox(str1, str2);
		return;
	}

	if(m_strComboExt.IsEmpty())
	{
		CString str1, str2;
		str1.LoadString(IDS_INPUT_FILE);
		str2.LoadString(IDS_MESSAGE);
		MessageBox(str1, str2);
		return;
	}

	if(m_strComboFolder.IsEmpty())
	{
		CString str1, str2;
		str1.LoadString(IDS_COUNTING_PATH);
		str2.LoadString(IDS_MESSAGE);
		MessageBox(str1, str2);
		return;
	}

	if(m_ctlFolder.FindStringExact(-1, m_strComboFolder)==CB_ERR)
	{
		m_ctlFolder.AddToMRU((LPCTSTR)m_strComboFolder);
	}

	m_btnCount.SetIcon(IDI_COUNTSTOP);
	CString str;
	str.LoadString(IDS_STOP);
	m_btnCount.SetWindowText(str);
	
	m_imageList.DeleteImageList();
	m_imageList.Create(16, 16, ILC_MASK|ILC_COLORDDB, 1, 100);
	m_ctlResult.SetImageList(&m_imageList, LVSIL_SMALL);

	m_ctlResult.DeleteAllItems();
	m_nItemCountSet = 1000;
	m_ctlResult.SetItemCount(m_nItemCountSet);

	char strCurrentDirectory[_MAX_PATH];
	GetCurrentDirectory(_MAX_PATH, strCurrentDirectory);
	m_strCurrentDir = strCurrentDirectory; //���浱ǰ·���Ա��߳̽�����ָ�

	SetCurrentDirectory(m_strComboFolder);//set directory to count

	m_nTotalLines = 0;//initialize
	m_nCodeLines = 0;
	m_nCommentLines = 0;
	m_nBlankLines = 0;
	m_nFiles = 0;
	m_nSize = 0;

	m_nTimer = SetTimer(COUNTING_TIMER, 200, NULL);
	m_CountingStatus = COUNTING;

	HICON hIcon = (HICON)::LoadImage(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_BIG_ICON2),
		IMAGE_ICON, 32, 32, LR_DEFAULTCOLOR);//SM_CXICON 
	m_ctrlCountingIcon.SendMessage(STM_SETICON, (WPARAM)hIcon, 0);

	char buf[_MAX_PATH];
	GetCurrentDirectory(_MAX_PATH, buf);
	//��ʼ�߳�
	CWinThread* pThread = AfxBeginThread(CountThread, this);
}

/*******************************************************************
* Extract one extension from strExtension, and assign it to strOneOfExt
* for example: strExtension = "*.cpp;*.c;*.h"
*	then,	1st time: strOneOfExt = "*.cpp", 
*			2nd time: strOneOfExt = "*.c",
*			3rd time: strOneOfExt = "*.h",
*	return: TRUE: extracted successfully
*			FALSE: strExtension is empty. 
*********************************************************************/
BOOL CCountingDlg::ExtractExtension(CString & strOneOfExt, CString & strExtension)
{
	strExtension.TrimLeft();

	if(strExtension.IsEmpty())
		return FALSE;

	int nLength = strExtension.GetLength();

	int nFirst = strExtension.FindOneOf(";,:");
	if(nFirst == -1) //there may be only one extension in strExtsion
		nFirst = nLength;
	strOneOfExt = strExtension.Left(nFirst);

	if(nFirst == nLength)
		strExtension.Empty();
	else
		strExtension = strExtension.Right(nLength-1-nFirst);//rest

	strOneOfExt.TrimLeft();//trim whitespace
	strOneOfExt.TrimRight();

	return TRUE;
}

/*******************************************************************
* find file type according to its extension
* for example: strExtension = "xiaogi.c"
*	return: TYPE_C
*********************************************************************/
int CCountingDlg::FindFileType(CString strFile)
{
	int nLast = strFile.ReverseFind('.');
	CString extNoDot = strFile.Right(strFile.GetLength()-nLast-1);

	for(int i=0; i<m_structExtention.arrayType.GetSize(); i++)
	{
		if(extNoDot.CompareNoCase(m_structExtention.arrayType[i])==0)
			return m_structExtention.nType[i];
	}

	return -1;
}

/*********************************************************
	ѡ����ͳ�Ƶ��ļ���
*********************************************************/
void CCountingDlg::OnBrowseFolder() 
{
	// TODO: Add your control notification handler code here
	CFolderDialog dlg("", BIF_RETURNONLYFSDIRS, this);
	if(dlg.DoModal()==IDOK)
	{
		CString strPath = dlg.GetPathName();
		m_ctlFolder.SetWindowText((LPCTSTR)strPath);
	}
}

/*********************************************************
	ѡ����ͳ�Ƶ��ļ�
*********************************************************/
void CCountingDlg::OnBrowseExt() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlgFile(TRUE, "", NULL, 
		OFN_ALLOWMULTISELECT|OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_HIDEREADONLY,
		NULL, this);

	dlgFile.m_ofn.lStructSize = sizeof(OPENFILENAME);
//	dlgFile.m_ofn.hwndOwner = GetSafeHwnd();
	static char BASED_CODE szFilter[]
		= "C++ Files (.c;.cpp;.cxx;.tli;.h;.tlh;.rc)\0*.c;*.cpp;*.h;*.rc\0\
Web Files(.htm;.html;.htx;.asp;.alx;.stm;.shtml)\0*.htm;*.html\0\
C++ Source Files(.c;.cpp;.cxx;.tli)\0*.c; *.cpp\0\
C++ Include Files(.h;.hpp;.hxx;.inl;.tlh)\0*.h\0\
Resource Files(.rc;.rct;.res)\0*.rc\0\
Java Source Files(.java)\0*.java\0\
ASP Source Files(.asp)\0*.asp\0\
JSP Source Files(.jsp)\0*.jsp\0\
PL*sql Files(.sql)\0*.sql\0\
VB Source Files(.frm;.bas;.ctl;.cls)\0*.frm;*.bas;*.ctl;*.cls\0\
Text File(.txt)\0*.txt\0\
All Files (*.*)\0*.*\0\0";

	dlgFile.m_ofn.lpstrFilter = szFilter;
	char FileName[640];
	memset(FileName, 0, sizeof(FileName));
	dlgFile.m_ofn.lpstrFile = FileName;
	dlgFile.m_ofn.nMaxFile = 640;

	CString strFiles = "";
	CString strPath = "";
	if(dlgFile.DoModal()==IDOK)
	{
		CString sFile = dlgFile.GetFileName();
		CString sPath = dlgFile.GetPathName();
		if(sFile.IsEmpty())
		{
			strPath = sPath;
		}
		else
		{
	 		strPath = GetPurePath(sPath);
		}

		POSITION pos = dlgFile.GetStartPosition();
		while(pos!=NULL)
		{
			CString strPathName = dlgFile.GetNextPathName(pos);
			int nFind = strPathName.ReverseFind('\\');
			strFiles += strPathName.Right(strPathName.GetLength()-nFind-1);
			strFiles += ";";
		}
		strFiles = strFiles.Left(strFiles.GetLength()-1);
		m_ctlExtension.SetWindowText((LPCTSTR)strFiles);
		m_ctlFolder.SetWindowText((LPCTSTR)strPath);
	}
}

/*********************************************************
	ͳ�����߳�
*********************************************************/
UINT CCountingDlg::CountThread(LPVOID lpvData)
{
	CCountingDlg* pThis = (CCountingDlg*)lpvData;
	CStringList listPaths;
	CString  strPath;
	CString  strFolder;
	int nTypeCount=0; //added by xiaogi 11.18

	CFileFind finder;
	BOOL bWorking;

	if(pThis->m_strComboFolder[pThis->m_strComboFolder.GetLength()-1]=='\\')
		strPath = pThis->m_strComboFolder + "*.*";
	else
		strPath = pThis->m_strComboFolder + "\\*.*";

	do{
		bWorking = finder.FindFile(strPath);
		while(bWorking  && pThis->m_CountingStatus==COUNTING)
		{
			bWorking = finder.FindNextFile();
			CString strFilePath = finder.GetFilePath();
			if(finder.IsDots())
				continue;

			if(finder.IsDirectory())
			{
				if(pThis->m_bIncludeSubfolder)
					listPaths.AddHead(strFilePath);
				continue;
			}
			else
			{
				if(pThis->IsSearchingFor(strFilePath))
				{
					CString str1, str2;
					str1.LoadString(IDS_COUNTINGFILE);
					str2.Format("%s:%s", str1, strFilePath);
					if(str2.GetLength()>75)
						str2 = str2.Left(75);
					pThis->GetDlgItem(IDC_PATH_COUNTING)->SetWindowText(str2);

					int nType;
					nType = pThis->FindFileType(strFilePath);
					if(nType == -1)
						nType = TYPE_OTHER;

					int nLines=0;
					int nCodeLines=0;
					int nCommentLines=0;
					int nBlankLines=0;
					int nLength=0;

					switch(nType)
					{
					case TYPE_C:
					case TYPE_CPP:
					case TYPE_H:
					case TYPE_JSP:
					case TYPE_JAVA:
						nLines = pThis->GetCppFileLines((LPCTSTR)strFilePath, &nLength, &nCommentLines, &nBlankLines);
						break;
					case TYPE_VB:
					case TYPE_ASP:
						nLines = pThis->GetVBFileLines((LPCTSTR)strFilePath, &nLength, &nCommentLines, &nBlankLines);
						break;
					case TYPE_SQL:
						nLines = pThis->GetSqlFileLines((LPCTSTR)strFilePath, &nLength, &nCommentLines, &nBlankLines);
						break;
					default:
						nLines = pThis->GetTxtFileLines((LPCTSTR)strFilePath, &nLength, &nCommentLines, &nBlankLines);
						break;
					}

					nCodeLines = nLines - nCommentLines - nBlankLines;

					int pos=strFilePath.ReverseFind('\\');

					if(pThis->m_nFiles > pThis->m_nItemCountSet)
						pThis->m_nItemCountSet += 1000;
					pThis->m_ctlResult.SetItemCount(pThis->m_nItemCountSet);

					SHFILEINFO sfi;
					if (::SHGetFileInfo (strFilePath, FILE_ATTRIBUTE_NORMAL, &sfi, sizeof(SHFILEINFO),SHGFI_USEFILEATTRIBUTES | SHGFI_DISPLAYNAME | SHGFI_TYPENAME |SHGFI_ICON|SHGFI_SMALLICON ))
					{	
						//added by xiaogi 11.18
						if(nType!=TYPE_OTHER && pThis->m_nIconIndex[nType]==-1)
						{
							pThis->m_imageList.Add(sfi.hIcon);
							pThis->m_nIconIndex[nType] = nTypeCount;
							nTypeCount++;
						}
						else if(nType==TYPE_OTHER)
						{
							pThis->m_imageList.Add(sfi.hIcon);
							pThis->m_nIconIndex[nType] = nTypeCount;
							nTypeCount++;
						}
						pThis->m_ctlResult.InsertItem(pThis->m_nFiles,sfi.szDisplayName,pThis->m_nIconIndex[nType]);

						CString str;
						//deleted by xiaogi 11.18
//						pThis->m_imageList.Add(sfi.hIcon);
//						pThis->m_ctlResult.InsertItem(pThis->m_nFiles,sfi.szDisplayName,pThis->m_nFiles);

     					pThis->m_ctlResult.SetItemText(pThis->m_nFiles, 1, strFilePath.Mid(0,pos));
						str.Format("%d", nLines);
    					pThis->m_ctlResult.SetItemText(pThis->m_nFiles, 2, str);
						str.Format("%d", nCodeLines);
    					pThis->m_ctlResult.SetItemText(pThis->m_nFiles, 3, str);
						str.Format("%d", nCommentLines);
    					pThis->m_ctlResult.SetItemText(pThis->m_nFiles, 4, str);
						str.Format("%d", nBlankLines);
    					pThis->m_ctlResult.SetItemText(pThis->m_nFiles, 5, str);
						pThis->m_ctlResult.SetItemText(pThis->m_nFiles, 6, sfi.szTypeName);
					}

					pThis->m_ctlResult.Update(pThis->m_nFiles);

					pThis->m_nFiles++;
					pThis->m_nSize += nLength;
					pThis->m_nTotalLines += nLines;
					pThis->m_nCodeLines += nCodeLines;
					pThis->m_nCommentLines += nCommentLines;
					pThis->m_nBlankLines += nBlankLines;

					pThis->UpdateResult();
				}
			}
		}
		if(listPaths.IsEmpty())
			break;

		if(pThis->m_nFiles>5000)
		{
			CString str1;
			str1.LoadString(IDS_TOOMUCH);
			AfxMessageBox(str1);
			break;
		}
		strFolder = listPaths.RemoveHead();
		strPath = strFolder + "\\*.*";

		CString str1, str2;
		str1.LoadString(IDS_COUNTINGFILE);
		str2.Format("%s:%s", str1, strFolder);
		if(str2.GetLength()>75)
			str2 = str2.Left(75);
		pThis->GetDlgItem(IDC_PATH_COUNTING)->SetWindowText(str2);

		finder.Close();
	}while(pThis->m_CountingStatus==COUNTING);

	if(pThis->m_nTimer!=NULL)
	{
		pThis->KillTimer(pThis->m_nTimer);
		pThis->m_nTimer = NULL;
	}

	CString str1;
	if(pThis->m_CountingStatus==STOP)
		str1.LoadString(IDS_ABORT); //�û�ǿ����ֹ
	else
		str1.LoadString(IDS_COUNTINGSTOP);
	pThis->GetDlgItem(IDC_PATH_COUNTING)->SetWindowText(str1);

	pThis->m_CountingStatus = STOP;

	pThis->m_btnCount.SetIcon(IDI_COUNT);
	CString str;
	str.LoadString(IDS_COUNT);
	pThis->m_btnCount.SetWindowText(str);

	HICON hIcon = (HICON)::LoadImage(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_BIG_ICON1),
		IMAGE_ICON, 32, 32, LR_DEFAULTCOLOR);//SM_CXICON 
	pThis->m_ctrlCountingIcon.SendMessage(STM_SETICON, (WPARAM)hIcon, 0);

	return 0;
}

////////////////////////////////////////////////////////////
//modify a path with file name to without file name
// such as: 
//   modify:  d:\\temp\\countingdlg.cpp
//        to:   d:\\temp
//
////////////////////////////////////////////////////////////
CString CCountingDlg::GetPurePath(CString strPath)
{
	int nLast = strPath.ReverseFind('\\');
	return strPath.Left(nLast);
}

/******************************************************************
*  ��һ�ַ���strText��׷�ӿո�ʹ�䳤�ȴﵽnum
*����bAtEnd : TRUE��ʾ���ַ�������׷�ӿո�
*			  FALSE��ʾ���ַ���ǰ��׷�ӿո�
*    ��strText�ĳ��ȱ����ʹ���num������������ַ���Ϊ...
*******************************************************************/
CString CCountingDlg::TextAppendSpace(CString strText, int num, BOOL bAtEnd)
{
	CString str;
	if(strText.GetLength()>=num)
	{
		str = strText.Left(num-3);
		str += "...";
	}
	else
	{
		str = strText;
		for(int i=strText.GetLength(); i<num; i++)
		{
			if(bAtEnd)
				str +=" ";
			else
				str = " "+str;
		}
	}

	return str;
}
/*****************************************************************
	strFileName�Ƿ�Ϊ����Ҫͳ�Ƶ��ļ�����
*****************************************************************/
BOOL CCountingDlg::IsSearchingFor(CString strFileName)
{
	CString strExts = m_strComboExt;
	strExts.MakeLower();
	strFileName.MakeLower();

	CString strOneOfExts; // get one extension in strExts
	while(ExtractExtension(strOneOfExts, strExts))
	{
		if(CompareMarkString(strOneOfExts, strFileName))
			return TRUE;
	}

	return FALSE;
}

/*****************************************************************
	�Ƚ�strFile�Ƿ�ΪinputFile���ļ�����
*****************************************************************/
BOOL CCountingDlg::CompareMarkString(CString inputFile, CString strFile)
{
	strFile = strFile.Right(strFile.GetLength()-strFile.ReverseFind('\\')-1);
	int nLength1 = strFile.GetLength(); 
	int nLength2 = inputFile.GetLength();

	for(int i=0, j=0; i<nLength1&&j<nLength2; i++, j++)
	{
		if(inputFile[j]=='*')
		{
			j++;
			if(j==nLength2)
				return TRUE;
			while(j<nLength2&&inputFile[j]=='?')
			{
				i++;
				j++;
			}
			if(j>=nLength2)
				return TRUE;

			while(i<nLength1&&inputFile[j]!=strFile[i])
				i++;
			if(i>=nLength1)
				return FALSE;

			continue;
		}
		if(inputFile[j]=='?')
		{
			continue;
		}
		if(inputFile[j]==strFile[i])
		{
			continue;
		}
		else
			return FALSE;
	}

	if(i==nLength1&&j==nLength2)
		return TRUE;
	else
		return FALSE;
}

/*****************************************************************
	ͳ�ƿ�ʼ��̬��ʾͼ�꣬��ʾͳ�ƽ�����
*****************************************************************/

void CCountingDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent != (UINT)m_nTimer)
		return;

	static int icons[] =
	{ IDI_BIG_ICON1, IDI_BIG_ICON2, IDI_BIG_ICON3, IDI_BIG_ICON4, IDI_BIG_ICON5, IDI_BIG_ICON6, 
	IDI_BIG_ICON7};
	
	static long index = 0;

	HICON hIcon = AfxGetApp()->LoadIcon(icons[index++%7]);
	m_ctrlCountingIcon.SendMessage(STM_SETICON, (WPARAM)hIcon, 0);
	DestroyIcon(hIcon); //�ͷ�icon
}


/*****************************************************************
	ȷ���Ƿ��˳�
*****************************************************************/
void CCountingDlg::OnQuit() 
{
	// TODO: Add your control notification handler code here
	CString str1, str2;
	str1.LoadString(IDS_TOQUIT);
	str2.LoadString(IDS_MESSAGE);
	if(MessageBox(str1, str2, MB_YESNO)==IDNO)
	{
		return ;
	}
	CDialog::OnCancel();
}

/*********************************************************
	ͳ��c++�ļ�
*********************************************************/
int CCountingDlg::GetCppFileLines(LPCTSTR strFileName, int* pnLength, int* pnCommentLines, int* pnBlankLines)
{
	//there are two methods to count lines in files, by CStdioFile or CFile
	*pnLength = 0;
	*pnCommentLines = 0;
	*pnBlankLines = 0;

	CStdioFile file;
	if(file.Open(strFileName, CFile::modeRead)==FALSE)
		return 0;

	int nLines = 0;
	int nCommentLines = 0;
	int nBlankLines = 0;

	BOOL bCommentSet = FALSE; //ע����ͳ�Ʊ�ʶ ��"/*"ʱTRUE, "*/"ʱFALSE

	int nLength = file.GetLength();
	*pnLength = nLength;

	CString bufRead;

	int nLineCommentBegin = 0;
	while(file.ReadString(bufRead)!=FALSE)
	{
		nLines++;

		bufRead.TrimLeft(); //�Ƚ��ļ�ͷ�Ŀո���Ʊ���ȥ��

		if(bufRead.GetLength()==0) //Ϊ�հ���
		{
			nBlankLines++;
			continue;
		}

		if(bufRead.Find("//")==0 && !bCommentSet)
		{
			nCommentLines++;
			continue;
		}

		int nStartComment = bufRead.Find("/*");
		if(nStartComment == 0  && !bCommentSet ) // "/*" is the first two chars
		{
			bCommentSet = TRUE;
//			nLineCommentBegin = nLines;
		}
		else if(nStartComment != -1 &&!bCommentSet) // "/*" is not the first two chars though found. so it's a code line
		{
			bCommentSet = TRUE;
			nLineCommentBegin = nLines;
			nCommentLines --;
			if(bufRead.Find("\"")!=-1) //��ֹ/*������"֮�䣬�� "...../*....."������/*����ע�ͷ�
			{
				CString strTemp = bufRead.Left(nStartComment);
				int nCountQuota=0;
				int i=1;
				if(strTemp[0]=='\"')nCountQuota++;
				while((strTemp[i]=='\"'&&strTemp[i-1]!='\\')&&i<strTemp.GetLength() )
				{
					nCountQuota++;
					i++;
				}
				if((nCountQuota/2)*2 != nCountQuota)//nCountQuotaΪ��������ԭbCoommentSet
				{
					bCommentSet = FALSE;
					nCommentLines ++;
				}
			}
		}

		bufRead.TrimRight();

		int nEndComment = bufRead.Find("*/");
		if(bufRead.GetLength()>=2 && (nEndComment == (bufRead.GetLength()-2)) && bCommentSet)
		{
			bCommentSet = FALSE;
			nCommentLines ++;  
		}
		else if(nEndComment != -1 && bCommentSet)
		{
			bCommentSet = FALSE;
			if(nLineCommentBegin == nLines) // /* */ on the same line
				nCommentLines++;
			bufRead = bufRead.Right(bufRead.GetLength()-nEndComment-2);
			if(bufRead.Find("//")!=-1) //it is very strange!  such as  "code */ (code or blank) // code"
			{
				bufRead.TrimLeft();
				if(bufRead.Find("//")==0)
					nCommentLines++;
			}
			else if(nLineCommentBegin != nLines && bufRead.GetLength()==0)
				nCommentLines++;
		}

		if(bCommentSet)
			nCommentLines++;
	}

	*pnCommentLines = nCommentLines;
	*pnBlankLines = nBlankLines;

	file.Close();

	return nLines;

	//the following is not so good. sometimes it may obtain a wrong result

/*	CFile file;

	file.Open(strFileName, CFile::modeRead);

	int nLines = 0;
	int nCodeLines = 0;
	int nCommentLines = 0;
	int nBlankLines = 0;

	BOOL bLastSplash = FALSE;
	BOOL bDoubleSplash = FALSE;
	BOOL bLastStar = FALSE;
	BOOL bCommentCount = FALSE;
	BOOL bBlankCount = TRUE;

	int nLength = file.GetLength();
	m_nSize += nLength;
	*pnLength = nLength;

	char buf[255];
	int nRead = 0;
	while(nLength>0)
	{
		nRead = file.Read(buf, 250);
		
		if(buf[0] == '*' && bLastSplash)
		{
			bLastSplash = FALSE;
			bCommentCount = TRUE;
		}

		if(buf[0] == '/' && bLastSplash && !bCommentCount && bBlankCount && !bDoubleSplash)
		{
			bLastSplash = FALSE;
			bDoubleSplash = TRUE;
		}

		if(buf[0] == '/' && bLastStar)
		{
			bLastStar = FALSE;
			bCommentCount = FALSE;
			nCommentLines++;
		}

		for(int i=0; i<nRead; i++)
		{
			if(buf[i] == '/')
			{
				if(i<nRead-1 && buf[i+1]=='*' && !bDoubleSplash )
					bCommentCount = TRUE;
				if(i<nRead-1 && buf[i+1]=='/' && !bCommentCount && bBlankCount  && !bDoubleSplash)
					bDoubleSplash = TRUE;
				if(i==nRead-1)
					bLastSplash=TRUE;
			}


			if(buf[i] == '*')
			{
				if(i<nRead-1 && buf[i+1]=='/')
				{
					bCommentCount = FALSE;
					nCommentLines++;
				}
				if(i==nRead-1)
					bLastStar=TRUE;
			}
			
			if( buf[i]!=' ' && buf[i]!='\t' && buf[i]!='\r' && buf[i]!='\n')//&& bBlankCount)
				bBlankCount = FALSE;

			if(buf[i]=='\n')
			{
				nLines++;
				if(bBlankCount)nBlankLines++;
				if(bBlankCount && bCommentCount)nCommentLines--;
				if(bDoubleSplash)
				{
					nCommentLines++;
					bDoubleSplash = FALSE;
				}

				bBlankCount = TRUE;
				
				if(bCommentCount) nCommentLines++;
			}
		}
		nLength -= nRead;
	}

	if(buf[nRead-1]!='\n')
		nLines++;
	if(bDoubleSplash)
		nCommentLines++;

	*pnCommentLines = nCommentLines;
	*pnBlankLines = nBlankLines;

	file.Close();

	return nLines;
*/
}

/*****************************************************************
	ͳ��SQL�ļ�������

*****************************************************************/

int CCountingDlg::GetSqlFileLines(LPCTSTR strFileName, int *pnLength, int *pnCommentLines, int *pnBlankLines)
{
	*pnLength = 0;
	*pnCommentLines = 0;
	*pnBlankLines = 0;

	CStdioFile file;
	if(file.Open(strFileName, CFile::modeRead)==FALSE)
		return 0;

	int nLines = 0;
	int nCommentLines = 0;
	int nBlankLines = 0;

	BOOL bCommentSet = FALSE;

	int nLength = file.GetLength();
	m_nSize += nLength;
	*pnLength = nLength;

	CString bufRead;

	while(file.ReadString(bufRead)!=FALSE)
	{
		nLines++;

		bufRead.TrimLeft();

		if(bufRead.GetLength()==0)
		{
			nBlankLines++;
			continue;
		}

		if(bufRead.Find("--")==0 && !bCommentSet)
		{
			nCommentLines++;
			continue;
		}

		int nStartComment = bufRead.Find("/*");
		if(nStartComment == 0  && !bCommentSet ) // "/*" is the first two chars
		{
			bCommentSet = TRUE;
		}
		else if(nStartComment != -1 &&!bCommentSet) // "/*" is not the first two chars though found. so it's a code line
		{
			bCommentSet = TRUE;
			nCommentLines --;  
		}

		bufRead.TrimRight();

		int nEndComment = bufRead.Find("*/");
		if(bufRead.GetLength()>=2 && (nEndComment == bufRead.GetLength()-2))
		{
			bCommentSet = FALSE;
			nCommentLines ++;  
		}
		else if(nEndComment != -1)
		{
			bCommentSet = FALSE;
			if(bufRead.Find("--")!=-1) //it is very strange!  such as  " */   -- "
			{
				CString sTemp = bufRead.Right(bufRead.GetLength()-nEndComment-3);
				sTemp.TrimLeft();
				if(sTemp.Find("--")==0)
					nCommentLines++;
			}
		}

		if(bCommentSet)
			nCommentLines++;
	}

	*pnCommentLines = nCommentLines;
	*pnBlankLines = nBlankLines;

	file.Close();

	return nLines;
}

int CCountingDlg::GetVBFileLines(LPCTSTR strFileName, int *pnLength, int *pnCommentLines, int *pnBlankLines)
{
	*pnLength = 0;
	*pnCommentLines = 0;
	*pnBlankLines = 0;

	CStdioFile file;
	if(file.Open(strFileName, CFile::modeRead)==FALSE)
		return 0;

	int nLines = 0;
	int nCommentLines = 0;
	int nBlankLines = 0;

	int nLength = file.GetLength();
	m_nSize += nLength;
	*pnLength = nLength;

	CString bufRead;

	while(file.ReadString(bufRead)!=FALSE)
	{
		nLines++;

		bufRead.TrimLeft();

		if(bufRead.GetLength()==0)
		{
			nBlankLines++;
			continue;
		}

		if(bufRead.Find("'")==0)
		{
			nCommentLines++;
			continue;
		}
	}

	*pnCommentLines = nCommentLines;
	*pnBlankLines = nBlankLines;

	file.Close();

	return nLines;
}

int CCountingDlg::GetTxtFileLines(LPCTSTR strFileName, int *pnLength, int *pnCommentLines, int *pnBlankLines)
{
	*pnLength = 0;
	*pnCommentLines = 0;
	*pnBlankLines = 0;

	CStdioFile file;
	if(file.Open(strFileName, CFile::modeRead)==FALSE)
		return 0;

	int nLines = 0;
	int nCommentLines = 0;
	int nBlankLines = 0;

	int nLength = file.GetLength();
	m_nSize += nLength;
	*pnLength = nLength;

	CString bufRead;

	while(file.ReadString(bufRead)!=FALSE)
	{
		nLines++;

		bufRead.TrimLeft();

		if(bufRead.GetLength()==0)
		{
			nBlankLines++;
			continue;
		}
	}

	*pnCommentLines = nCommentLines;
	*pnBlankLines = nBlankLines;

	file.Close();

	return nLines;
}


/*********************************************************************
*  Save as Text file, in which every column has its own width
*	input: filename: the save file name
*	output: void		
**********************************************************************/
void CCountingDlg::SaveAsTextFile(LPCTSTR filename)
{
	CFile file(filename, CFile::modeCreate|CFile::modeWrite);
	CString strText;

#define COLUMN1_WIDTH	20
#define COLUMN2_WIDTH	30
#define COLUMN3_WIDTH	15
#define COLUMN4_WIDTH	15
#define COLUMN5_WIDTH	15
#define COLUMN6_WIDTH	15
#define COLUMN7_WIDTH	30

	strText.LoadString(IDS_FILENAME);
	strText = TextAppendSpace(strText, COLUMN1_WIDTH, TRUE);
	file.Write(strText, strText.GetLength());//write file name
	strText.LoadString(IDS_PATHNAME);
	strText = TextAppendSpace(strText, COLUMN2_WIDTH, TRUE);
	file.Write(strText, strText.GetLength());//write path name
	strText.LoadString(IDS_TOTALLINE);
	strText = TextAppendSpace(strText, COLUMN3_WIDTH, FALSE);
	file.Write(strText, strText.GetLength());
	strText.LoadString(IDS_CODELINE);
	strText = TextAppendSpace(strText, COLUMN4_WIDTH, FALSE);
	file.Write(strText, strText.GetLength());
	strText.LoadString(IDS_COMMENTLINE);
	strText = TextAppendSpace(strText, COLUMN5_WIDTH, FALSE);
	file.Write(strText, strText.GetLength());
	strText.LoadString(IDS_BLANKLINE);
	strText = TextAppendSpace(strText, COLUMN6_WIDTH, FALSE);
	file.Write(strText, strText.GetLength());
	file.Write("  ", 2);
	strText.LoadString(IDS_FILETYPE);
	strText = TextAppendSpace(strText, COLUMN7_WIDTH, TRUE);
	file.Write(strText, strText.GetLength());
	file.Write("\r\n", 2);

	for(int i=0; i<m_ctlResult.GetItemCount(); i++)
	{
		strText = m_ctlResult.GetItemText(i, 0);
		strText = TextAppendSpace(strText, COLUMN1_WIDTH, TRUE);
		file.Write((LPCTSTR)strText, COLUMN1_WIDTH);//write file name

		strText = m_ctlResult.GetItemText(i, 1);
		strText = TextAppendSpace(strText, COLUMN2_WIDTH, TRUE);
		file.Write((LPCTSTR)strText, COLUMN2_WIDTH);

		strText = m_ctlResult.GetItemText(i, 2);
		strText = TextAppendSpace(strText, COLUMN3_WIDTH, FALSE);
		file.Write((LPCTSTR)strText, COLUMN3_WIDTH);

		strText = m_ctlResult.GetItemText(i, 3);
		strText = TextAppendSpace(strText, COLUMN4_WIDTH, FALSE);
		file.Write((LPCTSTR)strText, COLUMN4_WIDTH);

		strText = m_ctlResult.GetItemText(i, 4);
		strText = TextAppendSpace(strText, COLUMN5_WIDTH, FALSE);
		file.Write((LPCTSTR)strText, COLUMN5_WIDTH);

		strText = m_ctlResult.GetItemText(i, 5);
		strText = TextAppendSpace(strText, COLUMN6_WIDTH, FALSE);
		file.Write((LPCTSTR)strText, COLUMN6_WIDTH);

		file.Write("  ", 2);

		strText = m_ctlResult.GetItemText(i, 6);
		strText = TextAppendSpace(strText, COLUMN7_WIDTH, TRUE);
		file.Write((LPCTSTR)strText, COLUMN7_WIDTH);

		file.Write("\r\n", 2);
	}

	file.Write("\r\n", 2);
	strText.LoadString(IDS_TOTAL);
	file.Write(strText, strText.GetLength());
	file.Write("\r\n", 2);

	CString str1, str2;
	str1.LoadString(IDS_TOTALFILES);
	str2.Format("%s: %d", str1, m_nFiles);
	file.Write(str2, str2.GetLength());
	file.Write("\r\n", 2);

	//show the total size
	CString strUnit = "";
	float fSize = (float)m_nSize;
	if(fSize>1024)
	{
		fSize /= 1024.;
		strUnit = "KB";
		if(fSize>1024)
		{
			fSize /= 1024.;
			strUnit = "MB";
		}
	}

	str1.LoadString(IDS_TOTALSIZE);
	str2.Format("%s: %2.2f%s", str1, fSize, strUnit);
	file.Write(str2, str2.GetLength());
	file.Write("\r\n", 2);

	str1.LoadString(IDS_TOTALLINE);
	str2.Format("%s: %d (100%%)", str1, m_nTotalLines);
	file.Write(str2, str2.GetLength());
	file.Write("\r\n", 2);

	str1.LoadString(IDS_CODELINE);
	str2.Format("%s: %d (%.1f%%)", str1, m_nCodeLines, 100.*m_nCodeLines/m_nTotalLines);
	file.Write(str2, str2.GetLength());
	file.Write("\r\n", 2);

	str1.LoadString(IDS_COMMENTLINE);
	str2.Format("%s: %d (%.1f%%)", str1, m_nCommentLines, 100.*m_nCommentLines/m_nTotalLines);
	file.Write(str2, str2.GetLength());
	file.Write("\r\n", 2);

	str1.LoadString(IDS_BLANKLINE);
	str2.Format("%s: %d (%2.1f%%)", str1, m_nBlankLines, 100.*m_nBlankLines/m_nTotalLines);
	file.Write(str2, str2.GetLength());
	file.Write("\r\n", 2);

	str1.LoadString(IDS_SAVEOVER);
	GetDlgItem(IDC_PATH_COUNTING)->SetWindowText(str1);
}

/*********************************************************************
*  Save as csv file which can be analysed by Excel conveniently
*	input: filename: the save file name
*	output: void		
**********************************************************************/
void CCountingDlg::SaveAsCSVFile(LPCTSTR filename)
{
	CStdioFile file(filename, CFile::modeCreate|CFile::modeWrite);
	CString strText;

	CString str1, str2, str3, str4, str5, str6, str7;
	str1.LoadString(IDS_FILENAME);
	str2.LoadString(IDS_PATHNAME);
	str3.LoadString(IDS_TOTALLINE);
	str4.LoadString(IDS_CODELINE);
	str5.LoadString(IDS_COMMENTLINE);
	str6.LoadString(IDS_BLANKLINE);
	str7.LoadString(IDS_FILETYPE);
	strText.Format("%s,%s,%s,%s,%s,%s,%s\n", str1, str2, str3, str4, str5, str6, str7);
	file.WriteString(strText);

	for(int i=0; i<m_ctlResult.GetItemCount(); i++)
	{
		strText.Format("%s,%s,%s,%s,%s,%s,%s\n", 
			m_ctlResult.GetItemText(i, 0), m_ctlResult.GetItemText(i, 1),
			m_ctlResult.GetItemText(i, 2), m_ctlResult.GetItemText(i, 3),
			m_ctlResult.GetItemText(i, 4), m_ctlResult.GetItemText(i, 5),
			m_ctlResult.GetItemText(i, 6));

		file.WriteString(strText);
	}

	file.Write("\n", 1);
	str1.LoadString(IDS_TOTAL);
	file.Write(str1, str1.GetLength());
	file.Write("\n", 1);

	str1.LoadString(IDS_TOTALFILES);
	str2.Format("%s,%d", str1, m_nFiles);
	file.Write(str2, str2.GetLength());
	file.Write("\n", 1);

	//show the total size
	CString strUnit = "";
	float fSize = (float)m_nSize;
	if(fSize>1024)
	{
		fSize /= 1024.;
		strUnit = "KB";
		if(fSize>1024)
		{
			fSize /= 1024.;
			strUnit = "MB";
		}
	}

	str1.LoadString(IDS_TOTALSIZE);
	str2.Format("%s,%2.2f%s", str1, fSize, strUnit);
	file.Write(str2, str2.GetLength());
	file.Write("\n", 1);

	str1.LoadString(IDS_TOTALLINE);
	str2.Format("%s,%d (100%%)", str1, m_nTotalLines);
	file.Write(str2, str2.GetLength());
	file.Write("\n", 1);

	str1.LoadString(IDS_CODELINE);
	str2.Format("%s,%d (%2.1f%%)", str1, m_nCodeLines, 100.*m_nCodeLines/m_nTotalLines);
	file.Write(str2, str2.GetLength());
	file.Write("\n", 1);

	str1.LoadString(IDS_COMMENTLINE);
	str2.Format("%s,%d (%2.1f%%)", str1, m_nCommentLines, 100.*m_nCommentLines/m_nTotalLines);
	file.Write(str2, str2.GetLength());
	file.Write("\n", 1);

	str1.LoadString(IDS_BLANKLINE);
	str2.Format("%s,%d (%2.1f%%)", str1, m_nBlankLines, 100.*m_nBlankLines/m_nTotalLines);
	file.Write(str2, str2.GetLength());
	file.Write("\n", 1);

	str1.LoadString(IDS_SAVEOVER);
	GetDlgItem(IDC_PATH_COUNTING)->SetWindowText(str1);
}

/*********************************************************************
*  Show the About dialogbox
**********************************************************************/
void CCountingDlg::OnAbout() 
{
	// TODO: Add your control notification handler code here
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

/*********************************************************************
*  Update counting result frequently
*	the result including: total files, total size, 
*			total lines, code lines, comment lines, blank lines
**********************************************************************/
void CCountingDlg::UpdateResult()
{
	char sTemp[64]=" ";

	//show the number of files
	sprintf(sTemp, "%d", m_nFiles);
	GetDlgItem(IDC_FILES)->SetWindowText(sTemp);

	//show the total size
	CString strUnit = "";
	float fSize = (float)m_nSize;
	if(fSize>1024)
	{
		fSize /= 1024;
		strUnit = "KB";
		if(fSize>1024)
		{
			fSize /= 1024;
			strUnit = "MB";
		}
	}
	sprintf(sTemp, "%.2f%s", fSize, strUnit);
	GetDlgItem(IDC_SIZES)->SetWindowText(sTemp);

	//show total lines
	sprintf(sTemp, "%d", m_nTotalLines);
	GetDlgItem(IDC_TOTALLINES)->SetWindowText(sTemp);

	//show code lines
	if(m_nTotalLines!=0)
		sprintf(sTemp, "%d(%2.1f%%)", m_nCodeLines, m_nCodeLines*100./m_nTotalLines);
	else
		sprintf(sTemp, "0(0%)");
	GetDlgItem(IDC_CODELINES)->SetWindowText(sTemp);

	//show comment lines
	if(m_nTotalLines!=0)
		sprintf(sTemp, "%d(%2.1f%%)", m_nCommentLines, m_nCommentLines*100./m_nTotalLines);
	else
		sprintf(sTemp, "0(0%)");
	GetDlgItem(IDC_COMMENTLINES)->SetWindowText(sTemp);

	//show blank lines
	if(m_nTotalLines!=0)
		sprintf(sTemp, "%d(%2.1f%%)", m_nBlankLines, m_nBlankLines*100./m_nTotalLines);
	else
		sprintf(sTemp, "0(0%)");
	GetDlgItem(IDC_BLANKLINES)->SetWindowText(sTemp);
}
