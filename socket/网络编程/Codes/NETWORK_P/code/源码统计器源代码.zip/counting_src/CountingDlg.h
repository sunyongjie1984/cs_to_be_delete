// CountingDlg.h : header file
//

#if !defined(AFX_COUNTINGDLG_H__BF4CCD3D_0C43_11D3_87BA_0000B4B0BD6C__INCLUDED_)
#define AFX_COUNTINGDLG_H__BF4CCD3D_0C43_11D3_87BA_0000B4B0BD6C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "mrucombo.h"
#include "mylistctrl.h"
//#include "mystatic.h"
//#include "PictureEx.h"
#include "WinXPButtonST.h"

typedef struct _Extension{
	CStringArray arrayType; // strings of extension
	int  nType[50]; // file type defined as following
}EXTENSION, *PEXTENSION;

#define TOTAL_TYPE 16 //added by xiaogi 11.18
#define TYPE_OTHER	0
#define TYPE_CPP	1 //FOR extract icon, must map to IDB_FILETYPE
#define TYPE_CXX	1
#define TYPE_H		2 
#define TYPE_HPP	2 // the same value means the same icon
#define TYPE_TXT	3
#define TYPE_DSW	4
#define TYPE_RC		5
#define TYPE_WRI	6
#define TYPE_HTM	7
#define TYPE_INI	8
#define TYPE_HPJ	9
#define TYPE_C		10
#define TYPE_JAVA	11
#define TYPE_VB		12
#define TYPE_ASP	13
#define TYPE_JSP	14
#define TYPE_SQL	15

#define COUNTING_TIMER		1001
#define ABOUT_ICON_TIMER	1002
#define ABOUT_CREDIT_TIMER	1003
///////////////////////////////////////////////////////////////////////////
// CCountingDlg dialog

class CCountingDlg : public CDialog
{
// Construction
public:
	CWinXPButtonST	m_btnCount;
	CWinXPButtonST	m_btnSave;
	CWinXPButtonST	m_btnAbout;
	CWinXPButtonST	m_btnQuit;

	void SaveAsCSVFile(LPCTSTR filename);
	void SaveAsTextFile(LPCTSTR filename);
	int GetTxtFileLines(LPCTSTR strFileName, int* pnLength, int* pnCommentLines, int* pnBlankLines);
	int GetSqlFileLines(LPCTSTR strFileName, int* pnLength, int* pnCommentLines, int* pnBlankLines);
	int GetVBFileLines(LPCTSTR strFileName, int* pnLength, int* pnCommentLines, int* pnBlankLines);
	int GetCppFileLines(LPCTSTR strFileName, int* pnLength, int* pnCommentLines, int* pnBlankLines);

	int m_nFiles;
	int m_nSize;
	int m_nTotalLines;
	int m_nCodeLines;
	int m_nCommentLines;
	int m_nBlankLines;

	int m_nIconIndex[TOTAL_TYPE]; //added by xiaogi 11.18 ΪʹCListCtrl��icon������׷��̫��
	int m_nItemCountSet;

	BOOL CompareMarkString(CString inputFile, CString strFile);
	BOOL IsSearchingFor(CString strFileName);
	CString TextAppendSpace(CString strText, int num, BOOL bAtEnd);
	CString GetPurePath(CString strPath);
	int FindFileType(CString strFile);
	BOOL ExtractExtension(CString& strOneOfExt, CString& strExtension);

	static UINT CountThread(LPVOID lpvData);
	void UpdateResult();

	EXTENSION m_structExtention;
	CImageList m_imageList;

	CCountingDlg(CWnd* pParent = NULL);	// standard constructor
	~CCountingDlg();	// standard destructor

// Dialog Data
	//{{AFX_DATA(CCountingDlg)
	enum { IDD = IDD_COUNTING_DIALOG };
	CButton	m_ctrlSave;
	CStatic	m_ctrlCountingIcon;
	CStatic	m_ctrlSize;
	CMyListCtrl	m_ctlResult;
	CMRUComboBox	m_ctlFolder;
	CComboBox	m_ctlExtension;
	CString	m_strFiles;
	BOOL	m_bIncludeSubfolder;
	CString	m_strComboExt;
	CString	m_strComboFolder;
	CString	m_strSize;
	CString	m_strCommentLines;
	CString	m_strBlankLines;
	CString	m_strCodeLines;
	CString	m_strTotalLines;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCountingDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CString m_strCurrentDir;
	int m_nTimer;
	HICON m_hIcon;

private:
	enum COUNTINGSTATUS{
		COUNTING,
		STOP
	};
	COUNTINGSTATUS m_CountingStatus;

	// Generated message map functions
	//{{AFX_MSG(CCountingDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnCancel();
	afx_msg void OnSave();
	afx_msg void OnCount();
	afx_msg void OnBrowseFolder();
	afx_msg void OnBrowseExt();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnQuit();
	afx_msg void OnAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COUNTINGDLG_H__BF4CCD3D_0C43_11D3_87BA_0000B4B0BD6C__INCLUDED_)
