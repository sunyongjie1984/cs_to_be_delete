//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Counting.rc
//
#define IDS_INPUT_FILE                  1
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_COUNTING_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDB_FILETYPE                    131
#define IDI_BIG_ICON1                   144
#define IDI_BIG_ICON2                   145
#define IDI_BIG_ICON3                   146
#define IDI_BIG_ICON4                   147
#define IDI_BIG_ICON5                   148
#define IDI_BIG_ICON6                   149
#define IDI_BIG_ICON7                   150
#define IDI_SAVE                        155
#define IDI_COUNT                       156
#define IDI_QUIT                        157
#define IDI_ABOUT                       158
#define IDI_COUNTING                    160
#define IDI_SMALLICON                   161
#define IDR_WAVEHOVER2                  161
#define IDC_HAND                        162
#define IDI_COUNTSTOP                   163
#define IDR_WAVEHOVER                   165
#define IDC_SAVE                        1002
#define IDC_COMBO_EXTENSION             1003
#define IDC_COMBO_FOLDER                1004
#define IDC_BROWSE_FOLDER               1005
#define IDC_INCLUDE_SUBFOLDER           1006
#define IDC_RESULT                      1007
#define IDC_BROWSE_EXT                  1008
#define IDC_FILES                       1009
#define IDC_LINES                       1010
#define IDC_SIZES                       1011
#define IDC_SEARCH                      1012
#define IDC_QUIT                        1013
#define IDC_SEARCHICON                  1014
#define IDC_COMBO_EXTENSION2            1014
#define IDC_COMMENT                     1014
#define IDC_COMMENTLINES                1014
#define IDS_ABORT                       1014
#define IDC_COUNTICON                   1014
#define IDC_BLANK                       1015
#define IDC_BLANKLINES                  1015
#define IDS_MESSAGE                     1015
#define IDC_TOTAL                       1016
#define IDC_TOTALLINES                  1016
#define IDS_INVALIDFILE                 1016
#define IDS_COUNTING_PATH               1017
#define IDS_WRONGTYPE                   1018
#define IDS_FILENAME                    1019
#define IDS_PATHNAME                    1020
#define IDS_TOTALLINE                   1021
#define IDS_CODELINE                    1022
#define IDS_COMMENTLINE                 1023
#define IDS_BLANKLINE                   1024
#define IDC_FILES1                      1025
#define IDS_ACCESSTIME                  1025
#define IDC_FILES2                      1026
#define IDS_FILETYPE                    1026
#define IDS_COUNTINGFILE                1027
#define IDS_OPENFAILURE                 1028
#define IDC_CODE                        1029
#define IDC_CODELINES                   1029
#define IDS_COUNTINGSTOP                1029
#define IDC_MYEMAIL                     1030
#define IDS_TOQUIT                      1030
#define IDC_MYHOMEPAGE                  1031
#define IDS_TOTALFILES                  1031
#define IDS_TOTAL                       1032
#define IDS_UNSTARTED                   1033
#define IDS_TOTALSIZE                   1034
#define IDS_COUNT                       1035
#define IDS_STOP                        1036
#define IDS_SAVETYPE                    1037
#define IDS_WAITING                     1038
#define IDC_ABOUT                       1039
#define IDS_SAVEOVER                    1039
#define IDS_TOOMUCH                     1040
#define IDC_COUNTINGICON                1041
#define IDC_COUNTINGGIF                 1044
#define IDC_COUNT                       1045
#define IDC_PATH_COUNTING               1046
#define IDC_DISPLAY_HELP                1047

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        166
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1048
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
