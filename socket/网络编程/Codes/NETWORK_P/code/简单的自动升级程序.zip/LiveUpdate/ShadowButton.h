////////////////////////////////////////////////////////////////////
// ����: CShadowButton
//
// ˵��: ������ԭDOS�µ���ӰЧ����ť
//
// �÷�:
//       1�����ļ�shadowbutton.h��shadowbutton.cpp���빤����
//       2����ʹ�õĶԻ����м���ͷ�ļ���#include shadowbutton.h
//       3������Ҫ�ı�İ�ť��Ա����(���������н���)���磺
//           CShadowButton	m_Cancel;
//       4����OnInitDialog()�м���������䣬���г�ʼ��
//           m_Cancel.SetDefaultFace();
//           m_Cancel.SetDefaultButton();
//
// �޸�: �쾰��, ����PreSubclassWindow()��ʵ�ְ�ť����ʱ�Ի�����.
/////////////////////////////////////////////////////////////////////
#if !defined(AFX_SHADOWBUTTON_H__F2E1D200_7147_11D5_98C1_8B96D28F4E0A__INCLUDED_)
#define AFX_SHADOWBUTTON_H__F2E1D200_7147_11D5_98C1_8B96D28F4E0A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// shadowbutton.h : header file

/////////////////////////////////////////////////////////////////////////////
// CShadowButton window


class CShadowButton : public CButton
{
// Construction
public:
	CShadowButton();

// Attributes
public:

// Operations
public:
	
	void SetShadowSize(CSize cs)
	{
		m_sizeShadow.cx = cs.cx;
		m_sizeShadow.cy = cs.cy;
		Redraw();
	}


protected:

	BOOL m_bDefault;

	COLORREF m_crBorderColor;
	COLORREF m_crColor;
	COLORREF m_crShadowColor;
	COLORREF m_crTextColor;
	COLORREF m_crTransColor;

	CSize m_sizeShadow;
	int m_nBorderSize;

	int m_nShadowXOffset;
	int m_nShadowYOffset;

	CBitmap m_bmpNormal;
	CBitmap m_bmpDisabled;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShadowButton)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);	
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetDefaultFace();
	BOOL SetDefaultButton( BOOL bState = TRUE );
	
	void SetShadowOffset(int x, int y);
	BOOL LoadBitmaps(COLORREF crTransColor, UINT nresNormalBmp, UINT nresDisabledBmp = 0);
	void SetColors(COLORREF crColor, COLORREF crBorder, COLORREF crShadow, COLORREF crText);
	void SetBorderSize(int nSize);
	void Redraw();
	virtual ~CShadowButton();

	// Generated message map functions
protected:
	void DrawClient(CDC *pdc, CRect *pRect, int x, int y);
	void DrawDown(CDC *pDC, CRect *pRect);
	void DrawUp(CDC *pDC, CRect *pRect);
	//{{AFX_MSG(CShadowButton)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHADOWBUTTON_H__F2E1D200_7147_11D5_98C1_8B96D28F4E0A__INCLUDED_)
