// EDot.h: interface for the CEDot class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDOT_H__C49676C1_640B_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_EDOT_H__C49676C1_640B_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Base.h"
//#include "epoint.h"
class CEDot : public CBase
{
public:
	CEDot(int nType,CBaseList* pBaseList);
	CEDot(CBase* pp1,CBase* pp2,CBase *pp3,CBase *pp4,CBaseList* pBaseList);
	virtual ~CEDot();
public:
	void Draw(CDC* pDC);
	BOOL PtInOb(CPoint point);
	void OffSet(CSize size);
	CRect GetGraphRect();
	void SetPoint(CPoint pp);
	void RotateCell(double angle);
public:
};

#endif // !defined(AFX_EDOT_H__C49676C1_640B_11D4_BBD7_600000000ECD__INCLUDED_)
