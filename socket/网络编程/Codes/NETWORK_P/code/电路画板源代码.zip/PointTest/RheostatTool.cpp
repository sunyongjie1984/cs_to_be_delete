// RheostatTool.cpp: implementation of the CRheostatTool class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "RheostatTool.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRheostatTool::CRheostatTool(CWnd* cWnd,CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText)
		:CBaseTool(cWnd,pList,pOintList,pLineList,pText)
{

}
CRheostatTool::CRheostatTool(CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText)
		:CBaseTool(pList,pOintList,pLineList,pText)
{

}
CRheostatTool::~CRheostatTool()
{

}
void CRheostatTool::OnLButtonDown(UINT nFlags, CPoint point)
{
	CanDraw = TRUE;
	CaptureScr();

	AddObject(point);

	Draw();
}
void CRheostatTool::OnLButtonUp(UINT nFlags, CPoint point)
{
	if(!CanDraw) return;
	CanDraw = FALSE;
	ReleaseScr();
}
void CRheostatTool::OnMouseMove(UINT nFlags, CPoint point)
{
	if(CanDraw){
		m_pBase->SetPoint(point);
		Draw();
	}
}
void CRheostatTool::AddObject(CPoint point)
{
	p1 = new CEpoint(m_PointList);
	p2 = new CEpoint(m_PointList);
	m_pBase = new CRheostat(p1,p2,m_pList);
	
	m_pBase->TotalAngle = ToAngle;
	m_pBase->m_iSelected = Select;
//	m_pBase->Value = Value;
	m_pBase->SetPoint(point);

	p1->Parent = m_pBase;
	p2->Parent = m_pBase;
}