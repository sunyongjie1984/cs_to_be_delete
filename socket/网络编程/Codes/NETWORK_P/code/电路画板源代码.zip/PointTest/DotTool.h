// DotTool.h: interface for the CDotTool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DOTTOOL_H__C49676C2_640B_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_DOTTOOL_H__C49676C2_640B_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseTool.h"
#include "edot.h"
#include "epoint.h"
class CDotTool : public CBaseTool  
{
public:
	CDotTool(CWnd* cWnd,CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	CDotTool(CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	virtual ~CDotTool();
public:	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
	void AddObject(CPoint point);
public:
	CBase *p1,*p2,*p3,*p4;
};

#endif // !defined(AFX_DOTTOOL_H__C49676C2_640B_11D4_BBD7_600000000ECD__INCLUDED_)
