// Light.cpp: implementation of the CLight class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "Light.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CLight::CLight(int nType,CBaseList* pBaseList) : CBase(ID_LIGHT,pBaseList)
{
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "L";
	AddString(ID_LIGHT);
	Value = 1;
}
CLight::CLight(CBase* pp1,CBase* pp2,CBaseList* pBaseList) : CBase(ID_LIGHT,pBaseList)
{
	p1 = pp1;
	p2 = pp2;
	AddSon(p1);
	AddSon(p2);
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "L";
	AddString(ID_LIGHT);
	Value = 1;
}
CLight::~CLight()
{
}
void CLight::Draw(CDC* pDC)
{
	if(IsSelected()){
		CPen pen(PS_SOLID, 2,RED);
		CPen *Oldpen = pDC->SelectObject(&pen);
		pDC->MoveTo(left);
		pDC->LineTo(p1->CenterPoint);
		pDC->MoveTo(right);
		pDC->LineTo(p2->CenterPoint);
		DrawCircle(pDC);
		pDC->MoveTo(aa);
		pDC->LineTo(dd);
		pDC->MoveTo(cc);
		pDC->LineTo(bb);
		pDC->SelectObject(Oldpen);
		//pDC->SelectObject(oldbrush);
	}else{
		CPen pen(PS_SOLID, 2,BLACK);
		CPen *Oldpen = pDC->SelectObject(&pen);
		pDC->MoveTo(left);
		pDC->LineTo(p1->CenterPoint);
		pDC->MoveTo(right);
		pDC->LineTo(p2->CenterPoint);
		DrawCircle(pDC);
		pDC->MoveTo(aa);
		pDC->LineTo(dd);
		pDC->MoveTo(cc);
		pDC->LineTo(bb);
		pDC->SelectObject(Oldpen);
	}
	TextOut(pDC);
}
void CLight::DrawCircle(CDC *pp)
{
	CBrush* oldBrush;
	if(m_bSwitch){
		CBrush brush(LIGHT);
		oldBrush = pp->SelectObject(&brush);
	}
	pp->Ellipse(GetRect(CenterPoint,CSize(20,20)));
	if(m_bSwitch)
		pp->SelectObject(oldBrush);
}
void CLight::SetPoint(CPoint pp)
{
	left = right = CenterPoint = pp;
	left = pp - CPoint(10,0);
	right = pp + CPoint(10,0);

	p1->CenterPoint = pp - CPoint(20,0);
	p2->CenterPoint = pp + CPoint(19,0);

	aa = bb = cc = dd = left;

	aa = Rotate((45*PI/180),aa);
	bb = Rotate((135*PI/180),bb);
	cc = Rotate(-(45*PI/180),cc);
	dd = Rotate(-(135*PI/180),dd);

	RotateCell(TotalAngle);
}
void CLight::OffSet(CSize size)
{
	CenterPoint.Offset(size);
	left.Offset(size);
	right.Offset(size);
	p1->OffSet(size);
	p2->OffSet(size);
	aa.Offset(size);
	bb.Offset(size);
	cc.Offset(size);
	dd.Offset(size);
}
CRect CLight::GetGraphRect()
{
	CPoint up_left,down_right;
	up_left = down_right = CenterPoint;
	up_left.Offset(-10,-10);
	down_right.Offset(10,10);
	return CRect(up_left,down_right);	
}
void CLight::RotateCell(double angle)
{
	left = Rotate(angle,left);
	right = Rotate(angle,right);
	p1->CenterPoint = Rotate(angle,p1->CenterPoint);
	p2->CenterPoint = Rotate(angle,p2->CenterPoint);
	aa = Rotate(angle,aa);
	bb = Rotate(angle,bb);
	cc = Rotate(angle,cc);
	dd = Rotate(angle,dd);
}
