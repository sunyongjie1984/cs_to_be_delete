// Element.h: interface for the CAElement class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ELEMENT_H__6FF25B75_598A_11D4_AFFB_00E04C6749D0__INCLUDED_)
#define AFX_ELEMENT_H__6FF25B75_598A_11D4_AFFB_00E04C6749D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "afxtempl.h"

class CAJoint;

typedef struct tagJoints
{
	CAJoint *pJoint1;
	CAJoint *pJoint2;
} Joints;
typedef struct tagOrders
{
	int order1;
	int order2;
} Orders;
typedef CList<int,int>IntList;

class CAElement  
{
protected:
	BOOL m_bIsParel;
	int m_nIndex;
	float m_fValue;//nonobjective value of all kinds of elements
	int m_nType;
	BOOL m_bIsClose;
	float m_fVoltage;
	float m_fCurrent;
	BOOL m_bIsAsInductor;
	BOOL m_bIsAsCapacity;
	BOOL m_bIsWorked;
	BOOL m_bIsAsPower;
	Joints m_structJoint;
	Orders m_structOrder;
public:
	void SetIndex(int index);
	int GetIndex();

//	CList<int,int>m_nOrderList;
	virtual IntList* GetCapacityOrderList(CAJoint* pJoint);
//	virtual IntList* GetCapacityOrderList2();
	CAJoint *pRemove;
	CAJoint *pNoRemove;
	Joints* GetJointStruct();
	void SetOrderStruct(int order1,int order2);
	Orders* GetOrderStruct();
	int GetType();
	void SetType(int type);
	float GetVoltage();//get the voltage of the two sides 
	void SetStructJoint(CAJoint *p1,CAJoint *p2);
	float GetValue();
	void SetValue(float v);
	void SetVoltage(float v);
	void SetCurrent(float i);
	virtual float GetCurrent();
	void SetIsAsPower(BOOL b);
	BOOL IsAsPower();
	void SetWorked(BOOL b);
	BOOL IsWorked();
	BOOL IsClose();
	void SetIsAsInductor(BOOL b);
	void SetIsAsCapacity(BOOL b);
	BOOL IsAsInductor();
	BOOL IsAsCapacity();
	void SetIsParel( BOOL b );
	BOOL IsSetParel();
	

	BOOL IsTheP1Joint( CAJoint* pJoint );
public:
	CAElement(int type,float v);
	virtual ~CAElement();

};

#endif // !defined(AFX_ELEMENT_H__6FF25B75_598A_11D4_AFFB_00E04C6749D0__INCLUDED_)
