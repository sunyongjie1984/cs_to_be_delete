// CapTool.h: interface for the CCapTool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CAPTOOL_H__71CE99E2_678A_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_CAPTOOL_H__71CE99E2_678A_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseTool.h"
#include "epoint.h"
#include "capacitance.h"
class CCapTool : public CBaseTool  
{
public:
	CCapTool(CWnd* cWnd,CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	CCapTool(CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	virtual ~CCapTool();
public:	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
	void AddObject(CPoint point);
public:
	//CResis* m_pResis;
	CBase* p1,*p2;
};

#endif // !defined(AFX_CAPTOOL_H__71CE99E2_678A_11D4_BBD7_600000000ECD__INCLUDED_)
