// ButtonMouseTool.cpp: implementation of the ButtonMouseTool class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "ButtonMouseTool.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ButtonMouseTool::ButtonMouseTool()
{
}

ButtonMouseTool::~ButtonMouseTool()
{

}

void ButtonMouseTool::Draw( CDC *pDC )
{
	list.Draw( pDC );
}

void ButtonMouseTool::OnLButtonDown( UINT nFlags,CPoint point )
{
    list.OnLButtonDown( nFlags,point ); 
}

void ButtonMouseTool::OnLButtonUp( UINT nFlags,CPoint point )
{
	list.OnLButtonUp( nFlags,point );
}

void ButtonMouseTool::OnMouseMove( UINT nFlags,CPoint point )
{
	list.OnMouseMove( nFlags,point );
}

void ButtonMouseTool::Serialize( CArchive &ar )
{
	list.Serialize( ar );
}
