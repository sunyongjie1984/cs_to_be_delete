// NodeList.h: interface for the CNodeList class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_NODELIST_H__97F8C9E1_6B10_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_NODELIST_H__97F8C9E1_6B10_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Elist.h"
#include "pointlist.h"
#include "linelist.h"
#include "node.h"
#include "JointList.h"
#include "calculate.h"
#include "elementserial.h"
class CNodeList : public CPtrList  
{
public:
	CNodeList(CElist* pList , CPointList* pOintList,CLineList* pLineList);
	virtual ~CNodeList();
	void CreateBaseChain();
	void ConstructSystem();
	void UniteNode();
	void ClearAll();
	CString GetListString();
	void SendData();

	BOOL IsClose();//�Ƿ�պϵ�·
	BOOL IfCellClosed();
	BOOL IfAllPortHaveLine();
	CMyNode* GetNode(CBase* point,CMyNode* old);
	BOOL IfHavePower();
	//Serial function
	void AddElementToSerial();
	void AsignNodeToElement();
	int FindNode(CBase* befind);
	void Texis();
	void GiveYouData();
	void OutPut(CDC* pDC);

	void ClearSerial();

	BOOL IfCurrentParallel();//judge if the amperemeter parallel connection
	BOOL IfVoltageSeries();//judge if the voltmeter in series
public:
	CMyNode* node;
	CElist* m_pList;
	CPointList* m_PointList;
	CLineList* m_pLineList;
	int m_base;
protected:
	CJointList* m_pJointList;
	CCalculate *pCal;
	CElementSerial m_Serial;
};

#endif // !defined(AFX_NODELIST_H__97F8C9E1_6B10_11D4_BBD7_600000000ECD__INCLUDED_)
