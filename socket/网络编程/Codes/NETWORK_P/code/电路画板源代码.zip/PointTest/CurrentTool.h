// CurrentTool.h: interface for the CCurrentTool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CURRENTTOOL_H__9CCA6E61_691C_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_CURRENTTOOL_H__9CCA6E61_691C_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseTool.h"
#include "current.h"
#include "epoint.h"
class CCurrentTool : public CBaseTool  
{
public:
	CCurrentTool(CWnd* cWnd,CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	CCurrentTool(CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	virtual ~CCurrentTool();
public:	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
	void AddObject(CPoint point);
public:
	CBase* p1,*p2;
};

#endif // !defined(AFX_CURRENTTOOL_H__9CCA6E61_691C_11D4_BBD7_600000000ECD__INCLUDED_)
