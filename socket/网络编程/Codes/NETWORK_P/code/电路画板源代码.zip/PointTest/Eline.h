// Eline.h: interface for the CResis class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ELINE_H__37927A17_613E_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_ELINE_H__37927A17_613E_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Base.h"
class CResis : public CBase  
{
public:
	CResis(int nType,CBaseList* pBaseList);
	CResis(CBase* pp1,CBase* pp2,CBaseList* pBaseList);
	virtual ~CResis();
public:
	void Draw(CDC* pDC);
	void OffSet(CSize size);
	CRect GetGraphRect();
	void SetPoint(CPoint pp);
	void RotateCell(double angle);
public:
	CPoint aa,bb,cc,dd;
};

#endif // !defined(AFX_ELINE_H__37927A17_613E_11D4_BBD7_600000000ECD__INCLUDED_)
