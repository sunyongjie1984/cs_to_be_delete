// SwitchTool.h: interface for the CSwitchTool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SWITCHTOOL_H__53B48221_6853_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_SWITCHTOOL_H__53B48221_6853_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseTool.h"
#include "epoint.h"
#include "switch.h"
class CSwitchTool : public CBaseTool  
{
public:
	CSwitchTool(CWnd* cWnd,CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	CSwitchTool(CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	virtual ~CSwitchTool();
public:	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
	void AddObject(CPoint point);
public:
	CBase* p1,*p2;
};
#endif // !defined(AFX_SWITCHTOOL_H__53B48221_6853_11D4_BBD7_600000000ECD__INCLUDED_)
