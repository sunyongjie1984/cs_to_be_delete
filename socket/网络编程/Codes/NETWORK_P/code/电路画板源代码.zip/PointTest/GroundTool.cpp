// GroundTool.cpp: implementation of the CGroundTool class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "GroundTool.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGroundTool::CGroundTool(CWnd* cWnd,CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText)
		:CBaseTool(cWnd,pList,pOintList,pLineList,pText)
{

}
CGroundTool::CGroundTool(CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText)
		:CBaseTool(pList,pOintList,pLineList,pText)
{

}
CGroundTool::~CGroundTool()
{

}
void CGroundTool::OnLButtonDown(UINT nFlags, CPoint point)
{
	CanDraw = TRUE;
	CaptureScr();

	AddObject(point);

	Draw();
}
void CGroundTool::OnLButtonUp(UINT nFlags, CPoint point)
{
	if(!CanDraw) return;
	CanDraw = FALSE;
	ReleaseScr();
}
void CGroundTool::OnMouseMove(UINT nFlags, CPoint point)
{
	if(CanDraw){
		m_pBase->SetPoint(point);
		Draw();
	}
}
void CGroundTool::AddObject(CPoint point)
{
	p1 = new CEpoint(m_PointList);

	m_pBase = new CGround(p1,m_pList);
	m_pBase->TotalAngle = ToAngle;
	m_pBase->m_iSelected = Select;
//	m_pBase->Value = Value;
	m_pBase->SetPoint(point);
	p1->Parent = m_pBase;
}