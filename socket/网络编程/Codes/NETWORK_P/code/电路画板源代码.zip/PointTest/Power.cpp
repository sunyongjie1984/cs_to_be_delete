// Power.cpp: implementation of the CPower class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "Power.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPower::CPower(int nType,CBaseList* pBaseList) : CBase(ID_POWER,pBaseList)
{
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "P";
	AddString(ID_POWER);
	Value = 1;
}
CPower::CPower(CBase* pp1,CBase* pp2,CBaseList* pBaseList) : CBase(ID_POWER,pBaseList)
{
	p1 = pp1;
	p2 = pp2;
	AddSon(p1);
	AddSon(p2);
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "P";
	AddString(ID_POWER);
	Value = 1;
}
CPower::~CPower()
{
}
void CPower::Draw(CDC* pDC)
{


	if(IsSelected()){
		CPen pen(PS_SOLID, 2,RED);
		CPen *Oldpen = pDC->SelectObject(&pen);

		pDC->MoveTo(left);
		pDC->LineTo(p1->CenterPoint);
		pDC->MoveTo(right);
		pDC->LineTo(p2->CenterPoint);
		pDC->MoveTo(aa);
		pDC->LineTo(bb);
		pDC->MoveTo(cc);
		pDC->LineTo(dd);

		pDC->SelectObject(Oldpen);
	}else{
		CPen pen(PS_SOLID, 2,BLACK);
		CPen *Oldpen = pDC->SelectObject(&pen);
		pDC->MoveTo(left);
		pDC->LineTo(p1->CenterPoint);
		pDC->MoveTo(right);
		pDC->LineTo(p2->CenterPoint);
		pDC->MoveTo(aa);
		pDC->LineTo(bb);
		pDC->MoveTo(cc);
		pDC->LineTo(dd);
		pDC->SelectObject(Oldpen);
	}
	TextOut(pDC);
}
void CPower::SetPoint(CPoint pp)
{
	left = right = CenterPoint = pp;
	left = pp - CPoint(5,0);
	right = pp + CPoint(5,0);
	p1->CenterPoint = pp - CPoint(15,0);
	p2->CenterPoint = pp + CPoint(14,0);

	aa = bb = left;
	cc = dd = right;
	aa.Offset(CSize(0,-5));
	bb.Offset(CSize(0,5));
	cc.Offset(CSize(0,-10));
	dd.Offset(CSize(0,10));
	RotateCell(TotalAngle);
}
void CPower::OffSet(CSize size)
{
	CenterPoint.Offset(size);
	left.Offset(size);
	right.Offset(size);
	p1->OffSet(size);
	p2->OffSet(size);
	aa.Offset(size);
	bb.Offset(size);
	cc.Offset(size);
	dd.Offset(size);
}
CRect CPower::GetGraphRect()
{
	CPoint up_left,down_right;
	up_left = down_right = CenterPoint;
	up_left.Offset(-5,-10);
	down_right.Offset(5,10);
	return CRect(up_left,down_right);	
}
void CPower::RotateCell(double angle)
{
	left = Rotate(angle,left);
	right = Rotate(angle,right);
	p1->CenterPoint = Rotate(angle,p1->CenterPoint);
	p2->CenterPoint = Rotate(angle,p2->CenterPoint);
	aa = Rotate(angle,aa);
	bb = Rotate(angle,bb);
	cc = Rotate(angle,cc);
	dd = Rotate(angle,dd);
}