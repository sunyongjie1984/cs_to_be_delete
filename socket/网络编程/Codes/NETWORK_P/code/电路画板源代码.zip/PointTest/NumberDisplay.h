// NumberDisplay.h: interface for the NumberDisplay class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NUMBERDISPLAY_H__D88F3F98_72E9_11D4_B684_F36357A7FC1C__INCLUDED_)
#define AFX_NUMBERDISPLAY_H__D88F3F98_72E9_11D4_B684_F36357A7FC1C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class NumberDisplay  
{
public:
	NumberDisplay();
	virtual ~NumberDisplay();
public:
	int m_zhengNum;
	LOGPEN LogPenText;         //������ɫ
	LOGPEN LogPen8;       //����8��ɫ
	LOGPEN LogPenBackground;             //������ɫ
	BOOL m_Flag;
	int m_Number;          //����С��λ
	double m_date;            //��Ҫ��ʾ���� 
	int m_Hight;           //���ڵĿ��͸�
	int m_Width;
	CPoint m_LeftTopPoint;     //���ڵ����Ͻ�����
	int m_HengWidth;                    //��Ŀ��͸�
	int m_HengHight;
	int m_ShuWidth;                     //���Ŀ��͸�
	int m_ShuHight;
	int m_FontDistance;                 //����ļ��
	int m_FontToWindowDistance;         //����ߵ����ڱߵľ���
	int m_BottomDistance;               //����׵����ڵ׵ľ���
	int m_FontSum;                      //������ܸ��� 
	int m_HengToShuDistance;            //������ļ��
	int m_FontWidth;                     //����Ŀ��͸�
	int m_FontHight;

	int m_Num;
	CPoint m_tempPoint;
	BOOL m_LFlag;
	BOOL m_BeSelected;

public:
	void SetParam( double date,CPoint point,int width,int hight,int i );
	void SetParam( double date,CPoint point,int width,int hight,int i,int j );
    void ArithPosition( double date,int width,int hight );
	void Draw( CDC * );
    void DrawNumber( int i,CDC *pDC,int j );
	void Draw0( CDC *pDC,int j );
	void Draw1( CDC *pDC,int j );
	void Draw2( CDC *pDC,int j );
	void Draw3( CDC *pDC,int j );
	void Draw4( CDC *pDC,int j );
	void Draw5( CDC *pDC,int j );
	void Draw6( CDC *pDC,int j );
	void Draw7( CDC *pDC,int j );
    void Draw8( CDC *pDC,int j );
	void Draw9( CDC *pDC,int j );
	void DrawUpHeng( CDC *pDC,CPoint point,LOGPEN );
	void DrawDownHeng( CDC *pDC,CPoint point,LOGPEN );
	void DrawMidHeng( CDC *pDC,CPoint point,LOGPEN );
	void DrawLeftUpShu( CDC *,CPoint,LOGPEN );
	void DrawLeftDownShu( CDC *,CPoint,LOGPEN );
	void DrawRightUpShu( CDC *,CPoint,LOGPEN );
	void DrawRightDownShu( CDC *,CPoint,LOGPEN );
	void DrawPoint( int j,CDC *pDC );
	void DrawDoublePoint( int j,CDC *pDC );
	void DrawBottomPicture( CDC *,int j );
	BOOL PtInWindow( CPoint point );
	void ArithDragPosition( CPoint point );

	void OnLButtonDown( UINT nFlags,CPoint point );
	void OnLButtonUp( UINT nFlags,CPoint point );
	void OnMouseMove( UINT nFlags,CPoint point );

};

#endif // !defined(AFX_NUMBERDISPLAY_H__D88F3F98_72E9_11D4_B684_F36357A7FC1C__INCLUDED_)
