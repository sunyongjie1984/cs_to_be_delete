// Epoint.h: interface for the CEpoint class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EPOINT_H__37927A16_613E_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_EPOINT_H__37927A16_613E_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Base.h"
class CLine;

class CEpoint : public CBase  
{
public:
	CEpoint(CBaseList* pBaseList);
	CEpoint(int nType,CBaseList* pBaseList);
	virtual ~CEpoint();
public:
	void Draw(CDC* pDC);
	void OffSet(CSize size);
	CRect GetGraphRect();
	void SetPoint(CPoint point);
public:

};

#endif // !defined(AFX_EPOINT_H__37927A16_613E_11D4_BBD7_600000000ECD__INCLUDED_)
