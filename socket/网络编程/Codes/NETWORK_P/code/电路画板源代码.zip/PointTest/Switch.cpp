// Switch.cpp: implementation of the CSwitch class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "Switch.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CSwitch::CSwitch(int nType,CBaseList* pBaseList) : CBase(ID_SWITCH,pBaseList)
{
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "S";
	AddString(ID_SWITCH);
	Value = 0;
}
CSwitch::CSwitch(CBase* pp1,CBase* pp2,CBaseList* pBaseList) : CBase(ID_SWITCH,pBaseList)
{
	p1 = pp1;
	p2 = pp2;
	AddSon(p1);
	AddSon(p2);
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "S";
	AddString(ID_SWITCH);
	Value = 0;
}
CSwitch::~CSwitch()
{

}
void CSwitch::Draw(CDC* pDC)
{
	CRect a1(-2,-2,2,2),a2;
	a2 = a1;
	a1.OffsetRect(left);
	a2.OffsetRect(right);

	if(IsSelected()){
		CPen pen(PS_SOLID, 2,RED);
		CPen *Oldpen = pDC->SelectObject(&pen);
		if(m_bSwitch){
			pDC->MoveTo(p1->CenterPoint);
			pDC->LineTo(p2->CenterPoint);
			pDC->Ellipse(a1);
			pDC->Ellipse(a2);
		}else{
			pDC->MoveTo(aa);
			pDC->LineTo(left);
			pDC->LineTo(p1->CenterPoint);
			pDC->MoveTo(right);
			pDC->LineTo(p2->CenterPoint);
			pDC->SelectStockObject(NULL_BRUSH);
			pDC->Ellipse(a1);
			pDC->Ellipse(a2);
		}
		pDC->SelectObject(Oldpen);
		//pDC->SelectObject(oldbrush);
	}else{
		CPen pen(PS_SOLID, 2,BLACK);
		CPen *Oldpen = pDC->SelectObject(&pen);
		if(m_bSwitch){
			pDC->MoveTo(p1->CenterPoint);
			pDC->LineTo(p2->CenterPoint);
			pDC->Ellipse(a1);
			pDC->Ellipse(a2);
		}else{
			pDC->MoveTo(aa);
			pDC->LineTo(left);
			pDC->LineTo(p1->CenterPoint);
			pDC->MoveTo(right);
			pDC->LineTo(p2->CenterPoint);
			pDC->SelectStockObject(NULL_BRUSH);
			pDC->Ellipse(a1);
			pDC->Ellipse(a2);
		}
		pDC->SelectObject(Oldpen);
	}
	TextOut(pDC);
}
void CSwitch::SetPoint(CPoint pp)
{
	left = right = CenterPoint = pp;
	left = pp - CPoint(20,0);
	right = pp + CPoint(20,0);
	p1->CenterPoint = pp - CPoint(30,0);
	p2->CenterPoint = pp + CPoint(29,0);
	aa = Rotate((45*PI)/180,right);
	RotateCell(TotalAngle);
}
void CSwitch::OffSet(CSize size)
{
	CenterPoint.Offset(size);
	left.Offset(size);
	right.Offset(size);
	p1->OffSet(size);
	p2->OffSet(size);
	aa.Offset(size);
}
CRect CSwitch::GetGraphRect()
{
	CPoint up_left,down_right;
	up_left = down_right = CenterPoint;
	up_left.Offset(-20,-10);
	down_right.Offset(20,10);
	return CRect(up_left,down_right);
}
void CSwitch::RotateCell(double angle)
{
	left = Rotate(angle,left);
	right = Rotate(angle,right);
	p1->CenterPoint = Rotate(angle,p1->CenterPoint);
	p2->CenterPoint = Rotate(angle,p2->CenterPoint);
	aa = Rotate(angle,aa);
}
