#if !defined(AFX_PROPERTIY_H__57C33D81_6D3E_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_PROPERTIY_H__57C33D81_6D3E_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Propertiy.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropertiy dialog

class CPropertiy : public CDialog
{
// Construction
public:
	CPropertiy(CWnd* pParent = NULL);   // standard constructor
	CPropertiy(CString tr);   // standard constructor
// Dialog Data
	//{{AFX_DATA(CPropertiy)
	enum { IDD = IDD_PROPERY };
	float	m_value;
	float   m_MaxValue;
	CString	m_properte;
	CString	m_unit;
	CString m_title;
	CString m_remark;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropertiy)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropertiy)
	virtual BOOL OnInitDialog();
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTIY_H__57C33D81_6D3E_11D4_BBD7_600000000ECD__INCLUDED_)
