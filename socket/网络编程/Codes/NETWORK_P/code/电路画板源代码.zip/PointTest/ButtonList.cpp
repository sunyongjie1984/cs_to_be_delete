// ButtonList.cpp: implementation of the ButtonList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "ButtonList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ButtonList::ButtonList()
{
    m_ID = 1;
	m_LFlag = FALSE;
	m_BeSelected = FALSE;
	m_WhatToDo = 0;
}

ButtonList::~ButtonList()
{
    DeleteAllButton( );
}

void ButtonList::AddButton( Button *ptr )
{
	if ( MyList.IsEmpty( ) )
	{
		MyList.AddHead( ptr );
	}
	else
	{
		MyList.AddTail( ptr );
	}
}

void ButtonList::DeleteAllButton( )
{
	POSITION pos,tempPos;
	Button *temp;
	if ( MyList.IsEmpty() )
	{
	}
	else
	{
		pos = MyList.GetHeadPosition( );
		while ( pos )
		{
			tempPos = pos;
			temp = MyList.GetNext( pos );
			MyList.RemoveAt( tempPos );
			delete temp;
		}
	}
}


void ButtonList::DeleteAllFlag( )
{
	POSITION pos;
	Button *temp;
	if ( MyList.IsEmpty() )
	{
	}
	else
	{
		pos = MyList.GetHeadPosition( );
		while ( pos )
		{
			temp = MyList.GetNext( pos );
            temp->m_BeSelected = FALSE;
			temp->m_MoveBeSelected = FALSE;
		}
	}
}

void ButtonList::Draw( CDC *pDC )
{
	POSITION pos ;
	Button *temp;
	if ( MyList.IsEmpty( ) )
	{
	}
	else
	{
		pos = MyList.GetHeadPosition( ) ;
		while ( pos )
		{
			temp = MyList.GetNext( pos );
			temp->Draw( pDC );
		}
	}
}

void ButtonList::ExchangeButtonPosition( CPoint point ,UINT id )
{
	POSITION pos;
	Button *temp;
	if ( MyList.IsEmpty() )
	{
	}
	else
	{
		pos = MyList.GetHeadPosition( );
		while ( pos )
		{
			temp = MyList.GetNext( pos );
			if ( temp->m_ID == id )
			{
				temp->ExchangeButtonPosition( point );
			}
		}
	}
}

UINT ButtonList::CreateButton( CPoint tempPoint,int width,int hight,UINT id1,UINT id2,UINT id3 )
{
	Button *temp = new Button;
	temp->m_ID = m_ID;
	m_ID++;
	temp->m_Point = tempPoint;
	temp->m_Width = width;
	temp->m_Hight = hight;
	temp->m_BitmapID1 = id1;
	temp->m_BitmapID2 = id2;
	temp->m_BitmapID3 = id3;
	DeleteAllFlag( );
	AddButton( temp );
	return temp->m_ID;
}


void ButtonList::OnLButtonDown( UINT nFlags,CPoint point )
{
	m_LFlag = TRUE;
	POSITION pos;
	Button *temp;
	BOOL flag = FALSE;
	if ( MyList.IsEmpty( ) )
	{
	}
	else
	{
		pos = MyList.GetHeadPosition( );
		while ( pos )
		{
			temp = MyList.GetNext( pos );
            flag = temp->PtInButton( point );
			if ( flag )
			{
				m_BeSelected = TRUE;
				DeleteAllFlag( );
				temp->m_BeSelected = TRUE;
				m_WhatToDo = temp->m_ID;
				return;
			}
		}
	}
}

void ButtonList::OnLButtonUp( UINT nFlag,CPoint point )
{
	m_LFlag = FALSE;
	BOOL flag = TRUE;
	if ( m_BeSelected )
	{
		POSITION pos ;
		Button *temp;
		if ( MyList.IsEmpty( ) )
		{
			m_BeSelected = FALSE;
			m_WhatToDo = 0;
		}
		else
		{
			pos = MyList.GetHeadPosition( );
			while ( pos )
			{
				temp = MyList.GetNext( pos );
				if ( temp->m_ID == m_WhatToDo )
				{
					flag = temp->PtInButton( point );
					if ( flag  )
					{
						m_BeSelected = FALSE;
						DeleteAllFlag( );
						return;
					}
					else
					{
						m_BeSelected = FALSE;
						m_WhatToDo = 0;
						DeleteAllFlag( );
						return ;
					}
				}
			}
		    m_BeSelected = FALSE;
			m_WhatToDo = 0;
			DeleteAllFlag( );
		}
	}
}

void ButtonList::OnMouseMove( UINT nFlags,CPoint point )
{
	POSITION pos;
	Button *temp;
	BOOL flag = FALSE;
	if ( m_LFlag  )
	{
		if ( MyList.IsEmpty( ) )
		{
			m_BeSelected = FALSE;
			m_WhatToDo = 0;
		}
		else
		{
			pos = MyList.GetHeadPosition( );
			while ( pos )
			{
				temp = MyList.GetNext( pos );
				if ( temp->m_ID == m_WhatToDo )
				{
					flag = temp->PtInButton( point );
					if ( flag  )
					{
						temp->m_BeSelected = TRUE;
						return;
					}
					else
					{
						DeleteAllFlag( );
						return ;
					}
				}
			}
		}
	}
	else
	{
		if ( MyList.IsEmpty( ) )
		{
		}
		else
		{
			pos = MyList.GetHeadPosition( );
			while ( pos )
			{
				temp = MyList.GetNext( pos );
				flag = temp->PtInButton( point );
				if ( flag )
				{
					DeleteAllFlag( );
					temp->m_MoveBeSelected = TRUE;
					return;
				}
				else
				{
					DeleteAllFlag( );
				}
			}
		}
	}
}

void ButtonList::Serialize( CArchive &ar )
{
	POSITION pos;
	Button *temp;
	int i = 0;
	if ( ar.IsStoring( ) )
	{
		ar<<m_BeSelected<<m_LFlag;
		ar<<m_ID;
		ar<<m_WhatToDo;
		i = MyList.GetCount( );
		ar<<i;
		if ( MyList.IsEmpty( ) )
		{
		}
		else
		{
			pos = MyList.GetHeadPosition();
			while ( pos )
			{
				temp = MyList.GetNext( pos );
				temp->Serialize( ar );
			}
		}
	}
	else
	{
		ar>>m_BeSelected>>m_LFlag;
		ar>>m_ID;
		ar>>m_WhatToDo;
		ar>>i;
		DeleteAllButton( );
		for ( int j = 0;j<i;j++ )
		{
			temp = new Button;
			if ( MyList.IsEmpty( ) )
			{
				MyList.AddHead( temp );
			}
			else
			{
				MyList.AddTail( temp );
			}
			temp->Serialize( ar );
		}
	}
}


