// WatchFace.cpp: implementation of the WatchFace class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "WatchFace.h"
#include "math.h"

#define PI 3.1415926
#define FONTCOLOR RGB( 128,128,0 )
#define JIANTOUANGLE 15
#define JIANTOULONG 10

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

WatchFace::WatchFace()
{
	m_Number = 0;           //���ڼ���ڽ�

	m_Width =200;
	m_Hight = 100;           //����Ŀ��͸�
	m_Center = m_Width/2;    //����
	m_Angle = 0;             //����İڽ�
	m_Value = 0;             //��ֵ
	m_Name = "A";            //����
	m_DianWei = "����";      //��λ
	m_BigFlag = FALSE;       //���볬�������
	m_SmallFlag = FALSE;     //���볬����С��
	m_BeginAngle = -150;                         //�̶��̵���ʼ�Ǻ���ֹ�� 
	m_EndAngle = -30;

	m_Down = -0.5;
    m_Up = m_EndAngle+0.5;   //���ֵ��������
	m_PrevValue = m_Down;    //��һ�β���ֵ
	m_SmallAngle = m_BeginAngle+( m_Down-0.2 )/m_SingleExpress*m_SingleAngle;//�������С�ڽ�
    m_BigAngle = m_EndAngle+( 0.2 )/m_SingleExpress*m_SingleAngle;   //��������ڽ�
}


//void WatchFace::SetParam( int width,int hight,CString name,double singleangle,double express,CString units,double value )
void WatchFace::SetParam( CPoint point,int width,int hight,CString name,double bigValue,CString units,double value )
{
	lefttop = point;
    m_SingleExpress = bigValue/12;
	m_SingleAngle = 10;
	m_Width =width;
	m_Hight = hight;        //����Ŀ��͸�

	m_Center = CPoint( m_Width/2,m_Hight+10 );   //����
	m_Long = hight-7;                            //����ĳ�


	m_BeginPoint = ArithPoint( m_Center,m_BeginAngle,m_Long );
	m_EndPoint = ArithPoint( m_Center,m_EndAngle,m_Long );    //�̶��̵���ʼ�����ֹ�� 

	m_NamePoint = CPoint( m_Center.x-4,m_Center.y-50 );       //�����ڱ����ϵ�λ��

	m_Name = name;
//	m_SingleAngle = singleangle;
//	m_SingleExpress = express;
    m_DianWei = units;

    m_Value = value;


}

WatchFace::~WatchFace()
{

}

CPoint WatchFace::ArithPoint( CPoint point1,double angle,double l )
{
	CPoint point;
	point.x = int( ( cos( angle*PI/180 )*l )+point1.x );
	point.y = int( ( sin( angle*PI/180 )*l )+point1.y );
	return point;
}

void WatchFace::SetParam( double value )
{
	m_Value = value;
}

void WatchFace::Draw( CDC *pDC,int i )
{
	CDC *dc = new CDC;
	CBitmap *bitmap = new CBitmap;
    CBitmap *old ;
	dc->CreateCompatibleDC( pDC );
	bitmap->CreateCompatibleBitmap( pDC,m_Width,m_Hight );
	old = dc->SelectObject( bitmap );
	dc->PatBlt( 0,0,m_Width,m_Hight,WHITENESS );
	if ( i == 1 )
	{
		Draw1( dc );        //��еʽ���ñ�
	}
	else
	{
		dc->FillSolidRect( 0,0,m_Width,m_Hight,RGB( 117,245,214 ) );
		Draw2( dc );        //����ʽ���ñ�
	}
	pDC->BitBlt( lefttop.x,lefttop.y,m_Width,m_Hight,dc,0,0,SRCCOPY );
    dc->SelectObject( old );
	delete dc;
	delete bitmap;
}

void WatchFace::Draw1( CDC *pDC )
{
    COLORREF old=pDC->SetTextColor( RGB( 0,0,0 ) );  //��ʾ������ɫ
	int oldmode=pDC->SetBkMode( TRANSPARENT );    //���ñ���Ϊ͸��ɫ
	CPen pen,*pPen;
	pen.CreatePen( PS_SOLID,1,RGB( 128,128,0 ) );
	pPen = pDC->SelectObject( &pen );
	pDC->SelectStockObject( NULL_BRUSH );
    CRect rect2 = CRect( m_Center.x-26,m_Center.y-26,m_Center.x+26,m_Center.y+26 );
    CPoint point1,point3;
	pDC->Ellipse( rect2 );
	pDC->TextOut( m_NamePoint.x,m_NamePoint.y,m_Name );
	CRect rect = CRect( m_Center.x-(m_Hight ),m_Center.y-(m_Hight ),m_Center.x+( m_Hight ),m_Center.y+( m_Hight ) );
	pDC->Arc( rect,m_EndPoint,m_BeginPoint );
    point1 = ArithPoint( m_Center,m_BigAngle,50 );
	pDC->Ellipse( point1.x-2,point1.y-2,point1.x+2,point1.y+2 );
	point1 = ArithPoint( m_Center,m_SmallAngle,50 );
	pDC->Ellipse( point1.x-2,point1.y-2,point1.x+2,point1.y+2 );
	DrawKeDu( pDC );              //���̶���
	DrawBiaoZhen( pDC );          //������
	pDC->SelectObject( pPen );
	DeleteObject( pen );
    pDC->SetTextColor( old );
	pDC->SetBkMode( oldmode );
}

void WatchFace::Draw2( CDC *pDC )
{
	CFont font,*pOldFont;
	font.CreateFont( m_Width/10,m_Hight/10,0,0,0,FALSE,FALSE,FALSE,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,DEFAULT_PITCH|FF_SWISS,FALSE );
	pOldFont = pDC->SelectObject( &font );
    COLORREF old=pDC->SetTextColor( RGB( 128,128,0 ) );  //��ʾ������ɫ
	int oldmode=pDC->SetBkMode( TRANSPARENT );    //���ñ���Ϊ͸��ɫ
    if ( m_Name == "v"||m_Name == "V" )
	{
		pDC->TextOut( m_Width/20,m_Hight/20,"��ѹ" );
	}
	else
	{
		if ( m_Name == "a"||m_Name == "A" )
		{
			pDC->TextOut( m_Width/20,m_Hight/20,"����" );
		}
		else
		{
			if ( m_Name == "r"||m_Name == "R" )
			{
				pDC->TextOut( m_Width/20,m_Hight/20,"����" );
			}
		}
	}
	pDC->TextOut( m_Width-3*m_Width/10,m_Hight-2*m_Hight/10,m_DianWei );
	pDC->SelectObject( pOldFont );
	DeleteObject( font );
	pDC->SetTextColor( old );
	pDC->SetBkMode( oldmode );
    CPoint point;
	point= CPoint( m_Width/8,m_Hight/4 );
	m_Num.SetParam( m_Value,point,6*m_Width/8,2*m_Hight/4,2,4 );
	m_Num.Draw( pDC );


}

void WatchFace::DrawKeDu( CDC *pDC )
{
//	CFont font,*pOldFont;
//	font.CreateFont( 7,5,-i,0,0,FALSE,FALSE,FALSE,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
//		DEFAULT_QUALITY,DEFAULT_PITCH|FF_SWISS,FALSE );
//	pOldFont = pDC->SelectObject( &font );
	CFont*	pOldFont = pDC->SelectObject( CFont::FromHandle( (HFONT)GetStockObject(DEFAULT_GUI_FONT) ) );

	COLORREF old=pDC->SetTextColor( FONTCOLOR );  //��ʾ������ɫ
	int oldmode=pDC->SetBkMode( TRANSPARENT );    //���ñ���Ϊ͸��ɫ
	CPen pen,*pPen;
	pen.CreatePen( PS_SOLID,1,RGB( 128,128,0 ) );
	pPen = pDC->SelectObject( &pen );
    CPoint point1,point2;
	int j = 0;
	for ( int i = int( m_BeginAngle );i<=int( m_EndAngle );i += int( m_SingleAngle ) )
	{
		point1 = ArithPoint( m_Center,double(i),m_Hight );
		if ( ( i-int( m_BeginAngle) )%30 == 0 )
		{
			point2 = ArithPoint( m_Center,double( i ),m_Hight-10 );
			char str[20];
			sprintf( str,"%.1f",float( j*m_SingleExpress ) );
			pDC->TextOut( point2.x-10,point2.y,str );
		}
		else
		{
    		point2 = ArithPoint( m_Center,double( i ),m_Hight-5 );
		}
		j++;
		pDC->MoveTo( point1 );
		pDC->LineTo( point2 );
	}
	m_Up = ( --j )*m_SingleExpress;
	pDC->TextOut( m_Width-30,m_Hight-20,m_DianWei );
	pDC->SelectObject( pPen );
	DeleteObject( pen );
	pDC->SelectObject( pOldFont );
//	DeleteObject( font );   
	pDC->SetTextColor( old );
	pDC->SetBkMode( oldmode );
}

void WatchFace::DrawBiaoZhen( CDC *pDC )         //������
{
	CPen pen,*pPen;
	pen.CreatePen( PS_SOLID,1,RGB( 255,0,0 ) );
	pPen = pDC->SelectObject( &pen );
	double angle;
	CPoint point1,point2;
	angle = m_BeginAngle+m_Value/m_SingleExpress*m_SingleAngle;
	if ( angle<m_SmallAngle )
	{
		angle = m_SmallAngle;
		m_SmallFlag = TRUE;
	}
	else
	{
		if ( angle>m_BigAngle )
		{
			angle = m_BigAngle;
			m_BigFlag = TRUE;
		}
		else
		{
			m_BigFlag = m_SmallFlag = FALSE;
		}
	}
    point1 = ArithPoint( m_Center,angle,m_Long );
	point2 = ArithPoint( m_Center,angle,26 );
	DrawJianTou( point1,angle,pDC );
	pDC->MoveTo( point2 );
	pDC->LineTo( point1 );
/*	if ( angle<m_BigAngle )
	{
		if ( m_Value<=m_Up )
		{
			DrawBaiDong( angle,pDC,m_PrevValue );
		}
		else
		{
			point1 = ArithPoint( m_Center,angle,m_Long );
			point2 = ArithPoint( m_Center,angle,26 );
			DrawJianTou( point1,angle,pDC );
			pDC->MoveTo( point2 );
			pDC->LineTo( point1 );
		}
	}
	else
	{
        angle = m_BigAngle;
		point1 = ArithPoint( m_Center,angle,m_Long );
		point2 = ArithPoint( m_Center,angle,26 );
		DrawJianTou( point1,angle,pDC );
		pDC->MoveTo( point2 );
		pDC->LineTo( point1 );
		m_BigFlag = TRUE;
	}*/
	pDC->SelectObject( pPen );
	DeleteObject( pen );
}

void WatchFace::DrawBaiDong( double angle,CDC *pDC,double m_PrevValue )
{
	double tempAngle,tempPrevAngle;
	CPoint point1,point2;
	tempPrevAngle = m_BeginAngle+m_PrevValue/m_SingleExpress*m_SingleAngle;
	tempAngle = (angle-m_BeginAngle)/( tempPrevAngle-m_BeginAngle );
	while ( abs(int( tempAngle )) )
	{
		if ( m_Number == 0 )
		{
			point1 = ArithPoint( m_Center,angle+tempAngle,m_Long );
			point2 = ArithPoint( m_Center,angle+tempAngle,26 );
			DrawJianTou( point1,angle+tempAngle,pDC );
			pDC->MoveTo( point2 );
			pDC->LineTo( point1 );
			
			tempAngle = tempAngle+0.1;
			m_Number = 1;
		}
		else
		{
        	point1 = ArithPoint( m_Center,angle-tempAngle,m_Long );
			point2 = ArithPoint( m_Center,angle-tempAngle,26 );
			DrawJianTou( point1,angle-tempAngle,pDC );
			pDC->MoveTo( point2 );
			pDC->LineTo( point1 );
			tempAngle = tempAngle+0.1;
			m_Number = 0;
		}
	}
	m_PrevValue = m_Value;
}

void WatchFace::DrawJianTou( CPoint point,double angle,CDC *pDC )   //����ͷ
{

	CPoint Point1;
	double jiao1;
	CPen pen,*pPen ;
	pen.CreatePen( PS_SOLID,1,RGB( 255,0,0 ) );
	pPen = pDC->SelectObject( &pen );
	jiao1 = -angle+JIANTOUANGLE;

	jiao1 = jiao1*PI/180;
	Point1.x = int( point.x-cos( jiao1 )*JIANTOULONG );
	Point1.y = int( point.y+sin( jiao1 )*JIANTOULONG );
	pDC->MoveTo( point );
	pDC->LineTo( Point1 );
    jiao1 = -angle-JIANTOUANGLE;
	jiao1 = jiao1*PI/180;
	Point1.x = int( point.x-cos( jiao1 )*JIANTOULONG );
	Point1.y = int( point.y+sin( jiao1 )*JIANTOULONG );
	pDC->MoveTo( point );
	pDC->LineTo( Point1 );
	pDC->SelectObject( pPen );
	DeleteObject( pen );
}

double WatchFace::ToAngle( double value )
{
	double tempangle;
	tempangle = m_BeginAngle+value/m_SingleExpress*m_SingleAngle;
	return tempangle;
}

double WatchFace::ToValue( double angle )
{
	double tempValue;
	tempValue = ( angle-m_BeginAngle )/m_SingleAngle*m_SingleExpress;
	return tempValue;
}


