// TextTool.h: interface for the CTextTool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXTTOOL_H__B39327F7_6F66_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_TEXTTOOL_H__B39327F7_6F66_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseTool.h"
#include "text.h"
class CTextTool : public CBaseTool  
{
public:
	CTextTool(CWnd* cWnd,CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	virtual ~CTextTool();
public:
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
	void Select();
	void DeSelect();

	void GetData(CBase* aa);
	void SetData(CBase* aa);

	CRect Count_Size(CString aqie);//�����Ĵ�С
	CSize AddToMySize(CSize total,CSize add);

	void ClearData();
public:

	CEdit* m_pEdit;
	CRect Size_Of_Text;
	CRect Display_Size;
	CString Content_Of_Text;
	BOOL NEWOROLD;
};

#endif // !defined(AFX_TEXTTOOL_H__B39327F7_6F66_11D4_BBD7_600000000ECD__INCLUDED_)
