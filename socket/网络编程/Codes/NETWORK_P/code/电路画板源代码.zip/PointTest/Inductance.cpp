// Inductance.cpp: implementation of the CInductance class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "Inductance.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInductance::CInductance(int nType,CBaseList* pBaseList) : CBase(ID_INDUCTANCE,pBaseList)
{
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "I";
	AddString(ID_INDUCTANCE);
	Value = 1;
}
CInductance::CInductance(CBase* pp1,CBase* pp2,CBaseList* pBaseList) : CBase(ID_INDUCTANCE,pBaseList)
{
	p1 = pp1;
	p2 = pp2;
	AddSon(p1);
	AddSon(p2);
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "I";
	AddString(ID_INDUCTANCE);
	Value = 1;
}
CInductance::~CInductance()
{
}
void CInductance::Draw(CDC* pDC)
{
	if(IsSelected()){
		CPen pen(PS_SOLID, 2,RED);
		CPen *Oldpen = pDC->SelectObject(&pen);

		pDC->MoveTo(left);
		pDC->LineTo(p1->CenterPoint);
		pDC->MoveTo(right);
		pDC->LineTo(p2->CenterPoint);

		pDC->Arc(GetRect(bb[0],CSize(10,10)),aa[0],left);
		pDC->Arc(GetRect(bb[1],CSize(10,10)),CenterPoint,aa[0]);
		pDC->Arc(GetRect(bb[2],CSize(10,10)),aa[1],CenterPoint);
		pDC->Arc(GetRect(bb[3],CSize(10,10)),right,aa[1]);

		pDC->SelectObject(Oldpen);
	}else{
		CPen pen(PS_SOLID, 2,BLACK);
		CPen *Oldpen = pDC->SelectObject(&pen);
		pDC->MoveTo(left);
		pDC->LineTo(p1->CenterPoint);
		pDC->MoveTo(right);
		pDC->LineTo(p2->CenterPoint);

		pDC->Arc(GetRect(bb[0],CSize(10,10)),aa[0],left);
		pDC->Arc(GetRect(bb[1],CSize(10,10)),CenterPoint,aa[0]);
		pDC->Arc(GetRect(bb[2],CSize(10,10)),aa[1],CenterPoint);
		pDC->Arc(GetRect(bb[3],CSize(10,10)),right,aa[1]);

		pDC->SelectObject(Oldpen);
	}
	TextOut(pDC);
}
void CInductance::SetPoint(CPoint pp)
{
	left = right = CenterPoint = pp;
	left = pp - CPoint(20,0);
	right = pp + CPoint(20,0);
	p1->CenterPoint = pp - CPoint(30,0);
	p2->CenterPoint = pp + CPoint(29,0);
	aa[0]  = left;
	aa[0].Offset(CSize(10,0));
	aa[1] = right;
	aa[1].Offset(CSize(-10,0));
	for(int i=0;i<4;i++){
		bb[i] = left;
		bb[i].Offset(CSize(5*(1+2*i),0));
	}
	RotateCell(TotalAngle);
}
void CInductance::OffSet(CSize size)
{
	CenterPoint.Offset(size);
	left.Offset(size);
	right.Offset(size);
	p1->OffSet(size);
	p2->OffSet(size);
	for(int i=0;i<4;i++){
		if(i<2)
			aa[i].Offset(size);
		bb[i].Offset(size);
	}
}
CRect CInductance::GetGraphRect()
{
	CPoint up_left,down_right;
	up_left = down_right = CenterPoint;
	up_left.Offset(-20,-10);
	down_right.Offset(20,0);
	return CRect(up_left,down_right);
}
void CInductance::RotateCell(double angle)
{
	left = Rotate(angle,left);
	right = Rotate(angle,right);
	p1->CenterPoint = Rotate(angle,p1->CenterPoint);
	p2->CenterPoint = Rotate(angle,p2->CenterPoint);
	for(int i=0;i<4;i++){
		if(i<2)
			aa[i] = Rotate(angle,aa[i]);
		bb[i] = Rotate(angle,bb[i]);
	}
}