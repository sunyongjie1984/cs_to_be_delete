// SelectTool.cpp: implementation of the CSelectTool class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "SelectTool.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSelectTool::CSelectTool(CWnd* cWnd,CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText)
		:CBaseTool(cWnd,pList,pOintList,pLineList,pText)
{
	SelectedPoint = NULL;
	SelectedPoint1 = NULL;
	PointSelect = FALSE;
	ObSelect = FALSE;
	ControlKey = FALSE;
	ArrowSelect = FALSE;
	for(int i=0;i<3;i++)
		cell[i] = "";
}

CSelectTool::~CSelectTool()
{
}
void CSelectTool::OnLButtonDown(UINT nFlags, CPoint point)
{
	CanDraw = TRUE;

	CaptureScr();

	CDC* pDC = m_pWnd->GetDC();

	ControlKey = (MK_CONTROL & nFlags);
	ObSelect = m_pList->PtInGraph(point,ControlKey);
	TextSelect = m_pTextList->PtInGraph(point,ControlKey);
	ArrowSelect = m_pList->PtInArrow(point);
	if(ArrowSelect){

	}else if(ObSelect||TextSelect){//select element
		if(SelectedPoint)
			SelectedPoint = NULL;
		Draw();
	}else if(PointSelect){//select point
		if(SelectedPoint){
			Draw();
			pDC->MoveTo(SelectedPoint->CenterPoint);
			pDC->LineTo(point);
		}
	}else{
		ObSelect = m_pLineList->PtInGraph(point,ControlKey);
		if(ObSelect){
			Draw();
		}
	}
	BeginPoint = point;//passed
	//Draw();
	m_pWnd->ReleaseDC(pDC);

}
void CSelectTool::OnLButtonUp(UINT nFlags, CPoint point)
{
	if(!CanDraw) return;
	CanDraw = FALSE;
	
	if(ObSelect||TextSelect){
		if(SelectedPoint)
			SelectedPoint = NULL;
//		EndPoint = point;
//		m_pList->MoveSelected(EndPoint-BeginPoint);
//		m_pTextList->MoveSelected(EndPoint-BeginPoint);
//		BeginPoint = EndPoint;
		m_pTextList->ReSetMoveFlag();
		Draw();
	}else if(PointSelect){
		if(SelectedPoint){
			SelectedPoint1 = m_PointList->PtInGraph(point);
			if((SelectedPoint1!=SelectedPoint)&&SelectedPoint1){
				m_pLine = new CLine(SelectedPoint,SelectedPoint1,m_pLineList);
				SelectedPoint->AddSon(m_pLine);
				SelectedPoint1->AddSon(m_pLine);
			}
			SelectedPoint = NULL;
			SelectedPoint1 = NULL;
		}
	}else{
		EndPoint = point;
		m_pList->ObInRegion(GetRect(BeginPoint,EndPoint));
	}
	ReleaseScr();
	Draw();
}
void CSelectTool::OnMouseMove(UINT nFlags, CPoint point)
{
	if(!CanDraw){
		m_PointList->DeSelect();
		SelectedPoint = m_PointList->PtInGraph( point );
		if(!SelectedPoint)
			PointSelect = FALSE;
		Draw();
	}
	if(CanDraw){
	if(ArrowSelect){
		EndPoint = point;
		m_pList->MovePoint(point,EndPoint-BeginPoint);
		BeginPoint = EndPoint;
		Draw();
	}else if(ObSelect||TextSelect){
			if(SelectedPoint)
				SelectedPoint = NULL;
			EndPoint = point;
			m_pList->MoveSelected(EndPoint-BeginPoint);
			m_pTextList->MoveSelected(EndPoint-BeginPoint);
			BeginPoint = EndPoint;
			Draw();
		}else if(PointSelect){
			if(SelectedPoint){
				SelectedPoint1 = m_PointList->PtInGraph(point);
				Draw();
				CDC* pDC = m_pWnd->GetDC();
				pDC->MoveTo(SelectedPoint->CenterPoint);
				pDC->LineTo(point);
				m_pWnd->ReleaseDC(pDC);
			}
		}else{
			EndPoint = point;//passed
			Draw(BeginPoint,EndPoint);
		}
	}else if(SelectedPoint){
		PointSelect = TRUE;
	}
}
void CSelectTool::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	CBase* aa;
	UINT nId;
	aa = m_pList->PtDbInGraph(point);
	if(aa){
		if(GetCellString(aa)){
			CPropertiy dlg(cell[0]);
			dlg.m_value = aa->Value;
			dlg.m_properte = cell[1];
			dlg.m_unit = cell[2];
			dlg.m_remark = aa->Content_Of_Ob;
			nId = aa->GetType();
			if(nId==ID_RHEOSTAT||nId==ID_VOLTAGE_METER||nId==ID_CURRENT_METER){
				dlg.m_MaxValue = aa->MaxValue;
			}
			if(IDOK == dlg.DoModal()){
				aa->Value = dlg.m_value;
				aa->Content_Of_Ob = dlg.m_remark;
				if(nId==ID_RHEOSTAT||nId==ID_VOLTAGE_METER||nId==ID_CURRENT_METER){
					aa->MaxValue = dlg.m_MaxValue;
					aa->SetEValue();
				}

			}
		}
	}
}
BOOL CSelectTool::GetCellString(CBase* aa)
{
	switch(aa->GetType()){
	case ID_RESISTANCE:
		cell[0] = "��������";
		cell[1] = "������ֵ";
		cell[2] = "ŷķ";
		break;
	case ID_RHEOSTAT:
		cell[0] = "����������";
		cell[1] = "��������ֵ";
		cell[2] = "ŷķ";
		break;
	case ID_CAPACITANCE:
		cell[0] = "��������";
		cell[1] = "����ֵ";
		cell[2] = "΢��";
		break;
	case ID_DIODE:
		cell[0] = "����������";
		cell[1] = "������������ֵ";
		cell[2] = "ŷķ";
		break;
	case ID_GROUND:
		cell[0] = "�ӵ�����";
		cell[1] = "�ӵ�����ֵ";
		cell[2] = "ŷķ";
		break;
	case ID_INDUCTANCE:
		cell[0] = "�������";
		cell[1] = "���ֵ";
		cell[2] = "��";
		break;
	case ID_VOLTAGE_METER:
		cell[0] = "��ѹ������";
		cell[1] = "��ѹ������ֵ";
		cell[2] = "ŷķ";
		break;
	case ID_CURRENT_METER:
		cell[0] = "����������";
		cell[1] = "����������ֵ";
		cell[2] = "ŷķ";
		break;
	case ID_SWITCH:
		cell[0] = "��������";
		cell[1] = "��������ֵ";
		cell[2] = "ŷķ";
		break;
	case ID_POWER:
		cell[0] = "��Դ����";
		cell[1] = "��Դ��ѹֵ";
		cell[2] = "����";
		break;
	case ID_LIGHT:
		cell[0] = "�������";
		cell[1] = "�����ֵ";
		cell[2] = "ŷķ";
		break;
	default:
		return FALSE;	
	}
	return TRUE;
}