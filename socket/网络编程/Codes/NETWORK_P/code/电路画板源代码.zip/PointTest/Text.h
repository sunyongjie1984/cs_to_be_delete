// Text.h: interface for the CText class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXT_H__B39327F5_6F66_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_TEXT_H__B39327F5_6F66_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Base.h"

class CText : public CBase
{
public:
	CText(int nType,CBaseList* pBaseList);
	CText(CBaseList* pBaseList);
	virtual ~CText();
public:
	int PtInOb(CPoint point);
	void OffSet(CSize size);
	BOOL m_bMoving;
//	CRect Count_Size(CDC* mdc,CString aqie);//�����Ĵ�С
//	CSize AddToMySize(CSize total,CSize add);
	void SetText(CString str);

	void Draw(CDC* pDC);
	void Draw_Text(CDC* MemDC,CString text,int a ,int b);
	void TextMyOut1(CDC* pDC,int xx,int yy,CString string);


};

#endif // !defined(AFX_TEXT_H__B39327F5_6F66_11D4_BBD7_600000000ECD__INCLUDED_)
