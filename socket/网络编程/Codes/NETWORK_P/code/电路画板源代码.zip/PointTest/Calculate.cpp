// Calculate.cpp: implementation of the CCalculate class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "Calculate.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCalculate::CCalculate(CJointList *p,int datum )
{
	m_nDatumMark=datum;
	m_pJointList=p;
	m_bIsNewX=false;
	for( int i=0;i<100;i++ )
	{
		m_pArrayPower[i] = NULL;
		m_pCopyPower[i] = NULL;
	}
}

CCalculate::~CCalculate()
{
	m_listOnePower.RemoveAll();
	POSITION pos=m_capaList.GetHeadPosition();
	while(pos!=NULL)
	{
		CAElement *pCapa=m_capaList.GetNext(pos);
		delete pCapa;
	}
	for(int i=0;i<100;i++)
	{
		if(m_pArrayPower[i])
		{
			delete m_pArrayPower[i];
			m_pArrayPower[i] = NULL;
		}
		if(m_pCopyPower[i])
		{
			delete m_pCopyPower[i];
			m_pCopyPower[i] = NULL;
		}
	}
}
void CCalculate::EstablishEquation()
{
	if(m_listOnePower.IsEmpty())
	{

	}
	else
	{
		int i=0;
		CAJoint *pJoint;
		POSITION pos;
		pos=m_listOnePower.GetHeadPosition();
		while(pos!=NULL)
		{
			pJoint=m_listOnePower.GetAt(pos);
			m_pListElement.AddTail(&((pJoint->pElementList).m_pListElement));
			BuildMatrix(i,pJoint);
			m_listOnePower.GetNext(pos);
			i++;
			m_pListElement.RemoveAll();
		}
	}	
}
void CCalculate::BuildMatrix(int i,CAJoint *pJoint)
{

		CAElement *pElement;
		POSITION pos;
		pos=m_pListElement.GetHeadPosition();
//		pos=(pJoint->pElementList).m_pListElement.GetHeadPosition();
		while(pos!=NULL)
		{
			CAJoint *p1,*p2,*p;
			pElement=m_pListElement.GetNext(pos);
//			pElement=(pJoint->pElementList).m_pListElement.GetNext(pos);
			p1=(pElement->GetJointStruct())->pJoint1;
			p2=(pElement->GetJointStruct())->pJoint2;
			if(p1==pJoint)
			{
				p=p2;
			}
			else
			{
				p=p1;
			}
	//		p->SearchElecSource();
			if(p->IsHoldElecSource())
			{
				m_fPowerOfR[i]+=(p->GetVoltage())/(pElement->GetValue());
			}
			else
			{
				p->m_dReciprocalOfR[i]+=1/(pElement->GetValue());
			}
				pJoint->m_dReciprocalOfR[i]+=-1/(pElement->GetValue());
		}
}
void CCalculate::SetMatrixValue()
{
	if(m_pOnePowerJointList->m_pListJoint.IsEmpty())
	{

	}
	else
	{
		m_pOnePowerJointList->AdjustJoint(m_pOnePowerJointList->m_pOldList);
		m_listOnePower.RemoveAll();
		m_listOnePower.AddTail(&(m_pOnePowerJointList->m_pListJoint));
		EstablishEquation();
		int i;
		int count1=m_listOnePower.GetCount();//�˴����������������е�Դ�Ľڵ�
		for(i=0;i<count1;i++)
		{
			int j=0;
			POSITION pos;
			CAJoint *pJoint;
			pos=m_listOnePower.GetHeadPosition();
			while(pos!=NULL)
			{
				pJoint=m_listOnePower.GetAt(pos);
				m_dMatrix[i][j]=pJoint->m_dReciprocalOfR[i];
				m_listOnePower.GetNext(pos);
				j++;
			}
			m_dMatrix[i][j]=m_fPowerOfR[i];
		}
	}
}
void CCalculate::Calculate()
{
	int k,i,j;
	SetMatrixValue();
	int nCalJointNum=m_listOnePower.GetCount();
	if(nCalJointNum>0)
	{
		x=new float[nCalJointNum];
		m_bIsNewX=true;
		for(i=0;i<nCalJointNum;i++)
		{
			x[i]=0;
		}
		int m=0;
		float a,b;
		for(k=0;k<nCalJointNum;k++)
		{
			if(m_dMatrix[k][m]!=0.0)
			{
				a=m_dMatrix[k][m];
				for(i=0;i<(nCalJointNum+1);i++)
				{
					m_dMatrix[k][i]=m_dMatrix[k][i]/a;
				}
				for(i=k+1;i<nCalJointNum;i++)
				{
					if(m_dMatrix[i][m]!=0)
					{
						b=m_dMatrix[i][m];
						for(j=m;j<(nCalJointNum+1);j++)
						{
							m_dMatrix[i][j]=m_dMatrix[i][j]/b;
							m_dMatrix[i][j]=m_dMatrix[i][j]-m_dMatrix[k][j];
						}	
					}
				}
			}
			m++;
		}


		for(i=nCalJointNum-1;i>=0;i--)
		{
			if(m_dMatrix[i][i]==1)
			{
				k=i;
				break;
			}
		}


		for(i=k;i>=0;i--)
		{
			x[i]=-m_dMatrix[i][k+1];
			if(i<k)
			{
				for(j=k;j>i;j--)
				{
					x[i]=x[i]-m_dMatrix[i][j]*x[j];
				}
			}
		}
	}
}
void CCalculate::RealCalculate()
{
	m_pJointList->CreateCopyJointList(m_pJointList->m_pOldList,m_pJointList->m_pSaveList);
	SavePowerInArray(m_pJointList->m_pOldList);
	CreateCopyPowerArray(m_pArrayPower,m_pCopyPower);
	m_pJointList->CreateCopyJointList(m_pJointList->m_pSaveList,m_pJointList->m_pCopyList);
	m_pJointList->CreateCopyJointList(m_pJointList->m_pSaveList,m_pJointList->m_pOldList);
	int nPowerNum = m_nPowerNum;
//	AddPowerResistance(m_pJointList->m_pSaveList);
	for(int l = 0;l< m_nPowerNum;l++)
	{
		
//		AddPowerResistance(m_pJointList->m_pOldList);
		SavePowerInArray(m_pJointList->m_pOldList);
		RemovePowerFromJoint(l);
		m_pJointList->DealWithSwitch(m_pJointList->m_pOldList);
		m_pJointList->DealWithAmpermeter(m_pJointList->m_pOldList);
		m_pJointList->DealWithVoltmeter(m_pJointList->m_pOldList);
		float fAverageOfR = m_pJointList->GetAverageOfResistance(m_pJointList->m_pOldList);
		BOOL bIsDiode = m_pJointList->IsExistSpecEl(ID_DIODE,m_pJointList->m_pOldList,&(m_pJointList->m_pDiodeList));
		if(bIsDiode)
		{
			m_pJointList->AllElsToOthers(ID_DIODE,ID_RESISTANCE,fAverageOfR,m_pJointList->m_pOldList);
			OnePowerCalculate(l);
			m_pJointList->CreateCopyJointList(m_pJointList->m_pCopyList,m_pJointList->m_pOldList);
		//	AddPowerResistance(m_pJointList->m_pSaveList);
//			AddPowerResistance(m_pJointList->m_pOldList);
			m_pJointList->IsExistSpecEl(ID_DIODE,m_pJointList->m_pOldList,&(m_pJointList->m_pDiodeList));
			SavePowerInArray(m_pJointList->m_pOldList);
			RemovePowerFromJoint(l);
			m_pJointList->DealWithSwitch(m_pJointList->m_pOldList);
			m_pJointList->DealWithAmpermeter(m_pJointList->m_pOldList);
			m_pJointList->DealWithVoltmeter(m_pJointList->m_pOldList);
			m_pJointList->AdjustPloarityOfDiode(l);
			m_pJointList->SetZeroVoltage(l,m_pJointList->m_pSaveList);
			OnePowerCalculate(l);
		}
		else
		{
			OnePowerCalculate(l);
		}
		m_pJointList->CreateCopyJointList(m_pJointList->m_pCopyList,m_pJointList->m_pOldList);
	}
	POSITION pos2=m_pJointList->m_pSaveList->GetHeadPosition();
	while(pos2!=NULL)
	{
		CAJoint *p10=m_pJointList->m_pSaveList->GetNext(pos2);
		float v=0;
		for(int i=0;i<nPowerNum;i++)
		{
			v+=p10->m_fRealVoltage[i];
		}
		p10->SetVoltage(v);
	}
	m_pJointList->SetAllElCurrent(m_pJointList->m_pSaveList);
	m_pJointList->SetVoltmeterValue(m_pJointList->m_pSaveList);
	m_pJointList->SetVoltOutput(&(m_pJointList->m_VoltList),m_pJointList->m_pSaveList);
	m_pJointList->SetAmperOutput(&(m_pJointList->m_AmperList),m_pJointList->m_pSaveList);
}
void CCalculate::SavePowerInArray(CList<CAJoint*,CAJoint*>*pList)//save all powers in a array (m_pArrayPower)
{
	m_pJointList->SetAllIsAllPowerInList(false,pList);
	m_nPowerNum=0;
	if(m_pArrayPower[0])
	{
		for(int i=0;i<100;i++)
		{
			if(m_pArrayPower[i])
			{
				delete m_pArrayPower[i];
				m_pArrayPower[i]=NULL;
			}
		}
		if(pList->IsEmpty())
		{
		}
		else
		{
			POSITION pos=pList->GetHeadPosition();
			while(pos!=NULL)
			{
				CAJoint *p=pList->GetAt(pos);
	//			p->SearchElecSource();
				if(p->IsHoldElecSource())
				{
					POSITION pos1=p->pElementList.m_pListElement.GetHeadPosition();
					while(pos1!=NULL)
					{
						CAElement *pE=p->pElementList.m_pListElement.GetNext(pos1);
						if(pE->GetType()==ID_POWER&&!pE->IsAsPower())
						{
							BOOL bIsParalleCo=DealParallelConnectionPower(pE,m_pArrayPower,pList);
							if(!bIsParalleCo)
							{
								float value = pE->GetValue();
								int index = pE->GetIndex();
								int order1 = pE->GetJointStruct()->pJoint1->GetOrder();
								int order2 = pE->GetJointStruct()->pJoint2->GetOrder();
								CAElement* pNewE = m_pJointList->NewElement( ID_POWER,value );
								pNewE->SetIndex( index );
								pNewE->SetOrderStruct( order1,order2 );
								m_pArrayPower[m_nPowerNum]=pNewE;//save all powers in array;
								m_nPowerNum++;
							}
							else pos1=p->pElementList.m_pListElement.GetHeadPosition();
							pE->SetIsAsPower(true);
						}
					}
				}
				pList->GetNext(pos);
			}
		}
		for( i=0;i<100;i++)
		{
			if(m_pArrayPower[i])
			{
				delete m_pArrayPower[i];
				m_pArrayPower[i]=NULL;
			}
		}
		CreateCopyPowerArray(m_pCopyPower,m_pArrayPower);
	}
	else
	{
		if(pList->IsEmpty())
		{
		}
		else
		{
			POSITION pos=pList->GetHeadPosition();
			while(pos!=NULL)
			{
				CAJoint *p=pList->GetAt(pos);
	//			p->SearchElecSource();
				if(p->IsHoldElecSource())
				{
					POSITION pos1=p->pElementList.m_pListElement.GetHeadPosition();
					while(pos1!=NULL)
					{
						CAElement *pE=p->pElementList.m_pListElement.GetNext(pos1);
						if(pE->GetType()==ID_POWER&&!pE->IsAsPower())
						{
							BOOL bIsParalleCo=DealParallelConnectionPower(pE,m_pArrayPower,pList);
							if(!bIsParalleCo)
							{
								float value = pE->GetValue();
								int index = pE->GetIndex();
								CAJoint* p1 = pE->GetJointStruct()->pJoint1;
								CAJoint* p2 = pE->GetJointStruct()->pJoint2;
								CAElement* pNewE = m_pJointList->NewElement( ID_POWER,value );
								pNewE->SetIndex( index );
								pNewE->SetOrderStruct(p1->GetOrder(),p2->GetOrder() );
								m_pArrayPower[m_nPowerNum]=pNewE;//save all powers in array;
								m_nPowerNum++;
							}
							else pos1=p->pElementList.m_pListElement.GetHeadPosition();
							pE->SetIsAsPower(true);
						}
					}
				}
				pList->GetNext(pos);
			}
		}
	}
	
}
void CCalculate::RemovePowerFromJoint(int k)
{
	//SavePowerInArray();
	//P0SITION pos=p->pElementList->m_pListElement.GetHeadPosition();
	for(int i=0;i<m_nPowerNum;i++)
	{
		if(i!=k&&m_pArrayPower[i]->GetType()==ID_POWER)
		{
			CAElement* pPower = m_pArrayPower[i];
			CAElement* pPInList = m_pJointList->GetElement(pPower,m_pJointList->m_pOldList);
			CAElement *pNewE = m_pJointList->NewElement(ID_INDUCTANCE,1);
			CAElement *pEInSave = m_pJointList->GetElement(pPInList,m_pJointList->m_pSaveList);
			pEInSave->SetIsAsInductor(true);
			CAJoint* p1 = pPInList->GetJointStruct()->pJoint1;
			CAJoint* p2 = pPInList->GetJointStruct()->pJoint2;
			int index   = pPInList->GetIndex();
			pNewE->SetIndex( index );
			POSITION posDel1 = p1->pElementList.m_pListElement.Find(pPInList,NULL);
			POSITION posDel2 = p2->pElementList.m_pListElement.Find(pPInList,NULL);
			p2->pElementList.m_pListElement.RemoveAt(posDel2);
			p1->pElementList.m_pListElement.RemoveAt( posDel1 );
			delete pPInList;
			pNewE->SetStructJoint(p1,p2);
			pNewE->SetOrderStruct(p1->GetOrder(),p2->GetOrder() );
			p1->pElementList.m_pListElement.AddTail(pNewE);
			p2->pElementList.m_pListElement.AddTail(pNewE);
		}
	}
	/*		CAJoint *p1=pPInList->GetJointStruct()->pJoint1;//power[i]'s joint
			CAJoint *p2=pPInList->GetJointStruct()->pJoint2;
			POSITION pos1=p1->pElementList.m_pListElement.GetHeadPosition();
			int nNoPower1=0,nNoPower2=0;//the unpower numbers of p1 and p2;
			CAElement *arrayP1[100],*arrayP2[100];
			for(int n=0;n<100;n++)
			{
				arrayP1[n]=NULL;
				arrayP2[n]=NULL;
			}
			//the unpower of p1 and p2
			//which joint will be Gotten rid of?
			while(pos1!=NULL)//p1?
			{
				CAElement *pE=p1->pElementList.m_pListElement.GetAt(pos1);
				if(pE->GetIndex()==m_pArrayPower[k]->GetIndex()||pE->GetType()!=ID_POWER)
				{
					arrayP1[nNoPower1]=pE;
					nNoPower1++;
				}
				p1->pElementList.m_pListElement.GetNext(pos1);
			}
			pos1=p2->pElementList.m_pListElement.GetHeadPosition();
			while(pos1!=NULL)//p2?
			{
				CAElement *pE=p2->pElementList.m_pListElement.GetAt(pos1);
				if(pE->GetIndex()==m_pArrayPower[k]->GetIndex()||pE->GetType()!=ID_POWER)
				{
					arrayP2[nNoPower2]=pE;
					nNoPower2++;
				}
				p2->pElementList.m_pListElement.GetNext(pos1);
			}
			if(nNoPower1>=2)
			{
				if(nNoPower2>=2)
				{
//					m_pArrayPower[i]->pRemove=NULL;
					POSITION posDel1=p1->pElementList.m_pListElement.Find(pPInList,NULL);
					POSITION posDel2=p2->pElementList.m_pListElement.Find(pPInList,NULL);
					p1->pElementList.m_pListElement.RemoveAt(posDel1);
					p2->pElementList.m_pListElement.RemoveAt(posDel2);
					delete pPInList;
				}
				else//get rid of p2
				{
			//		m_pArrayPower[i]->pRemove=p2;
			//		m_pArrayPower[i]->pNoRemove=p1;
					pos1=m_pOnePowerJointList->m_pListJoint.Find(p2,NULL);
					m_pOnePowerJointList->m_pListJoint.RemoveAt(pos1);
				//	int count22=p2->pElementList.m_pListElement.GetCount()-1;
				//	for(int j=0;j<nNoPower2;j++)
					POSITION pos22=p2->pElementList.m_pListElement.GetHeadPosition();
					while(pos22!=NULL)
					//for(int j=0;j<count22;j++)
					{
						CAElement *pE22=p2->pElementList.m_pListElement.GetNext(pos22);
						if(pE22!=pPInList)
						{
							ChangeElement(p1,p2,pE22);
						}
					//		ChangeElement(p1,p2,arrayP2[j]);
					}
					POSITION posDel1=p1->pElementList.m_pListElement.Find(pPInList,NULL);
					POSITION posDel2=p2->pElementList.m_pListElement.Find(pPInList,NULL);
					p1->pElementList.m_pListElement.RemoveAt(posDel1);
					p2->pElementList.m_pListElement.RemoveAt(posDel2);
					delete pPInList;
					delete p2;
				}
			}
			else//get rid of p1
			{
//				m_pArrayPower[i]->pRemove=p1;
//				m_pArrayPower[i]->pNoRemove=p2;
				pos1=m_pOnePowerJointList->m_pListJoint.Find(p1,NULL);
				m_pOnePowerJointList->m_pListJoint.RemoveAt(pos1);
			//	int count11=p1->pElementList.m_pListElement.GetCount()-1;
			//	for(int j=0;j<nNoPower1;j++)
				POSITION pos11=p1->pElementList.m_pListElement.GetHeadPosition();
				while(pos11!=NULL)
			//	for(int j=0;j<count11;j++)
				{
					CAElement *pE11=p1->pElementList.m_pListElement.GetNext(pos11);
					if(pE11!=pPInList)
					{
						ChangeElement(p2,p1,pE11);
					}
					//	ChangeElement(p2,p1,arrayP1[j]);
				}
					POSITION posDel1=p1->pElementList.m_pListElement.Find(pPInList,NULL);
					POSITION posDel2=p2->pElementList.m_pListElement.Find(pPInList,NULL);
					p1->pElementList.m_pListElement.RemoveAt(posDel1);
					p2->pElementList.m_pListElement.RemoveAt(posDel2);
					delete pPInList;
					delete p1;
			}
		}
	}
*/
}

//add the elements of p2 to p1
void CCalculate::ChangeElement(CAJoint *p1, CAJoint *p2,CAElement* pE)
{
		BOOL bIsExist = false;
		POSITION posE = p1->pElementList.m_pListElement.GetHeadPosition();
		while(posE != NULL)
		{
			CAElement *pElement = p1->pElementList.m_pListElement.GetNext(posE);
			if(pElement == pE)
			{
				bIsExist = true;
				break;
			}
			else
			{
				bIsExist = false;
			}
		}
		if(!bIsExist)
		{
			p1->pElementList.m_pListElement.AddTail(pE);
		//p1 as the joint of p2's elements 
		}
		if(p2==pE->GetJointStruct()->pJoint1)
		{
			pE->SetStructJoint(p1,pE->GetJointStruct()->pJoint2);
		}
		else
		{
			pE->SetStructJoint(pE->GetJointStruct()->pJoint1,p1);
		}
	
}
void CCalculate::Processor(int powerArrayOrder)
{
	CAJoint *pJoint1,*pJoint2;
	int order;
	int k=0;
	POSITION pos1=m_pJointList->m_pOldList->GetHeadPosition();
	while(pos1!=NULL)
	{
		pJoint1=m_pJointList->m_pOldList->GetNext(pos1);
		order=pJoint1->GetOrder();
		pJoint2=m_pJointList->GetJoint(order,m_pJointList->m_pSaveList);
	//	ASSERT(pJoint2!=NULL);
		if( !pJoint2->IsSetVoltage() )
		{
			pJoint2->m_fVoltage[powerArrayOrder]=x[k];
			pJoint2->SetIsSetVoltage( true );
			k++;
		}
	}
	CAElement* pEInList = m_pJointList->GetElement( m_pArrayPower[powerArrayOrder],m_pJointList->m_pSaveList);
	CAJoint* p1 = pEInList->GetJointStruct()->pJoint1;
	CAJoint* p2 = pEInList->GetJointStruct()->pJoint2;
	p1->m_fVoltage[powerArrayOrder] = 0;
	p2->m_fVoltage[powerArrayOrder] = pEInList->GetValue();
	p1->SetIsSetVoltage( true );
	p2->SetIsSetVoltage( true );
/*	CAJoint *pJoint;
	POSITION pos2=m_pJointList->m_pSaveList->GetHeadPosition();
	while(pos2!=NULL)
	{
		pJoint=m_pJointList->m_pSaveList->GetNext(pos2);
		if(pJoint->m_fVoltage[powerArrayOrder]==0)
		{
			POSITION pos3=pJoint->pElementList.m_pListElement.GetHeadPosition();
			while(pos3!=NULL)
			{
				CAElement *pElement=pJoint->pElementList.m_pListElement.GetNext(pos3);
				if(pElement->GetType()==ID_POWER)//Is a power?
				{
					pJoint1=pElement->GetJointStruct()->pJoint1;
					pJoint2=pElement->GetJointStruct()->pJoint2;
					if(pElement==m_pArrayPower[powerArrayOrder])//Is power[powerArrayOrder]
					{
						pJoint1->m_fVoltage[powerArrayOrder]=0;
						pJoint2->m_fVoltage[powerArrayOrder]=m_pArrayPower[powerArrayOrder]->GetValue();
						pJoint1->SetIsSetVoltage( true );
						pJoint2->SetIsSetVoltage( true );
						break;
					}
					else
					{
						if(pJoint1==pJoint)
						{
							pJoint->m_fVoltage[powerArrayOrder]=pJoint2->m_fVoltage[powerArrayOrder];
						}
						else
						{
							pJoint->m_fVoltage[powerArrayOrder]=pJoint1->m_fVoltage[powerArrayOrder];
						}
						pJoint->SetIsSetVoltage( true );
					}
				}
				
			}
		}
	}
	*/
}

void CCalculate::InitialParameter()
{
	int nJointCount=m_pJointList->m_pOldList->GetCount();
	int i,j;
	m_fPowerOfR=new float[nJointCount-2];
	for(i=0;i<nJointCount-2;i++)
	{
		m_fPowerOfR[i]=0;
	}
//	m_dMatrix=new float[nJointCount-2][nJointCount-1];
	for(i=0;i<100;i++)
	{
		for(j=0;j<100;j++)
		{
			m_dMatrix[i][j]=0;
		}
	}
}

void CCalculate::SetValueAboutCapacity(int nPowerArrayOrder)
{
	POSITION posCapa=m_capaList.GetTailPosition();
	while(posCapa!=NULL)
	{
		CAElement *pCapa=m_capaList.GetPrev(posCapa);
		//CAJoint *p1=pCapa->GetJointStruct()->pJoint1;
	//	CAJoint *p2=pCapa->GetJointStruct()->pJoint2;
		int order1 = pCapa->GetOrderStruct()->order1;
		int order2= pCapa->GetOrderStruct()->order2;
		CAJoint *p1Save=m_pJointList->GetJoint(order1,m_pJointList->m_pSaveList);
		CAJoint *p2Save=m_pJointList->GetJoint(order2,m_pJointList->m_pSaveList);
		CAJoint *p11=m_pJointList->GetJoint(p1Save->m_nEqualValueOrder,m_pJointList->m_pSaveList);
		CAJoint *p22=m_pJointList->GetJoint(p2Save->m_nEqualValueOrder,m_pJointList->m_pSaveList);
		if( !p1Save->IsSetVoltage() && p11->IsSetVoltage() )
		{
			p1Save->m_fVoltage[nPowerArrayOrder]=p11->m_fVoltage[nPowerArrayOrder];
			p1Save->SetIsSetVoltage( true );
		}
		if( !p2Save->IsSetVoltage() && p22->IsSetVoltage() )
		{
			p2Save->m_fVoltage[nPowerArrayOrder]=p22->m_fVoltage[nPowerArrayOrder];
			p2Save->SetIsSetVoltage( true );
		}
		SetJointValueInCapaList(p1Save,pCapa,nPowerArrayOrder);
		SetJointValueInCapaList(p2Save,pCapa,nPowerArrayOrder);
	}
}
void CCalculate::SetJointValueInCapaList(CAJoint *pJoint,CAElement *pElement,int nPowerArrayOrder)
{
	CList<int,int>* OrderList=pElement->GetCapacityOrderList(pJoint);
	POSITION pos=OrderList->GetHeadPosition();
	if(pos!=NULL)
	{
		OrderList->GetNext(pos);
	}
	while(pos!=NULL)
	{
		int order=OrderList->GetNext(pos);
		CAJoint *p=m_pJointList->GetJoint(order,m_pJointList->m_pSaveList);
		if( !p->IsSetVoltage() && pJoint->IsSetVoltage() )
		{
			p->m_fVoltage[nPowerArrayOrder]=pJoint->m_fVoltage[nPowerArrayOrder];
			p->SetIsSetVoltage( true );
		}
	}
	
}

void CCalculate::AdjustInductor()
{
	POSITION posJ = m_pJointList->m_pOldList->GetHeadPosition();
	while(posJ != NULL)
	{
		CAJoint *pJoint = m_pJointList->m_pOldList->GetNext(posJ);
		POSITION posIn = pJoint->pElementList.m_pListElement.GetHeadPosition();
		while(posIn != NULL)
		{
			CAElement *pIn = pJoint->pElementList.m_pListElement.GetNext(posIn);
			if(pIn->GetType() == ID_INDUCTANCE)
			{
				CAJoint *p1 = pIn->GetJointStruct()->pJoint1;
				CAJoint *p2 = pIn->GetJointStruct()->pJoint2;
				POSITION posE = p2->pElementList.m_pListElement.GetHeadPosition();
				while(posE != NULL)
				{	
					CAElement *pE = p2->pElementList.m_pListElement.GetNext(posE);
					if(pE != pIn)
					{
						ChangeElement(p1,p2,pE);
					}
				}
				POSITION posDelIn1 = p1->pElementList.m_pListElement.Find(pIn,NULL);
				POSITION posDelIn2 = p2->pElementList.m_pListElement.Find(pIn,NULL);
				p1->pElementList.m_pListElement.RemoveAt(posDelIn1);
				p2->pElementList.m_pListElement.RemoveAt(posDelIn2);
				delete pIn;
				POSITION posDelJ = m_pJointList->m_pOldList->Find(p2,NULL);
				m_pJointList->m_pOldList->RemoveAt(posDelJ);
				delete p2;
				posJ = m_pJointList->m_pOldList->GetHeadPosition();
				break;
		//		posJ = m_pJointList->m_pOldList->GetHeadPosition();
			}
		}
	}
}

void CCalculate::SetValueAboutInductor(int nPowerArrayOrder)
{
	POSITION posJ = m_pJointList->m_pSaveList->GetHeadPosition();
	while(posJ != NULL)
	{
		CAJoint *pJoint = m_pJointList->m_pSaveList->GetNext(posJ);
		POSITION posIn = pJoint->pElementList.m_pListElement.GetHeadPosition();
		while(posIn != NULL)
		{
			CAElement *pIn = pJoint->pElementList.m_pListElement.GetNext(posIn);
			if(pIn->GetType() == ID_INDUCTANCE || pIn->IsAsInductor())
			{
				CAJoint *p1 = pIn->GetJointStruct()->pJoint1;
				CAJoint *p2 = pIn->GetJointStruct()->pJoint2;
				if( !p1->IsSetVoltage() && p2->IsSetVoltage())
				{
					p1->m_fVoltage[nPowerArrayOrder] = p2->m_fVoltage[nPowerArrayOrder];
					p1->SetIsSetVoltage( true );
				}
				else if( !p2->IsSetVoltage() && p1->IsSetVoltage() )
				{
					p2->m_fVoltage[nPowerArrayOrder] = p1->m_fVoltage[nPowerArrayOrder];
					p2->SetIsSetVoltage( true );
				}
			}
		}
	}
}

BOOL CCalculate::DealParallelConnectionPower(CAElement *pE,CAElement **pEArray,CList<CAJoint*,CAJoint*>*pList)
{  
	int i;
	if(pEArray[0] != NULL )
	{
		for(i=0;i<m_nPowerNum;i++)
		{
			CAElement *pEInArray=pEArray[i];
			CAElement *pEInList = m_pJointList->GetElement( pEInArray,pList );
			BOOL bIsSameJoint=IsSameJoint(pE,pEInList);
			if(bIsSameJoint)
			{
				if((pEInList->GetValue())<(pE->GetValue()))
				{
					CAJoint *p1=pEInList->GetJointStruct()->pJoint1;
					CAJoint *p2=pEInList->GetJointStruct()->pJoint2;
					POSITION pos1=p1->pElementList.m_pListElement.Find(pEInList,NULL);
					POSITION pos2=p2->pElementList.m_pListElement.Find(pEInList,NULL);
					p1->pElementList.m_pListElement.RemoveAt(pos1);
					p2->pElementList.m_pListElement.RemoveAt(pos2);
					pEArray[i]=pE;
					delete pEInArray;
				}
				else
				{
					CAJoint *p1=pE->GetJointStruct()->pJoint1;
					CAJoint *p2=pE->GetJointStruct()->pJoint2;
					POSITION pos1=p1->pElementList.m_pListElement.Find(pE,NULL);
					POSITION pos2=p2->pElementList.m_pListElement.Find(pE,NULL);
					p1->pElementList.m_pListElement.RemoveAt(pos1);
					p2->pElementList.m_pListElement.RemoveAt(pos2);
					delete pE;
				}
				return true;
				break;
			}
		}
		return false;
	}
	else
	{
		return false;
	}
}

BOOL CCalculate::IsSameJoint(CAElement *pE1, CAElement *pE2)
{
	BOOL b1,b2;
	if(pE1->GetJointStruct()->pJoint1==pE2->GetJointStruct()->pJoint1)
	{
		b1=true;
	}
	else
	{
		b1=false;
	}
	if(pE1->GetJointStruct()->pJoint2==pE2->GetJointStruct()->pJoint2)
	{
		b2=true;
	}
	else
	{
		b2=false;
	}
	if(b1&&b2)
	{
		return true;
	}
	else
	{
		return false;
	}
}


void CCalculate::OnePowerCalculate(int nArrayPowerNum)
{
		m_pJointList->SetAllIsSetVoltage( false,m_pJointList->m_pSaveList );
		m_bIsNewX=false;
	//	m_pJointList->CreateCopyJointList(m_pJointList->m_pOldList,m_pJointList->m_pCopyList);
		m_pOnePowerJointList=m_pJointList;
	//	RemovePowerFromJoint(nArrayPowerNum);
	
		m_pJointList->SaveCapacityInList(m_pJointList->m_pOldList,&m_capaList);
		m_pJointList->AdjustCapacityInList(m_pJointList->m_pOldList,&m_capaList);
		AdjustInductor();
		InitialParameter();
//		SavePowerInArray(m_pJointList->m_pOldList);
		CAElement* pInList = m_pJointList->GetElement( m_pArrayPower[nArrayPowerNum],m_pJointList->m_pOldList);
		pInList->GetJointStruct()->pJoint1->SetVoltage(0);
		pInList->GetJointStruct()->pJoint2->SetVoltage(m_pArrayPower[nArrayPowerNum]->GetValue());
		//int index = m_pArrayPower[0]->GetIndex();
		Calculate();
		delete m_fPowerOfR;
	//	SavePowerInArray(m_pJointList->m_pSaveList);
		Processor(nArrayPowerNum);
		while( !IsAllSetVoltage() )
		{
			SetValueAboutInductor(nArrayPowerNum);
			SetValueAboutCapacity(nArrayPowerNum);
		}
	//	m_pJointList->CreateCopyJointList(m_pJointList->m_pCopyList,m_pJointList->m_pOldList);
//		SavePowerInArray(m_pJointList->m_pOldList);

		POSITION pos1=m_pJointList->m_pSaveList->GetHeadPosition();
		while(pos1!=NULL)
		{
			CAJoint *pBaseJoint=m_pJointList->GetJoint(m_nDatumMark,m_pJointList->m_pSaveList);
			CAJoint *p1=m_pJointList->m_pSaveList->GetNext(pos1);
			p1->m_fRealVoltage[nArrayPowerNum]=(p1->m_fVoltage[nArrayPowerNum])-(pBaseJoint->m_fVoltage[nArrayPowerNum]);
		}
		if(m_bIsNewX)
		{
			delete x;
		}
}



void CCalculate::CreateCopyPowerArray(CAElement **pSourcePower, CAElement **pCopyPower)
{
	for(int i = 0; i<100; i ++ )
	{
		if( pSourcePower[i] )
		{
			float value = pSourcePower[i]->GetValue();
			int index = pSourcePower[i]->GetIndex();
			CAElement* pNewPower = m_pJointList->NewElement( ID_POWER,value );
			pNewPower->SetIndex( index );
		//	CAJoint* p1 = pSourcePower[i]->GetJointStruct()->pJoint1;
		//	CAJoint* p2 = pSourcePower[i]->GetJointStruct()->pJoint2;
			int order1 = pSourcePower[i]->GetOrderStruct()->order1;
			int order2 = pSourcePower[i]->GetOrderStruct()->order2;
			pNewPower->SetOrderStruct( order1,order2 );
			pCopyPower[i] = pNewPower;
		}
	}
}

BOOL CCalculate::IsAllSetVoltage()
{
	POSITION pos = m_pJointList->m_pSaveList->GetHeadPosition();
	while( pos != NULL )
	{
		CAJoint* pJoint = m_pJointList->m_pSaveList->GetNext( pos );
		BOOL b = pJoint->IsSetVoltage();
		if( !b )
		{
			return false;
		}
	}
	return true;
}

void CCalculate::AddPowerResistance(CList<CAJoint*,CAJoint*>* pList)
{
	int nCount = pList->GetCount();
	float R = m_pJointList->GetAverageOfResistance( pList )/100;
	for(int i = 0; i<100; i++)
	{
		if( m_pArrayPower[i] )
		{
			CAElement* pPower = m_pJointList->GetElement( m_pArrayPower[i],pList);
			CAElement* pNewEl = m_pJointList->NewElement( ID_RESISTANCE, R );
			pNewEl->SetIndex( nCount+1 );
			CAJoint* p1 = pPower->GetJointStruct()->pJoint1;
			CAJoint* p2 = pPower->GetJointStruct()->pJoint2;
			POSITION posRemove = p1->pElementList.m_pListElement.Find( pPower,NULL );
			p1->pElementList.m_pListElement.RemoveAt( posRemove );
			p1->pElementList.m_pListElement.AddTail( pNewEl );
			m_pJointList->AddJoint( pList,nCount );
			CAJoint* pNewJ = m_pJointList->GetJoint(nCount,pList);
			pNewEl->SetStructJoint( p1,pNewJ );
			pNewEl->SetOrderStruct( p1->GetOrder(),p2->GetOrder() );
			pPower->SetStructJoint( pNewJ,p2 );
			pPower->SetOrderStruct( pNewJ->GetOrder(),p2->GetOrder()) ;
			pNewJ->pElementList.m_pListElement.AddTail( pPower );
			pNewJ->pElementList.m_pListElement.AddTail( pNewEl );
			nCount ++;
		}
	}
}
