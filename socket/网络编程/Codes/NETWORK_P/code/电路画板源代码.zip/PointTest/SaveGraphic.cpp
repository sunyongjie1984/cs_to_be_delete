// SaveGraphic.cpp: implementation of the SaveGraphic class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "SaveGraphic.h"
#include "selecttool.h"
#include "base.h"
#include "line.h"
#include "linetool.h"
#include "pointtool.h"
#include "dottool.h"
#include "captool.h"
#include "indtool.h"
#include "powertool.h"
#include "groundtool.h"
#include "diodetool.h"
#include "switchtool.h"
#include "currenttool.h"
#include "voltagetool.h"
#include "lighttool.h"
#include "texttool.h"
#include "rheostattool.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

SaveGraphic::SaveGraphic(CWnd* pWnd,CElist* pList , CPointList* pOintList,CLineList* pLineList,CTextList* pTextList)
{
	m_pWnd = pWnd;
	m_pList = pList;
	m_PointList = pOintList;
	m_pLineList = pLineList;
	m_pTextList = pTextList;
}

SaveGraphic::~SaveGraphic()
{

}
void SaveGraphic::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		m_pList->Serialize(ar);
		m_PointList->SetPosition();
		m_pLineList->Serialize(ar);
		m_pTextList->Serialize(ar);
	}else{
		m_pList->RemoveAll();
		m_PointList->RemoveAll();
		m_pLineList->RemoveAll();
		m_pTextList->RemoveAll();
		ar >> nTime;
		for(int i=0;i<nTime;i++){
			ar >> m_ElementType;
			ar >> m_iSelected;
			ar >> TotalAngle;
			ar >> CenterPoint;
			ar >> Value;
			CreateElement(m_ElementType,CenterPoint,TotalAngle,m_iSelected,Value);
		}
		m_PointList->SetPosition();
		ar>>nTime;
		CBase *pa1,*pa2;
		CLine * pline;
		//CText *pText;
		for(i=0;i<nTime;i++){
			ar >> parentnumber1;
			ar >> parentnumber2;
			pa1 = m_PointList->GetObject(parentnumber1);
			pa2 = m_PointList->GetObject(parentnumber2);
			pline = new CLine(pa1,pa2,m_pLineList);
			pa1->AddSon(pline);
			pa2->AddSon(pline);
		}
		ar>>nTime;
		for(i = 0;i<nTime;i++){
			ar >> TextRect;
			ar >> TextString;
			pText = new CText(m_pTextList);
			pText->GetData(TextString,TextRect);
		}
		m_pWnd->Invalidate();
	}
}
void SaveGraphic::CreateElement(UINT id,CPoint point,double Rotate,BOOL select,float value)
{
	switch( id )
	{
	case ID_RESISTANCE:
		m_pBaseTool = new CRTool(m_pWnd, m_pList,m_PointList,m_pLineList,m_pTextList);
		break;
	case ID_RHEOSTAT:
		m_pBaseTool = new CRheostatTool(m_pWnd, m_pList,m_PointList,m_pLineList,m_pTextList);
		break;
	case ID_DOT:
		m_pBaseTool = new CDotTool(m_pWnd,  m_pList,m_PointList,m_pLineList,m_pTextList);
		break;
	case ID_CAPACITANCE:
		m_pBaseTool = new CCapTool(m_pWnd,  m_pList,m_PointList,m_pLineList,m_pTextList);
		break;
	case ID_DIODE:
		m_pBaseTool = new CDiodeTool(m_pWnd,  m_pList,m_PointList,m_pLineList,m_pTextList);
		break;
	case ID_GROUND:
		m_pBaseTool = new CGroundTool(m_pWnd,  m_pList,m_PointList,m_pLineList,m_pTextList);
		break;
	case ID_INDUCTANCE:
		m_pBaseTool = new CIndTool(m_pWnd,  m_pList,m_PointList,m_pLineList,m_pTextList);
		break;
	case ID_VOLTAGE_METER:
		m_pBaseTool = new CVoltageTool(m_pWnd,  m_pList,m_PointList,m_pLineList,m_pTextList);
		break;
	case ID_CURRENT_METER:
		m_pBaseTool = new CCurrentTool(m_pWnd,  m_pList,m_PointList,m_pLineList,m_pTextList);
		break;
	case ID_SWITCH:
		m_pBaseTool = new CSwitchTool( m_pWnd, m_pList,m_PointList,m_pLineList,m_pTextList);
		break;
	case ID_POWER:
		m_pBaseTool = new CPowerTool( m_pWnd, m_pList,m_PointList,m_pLineList,m_pTextList);
		break;
	case ID_LIGHT:
		m_pBaseTool = new CLightTool( m_pWnd, m_pList,m_PointList,m_pLineList,m_pTextList);
		break;
	case ID_TEXT:
		m_pBaseTool = new CTextTool( m_pWnd, m_pList,m_PointList,m_pLineList,m_pTextList);
		break;
	default:
		m_pBaseTool = NULL;
		AfxMessageBox( _T("�����ļ�����!") );
		return;		
	}
	m_pBaseTool->Value = value;
	m_pBaseTool->ToAngle = Rotate;
	m_pBaseTool->Select = select;
	m_pBaseTool->AddObject(point);
//	m_pBaseTool->Draw();
}
