// TextList.cpp: implementation of the CTextList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "TextList.h"
#include "base.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTextList::CTextList()
{

}

CTextList::~CTextList()
{

}
void CTextList::Draw(CDC* pDC)
{
	CText *aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CText*)GetNext(Pos);
		aa->Draw(pDC);
	}
}
CText* CTextList::AddText()
{
	return(new CText(this));
}
void CTextList::Serialize(CArchive& ar)
{
	CBase* aa;
	if(ar.IsStoring()){
		POSITION Pos = GetHeadPosition();
		ar << GetCount();
		while(Pos!=NULL){
			aa = (CBase*)GetNext(Pos);
			if(aa){
				ar << aa->GetGraphRect();
				ar << aa->GetGraphString();
			}
		}
	}else{}
}
CBase* CTextList::PtInOb(CPoint point)
{
	CBase* aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CBase*)GetNext(Pos);
		if(aa->PtInOb(point)){
			DeSelect();
			aa->Select();
			return aa;
		}
	}
	return NULL;
}
void CTextList::MoveSelected(CSize size)
{
	CText *aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CText*)GetNext(Pos);
		if(aa->IsSelected())
			aa->m_bMoving = TRUE;
	}
	CBaseList::MoveSelected(size);
}
void CTextList::Move(CSize size)
{
	CBaseList::MoveSelected(size);	
}
/*BOOL CTextList::PtInGraph(CPoint point,BOOL Control)
{

}*/
void CTextList::ReSetMoveFlag()
{
	CText *aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CText*)GetNext(Pos);
		if(aa->IsSelected())
			aa->m_bMoving = FALSE;
	}	
}