// CapTool.cpp: implementation of the CCapTool class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "CapTool.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCapTool::CCapTool(CWnd* cWnd,CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText)
		:CBaseTool(cWnd,pList,pOintList,pLineList,pText)
{

}
CCapTool::CCapTool(CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText)
		:CBaseTool(pList,pOintList,pLineList,pText)
{

}
CCapTool::~CCapTool()
{

}
void CCapTool::OnLButtonDown(UINT nFlags, CPoint point)
{
	CanDraw = TRUE;

	CaptureScr();

	AddObject(point);

	Draw();
}
void CCapTool::OnLButtonUp(UINT nFlags, CPoint point)
{
	if(!CanDraw) return;

	CanDraw = FALSE;

	ReleaseScr();
}
void CCapTool::OnMouseMove(UINT nFlags, CPoint point)
{
	if(CanDraw){
		m_pBase->SetPoint(point);
		Draw();
	}
}
void CCapTool::AddObject(CPoint point)
{
	p1 = new CEpoint(m_PointList);
	p2 = new CEpoint(m_PointList);

	m_pBase = new CCapacitance(p1,p2,m_pList);
	m_pBase->TotalAngle = ToAngle;
	m_pBase->m_iSelected = Select;
//	m_pBase->Value = Value;
	m_pBase->SetPoint(point);
	p1->Parent = m_pBase;
	p2->Parent = m_pBase;
}
