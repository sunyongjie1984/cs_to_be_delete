// PointtestDoc.h : interface of the CPointtestDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_POINTTESTDOC_H__37927A0B_613E_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_POINTTESTDOC_H__37927A0B_613E_11D4_BBD7_600000000ECD__INCLUDED_
#include "Elist.h"
#include "pointlist.h"
#include "linelist.h"
#include "textlist.h"
#include "savegraphic.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPointtestDoc : public CDocument
{
protected: // create from serialization only
	CPointtestDoc();
	DECLARE_DYNCREATE(CPointtestDoc)

// Attributes
public:

// Operations
public:
	CElist m_list;
	CPointList m_pointlist;
	CLineList m_linelist;
	CTextList m_textlist;
	SaveGraphic * saveg;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPointtestDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void SetTitle(LPCTSTR lpszTitle);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPointtestDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPointtestDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		afx_msg BOOL OnFileOpen();
		afx_msg void OnFileSave();
		afx_msg void OnNewFile();
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POINTTESTDOC_H__37927A0B_613E_11D4_BBD7_600000000ECD__INCLUDED_)
