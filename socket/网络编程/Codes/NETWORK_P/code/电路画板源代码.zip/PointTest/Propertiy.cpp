// Propertiy.cpp : implementation file
//

#include "stdafx.h"
#include "Pointtest.h"
#include "Propertiy.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertiy dialog


CPropertiy::CPropertiy(CWnd* pParent /*=NULL*/)
	: CDialog(CPropertiy::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPropertiy)
	m_value = 0.0;
	m_MaxValue = 0.0;
	m_properte = _T("");
	m_unit = _T("");
	//}}AFX_DATA_INIT
}
CPropertiy::CPropertiy(CString tr)
	: CDialog(CPropertiy::IDD, NULL)
{
	//{{AFX_DATA_INIT(CPropertiy)
	m_value = 0.0;
	m_MaxValue = 0.0;
	m_properte = _T("");
	m_unit = _T("");
	m_remark = _T("");
	m_title = tr;
	//}}AFX_DATA_INIT
}


void CPropertiy::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertiy)
	DDX_Text(pDX, IDC_VALUE, m_value);
	DDX_Text(pDX, IDC_PROPERTE, m_properte);
	DDX_Text(pDX, IDC_UNIT, m_unit);
	DDX_Text(pDX, IDC_REMARK, m_remark);
	DDX_Text(pDX, IDC_MAX,  m_MaxValue);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertiy, CDialog)
	//{{AFX_MSG_MAP(CPropertiy)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertiy message handlers
BOOL CPropertiy::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CWnd* pWnd;
	SetWindowText(m_title);
	if(m_title == "�ӵ�����"){
		pWnd = GetDlgItem(IDC_VALUE);
		pWnd->ShowWindow(FALSE);
		pWnd = GetDlgItem(IDC_UNIT);
		pWnd->ShowWindow(FALSE);
		pWnd = GetDlgItem(IDC_PROPERTE);
		pWnd->ShowWindow(FALSE);
		pWnd = GetDlgItem(IDC_MAX);
		pWnd->ShowWindow(FALSE);
		pWnd = GetDlgItem(IDC_STATIC1);
		pWnd->ShowWindow(FALSE);
	}
	if((m_title == "����������")||(m_title == "��ѹ������")||(m_title == "����������")){

	}else{
		pWnd = GetDlgItem(IDC_STATIC1);
		pWnd->ShowWindow(FALSE);		
		pWnd = GetDlgItem(IDC_MAX);
		pWnd->ShowWindow(FALSE);
	}
	//CWnd* pWnd = GetDlgItem(IDC_MAX);
	//pWnd->ShowWindow(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}