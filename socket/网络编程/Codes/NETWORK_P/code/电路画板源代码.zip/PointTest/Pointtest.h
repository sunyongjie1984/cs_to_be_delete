//��
#if !defined(AFX_POINTTEST_H__37927A05_613E_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_POINTTEST_H__37927A05_613E_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CPointtestApp:
// See Pointtest.cpp for the implementation of this class
//
#define ID_SELECT				61446
#define ID_LINE					61447
#define ID_POINT				61448
#define ID_DOT					61449

#define ID_RESISTANCE           61450//����
#define ID_POWER				61451//��Դ
#define ID_CAPACITANCE			61452//����
#define ID_DIODE				61453//������
#define ID_SWITCH				61454//����

#define ID_VOLTAGE_METER		61455//��ѹ��
#define ID_CURRENT_METER		61456//������
#define ID_INDUCTANCE			61457//inductance���
#define ID_GROUND				61458//��
#define ID_LIGHT				61459//����
#define ID_UNDEFINED			61460//δ����
#define ID_NONODE				61461//û�нڵ�
#define ID_DEFAULTBASE			61462//û�нӵ�
#define ID_TEXT					61463//�ı���ID
#define ID_RHEOSTAT				61464//������

class CPointtestApp : public CWinApp
{
public:
	CPointtestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPointtestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CPointtestApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POINTTEST_H__37927A05_613E_11D4_BBD7_600000000ECD__INCLUDED_)
