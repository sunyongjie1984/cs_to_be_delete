// Calculate.h: interface for the CCalculate class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CALCULATE_H__A5639AC6_5BBA_11D4_AFFB_00E04C6749D0__INCLUDED_)
#define AFX_CALCULATE_H__A5639AC6_5BBA_11D4_AFFB_00E04C6749D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "afxtempl.h"
#include "JointList.h"
#include "Element.h"
#include "Component.h"
#include "Joint.h"

class CCalculate  
{
	
protected:
	int m_nDatumMark;
	CJointList *m_pJointList;
	CJointList *m_pOnePowerJointList;
	CList<CAJoint*,CAJoint*>m_pOldJointList;
	CAJoint *m_pSourceJoint1,*m_pSourceJoint2;
	float m_dMatrix[100][100];//the last calculate matrix
	float *m_fPowerOfR;
	float *x;// save all joints voltage 
private:
	BOOL IsAllSetVoltage();
	int m_nPowerNum;//the number of power
	void ChangeElement(CAJoint *p1,CAJoint *p2,CAElement *pE);
	CList<CAElement*,CAElement*>m_pListElement;//a CAElement list longs to one of joints 
	CList<CAJoint*,CAJoint*>m_listOnePower;//the joint list when only one power left
	CAElement* m_pArrayPower[100];
	CAElement* m_pCopyPower[100];//the array which save all powers
	CList<CAElement*,CAElement*>m_capaList;
protected:
	void AddPowerResistance(CList<CAJoint* ,CAJoint*>* pList);
	void CreateCopyPowerArray(CAElement** pSourcePower,CAElement** pCopyPower);
	void OnePowerCalculate(int nArrayPowerNum);
	BOOL IsSameJoint(CAElement *pE1,CAElement *pE2);
	BOOL DealParallelConnectionPower(CAElement *pE,CAElement **pEArray,CList<CAJoint*,CAJoint*>*pList);
	BOOL m_bIsNewX;
	void SetValueAboutInductor(int nPowerArrayOrder);
	void AdjustInductor();
	void SetValueAboutCapacity(int nPowerArrayOrder);
	void SetJointValueInCapaList(CAJoint *pJoint,CAElement *pElement,int nPowerArrayOrder);
	void InitialParameter();
	void Processor(int powerArrayOrder);
	void SetMatrixValue();
	void EstablishEquation();
	void BuildMatrix(int i,CAJoint *p);//set one of line of the matrix
//	void AdjustJoint();
	void SavePowerInArray(CList<CAJoint*,CAJoint*>*pList);
	void RemovePowerFromJoint(int k);
	void Calculate();

public:
	void RealCalculate();
	CCalculate(CJointList *p,int datum = 1);
	virtual ~CCalculate();

};

#endif // !defined(AFX_CALCULATE_H__A5639AC6_5BBA_11D4_AFFB_00E04C6749D0__INCLUDED_)
