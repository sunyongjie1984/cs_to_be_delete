// RheostatTool.h: interface for the CRheostatTool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RHEOSTATTOOL_H__5B891A62_790B_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_RHEOSTATTOOL_H__5B891A62_790B_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseTool.h"
#include "Epoint.h"
#include "base.h"
#include "rheostat.h"
class CRheostatTool : public CBaseTool  
{
public:
	CRheostatTool(CWnd* cWnd,CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	CRheostatTool(CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	virtual ~CRheostatTool();
public:	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
	void AddObject(CPoint point);
public:
	CBase* p1,*p2;
};

#endif // !defined(AFX_RHEOSTATTOOL_H__5B891A62_790B_11D4_BBD7_600000000ECD__INCLUDED_)
