#if !defined(AFX_MYWATCH_H__C4959015_6FCA_11D4_B684_BA6FB458F61C__INCLUDED_)
#define AFX_MYWATCH_H__C4959015_6FCA_11D4_B684_BA6FB458F61C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyWatch.h : header file
//
#define WM_GOODBYE WM_USER + 5
/////////////////////////////////////////////////////////////////////////////
// MyWatch dialog
#include "WatchFace.h"
#include "NumberDisplay.h"
#include "ButtonMouseTool.h"

class MyWatch : public CDialog
{
// Construction
public:
	MyWatch(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(MyWatch)
	enum { IDD = IDD_DIALOG1 };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(MyWatch)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
	UINT m_ID;                //���
	CString m_Title;     //�Ի��������
	CString m_Name;           //�����
	double m_Value;           //��ֵ
	CString m_Units;          //��λ
	double m_BigValue;        //��������ֵ
	ButtonMouseTool tool;
	UINT m_ButtonID;
	int m_NUMBER;

protected:
	double m_PrevValue;       //��һ�β�����ֵ
    CView *m_pView;
	WatchFace face;
	NumberDisplay m_EditDisplay;
	BOOL m_LFlag;
	BOOL m_BigFlag;
	BOOL m_BaiDongFlag;
	int m_Number;
	double m_tempAngle1,m_tempAngle2;
	double m_tempValue;
	
public:
	void DrawScreen( );
	MyWatch( CView * );
	MyWatch( CView *view,CString m_Tille,UINT id,CString name,double value,CString units,double big );
	BOOL Create( );
	void SetParam( CString,UINT,CString,double,CString,double );
	//�Ի�������֣����ID����������֣������ֵ������ĵ�λ����������ֵ
	// Generated message map functions
	//{{AFX_MSG(MyWatch)
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYWATCH_H__C4959015_6FCA_11D4_B684_BA6FB458F61C__INCLUDED_)
