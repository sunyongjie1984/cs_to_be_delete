// BaseTool.h: interface for the CBaseTool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BASETOOL_H__37927A19_613E_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_BASETOOL_H__37927A19_613E_11D4_BBD7_600000000ECD__INCLUDED_
#include "base.h"
#include "Elist.h"
#include "pointlist.h"
#include "linelist.h"
#include "textlist.h"
#include "Propertiy.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CBaseTool  
{
public:
	CBaseTool(CWnd* pWnd, CElist* pList , CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	CBaseTool(CElist* pList , CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	virtual ~CBaseTool();
public:	
	//draw attribute
	virtual void Draw();
	virtual void Draw(CPoint p1,CPoint p2);
	virtual void DrawDash(CPoint p1,CPoint p2,CDC* pDC);
	virtual void DrawCompanySign(CDC* pDC);

	virtual CRect GetRect(CPoint p1,CPoint p2);
	//mouse func
	virtual void OnLButtonDown(UINT nFlags, CPoint point){}
	virtual void OnLButtonUp(UINT nFlags, CPoint point){}
	virtual void OnRButtonDown(UINT nFlags, CPoint point){}
	virtual void OnRButtontnUp(UINT nFlags, CPoint point){}
	virtual void OnMouseMove(UINT nFlags, CPoint point){}
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point){}
	virtual void OnRButtonDblClk(UINT nFlags, CPoint point){}

	//capture func
	virtual BOOL ClipCursorInClientRect();
	virtual void CaptureScr();
	virtual void ReleaseScr();
	//Object operation
	virtual void AddObject(CPoint point){}
public:
	BOOL CanDraw;
	CWnd* m_pWnd;
	CBase* m_pBase;
	CElist* m_pList;
	CPointList* m_PointList;
	CLineList* m_pLineList;
	CTextList *m_pTextList;
	CPoint BeginPoint,EndPoint;
public:
	double ToAngle;
	BOOL Select;
	float Value;
};

#endif // !defined(AFX_BASETOOL_H__37927A19_613E_11D4_BBD7_600000000ECD__INCLUDED_)
