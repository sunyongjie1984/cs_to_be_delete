// LightTool.h: interface for the CLightTool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LIGHTTOOL_H__3A5C80E2_6C3E_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_LIGHTTOOL_H__3A5C80E2_6C3E_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseTool.h"
#include "epoint.h"
#include "light.h"
class CLightTool : public CBaseTool  
{
public:
	CLightTool(CWnd* cWnd,CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	CLightTool(CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	virtual ~CLightTool();
public:	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
	void AddObject(CPoint point);
public:
	//CResis* m_pResis;
	CBase* p1,*p2;
};

#endif // !defined(AFX_LIGHTTOOL_H__3A5C80E2_6C3E_11D4_BBD7_600000000ECD__INCLUDED_)
