// Voltage.cpp: implementation of the CVoltage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "Voltage.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CVoltage::CVoltage(int nType,CBaseList* pBaseList) : CBase(ID_VOLTAGE_METER,pBaseList)
{
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "��ѹ��";
	AddString(ID_VOLTAGE_METER);
	Value = 1;
	MaxValue = 20;
}
CVoltage::CVoltage(CBase* pp1,CBase* pp2,CBaseList* pBaseList) : CBase(ID_VOLTAGE_METER,pBaseList)
{
	p1 = pp1;
	p2 = pp2;
	AddSon(p1);
	AddSon(p2);
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "��ѹ��";
	AddString(ID_VOLTAGE_METER);
	Value = 1;
	MaxValue = 20;
}
CVoltage::~CVoltage()
{
}
void CVoltage::Draw(CDC* pDC)
{
	if(IsSelected()){
		CPen pen(PS_SOLID, 2,RED);
		CPen *Oldpen = pDC->SelectObject(&pen);
		pDC->SetBkMode(TRANSPARENT);
		pDC->Rectangle(GetGraphRect());
		pDC->Rectangle(GetRect(aa,CSize(32,16)));
		pDC->Ellipse(GetRect(left,CSize(6,6)));
		pDC->Ellipse(GetRect(right,CSize(6,6)));
		pDC->MoveTo(left);
		pDC->LineTo(p1->CenterPoint);
		pDC->MoveTo(right);
		pDC->LineTo(p2->CenterPoint);
		pDC->TextOut(bb.x,bb.y,"V");
		DrawSign(pDC,sign,18);

		pDC->SelectObject(Oldpen);
	}else{
		CPen pen(PS_SOLID, 2,BLACK);
		CPen *Oldpen = pDC->SelectObject(&pen);
		pDC->SetBkMode(TRANSPARENT);
		pDC->Rectangle(GetGraphRect());
		pDC->Rectangle(GetRect(aa,CSize(32,16)));
		pDC->Ellipse(GetRect(left,CSize(6,6)));
		pDC->Ellipse(GetRect(right,CSize(6,6)));
		pDC->MoveTo(left);
		pDC->LineTo(p1->CenterPoint);
		pDC->MoveTo(right);
		pDC->LineTo(p2->CenterPoint);
		pDC->TextOut(bb.x,bb.y,"V");
		DrawSign(pDC,sign,18);

		pDC->SelectObject(Oldpen);
	}
	TextOut(pDC);
}
void CVoltage::SetPoint(CPoint pp)
{
	aa = left = right = CenterPoint = pp;
	left.Offset(CSize(-10,10));
	right.Offset(CSize(10,10));
	p1->SetPoint(left);
	p2->SetPoint(right);
	p1->OffSet(CSize(0,15));
	p2->OffSet(CSize(0,15));
	aa.Offset(CSize(0,-4));
	bb = aa;
	bb.Offset(CSize(-4,5));
	sign = CenterPoint;
	sign.Offset(CSize(0,22));
	//RotateCell(TotalAngle);
}
void CVoltage::OffSet(CSize size)
{
	CenterPoint.Offset(size);
	left.Offset(size);
	right.Offset(size);
	p1->OffSet(size);
	p2->OffSet(size);
	aa.Offset(size);
	bb.Offset(size);
	sign.Offset(size);
}
CRect CVoltage::GetGraphRect()
{
	CPoint up_left,down_right;
	up_left = down_right = CenterPoint;
	up_left.Offset(-20,-15);
	down_right.Offset(20,15);
	return CRect(up_left,down_right);		
}
/*void CVoltage::RotateCell(double angle)
{
	left = Rotate(angle,left);
	right = Rotate(angle,right);
	p1->CenterPoint = Rotate(angle,p1->CenterPoint);
	p2->CenterPoint = Rotate(angle,p2->CenterPoint);
	aa = Rotate(angle,aa);
	bb = Rotate(angle,bb);
}*/