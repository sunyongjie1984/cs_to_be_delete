// WatchList.cpp: implementation of the CWatchList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "WatchList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CWatchList::CWatchList()
{

}

CWatchList::~CWatchList()
{

}
void CWatchList::DeleteWatch(MyWatch* watch)
{
	POSITION Pos,OldPos;
	Pos= GetHeadPosition();
	while(Pos != NULL){
		OldPos = Pos;
		if(watch == (MyWatch *)GetNext(pos)){
			delete watch;
			RemoveAt(OldPos);
		}
	}	
}