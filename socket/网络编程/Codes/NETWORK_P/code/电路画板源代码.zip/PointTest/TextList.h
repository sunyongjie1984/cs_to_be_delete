// TextList.h: interface for the CTextList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXTLIST_H__B39327F6_6F66_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_TEXTLIST_H__B39327F6_6F66_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "BaseList.h"
#include "text.h"
class CTextList : public CBaseList  
{
public:
	CTextList();
	virtual ~CTextList();
public:
	void Draw(CDC* pDC);
	CText* AddText();
	CBase* PtInOb(CPoint point);
	void MoveSelected(CSize size);
	void Move(CSize size);
	//BOOL PtInGraph(CPoint point,BOOL Control);
	void ReSetMoveFlag();
public:
	void Serialize(CArchive& ar);
};

#endif // !defined(AFX_TEXTLIST_H__B39327F6_6F66_11D4_BBD7_600000000ECD__INCLUDED_)
