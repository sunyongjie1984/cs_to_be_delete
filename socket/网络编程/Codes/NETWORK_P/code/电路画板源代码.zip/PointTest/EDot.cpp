// EDot.cpp: implementation of the CEDot class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "EDot.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEDot::CEDot(int nType,CBaseList* pBaseList) 
			: CBase(ID_DOT,pBaseList)
{
}
CEDot::CEDot(CBase* pp1,CBase* pp2,CBase *pp3,CBase *pp4,CBaseList* pBaseList)
		 : CBase(ID_DOT,pBaseList)
{
	p1 = pp1;
	p2 = pp2;
	p3 = pp3;
	p4 = pp4;
	AddSon(p1);
	AddSon(p2);
	AddSon(p3);
	AddSon(p4);
}
CEDot::~CEDot()
{

}
void CEDot::Draw(CDC* pDC)
{
	if(IsSelected()){
		CPen pen(PS_SOLID, 1,RED);
		CBrush brush(RED);
		CBrush* Oldbrush = pDC->SelectObject(&brush);
		CPen *Oldpen = pDC->SelectObject(&pen);
		pDC->Ellipse(GetGraphRect());
		pDC->SelectObject(Oldbrush);
		pDC->SelectObject(Oldpen);
	}else{
		CPen pen(PS_SOLID, 1,BLACK);
		CBrush brush(BLACK);
		CBrush* Oldbrush = pDC->SelectObject(&brush);
		CPen *Oldpen = pDC->SelectObject(&pen);

		pDC->Ellipse(GetGraphRect());

		pDC->SelectObject(Oldbrush);
		pDC->SelectObject(Oldpen);
	}
}
void CEDot::SetPoint(CPoint pp)
{
	CenterPoint = pp;
	p1->CenterPoint = pp - CPoint(0,5);
	p2->CenterPoint = pp + CPoint(5,0);
	p3->CenterPoint = pp + CPoint(0,5);
	p4->CenterPoint = pp - CPoint(5,0);
}
BOOL CEDot::PtInOb(CPoint point)
{
	BOOL result = FALSE;
	CRgn mRect;
	mRect.CreateEllipticRgnIndirect(GetGraphRect());
	if(mRect.PtInRegion(point))
		result = TRUE;
	return result;
}
void CEDot::OffSet(CSize size)
{
	CenterPoint.Offset(size);
	p1->OffSet(size);
	p2->OffSet(size);
	p3->OffSet(size);
	p4->OffSet(size);
}
CRect CEDot::GetGraphRect()
{
	CPoint up_left,down_right;
	up_left = down_right = CenterPoint;
	up_left.Offset(-4,-4);
	down_right.Offset(4,4);
	return CRect(up_left,down_right);
}
void CEDot::RotateCell(double angle)
{
	p1->SetPoint(Rotate(angle,p1->CenterPoint));
	p2->SetPoint(Rotate(angle,p2->CenterPoint));
	p3->SetPoint(Rotate(angle,p3->CenterPoint));
	p4->SetPoint(Rotate(angle,p4->CenterPoint));
}