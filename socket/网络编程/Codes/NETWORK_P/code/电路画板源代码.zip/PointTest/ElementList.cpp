// ElementList.cpp: implementation of the CElementList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "ElementList.h"
#include "Joint.h"
#include "JointList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CElementList::CElementList()
{

}

CElementList::~CElementList()
{
/*	if(!m_pListElement.IsEmpty())
	{
		POSITION pos;
		pos=m_pListElement.GetHeadPosition();
		CAElement *p;
		while(pos!=NULL)
		{
			p=m_pListElement.GetAt(pos);
			m_pListElement.GetNext(pos);
			delete p;
		}
	}*/
}
void CElementList::AddElement(CAElement *p)
{
	m_pListElement.AddTail(p);
}
void CElementList::RemoveElement(CAElement *p)
{
	POSITION pos=m_pListElement.Find(p,NULL);
	p=m_pListElement.GetAt(pos);
	m_pListElement.RemoveAt(pos);
	if(p)
	{
		delete p;
	}
}
/*void CElementList::AllElToOther(int type1,int type2,float value)
{
	POSITION pos = m_pListElement.GetHeadPosition();
	while(pos != NULL)
	{
		CAElement *pE = m_pListElement.GetNext(pos);
		if(pE->GetType() == type1)
		{
			OneElToOther(pE,type2,value);
		}
	}
}*/
/*void CElementList::OneElToOther(CAElement *pE,int type,float value)
{
	CAJoint *p1 = pE->GetJointStruct()->pJoint1;
	CAJoint *p2 = pE->GetJointStruct()->pJoint2;
	CAElement *pNewEl = m_pJointList->NewElement(type,value);
	
	pE->SetType(type);
	pE->SetValue(value);
}*/


