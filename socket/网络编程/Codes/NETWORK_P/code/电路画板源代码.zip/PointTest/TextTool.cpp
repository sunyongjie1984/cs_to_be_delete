// TextTool.cpp: implementation of the CTextTool class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "TextTool.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTextTool::CTextTool(CWnd* cWnd,CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText) 
			:CBaseTool(cWnd,pList,pOintList,pLineList,pText)
{
	Content_Of_Text = "";
	m_pEdit = NULL;
	m_pBase = NULL;
	NEWOROLD = TRUE;
}

CTextTool::~CTextTool()
{
	if(m_pBase){
		DeSelect();
		if(Content_Of_Text.IsEmpty() == 0){
			SetData(m_pBase);
		}
	}
}
void CTextTool::OnLButtonDown(UINT nFlags, CPoint point)
{
	CanDraw = TRUE;
	BeginPoint = point;//passed
	MessageBeep(-1);
	TRACE("myptr = %d",m_pBase);
	if(m_pBase){
		DeSelect();
		if(Content_Of_Text.IsEmpty() == 0){
			SetData(m_pBase);
			Draw();
		}
	}
	m_pBase = m_pTextList->PtInOb(point);
	if(m_pBase){
		NEWOROLD = FALSE;
		GetData(m_pBase);
		Select();
	}else{
		NEWOROLD = TRUE;
	}
	BeginPoint = point;//passed
	Draw();
}
void CTextTool::OnLButtonUp(UINT nFlags, CPoint point)
{
	if(!CanDraw) return;
	CanDraw = FALSE;
	EndPoint = point;
	if(BeginPoint == EndPoint){
		ClearData();
		return;
	}
	if(NEWOROLD){
		m_pBase = m_pTextList->AddText();
		m_pTextList->DeSelect();
		m_pBase->Select();
		Size_Of_Text = GetRect(BeginPoint,EndPoint);
		Content_Of_Text.Empty();
		Select();
	}
	Draw();
}
void CTextTool::OnMouseMove(UINT nFlags, CPoint point)
{
	if(CanDraw){
		if(NEWOROLD){
			EndPoint = point;//passed
			Draw(BeginPoint,EndPoint);
		}
	}
}
void CTextTool::ClearData()
{
	m_pBase = NULL;
	Content_Of_Text.Empty();
	Size_Of_Text.SetRectEmpty();
}
void CTextTool::Select()
{
	if( m_pEdit == NULL){
		m_pEdit = new CEdit();
		Display_Size = Size_Of_Text;
		if(Content_Of_Text.IsEmpty() == 0)
			Display_Size.BottomRight().Offset(CSize(0,5));
		m_pEdit->Create( WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL|ES_LEFT|WS_BORDER|ES_MULTILINE,
			Display_Size, m_pWnd, IDE_TEXTBOX );
		m_pEdit->SetWindowText( Content_Of_Text );
		m_pEdit->SetFocus();
	}
}
void CTextTool::DeSelect()
{
	if( m_pEdit && m_pEdit->GetSafeHwnd()){
		m_pEdit->GetWindowText( Content_Of_Text );

		m_pEdit->DestroyWindow();
		delete m_pEdit;
		m_pEdit = NULL;
	}
	m_pWnd->Invalidate();
}
void CTextTool::SetData(CBase* aa)
{
	Size_Of_Text = Count_Size(Content_Of_Text);
	if(aa)
		aa->GetData(Content_Of_Text,Size_Of_Text);
}
void CTextTool::GetData(CBase* aa)
{
	aa->SetData(Content_Of_Text,Size_Of_Text);
}
CSize CTextTool::AddToMySize(CSize total,CSize add)
{
	CSize T1;
	T1 = total;
	if(T1.cx<add.cx)
		T1.cx = add.cx;
	T1.cy += add.cy+1;
	return T1;	
}
CRect CTextTool::Count_Size(CString aqie)//�����Ĵ�С
{
	CDC* mdc = m_pWnd->GetDC();
	CString tempString;
	CString string;
	CString findstring("\n" );
	CSize haha;
	CSize TotalSize = CSize(0,0);
	CRect aa = Size_Of_Text;
	int hang = 0,j = 0,line = 0,lie = 0;
	string = aqie;
	if(!string.IsEmpty()){
		line = string.GetLength();
		j = string.Find( findstring,0 );
		while(j != -1){
			hang = j;
			tempString = string.Left( j-1 );
			string = string.Right( line-j-1 );
			line = line-j-1;
			j = string.Find( findstring );
			if(hang<j) hang = j;
			lie++;
			haha = mdc->GetTextExtent(tempString);
			TotalSize = AddToMySize(TotalSize,haha);
		}
		
		if((j == -1)&&(lie == 0)){
			haha = mdc->GetTextExtent(string);
			Size_Of_Text = CRect(aa.TopLeft(),haha);
		}else if((j == -1)&&(lie != 0)){
			haha = mdc->GetTextExtent(string);
			TotalSize = AddToMySize(TotalSize,haha);
			Size_Of_Text = CRect(aa.TopLeft(),TotalSize);
		}
	}else{
		Size_Of_Text = CRect(0,0,0,0);
	}
	return Size_Of_Text;
}
