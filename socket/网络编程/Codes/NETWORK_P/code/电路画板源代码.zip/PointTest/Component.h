// Component.h: interface for the CComponent class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMPONENT_H__94C34141_62D4_11D4_AFFB_00E04C6749D0__INCLUDED_)
#define AFX_COMPONENT_H__94C34141_62D4_11D4_AFFB_00E04C6749D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Element.h"
#include "afxtempl.h"

class CAPower : public CAElement  
{
protected:
	float m_fPower;
public:
	float GetCurrent();
public:
	IntList* GetCapacityOrderList(CAJoint *pJoint);
	CAPower(float p);
	virtual ~CAPower();

};

////////////////////////

class CAResistance : public CAElement  
{
protected:
	float m_fResistance;
public:
	IntList* GetCapacityOrderList(CAJoint *pJoint);
	float GetCurrent();
public:
	CAResistance(float v);
	virtual ~CAResistance();

};
//////////////////////////

class CACapacity : public CAElement  
{
protected:
	IntList m_nOrderList1,m_nOrderList2;
	IntList *m_pOrderList1,*m_pOrderList2;
	float m_fCapacity;
public:
	IntList* GetCapacityOrderList(CAJoint *pJoint);
	float GetCurrent();
public:
	CACapacity(float c);
	virtual ~CACapacity();

};

//////////////////////

class CAInductor : public CAElement  
{
protected:
	float m_fInductivity;
public:
	IntList* GetCapacityOrderList(CAJoint *pJoint);
	float GetCurrent();
public:
	CAInductor(float i);
	virtual ~CAInductor();

};
///////////////////////

class CASwitch : public CAElement  
{
public:
	float GetCurrent();
public:
	IntList* GetCapacityOrderList(CAJoint *pJoint);
//	IntList* GetCapacityOrderList2();
	CASwitch(BOOL bIsClose);
	virtual ~CASwitch();

};
/////////////////////////

class CADiode: public CAElement
{
public:
	float GetCurrent();
public:
	IntList* GetCapacityOrderList(CAJoint *pJoint);
	CADiode();
	virtual ~CADiode();
};
/////////////////////////////
class CAAmpermeter:public CAElement
{
public:
	float GetCurrent();
public:
	IntList* GetCapacityOrderList(CAJoint* pJoint);
	CAAmpermeter();
	virtual ~CAAmpermeter();
};

////////////////////////////
class CAVoltmeter:public CAElement
{
public:
	float GetCurrent();
public:
	IntList* GetCapacityOrderList(CAJoint* pJoint);
	CAVoltmeter();
	virtual ~CAVoltmeter();
};

#endif // !defined(AFX_COMPONENT_H__94C34141_62D4_11D4_AFFB_00E04C6749D0__INCLUDED_)
