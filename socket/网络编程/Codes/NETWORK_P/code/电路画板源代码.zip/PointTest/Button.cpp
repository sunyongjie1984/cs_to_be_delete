// Button.cpp: implementation of the Button class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "Button.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Button::Button()
{
	m_LFlag = FALSE;
	m_BeSelected = FALSE;
	m_MoveBeSelected = FALSE;
    m_ID = 0;
	m_BitmapID1 = m_BitmapID2 = m_BitmapID3 = 0;
	m_Point = CPoint( 0,0 );
	m_Width = m_Hight = 0;
}

Button::~Button()
{

}

void Button::Draw( CDC *pDC )
{
	CDC *dc = new CDC;
	CBitmap *bitmap = new CBitmap;
	CBitmap *old;
	dc->CreateCompatibleDC( pDC );
	if ( m_BeSelected )
	{
        bitmap->LoadBitmap( m_BitmapID3 );
	}
	else
	{
		if ( m_MoveBeSelected )
		{
			bitmap->LoadBitmap( m_BitmapID2 );
		}
		else
		{
			bitmap->LoadBitmap( m_BitmapID1 );
		}
	}
	old = dc->SelectObject( bitmap );
	pDC->BitBlt( m_Point.x,m_Point.y,m_Width,m_Hight,dc,0,0,SRCCOPY );
	dc->SelectObject( old );
	delete bitmap;
	delete dc;
}

BOOL Button::PtInButton( CPoint point )
{
	CRect rect = CRect( m_Point.x,m_Point.y,m_Point.x+m_Width,m_Point.y+m_Hight );
	if ( rect.PtInRect( point ) )
	{
		return TRUE;
	}
	return FALSE;
}

void Button::ExchangeButtonPosition( CPoint point )
{
	m_Point = point ;
}

void Button::Serialize( CArchive &ar )
{
	if ( ar.IsStoring( ) )
	{
		ar<<m_BeSelected<<m_MoveBeSelected;
		ar<<m_BitmapID1<<m_BitmapID2<<m_BitmapID3;
		ar<<m_Width<<m_Hight<<m_Point;
		ar<<m_ID;
	}
	else
	{
		ar>>m_BeSelected>>m_MoveBeSelected;
		ar>>m_BitmapID1>>m_BitmapID2>>m_BitmapID3;
		ar>>m_Width>>m_Hight>>m_Point;
		ar>>m_ID;
	}
}
