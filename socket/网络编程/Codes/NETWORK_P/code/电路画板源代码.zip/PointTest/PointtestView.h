// PointtestView.h : interface of the CPointtestView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_POINTTESTVIEW_H__37927A0D_613E_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_POINTTESTVIEW_H__37927A0D_613E_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//class CElist;
#include "nodelist.h"
#include "textlist.h"
class CBaseTool;
class CPointtestDoc;
class CPointtestView : public CView
{
protected: // create from serialization only
	CPointtestView();
	DECLARE_DYNCREATE(CPointtestView)

// Attributes
public:
	CPointtestDoc* GetDocument();
	void ToolBox(UINT nID);
	void CreateBlankBitmap();
	void DrawCompanySign(CDC * pp, int xx, int yy);
	BOOL CheckIFCorrect();
	void Close();
public:
	int Operation_id;
	CElist *	m_pList;
	CPointList* m_ppointlist;
	CLineList* m_pLineList;
	CTextList* m_pTextList;
	CBaseTool *     m_pBaseTool;
	CNodeList* m_pNodeList;
	UINT id_Check;
// Operations
public:
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPointtestView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPointtestView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPointtestView)
	afx_msg void OnSelect();//ѡ����
	afx_msg void OnResistance();//���õ���
	afx_msg void OnRheostat();//���ñ�����
	afx_msg void OnPoint();//���ýڵ�
	afx_msg void OnCapacitance();//���õ���
	afx_msg void OnDiode();//���ö�����
	afx_msg void OnGround();//���ýӵ�
	afx_msg void OnInductance();//���õ��
	afx_msg void OnSwitch();//���ÿ���
	afx_msg void OnPower();//���õ�Դ
	afx_msg void OnVoltage();//���õ�ѹ��
	afx_msg void OnCurrent();//���õ�����
	afx_msg void OnLight();//���õ���
	afx_msg void OnHGrip();//ˮƽ����
	afx_msg void OnVGrip();//��ֱ����
	afx_msg void OnAntiClockWise();//˳ʱ��
	afx_msg void OnSeaZil();//��ʱ��
	afx_msg void OnGogo();//��ʱ��
	afx_msg void OnText();//�����ĵ�
	afx_msg void OnCalculate();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnUpdateDian(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDi(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDeng(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDddz(CCmdUI* pCmdUI);
	afx_msg void OnUpdateCap(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDianzu(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDianyuan(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDianyabiao(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDianliubiao(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDiangan(CCmdUI* pCmdUI);
	afx_msg void OnUpdateErjiguan(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSelectone(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTexta(CCmdUI* pCmdUI);
	afx_msg void OnUpdateKetiaodianzu(CCmdUI* pCmdUI);
	afx_msg void OnLookmeter();
	//}}AFX_MSG
	afx_msg LONG OnPleaseCopy(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in PointtestView.cpp
inline CPointtestDoc* CPointtestView::GetDocument()
   { return (CPointtestDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POINTTESTVIEW_H__37927A0D_613E_11D4_BBD7_600000000ECD__INCLUDED_)
