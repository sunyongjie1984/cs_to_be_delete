// BaseList.cpp: implementation of the CBaseList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "BaseList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBaseList::CBaseList()
{
	CtrlKey = FALSE;
}

CBaseList::~CBaseList()
{

}
void CBaseList::DeSelect()
{
	CBase * aa;	
	POSITION pos= GetHeadPosition();
    while(pos!=NULL)
	{
	    aa = (CBase *)GetNext(pos);
		aa->DeSelect();
   	}
}
CBase*	CBaseList::PtDbInGraph(CPoint point)
{
	CBase* aa;
	POSITION pos= GetHeadPosition();
    while(pos!=NULL)
	{
		aa = (CBase *)GetNext(pos);
		if(aa->PtInOb(point))
			return aa;
	}
	return NULL;
}
BOOL CBaseList::PtInGraph(CPoint point,BOOL Control)
{
	CBase* aa;
	POSITION pos= GetHeadPosition();
    while(pos!=NULL)
	{
		aa = (CBase *)GetNext(pos);
		if(Control){
			if(aa->PtInOb(point)){
				if(aa->IsSelected()){
					aa->DeSelect();
					return TRUE;
				}else{
					aa->Select();
					return TRUE;
				}
			}
		}else{
			if(aa->PtInOb(point)){
				if(aa->IsSelected()){
					return TRUE;
				}else{
					DeSelect();
					aa->Select();
					return TRUE;
				}
			}
			if(!IsAnySelect(point))
				DeSelect();
		}
   	}
	return FALSE;
}
void CBaseList::SelectAll()
{
	CBase* aa;
	POSITION pos = GetHeadPosition();
    while(pos!=NULL)
	{
	    aa = (CBase *)GetNext(pos);
		if(!aa->IsSelected()){
			aa->Select();
		}
   	}
}
void CBaseList::RemoveAll()
{
	CBase* aa;
	POSITION pos = GetHeadPosition();
    while(pos!=NULL)
	{
	    aa = (CBase *)GetNext(pos);
		if(aa){
			delete aa;
			aa = NULL;
		}
   	}
	CPtrList::RemoveAll();
}
CBase * CBaseList::GetAt( POSITION pos )
{
	return (CBase *)(CPtrList::GetAt(pos));
}
BOOL CBaseList::ObInRegion(CRect rect)
{
	BOOL result = FALSE;
	CBase* aa;
	POSITION pos= GetHeadPosition();
    while(pos!=NULL)
	{
		aa = (CBase *)GetNext(pos);
		if(aa->GraphInRect(rect)){
			aa->Select();
			result = TRUE;
		}
   	}
	return result;	
}
void CBaseList::RemoveSelected()
{
	CBase* aa;
	POSITION pos= GetHeadPosition();
    while(pos!=NULL)
	{
		aa = (CBase *)GetNext(pos);
		//DeSelect();
		if(aa->IsSelected()){
			delete aa;
		}
   	}
}
void CBaseList::MoveSelected(CSize size)
{
	CBase* aa;
	POSITION pos= GetHeadPosition();
    while(pos!=NULL)
	{
		aa = (CBase *)GetNext(pos);
		if(aa->IsSelected()){
			aa->OffSet(size);
		}
   	}
}
BOOL CBaseList::IsAnySelect(CPoint point)
{
	CBase* aa;
	POSITION pos= GetHeadPosition();
    while(pos!=NULL)
	{
		aa = (CBase *)GetNext(pos);
		if(aa->PtInOb(point)){
			return TRUE;
		}
   	}
	return FALSE;
}
void CBaseList::DeleteSelected()
{
	CBase* aa;
	POSITION pos,oldpos;
	pos= GetHeadPosition();
    while(pos!=NULL)
	{
		oldpos = pos;
		aa = (CBase *)GetNext(pos);
		if(aa->IsSelected()){
			aa->Delete();
		}
   	}
}
void CBaseList::RotateSelected(int Rotate)
{
	CBase* aa;
	POSITION pos,oldpos;
	pos= GetHeadPosition();
    while(pos!=NULL)
	{
		oldpos = pos;
		aa = (CBase *)GetNext(pos);
		if(aa->IsSelected()){
			aa->TotalAngle+=aa->ConvertAngle(Rotate);
			aa->RotateCell(aa->ConvertAngle(Rotate));
		}
   	}
}
void CBaseList::Notify(CBase* Remove)
{
	POSITION pos;
	pos = Find(Remove);
	RemoveAt(pos);
}
