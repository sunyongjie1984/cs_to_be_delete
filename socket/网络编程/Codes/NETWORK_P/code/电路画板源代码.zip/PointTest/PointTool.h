// PointTool.h: interface for the CPointTool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_POINTTOOL_H__37927A1A_613E_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_POINTTOOL_H__37927A1A_613E_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseTool.h"
#include "Epoint.h"
class CPointTool : public CBaseTool  
{
public:
	CPointTool(CWnd* cWnd,CElist* pList,CPointList* pOintList,CLineList* pLineList);
	virtual ~CPointTool();
public:	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
public:
	CEpoint* m_sigle;
};

#endif // !defined(AFX_POINTTOOL_H__37927A1A_613E_11D4_BBD7_600000000ECD__INCLUDED_)
