// Line.h: interface for the CLine class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINE_H__07575941_639C_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_LINE_H__07575941_639C_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Base.h"
//#include "epoint.h"
class CLine : public CBase  
{
public:
	CLine(int nType,CBaseList* pBaseList);
	CLine(CBase* p1,CBase* p2,CBaseList* pBaseList);
	virtual ~CLine();
public:
	BOOL PtInOb(CPoint point);
	void Draw(CDC* pDC);
	void OffSet(CSize size);
	void Notify();
public:
	CBase* parent1,*parent2;
};

#endif // !defined(AFX_LINE_H__07575941_639C_11D4_BBD7_600000000ECD__INCLUDED_)
