// ButtonList.h: interface for the ButtonList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BUTTONLIST_H__74583B42_741D_11D4_825F_60000000105A__INCLUDED_)
#define AFX_BUTTONLIST_H__74583B42_741D_11D4_825F_60000000105A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Button.h"
#include "Afxtempl.h"

class ButtonList  
{
public:
	ButtonList();
	virtual ~ButtonList();
public:
	CList < Button *,Button * > MyList;
	UINT m_ID;
	BOOL m_LFlag;
	UINT m_WhatToDo;
	BOOL m_BeSelected;
	void AddButton( Button * );
	void DeleteAllFlag( );
	void DeleteAllButton( );
	UINT CreateButton( CPoint ,int,int,UINT,UINT,UINT );
	void Draw( CDC * );
	void MoveAllButton( CPoint );
    void OnLButtonDown( UINT,CPoint );
	void OnLButtonUp( UINT,CPoint );
	void OnMouseMove( UINT,CPoint );
	void ExchangeButtonPosition( CPoint,UINT );
	void Serialize( CArchive &ar );

};

#endif // !defined(AFX_BUTTONLIST_H__74583B42_741D_11D4_825F_60000000105A__INCLUDED_)
