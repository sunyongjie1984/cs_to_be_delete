// SelectTool.h: interface for the CSelectTool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SELECTTOOL_H__A7085CE1_6217_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_SELECTTOOL_H__A7085CE1_6217_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseTool.h"

class CSelectTool : public CBaseTool  
{
public:
	CSelectTool(CWnd* cWnd,CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	virtual ~CSelectTool();
public:
	CBase* SelectedPoint;
	CBase* SelectedPoint1;
	CLine* m_pLine;
	BOOL ObSelect;
	BOOL PointSelect;
	BOOL ArrowSelect;
	BOOL TextSelect;
	BOOL ControlKey;
	CString cell[3];
public:	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
	void OnLButtonDblClk(UINT nFlags, CPoint point);
	BOOL GetCellString(CBase* aa);
};

#endif // !defined(AFX_SELECTTOOL_H__A7085CE1_6217_11D4_BBD7_600000000ECD__INCLUDED_)
