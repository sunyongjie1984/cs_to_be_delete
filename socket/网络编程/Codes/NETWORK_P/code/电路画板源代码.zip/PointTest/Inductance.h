// Inductance.h: interface for the CInductance class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INDUCTANCE_H__AFC29FE4_67BB_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_INDUCTANCE_H__AFC29FE4_67BB_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Base.h"

class CInductance : public CBase  
{
public:
	CInductance(int nType,CBaseList* pBaseList);
	CInductance(CBase* pp1,CBase* pp2,CBaseList* pBaseList);
	virtual ~CInductance();
public:
	void Draw(CDC* pDC);
	void OffSet(CSize size);
	CRect GetGraphRect();
	void SetPoint(CPoint pp);
	void RotateCell(double angle);
public:
	CPoint aa[2];
	CPoint bb[4];
};

#endif // !defined(AFX_INDUCTANCE_H__AFC29FE4_67BB_11D4_BBD7_600000000ECD__INCLUDED_)
