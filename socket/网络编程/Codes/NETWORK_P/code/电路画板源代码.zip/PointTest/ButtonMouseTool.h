// ButtonMouseTool.h: interface for the ButtonMouseTool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BUTTONMOUSETOOL_H__74583B43_741D_11D4_825F_60000000105A__INCLUDED_)
#define AFX_BUTTONMOUSETOOL_H__74583B43_741D_11D4_825F_60000000105A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ButtonList.h"

class ButtonMouseTool  
{
public:
	ButtonMouseTool();
	virtual ~ButtonMouseTool();
public:
	ButtonList list;
	void Draw( CDC * );
	void OnLButtonDown( UINT,CPoint );
	void OnLButtonUp( UINT,CPoint );
	void OnMouseMove( UINT,CPoint );
	void Serialize( CArchive &ar );

};

#endif // !defined(AFX_BUTTONMOUSETOOL_H__74583B43_741D_11D4_825F_60000000105A__INCLUDED_)
