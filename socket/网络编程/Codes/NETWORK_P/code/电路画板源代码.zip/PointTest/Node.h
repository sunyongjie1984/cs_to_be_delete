// Node.h: interface for the CNode class.
//
//////////////////////////////////////////////////////////////////////
#include <afxtempl.h>
#if !defined(AFX_NODE_H__97F8C9E2_6B10_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_NODE_H__97F8C9E2_6B10_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "base.h"
#include "elementserial.h"
class CMyNode
{
public:
	CMyNode(CBase* p1,CBase* p2);
	CMyNode(CBase* p1,CBase* p2,CBase* p3,CBase* p4);
	virtual ~CMyNode();
public:
	BOOL IfHaveSamePoint(CMyNode* NewOne);
	BOOL IfHaveSameElement(CMyNode* NewOne);
	void AddElement(CBase* elem);
	void AddPoint(CMyNode* point);
	void ArrangeElement();
	BOOL PointInNode(CBase* point);
	int  GetMyCount();
	BOOL IfHavePower();

	void AddElementToSerial(CElementSerial *m_Serial);
public:
	CList<CBase*,CBase*> m_pElementInNode;//Ԫ����
	CList<CBase*,CBase*> m_pPointInNode;//�˵��
	int Number;
};

#endif // !defined(AFX_NODE_H__97F8C9E2_6B10_11D4_BBD7_600000000ECD__INCLUDED_)
