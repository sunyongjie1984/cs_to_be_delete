// Rheostat.h: interface for the CRheostat class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RHEOSTAT_H__5B891A61_790B_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_RHEOSTAT_H__5B891A61_790B_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Base.h"

class CRheostat : public CBase  
{
public:
	CRheostat(int nType,CBaseList* pBaseList);
	CRheostat(CBase* pp1,CBase* pp2,CBaseList* pBaseList);
	virtual ~CRheostat();
public:
	void Draw(CDC* pDC);
	void OffSet(CSize size);
	CRect GetGraphRect();
	void SetPoint(CPoint pp);
	void RotateCell(double angle);
	//added
	CPoint Conv_coord(CPoint p,BOOL Real_or_Visual);//ת������
	CPoint Found_Right(CPoint pp);//
	CPoint Found_Left(CPoint pp);
	BOOL Pt_In_Arrow(CPoint pp);//�жϵ��Ƿ��ڼ�ͷ��
	void MovePoint(CPoint pp,CSize size);//�ƶ���ͷ
	void OffSetSlid(CSize size);
	void OffSetX(CSize size);
	void OffSetY(CSize size);
	BOOL CheckInRegn(CPoint pp,BOOL x_or_y);
	void GetValue(BOOL x_or_y);
	void SetEValue();
//	void SetPoinT(CPoint pp);
public:
	CPoint aa,bb,cc,dd;
	CPoint slid[3],slid4,slid5;
};

#endif // !defined(AFX_RHEOSTAT_H__5B891A61_790B_11D4_BBD7_600000000ECD__INCLUDED_)
