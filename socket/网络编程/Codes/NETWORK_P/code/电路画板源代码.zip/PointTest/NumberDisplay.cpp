// NumberDisplay.cpp: implementation of the NumberDisplay class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "NumberDisplay.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define FONTCOLOR RGB( 255,0,0 )
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NumberDisplay::NumberDisplay()
{
	m_zhengNum = 0;
	CPoint point ;
	point.x = 1;
	LogPenText.lopnWidth = point;
	LogPenText.lopnStyle = PS_SOLID;
	LogPenText.lopnColor = RGB( 0,0,0 );
	LogPen8.lopnWidth = point;
	LogPen8.lopnStyle = PS_SOLID;
	LogPen8.lopnColor = RGB( 191,191,191 );
	LogPenBackground.lopnWidth = point;
	LogPenBackground.lopnStyle = PS_SOLID;
	LogPenBackground.lopnColor = RGB( 117,245,214 );
	m_Number = 0;          //����С��λ
	m_date = 0;            //��Ҫ��ʾ���� 
	m_Hight = 0;           //���ڵĿ��͸�
	m_Width = 0;
	m_LeftTopPoint = CPoint( 0,0 );     //���ڵ����Ͻ�����
	m_HengWidth = 0;                    //��Ŀ��͸�
	m_HengHight = 0;
	m_ShuWidth = 0;                     //���Ŀ��͸�
	m_ShuHight = 0;
	m_FontDistance = 0;                 //����ļ��
	m_FontToWindowDistance = 0;         //����ߵ����ڱߵľ���
	m_BottomDistance = 0;               //����׵����ڵ׵ľ���
	m_FontSum = 0;                      //������ܸ��� 
	m_HengToShuDistance = 0;            //������ļ��
	m_FontWidth = 0;                     //����Ŀ��͸�
	m_FontHight = 0;

	m_Num = 0;
	m_tempPoint = CPoint( 0,0 );
	m_LFlag = FALSE;
	m_BeSelected = FALSE;

}

NumberDisplay::~NumberDisplay()
{

}

void NumberDisplay::SetParam( double date,CPoint point,int width,int hight,int i )
{
	m_Number = i;          //����С��λ
	m_date = date;
	m_LeftTopPoint = point;
	m_Width = width;
	m_Hight = hight;
	ArithPosition( date,width,hight );
}

void NumberDisplay::SetParam( double date,CPoint point,int width,int hight,int i,int j )
{
	m_zhengNum = j;     //����λ
	m_Number = i;          //����С��λ
	m_date = date;
	m_LeftTopPoint = point;
	m_Width = width;
	m_Hight = hight;
	ArithPosition( date,width,hight );
}

void NumberDisplay::ArithPosition( double date,int width,int hight )
{
	if ( hight<5||width<5 )
	{
		m_Flag = FALSE;              //������ʾ��־
	}
	else
	{
		int i = 0;
		int sum;
		sum = int( date );
		if ( sum == 0 )
		{
			i = 1;
		}
		else
		{
			while ( sum )
			{
				sum = sum/10;
				i++;
			}
		}
	    if ( m_zhengNum == 0 )
		{
			if ( m_Number )
			{
				m_FontSum = i+m_Number+1;      //��1����Ϊ��һ��С����
			}
			else
			{
				m_FontSum = i;
			}
		}
		else
		{
			if ( m_Number )
			{
				m_FontSum = m_zhengNum+m_Number+1;
			}
			else
			{
				m_FontSum = m_zhengNum;
			}
		}

		i = m_Width/m_FontSum;
		m_FontWidth = i/3*2;                  //����Ŀ���
		m_FontToWindowDistance = i/3;         //���嵽���ߵľ���
		m_FontDistance = m_FontToWindowDistance;
		
		m_HengToShuDistance = m_FontWidth/20;  //������ļ��
		if ( m_HengToShuDistance == 0 )
		{
			m_HengToShuDistance = 1;
		}
		m_HengHight = m_FontWidth/8;           //���
		m_HengWidth = m_FontWidth-m_HengToShuDistance*2;
		m_ShuWidth = m_HengHight;
		m_ShuHight = m_HengWidth*4/5;
		m_FontHight = m_ShuHight*2+2*m_HengToShuDistance;
		if ( m_FontHight<m_Hight )
		{
			m_BottomDistance = m_Hight/2-m_FontHight/2;
		}
		else
		{
			//m_FontHight = m_Hight/10*8;
			//m_ShuHight = m_FontHight/2-m
		}
	}
}



void NumberDisplay::Draw( CDC *pDC )
{
	CDC *dc = new CDC;
	CBitmap *bitmap = new CBitmap;
	CBitmap *old;
	dc->CreateCompatibleDC( pDC );
	bitmap->CreateCompatibleBitmap( pDC,m_Width,m_Hight );
	old = dc->SelectObject( bitmap );
	dc->PatBlt( 0,0,m_Width,m_Hight,WHITENESS );
	dc->FillSolidRect( 0,0,m_Width,m_Hight,LogPenBackground.lopnColor );
	int j = 1;
	int i = 0;
	int zheng,xiao;
	zheng = int( m_date );
	xiao = int( m_date*100 );
	xiao = xiao-zheng*100;
	int s = 0;
	if ( m_Number )
	{
		while ( s<m_Number )
		{
			i = xiao%10;
		    //array[j-1] = i;
			DrawNumber( i,dc,j );
			xiao =  xiao/10;
			j++;
			s++;
		}
		DrawPoint( j,dc );          //������ʾ
		//DrawDoublePoint( j,dc );    //ʱ����ʾ 
		j++;
	}
	if ( m_zhengNum == 0 )
	{
		if ( zheng == 0 )
		{
			DrawNumber( zheng,dc,j );
		}
		else
		{
			while ( zheng )
			{
				i = zheng%10;
				DrawNumber( i,dc,j );
				zheng = zheng/10;
				j++;
			}
		}
	}
	else
	{
		if ( zheng == 0 )
		{
			DrawNumber( zheng,dc,j );
			j++;
			DrawBottomPicture( dc,j );
			j++;
			DrawBottomPicture( dc,j );
			j++;
			DrawBottomPicture( dc,j );
		}
		else
		{
			s = 0;
			while ( zheng||s<4 )
			{
				if ( zheng == 0 )
				{
					DrawBottomPicture( dc,j );
				}
				else
				{
					i = zheng%10;
					DrawNumber( i,dc,j );
					zheng = zheng/10;
				}
				j++;
				s++;
			}
		}
	}

	pDC->BitBlt( m_LeftTopPoint.x,m_LeftTopPoint.y,m_Width,m_Hight,dc,0,0,SRCCOPY );
	dc->SelectObject( old );
	delete dc;
	delete bitmap;
}

void NumberDisplay::DrawNumber( int i,CDC *pDC,int j )
{
	switch ( i )
	{
	case 0:
		Draw0( pDC,j );
		break;
	case 1:
		Draw1( pDC,j );
		break;
	case 2:
		Draw2( pDC,j );
		break;
	case 3:
		Draw3( pDC,j );
		break;
	case 4:
		Draw4( pDC,j );
		break;
	case 5:
		Draw5( pDC,j );
		break;
	case 6:
		Draw6( pDC,j );
		break;
	case 7:
		Draw7( pDC,j );
		break;
	case 8:
		Draw8( pDC,j );
		break;
	case 9:
		Draw9( pDC,j );
		break;
	}
}

void NumberDisplay::Draw0( CDC *pDC,int j )
{
	DrawBottomPicture( pDC,j );
	CPoint point ;
	point.x = m_Width-m_FontToWindowDistance-j*m_FontWidth-(j-1 )*m_FontToWindowDistance/2;
	point.y = m_Hight-m_BottomDistance;
	DrawUpHeng( pDC,point,LogPenText );
	DrawLeftUpShu( pDC,point,LogPenText );
	DrawLeftDownShu( pDC,point,LogPenText );
	DrawRightUpShu( pDC,point,LogPenText );
	DrawRightDownShu( pDC,point,LogPenText );
	DrawDownHeng( pDC,point,LogPenText );
}

void NumberDisplay::Draw1( CDC *pDC,int j )
{
	DrawBottomPicture( pDC,j );
	CPoint point ;
	point.x = m_Width-m_FontToWindowDistance-j*m_FontWidth-(j-1 )*m_FontToWindowDistance/2;
	point.y = m_Hight-m_BottomDistance;
	DrawRightUpShu( pDC,point,LogPenText );
	DrawRightDownShu( pDC,point,LogPenText );
}

void NumberDisplay::Draw2( CDC *pDC,int j )
{
	DrawBottomPicture( pDC,j );
	CPoint point ;
	point.x = m_Width-m_FontToWindowDistance-j*m_FontWidth-(j-1 )*m_FontToWindowDistance/2;
	point.y = m_Hight-m_BottomDistance;
	DrawUpHeng( pDC,point,LogPenText );
	DrawMidHeng( pDC,point,LogPenText );
	DrawLeftDownShu( pDC,point,LogPenText );
	DrawRightUpShu( pDC,point,LogPenText );
	DrawDownHeng( pDC,point,LogPenText );
}

void NumberDisplay::Draw3( CDC *pDC,int j )
{
	DrawBottomPicture( pDC,j );
	CPoint point ;
	point.x = m_Width-m_FontToWindowDistance-j*m_FontWidth-(j-1 )*m_FontToWindowDistance/2;
	point.y = m_Hight-m_BottomDistance;
	DrawUpHeng( pDC,point,LogPenText );
	DrawMidHeng( pDC,point,LogPenText );
	DrawRightUpShu( pDC,point,LogPenText );
	DrawRightDownShu( pDC,point,LogPenText );
	DrawDownHeng( pDC,point,LogPenText );
}

void NumberDisplay::Draw4( CDC *pDC,int j )
{
	DrawBottomPicture( pDC,j );
	CPoint point ;
	point.x = m_Width-m_FontToWindowDistance-j*m_FontWidth-(j-1 )*m_FontToWindowDistance/2;
	point.y = m_Hight-m_BottomDistance;
	DrawMidHeng( pDC,point,LogPenText );
	DrawLeftUpShu( pDC,point,LogPenText );
	DrawRightUpShu( pDC,point,LogPenText );
	DrawRightDownShu( pDC,point,LogPenText );
}

void NumberDisplay::Draw5( CDC *pDC,int j )
{
	DrawBottomPicture( pDC,j );
	CPoint point ;
	point.x = m_Width-m_FontToWindowDistance-j*m_FontWidth-(j-1 )*m_FontToWindowDistance/2;
	point.y = m_Hight-m_BottomDistance;
	DrawUpHeng( pDC,point,LogPenText );
	DrawMidHeng( pDC,point,LogPenText );
	DrawLeftUpShu( pDC,point,LogPenText );
	DrawRightDownShu( pDC,point,LogPenText );
	DrawDownHeng( pDC,point,LogPenText );
}

void NumberDisplay::Draw6( CDC *pDC,int j )
{
	DrawBottomPicture( pDC,j );
	CPoint point ;
	point.x = m_Width-m_FontToWindowDistance-j*m_FontWidth-(j-1 )*m_FontToWindowDistance/2;
	point.y = m_Hight-m_BottomDistance;
	DrawUpHeng( pDC,point,LogPenText );
	DrawMidHeng( pDC,point,LogPenText );
	DrawLeftUpShu( pDC,point,LogPenText );
	DrawLeftDownShu( pDC,point,LogPenText );
	DrawRightDownShu( pDC,point,LogPenText );
	DrawDownHeng( pDC,point,LogPenText );
}

void NumberDisplay::Draw7( CDC *pDC,int j )
{
	DrawBottomPicture( pDC,j );
	CPoint point ;
	point.x = m_Width-m_FontToWindowDistance-j*m_FontWidth-(j-1 )*m_FontToWindowDistance/2;
	point.y = m_Hight-m_BottomDistance;
	DrawUpHeng( pDC,point,LogPenText );
	DrawRightUpShu( pDC,point,LogPenText );
	DrawRightDownShu( pDC,point,LogPenText );
}

void NumberDisplay::Draw8( CDC *pDC,int j )
{
	DrawBottomPicture( pDC,j );
	CPoint point ;
	point.x = m_Width-m_FontToWindowDistance-j*m_FontWidth-(j-1 )*m_FontToWindowDistance/2;
	point.y = m_Hight-m_BottomDistance;
	DrawUpHeng( pDC,point,LogPenText );
	DrawMidHeng( pDC,point,LogPenText );
	DrawLeftUpShu( pDC,point,LogPenText );
	DrawLeftDownShu( pDC,point,LogPenText );
	DrawRightUpShu( pDC,point,LogPenText );
	DrawRightDownShu( pDC,point,LogPenText );
	DrawDownHeng( pDC,point,LogPenText );
}

void NumberDisplay::DrawBottomPicture( CDC *pDC,int j )
{
	CPoint point ;
	point.x = m_Width-m_FontToWindowDistance-j*m_FontWidth-(j-1 )*m_FontToWindowDistance/2;
	point.y = m_Hight-m_BottomDistance;
	DrawUpHeng( pDC,point,LogPen8 );
	DrawMidHeng( pDC,point,LogPen8 );
	DrawLeftUpShu( pDC,point,LogPen8 );
	DrawLeftDownShu( pDC,point,LogPen8 );
	DrawRightUpShu( pDC,point,LogPen8 );
	DrawRightDownShu( pDC,point,LogPen8 );
	DrawDownHeng( pDC,point,LogPen8 );
}
void NumberDisplay::Draw9( CDC *pDC,int j )
{
	DrawBottomPicture( pDC,j );
	CPoint point ;
	point.x = m_Width-m_FontToWindowDistance-j*m_FontWidth-(j-1 )*m_FontToWindowDistance/2;
	point.y = m_Hight-m_BottomDistance;
	DrawUpHeng( pDC,point,LogPenText );
	DrawMidHeng( pDC,point,LogPenText );
	DrawLeftUpShu( pDC,point,LogPenText );
	DrawRightUpShu( pDC,point,LogPenText );
	DrawRightDownShu( pDC,point,LogPenText );
	DrawDownHeng( pDC,point,LogPenText );
}

void NumberDisplay::DrawUpHeng( CDC *pDC,CPoint point,LOGPEN logPen )
{
	CPen pen,*pPen;
	pen.CreatePenIndirect( &logPen );
	pPen = pDC->SelectObject( &pen );
    point.x = point.x+m_HengToShuDistance;
	point.y = point.y-m_FontHight;
	int i = 0;
	int width = m_HengWidth;
	while ( i<=m_HengHight )
	{
		pDC->MoveTo( point );
		pDC->LineTo( point.x+width-m_HengToShuDistance-i,point.y );
		point.x = point.x+1;
		width--;
		point.y = point.y+1;
		i++;
	}
	pDC->SelectObject( pPen );
	DeleteObject( pen );
}

void NumberDisplay::DrawDownHeng( CDC *pDC,CPoint point,LOGPEN logPen )
{
	CPen pen,*pPen;
	pen.CreatePenIndirect( &logPen );
	pPen = pDC->SelectObject( &pen );
	int i = 0;
    point.x = point.x+m_HengToShuDistance;
	int width = m_HengWidth;
	while ( i<=m_HengHight )
	{
    	pDC->MoveTo( point );
		pDC->LineTo( point.x+width-m_HengToShuDistance-i,point.y );
		point.x = point.x+1;
		width--;
		point.y = point.y-1;
		i++;
	}
	pDC->SelectObject( pPen );
	DeleteObject( pen );
}

void NumberDisplay::DrawMidHeng( CDC *pDC,CPoint point,LOGPEN logPen )
{
	CPen pen,*pPen;
	pen.CreatePenIndirect( &logPen );
	pPen = pDC->SelectObject( &pen );
	CPoint point1;
	point1.x = point.x+m_HengToShuDistance;
	point1.y = point.y-m_FontHight/2;
	int i = 0;
	int width = m_HengWidth;
	while ( i<=m_HengHight/2 )
	{
		pDC->MoveTo( point1 );
		pDC->LineTo( point1.x+width-m_HengToShuDistance-i,point1.y );
		point1.x = point1.x+1;
		width--;
		point1.y = point1.y+1;
		i++;
	}
	i = 0;
	width = m_HengWidth;
	point1.x = point.x+m_HengToShuDistance;
	point1.y = point.y-m_FontHight/2;
	while ( i<=m_HengHight/2 )
	{
		pDC->MoveTo( point1 );
		pDC->LineTo( point1.x+width-m_HengToShuDistance-i,point1.y );
		point1.x = point1.x+1;
		width--;
		point1.y = point1.y-1;
		i++;
	}
	pDC->SelectObject( pPen );
	DeleteObject( pen );
}

void NumberDisplay::DrawLeftUpShu( CDC *pDC,CPoint point,LOGPEN logPen )
{
	CPen pen,*pPen;
	pen.CreatePenIndirect( &logPen );
	pPen = pDC->SelectObject( &pen );
    point.x = point.x;
	point.y = point.y-m_FontHight+m_HengToShuDistance;
	int i = 0;
	int hight = m_ShuHight;
	while ( i<=m_ShuWidth )
	{
		pDC->MoveTo( point );
		pDC->LineTo( point.x,point.y+hight-i );
		point.x = point.x+1;
		hight--;
		point.y = point.y+1;
		i++;
	}
	pDC->SelectObject( pPen );
	DeleteObject( pen );
}

void NumberDisplay::DrawLeftDownShu( CDC *pDC,CPoint point,LOGPEN logPen )
{
	CPen pen,*pPen;
	pen.CreatePenIndirect( &logPen );
	pPen = pDC->SelectObject( &pen );
    point.x = point.x;
	point.y = point.y-m_HengToShuDistance;
	int i = 0;
	int hight = m_ShuHight;
	while ( i<=m_ShuWidth )
	{
		pDC->MoveTo( point );
		pDC->LineTo( point.x,point.y-hight+i );
		point.x = point.x+1;
		hight--;
		point.y = point.y-1;
		i++;
	}
	pDC->SelectObject( pPen );
	DeleteObject( pen );

}
void NumberDisplay::DrawRightUpShu( CDC *pDC,CPoint point,LOGPEN logPen )
{
	CPen pen,*pPen;
	pen.CreatePenIndirect( &logPen );
	pPen = pDC->SelectObject( &pen );
    point.x = point.x+m_FontWidth-m_HengToShuDistance;
	point.y = point.y-m_FontHight+m_HengToShuDistance;
	int i = 0;
	int hight = m_ShuHight;
	while ( i<=m_ShuWidth )
	{
		pDC->MoveTo( point );
		pDC->LineTo( point.x,point.y+hight-i );
		point.x = point.x-1;
		hight--;
		point.y = point.y+1;
		i++;
	}
	pDC->SelectObject( pPen );
	DeleteObject( pen );
}
void NumberDisplay::DrawRightDownShu( CDC *pDC,CPoint point,LOGPEN logPen )
{
	CPen pen,*pPen;
	pen.CreatePenIndirect( &logPen );
	pPen = pDC->SelectObject( &pen );
    point.x = point.x+m_FontWidth-m_HengToShuDistance;
	point.y = point.y-m_HengToShuDistance;
	int i = 0;
	int hight = m_ShuHight;
	while ( i<=m_ShuWidth )
	{
		pDC->MoveTo( point );
		pDC->LineTo( point.x,point.y-hight+i );
		point.x = point.x-1;
		hight--;
		point.y = point.y-1;
		i++;
	}
	pDC->SelectObject( pPen );
	DeleteObject( pen );

}

void NumberDisplay::DrawPoint( int j,CDC *pDC )
{
    DrawBottomPicture( pDC,j ); 
	CPen pen,*pPen;
	pen.CreatePenIndirect( &LogPenText );
	pPen = pDC->SelectObject( &pen );
	CPoint point;
	point.x = m_Width-m_FontToWindowDistance-j*m_FontWidth-(j-1 )*m_FontToWindowDistance/2;
	point.y = m_Hight-m_BottomDistance;
    point.x = point.x+m_FontWidth;
	point.y = point.y-m_HengToShuDistance/4;
    pDC->Rectangle( point.x-2*m_ShuWidth,point.y-2*m_HengHight,
		point.x,point.y );
	pDC->FillSolidRect( point.x-2*m_ShuWidth,point.y-2*m_HengHight,
        2*m_ShuWidth,2*m_HengHight,LogPenText.lopnColor );
	pDC->SelectObject( pPen );
	DeleteObject( pen );
}

void NumberDisplay::DrawDoublePoint( int j,CDC *pDC )
{
	DrawBottomPicture( pDC,j );
	CPen pen,*pPen;
	pen.CreatePenIndirect( &LogPenText );
	pPen = pDC->SelectObject( &pen );
	CPoint point,point1 ;
	point.x = m_Width-m_FontToWindowDistance-j*m_FontWidth-(j-1 )*m_FontToWindowDistance/2;
	point.y = m_Hight-m_BottomDistance;
    point1.x = point.x+m_FontWidth;
	point1.y = point.y-m_FontHight/3;
    pDC->Rectangle( point1.x-2*m_ShuWidth,point1.y,
		point1.x,point1.y+2*m_HengHight );
	pDC->FillSolidRect( point1.x-2*m_ShuWidth,point1.y,
        2*m_ShuWidth,2*m_HengHight,LogPenText.lopnColor );
	point1.x = point.x+m_FontWidth;
	point1.y = point.y-m_FontHight/3*2;
    pDC->Rectangle( point1.x-2*m_ShuWidth,point1.y-2*m_HengHight,
		point1.x,point1.y );
	pDC->FillSolidRect( point1.x-2*m_ShuWidth,point1.y-2*m_HengHight,
        2*m_ShuWidth,2*m_HengHight,LogPenText.lopnColor );
	pDC->SelectObject( pPen );
	DeleteObject( pen );
}


BOOL NumberDisplay::PtInWindow( CPoint point )
{
	CRect rect;
	rect = CRect( m_LeftTopPoint.x,m_LeftTopPoint.y,m_LeftTopPoint.x+m_Width,m_LeftTopPoint.y+m_Hight );
	if ( rect.PtInRect( point ) )
	{
		return TRUE;
	}
	return FALSE;
}

void NumberDisplay::ArithDragPosition( CPoint point )
{
	if ( m_Num == 0 )
	{
		m_tempPoint = point-m_LeftTopPoint;
		m_Num++;
	}
	else
	{
		m_LeftTopPoint = point-m_tempPoint;
	}
}

void NumberDisplay::OnLButtonDown( UINT nFlags,CPoint point )
{
	m_LFlag = TRUE;
	if ( PtInWindow( point ) )
	{
		::SetCursor( ::LoadCursor( NULL,IDC_CROSS ) );
		ArithDragPosition( point );
		m_BeSelected = TRUE;
	}
}

void NumberDisplay::OnLButtonUp( UINT nFlags,CPoint point )
{
	m_LFlag = FALSE;
	if ( m_BeSelected )
	{
		ArithDragPosition( point );
		m_BeSelected = FALSE;
		m_Num = 0;
		m_tempPoint = CPoint( 0,0 );
	}
}

void NumberDisplay::OnMouseMove( UINT nFlags,CPoint point )
{
	if ( PtInWindow( point ) )
	{
        ::SetCursor( ::LoadCursor( NULL,IDC_CROSS ) );
	}
	if ( m_LFlag )
	{
		if ( m_BeSelected )
		{
			::SetCursor( ::LoadCursor( NULL,IDC_CROSS ) );
			ArithDragPosition( point );
		}
	}
}
