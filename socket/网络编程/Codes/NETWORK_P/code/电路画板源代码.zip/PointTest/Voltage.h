// Voltage.h: interface for the CVoltage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VOLTAGE_H__53B48222_6853_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_VOLTAGE_H__53B48222_6853_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Base.h"

class CVoltage : public CBase  
{
public:
	CVoltage(int nType,CBaseList* pBaseList);
	CVoltage(CBase* pp1,CBase* pp2,CBaseList* pBaseList);
	virtual ~CVoltage();
public:
	void Draw(CDC* pDC);
	void OffSet(CSize size);
	CRect GetGraphRect();
	void SetPoint(CPoint pp);
	//void RotateCell(double angle);
public:
	CPoint aa,bb,sign;
};

#endif // !defined(AFX_VOLTAGE_H__53B48222_6853_11D4_BBD7_600000000ECD__INCLUDED_)
