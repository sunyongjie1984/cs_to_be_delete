// JointList.cpp: implementation of the CJointList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "JointList.h"
#include "Component.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CJointList::CJointList()
{
	m_pOldList=&m_pListJoint;
	m_pCopyList=&m_copyListJoint;
	m_pSaveList=&m_saveListJoint;
	m_pSaveRealList = & m_saveRealList;
}

CJointList::~CJointList()
{
	RemoveElList(&(m_pDiodeList));
	RemoveAll(m_pOldList);
	RemoveAll(m_pSaveList);
	RemoveAll(m_pSaveRealList);
	RemoveAll(m_pCopyList);
	RemoveElList(&(m_VoltList));
	RemoveElList(&(m_AmperList));
}
void CJointList::ClearUpAllList()
{
	RemoveElList(&(m_pDiodeList));
	RemoveAll(m_pOldList);
	RemoveAll(m_pSaveList);
	RemoveAll(m_pSaveRealList);
	RemoveAll(m_pCopyList);
	RemoveElList(&(m_VoltList));
	RemoveElList(&(m_AmperList));
}
void CJointList::AddJoint(JointList *p,int order)
{
	BOOL b;
	POSITION pos;
	if(p->IsEmpty())
	{
		b=false;
	}
	else
	{
		pos=p->GetHeadPosition();
		while(pos!=NULL)
		{
			if((p->GetNext(pos))->GetOrder()==order)
			{
				b=true;
				break;
			}
			else
			{
				b=false;
			}
		}
	}
	if(!b)
	{
		CAJoint *pJoint=new CAJoint(order);
		pJoint->SetVoltage(0);
		p->AddTail(pJoint);
	}
	
}
void CJointList::RemoveJoint(CAJoint *pJoint,JointList *pList)
{
	POSITION pos=pList->Find(pJoint,NULL);
	pJoint=pList->GetAt(pos);
	pList->RemoveAt(pos);
	if(pJoint)
	{
		delete pJoint;
	}
}
CAJoint* CJointList::GetJoint(int order,JointList *pList)
{
	POSITION pos=pList->GetHeadPosition();
	CAJoint *p;
	while(pos!=NULL)
	{
		p=pList->GetNext(pos);
		if(p->GetOrder()==order)
		{
			return p;
		}
	}
	return NULL;
}
void CJointList::AdjustJoint(JointList *pList)
{
	if(pList->IsEmpty())
	{
		return;
	}
	else
	{
		CAJoint *pJoint;
		int i=1;
		POSITION pos,sourcePos[10];
		pos=pList->GetHeadPosition();
		
		while(pos!=NULL)
		{
			pJoint=pList->GetAt(pos);
			int b=pJoint->GetOrder();
//			pJoint->SearchElecSource();
			if(pJoint->IsHoldElecSource())
			{
				sourcePos[i]=pos;
				i++;
			}
			pList->GetNext(pos);
		}
		for(int j=1;j<i;j++)
		{
			pList->RemoveAt(sourcePos[j]);//Is delete the power joint
		}
	}
}
void CJointList::CreateCopyJointList(JointList *pSourceList,JointList *pCopyList)
{
	RegulateListAsOrder(pSourceList);
	SetWorkedInList(false,pSourceList);
	RemoveAll(pCopyList);
	CAJoint *pJoint;
	CAElement *pElement,*pNewElement;
	int type;
	float value;
	BOOL bIsClose;
	POSITION pos=pSourceList->GetHeadPosition();
	while(pos!=NULL)
	{
		pJoint=pSourceList->GetNext(pos);
		POSITION pos1=pJoint->pElementList.m_pListElement.GetHeadPosition();
		while(pos1!=NULL)
		{
			pElement=pJoint->pElementList.m_pListElement.GetNext(pos1);
			if(!(pElement->IsWorked()))
			{
				type=pElement->GetType();
				if(type != ID_SWITCH)
				{
					value=pElement->GetValue();
					pNewElement=NewElement(type,value);
				}
				else
				{
					bIsClose = pElement->IsClose();
					pNewElement = NewSwitch(bIsClose);
				}
				CAJoint *p1,*p2;
				p1=pElement->GetJointStruct()->pJoint1;
				p2=pElement->GetJointStruct()->pJoint2;
				int index = pElement->GetIndex();
				pNewElement->SetIndex( index );
				pNewElement->SetOrderStruct( p1->GetOrder(),p2->GetOrder() );

			//	p1->pElementList.AddElement(pNewElement);
				int order1,order2;
				order1=p1->GetOrder();
				order2=p2->GetOrder();
				AddJoint(pCopyList,order1);
				AddJoint(pCopyList,order2);
				pNewElement->SetStructJoint(GetJoint(order1,pCopyList),GetJoint(order2,pCopyList));
				GetJoint(order1,pCopyList)->pElementList.AddElement(pNewElement);
				GetJoint(order2,pCopyList)->pElementList.AddElement(pNewElement);
				pElement->SetWorked(true);
			}
		}
	}
	RegulateListAsOrder(pCopyList);
}


POSITION CJointList::TwoLoop(POSITION pos,JointList *pList)
{
	while(pos!=NULL)
	{
		CAJoint *pJoint=pList->GetAt(pos);
		POSITION pos1=pos;
		while(pos1!=NULL)
		{
			CAJoint *pJointNext=pList->GetAt(pos1);
			if(pJoint->GetOrder()>pJointNext->GetOrder())
			{
				pList->RemoveAt(pos);
				pos1=pList->Find(pJointNext,NULL);
				pList->InsertAfter(pos1,pJoint);
				return pos;
			}
			pList->GetNext(pos1);
		}
		pList->GetNext(pos);
	}
	return pos;
}

void CJointList::RegulateListAsOrder(JointList *pList)
{
	POSITION pos;
	pos=pList->GetHeadPosition();
	while(pos!=NULL)
	{
		pos=TwoLoop(pos,pList);
		if(pos!=NULL)
		{
			pos=pList->GetHeadPosition();
		}
		else
		{
			break;
		}
	}
}

void CJointList::RemoveAll(JointList *pList)
{
	POSITION pos=pList->GetHeadPosition();
	while(pos!=NULL)
	{
		CAJoint *pJoint=pList->GetNext(pos);
		POSITION pos1=pJoint->pElementList.m_pListElement.GetHeadPosition();
		while(pos1!=NULL)
		{
			CAElement *pElement=pJoint->pElementList.m_pListElement.GetNext(pos1);
			CAJoint *p1,*p2,*pOther;
			p1=pElement->GetJointStruct()->pJoint1;
			p2=pElement->GetJointStruct()->pJoint2;
			if(p1==pJoint)
			{
				pOther=p2;
			}
			else
			{
				pOther=p1;
			}
			POSITION pos3=pOther->pElementList.m_pListElement.GetHeadPosition();
			while(pos3!=NULL)
			{
				CAElement *pElement1=pOther->pElementList.m_pListElement.GetAt(pos3);
				if(pElement1==pElement)
				{
					pOther->pElementList.m_pListElement.RemoveAt(pos3);
					break;
				}
				pOther->pElementList.m_pListElement.GetNext(pos3);
			}
			if(pElement)
			{
				delete pElement;
			}
		}
		pJoint->pElementList.m_pListElement.RemoveAll();
		if(pJoint)
		{
			delete pJoint;
		}
	}
	pList->RemoveAll();
}
CAElement* CJointList::NewElement(int type, float value)
{
	switch(type)
	{
	case ID_POWER:
		return (new CAPower(value));
		break;
	case ID_RESISTANCE:
		return (new CAResistance(value));
		break;
	case ID_CAPACITANCE:
		return (new CACapacity(value));
		break;
	case ID_INDUCTANCE:
		return (new CAInductor(value));
		break;
//	case ID_SWITCH:
//		return (new CASwitch(BOOL(value)));
	//	break;
	case ID_DIODE:
		return (new CADiode());
		break;
	case ID_CURRENT_METER:
		return (new CAAmpermeter());
		break;
	case ID_VOLTAGE_METER:
		return (new CAVoltmeter());
		break;
	default:
		return NULL;
		break;
	}
}

void CJointList::SetWorkedInList(BOOL b, JointList *pList)
{
	CAJoint *pJoint;
	POSITION pos=pList->GetHeadPosition();
	while(pos!=NULL)
	{
		pJoint=pList->GetNext(pos);
		CAElement *pElement;
		POSITION pos1=pJoint->pElementList.m_pListElement.GetHeadPosition();
		while(pos1!=NULL)
		{
			pElement=pJoint->pElementList.m_pListElement.GetNext(pos1);
			pElement->SetWorked(b);
		}
	}
}
void CJointList::SetAllIsAllPowerInList(BOOL b,JointList *pList)
{
	POSITION pos1=pList->GetHeadPosition();
	while(pos1!=NULL)
	{
		CAJoint *pJoint=pList->GetNext(pos1);
		CAElement *pElement;
		POSITION pos2=pJoint->pElementList.m_pListElement.GetHeadPosition();
		while(pos2!=NULL)
		{
			pElement=pJoint->pElementList.m_pListElement.GetNext(pos2);
			pElement->SetIsAsPower(b);
		}
	}
}
void CJointList::SaveCapacityInList(JointList *pList,CList<CAElement*,CAElement*>*pCapaList)
{
	POSITION posCapa=pCapaList->GetHeadPosition();
	while(posCapa!=NULL)
	{
		CAElement *pCapa=pCapaList->GetNext(posCapa);
		delete pCapa;
	}
	pCapaList->RemoveAll();
	POSITION pos=pList->GetHeadPosition();
	while(pos!=NULL)
	{
		CAJoint *pJoint=pList->GetNext(pos);
		CAElement *pElement;
		POSITION pos1=pJoint->pElementList.m_pListElement.GetHeadPosition();
		while(pos1!=NULL)
		{
			pElement=pJoint->pElementList.m_pListElement.GetNext(pos1);
			if(pElement->GetType()==ID_CAPACITANCE)
			{
				BOOL bIsAdd=false;
				if(pCapaList->IsEmpty())
				{
					bIsAdd=false;
				}
				else
				{
					POSITION posIs=pCapaList->GetHeadPosition();
					while(posIs!=NULL)
					{
						CAElement *pIs=pCapaList->GetNext(posIs);
						if(pElement!=pIs)
						{
							bIsAdd=false;
						}
						else
						{
							bIsAdd=true;
							break;
						}
					}
				}
				if(!bIsAdd)
				{
					pCapaList->AddTail(pElement);
				}
			}
			
		}
	}
}
void CJointList::AdjustCapacityInList(JointList *pList,CList<CAElement*,CAElement*>*pCapaList)
{
	POSITION capaPos=pCapaList->GetHeadPosition();
	while(capaPos!=NULL)
	{
		CAElement *pElement=pCapaList->GetNext(capaPos);
		CAJoint *p1=pElement->GetJointStruct()->pJoint1;
		CAJoint *p2=pElement->GetJointStruct()->pJoint2;
		POSITION posCapa1=p1->pElementList.m_pListElement.Find(pElement,NULL);
		POSITION posCapa2=p2->pElementList.m_pListElement.Find(pElement,NULL);
		p1->pElementList.m_pListElement.RemoveAt(posCapa1);
		p2->pElementList.m_pListElement.RemoveAt(posCapa2);
		pElement->GetCapacityOrderList(p1)->RemoveAll();
		pElement->GetCapacityOrderList(p2)->RemoveAll();
		SearchEqualVoltageJoint(p1,pElement,pList);
		SearchEqualVoltageJoint(p2,pElement,pList);	
	//	delete pElement;
	}
}
void CJointList::SearchEqualVoltageJoint(CAJoint *pJoint,CAElement *pCapa,JointList *pList)//search pJoint's equal voltage joint
{
	int count=pJoint->pElementList.m_pListElement.GetCount();
	CAJoint *pOtherJoint=pJoint;
	while( count==1 && !pOtherJoint->IsHoldElecSource() )
	{
		POSITION pos1=pList->Find(pOtherJoint,NULL);
		pList->RemoveAt(pos1);
		pCapa->GetCapacityOrderList(pJoint)->AddTail(pOtherJoint->GetOrder());
		CAElement *pElement=pOtherJoint->pElementList.m_pListElement.GetHead();
		CAJoint *p11=pElement->GetJointStruct()->pJoint1;
		CAJoint *p22=pElement->GetJointStruct()->pJoint2;
		if(p11==pJoint)
		{
			pOtherJoint=p22;
		}
		else
		{
			pOtherJoint=p11;
		}
		POSITION pos=pOtherJoint->pElementList.m_pListElement.Find(pElement,NULL);
		pOtherJoint->pElementList.m_pListElement.RemoveAt(pos);
		delete pElement;
		count=pOtherJoint->pElementList.m_pListElement.GetCount();
		
	//		delete pOtherJoint;
		
	}
	pJoint->m_nEqualValueOrder=pOtherJoint->GetOrder();
	CAJoint* pInSave = GetJoint( pJoint->GetOrder(),m_pSaveList);
	pInSave->m_nEqualValueOrder = pOtherJoint->GetOrder();
}
void CJointList::RemoveAboutCapacity(JointList *pList,CList<CAElement*,CAElement*>*pCapaList)
{
	POSITION posCapa=pCapaList->GetHeadPosition();
	while(posCapa!=NULL)
	{
		CAElement *pCapa=pCapaList->GetNext(posCapa);
		CAJoint *p1=pCapa->GetJointStruct()->pJoint1;
		CAJoint *p2=pCapa->GetJointStruct()->pJoint2;
		CList<int,int>* OrderList1=pCapa->GetCapacityOrderList(p1);
		CList<int,int>* OrderList2=pCapa->GetCapacityOrderList(p2);
	}
}
void CJointList::AllElsToOthers(int type1,int type2,float value,JointList *pList)
{
	SetWorkedInList(false,pList);
	POSITION pos = pList->GetHeadPosition();
	while(pos != NULL)
	{
		CAJoint *pJoint = pList->GetNext(pos);
		POSITION posE = pJoint->pElementList.m_pListElement.GetHeadPosition();
		while(posE != NULL)
		{
			CAElement *pE = pJoint->pElementList.m_pListElement.GetNext(posE);
			if(pE->GetType() == type1)
			{
				OneElToOther(pE,type2,value);
				posE = pJoint->pElementList.m_pListElement.GetHeadPosition();
			}

		}
	//	pJoint->pElementList.AllElToOther(type1,type2,value);
	}
}
float CJointList::GetAverageOfResistance(JointList *pList)
{
	SetWorkedInList(false,pList);
	float fResistanceV=0;
	int nResistanceNum=0;
	POSITION posJ = pList->GetHeadPosition();
	while(posJ != NULL)
	{
		CAJoint *pJ = pList->GetNext(posJ);
		POSITION posE = pJ->pElementList.m_pListElement.GetHeadPosition();
		while(posE != NULL)
		{
			CAElement *pE = pJ->pElementList.m_pListElement.GetNext(posE);
			if(pE->GetType() == ID_RESISTANCE && !(pE->IsWorked()))
			{
				fResistanceV += pE->GetValue();
				nResistanceNum ++;
				pE->SetWorked(true);
			}
		}
	}
	if(nResistanceNum > 0)
	{
		return float(fResistanceV/nResistanceNum);
	}
	else
	{
		return 0;
	}
}

BOOL CJointList::IsExistSpecEl(int type, JointList *pList,ElementList *pElList)
{
	RemoveElList(pElList);
	SetWorkedInList(false,pList);
	POSITION posJ = pList->GetHeadPosition();
	while(posJ != NULL)
	{
		CAJoint *pJoint = pList->GetNext(posJ);
		POSITION posE = pJoint->pElementList.m_pListElement.GetHeadPosition();
		while(posE != NULL)
		{
			CAElement *pE = pJoint->pElementList.m_pListElement.GetNext(posE);
			if(pE->GetType() == type && !(pE->IsWorked()))
			{
				CAElement *pNewEl = NewElement(type,pE->GetValue());
				int index = pE->GetIndex();
				pNewEl->SetIndex( index );
				CAJoint* p1 = pE->GetJointStruct()->pJoint1;
				CAJoint* p2 = pE->GetJointStruct()->pJoint2;
				pNewEl->SetStructJoint(p1,p2);
				pNewEl->SetOrderStruct( p1->GetOrder(),p2->GetOrder() );
				pElList->AddTail(pNewEl);
				pE->SetWorked(true);
			}
		}
	}
	if(pElList->IsEmpty())
	{
		return false;
	}
	else
	{
		return true;
	}
}
void CJointList::RemoveElList(ElementList *pElList)
{
	POSITION pos = pElList->GetHeadPosition();
	while(pos != NULL)
	{
		CAElement *pE = pElList->GetAt(pos);
		pElList->RemoveAt(pos);
		delete pE;
		pos = pElList->GetHeadPosition();
	}
}


void CJointList::AdjustPloarityOfDiode(int nArrayPowerNum)
{
//	CreateCopyJointList(m_pCopyList,m_pOldList);
	POSITION posE = m_pDiodeList.GetHeadPosition();
	while(posE != NULL)
	{
		CAElement *pE = m_pDiodeList.GetAt(posE);
		int order1 = pE->GetJointStruct()->pJoint1->GetOrder();
		int order2 = pE->GetJointStruct()->pJoint2->GetOrder();
		CAJoint *p1InSave = GetJoint(order1,m_pSaveList);
		CAJoint *p2InSave = GetJoint(order2,m_pSaveList);
		CAJoint *p1InOld = GetJoint(order1,m_pOldList);
		CAJoint *p2InOld = GetJoint(order2,m_pOldList);
		CAElement *pEInOld = GetElement(pE,m_pOldList);
		if((p1InSave->m_fRealVoltage[nArrayPowerNum])< (p2InSave->m_fRealVoltage[nArrayPowerNum]))
		{
			m_pDiodeList.RemoveAt(posE);
			OneElToOther(pEInOld,ID_CAPACITANCE,1);
			CAElement* pEInSave = GetElement(pE,m_pSaveList);
			pEInSave->SetIsAsCapacity(true);
		}
		else
		{
			m_pDiodeList.RemoveAt(posE);
			OneElToOther(pEInOld,ID_INDUCTANCE,1);
			CAElement* pEInSave = GetElement(pE,m_pSaveList);
			pEInSave->SetIsAsInductor(true);
		}
		delete pE;
		posE = m_pDiodeList.GetHeadPosition();
	}
}



CAElement* CJointList::GetElement(CAElement* pE,JointList* pList)
{
	int index = pE->GetIndex();
	POSITION posJ = pList->GetHeadPosition();
	while( posJ != NULL )
	{
		CAJoint* pJ = pList->GetNext( posJ );
		POSITION posE = pJ->pElementList.m_pListElement.GetHeadPosition();
		while( posE != NULL )
		{
			CAElement* pEOther = pJ->pElementList.m_pListElement.GetNext( posE );
			if( index == pEOther->GetIndex() )
			{
				return pEOther;
			}
		}
	}
	return NULL;
/*	POSITION pos = p1->pElementList.m_pListElement.GetHeadPosition();
	while(pos != NULL)
	{
		CAElement *pE = p1->pElementList.m_pListElement.GetNext(pos);
		CAJoint *p11,*p22;
		p11 = pE->GetJointStruct()->pJoint1;
		p22 = pE->GetJointStruct()->pJoint2;
		int order1 = p1->GetOrder();
		int order2 = p2->GetOrder();
		int order11 = p11->GetOrder();
		int order22 = p22->GetOrder();
		if(order11 == order1 && order22 == order2)
		{
			return pE;
		}
		else if(order11 == order2 && order22 == order1)
		{
			return pE;
		}
	}
	return NULL;*/
}

void CJointList::SetZeroVoltage(int nArrayPowerNum, JointList *pList)
{
	POSITION pos = pList->GetHeadPosition();
	while(pos != NULL)
	{
		CAJoint *pJ = pList->GetNext(pos);
		pJ->m_fRealVoltage[nArrayPowerNum] = 0;
		pJ->m_fVoltage[nArrayPowerNum] = 0;
	}
}

void CJointList::OneElToOther(CAElement *pE, int type, float value)
{
	CAJoint *p1 = pE->GetJointStruct()->pJoint1;
	CAJoint *p2 = pE->GetJointStruct()->pJoint2;
	CAElement *pNewEl = NewElement(type,value);
	pNewEl->SetStructJoint(p1,p2);
	int index = pE->GetIndex();
	pNewEl->SetIndex( index );
	pNewEl->SetOrderStruct( p1->GetOrder(),p2->GetOrder() );
	POSITION posDel1 = p1->pElementList.m_pListElement.Find(pE);
	POSITION posDel2 = p2->pElementList.m_pListElement.Find(pE);
	p1->pElementList.m_pListElement.RemoveAt(posDel1);
	p2->pElementList.m_pListElement.RemoveAt(posDel2);
	p1->pElementList.m_pListElement.AddTail(pNewEl);
	p2->pElementList.m_pListElement.AddTail(pNewEl);
	delete pE;
	
}

void CJointList::DealWithSwitch(JointList *pList)
{
	POSITION posJ = pList->GetHeadPosition();
	while(posJ != NULL)
	{
		CAJoint* pJ = pList->GetNext(posJ);
		POSITION posE = pJ->pElementList.m_pListElement.GetHeadPosition();
		while(posE != NULL)
		{
			CAElement* pE = pJ->pElementList.m_pListElement.GetNext(posE);
			if(pE->GetType() == ID_SWITCH)
			{
				CAElement* pNewE;
				if(pE->IsClose())
				{
					pNewE = NewElement(ID_INDUCTANCE,1);
					CAElement* pEInSave = GetElement(pE,m_pSaveList);
					pEInSave->SetIsAsInductor(true);
				}
				else
				{
					pNewE = NewElement(ID_CAPACITANCE,1);
					CAElement* pEInSave = GetElement(pE,m_pSaveList);
					pEInSave->SetIsAsCapacity(true);
				}
				CAJoint* p1 = pE->GetJointStruct()->pJoint1;
				CAJoint* p2 = pE->GetJointStruct()->pJoint2;
				int index   = pE->GetIndex();
				pNewE->SetIndex( index );
				pNewE->SetOrderStruct( p1->GetOrder(),p2->GetOrder() );
				POSITION posDel1 = p1->pElementList.m_pListElement.Find(pE,NULL);
				POSITION posDel2 = p2->pElementList.m_pListElement.Find(pE,NULL);
				p1->pElementList.m_pListElement.RemoveAt(posDel1);
				p2->pElementList.m_pListElement.RemoveAt(posDel2);
				delete pE;
				pNewE->SetStructJoint(p1,p2);
				p1->pElementList.m_pListElement.AddTail(pNewE);
				p2->pElementList.m_pListElement.AddTail(pNewE);
				posE = pJ->pElementList.m_pListElement.GetHeadPosition();
			}
		}
	}
}

CAElement* CJointList::NewSwitch(BOOL bIsClose)
{
	return (new CASwitch(bIsClose));
}

void CJointList::DealWithAmpermeter(JointList *pList)
{
	POSITION posJ = pList->GetHeadPosition();
	while(posJ != NULL)
	{
		CAJoint* pJ = pList->GetNext(posJ);
		POSITION posE = pJ->pElementList.m_pListElement.GetHeadPosition();
		while(posE != NULL)
		{
			CAElement* pE = pJ->pElementList.m_pListElement.GetNext(posE);
			if(pE->GetType() == ID_CURRENT_METER)
			{
				CAElement* pNewE = NewElement(ID_INDUCTANCE,1);
				CAElement* pEInSave = GetElement(pE,m_pSaveList);
				pEInSave->SetIsAsInductor(true);
				CAJoint* p1 = pE->GetJointStruct()->pJoint1;
				CAJoint* p2 = pE->GetJointStruct()->pJoint2;
				int index   = pE->GetIndex();
				pNewE->SetIndex( index );
				pNewE->SetOrderStruct( p1->GetOrder(),p2->GetOrder() );
				POSITION posDel1 = p1->pElementList.m_pListElement.Find(pE,NULL);
				POSITION posDel2 = p2->pElementList.m_pListElement.Find(pE,NULL);
				p1->pElementList.m_pListElement.RemoveAt(posDel1);
				p2->pElementList.m_pListElement.RemoveAt(posDel2);
				delete pE;
				pNewE->SetStructJoint(p1,p2);
				p1->pElementList.m_pListElement.AddTail(pNewE);
				p2->pElementList.m_pListElement.AddTail(pNewE);
				posE = pJ->pElementList.m_pListElement.GetHeadPosition();
			}
		}
	}
}

void CJointList::DealWithVoltmeter(JointList *pList)
{
	POSITION posJ = pList->GetHeadPosition();
	while(posJ != NULL)
	{
		CAJoint* pJ = pList->GetNext(posJ);
		POSITION posE = pJ->pElementList.m_pListElement.GetHeadPosition();
		while(posE != NULL)
		{
			CAElement* pE = pJ->pElementList.m_pListElement.GetNext(posE);
			if(pE->GetType() == ID_VOLTAGE_METER)
			{
				CAElement *pNewE = NewElement(ID_CAPACITANCE,1);
				CAElement *pEInSave = GetElement(pE,m_pSaveList);
				pEInSave->SetIsAsCapacity(true);
				CAJoint* p1 = pE->GetJointStruct()->pJoint1;
				CAJoint* p2 = pE->GetJointStruct()->pJoint2;
				int index   = pE->GetIndex();
				pNewE->SetIndex( index );
				pNewE->SetOrderStruct( p1->GetOrder(),p2->GetOrder() );
				POSITION posDel1 = p1->pElementList.m_pListElement.Find(pE,NULL);
				POSITION posDel2 = p2->pElementList.m_pListElement.Find(pE,NULL);
				p1->pElementList.m_pListElement.RemoveAt(posDel1);
				p2->pElementList.m_pListElement.RemoveAt(posDel2);
				delete pE;
				pNewE->SetStructJoint(p1,p2);
				p1->pElementList.m_pListElement.AddTail(pNewE);
				p2->pElementList.m_pListElement.AddTail(pNewE);
				posE = pJ->pElementList.m_pListElement.GetHeadPosition();
			}
		}
	}
}

void CJointList::SetVoltmeterValue(JointList *pList)
{
	POSITION posJ = pList->GetHeadPosition();
	while(posJ != NULL)
	{
		CAJoint* pJ = pList->GetNext(posJ);
		POSITION posE = pJ->pElementList.m_pListElement.GetHeadPosition();
		while(posE != NULL)
		{
			CAElement* pE = pJ->pElementList.m_pListElement.GetNext(posE);
			if(pE->GetType() == ID_VOLTAGE_METER)
			{
				CAJoint* p1 = pE->GetJointStruct()->pJoint1;
				CAJoint* p2 = pE->GetJointStruct()->pJoint2;
				float v = p2->GetVoltage()-p1->GetVoltage();
				pE->SetVoltage(v);
			}
		}
	}
}
void CJointList::SetVoltmeterCurrent(CAElement* pVoltmeter,CAJoint* p)
{
	pVoltmeter->SetCurrent(0);
}
void CJointList::SetAmpermeterCurrent(CAElement* pAmper,CAJoint* p)
{
	float i = 0;
	CAJoint* p1 = pAmper->GetJointStruct()->pJoint1;
	CAJoint* p2 = pAmper->GetJointStruct()->pJoint2;
	CAJoint* pOther;
	if(p1 == p) pOther = p2;
	else		pOther = p1;
	POSITION posE = pOther->pElementList.m_pListElement.GetHeadPosition();
	while(posE != NULL)
	{
		CAElement* pE = pOther->pElementList.m_pListElement.GetNext(posE);
		if(!pE->IsWorked() && pE!=pAmper)
		{
			SetSpecialElCurrent(pE,pOther);
		}
		if( pE != pAmper )
		{
			if((pE->IsTheP1Joint( pOther ) && !pAmper->IsTheP1Joint( pOther ))
			|| (!pE->IsTheP1Joint( pOther ) && pAmper->IsTheP1Joint( pOther )))
			{
				i += pE->GetCurrent();
			}
			else if(( pE->IsTheP1Joint( pOther ) && pAmper->IsTheP1Joint( pOther ))
				 || ( !pE->IsTheP1Joint( pOther ) && !pAmper->IsTheP1Joint( pOther )))
			{
				i += -pE->GetCurrent();
			}
		}
	//	i += pE->GetCurrent();
	}
	pAmper->SetWorked(true);
	pAmper->SetCurrent(i);
}

void CJointList::SetAllElCurrent(JointList *pList)
{
	SetWorkedInList(false,pList);
	POSITION posJ = pList->GetHeadPosition();
	while(posJ != NULL)
	{
		CAJoint* pJ = pList->GetNext(posJ);
		POSITION posE = pJ->pElementList.m_pListElement.GetHeadPosition();
		while(posE != NULL)
		{
			CAElement* pE = pJ->pElementList.m_pListElement.GetNext(posE);
			if(!pE->IsWorked())
			{
				SetSpecialElCurrent(pE,pJ);
			}
		}
	}
}
void CJointList::SetSwitchCurrent(CAElement* pSwitch,CAJoint* p)
{
	float i = 0;
	BOOL IsClose = pSwitch->IsClose();
	if(IsClose)
	{
		CAJoint* p1 = pSwitch->GetJointStruct()->pJoint1;
		CAJoint* p2 = pSwitch->GetJointStruct()->pJoint2;
		CAJoint* pOther;
		if(p1 == p) pOther = p2;
		else		pOther = p1;
		POSITION posE = pOther->pElementList.m_pListElement.GetHeadPosition();
		while(posE != NULL)
		{
			CAElement* pE = pOther->pElementList.m_pListElement.GetNext(posE);
			if(!pE->IsWorked() && pE!=pSwitch)
			{
				SetSpecialElCurrent(pE,pOther);
			}
			if( pE != pSwitch )
			{
				if((pE->IsTheP1Joint( pOther ) && !pSwitch->IsTheP1Joint( pOther ))
				|| (!pE->IsTheP1Joint( pOther ) && pSwitch->IsTheP1Joint( pOther )))
				{
					i += pE->GetCurrent();
				}
				else if(( pE->IsTheP1Joint( pOther ) && pSwitch->IsTheP1Joint( pOther ))
					 || ( !pE->IsTheP1Joint( pOther ) && !pSwitch->IsTheP1Joint( pOther )))
				{
					i += -pE->GetCurrent();
				}
			}
		}
	}
	else
	{
		i = 0;
	}
	pSwitch->SetWorked(true);
	pSwitch->SetCurrent(i);
}
void CJointList::SetInductorCurrent(CAElement* pInductor,CAJoint* p)
{
	float i = 0;
	CAJoint* p1 = pInductor->GetJointStruct()->pJoint1;
	CAJoint* p2 = pInductor->GetJointStruct()->pJoint2;
	CAJoint* pOther;
	if(p1 == p) pOther = p2;
	else		pOther = p1;
	POSITION posE = pOther->pElementList.m_pListElement.GetHeadPosition();
	while(posE != NULL)
	{
		CAElement* pE = pOther->pElementList.m_pListElement.GetNext(posE);
		if(!pE->IsWorked() && pE!=pInductor)
		{
			SetSpecialElCurrent(pE,pOther);
		}
		if( pE != pInductor )
		{
			if((pE->IsTheP1Joint( pOther ) && !pInductor->IsTheP1Joint( pOther ))
			|| (!pE->IsTheP1Joint( pOther ) && pInductor->IsTheP1Joint( pOther )))
			{
				i += pE->GetCurrent();
			}
			else if(( pE->IsTheP1Joint( pOther ) && pInductor->IsTheP1Joint( pOther ))
				 || ( !pE->IsTheP1Joint( pOther ) && !pInductor->IsTheP1Joint( pOther )))
			{
				i += -pE->GetCurrent();
			}
		}
	}
	pInductor->SetWorked(true);
	pInductor->SetCurrent(i);
}
void CJointList::SetCapacityCurrent(CAElement* pCapacity,CAJoint *p)
{
	pCapacity->SetCurrent(0);
}
void CJointList::SetResistanceCurrent(CAElement* pResistance,CAJoint* p)
{
	CAJoint* p1 = pResistance->GetJointStruct()->pJoint1;
	CAJoint* p2 = pResistance->GetJointStruct()->pJoint2;
	float    v1 = p1->GetVoltage();
	float    v2 = p2->GetVoltage();
/*	if(v1 > v2)
	{
		pResistance->SetCurrent((v1-v2)/pResistance->GetValue());
	}
	else
	{
		pResistance->SetCurrent((v2-v1)/pResistance->GetValue());
	}*/
	pResistance->SetCurrent((v2-v1)/pResistance->GetValue());
	pResistance->SetWorked(true);
}
void CJointList::SetPowerCurrent(CAElement* pPower,CAJoint* p)
{
	float i = 0;
	/*CAJoint* p1InSave = pPower->GetJointStruct()->pJoint1;
	CAJoint* p2InSave = pPower->GetJointStruct()->pJoint2;
	CAElement* pRealP = GetElement( pPower,m_pSaveRealList );
	CAJoint* p1InReal = pRealP->GetJointStruct()->pJoint1;
	CAJoint* p2InReal = pRealP->GetJointStruct()->pJoint2;
	CAElement* pR;
	if(pPOwer == p1InReal->pElementList.m_pListElement.GetHead())
	{
		pR = p1InReal->pElementList.m_pListElement.GetTail();
	}	
	else
	{
		pR = p1InReal->pElementList.m_pListElement.GetHead();
	}*/
	CAJoint* p1 = pPower->GetJointStruct()->pJoint1;
	CAJoint* p2 = pPower->GetJointStruct()->pJoint2;
	CAJoint* pOther;
//	int nCount1 = p1->pElementList.m_pListElement.GetCount();
//	int nCount2 = p2->pElementList.m_pListElement.GetCount();
//	if( nCount1 == 2 )
//	{
//		pOther = p1;
//	}
//	else
//	{
//		pOther = p2;
//	}
	if(p1 == p) pOther = p2;
	else		pOther = p1;
	int nParelCount = SetParrelPowerCurrent( pPower,pOther);
	POSITION posE = pOther->pElementList.m_pListElement.GetHeadPosition();
	int nCount = pOther->pElementList.m_pListElement.GetCount();
	while(posE != NULL)
	{
		CAElement* pE = pOther->pElementList.m_pListElement.GetNext(posE);
	//	if(nCount == 2 )
	//	{
	//		if(!pE->IsWorked() && pE!=pPower )
	//		{
	//			SetSpecialElCurrent(pE,pOther);
	//		}
	//	}
	//	else
	//	{
		//	if(!pE->IsWorked() && pE->GetType()!= ID_POWER )
			if( !pE->IsWorked() && pE != pPower && !pE->IsSetParel() )
			{
				SetSpecialElCurrent(pE,pOther);
			}
			if( !pE->IsSetParel() && pE != pPower ) 
				
			{
				if((pE->IsTheP1Joint( pOther ) && !pPower->IsTheP1Joint( pOther ))
				|| (!pE->IsTheP1Joint( pOther ) && pPower->IsTheP1Joint( pOther )))
				{
					i += pE->GetCurrent();
				}
				else if(( pE->IsTheP1Joint( pOther ) && pPower->IsTheP1Joint( pOther ))
					 || ( !pE->IsTheP1Joint( pOther ) && !pPower->IsTheP1Joint( pOther )))
				{
					i += -pE->GetCurrent();
				}
			}
//				i += pE->GetCurrent();
			pE->SetIsParel( false );
	//	}
	}
	pPower->SetWorked(true);
	pPower->SetCurrent(i/nParelCount);
	pPower->SetIsParel( false );
	
}
void CJointList::SetDiodeCurrent(CAElement* pDiode,CAJoint* p)
{
	float i = 0;
	CAJoint* p1 = pDiode->GetJointStruct()->pJoint1;
	CAJoint* p2 = pDiode->GetJointStruct()->pJoint2;
	if(p1->GetVoltage() != p2->GetVoltage())
	{
		pDiode->SetCurrent(0);
	}
	else
	{
		CAJoint* pOther;
		if(p1 == p) pOther = p2;
		else		pOther = p1;
		POSITION posE = pOther->pElementList.m_pListElement.GetHeadPosition();
		while(posE != NULL)
		{
			CAElement* pE = pOther->pElementList.m_pListElement.GetNext(posE);
			if(!pE->IsWorked() && pE!=pDiode)
			{
				SetSpecialElCurrent(pE,pOther);
			}
			if( pE!=pDiode )
			{
				if((pE->IsTheP1Joint( pOther ) && !pDiode->IsTheP1Joint( pOther ))
					|| (!pE->IsTheP1Joint( pOther ) && pDiode->IsTheP1Joint( pOther )))
				{
					i += pE->GetCurrent();
				}
				else if(( pE->IsTheP1Joint( pOther ) && pDiode->IsTheP1Joint( pOther ))
						 || ( !pE->IsTheP1Joint( pOther ) && !pDiode->IsTheP1Joint( pOther )))
				{
					i += -pE->GetCurrent();
				}
			}
//			i += pE->GetCurrent();
		}
	}
	pDiode->SetWorked(true);
	pDiode->SetCurrent(i);
}

void CJointList::SetSpecialElCurrent(CAElement *pE,CAJoint* p)
{
	int type = pE->GetType();
	switch(type)
	{
	case ID_POWER:
		SetPowerCurrent(pE,p);
		break;
	case ID_RESISTANCE:
		SetResistanceCurrent(pE,p);
		break;
	case ID_CAPACITANCE:
		SetCapacityCurrent(pE,p);
		break;
	case ID_INDUCTANCE:
		SetInductorCurrent(pE,p);
		break;
	case ID_SWITCH:
		SetSwitchCurrent(pE,p);
		break;
	case ID_DIODE:
		SetDiodeCurrent(pE,p);
		break;
	case ID_CURRENT_METER:
		SetAmpermeterCurrent(pE,p);
		break;
	case ID_VOLTAGE_METER:
		SetVoltmeterCurrent(pE,p);
		break;
	default:
		break;
	}
}

/*CAElement* CJointList::GetSameElInOtherList(CAElement *pE, JointList *pList)
{
	CAJoint* p1 = pE->GetJointStruct()->pJoint1;
	CAJoint* p2 = pE->GetJointStruct()->pJoint2;
	int order1 = p1->GetOrder();
	int order2 = p2->GetOrder();
	int type1   = pE->GetType();
	POSITION pos = pList->GetHeadPosition();
	while(pos != NULL)
	{
		CAJoint* pJ   = pList->GetNext(pos);
		POSITION posE = pJ->pElementList.m_pListElement.GetHeadPosition();
		while(posE != NULL)
		{
			CAElement* pEOther = pJ->pElementList.m_pListElement.GetNext(posE);
			int type2		   = pEOther->GetType();
			CAJoint* p11       = pEOther->GetJointStruct()->pJoint1;
			CAJoint* p22       = pEOther->GetJointStruct()->pJoint2;
			int order11		   = p11->GetOrder();
			int order22		   = p22->GetOrder();
			if(type1 == type2)
			{
				if    (order11 == order1 && order22 == order2)
				{
					return pEOther;
				}
				else if(order11 == order2 && order22 == order1)
				{
					return pEOther;
				}
			}
		}
	}
	return NULL;
}*/

void CJointList::GiveMeBase(int base)
{
	m_nBase = base;
}

int CJointList::GetBaseOrder()
{
	return m_nBase;
}

void CJointList::SetVoltOutput(ElementList *pElList, JointList *pList)
{
	POSITION pos = pElList->GetHeadPosition();
	while( pos != NULL )
	{
		CAElement* pE		= pElList->GetNext( pos );
//		int	order1			= pE->GetOrderStruct()->order1;
//		int order2			= pE->GetOrderStruct()->order2;
		CAElement* pEInSave = GetElement(pE,pList);
		pE->SetVoltage( pEInSave->GetVoltage() );
	}
}

void CJointList::SetAmperOutput(ElementList *pElList, JointList *pList)
{
	POSITION pos = pElList->GetHeadPosition();
	while( pos != NULL )
	{
		CAElement* pE		= pElList->GetNext( pos );
//		int order1			= pE->GetOrderStruct()->order1;
//		int order2			= pE->GetOrderStruct()->order2;
		CAElement* pEInSave = GetElement(pE,pList);
		pE->SetCurrent( pEInSave->GetCurrent() );
	}
}

/*CAElement* CJointList::GetSameElInOtherList(int type,int order1, int order2, JointList *pList)
{
	POSITION posJ = pList->GetHeadPosition();
	while( posJ != NULL )
	{
		CAJoint* pJ = pList->GetNext( posJ );
		POSITION posE = pJ->pElementList.m_pListElement.GetHeadPosition();
		while( posE != NULL )
		{
			CAElement* pE = pJ->pElementList.m_pListElement.GetNext( posE );
			if( pE->GetType() == type )
			{
				CAJoint* p1 = pE->GetJointStruct()->pJoint1;
				CAJoint* p2 = pE->GetJointStruct()->pJoint2;
				int      o1 = p1->GetOrder();
				int      o2 = p2->GetOrder();
				if( order1 == o1 && order2 == o2 )
				{
					return pE;
				}
				else if( order1 == o2 && order2 == o1 )
				{
					return pE;
				}
			}
		}
	}
	return NULL;
}
*/
int CJointList::GetElementCount(JointList* pList)
{
	int nCount = 0;
	SetWorkedInList( false,pList );
	POSITION posJ = pList->GetHeadPosition();
	while( posJ != NULL )
	{
		CAJoint* pJ = pList->GetNext( posJ );
		POSITION posE = pJ->pElementList.m_pListElement.GetHeadPosition();
		while( posE != NULL )
		{
			CAElement* pE = pJ->pElementList.m_pListElement.GetNext( posE );
			if( !pE->IsWorked() )
			{
				nCount ++;
				pE->SetWorked( true );
			}
		}
	}
	return nCount;
}

void CJointList::SetAllIsSetVoltage(BOOL b, JointList *pList)
{
	POSITION pos = pList->GetHeadPosition();
	while( pos != NULL )
	{
		CAJoint* pJoint = pList->GetNext( pos );
		pJoint->SetIsSetVoltage( b );
	}
}


BOOL CJointList::GoTheWay(CAJoint *pJoint)
{
	return false;
	//1.All Is Resistance;
	//2.Only one and it IsSetVoltage;
	//3.
}

int CJointList::SetParrelPowerCurrent(CAElement *pPower,CAJoint* pJ)
{
	int nCount = 1;
	pPower->SetIsParel( false );
//	CAJoint* p1 = pPower->GetJointStruct()->pJoint1;
//	CAJoint* p2 = pPower->GetJointStruct()->pJoint2;
	POSITION pos = pJ->pElementList.m_pListElement.GetHeadPosition();
	while( pos != NULL )
	{
		CAElement* pE = pJ->pElementList.m_pListElement.GetNext( pos );
		pE->SetIsParel( false );
		if( pE->GetType() == ID_POWER && pE != pPower )
		{
			if( IsSameJoint( pPower,pE ) )
			{
				nCount ++;
			//	pE->SetIsParel( true );
				pE->SetIsParel( true );
				pPower->SetIsParel( true );
			}
		}
	}
	return nCount;
}

BOOL CJointList::IsSameJoint(CAElement *pE1, CAElement *pE2)
{
	BOOL b1,b2;
	if(pE1->GetJointStruct()->pJoint1==pE2->GetJointStruct()->pJoint1)
	{
		b1=true;
	}
	else
	{
		b1=false;
	}
	if(pE1->GetJointStruct()->pJoint2==pE2->GetJointStruct()->pJoint2)
	{
		b2=true;
	}
	else
	{
		b2=false;
	}
	if(b1&&b2)
	{
		return true;
	}
	else
	{
		return false;
	}
}
