// PointList.cpp: implementation of the CPointList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "PointList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPointList::CPointList()
{

}

CPointList::~CPointList()
{

}
void CPointList::Draw(CDC* pDC)
{
	CBase* aa;

	POSITION pos = GetHeadPosition();
	while(pos != NULL){
		aa = (CBase *)GetNext(pos);
		aa->Draw(pDC);
	}
}
CBase* CPointList::PtInGraph(CPoint point)
{
	CBase* aa;
	POSITION pos= GetHeadPosition();
    while(pos!=NULL)
	{
		aa = (CBase *)GetNext(pos);
		DeSelect();
		if(aa->PtInOb(point)){
			aa->Select();
			return aa;
		}
   	}
	return NULL;
}
void CPointList::Serialize(CArchive& ar)
{
	if (ar.IsStoring()){

	}else{

	}
}
void CPointList::SetPosition()
{
	CBase* aa;
	int nowpos = 1;
	POSITION pos= GetHeadPosition();
    while(pos!=NULL)
	{
		aa = (CBase *)GetNext(pos);
		if(aa){
			aa->number = nowpos;
			nowpos++;
		}
   	}
}
CBase* CPointList::GetObject(int number)
{
	CBase* aa;
	POSITION pos= GetHeadPosition();
    while(pos!=NULL)
	{
		aa = (CBase *)GetNext(pos);
		if(aa->number == number){
			return aa;
		}
   	}
	return NULL;
}