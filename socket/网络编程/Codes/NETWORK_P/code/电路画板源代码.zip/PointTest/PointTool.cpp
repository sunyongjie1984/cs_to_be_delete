// PointTool.cpp: implementation of the CPointTool class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "PointTool.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPointTool::CPointTool(CWnd* cWnd,CElist* pList,CPointList* pOintList,CLineList* pLineList)
		:CBaseTool(cWnd,pList,pOintList,pLineList)
{
	m_sigle = NULL;
}

CPointTool::~CPointTool()
{

}
void CPointTool::OnLButtonDown(UINT nFlags, CPoint point)
{
	CanDraw = TRUE;

}
void CPointTool::OnLButtonUp(UINT nFlags, CPoint point)
{
	if(!CanDraw) return;
	CanDraw = FALSE;

}
void CPointTool::OnMouseMove(UINT nFlags, CPoint point)
{

}