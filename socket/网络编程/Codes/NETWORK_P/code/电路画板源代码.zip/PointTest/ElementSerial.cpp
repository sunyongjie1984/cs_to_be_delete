// ElementSerial.cpp: implementation of the CElementSerial class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "ElementSerial.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CElementSerial::CElementSerial()
{

}

CElementSerial::~CElementSerial()
{

}
BOOL CElementSerial::IfCellClosed()
{
	CBase* aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CBase*)GetNext(Pos);
		if(aa->Node1 == aa->Node2)
			return TRUE;
	}
	return FALSE;
}
BOOL CElementSerial::IfAllPortHaveLine()
{
	CBase* aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CBase*)GetNext(Pos);
		if(aa->Node1 == ID_NONODE)
			return FALSE;
		if(aa->Node2 == ID_NONODE)
			return FALSE;
	}
	return TRUE;
}
/*BOOL CElementSerial::IfAmperemeterParallel()//�ж��Ƿ��е���������
{
	CBase* aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		if(aa->GetType() == ID_CURRENT_METER){

		}
	}
		aa = (CBase*)GetNext(Pos);
		if(aa->Node1 == ID_NONODE)
			return FALSE;
		if(aa->Node2 == ID_NONODE)
			return FALSE;
	}
	return TRUE;
}
BOOL CElementSerial::IfVoltmeterSeries()//�ж��Ƿ��е�ѹ������
{

}*/