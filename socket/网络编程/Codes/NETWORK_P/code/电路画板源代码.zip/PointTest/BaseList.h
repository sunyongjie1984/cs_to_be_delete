// BaseList.h: interface for the CBaseList class.
//
//////////////////////////////////////////////////////////////////////
#include "base.h"
#if !defined(AFX_BASELIST_H__02B0FFA1_6481_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_BASELIST_H__02B0FFA1_6481_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CBaseList : public CPtrList  
{
public:
	CBaseList();
	virtual ~CBaseList();
public:
	virtual void		DeSelect();

	virtual BOOL	  	PtInGraph(CPoint point,BOOL Control);
	virtual CBase*		PtDbInGraph(CPoint point);

	virtual void        RemoveAll();
	virtual void		SelectAll();
	virtual void		Draw(CDC* pDC){}

	virtual CBase * GetAt( POSITION pos );
	virtual BOOL		ObInRegion(CRect rect);//check the object in the given region
	virtual void		RemoveSelected();
	virtual void		MoveSelected(CSize size);

	virtual BOOL		IsAnySelect(CPoint point);

	virtual void DeleteSelected();
	virtual void Notify(CBase* Remove);
	virtual void RotateSelected(int Rotate);
	virtual void Serialize(CArchive& ar){}
public:
	BOOL CtrlKey;
};

#endif // !defined(AFX_BASELIST_H__02B0FFA1_6481_11D4_BBD7_600000000ECD__INCLUDED_)
