//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Pointtest.rc
//
#define IDD_ABOUTBOX                    100
#define ID_BUTTON1                      101
#define ID_BUTTON2                      102
#define ID_BUTTON3                      103
#define ID_BUTTON4                      104
#define ID_BUTTON5                      105
#define ID_BUTTON6                      106
#define ID_BUTTON7                      107
#define ID_BUTTON8                      108
#define ID_BUTTON9                      109
#define ID_BUTTON10                     110
#define ID_BUTTON11                     111
#define ID_BUTTON12                     112
#define IDE_TEXTBOX                     113
#define IDR_MAINFRAME                   128
#define IDR_POINTTTYPE                  129
#define IDD_DIALOG1                     130
#define IDB_BIGFLAG2                    131
#define IDB_BIGFLAG1                    132
#define IDD_PROPERY                     133
#define IDI_ABC                         134
#define IDB_BUTTON1                     135
#define IDB_BUTTON2                     136
#define IDB_BUTTON3                     137
#define IDB_SPLASH                      138
#define IDC_PROPERTE                    1000
#define IDC_VALUE                       1001
#define IDC_UNIT                        1002
#define IDC_REMARK                      1003
#define IDC_MAX                         1004
#define IDC_STATIC1                     1005
#define ID_SELECTONE                    32771
#define ID_DIANZU                       32772
#define ID_DIAN                         32773
#define ID_CAP                          32774
#define ID_DIANYUAN                     32775
#define ID_DIANYABIAO                   32776
#define ID_DIANLIUBIAO                  32777
#define ID_ERJIGUAN                     32778
#define ID_DDDZ                         32779
#define ID_DDSZ                         32780
#define ID_SDSZ                         32781
#define ID_DI                           32782
#define ID_DIANGAN                      32783
#define ID_HGRIP                        32784
#define ID_VGRIP                        32785
#define ID_DEASIL                       32787
#define ID_DEAZIL                       32788
#define ID_ANTICLOCKWISE                32789
#define ID_GO                           32790
#define ID_DENG                         32791
#define ID_BUTTON32792                  32792
#define ID_KETIAODIANZU                 32794
#define ID_TEXTA                        32798
#define ID_LOOKMETER                    32799
#define ID_CALCULATE                    32801

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32802
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           114
#endif
#endif
