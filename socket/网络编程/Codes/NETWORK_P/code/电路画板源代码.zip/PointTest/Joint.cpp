// Joint.cpp: implementation of the CAJoint class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "Joint.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAJoint::CAJoint(int order)
{
	m_nOrder=order;
	m_nEqualValueOrder=m_nOrder;
	m_bIsSetVoltage = false;
	for(int i=0;i<10;i++)
	{
		m_dReciprocalOfR[i]=0;
	}
	for(int j=0;j<100;j++)
	{
		m_fVoltage[j]=0;
		m_fRealVoltage[j]=0;
	}
}

CAJoint::~CAJoint()
{
}
int CAJoint::GetOrder()
{
	return m_nOrder;
}
void CAJoint::SearchElecSource()
{
	if(pElementList.m_pListElement.IsEmpty())
	{
		m_bHoldElecSource=false;
	}
	else
	{
		POSITION pos,headPos,sourcePos;
		CAElement *pElement,*pSource;
		headPos=pos=pElementList.m_pListElement.GetHeadPosition();
		int k=pElementList.m_pListElement.GetCount();
		while(pos!=NULL)
		{
			pElement=pElementList.m_pListElement.GetAt(pos);
			float a=pElement->GetValue();
			if(pElement->GetType()==ID_POWER)
			{
				pSource=pElement;
				sourcePos=pos;
				break;
			}
			pElementList.m_pListElement.GetNext(pos);
		}
		if(pos!=NULL)
		{
			pElementList.m_pListElement.RemoveAt(sourcePos);
			pElementList.m_pListElement.AddHead(pSource);
			float b=pElementList.m_pListElement.GetHead()->GetValue();
			float c=pElementList.m_pListElement.GetTail()->GetValue();
			m_bHoldElecSource=true;
		}
		else
		{
			m_bHoldElecSource=false;
		}
	}
}
BOOL CAJoint::IsHoldElecSource()
{
	SearchElecSource();
	return m_bHoldElecSource;
}
float CAJoint::GetVoltage()
{
	return m_dVoltage;
}
void CAJoint::SetVoltage(float v)
{
	m_dVoltage=v;
}

float CAJoint::GetXXX()
{
	return 12.0;
}
void CAJoint::SetIsSetVoltage(BOOL b)
{
	m_bIsSetVoltage = b;
}
BOOL CAJoint::IsSetVoltage()
{
	return m_bIsSetVoltage;
}