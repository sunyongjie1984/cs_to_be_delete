// Elist.cpp: implementation of the CElist class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "Elist.h"
#include "Epoint.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CElist::CElist()
{
}

CElist::~CElist()
{

}
void CElist::Draw(CDC* pDC)
{
	CBase* aa;

	POSITION pos = GetHeadPosition();
	while(pos != NULL){
		aa = (CBase *)GetNext(pos);
		aa->Draw(pDC);
	}
}
void CElist::TurnSwitch()
{
	UINT type;
	CBase* aa;
	POSITION pos = GetHeadPosition();
	while(pos != NULL){
		aa = (CBase *)GetNext(pos);
		if(aa->IsSelected()){
			type = aa->GetType();
			if((type == ID_SWITCH)||(type == ID_LIGHT))
				aa->m_bSwitch = !aa->m_bSwitch;
		}
	}
}
void CElist::HGripSelected()
{
	CBase* aa;
	CPoint movepoint,re;
	BOOL moveflag = FALSE;
	POSITION pos = GetHeadPosition();
	while(pos != NULL){
		aa = (CBase *)GetNext(pos);
		if(aa->IsSelected()){
			if(!moveflag){
				movepoint = aa->CenterPoint;
				moveflag = TRUE;
			}else{
				re = aa->CenterPoint;
				re.y = movepoint.y;
				aa->SetPoinT(re);
			}
		}
	}
}
void CElist::VGripSelected()
{
	CBase* aa;
	CPoint movepoint,re;
	BOOL moveflag = FALSE;
	POSITION pos = GetHeadPosition();
	while(pos != NULL){
		aa = (CBase *)GetNext(pos);
		if(aa->IsSelected()){
			if(!moveflag){
				movepoint = aa->CenterPoint;
				moveflag = TRUE;
			}else{
				re = aa->CenterPoint;
				re.x = movepoint.x;
				aa->SetPoinT(re);
			}
		}
	}
}
void CElist::Serialize(CArchive& ar)
{
	CBase* pp;
	if (ar.IsStoring()){
		POSITION pos = GetHeadPosition();
		ar << GetCount();
		while(pos!=NULL)
		{
			pp = (CBase*)GetNext(pos);
			if(pp){
				ar << pp->m_ElementType;
				ar << pp->m_iSelected;
				ar << pp->TotalAngle;
				ar << pp->CenterPoint;
				ar << pp->Value;
			}
		}
	}else{
	}
}
void CElist::ClearAllNode()
{
	CBase* aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CBase*)GetNext(Pos);
		aa->Node1 = ID_NONODE;
		aa->Node2 = ID_NONODE;
	}
}
BOOL CElist::PtInArrow(CPoint pp)
{
	CBase* aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CBase*)GetNext(Pos);
		if(aa->GetType()==ID_RHEOSTAT){
			if(aa->Pt_In_Arrow(pp)){
				DeSelect();
				aa->Select();
				return TRUE;
			}
		}
	}
	return FALSE;
}
void CElist::MovePoint(CPoint pp,CSize size)
{
	CBase* aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CBase*)GetNext(Pos);
		if(aa->GetType()==ID_RHEOSTAT){
			if(aa->IsSelected()){
				aa->MovePoint(pp,size);
				return;
			}
		}
	}
}
void CElist::DisplayWatch(CView* pView)
{
	CBase* aa;
	UINT id;
	aa = FindSelected();
	if(aa){
		id = aa->GetType();
		switch(id){
		case ID_VOLTAGE_METER:
			watch = new MyWatch(pView);
			if ( watch->GetSafeHwnd() == 0 )
			{
				watch->Create( );
    			watch->SetParam( aa->Content_Of_Ob,1,"V",aa->MeterValue,"����",aa->MaxValue);
			}
			break;
		case ID_CURRENT_METER:
			watch = new MyWatch(pView);
			if ( watch->GetSafeHwnd() == 0 )
			{
				watch->Create( );
    			watch->SetParam( aa->Content_Of_Ob,1,"A",aa->MeterValue,"����",aa->MaxValue);
			}
			break;
		}
	}
}
CBase* CElist::FindSelected()
{
	CBase* aa = NULL;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CBase*)GetNext(Pos);
		if(aa->IsSelected()){
			switch(aa->GetType()){
			case ID_VOLTAGE_METER:
			case ID_CURRENT_METER:
				return aa;
				break;
			}
			
		}
	}
	return NULL;
}