// Elist.h: interface for the CElist class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_ELIST_H__37927A18_613E_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_ELIST_H__37927A18_613E_11D4_BBD7_600000000ECD__INCLUDED_
#include "base.h"
#include "baselist.h"
#include "mywatch.h"
//#include "epoint.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//class CBase;
class CElist : public CBaseList
{
public:
	CElist();
	virtual ~CElist();
public:
	void		Draw(CDC* pDC);
	void		HGripSelected();
	void		VGripSelected();
	void Serialize(CArchive& ar);
	void ClearAllNode();
	BOOL PtInArrow(CPoint pp);//���ڼ�ͷ��
	void MovePoint(CPoint pp,CSize size);
//	BOOL IfAllPortHaveLine();//�Ƿ����ж˵㶼���ߣ��ӵس��⣩
	void		TurnSwitch();
	void DisplayWatch(CView* pView);//��ʾ��ͷ
	CBase* FindSelected();
public:
	MyWatch* watch;
	//CList<MyWatch*,MyWatch*> CWatchList;//��ͷ����
};

#endif // !defined(AFX_ELIST_H__37927A18_613E_11D4_BBD7_600000000ECD__INCLUDED_)
