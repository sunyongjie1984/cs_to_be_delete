// PointList.h: interface for the CPointList class.
//
//////////////////////////////////////////////////////////////////////
//#include "epoint.h"
#include "baselist.h"
#if !defined(AFX_POINTLIST_H__08F322A1_6312_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_POINTLIST_H__08F322A1_6312_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPointList : public CBaseList  
{
public:
	CPointList();
	virtual ~CPointList();
public:
	void		Draw(CDC* pDC);
	CBase*  	PtInGraph(CPoint point);
	void		Serialize(CArchive& ar);
	void		SetPosition();
	CBase*		GetObject(int number);
};

#endif // !defined(AFX_POINTLIST_H__08F322A1_6312_11D4_BBD7_600000000ECD__INCLUDED_)
