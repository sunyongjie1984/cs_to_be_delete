// Base.h: interface for the CBase class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_BASE_H__37927A15_613E_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_BASE_H__37927A15_613E_11D4_BBD7_600000000ECD__INCLUDED_
#include <afxtempl.h>
#if _MSC_VER > 1000
#pragma once
//#include "baselist.h"
#endif // _MSC_VER > 1000
//#define WM_PLEASECOPY		(WM_USER+101)
//��������������С��
#define MAX2(x,y)	(((x)>(y))?(x):(y))
#define MIN2(x,y)	(((x)<(y))?(x):(y))

//��������������С��
#define MAX3(x,y,z)	( ((x)>(y)&&(x)>(z))?(x):((y)>(z)?(y):(z)) )
#define MIN3(x,y,z)	( ((x)<(y)&&(x)<(z))?(x):((y)<(z)?(y):(z)) )

/*#define ID_SELECT				61446
#define ID_LINE					61447
#define ID_POINT				61448
#define ID_DOT					61449

#define ID_RESISTANCE           61450//����
#define ID_POWER				61451//��Դ
#define ID_CAPACITANCE			61452//����
#define ID_DIODE				61453//������
#define ID_SWITCH				61454//����

#define ID_VOLTAGE_METER		61455//��ѹ��
#define ID_CURRENT_METER		61456//������
#define ID_INDUCTANCE			61457//inductance���
#define ID_GROUND				61458//��
#define ID_LIGHT				61459//����*/
#define BLACK RGB(0,0,0)
#define WHITE RGB(255,255,255)
#define GRAY RGB(191,191,191)
#define RED RGB(255,0,0)
#define GREEN RGB(0,255,0)
#define BLUE RGB(0,0,255)
#define LIGHT RGB(0,255,255)
#define PI 3.14159265
#define NODEFINE WM_USER+1000
class MyWatch;
class CEpoint;
class CBaseList;
class CBase  
{
public:
	CBase(int nType,CBaseList* pBaseList);
	CBase(int nType);
	virtual ~CBase();
public:
	virtual BOOL PtInOb(CPoint point);//test if point in object
	virtual void Draw(CDC* pDC){}//virtual draw function
	virtual int	 IsSelected();//tell if the object has beeing selected
	virtual void Select();//select object;
	virtual void DeSelect();//delete select state
	virtual BOOL GraphInRect( CRect lpRect );//test if the graphic is in the given rect

	virtual CRect GetGraphRect();//get total graphic rect
	virtual CString GetGraphString();//get the string of graphic

	virtual void SetData(CString &aa,CRect &bb);
	virtual void GetData(CString aa,CRect bb);

	virtual int GetType();//get the object type
	virtual void SetPoint(CPoint pp){}//virtual function to set the point value
	virtual void OffSet(CSize size){}//offset object
	virtual void AddSon(CBase* Element);//add a son in sonlist
	virtual void Notify(){}//notify the parent to delete the list

	virtual void Delete();//delete object

	virtual CPoint Rotate(double a,CPoint rotate);//rotate a ob depend on the owner center
	virtual void RotateCell(double angle){}//rotate all the point in ob
	virtual double ConvertAngle(int a);//convert a angle by give the int angle
	virtual int round(double aa);//��������
	virtual CRect GetRect(CPoint pp,CSize bb);//construct a rect by given point an size
	virtual void DrawSign(CDC* pDC,CPoint cen,int Length);
	virtual BOOL IfHaveSon();
	virtual void TextOut(CDC* pDC);
	virtual CPoint GetTextRect(CDC* pDC);
	virtual void ReduceCount(UINT id);
	virtual void AddString(UINT id);
	//������
	virtual CPoint Conv_coord(CPoint p,BOOL Real_or_Visual){return CPoint(0,0);}//ת������
	virtual CPoint Found_Right(CPoint pp){return CPoint(0,0);}//
	virtual CPoint Found_Left(CPoint pp){return CPoint(0,0);}
	virtual BOOL Pt_In_Arrow(CPoint pp){return FALSE;}//�жϵ��Ƿ��ڼ�ͷ��
	virtual void MovePoint(CPoint pp,CSize size){}//�ƶ���ͷ
	virtual void OffSetSlid(CSize size){}
	virtual void OffSetX(int x){}
	virtual void OffSetY(int y){}
	virtual BOOL CheckInRegn(CPoint pp,BOOL x_or_y){return FALSE;}
	virtual void SetEValue(){}
	virtual void SetPoinT(CPoint pp);
public:
	int m_ElementType;//the type you know
	
	BOOL m_iSelected;//the select flag
	//POSITION CellPos;
	CBaseList* WhereIAm;//the pointer to the list that owner have been
	CPoint CenterPoint;//center point
	CPoint OwnerCenter;//to the CEpoint class define the owner Center of the point
	CPoint TextPoint;
	CBase* Parent;
	CList<CBase*,CBase*> SonList;//the list of son
	CPoint left,right;//the position of cell
	double TotalAngle;//the rotated angle recorded
	float Value;			//Ԫ������ֵ����
	float MaxValue;			//Ԫ�������֦
	float MeterValue;
	int number;				//Ԫ�����
	
	CString Content_Of_Ob;	//Ԫ���ı�ʶ������
	CRect Size_Of_Ob;//the rect of ob

	CBase* p1,*p2;			//�ܽ�1,2
	CBase* p3,*p4;			//�ܽ�3,4
	BOOL m_bSwitch;			//ĳЩ����Ԫ���Ŀ��ر���
	int Node1,Node2;		//�����ڵ�
	char SerialNumber[2];      //��ǰÿ��Ԫ��������
	MyWatch* WhichWatchIsBelongToMe;
};

#endif // !defined(AFX_BASE_H__37927A15_613E_11D4_BBD7_600000000ECD__INCLUDED_)
