// PointtestDoc.cpp : implementation of the CPointtestDoc class
//

#include "stdafx.h"
#include "Pointtest.h"

#include "PointtestDoc.h"
#include "PointtestView.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPointtestDoc

IMPLEMENT_DYNCREATE(CPointtestDoc, CDocument)

BEGIN_MESSAGE_MAP(CPointtestDoc, CDocument)
	//{{AFX_MSG_MAP(CPointtestDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
		ON_COMMAND(ID_FILE_SAVE, OnFileSave)
		ON_COMMAND(ID_FILE_NEW, OnNewFile)
		
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPointtestDoc construction/destruction

CPointtestDoc::CPointtestDoc()
{
	m_list.RemoveAll();
	m_pointlist.RemoveAll();
	m_linelist.RemoveAll();
	m_textlist.RemoveAll();
}

CPointtestDoc::~CPointtestDoc()
{
	m_list.RemoveAll();
	m_pointlist.RemoveAll();
	m_linelist.RemoveAll();
	m_textlist.RemoveAll();
}

BOOL CPointtestDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	m_list.RemoveAll();
	m_pointlist.RemoveAll();
	m_linelist.RemoveAll();
	m_textlist.RemoveAll();
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CPointtestDoc serialization

void CPointtestDoc::Serialize(CArchive& ar)
{
	POSITION pos=GetFirstViewPosition( );
	CPointtestView* pView=(CPointtestView*)GetNextView( pos );
	saveg = new SaveGraphic(pView,&m_list,&m_pointlist,&m_linelist,&m_textlist);
/*	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}*/
	saveg->Serialize(ar);
	delete saveg;
}

/////////////////////////////////////////////////////////////////////////////
// CPointtestDoc diagnostics

#ifdef _DEBUG
void CPointtestDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPointtestDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG
char szFilter[] = "DHB Files(*.DHB)|*.DHB||";
BOOL CPointtestDoc::OnFileOpen() 
{
	static int nIndex = 1;
	CFileDialog FileDlg( TRUE, NULL, NULL, OFN_HIDEREADONLY, szFilter );
	FileDlg.m_ofn.nFilterIndex = (DWORD) nIndex;
	if( FileDlg.DoModal() == IDOK ){
		CString PathName = FileDlg.GetPathName();
		PathName.MakeUpper();
		if( !OnOpenDocument(PathName)){
			CString str;
			str.Format("���ܴ�ϵͳ�����ļ�:%s!", PathName);
			AfxMessageBox(str);
			return FALSE;
		}
		nIndex = (int) FileDlg.m_ofn.nFilterIndex;
		return TRUE;
	}else
		return FALSE;
}
void CPointtestDoc::OnFileSave() 
{
	static int nIndex = 1;
	CFileDialog FileDlg( FALSE, NULL, NULL, OFN_HIDEREADONLY, szFilter );
	FileDlg.m_ofn.nFilterIndex = (DWORD) nIndex;
	if( FileDlg.DoModal() == IDOK ){
		CString PathName = FileDlg.GetPathName();
		PathName.MakeUpper();
		//DoSave(PathName);
		if(PathName.Right(4) != ".DHB")
			PathName += ".DHB";
		OnSaveDocument(PathName);
		nIndex = (int) FileDlg.m_ofn.nFilterIndex;
	}
}
void CPointtestDoc::OnNewFile()
{
	POSITION pos=GetFirstViewPosition();
	CPointtestView* pView=(CPointtestView*)GetNextView( pos );
	if(IDYES==MessageBox(AfxGetMainWnd()->m_hWnd,"�Ƿ�ȷ��Ҫ�½�һ������","��·������ʾ",MB_ICONWARNING|MB_YESNO)){
		m_list.RemoveAll();
		m_pointlist.RemoveAll();
		m_linelist.RemoveAll();
		m_textlist.RemoveAll();
		pView->Invalidate();
	}
}
/////////////////////////////////////////////////////////////////////////////
// CPointtestDoc commands

void CPointtestDoc::SetTitle(LPCTSTR lpszTitle) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	//CDocument::SetTitle("��·����");
}
