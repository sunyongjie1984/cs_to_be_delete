// Rheostat.cpp: implementation of the CRheostat class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "Rheostat.h"
#include "math.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRheostat::CRheostat(int nType,CBaseList* pBaseList) : CBase(ID_RHEOSTAT,pBaseList)
{
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "RH";
	AddString(ID_RHEOSTAT);
	MaxValue = 20;
	Value = 20;
}
CRheostat::CRheostat(CBase* pp1,CBase* pp2,CBaseList* pBaseList) : CBase(ID_RHEOSTAT,pBaseList)
{
	p1 = pp1;
	p2 = pp2;
	AddSon(p1);
	AddSon(p2);
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "RH";
	AddString(ID_RHEOSTAT);
	MaxValue = 20;
	Value = 20;
}
CRheostat::~CRheostat()
{

}
void CRheostat::Draw(CDC* pDC)
{
	if(IsSelected()){
		CPen pen(PS_SOLID, 2,RED);
		CPen *Oldpen = pDC->SelectObject(&pen);
		pDC->SetBkMode(TRANSPARENT);
		pDC->MoveTo(left);
		pDC->LineTo(p1->CenterPoint);
		pDC->MoveTo(right);
		pDC->LineTo(p2->CenterPoint);
		pDC->MoveTo(aa);
		pDC->LineTo(dd);
		pDC->LineTo(bb);
		pDC->LineTo(cc);
		pDC->LineTo(aa);
		//draw arrow
		pDC->MoveTo(slid4);
		pDC->LineTo(slid[0]);
		pDC->Polygon(slid,3);
		pDC->MoveTo(slid5);
		pDC->LineTo(slid4);
		pDC->MoveTo(slid5);
		pDC->LineTo(p1->CenterPoint);

		pDC->SelectObject(Oldpen);
	}else{
		CPen pen(PS_SOLID, 2,BLACK);
		CPen *Oldpen = pDC->SelectObject(&pen);
		pDC->SetBkMode(TRANSPARENT);
		pDC->MoveTo(left);
		pDC->LineTo(p1->CenterPoint);
		pDC->MoveTo(right);
		pDC->LineTo(p2->CenterPoint);
		pDC->MoveTo(aa);
		pDC->LineTo(dd);
		pDC->LineTo(bb);
		pDC->LineTo(cc);
		pDC->LineTo(aa);
		//arrow
		pDC->MoveTo(slid4);
		pDC->LineTo(slid[0]);
		pDC->Polygon(slid,3);
		pDC->MoveTo(slid5);
		pDC->LineTo(slid4);
		pDC->MoveTo(slid5);
		pDC->LineTo(p1->CenterPoint);

		pDC->SelectObject(Oldpen);
	}
	TextOut(pDC);
}
void CRheostat::SetPoint(CPoint pp)
{
	TextPoint = left = right = CenterPoint = pp;
	left = pp - CPoint(20,0);
	right = pp + CPoint(20,0);
	slid4 = slid[0] = left;
	p1->CenterPoint = pp - CPoint(30,0);
	p2->CenterPoint = pp + CPoint(29,0);
	cc = aa = left;
	dd = bb = right;
	aa.Offset(CSize(0,10));
	cc.Offset(CSize(0,-10));
	bb.Offset(CSize(0,-10));
	dd.Offset(CSize(0,10));
	slid4.Offset(CSize(0,25));
	slid[0].Offset(CSize(0,10));
	slid[1] = Conv_coord(Found_Left(slid[0]),FALSE);
	slid[2] = Conv_coord(Found_Right(slid[0]),FALSE);
	slid5.x = p1->CenterPoint.x;
	slid5.y = slid4.y;
	RotateCell(TotalAngle);
}
void CRheostat::OffSet(CSize size)
{
	CenterPoint.Offset(size);
	left.Offset(size);
	right.Offset(size);
	p1->OffSet(size);
	p2->OffSet(size);
	aa.Offset(size);
	bb.Offset(size);
	cc.Offset(size);
	dd.Offset(size);
	OffSetSlid(size);
}
CRect CRheostat::GetGraphRect()
{
	CPoint up_left,down_right;
	up_left = down_right = CenterPoint;
	up_left.Offset(-20,-10);
	down_right.Offset(20,10);
	return CRect(up_left,down_right);	
}
void CRheostat::RotateCell(double angle)
{
	left = Rotate(angle,left);
	right = Rotate(angle,right);
	p1->CenterPoint = Rotate(angle,p1->CenterPoint);
	p2->CenterPoint = Rotate(angle,p2->CenterPoint);
	aa = Rotate(angle,aa);
	bb = Rotate(angle,bb);
	cc = Rotate(angle,cc);
	dd = Rotate(angle,dd);
	slid[0] = Rotate(angle,slid[0]);
	slid[1] = Rotate(angle,slid[1]);
	slid[2] = Rotate(angle,slid[2]);
	slid4 = Rotate(angle,slid4);
	slid5 = Rotate(angle,slid5);
}
//����������ߵ�
CPoint CRheostat::Found_Left(CPoint pp)
{
	double a;
	pp = Conv_coord(pp,TRUE);
	a = atan2(pp.y,pp.x);
	pp.x-=int(10*cos(a-PI/9));
	pp.y-=int(10*sin(a-PI/9));
	return pp;
}
//���������ұߵ�
CPoint CRheostat::Found_Right(CPoint pp)
{
	double a;
	pp = Conv_coord(pp,TRUE);
	a = atan2(pp.y,pp.x);
	pp.x-=int(10*cos(a+PI/9));
	pp.y-=int(10*sin(a+PI/9));
	return pp;
}
//����ͷ
CPoint CRheostat::Conv_coord(CPoint p,BOOL Real_or_Visual)
{
	CPoint q;
	if(Real_or_Visual){
		q.x = p.x - slid4.x;
		q.y = slid4.y - p.y;
	}else{
		q.x = p.x + slid4.x;
		q.y = slid4.y- p.y;
	}
	return q;
}
BOOL CRheostat::Pt_In_Arrow(CPoint pp)//�жϵ��Ƿ��ڼ�ͷ��
{
	BOOL result = FALSE;
	CRgn crgn;
	crgn.CreatePolygonRgn(slid,3,ALTERNATE);//�������������
	result = crgn.PtInRegion(pp);
	crgn.DeleteObject();
	return result;
}
void CRheostat::SetEValue()
{
	int angle = round(TotalAngle*180/PI);
	int a = angle%180;
	if(!a){
		GetValue(TRUE);
	}else{
		GetValue(FALSE);
	}
}
void CRheostat::MovePoint(CPoint pp,CSize size)//�ƶ���ͷ
{
	int angle = round(TotalAngle*180/PI);
	int a = angle%180;
	if(!a){
		if(CheckInRegn(pp,TRUE)){
			OffSetX(size);
		}
		GetValue(TRUE);
	}else{
		if(CheckInRegn(pp,FALSE)){
			OffSetY(size);
		}
		GetValue(FALSE);
	}
}
void CRheostat::OffSetSlid(CSize size)//move slide bar
{
	slid[0].Offset(size);
	slid[1].Offset(size);
	slid[2].Offset(size);
	slid4.Offset(size);
	slid5.Offset(size);
}
void CRheostat::OffSetX(CSize size)//��X�ƶ���ͷ
{
	int m_left,m_right;
	if(left.x<right.x){
		m_left = left.x;
		m_right = right.x;
	}else{
		m_left = right.x;
		m_right = left.x;
	}
	slid[0].Offset(CSize(size.cx,0));
	slid[1].Offset(CSize(size.cx,0));
	slid[2].Offset(CSize(size.cx,0));
	slid4.Offset(CSize(size.cx,0));
	if(slid[0].x < m_left){
		CSize offsize((m_left - slid[0].x),0);
		slid[0].Offset(offsize);
		slid[1].Offset(offsize);
		slid[2].Offset(offsize);
		slid4.Offset(offsize);
	}
	if(slid[0].x > m_right){
		CSize offsize(-(slid[0].x - m_right),0);
		slid[0].Offset(offsize);
		slid[1].Offset(offsize);
		slid[2].Offset(offsize);
		slid4.Offset(offsize);
	}
}
void CRheostat::OffSetY(CSize size)//��Y�ƶ���ͷ
{
	int m_up,m_down;
	if(right.y>left.y){
		m_up = left.y;
		m_down = right.y;
	}else{
		m_up = right.y;
		m_down = left.y;
	}
	slid[0].Offset(CSize(0,size.cy));
	slid[1].Offset(CSize(0,size.cy));
	slid[2].Offset(CSize(0,size.cy));
	slid4.Offset(CSize(0,size.cy));
	if(slid[0].y < m_up){
		CSize offsize(0,(m_up - slid[0].y));
		slid[0].Offset(offsize);
		slid[1].Offset(offsize);
		slid[2].Offset(offsize);
		slid4.Offset(offsize);
	}
	if(slid[0].y > m_down){
		CSize offsize(0,-(slid[0].y - m_down));
		slid[0].Offset(offsize);
		slid[1].Offset(offsize);
		slid[2].Offset(offsize);
		slid4.Offset(offsize);
	}
}
BOOL CRheostat::CheckInRegn(CPoint pp,BOOL x_or_y)//�ж������Ƿ���������
{
	BOOL result = FALSE;
	int m_left,m_right;
	int m_up,m_down;
	if(left.x<right.x){
		m_left = left.x;
		m_right = right.x;
	}else{
		m_left = right.x;
		m_right = left.x;
	}
	if(right.y>left.y){
		m_up = left.y;
		m_down = right.y;
	}else{
		m_up = right.y;
		m_down = left.y;
	}
	if(x_or_y){
		if(m_left<=pp.x&&pp.x<=m_right){
			result = TRUE;
		}else if(m_left>pp.x||pp.x>m_right){
			result = FALSE;
		}
	}else{
		if(m_up<=pp.y&&pp.y<=m_down){
			result = TRUE;
		}else if(m_up>pp.y||pp.y>m_down){
			result = FALSE;
		}
	}
	return result;
}
void CRheostat::GetValue(BOOL x_or_y)//ȡ�õ�ǰ����ֵ
{
	int aa;
	if(x_or_y){
		aa = right.x-slid[0].x;
		Value = (float)fabs(MaxValue*(float)aa/40);
	}else{
		aa = right.y-slid[0].y;
		Value = (float)fabs(MaxValue*(float)aa/40);
	}
}
