// MyWatch.cpp : implementation file
//

#include "stdafx.h"
#include "pointtest.h"
#include "MyWatch.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define BACKCOLOR RGB( 128,128,0 )
#define PEN1COLOR RGB( 191,191,191 )
#define PEN2COLOR RGB( 0,0,0 )

/////////////////////////////////////////////////////////////////////////////
// MyWatch dialog


MyWatch::MyWatch(CWnd* pParent /*=NULL*/)
	: CDialog(MyWatch::IDD, pParent)
{
	m_pView = NULL;
	//{{AFX_DATA_INIT(MyWatch)
	//}}AFX_DATA_INIT
}

MyWatch::MyWatch( CView *view )
{
	m_NUMBER = 1 ;
	m_ButtonID = tool.list.CreateButton( CPoint( 0,0 ),20,20,IDB_BUTTON1,IDB_BUTTON2,IDB_BUTTON3 );
	m_ID = 0;
	m_Title = "������";
	m_Name = "A";           //�����
	m_Value = -2;           //��ֵ
	m_PrevValue = 0;
	m_Units = "����";//��λ
	m_BigValue = 24; //��������ֵ
	m_pView = view ;
	m_LFlag = FALSE;
	m_BigFlag = FALSE;
	m_BaiDongFlag = FALSE;
	m_Number = 0;
	m_tempValue = 0;
}

MyWatch::MyWatch( CView *view,CString name1,UINT id,CString name,double value,CString units,double big )
{
	m_NUMBER = 1 ;
	m_ButtonID = tool.list.CreateButton( CPoint( 0,0 ),20,20,IDB_BUTTON1,IDB_BUTTON2,IDB_BUTTON3 );
	///////////////////////
	m_pView = view ;
	m_LFlag = FALSE;
	m_BigFlag = FALSE;
	m_BaiDongFlag = FALSE;
	m_Number = 0;
	m_tempValue = 0;
	m_PrevValue = 0;
	///////////////////////

    m_Title = name1;
	m_ID = id;
	m_Name = name;           //�����
	m_Value = value;           //��ֵ
	m_Units = units;//��λ
	m_BigValue = big; //��������ֵ
	SetWindowText( m_Title );

}

void MyWatch::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(MyWatch)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(MyWatch, CDialog)
	//{{AFX_MSG_MAP(MyWatch)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// MyWatch message handlers

BOOL MyWatch::Create( )
{
	return CDialog::Create( MyWatch::IDD );
}

void MyWatch::OnOK()
{
	// TODO: Add extra validation here
	if ( m_pView != NULL )
	{
	m_pView->PostMessage(WM_GOODBYE,IDCANCEL);
	}
	else
	{
		CDialog::OnOK();
	}
}

void MyWatch::OnCancel() 
{
	if ( m_pView != NULL )
	{
        DestroyWindow();
		delete this;
		m_pView->PostMessage(WM_GOODBYE);
	}
	else
	{
		CDialog::OnCancel();
	}
}

void MyWatch::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	DrawScreen();
}

void MyWatch::DrawScreen()
{

	CDC *pDC = GetDC( );
    CRect rect,rect1,rect2;
	GetClientRect( rect );
	CDC *dc = new CDC;
	CBitmap *bitmap = new CBitmap;
	CBitmap *pOld;
	dc->CreateCompatibleDC( pDC );
	bitmap->CreateCompatibleBitmap( pDC,rect.Width(),rect.Height() );
	pOld = dc->SelectObject( bitmap );
	dc->PatBlt( 0,0,rect.Width(),rect.Height(),WHITENESS );
	dc->FillSolidRect( 0,0,rect.Width(),rect.Height(),BACKCOLOR );

	//////////////////////////////////////////////////////////////////////////
	//������ 
	rect1 = CRect( rect.left+10,rect.top+10,rect.right-10,rect.bottom/5*3 );
    ///////////////////////////////////////////////////////////////////////
	//���߿�
	rect2 = CRect( rect1.left-3,rect1.top-3,rect1.right+3,rect1.bottom+3 );
	CPen pen1,pen2,*oldpen;
	pen1.CreatePen( PS_SOLID,1,PEN1COLOR );
	pen2.CreatePen( PS_SOLID,1,PEN2COLOR );
	oldpen = dc->SelectObject( &pen1 );
	for ( int i = 0;i<3;i++ )
	{
		dc->MoveTo( rect2.left+i,rect2.top+i );
		dc->LineTo( rect2.left+i,rect2.bottom-i );
		dc->MoveTo( rect2.left+i,rect2.top+i );
		dc->LineTo( rect2.right-i,rect2.top+i );
	}
	dc->SelectObject( oldpen );
	DeleteObject( pen1 );
	oldpen = dc->SelectObject( &pen2 );
	for ( i = 0;i<3;i++ )
	{
		dc->MoveTo( rect2.left+i,rect2.bottom-i );
		dc->LineTo( rect2.right-i,rect2.bottom-i );
		dc->MoveTo( rect2.right-i,rect2.top+i );
		dc->LineTo( rect2.right-i,rect2.bottom-i );
	}
	dc->SelectObject( oldpen );
	DeleteObject( pen2 );
	////////////////////////////////////////////////////////////////////
	face.SetParam( rect1.TopLeft(),rect1.Width(),rect1.Height(),m_Name,m_BigValue,m_Units,m_PrevValue );
	face.Draw( dc,m_NUMBER );
	///////////////////////////////////////////////////////////////////
	if ( face.m_BigFlag )
	{
		m_BigFlag = face.m_BigFlag;
	}
	else
	{
		if ( face.m_SmallFlag )
		{
			m_BigFlag = face.m_SmallFlag;
		}
		else
		{
			m_BigFlag = FALSE;
		}
	}
    //////////////////////////////////////////////////////////////////////////


	////////////////////////////////////////////////////
    //����ʾ����
	CDC *dc1 = new CDC;
	CBitmap *bitmap1 = new CBitmap;
	CBitmap *old1;
	dc1->CreateCompatibleDC( dc );
	if ( m_BigFlag == FALSE )
	{
		bitmap1->LoadBitmap( IDB_BIGFLAG1 );
	}
	else
	{
		bitmap1->LoadBitmap( IDB_BIGFLAG2 );
	}
	old1 = dc1->SelectObject( bitmap1 );
	dc->BitBlt( rect1.right-60,rect1.bottom+20,20,20,dc1,0,0,SRCCOPY );
	dc1->SelectObject( old1 );
	delete dc1;
	delete bitmap1;
    /////////////////////////////////////////

    ////////////////////////////////////////
	//����ť
	tool.list.ExchangeButtonPosition( CPoint( rect1.right-90,rect1.bottom+20 ),m_ButtonID );
	tool.Draw( dc );
    ////////////////////////////////////////

    ////////////////////////////////////////////////////////////////////
	//��������ͷ
    COLORREF oldcolor=dc->SetTextColor( RGB( 255,0,0 ) );  //��ʾ������ɫ
	int oldmode=dc->SetBkMode( TRANSPARENT );    //���ñ���Ϊ͸��ɫ
	CPen pen3,*pPen3;
	pen3.CreatePen( PS_SOLID,1,RGB( 255,0,0 ) );
	pPen3 = dc->SelectObject( &pen3 );
	dc->SelectStockObject( NULL_BRUSH );

	dc->TextOut( rect.right-32,rect.bottom-60,"+" );
	dc->Ellipse( rect.right-40,rect.bottom-40,rect.right-20,rect.bottom-20 );
	dc->Ellipse( rect.right-35,rect.bottom-35,rect.right-25,rect.bottom-25 );
	dc->SelectObject( pPen3 );
	DeleteObject( pen3 );
	CPen pen4,*pPen4;
	pen4.CreatePen( PS_SOLID,1,RGB( 0,0,0 ) );
	pPen4 = dc->SelectObject( &pen4 );
	dc->SetTextColor( oldcolor );
	COLORREF oldcolor1=dc->SetTextColor( RGB( 0,0,0 ) );  //��ʾ������ɫ
	dc->TextOut( rect.left+27,rect.bottom-60,"-" );
    dc->Ellipse( rect.left+40,rect.bottom-40,rect.left+20,rect.bottom-20 );
	dc->Ellipse( rect.left+35,rect.bottom-35,rect.left+25,rect.bottom-25 );
	dc->SelectObject( pPen4 );
	DeleteObject( pen4 );   
	dc->SetTextColor( oldcolor1 );
    dc->SetBkMode( oldmode );

    pDC->BitBlt( 0,0,rect.Width(),rect.Height(),dc,0,0,SRCCOPY );
	dc->SelectObject( pOld );
	delete dc;
	delete bitmap;	
	ReleaseDC( pDC );

	///////////////////////////////////////////////////////////////////////////
}

void MyWatch::SetParam( CString name1,UINT id,CString name,double value,CString units,double big )
{
	UpdateData( FALSE );
	m_Title = name1;
	SetWindowText( m_Title );
	m_ID = id;
    m_Name = name;
	m_Value = value;
	
	m_Units = units;
	m_BigValue = big;
	DrawScreen( );
	SetTimer( 1,100,NULL );
	if ( m_BaiDongFlag )
	{
	   SetTimer( 1,100,NULL );
	}
}

void MyWatch::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_LFlag = TRUE;
	tool.OnLButtonDown( nFlags,point );
    DrawScreen( );
	CDialog::OnLButtonDown(nFlags, point);
}

void MyWatch::OnLButtonUp(UINT nFlags, CPoint point) 
{
	m_LFlag = FALSE;
	tool.OnLButtonUp( nFlags,point );
	if ( tool.list.m_WhatToDo == m_ButtonID )
	{
		if ( m_NUMBER == 1 )
		{
			m_NUMBER = 2;
		}
		else
		{
			m_NUMBER = 1 ;
		}
		tool.list.m_WhatToDo = 0;
	}
	DrawScreen( );
	CDialog::OnLButtonUp(nFlags, point);
}

void MyWatch::OnMouseMove(UINT nFlags, CPoint point) 
{
	tool.OnMouseMove( nFlags,point );
	DrawScreen( );
	CDialog::OnMouseMove(nFlags, point);
}

void MyWatch::OnTimer(UINT nIDEvent) 
{
    if ( m_BaiDongFlag == FALSE )          //�ڶ���־
	{
		if ( m_Value>m_PrevValue )         //��ֵ���ھ�ֵ
		{
			if ( m_Number == 0 )
			{
			    m_tempValue = m_Value-m_PrevValue;
				m_Number++;
			}
			m_PrevValue += ( 0.8*face.m_SingleExpress );
			if ( m_Value <= m_PrevValue )
			{
				m_PrevValue = m_Value;
				KillTimer( 1 );
				m_BaiDongFlag = TRUE;
				m_Number = 0;
				SetTimer( 1,100,NULL );
			}
		}
		else
		{
			if ( m_Number == 0 )
			{
			    m_tempValue = m_PrevValue-m_Value;
				m_Number++;
			}
			m_PrevValue-= ( 0.8*face.m_SingleExpress );
			if ( m_Value>=m_PrevValue )
			{
				m_PrevValue = m_Value;
				KillTimer( 1 );
				m_BaiDongFlag = TRUE;
				m_Number = 0;
				SetTimer( 1,100,NULL );
			}
		}
	}
	else
	{
		if ( m_BaiDongFlag )
		{
			if ( m_Number == 0 )
			{
				m_PrevValue = m_Value+m_tempValue/50;
				m_tempValue -=1*face.m_SingleExpress ;
				m_Number++;
				if ( m_tempValue<=0 )
				{
					KillTimer( 1 );
					//m_PrevValue = m_Value;
					m_BaiDongFlag = FALSE;
					m_Number = 0;
				}
				
			}
			else
			{
				m_PrevValue = m_Value-m_tempValue/50;
				m_tempValue -= 1*face.m_SingleExpress;
				m_Number = 0;
				if ( m_tempValue<=0 )
				{
					KillTimer( 1 );
					//m_PrevValue = m_Value;
					m_BaiDongFlag = FALSE;
					m_Number = 0;
				}
			}
		}
	}
	DrawScreen( );
	CDialog::OnTimer(nIDEvent);
}
