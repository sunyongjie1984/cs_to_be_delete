// BaseTool.cpp: implementation of the CBaseTool class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "BaseTool.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
extern CBitmap blank;
extern int width,height;
CBaseTool::CBaseTool(CWnd* pWnd , 
					 CElist* pList,
					 CPointList* pOintList,
					 CLineList* pLineList,
					 CTextList* pText)
{
	BeginPoint = CPoint(0,0);
	EndPoint = CPoint(0,0);
	CanDraw = FALSE;
	m_pWnd = pWnd;
	ToAngle = 0;
	Select = FALSE;
	Value = 1;
	m_pList = pList;
	m_PointList = pOintList;
	m_pLineList = pLineList;
	m_pTextList = pText;
	m_pBase = NULL;
}
CBaseTool::CBaseTool(CElist* pList,
					 CPointList* pOintList,
					 CLineList* pLineList,
					 CTextList* pText)
{
	BeginPoint = CPoint(0,0);
	EndPoint = CPoint(0,0);
	CanDraw = FALSE;
	m_pWnd = NULL;
	ToAngle = 0;
	Select = FALSE;
	Value = 1;
	m_pList = pList;
	m_PointList = pOintList;
	m_pLineList = pLineList;
	m_pTextList = pText;
	m_pBase = NULL;
}
CBaseTool::~CBaseTool()
{

}
BOOL CBaseTool::ClipCursorInClientRect()
{			
	CRect clientRect;
	m_pWnd->GetClientRect(clientRect );
	
	POINT pointLT, pointRB;
	
	pointLT = clientRect.TopLeft();
	pointRB = clientRect.BottomRight();
		
	m_pWnd->ClientToScreen(&pointLT);
	m_pWnd->ClientToScreen(&pointRB);
		
	clientRect = CRect( pointLT, pointRB );

	return ClipCursor( clientRect );
}
void CBaseTool::Draw()
{
	CBitmap *old_bb;
	CDC* pDC = m_pWnd->GetDC();
	CDC* MemDC = new CDC;

	MemDC->CreateCompatibleDC(pDC);
	old_bb = MemDC->SelectObject(&blank);

	m_pLineList->Draw(MemDC);
	m_PointList->Draw(MemDC);//draw the element list
	m_pList->Draw(MemDC);//draw the point list
	m_pTextList->Draw(MemDC);
	//MessageBeep(-1);
	

	pDC->BitBlt(0,0,width,height,MemDC,0,0,SRCCOPY);
	MemDC->PatBlt(0,0,width,height,WHITENESS);
	//DrawCompanySign(MemDC);
	MemDC->SelectObject(old_bb);
	delete MemDC;
	m_pWnd->ReleaseDC(pDC);
}
void CBaseTool::DrawDash(CPoint p1,CPoint p2,CDC* pDC)
{
	CPen pen(PS_DOT,1,BLACK);
	CPen *oldpen = pDC->SelectObject(&pen);
	pDC->SelectStockObject(NULL_BRUSH);
	pDC->Rectangle(GetRect(p1,p2));
	pDC->SelectObject(oldpen);
}
CRect CBaseTool::GetRect(CPoint p1,CPoint p2)
{
	CRect rect;

	rect.left = MIN2(p1.x,p2.x);
	rect.right = MAX2(p1.x,p2.x);
	rect.bottom = MAX2(p1.y,p2.y);
	rect.top = MIN2(p1.y,p2.y);

	return rect;
}
void CBaseTool::Draw(CPoint p1,CPoint p2)
{
	CBitmap *old_bb;
	CDC* pDC = m_pWnd->GetDC();
	CDC* MemDC = new CDC;

	MemDC->CreateCompatibleDC(pDC);
	old_bb = MemDC->SelectObject(&blank);

	m_pLineList->Draw(MemDC);
	m_PointList->Draw(MemDC);//draw the element list
	m_pList->Draw(MemDC);//draw the point list
	m_pTextList->Draw(MemDC);	


	DrawDash(p1,p2,MemDC);
	pDC->BitBlt(0,0,width,height,MemDC,0,0,SRCCOPY);
	MemDC->PatBlt(0,0,width,height,WHITENESS);
	//DrawCompanySign(MemDC);
	MemDC->SelectObject(old_bb);
	delete MemDC;	
	m_pWnd->ReleaseDC(pDC);
}
void CBaseTool::DrawCompanySign(CDC * pp)
{
	CPen pen(PS_SOLID,1,RGB(240,240,240));
	CPen *Oldpen = pp->SelectObject(&pen);
	for(int i = 0;i<width;i+=10){
		for(int j=0;j<height;j+=10){
			pp->SetPixel(CPoint(i,j),BLACK);
		}
	}
	pp->SelectObject(Oldpen);
}
void CBaseTool::CaptureScr()
{
	ShowCursor(FALSE);
	m_pWnd->SetCapture();
	ClipCursorInClientRect();
}
void CBaseTool::ReleaseScr()
{
	ShowCursor(TRUE);
	ClipCursor( NULL );
	ReleaseCapture();
}