// LineTool.cpp: implementation of the CRTool class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "LineTool.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
extern int RisisNumber;
CRTool::CRTool(CWnd* cWnd,CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText)
		:CBaseTool(cWnd,pList,pOintList,pLineList,pText)
{

}
CRTool::CRTool(CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText)
		:CBaseTool(pList,pOintList,pLineList,pText)
{

}
CRTool::~CRTool()
{
}
void CRTool::OnLButtonDown(UINT nFlags, CPoint point)
{
	CanDraw = TRUE;
	CaptureScr();

	AddObject(point);

	Draw();
}
void CRTool::OnLButtonUp(UINT nFlags, CPoint point)
{
	if(!CanDraw) return;
	CanDraw = FALSE;
	ReleaseScr();
}
void CRTool::OnMouseMove(UINT nFlags, CPoint point)
{
	if(CanDraw){
		m_pBase->SetPoint(point);
		Draw();
	}
}
void CRTool::AddObject(CPoint point)
{
	p1 = new CEpoint(m_PointList);
	p2 = new CEpoint(m_PointList);
	m_pBase = new CResis(p1,p2,m_pList);
	
	m_pBase->TotalAngle = ToAngle;
	m_pBase->m_iSelected = Select;
//	m_pBase->Value = Value;
	m_pBase->SetPoint(point);

	p1->Parent = m_pBase;
	p2->Parent = m_pBase;
}