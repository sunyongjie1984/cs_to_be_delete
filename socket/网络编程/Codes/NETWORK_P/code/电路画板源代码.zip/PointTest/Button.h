// Button.h: interface for the Button class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BUTTON_H__74583B41_741D_11D4_825F_60000000105A__INCLUDED_)
#define AFX_BUTTON_H__74583B41_741D_11D4_825F_60000000105A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Button  
{
public:
	Button();
	virtual ~Button();
public:
	BOOL m_LFlag;
	BOOL m_BeSelected;
	BOOL m_MoveBeSelected;
	CPoint m_Point;
	int m_Width,m_Hight;
    UINT m_ID;
	UINT m_BitmapID1,m_BitmapID2,m_BitmapID3;
public :
	void Draw( CDC * );
	BOOL PtInButton( CPoint );
	void ExchangeButtonPosition( CPoint );
	void Serialize( CArchive &ar );
	

};

#endif // !defined(AFX_BUTTON_H__74583B41_741D_11D4_825F_60000000105A__INCLUDED_)
