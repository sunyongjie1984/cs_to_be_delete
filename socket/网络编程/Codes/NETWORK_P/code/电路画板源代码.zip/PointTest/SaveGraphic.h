// SaveGraphic.h: interface for the SaveGraphic class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SAVEGRAPHIC_H__D7ABA0C1_69EA_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_SAVEGRAPHIC_H__D7ABA0C1_69EA_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Elist.h"
#include "pointlist.h"
#include "linelist.h"
#include "textlist.h"
#include "basetool.h"
class SaveGraphic  
{
public:
	SaveGraphic(CWnd * pWnd,CElist* pList , CPointList* pOintList,CLineList* pLineList,CTextList* pTextList);
	virtual ~SaveGraphic();
	void Serialize(CArchive& ar);
	void CreateElement(UINT id,CPoint point,double Rotate,BOOL select,float value);
public:
	CElist* m_pList;
	CPointList* m_PointList;
	CLineList* m_pLineList;
	CTextList* m_pTextList;
	CBaseTool *     m_pBaseTool;
	int nTime;
	UINT m_ElementType;
	BOOL m_iSelected;
	double TotalAngle;
	CPoint CenterPoint;
	float Value;
	CWnd* m_pWnd;
	int parentnumber1,parentnumber2;

	CRect TextRect;
	CString TextString;

	CText * pText;
};

#endif // !defined(AFX_SAVEGRAPHIC_H__D7ABA0C1_69EA_11D4_BBD7_600000000ECD__INCLUDED_)
