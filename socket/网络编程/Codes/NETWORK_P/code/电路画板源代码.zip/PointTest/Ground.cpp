// Ground.cpp: implementation of the CGround class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "Ground.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGround::CGround(int nType,CBaseList* pBaseList) : CBase(ID_GROUND,pBaseList)
{
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "G";
	AddString(ID_GROUND);
	Value = 1;
}
CGround::CGround(CBase* pp1,CBaseList* pBaseList) : CBase(ID_GROUND,pBaseList)
{
	p1 = pp1;
	AddSon(p1);
	left = CPoint(0,0);
	right = CPoint(0,0);
	Content_Of_Ob = "G";
	AddString(ID_GROUND);
	Value = 1;
}
CGround::~CGround()
{
}
void CGround::Draw(CDC* pDC)
{
	if(IsSelected()){
		CPen pen(PS_SOLID, 2,RED);
		CPen *Oldpen = pDC->SelectObject(&pen);

		pDC->MoveTo(left);
		pDC->LineTo(p1->CenterPoint);

		pDC->MoveTo(aa[0]);
		pDC->LineTo(aa[1]);
		pDC->MoveTo(aa[2]);
		pDC->LineTo(aa[3]);
		pDC->MoveTo(aa[4]);
		pDC->LineTo(aa[5]);

		pDC->SelectObject(Oldpen);
	}else{
		CPen pen(PS_SOLID, 2,BLACK);
		CPen *Oldpen = pDC->SelectObject(&pen);
		pDC->MoveTo(left);
		pDC->LineTo(p1->CenterPoint);

		pDC->MoveTo(aa[0]);
		pDC->LineTo(aa[1]);
		pDC->MoveTo(aa[2]);
		pDC->LineTo(aa[3]);
		pDC->MoveTo(aa[4]);
		pDC->LineTo(aa[5]);
		pDC->SelectObject(Oldpen);
	}
	TextOut(pDC);
}
void CGround::SetPoint(CPoint pp)
{
	left = right = CenterPoint = pp;
	left = pp - CPoint(10,0);
	right = pp + CPoint(10,0);
	p1->CenterPoint = pp - CPoint(20,0);

	aa[0] = aa[1] = left;
	aa[2] = aa[3] = CenterPoint;
	aa[4] = aa[5] = right;
	aa[0].Offset(CSize(0,10));
	aa[1].Offset(CSize(0,-10));
	aa[2].Offset(CSize(0,8));
	aa[3].Offset(CSize(0,-8));
	aa[4].Offset(CSize(0,6));
	aa[5].Offset(CSize(0,-6));
	RotateCell(TotalAngle);
}
void CGround::OffSet(CSize size)
{
	CenterPoint.Offset(size);
	left.Offset(size);
	right.Offset(size);
	p1->OffSet(size);
	for(int i=0;i<6;i++)
		aa[i].Offset(size);
	
}
CRect CGround::GetGraphRect()
{
	CPoint up_left,down_right;
	up_left = down_right = CenterPoint;
	up_left.Offset(-10,-10);
	down_right.Offset(10,10);
	return CRect(up_left,down_right);	
}
void CGround::RotateCell(double angle)
{
	left = Rotate(angle,left);
	right = Rotate(angle,right);
	p1->CenterPoint = Rotate(angle,p1->CenterPoint);
	for(int i=0;i<6;i++)
		aa[i] = Rotate(angle,aa[i]);
}