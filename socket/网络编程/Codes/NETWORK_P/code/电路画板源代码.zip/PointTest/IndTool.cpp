// IndTool.cpp: implementation of the CIndTool class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "IndTool.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CIndTool::CIndTool(CWnd* cWnd,CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText)
		:CBaseTool(cWnd,pList,pOintList,pLineList,pText)
{
}
CIndTool::CIndTool(CElist* pList, CPointList* pOintList,CLineList* pLineList,CTextList* pText)
		:CBaseTool(pList,pOintList,pLineList,pText)
{
}
CIndTool::~CIndTool()
{

}
void CIndTool::OnLButtonDown(UINT nFlags, CPoint point)
{
	CanDraw = TRUE;
	CaptureScr();

	AddObject(point);

	Draw();
}
void CIndTool::OnLButtonUp(UINT nFlags, CPoint point)
{
	if(!CanDraw) return;
	CanDraw = FALSE;
	ReleaseScr();
}
void CIndTool::OnMouseMove(UINT nFlags, CPoint point)
{
	if(CanDraw){
		m_pBase->SetPoint(point);
		Draw();
	}
}
void CIndTool::AddObject(CPoint point)
{
	p1 = new CEpoint(m_PointList);
	p2 = new CEpoint(m_PointList);

	m_pBase = new CInductance(p1,p2,m_pList);
	m_pBase->TotalAngle = ToAngle;
	m_pBase->m_iSelected = Select;
//	m_pBase->Value = Value;
	m_pBase->SetPoint(point);
	p1->Parent = m_pBase;
	p2->Parent = m_pBase;
}