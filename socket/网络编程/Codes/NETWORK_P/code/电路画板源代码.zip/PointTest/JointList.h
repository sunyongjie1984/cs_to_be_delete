// JointList.h: interface for the CJointList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JOINTLIST_H__6FF25B79_598A_11D4_AFFB_00E04C6749D0__INCLUDED_)
#define AFX_JOINTLIST_H__6FF25B79_598A_11D4_AFFB_00E04C6749D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseList.h"
#include "afxtempl.h"
#include "Joint.h"
#include "Element.h"

class CJointList : public CABaseList  
{
public:
//	CList<CAJoint*,CAJoint*>m_pListJoint;
	void ClearUpAllList();
	typedef CList <CAJoint *,CAJoint *> JointList;
	JointList m_pListJoint,*m_pOldList;
	JointList m_copyListJoint,*m_pCopyList;
	JointList m_saveListJoint,*m_pSaveList;
	JointList m_saveRealList,*m_pSaveRealList;

	typedef CList <CAElement *,CAElement *> ElementList;
	ElementList m_pDiodeList;
	ElementList m_AmperList;
	ElementList m_VoltList;

public:
	int GetElementCount(JointList* pList);
	void AddJoint(JointList* p,int order);
	void RemoveJoint(CAJoint *pJoint,JointList *pList);
	CAJoint *GetJoint(int order,JointList *pList);
	void AdjustJoint(JointList *pList);//get rid of the two power joints
	void RemoveAll(JointList *pList);
	CAElement* NewElement(int type,float value);

	void CreateCopyJointList(JointList *pSourceList,JointList *pCopyList);
	void RegulateListAsOrder(JointList *pList);
	
	void SaveCapacityInList(JointList* pList,CList<CAElement*,CAElement*>*pCapaList);
	void AdjustCapacityInList(JointList* pList,CList<CAElement*,CAElement*>*pCapaList);
	void RemoveAboutCapacity(JointList* pList,CList<CAElement*,CAElement*>*pCapaList);

	void SetAllIsAllPowerInList(BOOL b,JointList *pList);

	void AllElsToOthers(int type1,int type2,float value,JointList *pList);

	float GetAverageOfResistance(JointList *pList);


public:
	void SetAllIsSetVoltage(BOOL b,JointList* pList);
	void SetAmperOutput(ElementList* pElList,JointList* pList);
	void SetVoltOutput(ElementList* pElList,JointList* pList);
	int GetBaseOrder();
	void GiveMeBase(int base);
//	CAElement* GetSameElInOtherList(CAElement* pE,JointList* pList);
	void SetSwitchCurrent(CAElement* pSwitch,CAJoint* p);
	void SetVoltmeterCurrent(CAElement* pVoltmeter,CAJoint* p);
	void SetAmpermeterCurrent(CAElement* pAmper,CAJoint* p);
	void SetInductorCurrent(CAElement* pInductor,CAJoint* p);
	void SetCapacityCurrent(CAElement* pCapacity,CAJoint* p);
	void SetResistanceCurrent(CAElement* pResistance,CAJoint* p);
	void SetPowerCurrent(CAElement* pPower,CAJoint* p);
	void SetDiodeCurrent(CAElement* pDiode,CAJoint* p);
	void SetAllElCurrent(JointList* pList);
	void SetVoltmeterValue(JointList* pList);
	void DealWithVoltmeter(JointList* pList);
	void DealWithAmpermeter(JointList* pList);
	CAElement* NewSwitch(BOOL bIsClose);
	void DealWithSwitch(JointList* pList);
	void OneElToOther(CAElement *pE,int type,float value);
	void SetZeroVoltage(int nArrayPowerNum,JointList *pList);
	CAElement* GetElement(CAElement* pE,JointList* pList);
	void AdjustPloarityOfDiode(int nArrayPowerNum);
	void RemoveElList(ElementList *pElList);
	BOOL IsExistSpecEl(int type,JointList *pList,ElementList *pElList);
	CJointList();
	virtual ~CJointList();
	void SetWorkedInList(BOOL b,JointList *pList);

protected:
	BOOL IsSameJoint(CAElement* pE1,CAElement* pE2);
	int SetParrelPowerCurrent(CAElement* pPower,CAJoint* pJ);
	BOOL GoTheWay(CAJoint* pJoint);
//	CAElement* GetSameElInOtherList(int type,int order1,int order2,JointList* pList);
	int m_nBase;
	void SetSpecialElCurrent(CAElement* pE,CAJoint* p);
	
	
	POSITION TwoLoop(POSITION pos,JointList *pList);
	void SearchEqualVoltageJoint(CAJoint *pJoint,CAElement *pCapa,JointList *pList);
};

#endif // !defined(AFX_JOINTLIST_H__6FF25B79_598A_11D4_AFFB_00E04C6749D0__INCLUDED_)
