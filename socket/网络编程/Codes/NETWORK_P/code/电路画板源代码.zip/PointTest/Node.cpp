// Node.cpp: implementation of the CNode class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "Node.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CMyNode::CMyNode(CBase* p1,CBase* p2)//CBase* p1,CBase* p2
{
	m_pPointInNode.AddTail(p1);
	m_pPointInNode.AddTail(p2);
	Number = ID_NONODE;
}
CMyNode::CMyNode(CBase* p1,CBase* p2,CBase* p3,CBase* p4)//CBase* p1,CBase* p2
{
	m_pPointInNode.AddTail(p1);
	m_pPointInNode.AddTail(p2);
	m_pPointInNode.AddTail(p3);
	m_pPointInNode.AddTail(p4);
	Number = ID_NONODE;
}
CMyNode::~CMyNode()
{
}
BOOL CMyNode::IfHaveSamePoint(CMyNode* NewOne)
{
	CBase* p1,*p2;
	POSITION OldPos,NewPos;
	OldPos = m_pPointInNode.GetHeadPosition();
	while(OldPos!=NULL){
		p1 = m_pPointInNode.GetNext(OldPos);
		NewPos = NewOne->m_pPointInNode.GetHeadPosition();
		while(NewPos!=NULL){
			p2 = NewOne->m_pPointInNode.GetNext(NewPos);
			if(p1 == p2)
				return TRUE;
		}
	}
	return FALSE;
}
BOOL CMyNode::IfHaveSameElement(CMyNode* NewOne)
{
	CBase* p1,*p2;
	POSITION OldPos,NewPos;
	OldPos = m_pElementInNode.GetHeadPosition();
	while(OldPos!=NULL){
		p1 = m_pElementInNode.GetNext(OldPos);
		NewPos = NewOne->m_pElementInNode.GetHeadPosition();
		while(NewPos!=NULL){
			p2 = NewOne->m_pElementInNode.GetNext(NewPos);
			if(p1 == p2)
				return TRUE;
		}
	}
	return FALSE;
}
void CMyNode::AddPoint(CMyNode* Owner)
{
	CBase* MovePoint;
	POSITION Pos = m_pPointInNode.GetHeadPosition();
	while(Pos!=NULL){
		MovePoint = m_pPointInNode.GetNext(Pos);
		if(!Owner->m_pPointInNode.Find(MovePoint))
			Owner->m_pPointInNode.AddTail(MovePoint);
	}
}
void CMyNode::AddElement(CBase* elem)
{
	if(!m_pElementInNode.Find(elem))
		m_pElementInNode.AddTail(elem);
}
void CMyNode::ArrangeElement()
{
	CBase* aa;
	POSITION pos= m_pPointInNode.GetHeadPosition();
	while(pos!=NULL)
	{
		aa = (CBase *)m_pPointInNode.GetNext(pos);
		AddElement(aa->Parent);
	}	
}
BOOL CMyNode::PointInNode(CBase* point)
{
	if(!m_pPointInNode.Find(point))
		return FALSE;
	return TRUE;
}
int  CMyNode::GetMyCount()
{
	int i=0;
	CBase* aa;
	POSITION pos= m_pElementInNode.GetHeadPosition();
	while(pos!=NULL)
	{
		aa = (CBase *)m_pElementInNode.GetNext(pos);
		if(aa->GetType()!=ID_DOT)
			i++;
	}
	return i;
}
BOOL CMyNode::IfHavePower()
{
	CBase* aa;
	POSITION Pos = m_pElementInNode.GetHeadPosition();
	while(Pos!=NULL){
		aa = m_pElementInNode.GetNext(Pos);
		if(aa->GetType()==ID_POWER)
			return TRUE;
	}
	return FALSE;
}
void CMyNode::AddElementToSerial(CElementSerial *m_Serial)
{
	CBase* aa;
	UINT nType;
	POSITION Pos = m_pElementInNode.GetHeadPosition();
	while(Pos!=NULL){
		aa = m_pElementInNode.GetNext(Pos);
		nType = aa->GetType();
		if(nType == ID_DOT||nType == ID_GROUND){
		}else{
			if(!m_Serial->Find(aa))
				m_Serial->AddTail(aa);
		}
	}
}