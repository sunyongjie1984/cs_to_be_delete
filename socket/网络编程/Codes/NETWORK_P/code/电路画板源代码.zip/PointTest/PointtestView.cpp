// PointtestView.cpp : implementation of the CPointtestView class
//

#include "stdafx.h"
#include "Pointtest.h"

#include "PointtestDoc.h"
#include "PointtestView.h"
#include "selecttool.h"
#include "linetool.h"
#include "pointtool.h"
#include "dottool.h"
#include "captool.h"
#include "indtool.h"
#include "powertool.h"
#include "groundtool.h"
#include "diodetool.h"
#include "switchtool.h"
#include "currenttool.h"
#include "voltagetool.h"
#include "lighttool.h"
#include "texttool.h"
#include "rheostattool.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPointtestView

IMPLEMENT_DYNCREATE(CPointtestView, CView)

BEGIN_MESSAGE_MAP(CPointtestView, CView)
	//{{AFX_MSG_MAP(CPointtestView)
	ON_COMMAND(ID_SELECTONE, OnSelect)
	ON_COMMAND(ID_DIANZU, OnResistance)
	ON_COMMAND(ID_KETIAODIANZU,OnRheostat)
	ON_COMMAND(ID_DIAN, OnPoint)
	ON_COMMAND(ID_CAP, OnCapacitance)
	ON_COMMAND(ID_ERJIGUAN, OnDiode)
	ON_COMMAND(ID_DI, OnGround)
	ON_COMMAND(ID_DIANGAN, OnInductance)
	ON_COMMAND(ID_DDDZ, OnSwitch)
	ON_COMMAND(ID_DIANYUAN, OnPower)
	ON_COMMAND(ID_DIANYABIAO, OnVoltage)
	ON_COMMAND(ID_DIANLIUBIAO, OnCurrent)
	ON_COMMAND(ID_DENG, OnLight)
	ON_COMMAND(ID_HGRIP, OnHGrip)
	ON_COMMAND(ID_VGRIP, OnVGrip)
	ON_COMMAND(ID_ANTICLOCKWISE, OnAntiClockWise)
	ON_COMMAND(ID_DEAZIL, OnSeaZil)
	ON_COMMAND(ID_GO, OnGogo)
	ON_COMMAND(ID_TEXTA, OnText)
	ON_COMMAND(ID_CALCULATE, OnCalculate)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_CREATE()
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_UPDATE_COMMAND_UI(ID_DIAN, OnUpdateDian)
	ON_UPDATE_COMMAND_UI(ID_DI, OnUpdateDi)
	ON_UPDATE_COMMAND_UI(ID_DENG, OnUpdateDeng)
	ON_UPDATE_COMMAND_UI(ID_DDDZ, OnUpdateDddz)
	ON_UPDATE_COMMAND_UI(ID_CAP, OnUpdateCap)
	ON_UPDATE_COMMAND_UI(ID_DIANZU, OnUpdateDianzu)
	ON_UPDATE_COMMAND_UI(ID_DIANYUAN, OnUpdateDianyuan)
	ON_UPDATE_COMMAND_UI(ID_DIANYABIAO, OnUpdateDianyabiao)
	ON_UPDATE_COMMAND_UI(ID_DIANLIUBIAO, OnUpdateDianliubiao)
	ON_UPDATE_COMMAND_UI(ID_DIANGAN, OnUpdateDiangan)
	ON_UPDATE_COMMAND_UI(ID_ERJIGUAN, OnUpdateErjiguan)
	ON_UPDATE_COMMAND_UI(ID_SELECTONE, OnUpdateSelectone)
	ON_UPDATE_COMMAND_UI(ID_TEXTA, OnUpdateTexta)
	ON_UPDATE_COMMAND_UI(ID_KETIAODIANZU, OnUpdateKetiaodianzu)
	ON_WM_CLOSE()
	ON_COMMAND(ID_LOOKMETER, OnLookmeter)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
	//ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
//	ON_MESSAGE(WM_PLEASECOPY, OnPleaseCopy)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPointtestView construction/destruction
CBitmap blank;
int width,height;
int RisisNumber = 0; //����
int PowerNumber = 0; //��Դ
int CapNumber = 0;   //����
int DiodeNumber = 0; //������
int InduNumber = 0;  //���
int LightNumber = 0; //����
int GroundNumber = 0;//�ӵ�
int CurrentNumber = 0;//������
int VoltageNumber = 0;//��ѹ��
int SwitchNumber = 0; //����
int RheostatNumber = 0;//������

CPointtestView::CPointtestView()
{
	Operation_id = ID_SELECT;
	m_pBaseTool = NULL;
	m_pNodeList = NULL;
	id_Check = ID_SELECTONE;
	
}

CPointtestView::~CPointtestView()
{
	
}

BOOL CPointtestView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPointtestView drawing

void CPointtestView::OnDraw(CDC* pDC)
{
	CPointtestDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	//DrawCompanySign(pDC, 0,(height/2-100));
	m_pList->Draw(pDC);
	m_pLineList->Draw(pDC);
	m_pTextList->Draw(pDC);
	/*ShowCursor(TRUE);
	ClipCursor( NULL );
	ReleaseCapture();*/
}

/////////////////////////////////////////////////////////////////////////////
// CPointtestView printing

BOOL CPointtestView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CPointtestView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CPointtestView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CPointtestView diagnostics

#ifdef _DEBUG
void CPointtestView::AssertValid() const
{
	CView::AssertValid();
}

void CPointtestView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPointtestDoc* CPointtestView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPointtestDoc)));
	return (CPointtestDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPointtestView message handlers

void CPointtestView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if( m_pBaseTool )
		m_pBaseTool->OnLButtonDown( nFlags, point );	
	
	CView::OnLButtonDown(nFlags, point);
}

void CPointtestView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if( m_pBaseTool )
		m_pBaseTool->OnLButtonUp( nFlags, point );	
	
	CView::OnLButtonUp(nFlags, point);
}

void CPointtestView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if( m_pBaseTool )
		m_pBaseTool->OnMouseMove( nFlags, point );	

	CView::OnMouseMove(nFlags, point);
}

int CPointtestView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	return 0;
}

void CPointtestView::OnSelect()//
{
	ToolBox(ID_SELECT);
	id_Check = ID_SELECTONE;
}
void CPointtestView::OnResistance()//
{
	ToolBox(ID_RESISTANCE);
	id_Check = ID_DIANZU;
}
void CPointtestView::OnRheostat()
{
	ToolBox(ID_RHEOSTAT);
	id_Check = ID_KETIAODIANZU;
}
void CPointtestView::OnPoint()//++
{
	ToolBox(ID_DOT);
	id_Check = ID_DIAN;
}
void CPointtestView::OnCapacitance()//
{
	ToolBox(ID_CAPACITANCE);
	id_Check = ID_CAP;
}
void CPointtestView::OnDiode()//
{
	ToolBox(ID_DIODE);
	id_Check = ID_ERJIGUAN;
}
void CPointtestView::OnGround()//++
{
	ToolBox(ID_GROUND);
	id_Check = ID_DI;
}
void CPointtestView::OnInductance()//
{
	ToolBox(ID_INDUCTANCE);
	id_Check = ID_DIANGAN;
}
void CPointtestView::OnVoltage()//
{
	ToolBox(ID_VOLTAGE_METER);
	id_Check = ID_DIANYABIAO;
}
void CPointtestView::OnCurrent()//
{
	ToolBox(ID_CURRENT_METER);
	id_Check = ID_DIANLIUBIAO;
}

void CPointtestView::OnSwitch()//++
{
	ToolBox(ID_SWITCH);
	id_Check = ID_DDDZ;
}
void CPointtestView::OnPower()
{
	ToolBox(ID_POWER);
	id_Check = ID_DIANYUAN;
}
void CPointtestView::OnLight()//++
{
	ToolBox(ID_LIGHT);
	id_Check = ID_DENG;
}
void CPointtestView::OnText()
{
	ToolBox(ID_TEXT);
	id_Check = ID_TEXTA;
}
void CPointtestView::OnCalculate()
{
CWnd* pWnd=CWnd::FindWindow(NULL,"������");
	if(pWnd==NULL)
	{
//	if(ShellExecute(NULL,"open","c:\\windows\\calc.exe",NULL,NULL,SW_SHOWNORMAL)<=32);
		if((WinExec("calc.exe",SW_SHOW))<=31)
			AfxMessageBox("�Ҳ���calc.exe�ļ�������ִ�д˲���!");
	}
	else
	{
		CWnd* pWndPopup=pWnd->GetLastActivePopup();
		pWnd->SetForegroundWindow();
		if(pWnd->IsIconic())
			pWnd->ShowWindow(SW_SHOWNORMAL);
		if(pWnd!=pWndPopup)
			pWndPopup->SetForegroundWindow();
	}
}
void CPointtestView::OnHGrip()
{
	if(m_pBaseTool){
		m_pList->HGripSelected();
		m_pBaseTool->Draw();
	}
}
void CPointtestView::OnVGrip()
{
	if(m_pBaseTool){
		m_pList->VGripSelected();
		m_pBaseTool->Draw();
	}
}
void CPointtestView::OnAntiClockWise()
{
	if(m_pBaseTool){
		m_pList->RotateSelected(45);
		m_pBaseTool->Draw();
	}
}
void CPointtestView::OnSeaZil()
{
	if(m_pBaseTool){
		m_pList->RotateSelected(-45);
		m_pBaseTool->Draw();
	}
}
//��ʼ��Ⲣģ��
void CPointtestView::OnGogo()
{
	CString print,dataA;
	CDC* pDC = GetDC();
	m_pNodeList->CreateBaseChain();
	m_pNodeList->AddElementToSerial();
	if(!CheckIFCorrect()){
		m_pNodeList->ClearAll();
		return;
	}
	print = m_pNodeList->GetListString();
	m_pNodeList->OutPut(pDC);
	m_pNodeList->ClearAll();
	pDC->TextOut(10,10,print);
	ReleaseDC(pDC);
}
//����
void CPointtestView::OnLookmeter() 
{
	m_pList->DisplayWatch(this);
}
//ѡ�񹤾�
void CPointtestView::ToolBox(UINT nID)
{
	//if( Operation_id == (int)nID )	return;
	Operation_id = (int)nID;
	if( m_pBaseTool )
		delete m_pBaseTool;

	Operation_id = nID;

	m_pList->DeSelect();
	m_ppointlist->DeSelect();
	m_pLineList->DeSelect();

	//ѡ���������
	switch( Operation_id )
	{
	case ID_SELECT:
		m_pBaseTool = new CSelectTool( this, m_pList ,m_ppointlist,m_pLineList,m_pTextList);
		break;
	case ID_RESISTANCE:
		m_pBaseTool = new CRTool( this, m_pList,m_ppointlist,m_pLineList,m_pTextList);
		break;
	case ID_DOT:
		m_pBaseTool = new CDotTool( this, m_pList,m_ppointlist,m_pLineList,m_pTextList);
		break;
	case ID_CAPACITANCE:
		m_pBaseTool = new CCapTool( this, m_pList,m_ppointlist,m_pLineList,m_pTextList);
		break;
	case ID_DIODE:
		m_pBaseTool = new CDiodeTool( this, m_pList,m_ppointlist,m_pLineList,m_pTextList);
		break;
	case ID_GROUND:
		m_pBaseTool = new CGroundTool( this, m_pList,m_ppointlist,m_pLineList,m_pTextList);
		break;
	case ID_INDUCTANCE:
		m_pBaseTool = new CIndTool( this, m_pList,m_ppointlist,m_pLineList,m_pTextList);
		break;
	case ID_VOLTAGE_METER:
		m_pBaseTool = new CVoltageTool( this, m_pList,m_ppointlist,m_pLineList,m_pTextList);
		break;
	case ID_CURRENT_METER:
		m_pBaseTool = new CCurrentTool( this, m_pList,m_ppointlist,m_pLineList,m_pTextList);
		break;
	case ID_SWITCH:
		m_pBaseTool = new CSwitchTool( this, m_pList,m_ppointlist,m_pLineList,m_pTextList);
		break;
	case ID_POWER:
		m_pBaseTool = new CPowerTool( this, m_pList,m_ppointlist,m_pLineList,m_pTextList);
		break;
	case ID_LIGHT:
		m_pBaseTool = new CLightTool( this, m_pList,m_ppointlist,m_pLineList,m_pTextList);
		break;
	case ID_TEXT:
		m_pBaseTool = new CTextTool( this, m_pList,m_ppointlist,m_pLineList,m_pTextList);
		break;
	case ID_RHEOSTAT:
		m_pBaseTool = new CRheostatTool( this ,m_pList,m_ppointlist,m_pLineList,m_pTextList);
		break;
	default:
		m_pBaseTool = NULL;
		AfxMessageBox( _T("û�д˹��ߣ�������ѡ��") );
		return;		
	}
}

void CPointtestView::OnInitialUpdate()
{
	CView::OnInitialUpdate();
	AfxGetMainWnd()->SetWindowText(_T("��·����"));
	width = ::GetSystemMetrics(SM_CXSCREEN);
	height = ::GetSystemMetrics(SM_CYSCREEN);
	CreateBlankBitmap();
	m_pList = &(GetDocument()->m_list);
	m_ppointlist = &(GetDocument()->m_pointlist);
	m_pLineList = &(GetDocument()->m_linelist);
	m_pTextList = &(GetDocument()->m_textlist);
	m_pNodeList = new CNodeList(m_pList,m_ppointlist,m_pLineList);
	OnSelect();
}
//�����հ�ҳ
void CPointtestView::CreateBlankBitmap()
{
	//CBitmap bcc;
	CDC* pDC = GetDC();
	CDC* MemDC = new CDC;
	blank.CreateCompatibleBitmap(pDC,width,height);
	MemDC->CreateCompatibleDC(pDC);
	CBitmap* oldbmp = MemDC->SelectObject(&blank);
	MemDC->PatBlt(0,0,width,height,WHITENESS);
	MemDC->SelectObject(oldbmp);
	delete MemDC;
	ReleaseDC(pDC);
}
void CPointtestView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	switch(nChar){
	case VK_DELETE:
		m_pList->DeleteSelected();
		m_pLineList->DeleteSelected();
		m_pTextList->DeleteSelected();
		break;
	case 'A'://VK_CONTROL:
		if(::GetKeyState(VK_CONTROL)){//&0x8000)
			m_pList->SelectAll();
			m_pTextList->SelectAll();
		}
		break;
	case VK_LEFT:
		m_pList->MoveSelected(CSize(-1,0));
		m_pTextList->Move(CSize(-1,0));
		break;
	case VK_RIGHT:
		m_pList->MoveSelected(CSize(1,0));
		m_pTextList->Move(CSize(1,0));
		break;
	case VK_UP:
		m_pList->MoveSelected(CSize(0,-1));
		m_pTextList->Move(CSize(0,-1));
		break;
	case VK_DOWN:
		m_pList->MoveSelected(CSize(0,1));
		m_pTextList->Move(CSize(0,1));
		break;
	case VK_NEXT:
		m_pList->RotateSelected(-45);
		break;
	case VK_PRIOR:
		m_pList->RotateSelected(45);
		break;
	case VK_SPACE:
		m_pList->TurnSwitch();
		break;
	default:
		break;
	}
	if(m_pBaseTool)
		m_pBaseTool->Draw();
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}
//����
void CPointtestView::DrawCompanySign(CDC * pp, int xx, int yy)
{
	LOGFONT logFont;
    logFont.lfHeight = 130;
    logFont.lfWidth = 40;
    logFont.lfEscapement = 300;
    logFont.lfOrientation = 0;
    logFont.lfWeight = FW_NORMAL;
    logFont.lfItalic = 0;
    logFont.lfUnderline = 0;
    logFont.lfStrikeOut = 0;
    logFont.lfCharSet = ANSI_CHARSET;
    logFont.lfOutPrecision = OUT_DEFAULT_PRECIS;
    logFont.lfClipPrecision = CLIP_DEFAULT_PRECIS;
    logFont.lfQuality = PROOF_QUALITY;
    logFont.lfPitchAndFamily = VARIABLE_PITCH | FF_ROMAN;
	strcpy(logFont.lfFaceName, "����_GB2312");
	pp->SetBkMode(TRANSPARENT);
	pp->SetTextColor(RGB(249,249,249));

	CFont font;
	font.CreateFontIndirect(&logFont);
	CFont* oldFont = pp->SelectObject(&font);
	CString company = "";
	pp->TextOut(0,0,company);
	pp->TextOut(0,130,company);
	pp->TextOut(0,260,company);
	pp->TextOut(0,390,company);
	pp->SelectObject(oldFont);
	pp->SetTextColor(RGB(0,0,0));
}
//��ӡ����
void CPointtestView::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo)
{
	CView::OnPrepareDC(pDC, pInfo);
	//pDC->SetMapMode(MM_TWIPS);
	pDC->SetMapMode(MM_ANISOTROPIC);//ת������ӳ�䷽ʽ	
	CSize size = CSize(800, 560);
	pDC->SetWindowExt(size);//ȷ�����ڴ�С//�õ�ʵ���豸ÿ�߼�Ӣ�����������
	int xLogPixPerInch = pDC->GetDeviceCaps(LOGPIXELSX);
	int yLogPixPerInch = pDC->GetDeviceCaps(LOGPIXELSY);//�õ��豸������߼�����ı���
	long xExt = (long)size.cx * xLogPixPerInch/96;
	long yExt = (long)size.cy * yLogPixPerInch/96;
	pDC->SetViewportExt((int)xExt, (int)yExt);
}

void CPointtestView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	if( m_pBaseTool )
		m_pBaseTool->OnLButtonDblClk( nFlags, point );
	
	CView::OnLButtonDblClk(nFlags, point);
}
//����·��ȷ��
BOOL CPointtestView::CheckIFCorrect()
{ 
	if(!m_pNodeList->IfAllPortHaveLine()){//����Ƿ�����Ԫ��������
		MessageBox("�����Ƿ�����Ԫ���������˵���!","��·������ʾ",MB_ICONQUESTION|MB_OK);
		return FALSE;
	}
	//if(!m_//����Դ���������
	if(!m_pNodeList->IfCellClosed()){//���Ԫ����·�����
		MessageBox("�����Ƿ���Ԫ����·���!","��·������ʾ",MB_ICONQUESTION|MB_OK);
		return FALSE;
	}
	if(!m_pNodeList->IfHavePower()){//����·���Ƿ��е�Դ
		MessageBox("�����·���Ƿ��е�Դ!","��·������ʾ",MB_ICONQUESTION|MB_OK);
		return FALSE;
	}
	if(!m_pNodeList->IfCurrentParallel()){//��������������Ƿ���
		MessageBox("�����·���Ƿ��е���������!","��·������ʾ",MB_ICONQUESTION|MB_OK);
		return FALSE;
	}
	if(!m_pNodeList->IfVoltageSeries()){//����ѹ���Ƿ���
		MessageBox("�����·���Ƿ��е�ѹ������!","��·������ʾ",MB_ICONQUESTION|MB_OK);
		return FALSE;
	}
	//if(!m_pNodeList->IsClose())//����·�Ƿ�պ�
	//MessageBox("�����·�Ƿ�պ�!","��·������ʾ",MB_ICONQUESTION|MB_OK);
	//	return FALSE;
	return TRUE;
}

void CPointtestView::OnUpdateDian(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_DIAN?1:0);
}

void CPointtestView::OnUpdateDi(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_DI?1:0);
}

void CPointtestView::OnUpdateDeng(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_DENG?1:0);
}

void CPointtestView::OnUpdateDddz(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_DDDZ?1:0);
}

void CPointtestView::OnUpdateCap(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_CAP?1:0);
}

void CPointtestView::OnUpdateDianzu(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_DIANZU?1:0);
}

void CPointtestView::OnUpdateDianyuan(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_DIANYUAN?1:0);
}

void CPointtestView::OnUpdateDianyabiao(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_DIANYABIAO?1:0);
}

void CPointtestView::OnUpdateDianliubiao(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_DIANLIUBIAO?1:0);
}

void CPointtestView::OnUpdateDiangan(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_DIANGAN?1:0);
}

void CPointtestView::OnUpdateErjiguan(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_ERJIGUAN?1:0);
}

void CPointtestView::OnUpdateSelectone(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_SELECTONE?1:0);
}

void CPointtestView::OnUpdateTexta(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_TEXTA?1:0);
}
void CPointtestView::OnUpdateKetiaodianzu(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(id_Check == ID_KETIAODIANZU?1:0);
	
}
void CPointtestView::Close()
{
	if( m_pBaseTool )
	{
		delete m_pBaseTool;
		m_pBaseTool = NULL;
	}
	if( m_pNodeList ){
		delete m_pNodeList;
		m_pNodeList = NULL;
	}		
}

