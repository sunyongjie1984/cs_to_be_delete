// Text.cpp: implementation of the CText class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "Text.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CText::CText(int nType,CBaseList* pBaseList) : CBase(ID_TEXT,pBaseList)
{
	Content_Of_Ob = "";
	m_bMoving = FALSE;
}
CText::CText(CBaseList* pBaseList) : CBase(ID_TEXT,pBaseList)
{
	Content_Of_Ob = "";
	m_bMoving = FALSE;
}
CText::~CText()
{

}
int CText::PtInOb(CPoint point)
{
	BOOL result = FALSE;
	if(Size_Of_Ob.PtInRect(point)){
		m_bMoving = FALSE;
		result = TRUE;
	}
	return result;
}
void CText::OffSet(CSize size)
{
	Size_Of_Ob.OffsetRect(size);
}
void CText::Draw(CDC* pDC)//draw through pdc
{
	int a,b,c,d,mode;
	COLORREF oldcolor;
//	Count_Size(pDC,Content_Of_Text);
	a = Size_Of_Ob.Width()+50;
	b = Size_Of_Ob.Height()+20;
	c = Size_Of_Ob.left;
	d = Size_Of_Ob.top;
	if(m_iSelected){
		if(m_bMoving){
			oldcolor = pDC->SetTextColor(RGB(0,0,0));
		}else{
			pDC->PatBlt(c,d,a,b,DSTINVERT);
			oldcolor = pDC->SetTextColor(RGB(255,255,255));
		}
	}else{
		oldcolor = pDC->SetTextColor(RGB(0,0,0));
	}
	/*****do what you want*****/
	mode = pDC->SetBkMode(TRANSPARENT);
	Draw_Text(pDC,Content_Of_Ob,c,d);
	pDC->SetBkMode(mode);
	pDC->SetTextColor(oldcolor);
}
void CText::TextMyOut1(CDC* pDC,int xx,int yy,CString string)
{
	LOGFONT logFont;
    logFont.lfHeight = 35;//31����
    logFont.lfWidth = 7;
    logFont.lfEscapement = 0;
    logFont.lfOrientation = 0;
    logFont.lfWeight = FW_NORMAL;//FW_DEMIBOLD;//
    logFont.lfItalic = 0;
    logFont.lfUnderline = 0;
    logFont.lfStrikeOut = 0;
    logFont.lfCharSet = ANSI_CHARSET;
    logFont.lfOutPrecision = OUT_DEFAULT_PRECIS;
    logFont.lfClipPrecision = CLIP_DEFAULT_PRECIS;
    logFont.lfQuality = PROOF_QUALITY;
    logFont.lfPitchAndFamily = VARIABLE_PITCH | FF_ROMAN;
	strcpy(logFont.lfFaceName, "����_GB2312");

	CFont font;
	font.CreateFontIndirect(&logFont);
	CFont* oldFont = pDC->SelectObject(&font);
	pDC->TextOut(xx,yy,string);
	pDC->SelectObject(oldFont);
}
void CText::Draw_Text(CDC* MemDC,CString text,int a ,int b)
{
	CString tempString;
	CString string;
	CString findstring("\n" );
	CRect aa = Size_Of_Ob;
	int hang = 0,j = 0,line = 0,lie = 0;
	string = text;
	if(!string.IsEmpty()){
		line = string.GetLength();
		j = string.Find( findstring,0 );
		while(j != -1){
			hang = j;
			tempString = string.Left( j-1 );
			string = string.Right( line-j-1 );
			line = line-j-1;
			j = string.Find( findstring );
			if(hang<j) hang = j;
			TextMyOut1(MemDC, a,lie*17+b,tempString);
			lie++;
		}
		if((j == -1)&&(hang != 0))
			TextMyOut1(MemDC,a,lie*17+b,string);
		else if((j == -1)&&(hang == 0))
			TextMyOut1(MemDC,a,b,string);
		//Size_Of_Text = CRect(aa.left,aa.top,aa.left+hang*10,aa.top+lie*15);
	}
}

