// LineTool.h: interface for the CRTool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINETOOL_H__37927A1B_613E_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_LINETOOL_H__37927A1B_613E_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseTool.h"
#include "Eline.h"
#include "Epoint.h"
#include "base.h"
//class CElist;

class CRTool : public CBaseTool  
{
public:
	CRTool(CWnd* cWnd,CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	CRTool(CElist* pList,CPointList* pOintList,CLineList* pLineList,CTextList* pText);
	virtual ~CRTool();
public:	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
	void AddObject(CPoint point);
public:
	//CResis* m_pResis;
	CBase* p1,*p2;
};

#endif // !defined(AFX_LINETOOL_H__37927A1B_613E_11D4_BBD7_600000000ECD__INCLUDED_)
