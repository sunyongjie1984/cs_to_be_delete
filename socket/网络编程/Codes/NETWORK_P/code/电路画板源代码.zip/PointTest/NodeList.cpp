// NodeList.cpp: implementation of the CNodeList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "NodeList.h"
#include "line.h"
#include "epoint.h"
#include "edot.h"
#include "element.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CNodeList::CNodeList(CElist* pList , CPointList* pOintList,CLineList* pLineList)
{
	m_pList = pList;
	m_PointList = pOintList;
	m_pLineList = pLineList;
	m_base = ID_DEFAULTBASE;
	m_pJointList = NULL;
	pCal = NULL;
}

CNodeList::~CNodeList()
{
	if(m_pJointList) delete m_pJointList;
	if(pCal) delete pCal;
}
void CNodeList::CreateBaseChain()//create the base chain
{
	CLine* aa;
	CBase* bb;
	POSITION pos = m_pLineList->GetHeadPosition();
    while(pos!=NULL)
	{
	    aa = (CLine *)m_pLineList->GetNext(pos);
		if(aa){
			node = new CMyNode(aa->parent1,aa->parent2);
			AddTail(node);
		}
   	}
	pos = m_pList->GetHeadPosition();
	while(pos!=NULL){
		bb = (CBase*)m_pList->GetNext(pos);
		if(bb->GetType() == ID_DOT){
			node = new CMyNode(bb->p1,bb->p2,bb->p3,bb->p4);
			AddTail(node);
		}//else if(bb->GetType() == ID_SWITCH){
		//	node = new CMyNode(bb->p1,bb->p2);
		//	AddTail(node);
		//}
	}
	UniteNode();
	ConstructSystem();
}
void CNodeList::UniteNode()//�ѽڵ�ϲ�
{
	CMyNode* OldOb,*NewOb;
	POSITION OutPos,InPos,PrePos;
	OutPos = GetHeadPosition();
    while(OutPos!=NULL){
		PrePos = OutPos;
		OldOb = (CMyNode*)GetNext(OutPos);
		InPos = OutPos;
		while(InPos!=NULL){
			NewOb = (CMyNode *)GetNext(InPos);
			if(OldOb->IfHaveSamePoint(NewOb)){
				OldOb->AddPoint(NewOb);//Move the ball to this block
				RemoveAt(PrePos);//remove Old block
				break;
			}
		}
   	}
}
void CNodeList::ConstructSystem()//����Ԫ����
{
	CMyNode* aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CMyNode*)GetNext(Pos);
		aa->ArrangeElement();
	}
}
void CNodeList::ClearAll()
{
	CMyNode* aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CMyNode*)GetNext(Pos);
		if(aa)
			delete aa;
	}
	m_base = ID_DEFAULTBASE;
	CPtrList::RemoveAll();
}
CString CNodeList::GetListString()
{
	CString content;
	char recent[20];
	int i = 1,j;
	CMyNode* aa;
	POSITION pos = GetHeadPosition();
	while(pos!=NULL)
	{
	    aa = (CMyNode *)GetNext(pos);
		j = aa->GetMyCount();
		sprintf(recent,"%d,%d,",i,j);
		content+=recent;
		i++;
   	}
	return content;
}
//if the circuit is closed
BOOL CNodeList::IsClose()
{
/*	CMyNode* aa;
	POSITION Pos = GetHeadPosition();
	if(Pos!=NULL){
		aa = (CMyNode*)GetNext(Pos);
		//
	}*/
	return FALSE;
}
CMyNode* CNodeList::GetNode(CBase* point,CMyNode* old)
{
	CMyNode* aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CMyNode*)GetNext(Pos);
		if(aa!=old&&aa->PointInNode(point))
			return aa;
	}
	return NULL;
}
BOOL CNodeList::IfHavePower()
{
	CMyNode* aa;
	BOOL result = FALSE;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CMyNode*)GetNext(Pos);
			if(aa->IfHavePower())
				result =  TRUE;
	}
	return result;
}
void CNodeList::AddElementToSerial()
{
	CMyNode* aa;
	POSITION Pos = GetHeadPosition();
	ClearSerial();
	Texis();
	while(Pos!=NULL){
		aa = (CMyNode*)GetNext(Pos);
		aa->AddElementToSerial(&m_Serial);
	}
	AsignNodeToElement();
}
void CNodeList::AsignNodeToElement()
{
	CBase * aa;
	m_pList->ClearAllNode();
	POSITION Pos = m_Serial.GetHeadPosition();
	while(Pos!=NULL){
		aa = (CBase*)m_Serial.GetNext(Pos);
		if(FindNode(aa->p1) != ID_NONODE)
			aa->Node1 = FindNode(aa->p1);
		if(FindNode(aa->p2) != ID_NONODE)
			aa->Node2 = FindNode(aa->p2);
	}
}
BOOL CNodeList::IfCurrentParallel()//judge if the amperemeter parallel connection
{
	CBase *OldCurrent,*NewCurrent;
	POSITION OutPos,InPos,PrePos;
	OutPos = m_Serial.GetHeadPosition();
	while(OutPos!=NULL){
		PrePos = OutPos;
		OldCurrent = (CBase*)m_Serial.GetNext(OutPos);
		InPos = OutPos;
		if(OldCurrent->GetType() == ID_CURRENT_METER){
			while(InPos!=NULL){
				NewCurrent = (CBase *)m_Serial.GetNext(InPos);
				if(NewCurrent->GetType() == ID_CURRENT_METER){
					if((OldCurrent->Node1 == NewCurrent->Node1)
						&&(OldCurrent->Node2 == NewCurrent->Node2)){
						return FALSE;
					}
					else if((OldCurrent->Node1 == NewCurrent->Node2)
						&&(OldCurrent->Node2 == NewCurrent->Node1)){
						return FALSE;
					}
				}
			}
		}
	}
	return TRUE;
}
BOOL CNodeList::IfVoltageSeries()//judge if the voltmeter in series
{
	CBase *OldCurrent,*NewCurrent;
	POSITION OutPos,InPos,PrePos;
	OutPos = m_Serial.GetHeadPosition();
	while(OutPos!=NULL){
		PrePos = OutPos;
		OldCurrent = (CBase*)m_Serial.GetNext(OutPos);
		InPos = OutPos;
		if(OldCurrent->GetType() == ID_VOLTAGE_METER){
			while(InPos!=NULL){
				NewCurrent = (CBase *)m_Serial.GetNext(InPos);
				if(NewCurrent->GetType() == ID_VOLTAGE_METER){
					if(((OldCurrent->Node1 == NewCurrent->Node1)
						&&(OldCurrent->Node2 != NewCurrent->Node2))||
						((OldCurrent->Node1 == NewCurrent->Node2)
						&&(OldCurrent->Node2 != NewCurrent->Node1))||
						((OldCurrent->Node2 == NewCurrent->Node1)
						&&(OldCurrent->Node1 != NewCurrent->Node2))||
						((OldCurrent->Node2 == NewCurrent->Node2)
						&&(OldCurrent->Node1 != NewCurrent->Node1))){
						return FALSE;
					}
				}
			}
		}
	}
	return TRUE;
}
int CNodeList::FindNode(CBase* befind)//���ҽڵ�
{
	CMyNode *aa;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CMyNode *)GetNext(Pos);
		if(aa->m_pPointInNode.Find(befind))
			return aa->Number;
	}
	return ID_NONODE;
}
void CNodeList::Texis()//���ڵ���
{
	CMyNode *aa;
	int num = 0;
	POSITION Pos = GetHeadPosition();
	while(Pos!=NULL){
		aa = (CMyNode*)GetNext(Pos);
		aa->Number = num;
		num++;
	}
}
void CNodeList::GiveYouData()//��������
{
	CBase* aa;
	CAElement *p;
	if( m_pJointList ) 
	{
		delete m_pJointList;
		m_pJointList = NULL;
	}
	m_pJointList = new CJointList();//aotian change
	int index = 1;
	POSITION Pos = m_Serial.GetHeadPosition();
	while(Pos!=NULL){
		aa = (CBase*)m_Serial.GetNext(Pos);
		if(aa->GetType() == ID_SWITCH){
			p=m_pJointList->NewSwitch(aa->m_bSwitch);
		}else{
			p=m_pJointList->NewElement(aa->m_ElementType,aa->Value);
			if( aa->m_ElementType == ID_CURRENT_METER )
			{
				CAElement* pA = m_pJointList->NewElement(aa->m_ElementType,aa->Value);
				pA->SetOrderStruct(aa->Node1,aa->Node2);
				pA->SetIndex( index );
				m_pJointList->m_AmperList.AddTail( pA );
			}
			if( aa->m_ElementType == ID_VOLTAGE_METER )
			{
				CAElement* pV = m_pJointList->NewElement(aa->m_ElementType,aa->Value);
				pV->SetOrderStruct(aa->Node1,aa->Node2);
				pV->SetIndex( index );
				m_pJointList->m_VoltList.AddTail( pV );
			}
		}

		p->SetIndex( index );
		index ++;
		m_pJointList->AddJoint(m_pJointList->m_pOldList,aa->Node1);
		m_pJointList->AddJoint(m_pJointList->m_pOldList,aa->Node2);
		p->SetStructJoint(m_pJointList->GetJoint(aa->Node1,m_pJointList->m_pOldList),m_pJointList->GetJoint(aa->Node2,m_pJointList->m_pOldList));
		p->SetOrderStruct(aa->Node1,aa->Node2);
		((m_pJointList->GetJoint(aa->Node1,m_pJointList->m_pOldList))->pElementList).AddElement(p);
		((m_pJointList->GetJoint(aa->Node2,m_pJointList->m_pOldList))->pElementList).AddElement(p);
	}
}
void CNodeList::OutPut(CDC* pDC)//���
{
	char a[256];
	CString str;
	GiveYouData();
	if(pCal){
		delete pCal;
		pCal = NULL;
	}
	pCal = new CCalculate(m_pJointList);//aotian change
	pCal->RealCalculate();
	POSITION pos = m_pJointList->m_VoltList.GetHeadPosition();
	while( pos != NULL )
	{
		CAElement* pE = m_pJointList->m_VoltList.GetNext( pos );
		sprintf(a,"%f\n",pE->GetVoltage());
		str += a;
		str += ",";
	}
	pos = m_pJointList->m_AmperList.GetHeadPosition();
	while( pos != NULL )
	{
		CAElement* pE= m_pJointList->m_AmperList.GetNext( pos );
		sprintf(a,"%f\n",pE->GetCurrent());
		str += a;
		str += ",";
	}
	pDC->TextOut(10,30,str);
}
BOOL CNodeList::IfCellClosed()//��·
{
	if(m_Serial.IfCellClosed())
		return FALSE;
	return TRUE;
}
BOOL CNodeList::IfAllPortHaveLine()//����
{
	if(m_Serial.IfAllPortHaveLine())
		return TRUE;
	return FALSE;
}
void CNodeList::ClearSerial()
{
	m_Serial.RemoveAll();
}
