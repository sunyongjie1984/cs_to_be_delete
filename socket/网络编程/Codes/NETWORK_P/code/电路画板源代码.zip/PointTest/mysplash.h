#if !defined(AFX_MYSPLASH_H__4F90C3E4_1CB6_11D4_825F_600000000ECD__INCLUDED_)
#define AFX_MYSPLASH_H__4F90C3E4_1CB6_11D4_825F_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// mysplash.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// mysplash window

class mysplash : public CWnd
{
// Construction
public:
	mysplash();

// Attributes
public:
	BOOL Create(CWnd * pParentWnd=NULL);
	HANDLE hBitsSrc;
	LPSTR pBitsSrc;
	UINT iW,iH;
	CBitmap hBitmap;
	BOOL Lbutton;
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(mysplash)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~mysplash();

	// Generated message map functions
protected:
	//{{AFX_MSG(mysplash)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	//CBitmap hBitmap;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSPLASH_H__4F90C3E4_1CB6_11D4_825F_600000000ECD__INCLUDED_)
