// Component.cpp: implementation of the CComponent class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "Component.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CAPower::CAPower(float p):CAElement(ID_POWER,p)
{
	m_fPower=p;
	m_bIsClose = true;
}

CAPower::~CAPower()
{

}
float CAPower::GetCurrent()
{
	return m_fCurrent;
}
IntList* CAPower::GetCapacityOrderList(CAJoint *pJoint)
{
	return NULL;
}
/////////////////////////

CAResistance::CAResistance(float r):CAElement(ID_RESISTANCE,r)
{
	m_fResistance=r;
	m_bIsClose = true;
}

CAResistance::~CAResistance()
{
	
}
float CAResistance::GetCurrent()
{
	return m_fCurrent;
}
IntList* CAResistance::GetCapacityOrderList(CAJoint *pJoint)
{
	return NULL;
}
/////////////////////////

CACapacity::CACapacity(float c):CAElement(ID_CAPACITANCE,c)
{
	m_fCapacity=c;
	m_pOrderList1=&m_nOrderList1;
	m_pOrderList2=&m_nOrderList2;
	m_bIsClose = true;
}

CACapacity::~CACapacity()
{

}
float CACapacity::GetCurrent()
{
	return m_fCurrent;
}
IntList* CACapacity::GetCapacityOrderList(CAJoint *pJoint)
{
	if(pJoint==GetJointStruct()->pJoint1)
	{
		return m_pOrderList1;
	}
	else
	{
		return m_pOrderList2;
	}
}
//////////////////////////

CAInductor::CAInductor(float i):CAElement(ID_INDUCTANCE,i)
{
	m_fInductivity=i;
	m_bIsClose = true;
}

CAInductor::~CAInductor()
{

}
float CAInductor::GetCurrent()
{
	return m_fCurrent;
}
IntList* CAInductor::GetCapacityOrderList(CAJoint *pJoint)
{
	return NULL;
}
/////////////////////////

CASwitch::CASwitch(BOOL bIsClose):CAElement(ID_SWITCH,0)
{
	m_bIsClose = bIsClose;
}

CASwitch::~CASwitch()
{

}
float CASwitch::GetCurrent()
{
	return m_fCurrent;
}
IntList* CASwitch::GetCapacityOrderList(CAJoint *pJoint)
{
	return NULL;
}

////////////////////////
CADiode::CADiode():CAElement(ID_DIODE,0)
{
	m_bIsClose = true;
}
CADiode::~CADiode()
{

}
float CADiode::GetCurrent()
{
	return m_fCurrent;
}
IntList* CADiode::GetCapacityOrderList(CAJoint *pJoint)
{
	return NULL;
}
//////////////////////////
CAAmpermeter::CAAmpermeter():CAElement(ID_CURRENT_METER,0)
{

}
CAAmpermeter::~CAAmpermeter()
{
	
}
float CAAmpermeter::GetCurrent()
{
	return m_fCurrent;
}
IntList* CAAmpermeter::GetCapacityOrderList(CAJoint* pJoint)
{
	return NULL;
}
/////////////////////////
CAVoltmeter::CAVoltmeter():CAElement(ID_VOLTAGE_METER,0)
{

}
CAVoltmeter::~CAVoltmeter()
{

}
float CAVoltmeter::GetCurrent()
{
	return m_fCurrent;
}
IntList* CAVoltmeter::GetCapacityOrderList(CAJoint* pJoint)
{
	return NULL;
}
