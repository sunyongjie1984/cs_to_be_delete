// BaseList.h: interface for the CABaseList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BASELIST_H__6FF25B77_598A_11D4_AFFB_00E04C6749D0__INCLUDED_)
#define AFX_BASELIST_H__6FF25B77_598A_11D4_AFFB_00E04C6749D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CABaseList  
{
public:
	CABaseList();
	virtual ~CABaseList();

};

#endif // !defined(AFX_BASELIST_H__6FF25B77_598A_11D4_AFFB_00E04C6749D0__INCLUDED_)
