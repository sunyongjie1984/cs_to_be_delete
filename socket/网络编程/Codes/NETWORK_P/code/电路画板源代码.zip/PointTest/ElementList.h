// ElementList.h: interface for the CElementList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ELEMENTLIST_H__6FF25B78_598A_11D4_AFFB_00E04C6749D0__INCLUDED_)
#define AFX_ELEMENTLIST_H__6FF25B78_598A_11D4_AFFB_00E04C6749D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "aBaseList.h"
#include "afxtempl.h"
#include "Element.h"

class CElementList : public CABaseList  
{
public:
	CList<CAElement*,CAElement*>m_pListElement;
public:
	void AddElement(CAElement *p);
	void RemoveElement(CAElement *p);
//	void AllElToOther(int type1,int type2,float value);
//	void OneElToOther(CAElement *pE,int type,float value);
public:
	CElementList();
	virtual ~CElementList();

};

#endif // !defined(AFX_ELEMENTLIST_H__6FF25B78_598A_11D4_AFFB_00E04C6749D0__INCLUDED_)
