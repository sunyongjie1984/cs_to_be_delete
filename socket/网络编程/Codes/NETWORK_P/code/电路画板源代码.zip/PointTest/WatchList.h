// WatchList.h: interface for the CWatchList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WATCHLIST_H__E6456FE1_87F3_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_WATCHLIST_H__E6456FE1_87F3_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "BaseList.h"
#include "mywatch.h"
class CWatchList : public CBaseList  
{
public:
	CWatchList();
	virtual ~CWatchList();
	//void CreateWatch(CWnd* pWnd);
	void DeleteWatch(MyWatch* watch);
};

#endif // !defined(AFX_WATCHLIST_H__E6456FE1_87F3_11D4_BBD7_600000000ECD__INCLUDED_)
