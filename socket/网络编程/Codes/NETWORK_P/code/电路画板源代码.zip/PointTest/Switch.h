// Switch.h: interface for the CSwitch class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SWITCH_H__AFC29FE2_67BB_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_SWITCH_H__AFC29FE2_67BB_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Base.h"

class CSwitch : public CBase  
{
public:
	CSwitch(int nType,CBaseList* pBaseList);
	CSwitch(CBase* pp1,CBase* pp2,CBaseList* pBaseList);
	virtual ~CSwitch();
public:
	void Draw(CDC* pDC);
	void OffSet(CSize size);
	CRect GetGraphRect();
	void SetPoint(CPoint pp);
	void RotateCell(double angle);
public:
	CPoint aa;
};

#endif // !defined(AFX_SWITCH_H__AFC29FE2_67BB_11D4_BBD7_600000000ECD__INCLUDED_)
