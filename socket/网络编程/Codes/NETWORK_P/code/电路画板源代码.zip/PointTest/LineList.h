// LineList.h: interface for the CLineList class.
//
//////////////////////////////////////////////////////////////////////
#include "line.h"
#include "baselist.h"
#if !defined(AFX_LINELIST_H__07575942_639C_11D4_BBD7_600000000ECD__INCLUDED_)
#define AFX_LINELIST_H__07575942_639C_11D4_BBD7_600000000ECD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLineList : public CBaseList  
{
public:
	CLineList();
	virtual ~CLineList();
public:
	void		Draw(CDC* pDC);
	void Serialize(CArchive& ar);
//	BOOL IfCellClosed();
};

#endif // !defined(AFX_LINELIST_H__07575942_639C_11D4_BBD7_600000000ECD__INCLUDED_)
