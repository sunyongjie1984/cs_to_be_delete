// Element.cpp: implementation of the CAElement class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "pointtest.h"
#include "Element.h"
#include "Joint.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAElement::CAElement(int type,float v)
{
	m_nType=type;
	m_fValue=v;
	m_fVoltage = 0;
	m_fCurrent = 0;

	m_bIsAsPower=false;
	m_bIsWorked=false;
	m_bIsAsInductor = false;
	m_bIsAsCapacity = false;
	m_bIsParel = false;
	pRemove=NULL;
	pNoRemove=NULL;
}

CAElement::~CAElement()
{

}
void CAElement::SetIndex(int index)
{
	m_nIndex = index;
}
int CAElement::GetIndex()
{
	return m_nIndex;
}
Joints* CAElement::GetJointStruct()
{
	return &m_structJoint;
}
int CAElement::GetType()
{
	return m_nType;
}
void CAElement::SetType(int type)
{
	m_nType=type;
}
void CAElement::SetStructJoint(CAJoint *p1,CAJoint *p2)
{
	//if((p1->GetOrder())<(p2->GetOrder()))
	//{
		m_structJoint.pJoint1=p1;
		m_structJoint.pJoint2=p2;
//	}
//	else 
//	{
//		m_structJoint.pJoint1=p2;
//		m_structJoint.pJoint2=p1;
//	}
}
void CAElement::SetOrderStruct(int order1,int order2)
{
	m_structOrder.order1 = order1;
	m_structOrder.order2 = order2;
}
Orders* CAElement::GetOrderStruct()
{
	return &m_structOrder;
}
float CAElement::GetValue()
{
	return m_fValue;
}
void CAElement::SetValue(float v)
{
	m_fValue=v;
}
float CAElement::GetVoltage()
{
/*	float v1,v2;
	v1=m_structJoint.pJoint1->GetVoltage();
	v2=m_structJoint.pJoint2->GetVoltage();
	if(v1>v2)
	{
		m_fVoltage=v1-v2;
	}
	else
	{
		m_fVoltage=v2-v1;
	}*/
	return m_fVoltage;
}
void CAElement::SetVoltage(float v)
{
	m_fVoltage = v;
}
void CAElement::SetCurrent(float i)
{
	m_fCurrent = i;
}
float CAElement::GetCurrent()
{
	return m_fCurrent;
}
BOOL CAElement::IsAsPower()
{
	return m_bIsAsPower;
}
void CAElement::SetIsAsPower(BOOL b)
{
	m_bIsAsPower=b;
}
void CAElement::SetWorked(BOOL b)
{
	m_bIsWorked=b;
}
BOOL CAElement::IsWorked()
{
	return m_bIsWorked;
}
IntList* CAElement::GetCapacityOrderList(CAJoint *pJoint)
{
	return NULL;
}
BOOL CAElement::IsClose()
{
	return m_bIsClose;
}
void CAElement::SetIsAsCapacity(BOOL b)
{
	m_bIsAsCapacity = b;
}
void CAElement::SetIsAsInductor(BOOL b)
{
	m_bIsAsInductor = b;
}
BOOL CAElement::IsAsCapacity()
{
	return m_bIsAsCapacity;
}
BOOL CAElement::IsAsInductor()
{
	return m_bIsAsInductor;
}
void CAElement::SetIsParel( BOOL b)
{
	m_bIsParel = b;
}
BOOL CAElement::IsSetParel()
{
	return m_bIsParel;
}
BOOL CAElement::IsTheP1Joint( CAJoint* pJoint)
{
	int order = pJoint->GetOrder();
	int order1 = m_structOrder.order1;
	int order2 = m_structOrder.order2;
	if( order == order1 )
	{
		return true;
	}
	else
	{
		return false;
	}
}