// Base.cpp: implementation of the CBase class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "Base.h"
#include "baselist.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
extern int RisisNumber; //����
extern int PowerNumber; //��Դ
extern int CapNumber;   //����
extern int DiodeNumber; //������
extern int InduNumber;  //���
extern int LightNumber; //����
extern int GroundNumber;//�ӵ�
extern int CurrentNumber;//������
extern int VoltageNumber;//��ѹ��
extern int SwitchNumber; //����
extern int RheostatNumber;//������
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBase::CBase(int nType,CBaseList* pBaseList)
{
	m_ElementType = nType;
	m_iSelected = FALSE;
	CenterPoint = CPoint(0,0);
	OwnerCenter = CPoint(0,0);
	WhereIAm = pBaseList;
	TotalAngle = 0;
	pBaseList->AddTail(this);
	number = 0;
	Size_Of_Ob = CRect(0,0,0,0);
	m_bSwitch = FALSE;
	Node1 = Node2 = NODEFINE;
	MeterValue = 0;
}
CBase::CBase(int nType)
{
	m_ElementType = nType;
	m_iSelected = FALSE;
	CenterPoint = CPoint(0,0);
	TotalAngle = 0;
	number = 0;
	Size_Of_Ob = CRect(0,0,0,0);
	m_bSwitch = FALSE;
	Node1 = Node2 = NODEFINE;
	MeterValue = 0;
}
CBase::~CBase()
{

}
int CBase::IsSelected()
{
	return m_iSelected;
}
void CBase::Select()
{
	m_iSelected = TRUE;
}
void CBase::DeSelect()
{
	m_iSelected = FALSE;
}
BOOL CBase::GraphInRect( CRect lpRect )
{
	if( !lpRect )	return FALSE;

	CRect graphRect, interRect;

	 graphRect = GetGraphRect();	

	interRect.IntersectRect( &lpRect, &graphRect );

	return (!interRect.IsRectEmpty());
}
int CBase::GetType()
{
	return m_ElementType;
}

CRect CBase::GetGraphRect()
{
	return Size_Of_Ob;
}
CString CBase::GetGraphString()
{
	return Content_Of_Ob;
}
void CBase::SetData(CString &aa,CRect &bb)
{
	aa = Content_Of_Ob;
	bb = Size_Of_Ob;
}
void CBase::GetData(CString aa,CRect bb)
{
	Content_Of_Ob = aa;
	Size_Of_Ob = bb;
}

void CBase::AddSon(CBase* Element)
{
	SonList.AddTail(Element);
}
void CBase::Delete()
{
		POSITION pos = SonList.GetHeadPosition();
		while( NULL != pos )
		{
			CBase* pBase = SonList.GetNext( pos );
			pBase->Delete();
		}

		// Notify parent
		this->Notify();

		// Notify list
		WhereIAm->Notify(this);
		ReduceCount(m_ElementType);
		delete this;

}
BOOL CBase::PtInOb(CPoint point)
{
	BOOL result = FALSE;
	CRect mRect;
	mRect = GetGraphRect();
	if(mRect.PtInRect(point))
		result = TRUE;
	return result;
}
double CBase::ConvertAngle(int a)
{
	double rValue;
	rValue = a*PI/180;
	return rValue;
}
CPoint CBase::Rotate(double a,CPoint rotate)
{
	CPoint pp;
	int t1,t2;
	double b,l,d1,d2;
	t1 = rotate.x - CenterPoint.x;
	t2 = CenterPoint.y - rotate.y;
	l = sqrt(t1*t1+t2*t2);
	b = atan2(t2,t1);
	d1 = l*sin(a+b);
	d2 = l*cos(a+b);

	d1 = round(d1);
	d2 = round(d2);
	pp.y = (long)(CenterPoint.y-d1);
	pp.x = (long)(d2+CenterPoint.x);
	return pp;
}
int CBase::round(double aa)//��������
{
	double bb;
	int result;
	bb = aa - (int)aa;
	if(bb>0){
		if((1 - bb)>bb){
			result = (int)aa;
			return result;
		}else{
			result = (int)aa+1;
			return result;
		}
	}else if(bb<0){
		if((1+bb)>-bb){
			result = (int)aa;
			return result;
		}else{
			result = (int)aa-1;
			return result;
		}
	}else{
		return (int)aa;
	}
}
CRect CBase::GetRect(CPoint pp,CSize bb)
{
	CRect rect(-(bb.cx)/2,-(bb.cy)/2,(bb.cx)/2,(bb.cy)/2);
	rect.OffsetRect(pp);
	return rect;
}
void CBase::DrawSign(CDC* pDC,CPoint cen,int Length)
{
	CPoint fuhao[3],zhenghao[5];
	fuhao[0] = cen;
	zhenghao[0] = cen;
	fuhao[0].Offset(CSize(-Length,0));
	zhenghao[0].Offset(CSize(Length,0));
	fuhao[1] = fuhao[2] = fuhao[0];
	zhenghao[1] = zhenghao[2] = zhenghao[3] = zhenghao[4] = zhenghao[0];
	fuhao[1].Offset(CSize(-5,0));
	fuhao[2].Offset(CSize(5,0));
	zhenghao[1].Offset(CSize(-5,0));
	zhenghao[2].Offset(CSize(5,0));
	zhenghao[3].Offset(CSize(0,5));
	zhenghao[4].Offset(CSize(0,-5));
	for(int i=1;i<5;i++){
		if(i<3){
			pDC->MoveTo(fuhao[0]);
			pDC->LineTo(fuhao[i]);
		}
		pDC->MoveTo(zhenghao[0]);
		pDC->LineTo(zhenghao[i]);
	}
}
BOOL CBase::IfHaveSon()//�Ƿ�����
{
	if(SonList.IsEmpty())
		return FALSE;
	return TRUE;
}
void CBase::TextOut(CDC* pDC)
{
	TextPoint = GetTextRect(pDC);
	pDC->SetBkMode(TRANSPARENT);
	pDC->TextOut(TextPoint.x,TextPoint.y,Content_Of_Ob);	
}
CPoint CBase::GetTextRect(CDC* pDC)
{
	CPoint point = CenterPoint;
	CSize size;
	size = pDC->GetTextExtent(Content_Of_Ob);
	point.x = CenterPoint.x - size.cx/2;
	int angle = round(TotalAngle*180/PI);
	int a = angle%180;
	if(a)
		point.y = CenterPoint.y - 27 - size.cy;
	else
		point.y = CenterPoint.y - 16 - size.cy;
	return point;
}
void CBase::ReduceCount(UINT id)
{
	switch(id){
	case ID_RESISTANCE:
		RisisNumber--;
		break;
	case ID_POWER:
		PowerNumber--;
		break;
	case ID_CAPACITANCE:
		CapNumber--;
		break;
	case ID_DIODE:
		DiodeNumber--;
		break;
	case ID_SWITCH:
		SwitchNumber--;
		break;
	case ID_LIGHT:
		LightNumber--; 
		break;
	case ID_VOLTAGE_METER:
		VoltageNumber--;
		break;
	case ID_CURRENT_METER:
		CurrentNumber--;
		break;
	case ID_INDUCTANCE:
		InduNumber--;
		break;
	case ID_GROUND:
		GroundNumber--;
		break;
	case ID_RHEOSTAT:
		RheostatNumber--;
		break;
	}
}
void CBase::AddString(UINT id)
{
	int number;
	switch(id){
	case ID_RESISTANCE:
		RisisNumber++;
		number = RisisNumber;
		break;
	case ID_POWER:
		PowerNumber++;
		number = PowerNumber;
		break;
	case ID_CAPACITANCE:
		CapNumber++;
		number = CapNumber;
		break;
	case ID_DIODE:
		DiodeNumber++;
		number = DiodeNumber;
		break;
	case ID_SWITCH:
		SwitchNumber++;
		number = SwitchNumber;
		break;
	case ID_LIGHT:
		LightNumber++; 
		number = LightNumber;
		break;
	case ID_VOLTAGE_METER:
		VoltageNumber++;
		number = VoltageNumber;
		break;
	case ID_CURRENT_METER:
		CurrentNumber++;
		number = CurrentNumber;
		break;
	case ID_INDUCTANCE:
		InduNumber++;
		number = InduNumber;
		break;
	case ID_GROUND:
		GroundNumber++;
		number = GroundNumber;
		break;
	case ID_RHEOSTAT:
		RheostatNumber++;
		number = RheostatNumber;
		break;
	}	
	sprintf(SerialNumber,"%d",number);
	Content_Of_Ob+=SerialNumber;
}
void CBase::SetPoinT(CPoint pp)
{
	CSize size;
	size = pp-CenterPoint;
	OffSet(size);
}