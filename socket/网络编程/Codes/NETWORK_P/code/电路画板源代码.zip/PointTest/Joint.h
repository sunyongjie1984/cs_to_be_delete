// Joint.h: interface for the CAJoint class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JOINT_H__6FF25B76_598A_11D4_AFFB_00E04C6749D0__INCLUDED_)
#define AFX_JOINT_H__6FF25B76_598A_11D4_AFFB_00E04C6749D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ElementList.h"

class CAJoint  
{
protected:
	
	BOOL m_bIsSetVoltage;
	int m_nOrder;
	float m_dVoltage;
	BOOL m_bHoldElecSource;
	
public:
	CElementList pElementList;
	float m_dReciprocalOfR[10];
	float m_fVoltage[100];
	int m_nEqualValueOrder;
public:
	float m_fRealVoltage[100];
	void SetIsSetVoltage(BOOL b);
	BOOL IsSetVoltage();
	int GetOrder();
	void SearchElecSource();
	BOOL IsHoldElecSource();
	float GetVoltage();
	static float GetXXX();
	void SetVoltage(float v);
	CAJoint(int order);
	virtual ~CAJoint();

};

#endif // !defined(AFX_JOINT_H__6FF25B76_598A_11D4_AFFB_00E04C6749D0__INCLUDED_)
