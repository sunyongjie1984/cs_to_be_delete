// LineList.cpp: implementation of the CLineList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "LineList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLineList::CLineList()
{

}

CLineList::~CLineList()
{

}
void CLineList::Draw(CDC* pDC)
{
	CLine* aa;

	POSITION pos = GetHeadPosition();
	while(pos != NULL){
		aa = (CLine *)GetNext(pos);
		aa->Draw(pDC);
	}
}
void CLineList::Serialize(CArchive& ar)
{
	CLine* pp;
	if (ar.IsStoring()){
		POSITION pos = GetHeadPosition();
		ar << GetCount();
		while(pos!=NULL)
		{
			pp = (CLine*)GetNext(pos);
			if(pp){
				ar << pp->parent1->number;
				ar << pp->parent2->number;
			}
		}
	}else{
	}
}
/*BOOL CLineList::IfCellClosed()
{
	CLine* aa;

	POSITION pos = GetHeadPosition();
	while(pos != NULL){
		aa = (CLine *)GetNext(pos);
		if(aa->parent1->Parent == aa->parent2->Parent)
			return FALSE;
	}
	return TRUE;
}*/