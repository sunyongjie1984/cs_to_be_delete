// Line.cpp: implementation of the CLine class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "Line.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLine::CLine(int nType,CBaseList* pBaseList) 
		:CBase(ID_LINE,pBaseList)
{

}
CLine::CLine(CBase* p1,CBase* p2,CBaseList* pBaseList) 
		:CBase(ID_LINE,pBaseList)
{
	parent1 = p1;
	parent2 = p2;
}
CLine::~CLine()
{

}
BOOL CLine::PtInOb(CPoint point)
{
	double d,d0,c;
	int x1,y1,x2,y2;

	x1 = parent1->CenterPoint.x;
	y1 = parent1->CenterPoint.y;
	x2 = parent2->CenterPoint.x;
	y2 = parent2->CenterPoint.y;

	d0 = sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	d = abs((x2-x1)*(point.y-y1)+(y1-y2)*(point.x-x1))/d0;
	c = (point.x - x1)*(x2 - point.x)+(point.y - y1)*(y2 - point.y);
	if((d<3)&&(c>=0))
		return TRUE;
	return FALSE;
}
void CLine::Draw(CDC* pDC)
{
	if(IsSelected()){
		CPen pen(PS_SOLID, 2,RED);
		CPen *Oldpen = pDC->SelectObject(&pen);

		pDC->MoveTo(parent1->CenterPoint);
		pDC->LineTo(parent2->CenterPoint);

		pDC->SelectObject(Oldpen);
	}else{
		CPen pen(PS_SOLID, 2,BLACK);
		CPen *Oldpen = pDC->SelectObject(&pen);

		pDC->MoveTo(parent1->CenterPoint);
		pDC->LineTo(parent2->CenterPoint);

		pDC->SelectObject(Oldpen);
	}
}
void CLine::OffSet(CSize size)
{
	
}
void CLine::Notify()
{
	POSITION pos;
	pos = parent1->SonList.Find(this);
	parent1->SonList.RemoveAt(pos);
	pos = parent2->SonList.Find(this);
	parent2->SonList.RemoveAt(pos);
}
