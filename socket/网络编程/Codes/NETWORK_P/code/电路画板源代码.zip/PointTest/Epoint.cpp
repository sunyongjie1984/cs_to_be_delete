// Epoint.cpp: implementation of the CEpoint class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pointtest.h"
#include "Epoint.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CEpoint::CEpoint(CBaseList* pBaseList) : CBase(ID_POINT,pBaseList)
{
}
CEpoint::CEpoint(int nType,CBaseList* pBaseList) 
		: CBase(ID_POINT,pBaseList)
{
}

CEpoint::~CEpoint()
{

}
void CEpoint::Draw(CDC* pDC)
{
	if(IsSelected()){
		CPen pen(PS_SOLID, 1,BLACK);
		CBrush brush(BLACK);
		CBrush* Oldbrush = pDC->SelectObject(&brush);
		CPen *Oldpen = pDC->SelectObject(&pen);

		pDC->Ellipse(GetGraphRect());

		pDC->SelectObject(Oldbrush);
		pDC->SelectObject(Oldpen);
	}
}
CRect CEpoint::GetGraphRect()
{
	CPoint up_left,down_right;
	up_left = down_right = CenterPoint;
	up_left.Offset(-3,-3);
	down_right.Offset(3,3);
	return CRect(up_left,down_right);
}
void CEpoint::OffSet(CSize size)
{
	CenterPoint.Offset(size);
}
void CEpoint::SetPoint(CPoint point)
{
	CenterPoint = point;
}

