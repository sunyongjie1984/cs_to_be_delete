// FileSearch.h: interface for the CFileSearch class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILESEARCH_H__6C8F2210_A19F_11D6_98C2_C99B4152F509__INCLUDED_)
#define AFX_FILESEARCH_H__6C8F2210_A19F_11D6_98C2_C99B4152F509__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Search.h"

class CFileSearch : public CSearch  
{
public:
	CFileSearch();
	virtual ~CFileSearch();

};

#endif // !defined(AFX_FILESEARCH_H__6C8F2210_A19F_11D6_98C2_C99B4152F509__INCLUDED_)
