// Search.cpp: implementation of the CSearch class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GameProbe.h"
#include "Search.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSearch::CSearch()
{
	m_dwTickTime = 0;
}

CSearch::~CSearch()
{

}

BOOL CSearch::BeginSearch()
{

	m_dwTickTime = 0;

	CleanResult();
	if(m_SearchResult.dwTimes == 1)
	{
		m_TempFile.Create("D:\\GameProbe.tmp");
		m_TempFile.SetHeader(&m_SearchResult);
	}
	else
	{
		CSearchResult OldResult;
		m_TempFile.Open("D:\\GameProbe.tmp");
		m_TempFile.GetHeader(&OldResult);
		m_dwFirstCount = OldResult.dwCount;
	}

	m_TempFile.SeekToDataBegin();

	OnBeginSearch();
	OnProgress(0, 100, 0);
	
	return TRUE;
}

BOOL CSearch::EndSearch()
{
	CSearchResult result;
	result = m_SearchResult;

	m_TempFile.Flush();

	OnProgress(0, 100, 100);

	OnEndSearch(&result);
	
	if(result.dwTimes != 1)result.dwCount = m_dwFirstCount;

	m_SearchResult.dwTimes++;
	
	m_TempFile.SeekToHeader();
	m_TempFile.SetHeader(&result);	
	m_TempFile.Close();

	return TRUE;

}

void CSearch::OnProgress(DWORD dwMin, DWORD dwMax, DWORD dwPos)
{

}


void CSearch::OnFound(DWORD dwAddress, DWORD dwCount)
{

}

BOOL CSearch::Create(CString strTempFile)
{
	Reset();
	return TRUE;
}

void CSearch::Release()
{

}

//��һ���ڴ������������
//�ɹ�����λ��
//ʧ�ܷ���-1
int CSearch::MemFind(int iStartPosition, LPBYTE pDestBuffer, int iDestBufferLength, LPBYTE pPatternBuffer, int iPatternBufferLength)
{
	
	signed int iFoundPosition, i;
	
	iFoundPosition = -1;
	if(iStartPosition > iDestBufferLength)return -1;
	
	for(i = iStartPosition; i < (iDestBufferLength + 1); i++)
	{
        if(memcmp(&pDestBuffer[i], pPatternBuffer, iPatternBufferLength) == 0)
        {
            iFoundPosition = i;
            break;
        }
    }
	return iFoundPosition;
}

void CSearch::DoOnFound(DWORD dwAddress)
{
	m_SearchResult.dwCount++;
	OnFound(dwAddress, m_SearchResult.dwCount);
}

void CSearch::Reset()
{
	m_SearchResult.dwTimes = 1;
	CleanResult();
	m_TempFile.Close();
	m_TempFile.Delete();
}

void CSearch::CleanResult()
{
	m_SearchResult.dwCount = 0;
	m_dwFirstCount = 0;
}

void CSearch::OnEndSearch(CSearchResult *pResult)
{

}

void CSearch::OnBeginSearch()
{

}

void CSearch::ProcessProgress(DWORD dwMin, DWORD dwMax, DWORD dwPos)
{
	DWORD dwTick = ::GetTickCount();
	if(dwTick - m_dwTickTime < 100)
	{
		m_dwTickTime = dwTick;
		return;
	}

	m_dwTickTime = dwTick;

	double pos, max, percent;
	pos = (double)dwPos;
	max = (double)dwMax;
	percent = pos / max * 1000000.0;
	OnProgress(0, 1000000, (DWORD)percent);

}

const CSearchResult *CSearch::GetResult()
{
	return &m_SearchResult;
}
