// GameProbeMemSearch.h: interface for the CGameProbeMemSearch class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEPROBEMEMSEARCH_H__6E7CB820_A2C6_11D6_A9B4_8DA62ABDB674__INCLUDED_)
#define AFX_GAMEPROBEMEMSEARCH_H__6E7CB820_A2C6_11D6_A9B4_8DA62ABDB674__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MemSearch.h"
#include "ProgressDlg.h"

class CSearchFrame;

class CGameProbeMemSearch : public CMemSearch  
{
public:
	void OnProgress(DWORD dwMin, DWORD dwMax, DWORD dwPos);
	void OnEndSearch(CSearchResult *pResult);
	void OnFound(DWORD dwAddress, DWORD dwCount);
	void OnBeginSearch();
	CGameProbeMemSearch();
	virtual ~CGameProbeMemSearch();

protected:
	CProgressDlg m_wndProgressDlg;
	CSearchFrame *m_pwndParent;

};

#endif // !defined(AFX_GAMEPROBEMEMSEARCH_H__6E7CB820_A2C6_11D6_A9B4_8DA62ABDB674__INCLUDED_)
