//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GameProbe.rc
//
#define IDD_FIX_FRAME                   101
#define IDD_GAMEPROBE_DIALOG            102
#define CG_IDD_PROGRESS                 103
#define CG_IDS_PROGRESS_CAPTION         104
#define IDS_DWORD                       105
#define IDS_WORD                        106
#define IDS_BYTE                        107
#define IDS_FLOAT                       108
#define IDS_DOUBLE                      109
#define IDS_STRING                      110
#define IDS_SEARCH_TASK                 111
#define IDS_ADDRESS_TABLE               112
#define IDS_SEARCH                      113
#define IDS_NAME                        114
#define IDS_ADDRESS                     115
#define IDS_VALUE                       116
#define IDS_DATA_TYPE                   117
#define IDS_FIX_MODE                    118
#define IDS_WINDOW_TITLE                119
#define IDS_PROCESS_ID                  120
#define IDS_DEST_PROCESS                121
#define IDS_APP_NAME                    122
#define IDS_NEW                         123
#define IDS_GOTO_EDIT                   124
#define IDS_PROPRETY                    125
#define IDS_AUTO_LOCK                   126
#define IDS_HOTKEY_FIX                  127
#define IDR_MAINFRAME                   128
#define IDS_NONE                        128
#define IDD_SEARCH_FRAME                129
#define IDD_SELECT_TASK_DLG             130
#define IDD_EDIT_ITEM_DLG               131
#define IDD_TABLE_FRAME                 135
#define IDR_TABLE_FRAME_TOOLBAR         136
#define IDB_OUTBAR_TABLE                141
#define IDB_OUTBAR_SEARCH               142
#define IDR_MAIN_MENU                   143
#define IDD_HEX_EDIT_DLG                147
#define IDC_CURSOR_HAND                 149
#define IDD_OPTIONS_DLG                 151
#define IDR_TABLE_MENU                  152
#define IDC_RESULT_LIST                 1000
#define IDC_TARGET                      1002
#define IDC_SEARCH                      1003
#define CG_IDC_PROGDLG_PROGRESS         1003
#define IDC_SEARCH_START                1003
#define CG_IDC_PROGDLG_PERCENT          1004
#define IDC_TASK_LIST                   1004
#define CG_IDC_PROGDLG_STATUS           1005
#define IDC_FRESH                       1005
#define IDC_SELECT_TASK                 1006
#define IDC_LIST1                       1007
#define IDC_TABLE                       1007
#define IDC_NAME                        1008
#define IDC_ADDRESS                     1010
#define IDC_DATA_TYPE                   1011
#define IDC_FIX_TYPE                    1012
#define IDC_SEARCH_DATA_TYPE            1014
#define IDC_SEARCH_TASK_LIST            1015
#define IDC_RESET_TASK                  1017
#define IDC_RENAME_TASK                 1018
#define IDC_TIMES                       1026
#define IDC_COUNT                       1027
#define IDC_TREND_SEARCH                1039
#define IDC_BUTTON1                     1040
#define IDC_HEX_EDIT                    1043
#define IDC_GOTO_EDIT                   1044
#define IDC_PROCESS_INFO                1045
#define IDC_ADD_TASK                    1046
#define IDC_REMOVE_TASK                 1047
#define IDC_ADD_TO_TABLE                1048
#define IDC_RETURN_TO_PROCESS           1050
#define IDC_OPTIONS_DIRECT_POPUP        1052
#define IDC_OPTIONS_PAUSE_GAME          1053
#define IDC_OPTIONS_POPUP_HOTKEY        1054
#define IDC_OPTIONS_REFRESH_HOTKEY      1055
#define IDC_SEARCH_FRAME_HELP           1055
#define ID_TABLE_NEW                    32772
#define ID_MENU_SWITCH_TO_SEARCH_FRAME  32773
#define IDS_YOU_MUST_SELECT_A_PROCESS   32773
#define ID_MENU_SWITCH_TO_TABLE_FRAME   32774
#define IDS_ERROR                       32774
#define IDS_YOU_ENTERD_DATA_INVALID     32775
#define ID_MENU_OPTIONS                 32777
#define ID_MENU_GAME_BOOK               32778
#define ID_TABLE_REMOVE                 32782
#define ID_TABLE_REMOVE_ALL             32783
#define ID_TABLE_PROPRETY               32785
#define ID_BUTTON32788                  32788

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1056
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
