// SelectTaskDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GameProbe.h"
#include "SelectTaskDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSelectTaskDlg dialog


CSelectTaskDlg::CSelectTaskDlg(CWnd* pParent /*=NULL*/)
: CDialog(CSelectTaskDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSelectTaskDlg)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSelectTaskDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSelectTaskDlg)
	DDX_Control(pDX, IDC_TASK_LIST, m_wndTaskList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSelectTaskDlg, CDialog)
//{{AFX_MSG_MAP(CSelectTaskDlg)
ON_BN_CLICKED(IDC_FRESH, OnFresh)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_TASK_LIST, OnItemChangedTaskList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSelectTaskDlg message handlers


void CSelectTaskDlg::OnFresh() 
{
	// TODO: Add your control notification handler code here
		
	HWND hWnd;
	TCHAR szTitle[255];
	CString strTitle, strPid;
	int nIndex = 0;
	DWORD dwPid;
	CDestProcess process;

	hWnd = ::GetWindow(this->GetSafeHwnd(), GW_HWNDFIRST);

	DeleteAll();

	do
	{		
		::GetWindowText(hWnd, szTitle, 255);
		
		strTitle = szTitle;		
				
		if((strTitle.IsEmpty() == FALSE)  && ::GetParent(hWnd) == NULL)
		{			
			GetWindowThreadProcessId(hWnd, &dwPid);
			strPid.Format("0x%08lX", dwPid);
			
			m_wndTaskList.InsertItem(nIndex, strPid);		
			m_wndTaskList.SetItemText(nIndex, 1, strTitle);
			process.dwProcessId = dwPid;
			process.hWnd = hWnd;
			process.strTitle = strTitle;
			m_Items.Add(process);
			m_wndTaskList.SetItemData(nIndex, nIndex);
			nIndex++;			
		}

		hWnd = ::GetWindow(hWnd, GW_HWNDNEXT);
	}while(hWnd != NULL);
		
}


BOOL CSelectTaskDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CString str;

	// TODO: Add extra initialization here
	m_wndTaskList.SetExtendedStyle(LVS_EX_FULLROWSELECT);

	str.LoadString(IDS_PROCESS_ID);
	m_wndTaskList.InsertColumn(0, str, LVCFMT_LEFT,80);
	str.LoadString(IDS_WINDOW_TITLE);
	m_wndTaskList.InsertColumn(1, str, LVCFMT_LEFT, 180);	
	
	OnFresh();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CSelectTaskDlg::OnItemChangedTaskList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	int nItem = 0;
	int nIndex;
	POSITION pos = m_wndTaskList.GetFirstSelectedItemPosition();

	if (pos != NULL)
	{

		nItem = m_wndTaskList.GetNextSelectedItem(pos);
		nIndex = (int)(m_wndTaskList.GetItemData(nItem));
		m_CurrentProcess = this->m_Items.GetAt(nIndex);		
	}

	*pResult = 0;
}

void CSelectTaskDlg::DeleteAll()
{
	m_Items.RemoveAll();
	m_wndTaskList.DeleteAllItems();

}

BOOL CSelectTaskDlg::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	DeleteAll();
	return CDialog::DestroyWindow();
}

void CSelectTaskDlg::OnOK() 
{
	// TODO: Add extra validation here
	if(m_wndTaskList.GetSelectedCount() <= 0)
	{
		CString strText, strTitle;
		strText.LoadString(IDS_YOU_MUST_SELECT_A_PROCESS);
		strTitle.LoadString(IDS_ERROR);
		MessageBox(strText, strTitle, MB_OK | MB_ICONERROR);
		return;

	}
	CDialog::OnOK();
}
