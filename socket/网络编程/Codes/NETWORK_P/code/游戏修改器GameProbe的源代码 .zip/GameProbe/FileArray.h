// FileArray.h: interface for the CFileArray class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILEARRAY_H__6C8F2211_A19F_11D6_98C2_C99B4152F509__INCLUDED_)
#define AFX_FILEARRAY_H__6C8F2211_A19F_11D6_98C2_C99B4152F509__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SearchDefs.h"

#define _MAX_CACHED_COUNT 3000

class CFileArray  
{
public:
	struct CItem
	{
		DWORD dwAddress;
		BYTE bIsValid;
	};

	struct CHeader
	{
		CSearchResult SearchResult;
	};

public:
	
	BOOL Delete();
	

	void GetHeader(CSearchResult *pResult);
	void SetHeader(const CSearchResult *pResult);

	void SeekToHeader();
	void SeekToDataBegin();

	 void Add(CItem *pItem);
	 BOOL SeekToNext();
	 BOOL SetItem(CItem *pItem);
	 BOOL GetItem(CItem *pItem);
	 void Flush();

	void Close();
	BOOL Create(CString strFileName);
	BOOL Open(CString strFileName);
	

	CFileArray();
	virtual ~CFileArray();

protected:
	CFile m_File;
	CItem m_ItemCache[_MAX_CACHED_COUNT];
	DWORD m_dwCacheCounter;
	int m_nItemSize;
	BYTE m_fIsOpened;

protected:
	CString m_strFileName;

	DWORD m_dwCachePos;

	 void FillCache();

};

#endif // !defined(AFX_FILEARRAY_H__6C8F2211_A19F_11D6_98C2_C99B4152F509__INCLUDED_)
