// TableFrame.cpp : implementation file
//

#include "stdafx.h"
#include "gameprobe.h"
#include "TableFrame.h"
#include "MainFrameDlg.h"
#include "SearchFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTableFrame dialog

#define _FIX_TIMER_ID 11

CTableFrame::CTableFrame(CWnd* pParent /*=NULL*/)
	: CDialog(CTableFrame::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTableFrame)
	//}}AFX_DATA_INIT

	m_Fixer.GetTable()->RemoveAll();
	m_nItemCount = 0;
}


void CTableFrame::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTableFrame)
	DDX_Control(pDX, IDC_TABLE, m_wndTable);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTableFrame, CDialog)
	//{{AFX_MSG_MAP(CTableFrame)
	ON_WM_CREATE()	
	ON_COMMAND(ID_TABLE_NEW, OnTableNew)
	ON_COMMAND(ID_TABLE_REMOVE_ALL, OnTableRemoveAll)
	ON_COMMAND(ID_TABLE_REMOVE, OnTableRemove)
	ON_COMMAND(ID_TABLE_PROPRETY, OnTableProprety)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTableFrame message handlers


int CTableFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here

	DWORD dwStyle = WS_CHILD | WS_VISIBLE | CBRS_BORDER_3D | CBRS_FLYBY | CBRS_SIZE_DYNAMIC | CBRS_ALIGN_TOP;
	m_wndToolBar.Create(this, dwStyle);
	m_wndToolBar.LoadToolBar(IDR_TABLE_FRAME_TOOLBAR);	
	m_wndToolBar.SetLook2000(TRUE);
	
	CString str;
	str.LoadString(IDS_NEW);
	m_wndToolBar.SetToolBarBtnText(0, str);

	str.LoadString(IDS_PROPRETY);
	m_wndToolBar.SetToolBarBtnText(3, str);

	return 0;
}

BOOL CTableFrame::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_wndTable.SetExtendedStyle(LVS_EX_FULLROWSELECT);

	CRect rect;
	m_wndTable.GetWindowRect(&rect);
	rect.top = 12;
	rect.bottom = m_wndToolBar.GetRowHeight() + rect.top + 3;
	rect.right -= 3;
	rect.left -= 3;
	m_wndToolBar.MoveWindow(rect);

	CString str;

	str.LoadString(IDS_NAME);
	m_wndTable.InsertColumn(0, str, LVCFMT_LEFT, 100);
	str.LoadString(IDS_ADDRESS);
	m_wndTable.InsertColumn(1, str, LVCFMT_LEFT, 90);
	str.LoadString(IDS_VALUE);
	m_wndTable.InsertColumn(2, str, LVCFMT_LEFT, 80);
	str.LoadString(IDS_DATA_TYPE);
	m_wndTable.InsertColumn(3, str, LVCFMT_LEFT, 80);
	str.LoadString(IDS_FIX_MODE);
	m_wndTable.InsertColumn(4, str, LVCFMT_LEFT, 60);

	m_wndTable.DeleteAllItems();

	SetTimer(_FIX_TIMER_ID, 200, NULL);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTableFrame::AddToTable(CTableItem item)
{
	m_Fixer.GetTable()->AddTail(item);
	m_wndTable.InsertItem(m_nItemCount, "");
	SetTableItemAt(m_nItemCount, item);
	m_nItemCount++;
}

void CTableFrame::DoFix()
{
	if(m_nItemCount <= 0)return;

	CMainFrameDlg *pwndMainDlg = (CMainFrameDlg *)GetTheApp()->GetMainWnd();
	CSearchFrame *pwndSearchDlg = (CSearchFrame *)pwndMainDlg->GetFrame(CMainFrameDlg::pageSearchFrame);
	
	if(!pwndSearchDlg->IsProcessSelected())return;
	
	m_Fixer.SetPid(pwndSearchDlg->GetSelectedProcess().dwProcessId);
	m_Fixer.Fix();
}

void CTableFrame::SetTableItemAt(int nIndex, CTableItem item)
{
	CString str;
	CTable *pTable = m_Fixer.GetTable();

	pTable->SetAt(pTable->FindIndex(nIndex), item);

	str = item.szName;
	m_wndTable.SetItemText(nIndex, 0, str);

	str.Format("0x%08lX", item.dwAddress);
	m_wndTable.SetItemText(nIndex, 1, str);

	//COMMENT::TEMP
	str = item.Value.GetValueStr();
	m_wndTable.SetItemText(nIndex, 2, str);

	str = TypeToStr(item.Value.GetDataType());
	m_wndTable.SetItemText(nIndex, 3, str);

	str = FixTypeToStr(item.FixType);
	m_wndTable.SetItemText(nIndex, 4, str);
}

void CTableFrame::RemoveAll()
{
	m_Fixer.GetTable()->RemoveAll();
	m_wndTable.DeleteAllItems();
	m_nItemCount = 0;
}

BOOL CTableFrame::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	RemoveAll();
	KillTimer(_FIX_TIMER_ID);
	return CDialog::DestroyWindow();
}

void CTableFrame::OnTableNew() 
{
	// TODO: Add your command handler code here
	CTableItem item;
	item.dwAddress = 0;
	::strcpy(item.szName, "");
	item.Value.SetValue(0);

	NewItem(item);
}

void CTableFrame::OnTableRemoveAll() 
{
	// TODO: Add your command handler code here
	RemoveAll();
}

void CTableFrame::OnTableRemove() 
{
	// TODO: Add your command handler code here
	RemoveSelected();
}


void CTableFrame::RemoveSelected()
{
	int nCount = m_wndTable.GetSelectedCount();
	
	
	POSITION pos = m_wndTable.GetFirstSelectedItemPosition();
	if (pos == NULL)return;	

	int nItem;

	while (pos)
	{
		nItem = m_wndTable.GetNextSelectedItem(pos);
		DoRemoveItem(nItem);
	}
}

void CTableFrame::DoRemoveItem(int nIndex)
{
	CTable* pTable = m_Fixer.GetTable();;
	pTable->RemoveAt(pTable->FindIndex(nIndex));
	m_wndTable.DeleteItem(nIndex);
	m_nItemCount--;
	
}

BOOL CTableFrame::NewItem(CTableItem item)
{
	CEditItemDlg dlg;
	dlg.SetData(item);
	if(dlg.DoModal() == IDOK)
	{
		item = dlg.GetData();
		AddToTable(item);
		return TRUE;
	}

	return FALSE;
}

void CTableFrame::OnTableProprety() 
{
	// TODO: Add your command handler code here
	CEditItemDlg dlg;
	CTable *pTable = m_Fixer.GetTable();
	int nItem;
	CTableItem item;

	if(m_wndTable.GetSelectedCount() == 0)return;

	TRACE("OnProprety\n");

	POSITION pos;
	pos = m_wndTable.GetFirstSelectedItemPosition();
	nItem = m_wndTable.GetNextSelectedItem(pos);

	item = GetTableItemAt(nItem);	
	dlg.SetData(item);

	if(dlg.DoModal() == IDOK)
	{
		item = dlg.GetData();
		SetTableItemAt(nItem, item);
	}

}

CTableItem CTableFrame::GetTableItemAt(int nIndex)
{
	CTable *pTable = m_Fixer.GetTable();
	return pTable->GetAt(pTable->FindIndex(nIndex));
}

void CTableFrame::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == _FIX_TIMER_ID)
	{
		DoFix(); //д��
	}
	
	CDialog::OnTimer(nIDEvent);
}

CString CTableFrame::TypeToStr(CDataType type)
{
	CString strRet;
	
	switch(type.id)
	{
	case CDataType::typeBYTE:
		strRet.LoadString(IDS_BYTE);
		break;

	case CDataType::typeWORD:
		strRet.LoadString(IDS_WORD);
		break;

	case CDataType::typeDWORD:
		strRet.LoadString(IDS_DWORD);
		break;

	case CDataType::typeFLOAT:
		strRet.LoadString(IDS_FLOAT);
		break;

	case CDataType::typeDOUBLE:
		strRet.LoadString(IDS_DOUBLE);
		break;
	}


	return strRet;
}

CString CTableFrame::FixTypeToStr(CFixType fixType)
{
	CString strRet;

	switch(fixType.id)
	{
	case CFixType::ftNONE:
		strRet.LoadString(IDS_NONE);
		break;

	case CFixType::ftAUTO:
		strRet.LoadString(IDS_AUTO_LOCK);
		break;

	case CFixType::ftHOTKEY:
		strRet.LoadString(IDS_HOTKEY_FIX);
		break;

	}

	return strRet;
}
