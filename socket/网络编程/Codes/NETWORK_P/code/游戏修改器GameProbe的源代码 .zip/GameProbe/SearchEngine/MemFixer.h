// MemFixer.h: interface for the CMemFixer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MEMFIXER_H__3F396B62_A3A4_11D6_B0CB_AF968509CCFF__INCLUDED_)
#define AFX_MEMFIXER_H__3F396B62_A3A4_11D6_B0CB_AF968509CCFF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Fixer.h"

class CMemFixer : public CFixer  
{
public:
	void Fix();
	CMemFixer();
	virtual ~CMemFixer();

	void SetPid(DWORD dwId){m_dwProcessId = dwId;}
	DWORD GetPid(DWORD dwId){return m_dwProcessId;}

protected:
	DWORD m_dwProcessId;
};

#endif // !defined(AFX_MEMFIXER_H__3F396B62_A3A4_11D6_B0CB_AF968509CCFF__INCLUDED_)
