#ifndef __SEARCHDEFS_H_
#define __SEARCHDEFS_H_


#define MAX_BUF_SIZE 5000
#define MAX_PATTERN_SIZE 1024

namespace SearchDefs
{
	struct CDestProcess
	{
		HWND hWnd;
		DWORD dwProcessId;
		CString strTitle;
	};

	
	struct CSearchResult
	{
		DWORD dwCount;
		DWORD dwTimes;
	};
};

using namespace SearchDefs;

class CError
{
public:
	CError(DWORD nErrNo){m_nErrorNo = nErrNo;}
public:
	DWORD m_nErrorNo;

public:
	enum{
		ERRNO__SUCCCESS = 0,
		ERRNO__INVALID_PTR,
		ERRNO__FILE_IS_READ_ONLY,
		ERRNO__CANNOT_CREATE_FILE,
		ERRNO__CANNOT_OPEN_FILE,
		ERRNO__DISK_FULL,
		ERRNO__INVALID_ENTER,
		ERRNO__INVALID_DATA_TYPE
	};
};


#endif