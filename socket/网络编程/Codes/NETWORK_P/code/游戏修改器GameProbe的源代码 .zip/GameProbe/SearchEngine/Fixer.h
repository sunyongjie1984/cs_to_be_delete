// Fixer.h: interface for the CFixer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FIXER_H__3F396B61_A3A4_11D6_B0CB_AF968509CCFF__INCLUDED_)
#define AFX_FIXER_H__3F396B61_A3A4_11D6_B0CB_AF968509CCFF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "searchdefs.h"
#include "SearchTarget.h"
#include "Value.h"

namespace Fixer
{
	struct CFixType
	{
		enum
		{
			ftHOTKEY = 1,
				ftAUTO = 2,
				ftNONE = 3
		}id;
	};
	
	struct CFileHeader
	{
		TCHAR szAuthor[MAX_PATH];
		DWORD dwAuthorSize;
		
		TCHAR szComment[1024];
		DWORD szCommentSize;
		
		DWORD dwItemCount;
		
	};
	
	struct CTableItem
	{
		TCHAR szName[255];
		DWORD dwAddress;
		CValue Value;	
		CFixType FixType;
		CDataType DataType;
	};
	
	typedef CList<CTableItem, CTableItem> CTable;
};
using namespace Fixer;

class CFixer  
{
public:
	
	
	
public:
	CFixer();
	virtual ~CFixer();
	
public:
	
	CTable * GetTable(){return &m_Table;}
	
	virtual void Fix() = 0;
	
protected:
	CTable m_Table;
	
};


#endif // !defined(AFX_FIXER_H__3F396B61_A3A4_11D6_B0CB_AF968509CCFF__INCLUDED_)
