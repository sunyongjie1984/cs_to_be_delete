// Value.cpp: implementation of the CValue class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GameProbe.h"
#include "Value.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CValue::CValue()
{
	::memset(&m_Value, 0, sizeof(m_Value));
	m_pBuffer = PBYTE((&m_Value));

}

CValue::~CValue()
{

}

void CValue::SetValue(CValueData value, CDataType type)
{
	m_Value = value;
	m_Type = type;
	SetBufferPtr();
}

void CValue::SetValue(DWORD n)
{
	CDataType type;
	type.id = CDataType::typeDWORD;
	CValueData v;
	v.Dword = n;
	SetValue(v, type);
}

BOOL CValue::StrToValue(CString str, CDataType type)
{
	CValueData uv;

	switch(type.id)
	{
	case CDataType::typeWORD:
		uv.Word = (WORD)::strtoul(str, NULL, 0);
		break;

	case CDataType::typeBYTE:
		uv.Byte = (BYTE)::strtoul(str, NULL, 0);
		break;

	case CDataType::typeDWORD:
		uv.Dword = ::strtoul(str, NULL, 0);
		break;

	case CDataType::typeFLOAT:
		uv.Float = (FLOAT)::strtod(str, NULL);
		break;

	case CDataType::typeDOUBLE:
		uv.Double = ::strtod(str, NULL);
		break;

	default: 
		CError err(CError::ERRNO__INVALID_DATA_TYPE);
		throw(err);
		return FALSE;
		break;
	}

	SetValue(uv, type);

	return TRUE;
}

void CValue::SetBufferPtr()
{
	switch(this->m_Type.id)
	{
	case CDataType::typeBYTE:
		m_pBuffer = PBYTE(&m_Value.Byte);
		m_nBufferSize = sizeof(BYTE);
		break;

	case CDataType::typeWORD:
		m_pBuffer = PBYTE(&m_Value.Word);
		m_nBufferSize = sizeof(WORD);
		break;

	case CDataType::typeDWORD:
		m_pBuffer = PBYTE(&m_Value.Dword);
		m_nBufferSize = sizeof(DWORD);
		break;

	case CDataType::typeFLOAT:
		m_pBuffer = PBYTE(&m_Value.Float);
		m_nBufferSize = sizeof(FLOAT);
		break;

	case CDataType::typeDOUBLE:
		m_pBuffer = PBYTE(&m_Value.Double);
		m_nBufferSize = sizeof(DOUBLE);
		break;

	}

}

CString CValue::GetValueStr()
{
	CString strRet;

	switch(this->m_Type.id)
	{
	case CDataType::typeBYTE:
		strRet.Format("%u", m_Value.Byte);
		break;

	case CDataType::typeWORD:
		strRet.Format("%u", m_Value.Word);
		break;

	case CDataType::typeDWORD:
		strRet.Format("%u", m_Value.Dword);
		break;

	case CDataType::typeFLOAT:
		strRet.Format("%f", m_Value.Float);
		break;

	case CDataType::typeDOUBLE:
		strRet.Format("%f", m_Value.Double);
		break;

	default: 
		break;
	}

	return strRet;
}

void CValue::SetDataType(CDataType type)
{
	m_Type = type;
	SetBufferPtr();	
}
