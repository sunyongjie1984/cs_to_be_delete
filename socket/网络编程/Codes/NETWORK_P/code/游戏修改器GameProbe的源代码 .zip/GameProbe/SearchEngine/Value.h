// Value.h: interface for the CValue class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VALUE_H__6C8F2212_A19F_11D6_98C2_C99B4152F509__INCLUDED_)
#define AFX_VALUE_H__6C8F2212_A19F_11D6_98C2_C99B4152F509__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


struct CDataType
{
	enum
	{
		typeBYTE = 1,
		typeWORD = 2,
		typeDWORD = 3,
		typeFLOAT = 4,
		typeDOUBLE = 5,
	}id;
		
};

class CValue  
{
public:
	union CValueData
	{
		BYTE Byte;
		WORD Word;
		DWORD Dword;
		float Float;
		double Double;
	};

public:
	CValue();
	virtual ~CValue();

public:
	CDataType GetDataType(){return m_Type;}
	void SetDataType(CDataType type);
	CString GetValueStr();
	void SetBufferPtr();
	BOOL StrToValue(CString str, CDataType type);
	void SetValue(DWORD n);
	void SetValue(CValueData value, CDataType type);
	DWORD GetBufferSize(){return m_nBufferSize;}
	const BYTE * GetBufferPtr(){return m_pBuffer;}
	CValueData GetValue(){return m_Value;}

private:
	//void ValueToBuffer();

private:
	BYTE *m_pBuffer;
	CValueData m_Value; 
	DWORD m_nBufferSize;
	CDataType m_Type;

};

#endif // !defined(AFX_VALUE_H__6C8F2212_A19F_11D6_98C2_C99B4152F509__INCLUDED_)
