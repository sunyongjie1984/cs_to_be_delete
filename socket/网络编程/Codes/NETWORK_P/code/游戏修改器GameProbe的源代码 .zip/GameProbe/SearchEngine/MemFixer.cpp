// MemFixer.cpp: implementation of the CMemFixer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GameProbe.h"
#include "MemFixer.h"
#include "processmem.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMemFixer::CMemFixer()
{

}

CMemFixer::~CMemFixer()
{

}

void CMemFixer::Fix()
{
	DWORD nIndex;
	DWORD nCount = (DWORD)m_Table.GetCount();
	CTableItem item;

	CProcessMem ProcessMem;

	if(!ProcessMem.Open(m_dwProcessId))return;

	for(nIndex = 0; nIndex < nCount; nIndex++)
	{
		item = m_Table.GetAt(m_Table.FindIndex(nIndex));

		ProcessMem.Seek(item.dwAddress);
		ProcessMem.Write((LPVOID)item.Value.GetBufferPtr(), item.Value.GetBufferSize());
	}
	
	ProcessMem.Close();

}
