// MemSearch.cpp: implementation of the CMemSearch class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GameProbe.h"
#include "MemSearch.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMemSearch::CMemSearch()
{
	
}

CMemSearch::~CMemSearch()
{
	
}

void CMemSearch::DoFirstSearch()
{
	MEMORY_BASIC_INFORMATION mbi;
	CProcessMem::CMemoryInfo mi;
	CProcessMem ProcessMem;

	CFileArray::CItem tfItem;
	tfItem.bIsValid = 1;

	DWORD dwSearchedBytes = 0;
	DWORD nPatternSize = m_DestBuffer.nSize;
	DWORD dwBytesLeft, dwReadedBytes;
	DWORD dwOffset = 0;
	int nStartPos;
	DWORD dwBaseAddress, dwCurrentPos;
	DWORD nPatternPos;
	DWORD dwSegAddress;
	BYTE bBuf[MAX_BUF_SIZE];
	DWORD dwCurrentOffset;
	DWORD dwMaxSize;
	
	if(ProcessMem.Open(m_dwProcessId) == FALSE)return;
	ProcessMem.GetMemoryInfo(&mi);
	
	dwBaseAddress = mi.dwMinAddress;
	
	dwMaxSize = ProcessMem.GetSize();

	//	mbi.BaseAddress = (LPVOID)dwBaseAddress;
	TRACE("MaxAddress = %X, MinAddress = %X\n", mi.dwMaxAddress, mi.dwMinAddress);
	while(dwBaseAddress < mi.dwMaxAddress)
	{
		mbi.BaseAddress = (LPVOID)dwBaseAddress;
		ProcessMem.Query((PVOID)dwBaseAddress, &mbi);
		dwSegAddress = (DWORD)mbi.BaseAddress;
		dwBaseAddress = (DWORD)mbi.BaseAddress + mbi.RegionSize;
		ProcessProgress(0, dwMaxSize, dwSearchedBytes);
		dwSearchedBytes += mbi.RegionSize;
		
		if(ProcessMem.IsUsable(mbi) == FALSE)
		{
			continue;
		}
		
		dwCurrentOffset = 0;
		dwOffset = 0;
		dwReadedBytes = 0;
		dwCurrentPos = dwSegAddress;
		dwBytesLeft = mbi.RegionSize;

		while(dwBytesLeft > nPatternSize)
		{			

			dwCurrentPos = dwSegAddress + dwOffset;
			ProcessMem.Seek(dwCurrentPos);
			dwReadedBytes = ProcessMem.Read(bBuf, MAX_BUF_SIZE);
			//if(dwReadedBytes < nPatternSize)break;
			if(dwOffset + 1 > mbi.RegionSize)break;
			dwCurrentOffset += dwReadedBytes;
			nStartPos = 0;
			
			do
			{
				nPatternPos = MemFind(nStartPos, bBuf, dwReadedBytes, m_DestBuffer.pBuffer, nPatternSize);
				
				if(nPatternPos != -1)
				{
					//�ҵ��ĵ�ֵ
					nStartPos = nPatternPos + 1;
					tfItem.dwAddress = dwSegAddress + dwOffset + nPatternPos;
					DoOnFound(tfItem.dwAddress);
					m_TempFile.Add(&tfItem);
					if(m_SearchResult.dwCount % 48123 == 0)ProcessProgress(0, dwMaxSize, dwSearchedBytes + dwOffset);
					//TRACE("0x%X ", tfItem.dwAddress);
				}
				
			}while(nPatternPos != -1);
			
			dwOffset = dwCurrentOffset - nPatternSize;
			dwCurrentOffset = dwOffset + 1;
			dwBytesLeft = mbi.RegionSize - dwOffset;
			//TRACE("dwReadedBytes = %u\n", dwReadedBytes);			
		}
		

	}
	
	ProcessMem.Close();
	
}

BOOL CMemSearch::Search(BYTE *pDestBuf, DWORD nBufSize, CSearchResult &result)
{
	m_DestBuffer.pBuffer = pDestBuf;
	m_DestBuffer.nSize = nBufSize;
	
	BeginSearch();
	
	if(m_SearchResult.dwTimes == 1)
		DoFirstSearch();
	else DoNextSearch();
	
	EndSearch();
	result = m_SearchResult;
	
	return TRUE;
}

BOOL CMemSearch::DoNextSearch()
{
	TRACE("Calling DoNextSearch()\n");
	CFileArray::CItem Item;
	DWORD dwCount;
	CProcessMem ProcessMem;
	BYTE buf[MAX_PATTERN_SIZE];
	
	TRACE("FirstCount = %u \n", m_dwFirstCount);

	ProcessMem.Open(m_dwProcessId);	
	for(dwCount = 0; dwCount < m_dwFirstCount; dwCount++)
	{
		m_TempFile.GetItem(&Item);
		if(Item.bIsValid == TRUE)
		{
			ProcessMem.Seek(Item.dwAddress);
			ProcessMem.Read(buf, m_DestBuffer.nSize);
			if(!::memcmp(buf, m_DestBuffer.pBuffer, m_DestBuffer.nSize))
			{
				DoOnFound(Item.dwAddress);
			}
			else
			{
				Item.bIsValid = FALSE;
			}
		}
		
		m_TempFile.SetItem(&Item);
		m_TempFile.SeekToNext();
		
		if(dwCount % 1500 == 0)
		{
			ProcessProgress(0, m_dwFirstCount, dwCount);
		}
	}
	
	ProcessMem.Close();
	
	return TRUE;
}

void CMemSearch::SetProcessId(DWORD dwProcessId)
{
	m_dwProcessId = dwProcessId;
}

DWORD CMemSearch::GetProcessId()
{
	return m_dwProcessId;
}
