// EditItemDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GameProbe.h"
#include "EditItemDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditItemDlg dialog


CEditItemDlg::CEditItemDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEditItemDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEditItemDlg)
	m_strAddress = _T("");
	m_strName = _T("");
	m_strTarget = _T("");
	//}}AFX_DATA_INIT
}


void CEditItemDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditItemDlg)
	DDX_Control(pDX, IDC_FIX_TYPE, m_wndFixType);
	DDX_Control(pDX, IDC_DATA_TYPE, m_wndDataType);
	DDX_Text(pDX, IDC_ADDRESS, m_strAddress);
	DDX_CBString(pDX, IDC_NAME, m_strName);
	DDX_Text(pDX, IDC_TARGET, m_strTarget);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEditItemDlg, CDialog)
	//{{AFX_MSG_MAP(CEditItemDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditItemDlg message handlers

void CEditItemDlg::SetTitle(CString str)
{
	SetWindowText(str);
}

CTableItem CEditItemDlg::GetData()
{
	return m_ItemData;
}

BOOL CEditItemDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	

	m_wndDataType.Init();
	m_wndFixType.Init();

	m_strName = m_ItemData.szName;
	m_strAddress.Format("0x%08lX", m_ItemData.dwAddress);
	m_strTarget = m_ItemData.Value.GetValueStr();
	m_wndFixType.SetFixType(m_ItemData.FixType);
	m_wndDataType.SetDataType(m_ItemData.DataType);

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CEditItemDlg::SetData(CTableItem item)
{
	m_ItemData = item;
}
void CEditItemDlg::OnOK() 
{
	UpdateData();
	// TODO: Add extra validation here

	::strcpy(m_ItemData.szName, m_strName);
	m_ItemData.Value.StrToValue(m_strTarget, m_wndDataType.GetDataType());
	::sscanf(m_strAddress, "0x%08lX", &m_ItemData.dwAddress);	
	m_ItemData.DataType = m_wndDataType.GetDataType();
	m_ItemData.FixType = m_wndFixType.GetFixType();
	TRACE("Address is: 0x%08lX", m_ItemData.dwAddress);

	CDialog::OnOK();
}

INT_PTR CALLBACK CEditItemDlg::DlgProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        case WM_INITDIALOG:
            return TRUE;

        case WM_COMMAND:
            switch( LOWORD(wParam) )
            {
                case IDCANCEL:
                case IDOK:
                    ::EndDialog( hDlg, TRUE );
                    return TRUE;
            }
            break;

        case WM_MOVE:
            // The window is moving around, so re-draw the backbuffer            
            break;

        case WM_DESTROY:            
            break;
    }

    return FALSE;
}
