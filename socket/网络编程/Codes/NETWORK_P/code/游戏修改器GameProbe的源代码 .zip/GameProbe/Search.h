// Search.h: interface for the CSearch class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SEARCH_H__6C8F220E_A19F_11D6_98C2_C99B4152F509__INCLUDED_)
#define AFX_SEARCH_H__6C8F220E_A19F_11D6_98C2_C99B4152F509__INCLUDED_

#include "FileArray.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FileArray.h"

class CValue;

class CSearch  
{
public:

	struct CBuffer
	{
		BYTE *pBuffer;
		DWORD nSize;
	};
	
	public:
		CSearch();
		virtual ~CSearch();
		
	public:
		const CSearchResult *GetResult();
		virtual void OnBeginSearch();
		virtual void OnEndSearch(CSearchResult *pResult);
		void CleanResult();
		void Reset();
		virtual BOOL Search(BYTE *pDestBuf, DWORD nBufSize, CSearchResult &result) = 0;
		virtual void Release();
		virtual BOOL Create(CString strTempFile);
		virtual void OnFound(DWORD dwAddress, DWORD dwCount);
		virtual void OnProgress(DWORD dwMin, DWORD dwMax, DWORD dwPos);
		
		
	protected:
		CFileArray m_TempFile;
		CSearchResult m_SearchResult;

		DWORD m_dwTickTime;
		
	protected:
		void ProcessProgress(DWORD dwMin, DWORD dwMax, DWORD dwPos);
		DWORD m_dwFirstCount;
		CBuffer m_DestBuffer;
		void DoOnFound(DWORD dwAddress);
		
		BOOL EndSearch();
		BOOL BeginSearch();
		MemFind(int iStartPosition, LPBYTE pDestBuffer, int iDestBufferLength, LPBYTE pPatternBuffer, int iPatternBufferLength);
		
};


#endif // !defined(AFX_SEARCH_H__6C8F220E_A19F_11D6_98C2_C99B4152F509__INCLUDED_)
