#if !defined(AFX_SEARCHFRAME_H__30B6DB01_A341_11D6_B0CB_F85109371975__INCLUDED_)
#define AFX_SEARCHFRAME_H__30B6DB01_A341_11D6_B0CB_F85109371975__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SearchFrame.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSearchFrame dialog
#include "searchdefs.h"
#include "memsearch.h"
#include "GameProbememSearch.h"
#include "customcombo.h"
#include "Staticex.h"
#include "LinkButton.h"


class CSearchFrame : public CDialog
{
public:
	BOOL IsProcessSelected(){return m_fIsProcessSelected;}

protected:
	CSearch *m_pSearchTasks[10];
	int m_nTaskCount;
	int m_nCurrentTask;

	CDestProcess m_Process;
	
	BOOL m_fIsProcessSelected;

	//U I 
protected:



// Construction
public:
	CDestProcess GetSelectedProcess(){return m_Process;}
	void SelectProcess(HWND hWnd);
	void ShowProcessInfo();
	void DeleteSearchTask(DWORD nIndex);
	virtual  ~CSearchFrame();
	BOOL NewSearchTask();
	void RefreshInterface();


	CSearchFrame(CWnd* pParent = NULL);   // standard constructor

	void ShowResult(const CSearchResult *pResult);

// Dialog Data
	//{{AFX_DATA(CSearchFrame)
	enum { IDD = IDD_SEARCH_FRAME };
	CLinkButton	m_wndHelp;
	CLinkButton	m_wndGotoEdit;
	CComboBox	m_wndTarget;
	CStaticEx	m_wndProcessInfo;
	CStaticEx	m_wndTimes;
	CStaticEx	m_wndCount;
	CDataTypeCombo	m_wndDataType;
	CListBox	m_wndSearchTaskList;
	CListBox	m_wndResultList;
	BOOL	m_bTrendSearch;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSearchFrame)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void RefreshTarget();
	BOOL IsTargetValid();
	

	// Generated message map functions
	//{{AFX_MSG(CSearchFrame)
	afx_msg void OnSearch();
	afx_msg void OnSelectTask();
	virtual BOOL OnInitDialog();
	afx_msg void OnResetTask();
	afx_msg void OnGotoEdit();
	afx_msg void OnTrendSearch();
	afx_msg void OnAddToTable();
	afx_msg void OnEditchangeTarget();
	afx_msg void OnReturnToProcess();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnSelchangeResultList();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SEARCHFRAME_H__30B6DB01_A341_11D6_B0CB_F85109371975__INCLUDED_)
