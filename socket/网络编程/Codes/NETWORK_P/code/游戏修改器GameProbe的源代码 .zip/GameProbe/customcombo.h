#if !defined(AFX_CUSTOMCOMBO_H__12746D81_A3B0_11D6_B0CB_A16EFCB4D035__INCLUDED_)
#define AFX_CUSTOMCOMBO_H__12746D81_A3B0_11D6_B0CB_A16EFCB4D035__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CustomCombo.h : header file
//

#include "Value.h"
#include "Fixer.h"

/////////////////////////////////////////////////////////////////////////////
// CDataTypeCombo window
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// CEnumCombo window

class CEnumCombo : public CComboBox
{
// Construction
public:
	CEnumCombo();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEnumCombo)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CEnumCombo();

	// Generated message map functions
protected:
	//{{AFX_MSG(CEnumCombo)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

class CDataTypeCombo : public CEnumCombo
{
public:
	typedef CList<CDataType, CDataType> CDataTypeList;
// Construction
public:
	CDataTypeCombo();

// Attributes
public:

// Operations
public:
	void Init();
	

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataTypeCombo)
	public:
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetDataType(CDataType type);
	CDataType GetDataType();
	virtual ~CDataTypeCombo();

	// Generated message map functions
protected:
	int m_nCurrentSel;

	CDataTypeList m_DataTypeList;

	
	//{{AFX_MSG(CDataTypeCombo)
	afx_msg void OnSelchange();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// CFixTypeCombo window

class CFixTypeCombo : public CEnumCombo
{
public:
	typedef CList<CFixType, CFixType> CFixTypeList;
// Construction
public:
	CFixTypeCombo();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFixTypeCombo)
	public:
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

protected:
	CFixTypeList m_FixTypeList;

// Implementation
public:
	void SetFixType(CFixType type);
	CFixType GetFixType();
	void Init();
	virtual ~CFixTypeCombo();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFixTypeCombo)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CUSTOMCOMBO_H__12746D81_A3B0_11D6_B0CB_A16EFCB4D035__INCLUDED_)
