// MainFrameDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GameProbe.h"
#include "MainFrameDlg.h"

#include "SearchFrame.h"
#include "TableFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define _OUTBAR_WIDTH 80
#define _MAIN_DIALOG_BORDER_SIZE 12

#define ID_OUTBAR AFX_IDW_CONTROLBAR_FIRST + 20

/////////////////////////////////////////////////////////////////////////////
// CMainFrameDlg dialog

CMainFrameDlg::CMainFrameDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMainFrameDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMainFrameDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMainFrameDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMainFrameDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMainFrameDlg, CDialog)
	//{{AFX_MSG_MAP(CMainFrameDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_COMMAND(ID_MENU_SWITCH_TO_SEARCH_FRAME, OnMenuSwitchToSearchFrame)
	ON_COMMAND(ID_MENU_SWITCH_TO_TABLE_FRAME, OnMenuSwitchToTableFrame)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_HOTKEY_DOWN,OnHotKeyDown) //���Լ����ӵ���Ϣӳ�亯��
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrameDlg message handlers

BOOL CMainFrameDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	//��ʾ��һҳ
	SwitchFrame(pageSearchFrame);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMainFrameDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

BOOL CMainFrameDlg::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	for(DWORD n = 0; n < m_dwPageCount; n++)
	{
		m_pwndPages[n]->DestroyWindow();
		delete m_pwndPages[n];
	}
	
	GetTheApp()->DisableHotKey();

	return CDialog::DestroyWindow();
}

void CMainFrameDlg::SetFrame(int nIndex)
{	
	DWORD dwLeftOffset = _OUTBAR_WIDTH + _MAIN_DIALOG_BORDER_SIZE;
	TRACE("Index = %d \n", nIndex);
	if((DWORD)(nIndex + 1) > m_dwPageCount)return;

	int nTop;
	CRect rect;
	m_pwndPages[nIndex]->GetClientRect(&rect);
	nTop = rect.top;
	rect.top = 0;
	rect.bottom -= nTop;
	rect.left += dwLeftOffset;
	rect.right += dwLeftOffset;
	m_pwndPages[nIndex]->MoveWindow(rect);
	m_pwndPages[nIndex]->ShowWindow(SW_HIDE);
}


int CMainFrameDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;


	if(!CreateOutbar())
	{
		TRACE("Create the OutlookBar failed\n");
		return -1;
	}
	
	CreatePages();
	// TODO: Add extra initialization here


	return 0;
}

void CMainFrameDlg::OnMenuSwitchToSearchFrame() 
{
	SwitchFrame(pageSearchFrame);
}

void CMainFrameDlg::OnMenuSwitchToTableFrame() 
{
	// TODO: Add your command handler code here
	SwitchFrame(pageTableFrame);
	
}

void CMainFrameDlg::SwitchFrame(DWORD dwPage)
{
	CDialog *pFrame;
	pFrame = m_pwndPages[m_dwCurrentPage];
	
	if(dwPage == m_dwCurrentPage && pFrame->IsWindowVisible())return;  //��������
	m_pwndPages[m_dwCurrentPage]->ShowWindow(SW_HIDE);
	m_dwCurrentPage = dwPage;
	m_pwndPages[m_dwCurrentPage]->ShowWindow(SW_SHOW);
	m_pwndPages[m_dwCurrentPage]->SetForegroundWindow();
	m_pwndPages[m_dwCurrentPage]->BringWindowToTop();
}

BOOL CMainFrameDlg::CreatePages()
{
	m_dwPageCount = pageSearchFrame;

	m_dwCurrentPage = pageSearchFrame;
	m_pwndPages[m_dwPageCount] = new CSearchFrame;
	m_pwndPages[m_dwPageCount]->Create(IDD_SEARCH_FRAME, this);
	m_dwPageCount++;
	SetFrame(m_dwPageCount - 1);

	m_pwndPages[m_dwPageCount] = new CTableFrame;
	m_pwndPages[m_dwPageCount]->Create(IDD_TABLE_FRAME, this);
	m_dwPageCount++;
	SetFrame(m_dwPageCount - 1);

	return TRUE;
}

BOOL CMainFrameDlg::CreateOutbar()
{
	if(!m_wndOutbar.Create(this, WS_CHILD | WS_VISIBLE, ID_OUTBAR))
	{
		TRACE("Cannot create the Outbar\n");
		return FALSE;
	}

	m_wndOutbar.SetBarStyle(CBRS_SIZE_FIXED);

	CRect rect;
	this->GetClientRect(&rect);
	rect.top = _MAIN_DIALOG_BORDER_SIZE - 1;
	rect.left = _MAIN_DIALOG_BORDER_SIZE - 1;
	rect.right = _OUTBAR_WIDTH + rect.left;
	rect.bottom -= rect.top;
	m_wndOutbar.MoveWindow(&rect);
	m_wndOutbar.SetBorders(&rect);
	m_wndOutbar.SetBackColor(RGB(128, 128, 128));
	m_wndOutbar.SetTransparentColor (RGB (255, 0, 255));
	m_wndOutbar.SetTextColor (RGB (255, 255, 255));
	m_wndOutbar.EnableTextLabels (TRUE);

	m_wndOutbar.AddButton(IDB_OUTBAR_TABLE, IDS_ADDRESS_TABLE, ID_MENU_SWITCH_TO_TABLE_FRAME);
	m_wndOutbar.AddButton(IDB_OUTBAR_SEARCH, IDS_SEARCH, ID_MENU_SWITCH_TO_SEARCH_FRAME);

	return TRUE;
	
}

void CMainFrameDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	switch(nID)
	{
	case SC_MINIMIZE:
		GetTheApp()->EnableHotKey();			
		break;

	case SC_RESTORE:		
		GetTheApp()->DisableHotKey();
		break;
	}

	CDialog::OnSysCommand(nID, lParam);
}

void CMainFrameDlg::OnHotKeyDown(WPARAM wP,LPARAM lP)
{
	TRACE("OnHotKeyDown()\n");
	DWORD wp = (DWORD)wP;
	switch(wp)
	{
	case 0:
		GetTheApp()->DoPopup();
		break;
	}
}

CDialog * CMainFrameDlg::GetFrame(int nIndex)
{
	return this->m_pwndPages[nIndex];
}
