// FileArray.cpp: implementation of the CFileArray class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GameProbe.h"
#include "FileArray.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFileArray::CFileArray()
{
	m_dwCacheCounter = 0;
	m_nItemSize = sizeof(CItem);
	m_fIsOpened = FALSE;
}

CFileArray::~CFileArray()
{

}

void CFileArray::Add(CItem *pItem)
{

	if(pItem == NULL)return;
	::memcpy(&(m_ItemCache[m_dwCacheCounter]), pItem, m_nItemSize);
	m_dwCacheCounter++;
	if(m_dwCacheCounter >= _MAX_CACHED_COUNT)Flush();
	

}

BOOL CFileArray::Open(CString strFileName)
{
	BOOL bRet = m_File.Open(strFileName, CFile::modeReadWrite);
	m_strFileName = strFileName;
	m_fIsOpened = bRet;
	return bRet;
}

BOOL CFileArray::Create(CString strFileName)
{
	BOOL bRet = m_File.Open(strFileName, CFile::modeCreate | CFile::modeReadWrite);
	m_strFileName = strFileName; 
	m_fIsOpened = bRet;
	return bRet;
}

void CFileArray::Close()
{
	if(!m_fIsOpened)return;
	m_File.Close();
	m_fIsOpened = FALSE;
}

BOOL CFileArray::GetItem(CItem *pItem)
{
	::memcpy(pItem, &m_ItemCache[m_dwCachePos], m_nItemSize);
	return TRUE;
}


BOOL CFileArray::SetItem(CItem *pItem)
{
	::memcpy(&m_ItemCache[m_dwCachePos], pItem, m_nItemSize);
	return TRUE;
}

BOOL CFileArray::SeekToNext()
{
	m_dwCachePos++;
	
	if(m_dwCachePos >= m_dwCacheCounter)
	{
		TRACE("Calling FillCache()\n");
		m_dwCacheCounter = m_dwCachePos;
		Flush();
		FillCache();

	}			
	return TRUE;
}

void CFileArray::SeekToDataBegin()
{
	m_File.Seek(sizeof(CHeader), CFile::begin);
	FillCache();
}

void CFileArray::SeekToHeader()
{
	m_File.SeekToBegin();
}

void CFileArray::GetHeader(CSearchResult *pResult)
{
	CHeader header;
	m_File.SeekToBegin();
	m_File.Read(&header, sizeof(CHeader));
	::memcpy(pResult, &(header.SearchResult), sizeof(CSearchResult));
}


void CFileArray::SetHeader(const CSearchResult *pResult)
{
	CHeader header;
	::memcpy(&(header.SearchResult), pResult, sizeof(CSearchResult));
	m_File.SeekToBegin();
	m_File.Write(&header, sizeof(CHeader));
}

void CFileArray::Flush()
{
	m_File.Write(m_ItemCache, m_nItemSize * m_dwCacheCounter);
	m_dwCacheCounter = 0;
}

void CFileArray::FillCache()
{
	
	DWORD dwPos = m_File.GetPosition();
	m_dwCacheCounter = m_File.Read(m_ItemCache, m_nItemSize * _MAX_CACHED_COUNT) / m_nItemSize;
	m_dwCachePos = 0;
	m_File.Seek(dwPos, CFile::begin);
}

BOOL CFileArray::Delete()
{

	TRACE("Deleting file: %s\n", m_strFileName);
	TRY
	{
		
		CFile::Remove(m_strFileName);
	}
	CATCH( CFileException, e )
	{
		return FALSE;
	}
	END_CATCH

	return TRUE;

}
