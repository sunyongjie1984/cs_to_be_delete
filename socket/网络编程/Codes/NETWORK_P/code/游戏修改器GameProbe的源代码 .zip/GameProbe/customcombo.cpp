// CustomCombo.cpp : implementation file
//

#include "stdafx.h"
#include "GameProbe.h"
#include "CustomCombo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDataTypeCombo

CDataTypeCombo::CDataTypeCombo()
{
}

CDataTypeCombo::~CDataTypeCombo()
{
}


BEGIN_MESSAGE_MAP(CDataTypeCombo, CComboBox)
	//{{AFX_MSG_MAP(CDataTypeCombo)
	ON_CONTROL_REFLECT(CBN_SELCHANGE, OnSelchange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFixTypeCombo message handlers

void CDataTypeCombo::Init()
{
	
	CString str;
	int i;
	int iDefault;
	CDataType type;

	ResetContent();

	str.LoadString(IDS_BYTE);
	i = AddString(str);
	type.id = CDataType::typeBYTE;
	m_DataTypeList.AddTail(type);


	str.LoadString(IDS_WORD);
	i = AddString(str);
	type.id = CDataType::typeWORD;
	m_DataTypeList.AddTail(type);

	str.LoadString(IDS_DWORD);
	i = AddString(str);
	type.id = CDataType::typeDWORD;
	m_DataTypeList.AddTail(type);

	iDefault = i;

	str.LoadString(IDS_FLOAT);
	i = AddString(str);
	type.id = CDataType::typeFLOAT;
	m_DataTypeList.AddTail(type);


	str.LoadString(IDS_DOUBLE);
	i = AddString(str);
	type.id = CDataType::typeDOUBLE;
	m_DataTypeList.AddTail(type);


	this->SetCurSel(iDefault);
}


/////////////////////////////////////////////////////////////////////////////
// CDataTypeCombo message handlers
/////////////////////////////////////////////////////////////////////////////
// CFixTypeCombo

CFixTypeCombo::CFixTypeCombo()
{

}

CFixTypeCombo::~CFixTypeCombo()
{
}


BEGIN_MESSAGE_MAP(CFixTypeCombo, CComboBox)
	//{{AFX_MSG_MAP(CFixTypeCombo)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


void CDataTypeCombo::OnSelchange() 
{
	// TODO: Add your control notification handler code here
	m_nCurrentSel = GetCurSel();
}

void CFixTypeCombo::Init()
{

	CString str;
	int i;
	int iDefault;
	CFixType type;

	ResetContent();

	str.LoadString(IDS_NONE);
	i = AddString(str);
	type.id = CFixType::ftNONE;
	m_FixTypeList.AddTail(type);


	str.LoadString(IDS_AUTO_LOCK);
	i = AddString(str);
	type.id = CFixType::ftAUTO;
	m_FixTypeList.AddTail(type);


	iDefault = i;

	str.LoadString(IDS_HOTKEY_FIX);
	i = AddString(str);
	type.id = CFixType::ftHOTKEY;
	m_FixTypeList.AddTail(type);


	//SetItemData(i, CDataType::dsdsd);

	this->SetCurSel(iDefault);
}

CFixType CFixTypeCombo::GetFixType()
{
	int nIndex = GetCurSel();
	return m_FixTypeList.GetAt(m_FixTypeList.FindIndex(nIndex));
}

CDataType CDataTypeCombo::GetDataType()
{
	int nIndex = GetCurSel();
	return m_DataTypeList.GetAt(m_DataTypeList.FindIndex(nIndex));
}

BOOL CDataTypeCombo::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	ResetContent();
	m_DataTypeList.RemoveAll();

	return CComboBox::DestroyWindow();
}

BOOL CFixTypeCombo::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	ResetContent();
	m_FixTypeList.RemoveAll();

	return CComboBox::DestroyWindow();
}

void CDataTypeCombo::SetDataType(CDataType type)
{
	int nIndex, nMax;
	nMax = m_DataTypeList.GetCount();
	for(nIndex = 0; nIndex < nMax; nIndex++)
	{
		if(m_DataTypeList.GetAt(m_DataTypeList.FindIndex(nIndex)).id == type.id)
		{
			SetCurSel(nIndex);
			break;
		}
	}

}

void CFixTypeCombo::SetFixType(CFixType type)
{
	int nIndex, nMax;
	nMax = m_FixTypeList.GetCount();
	for(nIndex = 0; nIndex < nMax; nIndex++)
	{
		if(m_FixTypeList.GetAt(m_FixTypeList.FindIndex(nIndex)).id == type.id)
		{
			SetCurSel(nIndex);
			break;
		}
	}

}
/////////////////////////////////////////////////////////////////////////////
// CEnumCombo

CEnumCombo::CEnumCombo()
{
}

CEnumCombo::~CEnumCombo()
{
}


BEGIN_MESSAGE_MAP(CEnumCombo, CComboBox)
	//{{AFX_MSG_MAP(CEnumCombo)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEnumCombo message handlers

BOOL CEnumCombo::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class

	cs.style |= CBS_DROPDOWNLIST;
	cs.style &= ~CBS_SORT;

	return CComboBox::PreCreateWindow(cs);
}

void CEnumCombo::PreSubclassWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	ModifyStyle(CBS_SORT, CBS_DROPDOWNLIST);
	CComboBox::PreSubclassWindow();
}

BOOL CEnumCombo::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	dwStyle |= CBS_DROPDOWNLIST;
	dwStyle &= ~CBS_SORT;
	
	return CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
}
