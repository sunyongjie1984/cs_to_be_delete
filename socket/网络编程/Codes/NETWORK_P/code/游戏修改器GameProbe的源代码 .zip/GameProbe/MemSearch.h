// MemSearch.h: interface for the CMemSearch class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MEMSEARCH_H__6C8F220F_A19F_11D6_98C2_C99B4152F509__INCLUDED_)
#define AFX_MEMSEARCH_H__6C8F220F_A19F_11D6_98C2_C99B4152F509__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Search.h"
#include "ProcessMem.h"

class CMemSearch : public CSearch  
{
public:
	DWORD GetProcessId();
	void SetProcessId(DWORD dwProcessId);
	BOOL Search(BYTE *pDestBuf, DWORD nBufSize, CSearchResult &result);
	CMemSearch();
	virtual ~CMemSearch();

protected:
	BOOL DoNextSearch();
	DWORD m_dwProcessId;
	void DoFirstSearch();

};

#endif // !defined(AFX_MEMSEARCH_H__6C8F220F_A19F_11D6_98C2_C99B4152F509__INCLUDED_)
