
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the HOTKEY_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// HOTKEY_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.

#define HOTKEY_API __declspec(dllexport)__stdcall

#define WM_HOTKEY_UP		WM_USER + 3000
#define WM_HOTKEY_DOWN		WM_USER + 3001

struct CHotKey
{
	WORD wVirtualKey;
	WORD wModifiers;
};


BOOL HOTKEY_API InstallHotKey(HWND hWnd, CHotKey* pHotKeys, DWORD nCount);
BOOL HOTKEY_API UninstHotKey();