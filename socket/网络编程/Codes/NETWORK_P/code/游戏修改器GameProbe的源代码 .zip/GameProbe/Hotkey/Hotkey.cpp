// Hotkey.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "Hotkey.h"

#define SHARD_SEG_NAME "SHARD_DATA"


#pragma data_seg(SHARD_SEG_NAME)
#pragma bss_seg(SHARD_SEG_NAME)

static BOOL g_fIsInstalled = FALSE;
static HHOOK g_hKeyHook;
static HINSTANCE g_hInstance;
static WORD g_wCurMod = 0;
static HWND g_hWnd;
static CHotKey* g_pHotKeys;
static DWORD g_dwHotKeyCount;

#pragma data_seg()

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{

	g_hInstance = (HINSTANCE)hModule;


    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

LRESULT HOTKEY_API CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	//if(((DWORD)lParam & 0x40000000) && (HC_ACTION == nCode));
	WORD wKey = (WORD)wParam;
	DWORD n;
	
	//������
	if((HIWORD(lParam) & KF_UP) == 0 && HC_ACTION == nCode)
	{
		//if(//g_wCurMod |= HOTKEYF_ALT;
		switch(wParam)
		{
			case VK_CONTROL:
				g_wCurMod |= HOTKEYF_CONTROL;
				break;
			
			case VK_MENU:
				g_wCurMod |= HOTKEYF_ALT;
				break;

			case VK_SHIFT:
				g_wCurMod |= HOTKEYF_SHIFT;
				break;
		}

		for(n = 0; n < g_dwHotKeyCount; n++)
		{
			if(wKey == g_pHotKeys[n].wVirtualKey && g_wCurMod == g_pHotKeys[n].wModifiers)::PostMessage(g_hWnd, WM_HOTKEY_DOWN, (WPARAM)n, 0);
		}
	}

	if((HIWORD(lParam) & KF_UP) > 0 && HC_ACTION == nCode)
	{
		switch(wParam)
		{
			case VK_CONTROL:
				g_wCurMod ^= HOTKEYF_CONTROL;
				break;
			
			case VK_MENU:
				g_wCurMod ^= HOTKEYF_ALT;
				break;

			case VK_SHIFT:
				g_wCurMod ^= HOTKEYF_SHIFT;
				break;
		}
	}

	LRESULT RetVal = CallNextHookEx(g_hKeyHook, nCode, wParam, lParam );

	return  RetVal;
}

BOOL HOTKEY_API InstallHotKey(HWND hWnd, CHotKey* pHotKeys, DWORD nCount)
{
	if(g_fIsInstalled)return FALSE;
	if(pHotKeys == NULL || nCount <= 0)return FALSE;
	
	g_hKeyHook = ::SetWindowsHookEx(WH_KEYBOARD,(HOOKPROC)KeyboardProc, g_hInstance, 0);
	g_fIsInstalled = TRUE;
	g_hWnd = hWnd;
	g_pHotKeys = pHotKeys;
	g_dwHotKeyCount = nCount;

	return TRUE;
}

BOOL HOTKEY_API UninstHotKey()
{
	BOOL bRet;
	
	bRet = ::UnhookWindowsHookEx(g_hKeyHook);
	g_fIsInstalled = FALSE;
	g_hKeyHook = NULL;

	return bRet;
}
/*
BOOL HOOTKEY_API DoPopupDialog(HWND hwndDestWnd, UINT )
{
	DWORD dwThreadId;
	HHOOK hHook;

	dwThreadId = ::GetWindowThreadProcessId(hwndDestWnd, NULL);
	hHook = ::SetWindowsHookEx(WH_GETMESSAGE, (HOOKPROC)GetMsgProc, g_hInstance, dwThreadId);

	return TRUE;
}*/