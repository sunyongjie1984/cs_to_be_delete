// SearchTarget.cpp: implementation of the CSearchTarget class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gameprobe.h"
#include "SearchTarget.h"
#include "searchdefs.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSearchTarget::CSearchTarget()
{

}

CSearchTarget::~CSearchTarget()
{

}

//Throw CError!!!
BOOL CSearchTarget::StrToBin(CString str, LPBYTE pBuf, DWORD &dwSize, CDataType type)
{
	if(pBuf == NULL)
	{
		ASSERT(pBuf != NULL);
		CError err(CError::ERRNO__INVALID_PTR);
		throw(err);
		return FALSE;
		
	}

	CString strPattern;
	int dwTempSize = 0;
	int nStrLen, nPos;
	int i = 0;
	DWORD dwWrittenSize = 0;
	TCHAR ch;
	CString strTemp = str;
	strTemp += "   ";

	nStrLen = strTemp.GetLength();

	while(i < nStrLen)
	{

		ch = strTemp.GetAt(i);
		if(ch == ' ' || ch == '\t')
		{
			i++;
			continue;
		}

		//���ַ����Ŀ�ʼ
		if(ch == '"' )
		{
			nPos = FindTokenTail(i + 1, strTemp, '"');
			if(nPos == -1)
			{
				CError err(CError::ERRNO__INVALID_ENTER);
				throw(err);
				return FALSE;
			}
			strPattern = strTemp.Mid(i + 1, nPos);
			TRACE("strPattern = %s\n", strPattern);
			StrToValue(strPattern, &pBuf[dwTempSize], dwWrittenSize, type);
			dwTempSize += dwWrittenSize;
			i += nPos + 1;
			continue;
		}
		
		if(ch != ' ' && ch != '\t' && ch != '"')
		{

			nPos = FindTokenTail(i, strTemp, ' ');
			if(nPos == -1)
			{
				CError err(CError::ERRNO__INVALID_ENTER);
				throw(err);
				return FALSE;
			}
			strPattern = strTemp.Mid(i, nPos);
			TRACE("strPattern = %s\n", strPattern);
			StrToValue(strPattern, &pBuf[dwTempSize], dwWrittenSize, type);
			dwTempSize += dwWrittenSize;
			i += nPos;
			continue;
		}


		CError err(CError::ERRNO__INVALID_ENTER);
		throw(err);
		return FALSE;

	}

	dwSize= dwTempSize;

	return TRUE;
}

BOOL CSearchTarget::StrToValue(CString str, LPBYTE pBuf, DWORD &dwSize, CDataType type)
{
	//���´����Լ�����ġ���λ��ǰ��Ϊǰ�ᣬ�� Intel x86
	DWORD dwVal;
	DOUBLE dVal;
	FLOAT fVal;

	switch(type.id)
	{
	case CDataType::typeBYTE:
		dwVal = (DWORD)::strtoul(str, NULL, 0);
		dwSize = sizeof(BYTE);
		::memcpy(pBuf, &dwVal, dwSize);
		break;

	case CDataType::typeWORD:
		dwVal = (DWORD)::strtoul(str, NULL, 0);
		dwSize = sizeof(WORD);
		::memcpy(pBuf, &dwVal, dwSize);
		break;

	case CDataType::typeDWORD:
		dwVal = (DWORD)::strtoul(str, NULL, 0);
		dwSize = sizeof(DWORD);
		::memcpy(pBuf, &dwVal, dwSize);
		break;

	case CDataType::typeFLOAT:
		fVal = (FLOAT)::strtod(str, NULL);
		dwSize = sizeof(FLOAT);
		::memcpy(pBuf, &dwVal, dwSize);
		break;

	case CDataType::typeDOUBLE:
		dVal = (DOUBLE)::strtod(str, NULL);
		dwSize = sizeof(DOUBLE);
		::memcpy(pBuf, &dwVal, dwSize);

		break;

	default: 
		CError err(CError::ERRNO__INVALID_DATA_TYPE);
		throw(err);
		return FALSE;
		break;
	}

	return TRUE;

}

//�ҵ��ַ�����δ�������� '"'
int CSearchTarget::FindTokenTail(int nStartPos, CString str, TCHAR ch)
{
	int c = str.GetLength();
	int p = 0;

	for(int i = nStartPos; i < c; i++)
	{
		
		if(str[i] == ch)return p;
		p++;
	}

	return -1;
}