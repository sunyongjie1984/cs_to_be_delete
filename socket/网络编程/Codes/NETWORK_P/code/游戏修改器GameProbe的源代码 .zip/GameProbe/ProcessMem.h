// ProcessMem.h: interface for the CProcessMemMem class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROCESSMEM_H__6C8F2213_A19F_11D6_98C2_C99B4152F509__INCLUDED_)
#define AFX_PROCESSMEM_H__6C8F2213_A19F_11D6_98C2_C99B4152F509__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
class CProcessMem
{
public:
	
	struct CMemoryInfo
	{
		DWORD dwMaxAddress;
		DWORD dwMinAddress;
	};


	void GetMemoryInfo(CMemoryInfo *pMemInfo);
	void Close();
	virtual void Query(PVOID pAddress, MEMORY_BASIC_INFORMATION *mbi);
	virtual BOOL IsUsable(MEMORY_BASIC_INFORMATION mbi);
	virtual BOOL Open(DWORD dwProcessId);
	virtual BOOL Open(PROCESS_INFORMATION pi);
	virtual BOOL SeekToBegin();
	virtual DWORD GetSize();
	virtual BOOL Seek(DWORD dwNewAddress);
	virtual UINT Write(LPVOID lpBuf, UINT nCount);
	virtual UINT Read(LPVOID lpBuf, UINT nCount);
	CProcessMem();
	virtual ~CProcessMem();

protected:
	CMemoryInfo m_MemInfo;
	BOOL m_bOpenFlag;
	PROCESS_INFORMATION m_ProcessInfo;
	SYSTEM_INFO m_SystemInfo;
	LPVOID m_lpBaseAddress;
};


#endif // !defined(AFX_PROCESSMEM_H__6C8F2213_A19F_11D6_98C2_C99B4152F509__INCLUDED_)
