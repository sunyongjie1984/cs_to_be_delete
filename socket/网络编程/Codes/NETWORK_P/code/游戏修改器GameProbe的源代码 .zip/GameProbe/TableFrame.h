#if !defined(AFX_TABLEFRAME_H__72A8F500_A42C_11D6_B0CB_EA1B01074B0D__INCLUDED_)
#define AFX_TABLEFRAME_H__72A8F500_A42C_11D6_B0CB_EA1B01074B0D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TableFrame.h : header file
//
#include "MemFixer.h"
#include "EditItemDlg.h"
#include "Fixer.h"	// Added by ClassView
/////////////////////////////////////////////////////////////////////////////
// CTableFrame dialog

class CTableFrame : public CDialog
{
// Construction
public:
	static CString FixTypeToStr(CFixType fixType);
	static CString TypeToStr(CDataType type);
	void SetTableItemAt(int nIndex, CTableItem item);
	CTableItem GetTableItemAt(int nIndex);
	BOOL NewItem(CTableItem item);
	void DoRemoveItem(int nIndex);
	void RemoveSelected();

	void RemoveAll();
	void DoFix();
	void AddToTable(CTableItem item);

	CTableFrame(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTableFrame)
	enum { IDD = IDD_TABLE_FRAME };
	CListCtrl	m_wndTable;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTableFrame)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	CBCGToolBar m_wndToolBar;
	CMemFixer m_Fixer;


// Implementation
protected:
	int m_nItemCount;

	// Generated message map functions
	//{{AFX_MSG(CTableFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	virtual BOOL OnInitDialog();
	afx_msg void OnTableNew();
	afx_msg void OnTableRemoveAll();
	afx_msg void OnTableRemove();
	afx_msg void OnTableProprety();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABLEFRAME_H__72A8F500_A42C_11D6_B0CB_EA1B01074B0D__INCLUDED_)
