// HexEditDlg.cpp : implementation file
//

#include "stdafx.h"
#include "gameprobe.h"
#include "HexEditDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHexEditDlg dialog


CHexEditDlg::CHexEditDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHexEditDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHexEditDlg)
	//}}AFX_DATA_INIT
}


void CHexEditDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHexEditDlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CHexEditDlg, CDialog)
	//{{AFX_MSG_MAP(CHexEditDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHexEditDlg message handlers

BOOL CHexEditDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
