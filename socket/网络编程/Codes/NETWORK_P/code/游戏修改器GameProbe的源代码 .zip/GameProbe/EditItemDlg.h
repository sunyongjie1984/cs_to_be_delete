#if !defined(AFX_EDITITEMDLG_H__12746D80_A3B0_11D6_B0CB_A16EFCB4D035__INCLUDED_)
#define AFX_EDITITEMDLG_H__12746D80_A3B0_11D6_B0CB_A16EFCB4D035__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EditItemDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEditItemDlg dialog
#include "Fixer.h"
#include "CustomCombo.h"


class CEditItemDlg : public CDialog
{
// Construction
public:
	static INT_PTR CALLBACK DlgProc( HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam );
	void SetData(CTableItem item);
	CTableItem GetData();
	void SetTitle(CString str);
	CEditItemDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEditItemDlg)
	enum { IDD = IDD_EDIT_ITEM_DLG };
	CFixTypeCombo	m_wndFixType;
	CDataTypeCombo	m_wndDataType;
	CString	m_strAddress;
	CString	m_strName;
	CString	m_strTarget;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditItemDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CTableItem m_ItemData;

	// Generated message map functions
	//{{AFX_MSG(CEditItemDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITITEMDLG_H__12746D80_A3B0_11D6_B0CB_A16EFCB4D035__INCLUDED_)
