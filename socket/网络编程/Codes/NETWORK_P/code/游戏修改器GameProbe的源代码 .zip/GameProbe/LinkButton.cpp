// LinkButton.cpp : implementation file
//

#include "stdafx.h"
#include "gameprobe.h"
#include "LinkButton.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLinkButton

CLinkButton::CLinkButton()
{
	m_hCursorHand = ::AfxGetApp()->LoadCursor(IDC_CURSOR_HAND);	
	//m_hCursorDefault = ::AfxGetApp()->LoadCursor(IDC_ARROW);

}

CLinkButton::~CLinkButton()
{
}


BEGIN_MESSAGE_MAP(CLinkButton, CButton)
	//{{AFX_MSG_MAP(CLinkButton)
	ON_WM_MOUSEMOVE()
	ON_WM_SETCURSOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLinkButton message handlers

void CLinkButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your code to draw the specified item
	CDC dc;
	int strx, stry;
	dc.Attach(lpDrawItemStruct->hDC);
	CRect rect(lpDrawItemStruct->rcItem);
	CString str;	
	CSize sz;
	COLORREF crOld;

	CPen pen, *pOldPen;
	pen.CreatePen(PS_SOLID, 1, RGB(0, 0, 255));
	pOldPen = dc.SelectObject(&pen);	

	crOld = dc.GetTextColor();

	dc.SetTextColor(RGB(0 , 0, 255));
	GetWindowText(str);
	sz = dc.GetOutputTextExtent(str);
	strx = rect.left;
	stry = rect.top;
	dc.TextOut(strx, stry, str);
	
	dc.MoveTo(rect.left, stry + sz.cy);
	dc.LineTo(sz.cx - 1, stry + sz.cy);
	
	dc.SelectObject(pOldPen);
	pen.DeleteObject();

	dc.SetTextColor(crOld);

}

void CLinkButton::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRect rect;
	GetClientRect(&rect);	
	if(rect.PtInRect(point))
	{		
		//::SetCursor(m_hCursorHand);
		//::ShowCursor(TRUE);
	}

	CButton::OnMouseMove(nFlags, point);
}


BOOL CLinkButton::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	::SetCursor(m_hCursorHand);
	if (m_hCursorHand != NULL)
	{
		CRect rectClient;
		GetClientRect (rectClient);

		CPoint ptCursor;
		::GetCursorPos (&ptCursor);
		ScreenToClient (&ptCursor);

		if (rectClient.PtInRect (ptCursor))
		{
			::SetCursor (m_hCursorHand);
			return TRUE;
		}
	}

	return CButton::OnSetCursor(pWnd, nHitTest, message);
}
