// GameProbe.h : main header file for the GAMEPROBE application
//

#if !defined(AFX_GAMEPROBE_H__30B6DAF7_A341_11D6_B0CB_F85109371975__INCLUDED_)
#define AFX_GAMEPROBE_H__30B6DAF7_A341_11D6_B0CB_F85109371975__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "edititemdlg.h"
#include "HotKey.h"

/////////////////////////////////////////////////////////////////////////////
// CGameProbeApp:
// See GameProbe.cpp for the implementation of this class
//

class CGameProbeApp;

struct CConfig
{
	TCHAR szConfigFileName;

	struct CHotKeys
	{
		WORD wPopupKey;
		WORD wPopupMods;
	};

	struct CPopupOptions
	{
		BOOL fIsDirectPopup;
		BOOL fPauseGame;
	};
};


CGameProbeApp *GetTheApp();

class CGameProbeApp : public CWinApp//, public CBCGWorkspace
{

public:
	void DisabledFix();
	void EnabledFix();
	void DoReturn();
	void DoPopup();
	void DisableHotKey();
	void EnableHotKey();

	BOOL IsPopuped(){return m_fIsPopuped;}

	CDialog* GetPages(DWORD nIndex);
	CGameProbeApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGameProbeApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CGameProbeApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
protected:
	CHotKey m_HotKeys[3];
	BOOL m_fIsPopuped;
	BOOL m_fIsHotkeyEnabled;
	BOOL m_fIsFixEnabled;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GAMEPROBE_H__30B6DAF7_A341_11D6_B0CB_F85109371975__INCLUDED_)
