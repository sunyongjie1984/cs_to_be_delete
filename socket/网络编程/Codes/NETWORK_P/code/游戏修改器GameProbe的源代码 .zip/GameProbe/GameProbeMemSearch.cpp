// GameProbeMemSearch.cpp: implementation of the CGameProbeMemSearch class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GameProbe.h"
#include "GameProbeMemSearch.h"
#include "mainFrameDlg.h"
#include "SearchFrame.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGameProbeMemSearch::CGameProbeMemSearch()
{	
	m_pwndParent = ((CSearchFrame *)::GetTheApp()->GetPages(CMainFrameDlg::pageSearchFrame));
}

CGameProbeMemSearch::~CGameProbeMemSearch()
{

}

void CGameProbeMemSearch::OnBeginSearch()
{
	m_wndProgressDlg.Create(AfxGetApp()->GetMainWnd());
}

void CGameProbeMemSearch::OnFound(DWORD dwAddress, DWORD dwCount)
{

	if(dwCount > 50)return;
	CString str;
	int i;
	str.Format("0x%08lX", dwAddress);
	i = m_pwndParent->m_wndResultList.AddString(str);
	m_pwndParent->m_wndResultList.SetItemData(i, dwAddress);
}

void CGameProbeMemSearch::OnEndSearch(CSearchResult *pResult)
{
	m_wndProgressDlg.DestroyWindow();
}

void CGameProbeMemSearch::OnProgress(DWORD dwMin, DWORD dwMax, DWORD dwPos)
{
	m_pwndParent->ShowResult(GetResult());
	this->m_wndProgressDlg.SetRange((int)dwMin, (int)dwMax);
	this->m_wndProgressDlg.SetPos((int)dwPos);
}
