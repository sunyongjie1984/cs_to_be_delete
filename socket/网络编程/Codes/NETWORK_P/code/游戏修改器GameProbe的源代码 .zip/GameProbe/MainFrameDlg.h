// MainFrameDlg.h : header file
//

#if !defined(AFX_MAINFRAMEDLG_H__30B6DAF9_A341_11D6_B0CB_F85109371975__INCLUDED_)
#define AFX_MAINFRAMEDLG_H__30B6DAF9_A341_11D6_B0CB_F85109371975__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMainFrameDlg dialog

class CMainFrameDlg : public CDialog
{
public:
	enum CPageName
	{
		pageSearchFrame = 0,
		pageTableFrame = 1
	};


public:
	CDialog *m_pwndPages[2];
	DWORD m_dwCurrentPage;
	DWORD m_dwPageCount;

	CBCGOutlookBar m_wndOutbar;

	CToolBar m_wndMainBar;

// Construction
public:
	CDialog * GetFrame(int nIndex);
	BOOL CreateOutbar();
	BOOL CreatePages();
	void SwitchFrame(DWORD dwPage);
	void SetFrame(int nIndex);
	CMainFrameDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMainFrameDlg)
	enum { IDD = IDD_GAMEPROBE_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrameDlg)
	public:
	virtual BOOL DestroyWindow();	
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support	
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMainFrameDlg)
	virtual BOOL OnInitDialog();
	afx_msg void CMainFrameDlg::OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnMenuSwitchToSearchFrame();
	afx_msg void OnMenuSwitchToTableFrame();	
	//}}AFX_MSG
	afx_msg void OnHotKeyDown(WPARAM wP,LPARAM lP);
	DECLARE_MESSAGE_MAP()	
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRAMEDLG_H__30B6DAF9_A341_11D6_B0CB_F85109371975__INCLUDED_)
