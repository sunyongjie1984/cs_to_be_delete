// GameProbe.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "GameProbe.h"
#include "MainFrameDlg.h"
#include "SearchFrame.h"
#include "EditItemDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CGameProbeApp *GetTheApp()
{
	return (CGameProbeApp *)::AfxGetApp();
}

/////////////////////////////////////////////////////////////////////////////
// CGameProbeApp

BEGIN_MESSAGE_MAP(CGameProbeApp, CWinApp)
	//{{AFX_MSG_MAP(CGameProbeApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGameProbeApp construction

CGameProbeApp::CGameProbeApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
	m_fIsHotkeyEnabled = FALSE;

	//Set popup Hotkey to default value
	m_HotKeys[0].wModifiers = 0;
	m_HotKeys[0].wVirtualKey = VK_MULTIPLY;

}

/////////////////////////////////////////////////////////////////////////////
// The one and only CGameProbeApp object

CGameProbeApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CGameProbeApp initialization

BOOL CGameProbeApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

//	::AfxOleInit();
	m_fIsHotkeyEnabled = FALSE;
	DisableHotKey();
	m_fIsFixEnabled = TRUE;

	CMainFrameDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();


	m_fIsPopuped = TRUE;
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}
	DisableHotKey();
	DisabledFix();
	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

CDialog* CGameProbeApp::GetPages(DWORD nIndex)
{
	CDialog *pDlg;
	pDlg = ((CMainFrameDlg *)AfxGetApp()->GetMainWnd())->m_pwndPages[nIndex];
	return pDlg;
}

void CGameProbeApp::EnableHotKey()
{
	if(m_fIsHotkeyEnabled)return;

	TRACE("The Hot Key was enabled.\n");
	::InstallHotKey(this->GetMainWnd()->GetSafeHwnd(), m_HotKeys, 3);
	m_fIsHotkeyEnabled = TRUE;

	
}

void CGameProbeApp::DisableHotKey()
{	
	if(!m_fIsHotkeyEnabled)return;

	TRACE("The Hot Key was disabled.\n");
	::UninstHotKey();
	m_fIsHotkeyEnabled = FALSE;
}

void CGameProbeApp::DoPopup()
{
	HWND hWnd;
	//HINSTANCE hInst;
	CMainFrameDlg *pwndMainDlg = (CMainFrameDlg *)GetMainWnd();
	CSearchFrame *pwndSearchDlg = (CSearchFrame *)pwndMainDlg->GetFrame(CMainFrameDlg::pageSearchFrame);

	m_fIsPopuped = TRUE;

	hWnd = ::GetForegroundWindow();	

//	pwndMainDlg->ModifyStyle(0, WS_EX_TOPMOST | WS_OVERLAPPED);
	
	pwndMainDlg->ShowWindow(SW_RESTORE);
	//pwndMainDlg->Invalidate();
	pwndMainDlg->SetForegroundWindow();
//	hInst = (HINSTANCE)::GetWindowLong(hWnd, GWL_HINSTANCE);
	//m_wndDlg.Create(IDD_EDIT_ITEM_DLG, CWnd::FromHandle(hWnd));
	//::SetWindowLong(m_wndDlg.GetSafeHwnd(), GWL_HINSTANCE, (LONG)hInst);

	//m_wndDlg.ShowWindow(SW_SHOW);	

	DisableHotKey();

	pwndSearchDlg->RefreshInterface();
	pwndSearchDlg->SelectProcess(hWnd);
}

void CGameProbeApp::DoReturn()
{
	CMainFrameDlg *pwndMainDlg = (CMainFrameDlg *)GetMainWnd();
	CSearchFrame *pwndSearchDlg = (CSearchFrame *)pwndMainDlg->GetFrame(CMainFrameDlg::pageSearchFrame);
	HWND hWnd = pwndSearchDlg->GetSelectedProcess().hWnd;

	
	m_fIsPopuped = FALSE;	
	EnableHotKey();

	pwndMainDlg->ShowWindow(SW_MINIMIZE);
	::ShowWindow(hWnd, SW_SHOW);
	::BringWindowToTop(hWnd);
	::SetForegroundWindow(hWnd);
}

void CGameProbeApp::EnabledFix()
{
	CMainFrameDlg *pwndMainDlg = (CMainFrameDlg *)GetMainWnd();
	CSearchFrame *pwndSearchDlg = (CSearchFrame *)pwndMainDlg->GetFrame(CMainFrameDlg::pageSearchFrame);

	if(!m_fIsPopuped && pwndSearchDlg->IsProcessSelected() && !m_fIsFixEnabled)
	{
		m_fIsFixEnabled = TRUE;	
	}

}

void CGameProbeApp::DisabledFix()
{
	m_fIsFixEnabled = FALSE;
}