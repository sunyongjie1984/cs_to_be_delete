#if !defined(AFX_SELECTTASKDLG_H__C6AD5D00_A380_11D6_B0CB_B506A3193A50__INCLUDED_)
#define AFX_SELECTTASKDLG_H__C6AD5D00_A380_11D6_B0CB_B506A3193A50__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SelectTaskDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSelectTaskDlg dialog

#include "Searchdefs.h"

class CSelectTaskDlg : public CDialog
{
// Construction
public:
	void DeleteAll();
	CDestProcess GetSelectedProcess(){return m_CurrentProcess;}
	CSelectTaskDlg(CWnd* pParent = NULL);   // standard constructor


protected:

	CArray<CDestProcess, CDestProcess> m_Items;


// Dialog Data
	//{{AFX_DATA(CSelectTaskDlg)
	enum { IDD = IDD_SELECT_TASK_DLG };
	CListCtrl	m_wndTaskList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSelectTaskDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CDestProcess m_CurrentProcess;

	// Generated message map functions
	//{{AFX_MSG(CSelectTaskDlg)
	afx_msg void OnFresh();
	virtual BOOL OnInitDialog();
	afx_msg void OnItemChangedTaskList(NMHDR* pNMHDR, LRESULT* pResult);
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SELECTTASKDLG_H__C6AD5D00_A380_11D6_B0CB_B506A3193A50__INCLUDED_)
