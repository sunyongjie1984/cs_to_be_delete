// SearchFrame.cpp : implementation file
//

#include "stdafx.h"
#include "GameProbe.h"
#include "SearchFrame.h"
#include "SelectTaskDlg.h"
#include "TableFrame.h"
#include "MainFrameDlg.h"
#include "HexEditDlg.h"
#include "EditItemDlg.h"
#include "value.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSearchFrame dialog


CSearchFrame::CSearchFrame(CWnd* pParent /*=NULL*/)
	: CDialog(CSearchFrame::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSearchFrame)
	m_bTrendSearch = FALSE;
	//}}AFX_DATA_INIT

	m_nTaskCount = 0;
	m_nCurrentTask = 0;
	m_fIsProcessSelected = FALSE;

	m_Process.dwProcessId = 0;
	m_Process.hWnd = NULL;
	m_Process.strTitle.Empty();
	
}


void CSearchFrame::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSearchFrame)
	DDX_Control(pDX, IDC_SEARCH_FRAME_HELP, m_wndHelp);
	DDX_Control(pDX, IDC_GOTO_EDIT, m_wndGotoEdit);
	DDX_Control(pDX, IDC_TARGET, m_wndTarget);
	DDX_Control(pDX, IDC_PROCESS_INFO, m_wndProcessInfo);
	DDX_Control(pDX, IDC_TIMES, m_wndTimes);
	DDX_Control(pDX, IDC_COUNT, m_wndCount);
	DDX_Control(pDX, IDC_SEARCH_DATA_TYPE, m_wndDataType);
	DDX_Control(pDX, IDC_SEARCH_TASK_LIST, m_wndSearchTaskList);
	DDX_Control(pDX, IDC_RESULT_LIST, m_wndResultList);
	DDX_Check(pDX, IDC_TREND_SEARCH, m_bTrendSearch);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSearchFrame, CDialog)
	//{{AFX_MSG_MAP(CSearchFrame)
	ON_BN_CLICKED(IDC_SEARCH, OnSearch)
	ON_BN_CLICKED(IDC_SELECT_TASK, OnSelectTask)
	ON_BN_CLICKED(IDC_RESET_TASK, OnResetTask)
	ON_BN_CLICKED(IDC_GOTO_EDIT, OnGotoEdit)
	ON_BN_CLICKED(IDC_TREND_SEARCH, OnTrendSearch)
	ON_BN_CLICKED(IDC_ADD_TO_TABLE, OnAddToTable)
	ON_CBN_EDITCHANGE(IDC_TARGET, OnEditchangeTarget)
	ON_BN_CLICKED(IDC_RETURN_TO_PROCESS, OnReturnToProcess)
	ON_WM_SHOWWINDOW()
	ON_LBN_SELCHANGE(IDC_RESULT_LIST, OnSelchangeResultList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSearchFrame message handlers

void CSearchFrame::OnSearch() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	RefreshInterface();

	BYTE buf[1024];
	DWORD nBufSize = 1024;
	CString str;
	CSearchResult result;
	CGameProbeMemSearch *pSearch = (CGameProbeMemSearch *)m_pSearchTasks[0];
	CSearchTarget Target;	

	
	
	GetDlgItem(IDC_TARGET)->GetWindowText(str);
	try
	{
		Target.StrToBin(str, buf, nBufSize, m_wndDataType.GetDataType());
	}
	catch(CError &err)
	{
		if(err.m_nErrorNo == CError::ERRNO__INVALID_ENTER || err.m_nErrorNo == CError::ERRNO__INVALID_DATA_TYPE)
		{
			CString strText, strTitle;
			strText.LoadString(IDS_YOU_ENTERD_DATA_INVALID);
			strTitle.LoadString(IDS_ERROR);
			MessageBox(strText, strTitle, MB_OK | MB_ICONERROR);
			return;
		}
	}
	
	m_wndResultList.ResetContent();
	pSearch->SetProcessId(m_Process.dwProcessId);


	pSearch->Search(buf, nBufSize, result);

	UpdateData(FALSE);
}

BOOL CSearchFrame::NewSearchTask()
{
	CString str;
	str.LoadString(IDS_SEARCH_TASK);
	int i;

	//COMMENT-TEMP_ITEM
	m_pSearchTasks[m_nCurrentTask] = new CGameProbeMemSearch;
	m_pSearchTasks[m_nCurrentTask]->Create("");

	i = m_wndSearchTaskList.AddString(str);
	m_wndSearchTaskList.SetItemData(i, m_nCurrentTask);
	m_wndSearchTaskList.SetSel(m_nCurrentTask);

	m_nTaskCount++;

	RefreshInterface();

	return TRUE;
}

CSearchFrame::~CSearchFrame()
{
	for(int i = 0; i < m_nTaskCount; i++)
		DeleteSearchTask(i);
}

void CSearchFrame::DeleteSearchTask(DWORD nIndex)
{
	m_pSearchTasks[nIndex]->Release();
	delete m_pSearchTasks[nIndex];
}

void CSearchFrame::OnSelectTask() 
{
	// TODO: Add your control notification handler code here
	CSelectTaskDlg dlg;
	if(dlg.DoModal() == IDOK)
	{
		m_Process = dlg.GetSelectedProcess();
		m_fIsProcessSelected = TRUE;
		
	}

	RefreshInterface();
}

BOOL CSearchFrame::OnInitDialog() 
{
	CDialog::OnInitDialog();	
	// TODO: Add extra initialization here
	NewSearchTask();	

	

	m_wndDataType.Init();

	m_wndCount.bkColor(0);
	m_wndCount.textColor(RGB(0, 255, 0));;
	m_wndTimes.bkColor(0);
	m_wndTimes.textColor(RGB(0, 255, 0));
	m_wndProcessInfo.bkColor(0);
	m_wndProcessInfo.textColor(RGB(255, 255, 0));

	RefreshInterface();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSearchFrame::OnResetTask() 
{
	m_pSearchTasks[0]->Reset();

	m_wndResultList.ResetContent();	
	ShowResult(m_pSearchTasks[0]->GetResult());

	RefreshInterface();
	// TODO: Add your control notification handler code here
	
}

void CSearchFrame::ShowResult(const CSearchResult *pResult)
{
	CString str;
	str.Format("%03u", pResult->dwTimes);
	GetDlgItem(IDC_TIMES)->SetWindowText(str);

	str.Format("%09u", pResult->dwCount);
	GetDlgItem(IDC_COUNT)->SetWindowText(str);

}

void CSearchFrame::OnGotoEdit() 
{
	// TODO: Add your control notification handler code here
	CHexEditDlg dlg;
	dlg.DoModal();
}

void CSearchFrame::ShowProcessInfo()
{
	CString str;
	str.Format(IDS_DEST_PROCESS, m_Process.dwProcessId, m_Process.strTitle);
	GetDlgItem(IDC_PROCESS_INFO)->SetWindowText(str);
}

void CSearchFrame::OnTrendSearch() 
{
	// TODO: Add your control notification handler code here
	UpdateData();

	RefreshInterface();
	UpdateData(FALSE);
}

void CSearchFrame::OnAddToTable() 
{
	// TODO: Add your control notification handler code here
	UpdateData();


	CString str;
	CEditItemDlg dlg;
	CMainFrameDlg *pMainDlg = (CMainFrameDlg *)GetTheApp()->GetMainWnd();
	CTableFrame* pTabDlg = (CTableFrame *)pMainDlg->m_pwndPages[CMainFrameDlg::pageTableFrame];

	CTableItem item;

	item.dwAddress = m_wndResultList.GetItemData(m_wndResultList.GetCurSel());
	item.Value.SetValue(0);

	str.LoadString(IDS_NAME);
	::strcpy(item.szName, str);
	
	pMainDlg->SwitchFrame(CMainFrameDlg::pageTableFrame);
	pTabDlg->NewItem(item);
	pMainDlg->SwitchFrame(CMainFrameDlg::pageSearchFrame);

}

void CSearchFrame::RefreshInterface()
{
	UpdateData();

	m_wndSearchTaskList.SetCurSel(m_nCurrentTask);

	if(GetTheApp()->IsPopuped() && m_fIsProcessSelected)GetDlgItem(IDC_RETURN_TO_PROCESS)->EnableWindow();
	else GetDlgItem(IDC_RETURN_TO_PROCESS)->EnableWindow(FALSE);

	if(m_bTrendSearch)
	{
		m_wndDataType.EnableWindow(FALSE);
		m_wndTarget.EnableWindow(FALSE);
 
	}
	else
	{
		m_wndDataType.EnableWindow();
		m_wndTarget.EnableWindow();
	}

	if(m_nTaskCount <= 1)GetDlgItem(IDC_REMOVE_TASK)->EnableWindow(FALSE);
	else GetDlgItem(IDC_REMOVE_TASK)->EnableWindow();

	RefreshTarget();
	ShowProcessInfo();
	ShowResult(m_pSearchTasks[0]->GetResult());//{$COMMENT-TEMP_ITEM}


	UpdateData(FALSE);
}

BOOL CSearchFrame::IsTargetValid()
{
	UpdateData();

	CString str;
	m_wndTarget.GetWindowText(str);
	if(str.IsEmpty())return FALSE;

	return TRUE;

}

void CSearchFrame::OnEditchangeTarget() 
{
	// TODO: Add your control notification handler code here
	RefreshTarget();	
}

void CSearchFrame::RefreshTarget()
{
	if(m_fIsProcessSelected && IsTargetValid())
	{
		GetDlgItem(IDC_SEARCH_START)->EnableWindow();
	}
	else
	{
		GetDlgItem(IDC_SEARCH_START)->EnableWindow(FALSE);
	}

}

void CSearchFrame::SelectProcess(HWND hWnd)
{
	m_Process.hWnd = hWnd;
	::GetWindowThreadProcessId(hWnd, &m_Process.dwProcessId);
	CWnd::FromHandle(hWnd)->GetWindowText(m_Process.strTitle);
	m_fIsProcessSelected = TRUE;

	RefreshInterface();
}


void CSearchFrame::OnReturnToProcess() 
{
	// TODO: Add your control notification handler code here
	RefreshInterface();
	GetTheApp()->DoReturn();
}

void CSearchFrame::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	RefreshInterface();
}



void CSearchFrame::OnSelchangeResultList() 
{
	// TODO: Add your control notification handler code here
	RefreshInterface();
}
