// ProcessMem.cpp: implementation of the CProcessMemMem class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GameProbe.h"
#include "ProcessMem.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProcessMem::CProcessMem()
{	

	SYSTEM_INFO m_SystemInfo;
	::GetSystemInfo(&m_SystemInfo);
	m_bOpenFlag = FALSE;

//	::GetVersionEx(&vi);
/*
	if(vi.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS) //�������ϵͳ�� win95/98
	{
		m_MemInfo.dwMinAddress = 0x00400000; 
		m_MemInfo.dwMaxAddress = 0x7FFFFFFF;

	}
	else
	{
		m_MemInfo.dwMinAddress = 0x00000000;
		m_MemInfo.dwMaxAddress = 0x7FFFFFFF;
	}
*/	
	m_MemInfo.dwMaxAddress = (DWORD)m_SystemInfo.lpMaximumApplicationAddress;
	m_MemInfo.dwMinAddress = (DWORD)m_SystemInfo.lpMinimumApplicationAddress;
}

CProcessMem::~CProcessMem()
{

}

UINT CProcessMem::Read(LPVOID lpBuf, UINT nCount)
{
	DWORD dwRetVal;

	if(!m_bOpenFlag)return FALSE;

	if(!::ReadProcessMemory(m_ProcessInfo.hProcess, m_lpBaseAddress, lpBuf, nCount, &dwRetVal))
	{
		//CError e("ProcessMemory: ReadProcessMemory");
		//THROW(&e);
	}
	return dwRetVal;

}

UINT CProcessMem::Write(LPVOID lpBuf, UINT nCount)
{
	DWORD dwRetVal;

	if(!m_bOpenFlag)return FALSE;

	if(!::WriteProcessMemory(m_ProcessInfo.hProcess, m_lpBaseAddress, lpBuf, nCount, &dwRetVal))
	{
		//CError e("Writing Process memory");
		//THROW(&e);
	}

	return dwRetVal;
}

BOOL CProcessMem::Seek(DWORD dwNewAddress)
{
	if(!m_bOpenFlag)return FALSE;
	m_lpBaseAddress = (LPVOID)dwNewAddress;
	return TRUE;
}

DWORD CProcessMem::GetSize()
{	
	return m_MemInfo.dwMaxAddress - m_MemInfo.dwMinAddress;
}

BOOL CProcessMem::SeekToBegin()
{
	if(!m_bOpenFlag)return FALSE;

	m_lpBaseAddress = (LPVOID)m_MemInfo.dwMinAddress;
	return TRUE;
}

BOOL CProcessMem::Open(PROCESS_INFORMATION pi)
{
	if(pi.hProcess == NULL || pi.hThread == NULL)return FALSE;

	m_ProcessInfo = pi;

	m_bOpenFlag = TRUE;

	return TRUE;
}

BOOL CProcessMem::Open(DWORD dwProcessId)
{
	HANDLE hProcess;
	hProcess = ::OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwProcessId);
	if(hProcess == NULL)return FALSE;
	m_ProcessInfo.hProcess = hProcess;
	m_ProcessInfo.dwProcessId = dwProcessId;
	m_bOpenFlag = TRUE;

	return TRUE;

}

BOOL CProcessMem::IsUsable(MEMORY_BASIC_INFORMATION mbi)
{
	if(!m_bOpenFlag)return FALSE;
	//if((mbi.AllocationProtect == PAGE_READWRITE) || (mbi.AllocationProtect == PAGE_EXECUTE_READWRITE))
	//	if(mbi.State == MEM_COMMIT)return TRUE;
	//if((mbi.State == MEM_COMMIT) && (mbi.AllocationProtect == PAGE_READWRITE))return TRUE;

	if(mbi.State == MEM_COMMIT)if(mbi.Protect == PAGE_READWRITE || mbi.Protect == PAGE_EXECUTE_READWRITE)return TRUE;


	return FALSE;
}

void CProcessMem::Query(PVOID pAddress, MEMORY_BASIC_INFORMATION *pMbi)
{
	if(!m_bOpenFlag || pMbi == NULL)return;
	::VirtualQueryEx(m_ProcessInfo.hProcess, pAddress, pMbi, sizeof(MEMORY_BASIC_INFORMATION));

}

void CProcessMem::Close()
{
	::CloseHandle(this->m_ProcessInfo.hProcess);
}

void CProcessMem::GetMemoryInfo(CMemoryInfo *pMemInfo)
{
	::memcpy(pMemInfo, &m_MemInfo, sizeof(m_MemInfo));
}
