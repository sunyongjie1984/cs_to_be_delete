// SearchTarget.h: interface for the CSearchTarget class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SEARCHTARGET_H__9B1C8920_A74C_11D6_B0CB_B35DF823685F__INCLUDED_)
#define AFX_SEARCHTARGET_H__9B1C8920_A74C_11D6_B0CB_B35DF823685F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Value.h"

class CSearchTarget  
{
public:
	CSearchTarget();
	virtual ~CSearchTarget();

public:

	static BOOL StrToValue(CString str, LPBYTE pBuf, DWORD &dwSize, CDataType type);
	static BOOL StrToBin(CString str, LPBYTE pBuf, DWORD &dwSize, CDataType type);
	static int FindTokenTail(int nStartPos, CString str, TCHAR ch);

protected:
	
};

#endif // !defined(AFX_SEARCHTARGET_H__9B1C8920_A74C_11D6_B0CB_B35DF823685F__INCLUDED_)
