// shit.h : main header file for the SHIT application
//

#if !defined(AFX_SHIT_H__ED91E6E5_56CF_11D7_9D61_5254AB256237__INCLUDED_)
#define AFX_SHIT_H__ED91E6E5_56CF_11D7_9D61_5254AB256237__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CShitApp:
// See shit.cpp for the implementation of this class
//

class CShitApp : public CWinApp
{
public:
	CShitApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShitApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CShitApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHIT_H__ED91E6E5_56CF_11D7_9D61_5254AB256237__INCLUDED_)
