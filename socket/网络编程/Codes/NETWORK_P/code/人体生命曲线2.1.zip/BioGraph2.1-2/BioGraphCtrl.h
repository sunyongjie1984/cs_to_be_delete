
#pragma once

#define WM_BIO_SELECTCHANGING	WM_USER+1000
#define WM_BIO_SELECTCHANGED	WM_USER+1001

class BioGraphCtrl : public CWnd
{
public:
	CTime	m_bornDate;
	CTime	m_curDate;
	CTime	m_startDate;
	CTime	m_endDate;

	COLORREF m_topColor;
	COLORREF m_bottomColor;

	COLORREF m_focusColor;
	CTime m_focusDate;

public:
	void SetBornDate (CTime bornDate);
	CTime GetBornDate ();

	void SetCurDate (CTime curDate);
	CTime GetCurDate ();

	void SetStartDate (CTime startDate);
	CTime GetStartDate ();

	void SetEndDate (CTime endDate = NULL);
	CTime GetEndDate ();

	void SetFocusDate (CTime focusDate);
	CTime GetFocusDate ();

	void SetTopColor(COLORREF topColor);
	COLORREF GetTopColor();

	void SetBottomColor(COLORREF bottomColor);
	COLORREF GetBottomColor();

	void SetFocusColor(COLORREF focusColor);
	COLORREF GetFocusColor();

	float Eval (CTime testDate, int cycle);
	CString EvalString(CTime testDate);

	void GotoNextMonth();
	void GotoPrevMonth();
	void GotoCurrentMonth();
	//���ű�������
	void PlayMusic ();

protected:
	//��������ɫ����
	void DrawBackground (CDC* pDC);

	//������	
	void DrawGrid (CDC* pDC);

	void DrawGuage (CDC* pDC);

	//����������
	void DrawLifeCurve (CDC* pDC);
	void DrawLifeCurve (CDC* pDC, int cycle, float range, int width, COLORREF color);

	//
	void DrawLabel (CDC* pDC);

	//����������
	void DrawFocus (CDC* pDC);

	//����ʱ���
	int CalcDays ();


public:

	// ��д
public:

	// ʵ��
public:
	BioGraphCtrl();
	virtual ~BioGraphCtrl();

protected:

	// ���ɵ���Ϣӳ�亯��
protected:

public:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);

};
