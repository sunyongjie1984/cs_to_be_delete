// BioGraph.h : main header file for the BIOGRAPH application
//

#if !defined(AFX_BIOGRAPH_H__5A2945E4_B3F6_11D7_B3D1_000021918671__INCLUDED_)
#define AFX_BIOGRAPH_H__5A2945E4_B3F6_11D7_B3D1_000021918671__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CBioGraphApp:
// See BioGraph.cpp for the implementation of this class
//

class CBioGraphApp : public CWinApp
{
public:
	CBioGraphApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBioGraphApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CBioGraphApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BIOGRAPH_H__5A2945E4_B3F6_11D7_B3D1_000021918671__INCLUDED_)
