// BioGraphDlg.h : header file
//

#if !defined(AFX_BIOGRAPHDLG_H__2CBAF766_B3FC_11D7_B3D1_000021918671__INCLUDED_)
#define AFX_BIOGRAPHDLG_H__2CBAF766_B3FC_11D7_B3D1_000021918671__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BioGraphCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CBioGraphDlg dialog

class CBioGraphDlg : public CDialog
{
// Construction
public:
	CBioGraphDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CBioGraphDlg)
	enum { IDD = IDD_BIOGRAPH_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBioGraphDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
	CTime m_bornDate;
	CTime m_TestDate;
	CString m_evalText;


	//����ı�
	void OutText(int x, int y, CString str, long textColor,long bkColor,CFont *font =NULL);

protected:
	HICON m_hIcon;
	BioGraphCtrl* m_bioGraph;

	// Generated message map functions
	//{{AFX_MSG(CBioGraphDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBnClickedPrevmonth();
	afx_msg void OnBnClickedCurrentmonth();
	afx_msg void OnBnClickedNextmonth();
	afx_msg void OnDtnDatetimechangeBornDatetime(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDtnDatetimechangeTestDatetime(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	virtual BOOL OnWndMsg(UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pResult);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BIOGRAPHDLG_H__2CBAF766_B3FC_11D7_B3D1_000021918671__INCLUDED_)
