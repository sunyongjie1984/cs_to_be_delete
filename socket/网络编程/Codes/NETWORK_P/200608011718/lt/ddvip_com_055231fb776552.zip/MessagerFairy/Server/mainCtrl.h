//mainCtrl.h
///////////////////////////////////////////////////////////////////////////////
#ifndef _MAIN_CTRL_H_
#define _MAIN_CTRL_H_

///////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <conio.h>
#include <io.h>

#include "ServerTunnel.h"
#include "TableInfoMgr.h"
///////////////////////////////////////////////////////////////////////////////

/*/////////////////////////////////////////////////////////////////////////* /
#if defined(__cplusplus)
extern "C" {
#endif
/*/////////////////////////////////////////////////////////////////////////*/
class CMainCtrl
{
public:
	CMainCtrl();
	~CMainCtrl();

public:
	int StartServer();
	int StopServer();

	void processNetEvent(IN SOCKET hSocket, 
						IN ETransportEvent eEvent, 
						IN void *pRecvMsg, IN unsigned long nDataLen);

public:
	CTableInfoMgr *GetClientConnectionTable();

private:
	CServerTunnel m_tServerTunnel;

	CTableInfoMgr m_tClientConnections;

private:
	void processLoginRequest(void *pLoginInfo);
	void processDiconnection(unsigned long ulUserID);
	void processChatMessageRequest(void *pChatMessage);

private:
	int VerifyUserLoginInfo(void *pLoginInfo);
	void sendMessageToAllUsers(void *pHeader, void *pDataBuf, unsigned long ulDataLen);
	
};


/*/////////////////////////////////////////////////////////////////////////* /
#if defined(__cplusplus)
}
#endif
/*/////////////////////////////////////////////////////////////////////////*/
#endif	/*_MAIN_CTRL_H_*/