/*******************************************************************************
RichEditCtrlEx.h
*******************************************************************************/
#if !defined(AFX_RICHEDITCTRLEX_H__0853A768_1700_4BE3_827A_A2F33AD6EFE4__INCLUDED_)
#define AFX_RICHEDITCTRLEX_H__0853A768_1700_4BE3_827A_A2F33AD6EFE4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// richeditctrlex.h : header file
//
#define MAX_LINECOUNT	(20000)
/////////////////////////////////////////////////////////////////////////////
// CRichEditCtrlEx window

class CRichEditCtrlEx : public CRichEditCtrl
{
// Construction
public:
	CRichEditCtrlEx();

// Attributes
public:

// Operations
public:
	void OnCopyEx();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRichEditCtrlEx)
	//}}AFX_VIRTUAL

// Implementation
public:
	
	virtual ~CRichEditCtrlEx();

	// Generated message map functions
protected:
	//{{AFX_MSG(CRichEditCtrlEx)	
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnCopy();
	afx_msg void OnCut();
	afx_msg void OnPaste();
	afx_msg void OnSelectAll();
	afx_msg void OnUndo();
	afx_msg void OnClear();
	afx_msg void OnSelectFont();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
public:	//��������
	BOOL AppendText(LPCTSTR lpszText, 
					COLORREF clrText=::GetSysColor(COLOR_WINDOWTEXT), 
					BOOL bAddDateTime = TRUE);

private:
	void UnSelect();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RICHEDITCTRLEX_H__0853A768_1700_4BE3_827A_A2F33AD6EFE4__INCLUDED_)
