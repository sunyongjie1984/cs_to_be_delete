//ServerTunnel.h
///////////////////////////////////////////////////////////////////////////////
#ifndef _SERVER_TUNNEL_H_
#define _SERVER_TUNNEL_H_

/*/////////////////////////////////////////////////////////////////////////* /
#if defined(__cplusplus)
extern "C" {
#endif
/*/////////////////////////////////////////////////////////////////////////*/
#include "netMain.h"
#include "protocolhdr.h"
#include "struct_def.h"
/////////////////////////////////////////////////////////////////////////////
class CServerTunnel : public CTransportImpl
{
public:
	CServerTunnel();
	virtual ~CServerTunnel();

public:
	int net_OpenSocket(IN ETransportType eType, 							
							IN unsigned short usPort, 
							IN LPTRANSPORT_EVENT eventHandler, 							
							void *pContext);
	void net_CloseSocket();
	int net_Connect(IN unsigned long ulIPValue, IN unsigned short usPort);
	unsigned long net_Send(IN SOCKET hSocket, 
							IN void *pHeader, 
							IN void *pMessage, 
							IN unsigned long ulDataLen);

public:
	LPTRANSPORT_EVENT m_eventHandler;
	void *m_pContext;


private:
	SOCKET m_hSocket;
};


/*/////////////////////////////////////////////////////////////////////////* /
#if defined(__cplusplus)
}
#endif
/*/////////////////////////////////////////////////////////////////////////*/
#endif	/*_SERVER_TUNNEL_H_*/