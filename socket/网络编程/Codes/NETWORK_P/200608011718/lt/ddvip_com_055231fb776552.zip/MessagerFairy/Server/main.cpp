//main.cpp
///////////////////////////////////////////////////////////////////////////////
#include "mainCtrl.h"

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
static CMainCtrl g_tMainCtrl;
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

int main(int agc, char *agv[])
{
	int nResult = Transport_Init();
	if( TRANSPORT_OK != nResult)
	{
		printf("Transport_Init failed!\n");
		
		return 1;
	}

	nResult = g_tMainCtrl.StartServer();

	if( TRANSPORT_OK != nResult )
	{
		printf("StartServer failed!\n");

		return 1;
	}

	printf("\nPress <Esc> to Stop Server...\n\n\n");
	while(getch() != 27) Sleep(50);//ESC

	g_tMainCtrl.StopServer();
	nResult = Transport_UnInit();

	printf("\nServer is Stopped!\n");
	printf("\nPress <Enter> to Exit...\n\n");
	while(getch() != 13) Sleep(50);//Enter
	
	return 0;
}
/////main()////////////////////////////////////////