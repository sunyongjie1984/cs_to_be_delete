//data_def.h
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
#ifndef _DATA_DEF_H_
#define _DATA_DEF_H_

///////////////////////////////////////////////////////////////////////////////
#if defined(__cplusplus)
extern "C" {
#endif
	
///////////////////////////////////////////////////////////////////////////////
#include <winsock2.h>
#include <process.h>
///////////////////////////////////////////////////////////////////////////////
#ifndef IMPORTS
#define DLLENTRY __declspec(dllexport)
#else
#define DLLENTRY __declspec(dllimport)
#endif

///////////////////////////////////////////////////////////////////////////////
typedef int TransportBool;
typedef int TransportStatus;
typedef char TransportData;
typedef unsigned long TransportLength;
typedef int TransportError;
typedef unsigned long ULong;
typedef unsigned short UShort;
typedef unsigned long TransportHandle;

///////////////////////////////////////////////////////////////////////////////
typedef enum _tagTransportBool
{
	TRANSPORT_FALSE = 0,
	TRANSPORT_TRUE = 1
		
} ETransportBool;

typedef enum _tagTransportStatus
{
	TRANSPORT_UNKNOWN = -2,
	TRANSPORT_ERROR = -1,
	TRANSPORT_OK = 0,
		
} ETransportStatus;

typedef enum _tagTransportType
{
	Transport_Undefined,
	Transport_Client,
	Transport_Server
		
} ETransportType;


typedef enum _tagTransportEvents
{
	Transport_ReadEv,
	Transport_WriteEv,
	Transport_AcceptEv,
	Transport_ConnectEv,
	Transport_CloseEv
		
} ETransportEvent;


typedef struct _tagTransportAddress
{
	ULong	ip;    /* 4 byte IP address, network format */
	UShort	port;  /* 2 byte port number, host format */
} TransportAddress;

///////////////////////////////////////////////////////////////////////////////
////////////////////////define callback functions//////////////////////////////
/*net event callback*/
typedef void (*LPTRANSPORT_EVENT)(IN SOCKET hSocket, IN ETransportEvent eEvent, 
								  IN void *pDataBuf, IN unsigned long nDataLen, 
								  IN int nError, IN void *pContext);

/*obtain packet size from packet header callback*/
typedef void (*LPTRANSPORT_GETDATABUFLEN)(IN SOCKET hSocket, IN void *pHeaderBuf, 
										  OUT unsigned long *nDataLen);

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
TransportStatus Transport_Init();
TransportStatus Transport_UnInit();
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
#if defined(__cplusplus)
}
#endif
///////////////////////////////////////////////////////////////////////////////
#endif	/*_DATA_DEF_H_*/