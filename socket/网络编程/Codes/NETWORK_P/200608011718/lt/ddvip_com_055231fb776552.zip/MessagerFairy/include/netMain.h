//netMain.h
/////////////////////////////////////////////////////////////////////////////
#ifndef _NET_MAIN_H_
#define _NET_MAIN_H_

/////////////////////////////////////////////////////////////////////////////
/*/////////////////////////////////////////////////////////////////////////*/
#if defined(__cplusplus)
extern "C" {
#endif
/*/////////////////////////////////////////////////////////////////////////*/
#include "data_def.h"

/////////////////////////////////////////////////////////////////////////////
#define MAX_HOSTNAME_LEN	(256)
#define MAX_IPADDRESS_LEN	(16)
/////////////////////////////////////////////////////////////////////////////
class CTransport;

class CTransportImpl
{
public:
	CTransportImpl();
	virtual ~CTransportImpl();

	int net_Init();
	int net_UnInit();
	virtual SOCKET net_OpenSocket(IN ETransportType eType, 									
									IN unsigned short usPort, 
									IN LPTRANSPORT_EVENT eventHandler, 
									IN LPTRANSPORT_GETDATABUFLEN cbHandler, 
									IN unsigned long ulHeaderLen, 
									void *pContext);
	virtual void net_CloseSocket();
	virtual int net_Connect(IN unsigned long ulIPValue, IN unsigned short usPort);
	virtual unsigned long net_Send(IN SOCKET hSocket, 
									IN void *pMessage, 
									IN unsigned long ulDataLen);

public:
	virtual unsigned long net_GetLocalHostIp(OUT char *pIpAddress, OUT char *pHostName);

private:
	CTransport *m_ptTransport;
};	
/*/////////////////////////////////////////////////////////////////////////*/
#if defined(__cplusplus)
}
#endif
/*/////////////////////////////////////////////////////////////////////////*/
#endif	/*_NET_MAIN_H_*/