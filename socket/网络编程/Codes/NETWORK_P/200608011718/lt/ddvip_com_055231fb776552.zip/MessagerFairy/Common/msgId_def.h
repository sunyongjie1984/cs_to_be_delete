//msgId_def.h
///////////////////////////////////////////////////////////////////////////////
typedef enum _tagMESSAGE_ID
{
	/*Message Request or Response*/
	MSG_LOGIN_REQ,
	MSG_LOGIN_RESP,
	MSG_LOGOUT_REQ,
	MSG_LOGOUT_RESP,

	MSG_USERINFO_REQ,
	MSG_USERINFO_RESP,

	MSG_CHATMESSAGE_REQ,
	MSG_CHATMESSAGE_RESP,

} EMESSAGE_ID;


typedef enum _tagLOGIN_RESULT
{
	LOGIN_RESULT_FAILED = -1,
	LOGIN_RESULT_SUC = 0,
	LOGIN_RESULT_MULTI,
	LOGIN_RESULT_NAMERROR,
	LOGIN_RESULT_PWERROR,
	

} ELOGIN_RESULT;

typedef enum _tagUSER_STATUS
{
	USER_STATUS_UNKNOWN = -1,
	USER_STATUS_ONLINE = 0,
	USER_STATUS_OFFLINE,
	USER_STATUS_BUSY,
	USER_STATUS_INGAME,
	

} EUSER_STATUS;

///////////////////////////////////////////////////////////////////////////////