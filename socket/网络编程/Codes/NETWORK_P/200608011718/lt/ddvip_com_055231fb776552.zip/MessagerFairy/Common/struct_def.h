//struct_def.h
///////////////////////////////////////////////////////////////////////////////
#ifndef _STRUCT_DEF_H_
#define _STRUCT_DEF_H_

/*/////////////////////////////////////////////////////////////////////////*/
#if defined(__cplusplus)
extern "C" {
#endif
/*/////////////////////////////////////////////////////////////////////////*/
#include <windef.h>

#include "msgId_def.h"
/*/////////////////////////////////////////////////////////////////////////*/
#define MAX_NAME_LEN	(30)
/*/////////////////////////////////////////////////////////////////////////*/
typedef struct _tagUSER_INFO_STRU
{
	DWORD	dwUserID;
	BYTE	byStatus;
	char	szUserName[MAX_NAME_LEN+1];
	char	szPassword[MAX_NAME_LEN+2];

} TUSER_INFO_STRU;

typedef struct _tagUSER_GAME_INFO_STRU
{
	DWORD	dwConnectionID;
	TUSER_INFO_STRU tUserInfo;

} TUSER_GAME_INFO_STRU;

typedef struct _tagUSERLIST_INFO_STRU
{
	DWORD	dwConnectionID;
	BYTE	byStatus;
	char	szUserName[MAX_NAME_LEN+1];

} TUSERLIST_INFO_STRU;


/*/////////////////////////////////////////////////////////////////////////*/
typedef struct _tagCOMMON_MSG_STRU
{
	DWORD	dwConnectionID;
	WORD	wMessageId;
	WORD	wSubMessageId;

} TCOMMON_MSG_STRU;

typedef struct _tagLOGIN_STRU
{
	TCOMMON_MSG_STRU	tCommonMsg;

	TUSER_INFO_STRU		tUserInfo;

} TLOGIN_STRU;

typedef struct _tagLOGIN_RESULT_STRU
{
	TCOMMON_MSG_STRU	tCommonMsg;

	DWORD	dwUserID;
	BYTE	byResult;
	BYTE	byStatus;
	WORD	wUserCount;

} LOGIN_RESULT_STRU;

typedef struct _tagCHAT_MESSAGE_STRU
{
	TCOMMON_MSG_STRU	tCommonMsg;

	DWORD dwFromUserID;
	DWORD dwToUserID;

	char szFromUserName[MAX_NAME_LEN];

	WORD wMessageLen;
	BYTE byFileContent[2];

} TCHAT_MESSAGE_STRU;

/*/////////////////////////////////////////////////////////////////////////*/
#if defined(__cplusplus)
}
#endif
/*/////////////////////////////////////////////////////////////////////////*/
#endif	/*_STRUCT_DEF_H_*/