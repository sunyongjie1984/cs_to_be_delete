//TableInfoMgr.h
/////////////////////////////////////////////////////////////////////
/********************************************************************
��Ҫ�Ƕ�ȫ����Ϣ�Ĺ���
********************************************************************/
#ifndef _TABLEINFO_MGR_H_
#define _TABLEINFO_MGR_H_
/////////////////////////////////////////////////////////////////////
#include "mutexlock.h"
/////////////////////////////////////////////////////////////////////
template<typename Key, typename Value >	class CList;
typedef CList<long, void *>				LongVoidLists;
/////////////////////////////////////////////////////////////////////
class CTableInfoMgr
{
public:
	CTableInfoMgr();	
	virtual ~CTableInfoMgr();

public:
	BOOL Init(int nElemSize, char *szTableName);
	BOOL End();
	
	int GetElementSize();
	const char *GetTableName();

	long GetItemCount();
	void *GetItemValue(long lIndex);

	BOOL Add(long lKey, void *pInfo);
	BOOL Modify(long lKey, void *pInfo);
	BOOL Delete(long lKey);
	BOOL DeleteAll();
	void *Find(long lKey);

private:
	int m_nElementSize;
	char m_szTableName[64];
	LongVoidLists *m_ptTableInfo;
};
/////////////////////////////////////////////////////////////////////
#endif	//_TABLEINFO_MGR_H_
