#define _WIN32_WINNT 0x400 // make sure windows.h includes winsock 2, not 1

#include <windows.h>
#include <iostream>
#include <string>

using namespace std;
