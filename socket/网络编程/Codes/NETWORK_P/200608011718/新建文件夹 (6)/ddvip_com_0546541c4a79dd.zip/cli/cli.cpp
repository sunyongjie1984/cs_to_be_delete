#include "stdafx.h"


int main( int argc, char *argv[] )
{
	clog << "Move along, people ... nothing to see here ... (yet, that is.)" <<
		endl << "But you _can_ use a telnet client to connect to the test server." <<
		endl << endl << "Sorry," << endl << "Felix." << endl;

	return 1;
}
