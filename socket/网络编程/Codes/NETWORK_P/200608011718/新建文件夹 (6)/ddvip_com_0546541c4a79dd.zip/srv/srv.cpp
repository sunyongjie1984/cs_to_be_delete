#include "stdafx.h"
#include "getopt.h"
#include "worker.h"


const int MAXSOCKETS = 5000;
HANDLE suicideEvent = 0;
SOCKET listener = INVALID_SOCKET; // our listener socket. Duh!
int concurrency = 0;


typedef vector< HANDLE > HL;
typedef HL::iterator HLI;


#define err(c,f) _err( c, #c, f, __FILE__, __LINE__ )
#define err2(c,f,t) _err( c, #c, f, __FILE__, __LINE__, t )


void _err( bool cond, const char *strCond, const char *func,
	const char *file, int line, const char *text = NULL )
{
	DWORD gle;
	char buf[2048];

	if ( ! cond )
		return;

	gle = GetLastError();

	_snprintf( buf, sizeof buf, "%s(%d): %s, gle = %lu\n  %s%s%s",
		file, line, func, gle, strCond, text == NULL? "": "; ", text == NULL? "": text );

	clog << buf << endl;

	cin.get();

	exit( 1 );
}


BOOL __stdcall ConsoleHandler( DWORD ConsoleEvent )
{
	switch ( ConsoleEvent )
	{
	case CTRL_LOGOFF_EVENT:		// FALL THROUGH
	case CTRL_C_EVENT:			// FALL THROUGH
	case CTRL_BREAK_EVENT:		// FALL THROUGH
	case CTRL_CLOSE_EVENT:		// FALL THROUGH
	case CTRL_SHUTDOWN_EVENT:
		if ( suicideEvent != 0 )
		{
			SetEvent( suicideEvent );
			return TRUE;
		}
		// FALL THROUGH because we cannot abort right now
	default:
		return FALSE;
	}
}


bool ParseArgs( int argc, char **argv, int &maxthreads, int &concurrency, int &port, int &maxsockets )
{
	int opt, errors = 0;
	GetOpt go( argc, argv, "?ht:c:p:s:" );

	for ( errors = 0, opt = go(); opt != EOF; opt = go() )
	{
		switch ( opt )
		{
		case '?':
		case 'h':
			++ errors;
			break;
		case 'c':
			concurrency = atoi( go.optarg );
			if ( concurrency < 0 || concurrency > MAXIMUM_WAIT_OBJECTS )
			{
				clog << argv[0] << ": <concurrency> must be between 0 (auto) and " <<
					MAXIMUM_WAIT_OBJECTS << "." << endl;
				++ errors;
			}
			break;
		case 'p':
			port = atoi( go.optarg );
			if ( port < 1 || port > 65535 )
			{
				clog << argv[0] << ": <port> must be between 1 and 65535." << endl;
				++ errors;
			}
			break;
		case 's':
			maxsockets = atoi( go.optarg );
			if ( maxsockets < 1 || maxsockets > MAXSOCKETS )
			{
				clog << argv[0] << ": <maxsockets> must be between 1 and " <<
					MAXSOCKETS << "." << endl;
				++ errors;
			}
			break;
		case 't':
			maxthreads = atoi( go.optarg );
			if ( maxthreads < 1 || maxthreads > MAXIMUM_WAIT_OBJECTS )
			{
				clog << argv[0] << ": <threads> must be between 1 and " <<
					MAXIMUM_WAIT_OBJECTS << "." << endl;
				++ errors;
			}
			break;
		default:
			++ errors;
			break;
		}
	}

	if ( go.optind != argc )
	{
		clog << argv[0] << ": unwanted arguments '";
		for ( bool f = true; go.optind < argc; ++ go.optind, f = false )
			clog << ( f? "": " " ) << argv[go.optind];
		clog << "'" << endl;
		++ errors;
	}

	if ( errors )
	{
		cout << "usage: " << argv[0] << " -t <threads> -c <concurrency> -p <port> -s <max sockets>" << endl <<
			"       defaults: -t " << MAXIMUM_WAIT_OBJECTS << " -c 0 -p 2357 -s 300" << endl;
		return false;
	}

	return true;
}


int main( int argc, char *argv[] )
{
	int maxthreads = MAXIMUM_WAIT_OBJECTS, port = 2357, maxsockets = 300;
	int zero = 0;
	HL thread; // vector of thread handles
	HLI hli; // iterator into that vector
	OL ovl; // linked list of OVERLAPPED derivates
	OLI ovi; // iterator into that list
	HANDLE h; // temporary thread handle
	HANDLE scavengerThread; // handle to scavenger thread
	ScavengerArgs scavengerArgs; // args for scavenger thread
	DWORD i;
	unsigned int dummy;

	if ( ! ParseArgs( argc, argv, maxthreads, concurrency, port, maxsockets ) )
		return 1;

	cout << "Total threads:      " << maxthreads << endl <<
		"Concurrent threads: " << concurrency << endl <<
		"Max connections:    " << maxsockets << endl <<
		"TCP port:           " << port << endl;

	suicideEvent = CreateEvent( 0, TRUE, FALSE, 0 );
	err( ! VALID( suicideEvent ), "CreateEvent()" );

	scavengerArgs.suicideEvent = CreateEvent( 0, TRUE, FALSE, 0 );
	err( ! VALID( scavengerArgs.suicideEvent ), "CreateEvent() #2" );

	SetConsoleCtrlHandler( ConsoleHandler, TRUE );

	// create IOCP
	hiocp = CreateIoCompletionPort( INVALID_HANDLE_VALUE, 0, 0, concurrency );
	err( ! VALID( hiocp ), "CreateIoCompletionPort()" );

	// create threads

	for ( i = 0; i < maxthreads; ++ i )
	{
		h = (HANDLE) _beginthreadex( 0, 0, Worker, hiocp, 0, &dummy );
		if ( VALID( h ) )
			thread.push_back( h );
		else
			clog << "Failed to create thread " << i <<
				", gle == " << GetLastError() << endl;
	}

	if ( maxthreads != thread.size() )
		clog << "Only " << thread.size() << " instead of " << maxthreads << 
			" threads were created." << endl;

	// initialize winsock
	WSADATA wd = { 0 };
	int e;

	e = WSAStartup( MAKEWORD( 2, 0 ), &wd );
	SetLastError( e ); // for _err()
	err( e != 0, "WSAStartup()" );
	err( LOBYTE( wd.wVersion ) < 2, "WSAStartup()" );

	// create listen socket
	SOCKADDR_IN addr;

	listener = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
	err2( listener == INVALID_SOCKET, "socket()", "listener" );

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	addr.sin_port = htons( (short) port );

	e = bind( listener, (SOCKADDR *) &addr, sizeof addr );
	err2( e == SOCKET_ERROR, "bind()", "listener" );

	e = listen( listener, 200 );
	err2( e == SOCKET_ERROR, "listen()", "listener" );

	// create accept sockets and OV structs

	// note that this socket pool is never expanded, effectively
	// limiting the number of connections to the number of sockets
	// created here. An alternative strategy that is often used is
	// to create a new socket (and post and AcceptEx() for it) in
	// the AcceptEx() completion notification. In that case, you'd
	// start with only a few sockets -- say, a hundred or so -- and
	// delete the sockets/contexts for closed connections.

	for ( i = 0; i < maxsockets; ++ i )
	{
		OV *o = new OV;
		o->state = stAccepting;
		o->ix = ovl.size();
		ReinitContext( *o );
		if ( o->s != INVALID_SOCKET )
			ovl.push_back( o );
		else
			clog << "Failed to create socket " << i <<
				", gle == " << GetLastError() << endl;
	}

	if ( maxsockets != ovl.size() )
		clog << "Only " << ovl.size() << " instead of " << maxsockets << 
			" sockets were created." << endl;

	// kick socket scavenger loose
	scavengerArgs.delay = 500; // 500 msec between runs
	scavengerArgs.timeout = 5000; // time before killing an idle accepted socket
	scavengerArgs.povl = &ovl;
	scavengerThread = (HANDLE) _beginthreadex( 0, 0,
		ScavengePulingSockets, &scavengerArgs, 0, &dummy );
	err( ! VALID( scavengerThread ), "_beginthreadex( scavenger )" );

	// connect listener socket to IOCP
	err( 0 == CreateIoCompletionPort( (HANDLE) listener, hiocp, 0, concurrency ),
		"CreateIoCompletionPort( listener )" );

	// wait until end indicated
	WaitForSingleObject( suicideEvent, INFINITE );

	// no more accepts, please
	closesocket( listener );
	listener = INVALID_SOCKET;
	Sleep( 1000 ); // just for testing

	// queue suicide packets
	for ( i = 0; i < maxthreads; ++ i )
	{
		err( ! PostQueuedCompletionStatus( hiocp, 0, COMPKEY_DIEDIEDIE, 0 ),
			"PostQueuedCompletionStatus()" );
	}

	// wait for thread terminations
	i = WaitForMultipleObjects( thread.size(), &thread[0], TRUE, 15000 );
	switch ( i )
	{
	case WAIT_TIMEOUT:
		clog << "Not all threads died in time." << endl;
		break;
	case WAIT_FAILED:
		err2( i != WAIT_OBJECT_0, "WaitForMultipleObjects()", "WAIT_FAILED" );
		break;
	default:
		break;
	}

	for ( hli = thread.begin(); hli != thread.end(); ++ hli )
		CloseHandle( *hli );

	thread.clear();

	// kill off the scavenger
	SetEvent( scavengerArgs.suicideEvent );
	i = WaitForSingleObject( scavengerThread, 2 * scavengerArgs.timeout );
	CloseHandle( scavengerThread );
	CloseHandle( scavengerArgs.suicideEvent );

	// tear down and close sockets
	for ( ovi = ovl.begin(); ovi != ovl.end(); ++ ovi )
	{
		closesocket( (*ovi)->s );
		delete (*ovi);
	}

	ovl.clear();

	// shut down winsock
	WSACleanup();

	// close IOCP and suicide flag
	SetConsoleCtrlHandler( ConsoleHandler, FALSE );
	CloseHandle( hiocp );
	CloseHandle( suicideEvent );

	return 0;
}
