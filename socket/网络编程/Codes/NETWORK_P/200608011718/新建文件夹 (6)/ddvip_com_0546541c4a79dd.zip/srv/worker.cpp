// worker thread code

#include "stdafx.h"
#include "worker.h"
#include <assert.h>


// a note on initialReceiveSize: If the client starts sending
// as soon as it has a connection, you can leave this value
// != 0. If, however, the client expects the server to offer
// a banner first, you *must* set initialReceiveSize to ZERO.
// If you don't, AcceptEx() will wait for the client to speak
// up, while the client waits for the server to say something!

#ifdef SEND_BANNER_FIRST
	const int OV::initialReceiveSize = 0;
#else // SEND_BANNER_FIRST
	// available buffer minus the space for local/peer addresses
	const int OV::initialReceiveSize = OV::bs - 2 * ( sizeof sockaddr_in + 16 );
#endif // SEND_BANNER_FIRST
const int OV::addrlen = sizeof sockaddr_in + 16;
long runningThreads = 0;
extern SOCKET listener; // the listener socket, obviously.
HANDLE hiocp = 0;


// closes sockets that were connected but never received data
unsigned int __stdcall ScavengePulingSockets( void *arg )
{
	DWORD st;
	OLI ovi;
	int seconds, len;
	OL &ovl = *((ScavengerArgs *) arg)->povl;

	while ( 1 )
	{
		// scavenge sockets
		for ( ovi = ovl.begin(); ovi != ovl.end(); ++ ovi )
		{
			if ( (*ovi)->state == stAccepting )
			{
				// stAccepting means AcceptEx() called, but no completion yet

				// BUGBUG sanity check
				if ( (*ovi)->end < (*ovi)->buf || (*ovi)->end > &(*ovi)->buf[OV::bs] )
					cout << '[' << setw( 4 ) << (*ovi)->ix << "]*end != buf!" << endl;

				// determine if the socket is connected
				seconds = 0;
				len = sizeof seconds;
				if ( 0 == getsockopt( (*ovi)->s, SOL_SOCKET,
					SO_CONNECT_TIME, (char *) &seconds, &len ) )
				{
					if ( seconds != -1 && seconds * 1000 > ((ScavengerArgs *) arg)->timeout )
					{
						cout << '[' << setw( 4 ) << (*ovi)->ix <<
							"]*idle for " << seconds << " seconds" << endl;
						// closesocket() here causes an immediate IOCP notification
						// with an error indication; that will cause our worker thread
						// to call DoClose(). The state of the listener socket will
						// determine whether the socket will be reopened to accept
						// another connection, or whether it is left for dead.
						closesocket( (*ovi)->s );
					}
				}
			}
		}

		// pause until next run due
		st = WaitForSingleObject( ((ScavengerArgs *) arg)->suicideEvent,
			((ScavengerArgs *) arg)->delay );
		if ( st != WAIT_TIMEOUT )
			break;
	}

	return 0;
}


unsigned int __stdcall Worker( void *arg )
{
	DWORD n, gle;
	ULONG key;
	BOOL result;
	OV *pov;

	InterlockedIncrement( &runningThreads );
	// attach to IOCP and start looping
	for ( ; ; )
	{
		InterlockedDecrement( &runningThreads );
		// note how I am blithely assuming that a pointer
		// to one of my OV structs is the same as a pointer
		// to the OVERLAPPED class which is OV's parent.
		// Kids, do not do this at home -- _our_ pointers
		// are highly trained athletes.
		result = GetQueuedCompletionStatus( hiocp, &n,
			&key, (OVERLAPPED **) &pov, INFINITE );

		// check if we are to die
		if ( key == COMPKEY_DIEDIEDIE )
			break; // sniffle

		gle = GetLastError();
		if ( pov != 0 )
			pov->n = n;
		InterlockedIncrement( &runningThreads );

		if ( result == FALSE ) // something gone awry?
		{
			// something failed. Was it the call itself, or did we just eat
			// a failed socket I/O?
			if ( pov == 0 ) // the IOCP op failed
			{
				// no key, no byte count, no overlapped info available!
				// how do I handle this?
				// by ignoring it. I don't even have a socket handle to close.
				// You might want to abort instead, as something is seriously
				// wrong if we get here.
			}
			else
			{
				// key, byte count, and overlapped are valid.
				// tear down the connection and requeue the socket
				// (unless the listener socket is closed, in which case
				// this is a failed AcceptEx(), and we stop accepting)
				DoClose( *pov, true, listener == INVALID_SOCKET? false: true );
			}
		}
		else // GQCS() returned TRUE
		{
			// since we are still here, we have an I/O to process
			DoIo( *pov ); // n is redundant -- see pov->InternalHigh
		}
	}

	InterlockedDecrement( &runningThreads );
	cout << "[    ] La garde meurt, mais elle ne se rend pas." << endl;

	return 0;
}


void DoClose( OV &ov, bool force /* = false */, bool listenAgain /* = true */ )
{
	struct linger li = { 0, 0 }; // default: SO_DONTLINGER

	cout << '[' << setw( 4 ) << ov.ix << "] DoClose(): force == " << ( force? "true": "false" ) << endl;

	if ( force )
		li.l_onoff = 1; // SO_LINGER, timeout = 0

	setsockopt( ov.s, SOL_SOCKET, SO_LINGER, (char *) &li, sizeof li );
	closesocket( ov.s );
	if ( ov.sendFile )
	{
		CloseHandle( ov.hf );
		ov.hf = INVALID_HANDLE_VALUE;
	}

	if ( listenAgain )
		ReinitContext( ov );
}


void ReinitContext( OV &ov )
{
	int zero = 0;

	ov.s = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
	if ( ov.s != INVALID_SOCKET )
	{
		ov.state = stAccepting;
		ov.ignore = ov.sendFile = false;
		ov.end = &ov.buf[0];

		setsockopt( ov.s, SOL_SOCKET, SO_SNDBUF, (char *) &zero, sizeof zero );
		setsockopt( ov.s, SOL_SOCKET, SO_RCVBUF, (char *) &zero, sizeof zero );

		// clear the area for AcceptEx() addresses. Why? Because if
		// OV::initialReceiveSize == 0 (that is, if SEND_BANNER_FIRST
		// is defined), no addresses are captured; this way, we get
		// at least zeroes instead of garbage.
		memset( ov.buf, '\0', sizeof ov.buf );

		if ( ! AcceptEx( listener, ov.s, &ov.buf[0],
			OV::initialReceiveSize, ov.addrlen,
			ov.addrlen, &ov.n, &ov ) )
		{
			// AcceptEx() returned FALSE, check for real errors
			if ( GetLastError() != ERROR_IO_PENDING )
				clog << "AcceptEx() in ReinitContext() failed, gle == " <<
					GetLastError() << endl;
		}
	}
	else
		clog << "Socket creation in ReinitContext() failed, gle == " <<
			GetLastError() << endl;
}


// handle a successful I/O
void DoIo( OV &ov )
{
	int locallen, remotelen;
	string tt;
	sockaddr_in *plocal = 0, *premote = 0;

	// what was that socket doing, anyway?
#ifndef SEND_BANNER_FIRST
reevaluate:
#endif // SEND_BANNER_FIRST
	switch ( ov.state )
	{
	case stAccepting:
		GetAcceptExSockaddrs( &ov.buf[0], OV::initialReceiveSize,
			ov.addrlen, ov.addrlen, (sockaddr **) &plocal, &locallen,
			(sockaddr **) &premote, &remotelen );
		memcpy( &ov.local, plocal, sizeof sockaddr_in );
		memcpy( &ov.peer, premote, sizeof sockaddr_in );

		setsockopt( ov.s, SOL_SOCKET, SO_UPDATE_ACCEPT_CONTEXT,
			(char *) &listener, sizeof listener );

		// we still need to associate the newly connected socket to our IOCP:
		CreateIoCompletionPort( (HANDLE) ov.s, hiocp, 0, concurrency );
		tt = inet_ntoa( ov.peer.sin_addr );
		cout << '[' << setw( 4 ) << ov.ix << "] stAccepting: from " <<
			tt.c_str() << ':' << ntohs( ov.peer.sin_port ) << " to " <<
			inet_ntoa( ov.local.sin_addr ) << ":" << ntohs( ov.local.sin_port ) << endl;

#ifdef SEND_BANNER_FIRST
		// if we get here, then the initial receive size must have been 0,
		// therefore ov.n must be 0, with nothing at all in our receive buffer.
		// we can therefore blithely allow SendReply() to overwrite ov.n
		// (and other things).

		ov.reply = BANNER_STRING;
		SendReply( ov ); // that will put us into stWriting
#else // SEND_BANNER_FIRST
		if ( ov.n != 0 ) // we received something during AcceptEx()
		{ // note that this can only be if SEND_BANNER_FIRST was undefined
			// process the buffer read by AcceptEx()
			// like a normal read completion
			ov.state = stReading; // fake a completed read
			goto reevaluate;
		}

		// we should never get here: if SEND_BANNER_FIRST was undefined,
		// then AcceptEx() was told to receive at least one byte, and it
		// would not have returned withour that byte (unless the scavenger
		// force-closed the socket, in which case the AcceptEx() result
		// would have been an error, handled before ever calling DoIo().

		// Still, to be on the safe side, let's post a read.
		PostRead();
#endif // SEND_BANNER_FIRST

		break; // nothing read yet, don't attempt to buffer it

	case stReading:
		if ( ov.n == SOCKET_ERROR ) // error?
		{
			cout << '[' << setw( 4 ) << ov.ix << "] stReading: ov.n == SOCKET_ERROR" << endl;
			DoClose( ov, true );
		}
		else if ( ov.n == 0 ) // connection closing?
		{
			cout << '[' << setw( 4 ) << ov.ix << "] stReading: ov.n == 0, closing" << endl;
			DoClose( ov, false );
		}
		else
		{
			cout << '[' << setw( 4 ) << ov.ix << "] stReading: ov.n == " << ov.n << endl;
			ov.end += ov.n;
			if ( ! DoCommands( ov ) ) // no commands found? recv() some more!
			{
				// post anoher read, because DoCommands() did not post
				// a write whose completion would cause a read to be posted
				PostRead( ov );
			}
			else
			{
				// (intentionally empty else branch)

				// DoCommands() has posted a write; the completion of
				// this write, handled below, will post another read
			}
		}
		break;

	case stWriting:
		// a write just completed, post another read
		// but check for files to send first
		if ( ov.n == SOCKET_ERROR ) // error?
		{
			cout << '[' << setw( 4 ) << ov.ix << "] stWriting: ov.n == SOCKET_ERROR" << endl;
			DoClose( ov, true );
		}
		else if ( ov.n == 0 ) // connection closing?
		{
			cout << '[' << setw( 4 ) << ov.ix << "] stWriting: ov.n == 0, closing" << endl;
			DoClose( ov, false );
		}
		else
		{
			cout << '[' << setw( 4 ) << ov.ix << "] stWriting: ov.n == " << ov.n << endl;
			if ( ov.sendFile )
			{
				// ov.hf has a handle to a file to transmit
				memset( &ov.tfb, '\0', sizeof ov.tfb );
				if ( ! ov.tfHead.empty() )
				{
					ov.tfb.HeadLength = ov.tfHead.size();
					ov.tfb.Head = (void *) ov.tfHead.c_str();
				}
				if ( ! ov.tfHead.empty() )
				{
					ov.tfb.TailLength = ov.tfTail.size();
					ov.tfb.Tail = (void *) ov.tfTail.c_str();
				}
				
				if ( TransmitFile( ov.s, ov.hf, 0, 0, &ov, &ov.tfb, 0 ) ||
					GetLastError() == ERROR_IO_PENDING )
					ov.state = stSendingFile;
				else
				{
					// TF() error
					clog << "TransmitFile() failed, gle == " << GetLastError() << endl;
					DoClose( ov, true );
				}
			}
			else
			{
				// the write was OK, post another read
				PostRead( ov );
			}
		}
		break;

	case stSendingFile:
		if ( ov.n == SOCKET_ERROR ) // error?
		{
			cout << '[' << setw( 4 ) << ov.ix << "] stSendingFile: ov.n == SOCKET_ERROR" << endl;
			DoClose( ov, true );
		}
		else if ( ov.n == 0 ) // connection closing?
		{
			cout << '[' << setw( 4 ) << ov.ix << "] stSendingFile: ov.n == 0, closing" << endl;
			DoClose( ov, false );
		}
		else
		{
			cout << '[' << setw( 4 ) << ov.ix << "] stSendingFile: ov.n == " << ov.n << endl;
			ov.sendFile = false;
			CloseHandle( ov.hf );
			// go back to reading commands
			PostRead( ov );
		}
		break;
	}
}


// returns true if read completed immediately
void PostRead( OV &ov )
{
	BOOL result;

	// if there is not enough room in the buffer,
	// flush it and set the ignore-this-cmd flag
	if ( ov.end == &ov.buf[ov.bs] )
	{
		ov.end = &ov.buf[0];
		ov.ignore = true;
	}

	ov.state = stReading; // obviously
	ov.n = &ov.buf[ov.bs] - ov.end;
#ifdef USE_WSARECV
	ov.recvBufferDescriptor.len = ov.n;
	ov.recvBufferDescriptor.buf = ov.end;
	ov.recvFlags = 0;
	result = WSARecv( ov.s, &ov.recvBufferDescriptor, /* number of WSABUFs */ 1,
		&ov.n, &ov.recvFlags, &ov, /* completion routine address */ 0 );
	result = ( result != SOCKET_ERROR ); // inverted logic
#else
	result = ReadFile( (HANDLE) ov.s, ov.end, ov.n, &ov.n, &ov );
#endif
	if ( result )
	{
		// everything OK
		return;
	}
	else
	{
		if ( GetLastError() != ERROR_IO_PENDING )
		{
			clog << "PostRead() failed, gle == " << GetLastError() << endl;
			DoClose( ov, true );
		}
		else
		{
			// (else branch intentionally empty)

			// if we get here, gle == ERROR_IO_PENDING,
			// which is fine by me
		}
	}

	return;
}


void SendReply( OV &ov )
{
	BOOL result;
	DWORD err;

	ov.state = stWriting;

	// submit a WriteFile() for the reply buffer
	ov.n = ov.reply.size();
#ifdef USE_WSASEND
	ov.sendBufferDescriptor.len = ov.n;
	// casting away const is not nice, but since the NT guys have
	// an innate hatred for const input argument declarations,
	// there is not much we can do
	ov.sendBufferDescriptor.buf = const_cast< char * >( ov.reply.c_str() );
	result = WSASend( ov.s, &ov.sendBufferDescriptor, /* number of WSABUFs */ 1,
		&ov.n, /* flags */ 0, &ov, /* completion routine */ 0 );
	result = ( result != SOCKET_ERROR ); // WSASend() uses inverted logic wrt/WriteFile()
	err = WSAGetLastError();
#else
	result = WriteFile( (HANDLE) ov.s, ov.reply.c_str(), ov.n, &ov.n, &ov );
	err = GetLastError();
#endif
	if ( ! result )
	{
		if ( err != ERROR_IO_PENDING )
		{
			clog << "WriteFile()/WSASend() failed, gle == " << err << endl;
			DoClose( ov, true );
			// the fall-through does nothing because the caller
			// shouldn't post another read -- the reinitialised
			// socket has an AcceptEx() pending
		}
		else
		{
			// (else branch intentionally empty)

			// if we get here, gle == ERROR_IO_PENDING; nothing
			// left to do but return. Caller loops back to GQCS().
		}
	}
	else // WriteFile()
	{
		// the write completed immediately
		// this doesn't bother us -- we will still
		// get the completion packet
	}
}


bool DoCommands( OV &ov )
{
	int numCommands = 0; // number of commands removed from ov.buf
	char *p, *q;

	ov.reply.erase();

	for ( p = &ov.buf[0]; ; )
	{
		// skip line feeds left over from prev command
		for ( ; p < ov.end && *p == '\n'; ++ p )
			;

		// first, locate the end of the command line
		for ( q = p; q < ov.end && *q != '\r'; ++ q )
			;

		if ( q == ov.end ) // no complete command left in the buffer
		{
			if ( p > &ov.buf[0] ) // did we process something already?
			{
				// if so, shift the remaining buffer to the left
				memmove( &ov.buf[0], p, ov.end - p );
				ov.end -= p - &ov.buf[0];
			}
			break;
		}

		// p points at the start of a command, q points at its terminating character
		*q = '\0';

		if ( ov.ignore ) // is this the rest of an overflowing command line?
		{
			ov.ignore = false; // yup, and we did penance
			ov.reply += "One command ignored due to its length.\r\n";
		}
		else // do not ignore this command
			DoOneCommand( p, ov ); // presumably, this adds to ov.reply

		++ numCommands;
		p = q + 1;
	}

	if ( ! ov.reply.empty() )
	{
		SendReply( ov );
		return true;
	}
	else // reply was empty
		return false; // tell the caller that we didn't post a write.
			// this means that no write completion will occur, therefore
			// no read will be posted -- the caller needs to do that himself
}


void DoOneCommand( char *cmd, OV &ov )
{
	char *p;
	static const char * const delim = " \t";
	static const string prompt( "\r\n> " ), crlf( "\r\n" );

	if ( cmd == 0 )
	{
		cout << '[' << setw( 4 ) << "] Oops! cmd == 0!" << endl;
		cmd = "";
	}

	ov.reply += prompt + cmd + crlf;
	p = strtok( cmd, delim );

	if ( p == 0 )
		ov.reply += "Nothing to do.\r\n";
	else if ( stricmp( p, "help" ) == 0 || stricmp( p, "?" ) == 0 )
	{
		ov.reply += "Valid commands:\r\n"
			"  help\r\n"
			"  quit\r\n"
			"  sleep <msec>\r\n"
			"  status\r\n"
			"  xmit <filename>\r\n";
	}
	else if ( stricmp( p, "quit" ) == 0 )
	{
		ov.reply += "Death is lighter than a flower;\r\nduty, heavier than a mountain.\r\n";
		SetEvent( suicideEvent );
	}
	else if ( stricmp( p, "status" ) == 0 )
	{
		char tt[40];

		itoa( ntohs( ov.peer.sin_port ), tt, 10 );
		ov.reply += "client address " + string( inet_ntoa( ov.peer.sin_addr ) ) + ":" + tt + crlf;
		itoa( ntohs( ov.local.sin_port ), tt, 10 );
		ov.reply += "server address " + string( inet_ntoa( ov.local.sin_addr ) ) + ":" + tt + crlf;
	}
	else if ( stricmp( p, "sleep" ) == 0 )
	{
		p = strtok( NULL, delim );
		DWORD timeout = ( p == 0 )? 0: atoi( p );
		if ( timeout < 0 || timeout > 60000 )
			timeout = 50;
		Sleep( timeout );
		ov.reply += "Good morning!\r\n";
	}
	else if ( stricmp( p, "xmit" ) == 0 )
	{
		p = strtok( NULL, delim );
		ov.tfHead = string( "And here is your file (" ) + p + string( "):\r\n" ) + 
			"------------------------------------------------------------------------------\r\n";
		ov.tfTail = "------------------------------------------------------------------------------\r\n"
			"There you go!\r\n";
		ov.hf = CreateFile( p, GENERIC_READ, FILE_SHARE_READ, 0,
			OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, 0 );
		if ( ov.hf == INVALID_HANDLE_VALUE )
		{
			char tt[40];
			itoa( GetLastError(), tt, 10 );
			ov.sendFile = false;
			ov.reply = "Sorry, but the file is unavailable (error " + string( tt ) + ").\r\n"
				"Remember that I am too lazy to correctly handle file names with spaces.\r\n";
		}
		else
		{
			// tell DoIo()'s transmit completion case to start the file transfer
			ov.sendFile = true;
			ov.reply += "Your file is coming up next ...\r\n";
		}
	}
	else
		ov.reply += "Unknown command.\r\n";
}
