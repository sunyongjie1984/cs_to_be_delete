// WCSock.cpp: implementation of the CWCSock class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WC.h"
#include "WCSock.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CWCSock::CWCSock()
{

}

CWCSock::~CWCSock()
{

}
UINT dwRead=0;

CFile destFile("12345", CFile::modeCreate | CFile::modeWrite | CFile::typeBinary);
void CWCSock::OnReceive(int nErrorCode)
{
	
	Receive(&m_Dat,sizeof(m_Dat));

	PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd,RE_RECEIVED,(WPARAM)&m_Dat,0);


	
}
/////////////////////////////////////////////////////////////////////////////
// CPortDlg dialog


CPortDlg::CPortDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPortDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPortDlg)
	m_Address = _T("");
	m_Name = _T("");
	m_nPort = 0;
	//}}AFX_DATA_INIT
}


void CPortDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPortDlg)
	DDX_Text(pDX, IDC_ADDRESS, m_Address);
	DDX_Text(pDX, IDC_NAME, m_Name);
	DDX_Text(pDX, IDC_PORT, m_nPort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPortDlg, CDialog)
	//{{AFX_MSG_MAP(CPortDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPortDlg message handlers

BOOL CPortDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	SetDlgItemText(IDC_PORT,"0");
	SetDlgItemText(IDC_ADDRESS,"localhost");
	return true;

}

void CPortDlg::OnOK() 
{
	// TODO: Add extra validation here
	CString str;
	GetDlgItemText(IDC_ADDRESS,m_Address);
	GetDlgItemText(IDC_NAME,m_Name);
	GetDlgItemText(IDC_PORT,str);
	m_nPort=atoi(str);

	
	CDialog::OnOK();
}

void CPortDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	exit(0);
	CDialog::OnCancel();
}
/////////////////////////////////////////////////////////////////////////////
// CTryDlg dialog


CTryDlg::CTryDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTryDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTryDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTryDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTryDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTryDlg, CDialog)
	//{{AFX_MSG_MAP(CTryDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTryDlg message handlers

void CTryDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}

void CWCSock::abc()
{


}
