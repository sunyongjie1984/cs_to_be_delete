// WCSock.h: interface for the CWCSock class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WCSOCK_H__17A7A5A7_A573_4FB7_8722_2C0106C6FAF6__INCLUDED_)
#define AFX_WCSOCK_H__17A7A5A7_A573_4FB7_8722_2C0106C6FAF6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define RE_RECEIVED WM_USER+1

typedef struct _SOCKET_STREAM_FILE_INFO {

    TCHAR       szFileTitle[128];                   //�ļ��ı�����
    DWORD       dwFileAttributes;                   //�ļ�������
    FILETIME    ftCreationTime;                     //�ļ��Ĵ���ʱ��
    FILETIME    ftLastAccessTime;                   //�ļ���������ʱ��
    FILETIME    ftLastWriteTime;                    //�ļ�������޸�ʱ��
    DWORD       nFileSizeHigh;                      //�ļ���С�ĸ�λ˫��
    DWORD       nFileSizeLow;                       //�ļ���С�ĵ�λ˫��
    DWORD       dwReserved0;                        //������Ϊ0
    DWORD       dwReserved1;                        //������Ϊ0

} SOCKET_STREAM_FILE_INFO, * PSOCKET_STREAM_FILE_INFO;
typedef struct
{
	char m_strName[255];
	char m_strAction[255];
	BOOL m_bOnline;
	BOOL m_bAngular;
	double m_dbData;
}_DATA;

class CWCSock : public CSocket  
{
public:
	void abc();
	void OnReceive(int nErrorCode);
	_DATA m_Dat;
	CWCSock();
	virtual ~CWCSock();
	bool logic1;


};

#endif // !defined(AFX_WCSOCK_H__17A7A5A7_A573_4FB7_8722_2C0106C6FAF6__INCLUDED_)
/////////////////////////////////////////////////////////////////////////////
// CPortDlg dialog

class CPortDlg : public CDialog
{
// Construction
public:
	BOOL OnInitDialog();
	CPortDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPortDlg)
	enum { IDD = IDD_PORTDLG_DIALOG };
	CString	m_Address;
	CString	m_Name;
	int		m_nPort;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPortDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPortDlg)
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CTryDlg dialog

class CTryDlg : public CDialog
{
// Construction
public:
	CTryDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTryDlg)
	enum { IDD = IDD_TRYEDLG_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTryDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTryDlg)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
