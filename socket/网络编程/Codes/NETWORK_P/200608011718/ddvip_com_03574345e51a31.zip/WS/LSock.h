// LSock.h: interface for the CLSock class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LSOCK_H__BEC1836D_A53B_4736_813E_CC6159C5299A__INCLUDED_)
#define AFX_LSOCK_H__BEC1836D_A53B_4736_813E_CC6159C5299A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "RWSock.h"

class CLSock : public CSocket  
{
public:
	void CloseAllSockets();
	void CloseSocket(CRWSock *pSocket);
	void OnAccept(int nErrorCode);

	CPtrList m_RWSocks;
	CLSock();
	virtual ~CLSock();
	







	

};

#endif // !defined(AFX_LSOCK_H__BEC1836D_A53B_4736_813E_CC6159C5299A__INCLUDED_)
