// RWSock.h: interface for the CRWSock class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RWSOCK_H__03831F29_57DF_4A73_861D_B1653349CC82__INCLUDED_)
#define AFX_RWSOCK_H__03831F29_57DF_4A73_861D_B1653349CC82__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "math.h"
#define CLT_CLOSE WM_USER+1
#define CLT_TALKING WM_USER+2

typedef struct
	{
		char m_strName[255];
		char m_strAction[255];
		BOOL m_bOnline;
		BOOL m_bAngular;
		double m_dbData;
	}_DATA;

class CRWSock : public CSocket  
{
public:
	void OnReceive(int nErrorCode);
	double Calculate(double x);
	_DATA m_Dat;
	CRWSock();
	virtual ~CRWSock();
	

};

#endif // !defined(AFX_RWSOCK_H__03831F29_57DF_4A73_861D_B1653349CC82__INCLUDED_)
