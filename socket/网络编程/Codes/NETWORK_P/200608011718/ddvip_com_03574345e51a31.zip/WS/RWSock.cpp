// RWSock.cpp: implementation of the CRWSock class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WS.h"
#include "RWSock.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRWSock::CRWSock()
{

}

CRWSock::~CRWSock()
{

}

double CRWSock::Calculate(double x)
{
	double re;
	if(m_Dat.m_bAngular)
	{
		x=x/57.1;
		re=sin(x);
	}
	else
	{
		re=sin(x);
	}
	return re;


}

void CRWSock::OnReceive(int nErrorCode)
{

	Receive(&m_Dat,sizeof(m_Dat));
	::PostMessage(::AfxGetApp()->m_pMainWnd->m_hWnd,CLT_TALKING,(WPARAM)&m_Dat,0);
	
	if(m_Dat.m_bOnline)
	{
	


		m_Dat.m_dbData=Calculate(m_Dat.m_dbData);
		Send(&m_Dat,sizeof(m_Dat));
		
	}
	else
	{
		::PostMessage(::AfxGetApp()->m_pMainWnd->m_hWnd,CLT_CLOSE,(WPARAM)this,0);
	}
	CSocket::OnReceive(nErrorCode);

}
