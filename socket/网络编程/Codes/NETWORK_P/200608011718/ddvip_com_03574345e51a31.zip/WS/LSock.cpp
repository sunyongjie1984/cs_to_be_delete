// LSock.cpp: implementation of the CLSock class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WS.h"
#include "LSock.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLSock::CLSock()
{

}

CLSock::~CLSock()
{

}

void CLSock::OnAccept(int nErrorCode)
{
	CRWSock *rwSock;
	rwSock=new CRWSock;
	if(Accept(*rwSock))
	{
	
		m_RWSocks.AddTail(rwSock);
	}
	else
	{
		delete rwSock;
		AfxMessageBox("Accept() fail");
	}
	CSocket::OnAccept(nErrorCode);

}




void CLSock::CloseSocket(CRWSock *pSocket)
{
	pSocket->Close();
	POSITION pos;
	pos=m_RWSocks.Find(pSocket);
	m_RWSocks.RemoveAt(pos);
	if(pSocket!=NULL)
	{
		delete pSocket;
	}


}

void CLSock::CloseAllSockets()
{
	POSITION pos;
	CRWSock *rwSock;
	pos=m_RWSocks.GetHeadPosition();
	while(pos!=NULL)
	{
		_DATA dat;
		rwSock=(CRWSock*)m_RWSocks.GetNext(pos);
		dat.m_bOnline=false;
		rwSock->Send(&dat,sizeof(dat));
		CloseSocket(rwSock);
	}

}
