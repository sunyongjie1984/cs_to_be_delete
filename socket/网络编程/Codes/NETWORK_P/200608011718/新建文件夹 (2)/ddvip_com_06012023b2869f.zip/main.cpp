#include "stdafx.h"
#include "W3Mfc.h"
#include "HttpClient.h"




//The global variables
CWinApp theApp;
CHttpServer theWebServer;

BOOL ConsoleHandlerRoutine(DWORD /*dwCtrlType*/)
{
  _tprintf(_T("Received request to shut down the Web Server\n"));
  theWebServer.Stop();
  return TRUE;
}

class CMyHttpClient : public CHttpClient
{
public:
  void PostLog(int nHTTPStatusCode, DWORD dwBodyLength);

  DECLARE_DYNCREATE(CMyHttpClient)
};

IMPLEMENT_DYNCREATE(CMyHttpClient, CHttpClient)

void CMyHttpClient::PostLog(int nHTTPStatusCode, DWORD dwBodyLength)
{
  //Log each request to the console window using the W3C Common
  //log format.

  //Get the current date and time
  time_t now = time(NULL);
  tm* pNow = localtime(&now);

  //Get the time zone information
  TIME_ZONE_INFORMATION tzi;
  GetTimeZoneInformation(&tzi);

  //Format the date and time appropiately
  TCHAR sDateTime[64];
  _tcsftime(sDateTime, 64, _T("[%d/%b/%Y:%H:%M:%S"), pNow);

  //Display the connections to the console window
  CString sUser(m_Request.m_sUsername);
  if (sUser.IsEmpty())
    sUser = _T("-");
  _tprintf(_T("%d.%d.%d.%d - %s %s %04d] \"%s\" %d %d\n"), 
           m_Request.m_ClientAddress.sin_addr.S_un.S_un_b.s_b1,
           m_Request.m_ClientAddress.sin_addr.S_un.S_un_b.s_b2, 
           m_Request.m_ClientAddress.sin_addr.S_un.S_un_b.s_b3, 
           m_Request.m_ClientAddress.sin_addr.S_un.S_un_b.s_b4, 
           sUser, sDateTime, tzi.Bias, m_Request.m_sRequest, nHTTPStatusCode, dwBodyLength);
}

void main()
{
  //Initialize MFC
  if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))    
  {
    _tprintf(_T("Failed to initialise MFC\n"));
    return;
  }

  //Initialise Sockets
  if (!AfxSocketInit())
  {
    _tprintf(_T("Failed to initialise sockets, GetLastError:%d\n"), ::GetLastError());
    return;
  }

  //Setup the root directory
  CHttpDirectory dir1;
  dir1.SetAlias(_T('\\'));
  dir1.SetDirectory(_T("c:\\webshare\\wwwroot")); //change this to suit your system
  dir1.SetDefaultFile(_T("index.html"));          //change this to suit your system
  CHttpServerSettings settings;
  settings.m_Directories.SetAt(0, dir1);

  //setup another virtual directory
  CHttpDirectory dir2;
  dir2.SetAlias(_T("~pjn"));
  dir2.SetDirectory(_T("c:\\webshare\\wwwroot2"));
  dir2.SetDefaultFile(_T("index.html"));
  dir2.SetDirectoryListing(TRUE);
  settings.m_Directories.Add(dir2);

  //Do not use port 80 for this sample app. Helps avoid any possible
  //conflict with exisiting web servers which may be running
  settings.m_nPort = 90;

  //Setup the runtime client class
  settings.m_pRuntimeClientClass = RUNTIME_CLASS(CMyHttpClient);

  //and start it up
  _tprintf(_T("Web server is starting...\n"));
  if (!theWebServer.Start(settings))
    _tprintf(_T("Failed to start the web server, GetLastError:%d\n"), ::GetLastError());

  //Register the console handler to allow the program to be gracefully terminated
  if (!SetConsoleCtrlHandler((PHANDLER_ROUTINE) ConsoleHandlerRoutine, TRUE))
  {
    _tprintf(_T("Failed to initialise console handler, GetLastError:%d\n"), ::GetLastError());
    return;
  }

  //Wait until the server finishes
  theWebServer.Wait();
  _tprintf(_T("Web server has shut down...\n"));
}   

