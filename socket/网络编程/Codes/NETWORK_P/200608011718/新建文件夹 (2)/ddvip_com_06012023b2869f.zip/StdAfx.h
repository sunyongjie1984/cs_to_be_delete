#define VC_EXTRALEAN

#include <afxext.h> 
#include <afxsock.h>
#include <afxmt.h>
#include <afxtempl.h>