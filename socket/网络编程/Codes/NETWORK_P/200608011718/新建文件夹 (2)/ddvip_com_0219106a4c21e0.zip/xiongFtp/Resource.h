//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by xiongFtp.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_LOC_FORMVIEW                101
#define CG_ID_VIEW_MYDIALOGBAR          103
#define WM_SETDIRECTORYDISPLAY          104
#define WM_SETFILE                      105
#define WM_SETREDRAWFLAG                106
#define WM_REDISPLAYFILE                107
#define IDD_INPUT_EDIT                  109
#define WM_SETDIR                       110
#define WM_RECORDFTPINFO                111
#define IDR_MAINFRAME                   128
#define IDR_XIONGFTYPE                  129
#define IDD_SERV_FORMVIEW               130
#define IDI_CURSOR                      132
#define IDB_BACKBITMAP                  132
#define IDR_LOC_SERV_MENU               133
#define IDB_FILE_BITMAP                 140
#define IDC_SERV_DIR                    1000
#define IDC_SERV_FILE                   1001
#define IDC_LOC_DIR                     1002
#define IDC_BACK                        1002
#define IDC_LOC_FILE                    1003
#define IDC_FTPNAME                     1004
#define IDC_FTPPORT                     1005
#define IDC_FTPUSER                     1006
#define IDC_FTPPASSWORD                 1007
#define IDC_QUICKCONNECT                1008
#define CG_IDD_MYDIALOGBAR              1111
#define ID_FILE_FTP_DOWNLOAD            32771
#define ID_FILE_DELETE                  32772
#define ID_FILE_RENAME                  32774
#define ID_FILE_EXECUTE                 32775
#define ID_FILE_SEND                    32776
#define ID_FILE_FTP_EXECUTE             32778
#define IDC_FILE_RECONNECT              32779
#define ID_FILE_DISCONNECT              57601
#define ID_FILE_REFUSE                  57634
#define ID_FILE_STOP                    57635

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           112
#endif
#endif
