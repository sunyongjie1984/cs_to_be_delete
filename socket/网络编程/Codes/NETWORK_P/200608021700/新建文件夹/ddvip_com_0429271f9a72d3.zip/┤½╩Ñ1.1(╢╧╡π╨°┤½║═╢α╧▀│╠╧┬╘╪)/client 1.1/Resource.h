//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by client1.rc
//
#define IDR_CNTR_INPLACE                6
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define ID_IP                           101
#define IDP_FAILED_TO_CREATE            102
#define CLT_TALKING                     102
#define IDP_SOCKETS_INIT_FAILED         104
#define CLT_ONSE                        104
#define WM_AGE1                         105
#define CLT_ONSETWO                     106
#define WM_KSEND                        107
#define CLT_ON                          108
#define IDC_LIST1                       109
#define CLT_SE                          110
#define WM_ONSE                         111
#define CLT_ONRSE                       112
#define AA                              113
#define BB                              114
#define IDR_MAINFRAME                   128
#define IDR_CLIENTTYPE                  129
#define IDD_DIALOG1                     130
#define IDD_DIALOG2                     131
#define IDD_DIALOG3                     132
#define IDD_DIALOG4                     133
#define IDC_CURSOR2                     135
#define IDC_IPADDRESS1                  1003
#define IDC_EDIT1                       1004
#define IDC_SEND                        1005
#define IDC_HTTP                        1007
#define IDC_MAIL                        1008
#define ID_CANCEL_EDIT_CNTR             32768
#define ID_CONNECT                      32771
#define ID_BLACK                        32772
#define ID_NEXT1                        32774
#define ID_GARBAGE                      32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           115
#endif
#endif
