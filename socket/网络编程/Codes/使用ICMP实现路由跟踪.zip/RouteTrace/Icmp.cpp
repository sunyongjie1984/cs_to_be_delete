 // ICMP.cpp: implementation of the CICMP class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "RouteTrace.h"
#include "ICMP.h"
#include "ws2tcpip.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CICMP::CICMP()
{
	winsock = 0;
	m_pIp = NULL;
	m_pIcmp = NULL;

	m_pIp = (IP_HEAD *)new BYTE[MAX_PACKET];
	m_pIcmp = (ICMP_HEAD *)new BYTE[MAX_PACKET];

}

CICMP::~CICMP()
{
	delete [] m_pIp;
	delete [] m_pIcmp;
}


BOOL CICMP::Initialize()
{
	WSADATA wsadata;
	if( WSAStartup(MAKEWORD(2, 1),&wsadata) )   
	{
		AfxMessageBox("WSAStartup��ʼ��ʧ��!");
		return FALSE;
	}
	
	winsock= WSASocket (AF_INET,  	//����socket

				   SOCK_RAW,
				   IPPROTO_ICMP,
				   NULL, 0,0);
	if(!winsock)	{
		AfxMessageBox( "Socket����ʧ��!");
		return FALSE;
	}

	int timeout =5000;
	setsockopt(winsock,SOL_SOCKET,SO_RCVTIMEO,(char *)&timeout,   //�����ý��ճ�ʱ
		sizeof(timeout));
	timeout = 5000;
	setsockopt(winsock,SOL_SOCKET,SO_SNDTIMEO,(char *)&timeout,    //���÷��ͳ�ʱ
		sizeof(timeout));

	return TRUE;
}

void CICMP::Uninitialize()                //�ͷ�Socket
{
	if(winsock)
		closesocket(winsock);
	WSACleanup();
}

USHORT CICMP::CheckSum(USHORT *buffer, int size)  //����У���
{
  unsigned long cksum = 0;
  while(size > 1) {
	cksum+=*buffer++;
	size -=sizeof(USHORT);
  }
  
  if(size ) {
	cksum += *(UCHAR*)buffer;
  }

  cksum = (cksum >> 16) + (cksum & 0xffff);
  cksum += (cksum >>16);

  return (USHORT)(~cksum);

}

BOOL CICMP::SendICMPPack(char *pAddr)
{
	sockaddr_in sockAddr;
	memset((void *)&sockAddr,0,sizeof(sockAddr));
	sockAddr.sin_family = AF_INET;
	sockAddr.sin_port = 0;
	sockAddr.sin_addr.S_un.S_addr=inet_addr(pAddr);

	return SendICMPPack(&sockAddr);
}
//--------------------����---------------------------
BOOL CICMP::SendICMPPack(sockaddr_in *pAddr)
{
	//���ICMP���ݸ���
	int  state;
	char *p_data;
	m_pIcmp->type = ICMP_ECHO;
	m_pIcmp->code = 0;
	m_pIcmp->ID = (USHORT)GetCurrentProcessId();
	m_pIcmp->number = 0;
	m_pIcmp->time = GetTickCount();
	m_pIcmp->cksum = 0;

	//�������
	p_data = ((char *)m_pIcmp + sizeof(ICMP_HEAD));
	memset((char *)p_data,'0',DEF_PACKET);

	//����
	m_pIcmp->cksum = CheckSum((USHORT *)m_pIcmp,
		DEF_PACKET+sizeof(ICMP_HEAD));
	
	//��������
	state = sendto(winsock,(char *)m_pIcmp,
		DEF_PACKET+sizeof(ICMP_HEAD),
		NULL,(struct sockaddr *)pAddr,sizeof(sockaddr));

	if(state == SOCKET_ERROR) {
		if(GetLastError()==WSAETIMEDOUT)
			m_strInfo = "���ӳ�ʱ!(����)";
		else
			m_strInfo="����δ֪���ʹ���!";
		return FALSE;
	}

	if(state <DEF_PACKET) {
		m_strInfo = "�������ݴ���!";
		return FALSE;
	}
	
	memcpy((void *)&m_sockAddr,(void *)pAddr,
		sizeof(sockaddr_in));

	return TRUE;
}

//----------------------��������----------------------------
BOOL CICMP::RecvICMPPack()
{
	int state;
	int len = sizeof(sockaddr_in);
	char * addr;
    struct hostent *lpHostent = NULL;

	addr = inet_ntoa(m_sockAddr.sin_addr);
	state = recvfrom(winsock,(char *)m_pIp,MAX_PACKET,0,
		(struct sockaddr*)&m_sockAddr,&len);

	if (state == SOCKET_ERROR) {
		if (WSAGetLastError() == WSAETIMEDOUT)
		{	m_strInfo.Format("���ճ�ʱ,·�ɸ���ʧ��!");
		routestate=0;
		RouteState="·�ɸ���ʧ��!";
		}
		else
			m_strInfo = "δ֪���մ���!";
		return FALSE;
	}

	//��������
	int ipheadlen;
	ipheadlen = m_pIp->HeadLen * 4 ;

	if (state < (ipheadlen+MIN_PACKET))	{
		m_strInfo = "Ŀ�ĵ�ַ����Ӧ���ݲ���ȷ";
		return FALSE;
	}

	ICMP_HEAD * p_icmprev;
	p_icmprev = (ICMP_HEAD*)((char *)m_pIp + ipheadlen);

    	switch (p_icmprev->type)
		{
		case ICMP_ECHOREPLY:  //�յ���������
		{
		m_strInfo.Format("���յ�%s  %d�ֽ���Ӧ����,��Ӧʱ��:%dms.",
		inet_ntoa(m_sockAddr.sin_addr),len,GetTickCount()-p_icmprev->time);
		routeaddr=addr;
		routestate=0;	
	    RouteState="����Ŀ������!";
	    return TRUE;
			break;	
		}
		case ICMP_TTLOUT:   // TTL��ʱ
		{   routeaddr=inet_ntoa(m_sockAddr.sin_addr);
			routestate=1;
			RouteState="���Ե�·����!";
			return TRUE;
			break;
		}
		
		case ICMP_DESUNREACH:  //Ŀ�Ĳ��ɴ�
		{	m_strInfo = "Ŀ�Ĳ��ɴ�!";
		   	routestate=0;
			RouteState="Ŀ�Ĳ��ɴ�!";
			return TRUE;
			break;
		}
				
		default :{  routestate=0;
					m_strInfo="δ֪����!";
					RouteState="����״̬!";
				 }
		}
		return TRUE;

}
//----------------����TTL--------------------
int CICMP::SetTTL(int TTL)
{
	int nRet=setsockopt(winsock, IPPROTO_IP, IP_TTL,(LPSTR)&TTL,sizeof(int));
    
	if(nRet==SOCKET_ERROR)
	{   CString ttlerr;
		ttlerr.Format("���� TTL ����!");
		AfxMessageBox(ttlerr);
		return 0;
	}
	return 1;
}