/*
 *--------------------------------------------------------------
 * �V�X�e�� : �V������V�X�e��
 * �@�\���� : �g�Œ[��
 * ���@�@�� : addon.h
 * �T�@�@�v : �A�h�I�����W���[������֐��p�w�b�_�t�@�C��
 * ���@�@�� : REV.00.00 2006-08-24 �V�K�쐬
 *
 *--------------------------------------------------------------
 * (C) COPYRIGHT TOSHIBA SOLUTIONS CORPORATION 2006 ALL RIGHT RESERVED
 *--------------------------------------------------------------
 * �C���^�[�t�F�[�X����
 *
 *--------------------------------------------------------------
 * ���L����
 *
 *--------------------------------------------------------------
 */
#ifndef	_ADDON_H_
#define	_ADDON_H_
#include	<stdio.h>
#include	<windows.h>

/*==========================================================================*/
/* �������������̒�`														*/
/*==========================================================================*/
#define DLL_EXPORT __declspec( dllexport )
#define DLL_IMPORT __declspec( dllimport )

/* �����敪 */
#define	KBN_BASETYPES	0
#define	KBN_UPTYPE		1
#define	KBN_GUI			2

/* �@�\�ԍ� */
#define	KNO_BASETYPES_FC		0x0000000
#define	KNO_BASETYPES_CONV		0x0001000
#define	KNO_BASETYPES_BIT_COMN	0x0002000
#define	KNO_BASETYPES_HON		0x0003000
#define	KNO_BASETYPES_HIRA		0x0004000
#define	KNO_BASETYPES_HYO		0x0005000
#define	KNO_BASETYPES_HSP		0x0006000
#define	KNO_BASETYPES_KC		0x0007000
#define	KNO_BASETYPES_KOM		0x0008000
#define	KNO_BASETYPES_KMSLCT	0x0009000
#define	KNO_BASETYPES_KM		0x000a000
#define	KNO_BASETYPES_SEN		0x000b000
#define	KNO_BASETYPES_NHYO		0x000c000
#define	KNO_BASETYPES_MID		0x000d000
#define	KNO_BASETYPES_LTF		0x000e000
#define	KNO_BASETYPES_SPT		0x000f000
#define	KNO_BASETYPES_TNA		0x0010000


/*==========================================================================*/
/* �\���̂̒�`																*/
/*==========================================================================*/
struct ADDON_FUNCINFO
{
	int		kbn;			/* �����敪                 */
	int		command;		/* �R�}���h�ԍ�             */
	char	function[32];	/* �֐���                   */
	char	version[16];	/* �o�[�W�������           */
	char	info[64];		/* �֐��̊T�v				*/
};

struct ADDON_DLLINFO
{
	char	version[16];	/* �o�[�W�������			*/
	char	info[64];		/* �c�k�k�̊T�v				*/
};

union ADDON_VTYPE
{
	char           vc;
	short          vs;
	int            vi;
	long           vl;
	unsigned char  vuc;
	unsigned short vus;
	unsigned int   vui;
	unsigned long  vul;
	char          *vcp;
	short         *vch;
	int           *vci;
	long          *vcl;
};

struct ADDON_PARA
{
	int                argc;
	union ADDON_VTYPE   rtn;
	union ADDON_VTYPE   argv[10];
};



/*==========================================================================*/
/* �O���Q�Ɖ\�֐��̒�`													*/
/*==========================================================================*/
#ifdef	_ADDON_C_
#define ADDON_Dllport1 __declspec( dllimport )
#define ADDON_Dllport2 __declspec( dllexport )
typedef int (*FUNC_Addon_GetFuncInfo )( struct ADDON_FUNCINFO *, int );
typedef void (*FUNC_Addon_GetFunction )( struct ADDON_PARA * );
#else
#define ADDON_Dllport1 __declspec( dllexport )
#define ADDON_Dllport2 __declspec( dllimport )
#endif	_ADDON_C_

extern "C" {
ADDON_Dllport1 int Addon_GetFuncInfo( struct ADDON_FUNCINFO *, int );
ADDON_Dllport2 int Addon_LoadDll( char * );
ADDON_Dllport2 int Addon_FreeDll( void );
ADDON_Dllport2 int Addon_Function( int, int, struct ADDON_PARA * );
ADDON_Dllport2 int Addon_DllInfo( struct ADDON_DLLINFO *, int );
ADDON_Dllport2 int Addon_FuncInfo( struct ADDON_FUNCINFO *, int );
}
#endif	_ADDON_H_
