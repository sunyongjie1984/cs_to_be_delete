// MciDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Mci.h"
#include "MciDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include <mapi.h>

////////////////////�����⼸��///////////////////////////////
#include <stdlib.h>
/* ���巵��ֵ*/
#define SENDEMAIL_SUCCESS               0 //�ʼ��ɹ�����
#define SENDEMAIL_MAPI_NOT_INSTALLED    1 //û�а�װMAPI Server
#define SENDEMAIL_MAPILOAD_FAILED       2 //���� MAPI32.DLL ʧ��
#define SENDEMAIL_LOGON_FAILED          3 //�޷���½�� MAPI Server ���� �û�ȡ���˵�½��
#define SENDEMAIL_SEND_FAILED           4 //��Ϣ����ʧ��

/////////////////////////////////////////////////////////////////////////////
// CMciDlg dialog

CMciDlg::CMciDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMciDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMciDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMciDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMciDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMciDlg, CDialog)
	//{{AFX_MSG_MAP(CMciDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMciDlg message handlers

BOOL CMciDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMciDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMciDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMciDlg::OnOK() 
{
	// TODO: Add extra validation here
	CDialog::OnOK();
}

void CMciDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	HINSTANCE hInstMail;
	hInstMail=::LoadLibrary("MAPI32.DLL");
	if(!hInstMail)
	{
		AfxMessageBox("���� MAPI32.DLL ����!");
	}
	ULONG (PASCAL *lpfnMAPISendMail) (LHANDLE lhSession, ULONG ulUIParam, lpMapiMessage lpMessage, 
	FLAGS flFlags, ULONG ulReserved);

	ULONG (PASCAL *lpfnMAPIResolveName) (LHANDLE lhSession, ULONG ulUIParam, LPTSTR lpszName, 
	FLAGS ulFlags, ULONG ulReserved,lpMapiRecipDesc FAR *lppRecip);

	ULONG (FAR PASCAL *lpfnMAPILogon)(ULONG ulUIParam, LPSTR lpszProfileName, LPSTR lpszPassword, 
	FLAGS flFlags, ULONG ulReserved, LPLHANDLE lplhSession);

	ULONG (FAR PASCAL *lpfnMAPILogoff)(LHANDLE lhSession, ULONG ulUIParam, FLAGS flFlags,
	ULONG ulReserved);

	ULONG (FAR PASCAL *lpfnMAPIFreeBuffer)(LPVOID lpBuffer);

	ULONG (FAR PASCAL *lpfnMAPIAddress)(LHANDLE lhSession,ULONG ulUIParam, LPSTR lpszCaption,
	ULONG nEditFields, LPSTR lpszLabels,ULONG nRecips, lpMapiRecipDesc lpRecips,
	FLAGS flFlags, ULONG ulReserved, LPULONG lpnNewRecips, lpMapiRecipDesc FAR *lppNewRecips);

	ULONG (FAR PASCAL *lpfnMAPIFindNext)(LHANDLE lhSession,ULONG ulUIParam, LPSTR lpszMessageType, 
	LPSTR lpszSeedMessageID, FLAGS flFlags,ULONG ulReserved, LPSTR lpszMessageID);

	ULONG (FAR PASCAL *lpfnMAPIReadMail)(LHANDLE lhSession, ULONG ulUIParam, LPSTR lpszMessageID,
	FLAGS flFlags, ULONG ulReserved,lpMapiMessage FAR *lppMessage);


	(FARPROC&) lpfnMAPISendMail = GetProcAddress(hInstMail,"MAPISendMail");
	(FARPROC&) lpfnMAPIResolveName = GetProcAddress(hInstMail,"MAPIResolveName");
	(FARPROC&) lpfnMAPILogon = GetProcAddress(hInstMail,"MAPILogon");
	(FARPROC&) lpfnMAPILogoff = GetProcAddress(hInstMail,"MAPILogoff");
	(FARPROC&) lpfnMAPIFreeBuffer = GetProcAddress(hInstMail,"MAPIFreeBuffer");
	(FARPROC&) lpfnMAPIAddress = GetProcAddress(hInstMail,"MAPIAddress");
	(FARPROC&) lpfnMAPIFindNext = GetProcAddress(hInstMail,"MAPIFindNext");
	(FARPROC&) lpfnMAPIReadMail = GetProcAddress(hInstMail,"MAPIReadMail");


	LHANDLE lhSession;
	ULONG lResult = lpfnMAPILogon(0, NULL, NULL, MAPI_NEW_SESSION  , 0, &lhSession);
	if (lResult != SUCCESS_SUCCESS)
	//SUCCESS_SUCCESS��MAPI.H�б�����(0)
	{
		AfxMessageBox("��½MAPI Server ����!");
	}

	MapiMessage message;
	memset(&message, 0, sizeof(message));
	message.ulReserved = 0;
	message.lpszMessageType = NULL;
	char subject[512];
	strcpy(subject, "MAPI.DLL����");
	message.lpszSubject =subject;
	char text[5000];
	strcpy(text, "�ˣ�����һ��MAPI.DLL����!");
	message.lpszNoteText = text;
	message.flFlags = MAPI_SENT;
	message.lpOriginator = NULL;
	message.nRecipCount = 1;

	char recipient[512];
	strcpy(recipient, "zhaoxn@sdb.com.cn");
	lResult = lpfnMAPIResolveName(lhSession, 0, recipient,0, 0, &message.lpRecips);

	message.lpRecips->ulRecipClass = MAPI_TO;

	lResult = lpfnMAPISendMail(lhSession, 0, &message, 0, 0);
    if(lResult != SUCCESS_SUCCESS)
		AfxMessageBox("�����ʼ�ʧ��!");

    lpfnMAPILogoff(lhSession, 0, 0, 0);

	lpfnMAPIFreeBuffer(message.lpRecips);
}

void CMciDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
    int rc = SendEmail("SMTP:hangwire@sina.com", "һ��С����",
              "��ã�\n���ǲ�����Ϣ��");
}

int CMciDlg::SendEmail(const char* Address,
				  const char* Subject, 
				  const char* Text)
{
    int             iResult;
    UINT            iMapiInstalled;
    HINSTANCE       hMAPIInst;
    LPMAPILOGON     pMAPILogon;
    LPMAPILOGOFF    pMAPILogoff;
    LPMAPISENDMAIL  pMAPISendMail;
    LHANDLE         lhSession;

    iResult         = SENDEMAIL_SUCCESS;

    iMapiInstalled  = GetProfileInt("Mail", "MAPI", 0);

    if(! iMapiInstalled)
        return SENDEMAIL_MAPI_NOT_INSTALLED;

    hMAPIInst       = LoadLibrary("MAPI32.DLL");
    if(!hMAPIInst)
        return SENDEMAIL_MAPILOAD_FAILED;

    pMAPILogon      = (LPMAPILOGON)
                      GetProcAddress(hMAPIInst, "MAPILogon");
    pMAPILogoff     = (LPMAPILOGOFF)
                      GetProcAddress(hMAPIInst, "MAPILogoff");
    pMAPISendMail   = (LPMAPISENDMAIL)
                      GetProcAddress(hMAPIInst, "MAPISendMail");

    if(pMAPILogon(0, NULL, NULL, MAPI_LOGON_UI, 0, &lhSession)
        != SUCCESS_SUCCESS)
    {
        iResult = SENDEMAIL_LOGON_FAILED;
    }
    else        /* Send the Message         */
    {
        ULONG       Result;
        MapiMessage Msg;

        MapiRecipDesc Recipients[1];
        Recipients[0].ulReserved = 0;
        Recipients[0].ulRecipClass = MAPI_TO;
        Recipients[0].lpszName = (char*)Address;
        Recipients[0].lpszAddress = (char*)Address;
        Recipients[0].ulEIDSize = 0;
        Recipients[0].lpEntryID = 0;

        memset(&Msg, 0, sizeof(Msg));
        Msg.lpszSubject         = (char*)Subject;
        Msg.lpszNoteText        = (char*)Text;
        Msg.nRecipCount         = 1;
        Msg.lpRecips            = Recipients;

//	lResult = lpfnMAPISendMail(lhSession, 0, &message, 0, 0);
        Result      = pMAPISendMail(lhSession, 0, &Msg, 0, 0);
        if(Result != SUCCESS_SUCCESS)
            iResult = SENDEMAIL_SEND_FAILED;

        pMAPILogoff(lhSession, 0, 0, 0);
    }

    FreeLibrary(hMAPIInst);

    return iResult;
}