#include <windows.h>
#include <mapi.h>
#include <stdlib.h>
#define DllExport   __declspec( dllexport )
#include "sndemail.h"



#ifdef  __BORLANDC__
#pragma argsused
#endif
BOOL WINAPI DllMain(HANDLE hModule,DWORD dwReason,LPVOID lpReserved)
{    return TRUE;   }


DllExport int __stdcall SendEmail(const char* Address,
            const char* Subject, const char* Text)
{
    int             iResult;
    UINT            iMapiInstalled;
    HINSTANCE       hMAPIInst;
    LPMAPILOGON     pMAPILogon;
    LPMAPILOGOFF    pMAPILogoff;
    LPMAPISENDMAIL  pMAPISendMail;
    LHANDLE         lhSession;


    iResult         = SENDEMAIL_SUCCESS;

    iMapiInstalled  = GetProfileInt("Mail", "MAPI", 0);

    if(! iMapiInstalled)
        return SENDEMAIL_MAPI_NOT_INSTALLED;

    hMAPIInst       = LoadLibrary("MAPI32.DLL");
    if(!hMAPIInst)
        return SENDEMAIL_MAPILOAD_FAILED;

    pMAPILogon      = (LPMAPILOGON)
                      GetProcAddress(hMAPIInst, "MAPILogon");
    pMAPILogoff     = (LPMAPILOGOFF)
                      GetProcAddress(hMAPIInst, "MAPILogoff");
    pMAPISendMail   = (LPMAPISENDMAIL)
                      GetProcAddress(hMAPIInst, "MAPISendMail");

    if(pMAPILogon(0, NULL, NULL, MAPI_LOGON_UI, 0, &lhSession)
        != SUCCESS_SUCCESS)
    {
        iResult = SENDEMAIL_LOGON_FAILED;
    }
    else        /* Send the Message         */
    {
        ULONG       Result;
        MapiMessage Msg;

        MapiRecipDesc Recipients[1];
        Recipients[0].ulReserved = 0;
        Recipients[0].ulRecipClass = MAPI_TO;
        Recipients[0].lpszName = (char*)Address;
        Recipients[0].lpszAddress = (char*)Address;
        Recipients[0].ulEIDSize = 0;
        Recipients[0].lpEntryID = 0;

        memset(&Msg, 0, sizeof(Msg));
        Msg.lpszSubject         = (char*)Subject;
        Msg.lpszNoteText        = (char*)Text;
        Msg.nRecipCount         = 1;
        Msg.lpRecips            = Recipients;

        Result      = pMAPISendMail(lhSession, 0, &Msg, 0, 0);
        if(Result != SUCCESS_SUCCESS)
            iResult = SENDEMAIL_SEND_FAILED;

        pMAPILogoff(lhSession, 0, 0, 0);
    }

    FreeLibrary(hMAPIInst);

    return iResult;
}
