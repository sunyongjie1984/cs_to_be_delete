#include <windows.h>
#include <stdlib.h>
#include "sndemail.h"

int     main(void)
    {
    SendEmail("SMTP:hangwire@sina.com", "This is a  test",
              "Here is my\n2-line message.");
    return EXIT_SUCCESS;
    }
