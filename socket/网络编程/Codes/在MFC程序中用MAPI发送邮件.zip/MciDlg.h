// MciDlg.h : header file
//

#if !defined(AFX_MCIDLG_H__9BBF3087_D871_11D5_A954_AC5CBA017829__INCLUDED_)
#define AFX_MCIDLG_H__9BBF3087_D871_11D5_A954_AC5CBA017829__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMciDlg dialog

class CMciDlg : public CDialog
{
// Construction
public:
	CMciDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMciDlg)
	enum { IDD = IDD_MCI_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMciDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	 HICON m_hIcon;
	 int SendEmail(const char* Address,
						  const char* Subject, 
						  const char* Text);
	// Generated message map functions
	//{{AFX_MSG(CMciDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MCIDLG_H__9BBF3087_D871_11D5_A954_AC5CBA017829__INCLUDED_)
