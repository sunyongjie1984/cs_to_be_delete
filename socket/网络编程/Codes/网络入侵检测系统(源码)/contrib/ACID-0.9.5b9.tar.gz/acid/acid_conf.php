<?php

$ACID_VERSION = "0.9.5b9";

/* Alert DB connection parameters
    - $alert_dbname   : MySQL database name of Snort alert DB
    - $alert_host     : host on which the DB is stored
    - $alert_port     : port on which to access the DB
    - $alert_user     : login to the database with this user
    - $alert_password : password of the DB user

   This information can be gleaned from the Snort database
   ouput plugin configuration.
 */
$alert_dbname   = "snort_log";
$alert_host     = "localhost";
$alert_port     = "";
$alert_user     = "root";
$alert_password = "mypassword";

/* maximum number of rows per criteria element */
$MAX_ROWS = 10;

/* Number of rows to display for any query results */
$show_rows = 50;

/* Number of alerts to return when giving mere a snapshot - 
   Last _X_ # of alerts */
$last_num_alerts = 15;

/* Number of scroll buttons to use when displaying query results */
$max_scroll_buttons = 12; 

/* Debug mode - How much debugging information should be shown
    0 : no extra information
    1 : extended debugging information 
 */
$debug_mode = 0;

/* Should certain statstics pages refresh? */
$refresh_stat_page = 1;

/* Number of seconds between refreshes of a statistics page */
$stat_page_refresh_time = 180;

/* Have mod_snort info in the database? */
$mod_snort_config = 0;

?>






