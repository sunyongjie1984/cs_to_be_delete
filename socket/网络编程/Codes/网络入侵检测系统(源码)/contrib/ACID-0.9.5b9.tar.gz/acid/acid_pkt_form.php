<?php
/*  
 * Analysis Console for Incident Databases (ACID)
 *
 * Author: Roman Danyliw <rdd@cert.org>, <roman@danyliw.com>
 *
 * Copyright (C) 2000 Carnegie Mellon University
 * (see the file 'acid_main.php' for license details)
 *
 * Purpose:   
 *
 */
?>

<?php

echo '
<!-- ************ Meta Criteria ******************** -->
<TABLE WIDTH="100%" BORDER=0>
  <TR>
      <TD WIDTH="40%" CLASS="metatitle"><B><FONT COLOR="#FFFFFF">Meta Criteria</FONT></B></TD>
      <TD></TD></TR>
</TABLE>

<TABLE WIDTH="100%" BORDER=2 BGCOLOR="#CCCC99">
  <TR>
      <TD COLSPAN=2>
           <B>Sensor: </B>
           <SELECT NAME="sensor">
             <OPTION VALUE=" " '.chk_select($sensor, " ").'>{ any sensor }';

     $temp_sql = "SELECT sid, hostname, interface, filter FROM sensor";
     $tmp_result = mysql_query($temp_sql, $db);
     if ( $tmp_result )
     {
        $tmp_num = mysql_num_rows($tmp_result);
        for ($i = 0; $i < $tmp_num; $i++ )
        {
           $myrow = mysql_fetch_row($tmp_result);
           echo '<OPTION VALUE="'.$myrow[0].'" '.chk_select($sensor, $myrow[0]).'>'.
                 '['.$myrow[0].'] '.GetSensorName($myrow[0], $db);
        }
        mysql_free_result($tmp_result);
     }
     echo '</SELECT>&nbsp;&nbsp;
          <B>Alert Group: </B>
           <SELECT NAME="ag">
             <OPTION VALUE=" " '.chk_select($ag, " ").'>{ any Alert Group }';

     $temp_sql = "SELECT ag_id, ag_name FROM acid_ag";
     $tmp_result = mysql_query($temp_sql, $db);
     if ( $tmp_result )
     {
        $tmp_num = mysql_num_rows($tmp_result);
        for ($i = 0; $i < $tmp_num; $i++ )
        {
           $myrow = mysql_fetch_row($tmp_result);
           echo '<OPTION VALUE="'.$myrow[0].'" '.chk_select($ag, $myrow[0]).'>'.
                 '['.$myrow[0].'] '.$myrow[1];
        }
        mysql_free_result($tmp_result);
     }
     echo '</SELECT>&nbsp;&nbsp;</TD>';

     echo '<TR>
            <TD><B>Signature: </B></TD>
           <TD>';  
     echo '<SELECT NAME="sig[0]"><OPTION VALUE=" "  '.chk_select($sig[0]," "). '>{ signature }';    
     echo '                      <OPTION VALUE="="     '.chk_select($sig[0],"="). '>exactly ';
     echo '                      <OPTION VALUE="LIKE" '.chk_select($sig[0],"LIKE").'>roughly</SELECT>';
     echo '<INPUT TYPE="text" NAME="sig[1]" SIZE=40 VALUE="'.$sig[1].'">
          </TD></TR>';    

echo '<TR>
      <TD><B>Alert Time:</B></TD>
      <TD>';
          
  for ( $i = 0; $i < $time_cnt; $i++ )
  {
      echo '<SELECT NAME="time['.$i.'][0]"><OPTION VALUE=" " '.chk_select($time[$i][0]," ").'>__'; 
      echo '                                   <OPTION VALUE="("  '.chk_select($time[$i][0],"(").'>(</SELECT>';
      echo '<SELECT NAME="time['.$i.'][1]">    <OPTION VALUE=" "  '.chk_select($time[$i][1]," "). '>{ time }';    
      echo '                                   <OPTION VALUE="="  '.chk_select($time[$i][1],"="). '>=';
      echo '                                   <OPTION VALUE="!=" '.chk_select($time[$i][1],"!=").'>!=';
      echo '                                   <OPTION VALUE="<"  '.chk_select($time[$i][1],"<"). '><';
      echo '                                   <OPTION VALUE="<=" '.chk_select($time[$i][1],"<=").'><=';
      echo '                                   <OPTION VALUE=">"  '.chk_select($time[$i][1],">"). '>>';
      echo '                                   <OPTION VALUE=">=" '.chk_select($time[$i][1],">=").'>>=</SELECT>';

      echo '<SELECT NAME="time['.$i.'][2]"><OPTION VALUE=" "  '.chk_select($time[$i][2]," " ).'>{ month }';
      echo '                               <OPTION VALUE="01" '.chk_select($time[$i][2],"01").'>Jan';
      echo '                               <OPTION VALUE="02" '.chk_select($time[$i][2],"02").'>Feb';
      echo '                               <OPTION VALUE="03" '.chk_select($time[$i][2],"03").'>Mar';
      echo '                               <OPTION VALUE="04" '.chk_select($time[$i][2],"04").'>Apr';
      echo '                               <OPTION VALUE="05" '.chk_select($time[$i][2],"05").'>May';
      echo '                               <OPTION VALUE="06" '.chk_select($time[$i][2],"06").'>Jun';
      echo '                               <OPTION VALUE="07" '.chk_select($time[$i][2],"07").'>Jly';
      echo '                               <OPTION VALUE="08" '.chk_select($time[$i][2],"08").'>Aug';
      echo '                               <OPTION VALUE="09" '.chk_select($time[$i][2],"09").'>Sep';
      echo '                               <OPTION VALUE="10" '.chk_select($time[$i][2],"10").'>Oct';
      echo '                               <OPTION VALUE="11" '.chk_select($time[$i][2],"11").'>Nov';
      echo '                               <OPTION VALUE="12" '.chk_select($time[$i][2],"12").'>Dec</SELECT>';
      echo '<INPUT TYPE="text" NAME="time['.$i.'][3]" SIZE=2 VALUE="'.$time[$i][3].'">';
      echo '<SELECT NAME="time['.$i.'][4]"><OPTION VALUE=" "    '.chk_select($time[$i][4]," ").'>{ year }';
      echo '                               <OPTION VALUE="1999" '.chk_select($time[$i][4],"1999").'>1999';
      echo '                               <OPTION VALUE="2000" '.chk_select($time[$i][4],"2000").'>2000';
      echo '                               <OPTION VALUE="2001" '.chk_select($time[$i][4],"2001").'>2001</SELECT>';
      echo '<INPUT TYPE="text" NAME="time['.$i.'][5]" SIZE=2 VALUE="'.$time[$i][5].'"><B>:</B>';
      echo '<INPUT TYPE="text" NAME="time['.$i.'][6]" SIZE=2 VALUE="'.$time[$i][6].'"><B>:</B>';
      echo '<INPUT TYPE="text" NAME="time['.$i.'][7]" SIZE=2 VALUE="'.$time[$i][7].'">';

      echo '<SELECT NAME="time['.$i.'][8]"><OPTION VALUE=" " '.chk_select($time[$i][8]," ").'>__';
      echo '                               <OPTION VALUE="(" '.chk_select($time[$i][8],"(").'>(';
      echo '                               <OPTION VALUE=")" '.chk_select($time[$i][8],")").'>)</SELECT>';
      echo '<SELECT NAME="time['.$i.'][9]"><OPTION VALUE=" "   '.chk_select($time[$i][9]," ").  '>__';
      echo '                               <OPTION VALUE="OR" '.chk_select($time[$i][9],"OR").  '>OR';
      echo '                               <OPTION VALUE="AND" '.chk_select($time[$i][9],"AND").'>AND</SELECT>';

                
      if ( $i == $time_cnt-1 )
         echo '    <INPUT TYPE="submit" NAME="submit" VALUE="ADD Time">';
      echo '<BR>';
   }
        echo '
</TABLE>';

  echo '
<!-- ************ IP Criteria ******************** -->
<P>
<TABLE WIDTH="100%" BORDER=0>
  <TR>
      <TD WIDTH="40%" CLASS="iptitle"><B>IP Criteria</B></TD>
      <TD></TD></TR>
</TABLE>

<TABLE WIDTH="100%" BORDER=2 BGCOLOR="#CCCC99">';
      echo '<TR><TD VALIGN=TOP><B>Address:</B>';  
      echo '    <TD>';
  for ( $i = 0; $i < $ip_addr_cnt; $i++ )
  {

      echo '    <SELECT NAME="ip_addr['.$i.'][0]"><OPTION VALUE=" " '.chk_select($ip_addr[$i][0]," ").'>__'; 
      echo '                                      <OPTION VALUE="(" '.chk_select($ip_addr[$i][0],"(").'>(</SELECT>';
      echo '    <SELECT NAME="ip_addr['.$i.'][1]">
                   <OPTION VALUE=" "      '.chk_select($ip_addr[$i][1]," "     ).'>{ address }
                   <OPTION VALUE="ip_src" '.chk_select($ip_addr[$i][1],"ip_src").'>Source
                   <OPTION VALUE="ip_dst" '.chk_select($ip_addr[$i][1],"ip_dst").'>Dest
                </SELECT>'; 
      echo '    <SELECT NAME="ip_addr['.$i.'][2]">
                   <OPTION VALUE="="  '.chk_select($ip_addr[$i][2],"="). '>=
                   <OPTION VALUE="!=" '.chk_select($ip_addr[$i][2],"!=").'>!=
                </SELECT>';
      echo '    <INPUT TYPE="text" NAME="ip_addr['.$i.'][3]" SIZE=3 VALUE="'.$ip_addr[$i][3].'"><B>.</B>';
      echo '    <INPUT TYPE="text" NAME="ip_addr['.$i.'][4]" SIZE=3 VALUE="'.$ip_addr[$i][4].'"><B>.</B>';
      echo '    <INPUT TYPE="text" NAME="ip_addr['.$i.'][5]" SIZE=3 VALUE="'.$ip_addr[$i][5].'"><B>.</B>';
      echo '    <INPUT TYPE="text" NAME="ip_addr['.$i.'][6]" SIZE=3 VALUE="'.$ip_addr[$i][6].'"><!--<B>/</B>';
      echo '    <INPUT TYPE="text" NAME="ip_addr['.$i.'][7]" SIZE=3 VALUE="'.$ip_addr[$i][7].'">-->';
      echo '    <SELECT NAME="ip_addr['.$i.'][8]"><OPTION VALUE=" " '.chk_select($ip_addr[$i][8]," ").'>__';
      echo '                                      <OPTION VALUE="(" '.chk_select($ip_addr[$i][8],"(").'>(';
      echo '                                      <OPTION VALUE=")" '.chk_select($ip_addr[$i][8],")").'>)</SELECT>';
      echo '    <SELECT NAME="ip_addr['.$i.'][9]"><OPTION VALUE=" "   '.chk_select($ip_addr[$i][9]," ").  '>__';
      echo '                                      <OPTION VALUE="OR" '.chk_select($ip_addr[$i][9],"OR").  '>OR';
      echo '                                      <OPTION VALUE="AND" '.chk_select($ip_addr[$i][9],"AND").'>AND</SELECT>';
      if ( $i == $ip_addr_cnt-1 )
         echo '    <INPUT TYPE="submit" NAME="submit" VALUE="ADD Addr">';
      echo '<BR>';
  }

      echo '<TR><TD><B>Misc:</B>';
      echo '    <TD>';
  for ( $i = 0; $i < $ip_field_cnt; $i++ )
  {
      echo '    <SELECT NAME="ip_field['.$i.'][0]"><OPTION VALUE=" " '.chk_select($ip_field[$i][0]," ").'>__'; 
      echo '                                       <OPTION VALUE="(" '.chk_select($ip_field[$i][0],"(").'>(</SELECT>';
      echo '    <SELECT NAME="ip_field['.$i.'][1]"><OPTION VALUE=" "      '.chk_select($ip_field[$i][1]," ").'>{ field }';
      echo '                                       <OPTION VALUE="ip_tos" '.chk_select($ip_field[$i][1],"ip_tos").'>TOS';
      echo '                                       <OPTION VALUE="ip_ttl" '.chk_select($ip_field[$i][1],"ip_ttl").'>TTL'; 
      echo '                                       <OPTION VALUE="ip_id"  '.chk_select($ip_field[$i][1],"ip_id").'>ID';
      echo '                                       <OPTION VALUE="ip_off" '.chk_select($ip_field[$i][1],"ip_off").'>offset';
      echo '                                       <OPTION VALUE="ip_csum" '.chk_select($ip_field[$i][1],"ip_csum").'>chksum';     
      echo '                                       <OPTION VALUE="ip_len" '.chk_select($ip_field[$i][1],"ip_len").'>length</SELECT>';
      echo '    <SELECT NAME="ip_field['.$i.'][2]"><OPTION VALUE="="  '.chk_select($ip_field[$i][2],"="). '>=';
      echo '                                       <OPTION VALUE="!=" '.chk_select($ip_field[$i][2],"!=").'>!=';
      echo '                                       <OPTION VALUE="<"  '.chk_select($ip_field[$i][2],"<"). '><';
      echo '                                       <OPTION VALUE="<=" '.chk_select($ip_field[$i][2],"<=").'><=';
      echo '                                       <OPTION VALUE=">"  '.chk_select($ip_field[$i][2],">"). '>>';
      echo '                                       <OPTION VALUE=">=" '.chk_select($ip_field[$i][2],">=").'>>=</SELECT>';
      echo '    <INPUT TYPE="text" NAME="ip_field['.$i.'][3]" SIZE=5 VALUE="'.$ip_field[$i][3].'">';
      echo '    <SELECT NAME="ip_field['.$i.'][4]"><OPTION VALUE=" " '.chk_select($ip_field[$i][4]," ").'>__';
      echo '                                       <OPTION VALUE="(" '.chk_select($ip_field[$i][4],"(").'>(';
      echo '                                       <OPTION VALUE=")" '.chk_select($ip_field[$i][4],")").'>)</SELECT>';
      echo '    <SELECT NAME="ip_field['.$i.'][5]"><OPTION VALUE=" "   '.chk_select($ip_field[$i][5]," ").  '>__';
      echo '                                      <OPTION VALUE="OR" '.chk_select($ip_field[$i][5],"OR").  '>OR';
      echo '                                      <OPTION VALUE="AND" '.chk_select($ip_field[$i][5],"AND").'>AND</SELECT>';
      if ( $i == $ip_field_cnt-1 )
         echo '    <INPUT TYPE="submit" NAME="submit" VALUE="ADD IP Field">';
      echo '<BR>';
   }

/*      echo '<TR><TD><B>Option:</B>';
      echo '    <TD>';
  for ( $i = 0; $i < $ip_opt_cnt; $i++ )
  {
      echo '    <SELECT NAME="ip_opt['.$i.'][0]"><OPTION VALUE=" " '.chk_select($ip_opt[$i][0]," ").'>__'; 
      echo '                                       <OPTION VALUE="(" '.chk_select($ip_opt[$i][0],"(").'>(</SELECT>';
      echo '    <SELECT NAME="ip_opt['.$i.'][1]"><OPTION VALUE=" "      '.chk_select($ip_opt[$i][1]," ").'>{ field }';
      echo '                                       <OPTION VALUE="opt_code" '.chk_select($ip_opt[$i][1],"opt_code").'>code';
      echo '                                       <OPTION VALUE="opt_len" '.chk_select($ip_opt[$i][1],"opt_len").'>length</SELECT>';
      echo '    <SELECT NAME="ip_opt['.$i.'][2]"><OPTION VALUE="="  '.chk_select($ip_opt[$i][2],"="). '>=';
      echo '                                       <OPTION VALUE="!=" '.chk_select($ip_opt[$i][2],"!=").'>!=';
      echo '                                       <OPTION VALUE="<"  '.chk_select($ip_opt[$i][2],"<"). '><';
      echo '                                       <OPTION VALUE="<=" '.chk_select($ip_opt[$i][2],"<=").'><=';
      echo '                                       <OPTION VALUE=">"  '.chk_select($ip_opt[$i][2],">"). '>>';
      echo '                                       <OPTION VALUE=">=" '.chk_select($ip_opt[$i][2],">=").'>>=</SELECT>';
      echo '    <INPUT TYPE="text" NAME="ip_opt['.$i.'][3]" SIZE=5 VALUE="'.$ip_opt[$i][3].'">';
      echo '    <SELECT NAME="ip_opt['.$i.'][4]"><OPTION VALUE=" " '.chk_select($ip_opt[$i][4]," ").'>__';
      echo '                                       <OPTION VALUE="(" '.chk_select($ip_opt[$i][4],"(").'>(';
      echo '                                       <OPTION VALUE=")" '.chk_select($ip_opt[$i][4],")").'>)</SELECT>';
      echo '    <SELECT NAME="ip_opt['.$i.'][5]"><OPTION VALUE=" "   '.chk_select($ip_opt[$i][5]," ").  '>__';
      echo '                                      <OPTION VALUE="OR" '.chk_select($ip_opt[$i][5],"OR").  '>OR';
      echo '                                      <OPTION VALUE="AND" '.chk_select($ip_opt[$i][5],"AND").'>AND</SELECT>';
      if ( $i == $ip_opt_cnt-1 )
         echo '    <INPUT TYPE="submit" NAME="submit" VALUE="ADD IP Option Field">';
      echo '<BR>';
   } */

   echo '
   <TR><TD><B>Layer-4:</B>
       <TD>';
   if ( $layer4 != "" )
      echo '<INPUT TYPE="submit" NAME="submit" VALUE="no layer4"> &nbsp';
   if ( $layer4 == "TCP" )
      echo '  
           <INPUT TYPE="submit" NAME="submit" VALUE="UDP"> &nbsp
           <INPUT TYPE="submit" NAME="submit" VALUE="ICMP">';
   else if ( $layer4 == "UDP" )
      echo '  
           <INPUT TYPE="submit" NAME="submit" VALUE="TCP"> &nbsp
           <INPUT TYPE="submit" NAME="submit" VALUE="ICMP">';
   else if ( $layer4 == "ICMP" )
      echo '  
           <INPUT TYPE="submit" NAME="submit" VALUE="TCP"> &nbsp
           <INPUT TYPE="submit" NAME="submit" VALUE="UDP">';
    else
      echo '  
           <INPUT TYPE="submit" NAME="submit" VALUE="TCP"> &nbsp
           <INPUT TYPE="submit" NAME="submit" VALUE="UDP">
           <INPUT TYPE="submit" NAME="submit" VALUE="ICMP">';
   
echo '
   </TABLE>';

if ( $layer4 == "TCP" )
{
  echo '
<!-- ************ TCP Criteria ******************** -->
<P>
<TABLE WIDTH="100%" BORDER=0>
  <TR>
      <TD WIDTH="40%" CLASS="layer4title"><B>TCP Criteria</B></TD>
      <TD></TD>
</TABLE>

<TABLE WIDTH="100%" BORDER=2 BGCOLOR="#CCCC99">';

      echo '<TR><TD><B>Port:</B>';
      echo '    <TD>';
  for ( $i = 0; $i < $tcp_port_cnt; $i++ )
  {
      echo '    <SELECT NAME="tcp_port['.$i.'][0]"><OPTION VALUE=" " '.chk_select($tcp_port[$i][0]," ").'>__'; 
      echo '                                       <OPTION VALUE="(" '.chk_select($tcp_port[$i][0],"(").'>(</SELECT>';
      echo '    <SELECT NAME="tcp_port['.$i.'][1]"><OPTION VALUE=" "      '.chk_select($tcp_port[$i][1]," ").'>{ port }';
      echo '                                       <OPTION VALUE="tcp_sport" '.chk_select($tcp_port[$i][1],"tcp_sport").'>Source';
      echo '                                       <OPTION VALUE="tcp_dport" '.chk_select($tcp_port[$i][1],"tcp_dport").'>Dest</SELECT>';
      echo '    <SELECT NAME="tcp_port['.$i.'][2]"><OPTION VALUE="="  '.chk_select($tcp_port[$i][2],"="). '>=';
      echo '                                       <OPTION VALUE="!=" '.chk_select($tcp_port[$i][2],"!=").'>!=';
      echo '                                       <OPTION VALUE="<"  '.chk_select($tcp_port[$i][2],"<"). '><';
      echo '                                       <OPTION VALUE="<=" '.chk_select($tcp_port[$i][2],"<=").'><=';
      echo '                                       <OPTION VALUE=">"  '.chk_select($tcp_port[$i][2],">"). '>>';
      echo '                                       <OPTION VALUE=">=" '.chk_select($tcp_port[$i][2],">=").'>>=</SELECT>';
      echo '    <INPUT TYPE="text" NAME="tcp_port['.$i.'][3]" SIZE=5 VALUE="'.$tcp_port[$i][3].'">';
      echo '    <SELECT NAME="tcp_port['.$i.'][4]"><OPTION VALUE=" " '.chk_select($tcp_port[$i][4]," ").'>__';
      echo '                                       <OPTION VALUE="(" '.chk_select($tcp_port[$i][4],"(").'>(';
      echo '                                       <OPTION VALUE=")" '.chk_select($tcp_port[$i][4],")").'>)</SELECT>';
      echo '    <SELECT NAME="tcp_port['.$i.'][5]"><OPTION VALUE=" "   '.chk_select($tcp_port[$i][5]," ").  '>__';
      echo '                                      <OPTION VALUE="OR" '.chk_select($tcp_port[$i][5],"OR").  '>OR';
      echo '                                      <OPTION VALUE="AND" '.chk_select($tcp_port[$i][5],"AND").'>AND</SELECT>';
      if ( $i == $tcp_port_cnt-1 )
         echo '    <INPUT TYPE="submit" NAME="submit" VALUE="ADD TCP Port">';
      echo '<BR>';
   }

  echo '
  <TR>
      <TD VALIGN=TOP><B>Flags:</B>';
  echo '<TD><SELECT NAME="tcp_flags[0]"><OPTION VALUE=" " '.chk_select($tcp_flags[0]," ").'>{ flags }';
  echo '                              <OPTION VALUE="is" '.chk_select($tcp_flags[0],"is").'>is';
  echo '                              <OPTION VALUE="contains" '.chk_select($tcp_flags[0],"contains").'>contains</SELECT>';
  echo '   <FONT>';
  echo '    <INPUT TYPE="checkbox" NAME="tcp_flags[8]" VALUE="128" '.chk_check($tcp_flags[8],"128").'> [RSV1] &nbsp'; 
  echo '    <INPUT TYPE="checkbox" NAME="tcp_flags[7]" VALUE="64"  '.chk_check($tcp_flags[7],"64").'> [RSV0] &nbsp';
  echo '    <INPUT TYPE="checkbox" NAME="tcp_flags[6]" VALUE="32"  '.chk_check($tcp_flags[6],"32").'> [URG] &nbsp';
  echo '    <INPUT TYPE="checkbox" NAME="tcp_flags[5]" VALUE="16"  '.chk_check($tcp_flags[5],"16").'> [ACK] &nbsp';
  echo '    <INPUT TYPE="checkbox" NAME="tcp_flags[3]" VALUE="8"   '.chk_check($tcp_flags[4],"8").'> [PSH] &nbsp'; 
  echo '    <INPUT TYPE="checkbox" NAME="tcp_flags[4]" VALUE="4"   '.chk_check($tcp_flags[3],"4").'> [RST] &nbsp';
  echo '    <INPUT TYPE="checkbox" NAME="tcp_flags[2]" VALUE="2"   '.chk_check($tcp_flags[2],"2").'> [SYN] &nbsp';
  echo '    <INPUT TYPE="checkbox" NAME="tcp_flags[1]" VALUE="1"   '.chk_check($tcp_flags[1],"1").'> [FIN] &nbsp';
  echo '  </FONT>';

      echo '<TR><TD><B>Misc:</B>';
      echo '    <TD>';
  for ( $i = 0; $i < $tcp_field_cnt; $i++ )
  {
      echo '    <SELECT NAME="tcp_field['.$i.'][0]"><OPTION VALUE=" " '.chk_select($tcp_field[$i][0]," ").'>__'; 
      echo '                                       <OPTION VALUE="(" '.chk_select($tcp_field[$i][0],"(").'>(</SELECT>';
      echo '    <SELECT NAME="tcp_field['.$i.'][1]"><OPTION VALUE=" "      '.chk_select($tcp_field[$i][1]," ").'>{ field }';
      echo '                                       <OPTION VALUE="tcp_seq" '.chk_select($tcp_field[$i][1],"tcp_seq").'>seq #';
      echo '                                       <OPTION VALUE="tcp_ack" '.chk_select($tcp_field[$i][1],"tcp_ack").'>ack';
      echo '                                       <OPTION VALUE="tcp_off" '.chk_select($tcp_field[$i][1],"tcp_off").'>offset';
      echo '                                       <OPTION VALUE="tcp_res" '.chk_select($tcp_field[$i][1],"tcp_res").'>res';
      echo '                                       <OPTION VALUE="tcp_win" '.chk_select($tcp_field[$i][1],"tcp_win").'>window';
      echo '                                       <OPTION VALUE="tcp_csum" '.chk_select($tcp_field[$i][1],"tcp_csum").'>chksum';
      echo '                                       <OPTION VALUE="tcp_urp" '.chk_select($tcp_field[$i][1],"tcp_urp").'>urp</SELECT>';
      echo '    <SELECT NAME="tcp_field['.$i.'][2]"><OPTION VALUE="="  '.chk_select($tcp_field[$i][2],"="). '>=';
      echo '                                       <OPTION VALUE="!=" '.chk_select($tcp_field[$i][2],"!=").'>!=';
      echo '                                       <OPTION VALUE="<"  '.chk_select($tcp_field[$i][2],"<"). '><';
      echo '                                       <OPTION VALUE="<=" '.chk_select($tcp_field[$i][2],"<=").'><=';
      echo '                                       <OPTION VALUE=">"  '.chk_select($tcp_field[$i][2],">"). '>>';
      echo '                                       <OPTION VALUE=">=" '.chk_select($tcp_field[$i][2],">=").'>>=</SELECT>';
      echo '    <INPUT TYPE="text" NAME="tcp_field['.$i.'][3]" SIZE=5 VALUE="'.$tcp_field[$i][3].'">';
      echo '    <SELECT NAME="tcp_field['.$i.'][4]"><OPTION VALUE=" " '.chk_select($tcp_field[$i][4]," ").'>__';
      echo '                                       <OPTION VALUE="(" '.chk_select($tcp_field[$i][4],"(").'>(';
      echo '                                       <OPTION VALUE=")" '.chk_select($tcp_field[$i][4],")").'>)</SELECT>';
      echo '    <SELECT NAME="tcp_field['.$i.'][5]"><OPTION VALUE=" "   '.chk_select($tcp_field[$i][5]," ").  '>__';
      echo '                                      <OPTION VALUE="OR" '.chk_select($tcp_field[$i][5],"OR").  '>OR';
      echo '                                      <OPTION VALUE="AND" '.chk_select($tcp_field[$i][5],"AND").'>AND</SELECT>';
      if ( $i == $tcp_field_cnt-1 )
         echo '    <INPUT TYPE="submit" NAME="submit" VALUE="ADD TCP Field">';
      echo '<BR>';
   }

/*      echo '<TR><TD><B>Option:</B>';
      echo '    <TD>';
  for ( $i = 0; $i < $tcp_opt_cnt; $i++ )
  {
      echo '    <SELECT NAME="tcp_opt['.$i.'][0]"><OPTION VALUE=" " '.chk_select($tcp_opt[$i][0]," ").'>__'; 
      echo '                                       <OPTION VALUE="(" '.chk_select($tcp_opt[$i][0],"(").'>(</SELECT>';
      echo '    <SELECT NAME="tcp_opt['.$i.'][1]"><OPTION VALUE=" "      '.chk_select($tcp_opt[$i][1]," ").'>{ field }';
      echo '                                       <OPTION VALUE="opt_code" '.chk_select($tcp_opt[$i][1],"opt_code").'>code';
      echo '                                       <OPTION VALUE="opt_len" '.chk_select($tcp_opt[$i][1],"opt_len").'>length</SELECT>';
      echo '    <SELECT NAME="tcp_opt['.$i.'][2]"><OPTION VALUE="="  '.chk_select($tcp_opt[$i][2],"="). '>=';
      echo '                                       <OPTION VALUE="!=" '.chk_select($tcp_opt[$i][2],"!=").'>!=';
      echo '                                       <OPTION VALUE="<"  '.chk_select($tcp_opt[$i][2],"<"). '><';
      echo '                                       <OPTION VALUE="<=" '.chk_select($tcp_opt[$i][2],"<=").'><=';
      echo '                                       <OPTION VALUE=">"  '.chk_select($tcp_opt[$i][2],">"). '>>';
      echo '                                       <OPTION VALUE=">=" '.chk_select($tcp_opt[$i][2],">=").'>>=</SELECT>';
      echo '    <INPUT TYPE="text" NAME="tcp_opt['.$i.'][3]" SIZE=5 VALUE="'.$tcp_opt[$i][3].'">';
      echo '    <SELECT NAME="tcp_opt['.$i.'][4]"><OPTION VALUE=" " '.chk_select($tcp_opt[$i][4]," ").'>__';
      echo '                                       <OPTION VALUE="(" '.chk_select($tcp_opt[$i][4],"(").'>(';
      echo '                                       <OPTION VALUE=")" '.chk_select($tcp_opt[$i][4],")").'>)</SELECT>';
      echo '    <SELECT NAME="tcp_opt['.$i.'][5]"><OPTION VALUE=" "   '.chk_select($tcp_opt[$i][5]," ").  '>__';
      echo '                                      <OPTION VALUE="OR" '.chk_select($tcp_opt[$i][5],"OR").  '>OR';
      echo '                                      <OPTION VALUE="AND" '.chk_select($tcp_opt[$i][5],"AND").'>AND</SELECT>';
      if ( $i == $tcp_opt_cnt-1 )
         echo '    <INPUT TYPE="submit" NAME="submit" VALUE="ADD TCP Option Field">';
      echo '<BR>';
   } */

  echo'
</TABLE>';
}

if ( $layer4 == "UDP" )
{
  echo '
<!-- ************ UDP Criteria ******************** -->
<P>
<TABLE WIDTH="100%" BORDER=0>
  <TR>
      <TD WIDTH="40%" CLASS="layer4title"><B>UDP Criteria</B></TD>
      <TD></TD>
</TABLE>

<TABLE WIDTH="100%" BORDER=2 BGCOLOR="#CCCC99">';

      echo '<TR><TD><B>Port:</B>';
      echo '    <TD>';
  for ( $i = 0; $i < $udp_port_cnt; $i++ )
  {
      echo '    <SELECT NAME="udp_port['.$i.'][0]"><OPTION VALUE=" " '.chk_select($udp_port[$i][0]," ").'>__'; 
      echo '                                       <OPTION VALUE="(" '.chk_select($udp_port[$i][0],"(").'>(</SELECT>';
      echo '    <SELECT NAME="udp_port['.$i.'][1]"><OPTION VALUE=" "      '.chk_select($udp_port[$i][1]," ").'>{ port }';
      echo '                                       <OPTION VALUE="udp_sport" '.chk_select($udp_port[$i][1],"udp_sport").'>Source';
      echo '                                       <OPTION VALUE="udp_dport" '.chk_select($udp_port[$i][1],"udp_dport").'>Dest</SELECT>';
      echo '    <SELECT NAME="udp_port['.$i.'][2]"><OPTION VALUE="="  '.chk_select($udp_port[$i][2],"="). '>=';
      echo '                                       <OPTION VALUE="!=" '.chk_select($udp_port[$i][2],"!=").'>!=';
      echo '                                       <OPTION VALUE="<"  '.chk_select($udp_port[$i][2],"<"). '><';
      echo '                                       <OPTION VALUE="<=" '.chk_select($udp_port[$i][2],"<=").'><=';
      echo '                                       <OPTION VALUE=">"  '.chk_select($udp_port[$i][2],">"). '>>';
      echo '                                       <OPTION VALUE=">=" '.chk_select($udp_port[$i][2],">=").'>>=</SELECT>';
      echo '    <INPUT TYPE="text" NAME="udp_port['.$i.'][3]" SIZE=5 VALUE="'.$udp_port[$i][3].'">';
      echo '    <SELECT NAME="udp_port['.$i.'][4]"><OPTION VALUE=" " '.chk_select($udp_port[$i][4]," ").'>__';
      echo '                                       <OPTION VALUE="(" '.chk_select($udp_port[$i][4],"(").'>(';
      echo '                                       <OPTION VALUE=")" '.chk_select($udp_port[$i][4],")").'>)</SELECT>';
      echo '    <SELECT NAME="udp_port['.$i.'][5]"><OPTION VALUE=" "   '.chk_select($udp_port[$i][5]," ").  '>__';
      echo '                                      <OPTION VALUE="OR" '.chk_select($udp_port[$i][5],"OR").  '>OR';
      echo '                                      <OPTION VALUE="AND" '.chk_select($udp_port[$i][5],"AND").'>AND</SELECT>';
      if ( $i == $udp_port_cnt-1 )
         echo '    <INPUT TYPE="submit" NAME="submit" VALUE="ADD UDP Port">';
      echo '<BR>';
  }

      echo '<TR><TD><B>Misc:</B>';
      echo '    <TD>';
  for ( $i = 0; $i < $udp_field_cnt; $i++ )
  {
      echo '    <SELECT NAME="udp_field['.$i.'][0]"><OPTION VALUE=" " '.chk_select($udp_field[$i][0]," ").'>__'; 
      echo '                                       <OPTION VALUE="(" '.chk_select($udp_field[$i][0],"(").'>(</SELECT>';
      echo '    <SELECT NAME="udp_field['.$i.'][1]"><OPTION VALUE=" "      '.chk_select($udp_field[$i][1]," ").'>{ field }';
      echo '                                       <OPTION VALUE="udp_len" '.chk_select($udp_field[$i][1],"udp_len").'>length';
      echo '                                       <OPTION VALUE="udp_csum" '.chk_select($udp_field[$i][1],"udp_csum").'>chksum</SELECT>';
      echo '    <SELECT NAME="udp_field['.$i.'][2]"><OPTION VALUE="="  '.chk_select($udp_field[$i][2],"="). '>=';
      echo '                                       <OPTION VALUE="!=" '.chk_select($udp_field[$i][2],"!=").'>!=';
      echo '                                       <OPTION VALUE="<"  '.chk_select($udp_field[$i][2],"<"). '><';
      echo '                                       <OPTION VALUE="<=" '.chk_select($udp_field[$i][2],"<=").'><=';
      echo '                                       <OPTION VALUE=">"  '.chk_select($udp_field[$i][2],">"). '>>';
      echo '                                       <OPTION VALUE=">=" '.chk_select($udp_field[$i][2],">=").'>>=</SELECT>';
      echo '    <INPUT TYPE="text" NAME="udp_field['.$i.'][3]" SIZE=5 VALUE="'.$udp_field[$i][3].'">';
      echo '    <SELECT NAME="udp_field['.$i.'][4]"><OPTION VALUE=" " '.chk_select($udp_field[$i][4]," ").'>__';
      echo '                                       <OPTION VALUE="(" '.chk_select($udp_field[$i][4],"(").'>(';
      echo '                                       <OPTION VALUE=")" '.chk_select($udp_field[$i][4],")").'>)</SELECT>';
      echo '    <SELECT NAME="udp_field['.$i.'][5]"><OPTION VALUE=" "   '.chk_select($udp_field[$i][5]," ").  '>__';
      echo '                                      <OPTION VALUE="OR" '.chk_select($udp_field[$i][5],"OR").  '>OR';
      echo '                                      <OPTION VALUE="AND" '.chk_select($udp_field[$i][5],"AND").'>AND</SELECT>';
      if ( $i == $udp_field_cnt-1 )
         echo '    <INPUT TYPE="submit" NAME="submit" VALUE="ADD UDP Field">';
      echo '<BR>';
   }

  echo'
</TABLE>';
}


if ( $layer4 == "ICMP" )
{
  echo  '
<!-- ************ ICMP Criteria ******************** -->
<P>
<TABLE WIDTH="100%" BORDER=0>
  <TR>
      <TD WIDTH="40%" CLASS="layer4title"><B>ICMP Criteria</B></TD>
      <TD></TD>
</TABLE>


<TABLE WIDTH="100%" BORDER=2 BGCOLOR="#CCCC99">';

      echo '<TR><TD><B>Misc:</B>';
      echo '    <TD>';
  for ( $i = 0; $i < $icmp_field_cnt; $i++ )
  {
      echo '    <SELECT NAME="icmp_field['.$i.'][0]"><OPTION VALUE=" " '.chk_select($icmp_field[$i][0]," ").'>__'; 
      echo '                                       <OPTION VALUE="(" '.chk_select($icmp_field[$i][0],"(").'>(</SELECT>';
      echo '    <SELECT NAME="icmp_field['.$i.'][1]">
                                           <OPTION VALUE=" "      '.chk_select($icmp_field[$i][1]," ").'>{ field }';
      echo '                               <OPTION VALUE="icmp_type" '.chk_select($icmp_field[$i][1],"icmp_type").'>type';
      echo '                               <OPTION VALUE="icmp_code" '.chk_select($icmp_field[$i][1],"icmp_code").'>code';
      echo '                               <OPTION VALUE="icmp_id" '.chk_select($icmp_field[$i][1],"icmp_id").'>id';
      echo '                               <OPTION VALUE="icmp_seq" '.chk_select($icmp_field[$i][1],"icmp_seq").'>seq #';
      echo '                               <OPTION VALUE="icmp_csum" '.chk_select($icmp_field[$i][1],"icmp_csum").'>chksum</SELECT>';
      echo '    <SELECT NAME="icmp_field['.$i.'][2]">
                                           <OPTION VALUE="="  '.chk_select($icmp_field[$i][2],"="). '>=';
      echo '                               <OPTION VALUE="!=" '.chk_select($icmp_field[$i][2],"!=").'>!=';
      echo '                               <OPTION VALUE="<"  '.chk_select($icmp_field[$i][2],"<"). '><';
      echo '                               <OPTION VALUE="<=" '.chk_select($icmp_field[$i][2],"<=").'><=';
      echo '                               <OPTION VALUE=">"  '.chk_select($icmp_field[$i][2],">"). '>>';
      echo '                               <OPTION VALUE=">=" '.chk_select($icmp_field[$i][2],">=").'>>=</SELECT>';
      echo '    <INPUT TYPE="text" NAME="icmp_field['.$i.'][3]" SIZE=5 VALUE="'.$icmp_field[$i][3].'">';
      echo '    <SELECT NAME="icmp_field['.$i.'][4]"><OPTION VALUE=" " '.chk_select($icmp_field[$i][4]," ").'>__';
      echo '                                       <OPTION VALUE="(" '.chk_select($icmp_field[$i][4],"(").'>(';
      echo '                                       <OPTION VALUE=")" '.chk_select($icmp_field[$i][4],")").'>)</SELECT>';
      echo '    <SELECT NAME="icmp_field['.$i.'][5]"><OPTION VALUE=" "   '.chk_select($icmp_field[$i][5]," ").  '>__';
      echo '                                      <OPTION VALUE="OR" '.chk_select($icmp_field[$i][5],"OR").  '>OR';
      echo '                                      <OPTION VALUE="AND" '.chk_select($icmp_field[$i][5],"AND").'>AND</SELECT>';
      if ( $i == $icmp_field_cnt-1 )
         echo '    <INPUT TYPE="submit" NAME="submit" VALUE="ADD ICMP Field">';
      echo '<BR>';
   }
   echo '
</TABLE>'; 
}

echo '
<!-- ************ Payload Criteria ******************** -->
<P>
<TABLE WIDTH="100%" BORDER=0>
  <TR>
      <TD WIDTH="40%" CLASS="payloadtitle"><B><FONT COLOR="#FFFFFF">Payload Criteria</FONT></B></TD>
      <TD></TD></TR>
</TABLE>

<TABLE WIDTH="100%" BORDER=2 BGCOLOR="#CCCC99">
  <TR>
      <TD><B>Input Criteria Encoding Type:</B>';
  echo '<SELECT NAME="data_encode[0]"><OPTION VALUE=" "    '.chk_select($data_encode[0]," ").'>{ Encoding }'; 
  echo '                              <OPTION VALUE="hex"  '.chk_select($data_encode[0],"hex").'>hex';
  echo '                              <OPTION VALUE="ascii"'.chk_select($data_encode[0],"ascii").'>ascii</SELECT>';
  echo '<B>Convert To (when searching):</B>';
  echo '<SELECT NAME="data_encode[1]"><OPTION VALUE=" "    '.chk_select($data_encode[1]," ").'>{ Convert To }'; 
  echo '                              <OPTION VALUE="hex"  '.chk_select($data_encode[1],"hex").'>hex';
  echo '                              <OPTION VALUE="ascii"'.chk_select($data_encode[1],"ascii").'>ascii</SELECT>';
  echo '<BR>';

  for ( $i = 0; $i < $data_cnt; $i++ )
  {
      echo '<SELECT NAME="data['.$i.'][0]"><OPTION VALUE=" " '.chk_select($data[$i][0]," ").'>__'; 
      echo '                               <OPTION VALUE="("  '.chk_select($data[$i][0],"(").'>(</SELECT>';
      echo '<SELECT NAME="data['.$i.'][1]"><OPTION VALUE=" "  '.chk_select($data[$i][1]," "). '>{ payload }';    
      echo '                               <OPTION VALUE="LIKE"     '.chk_select($data[$i][1],"LIKE"). '>has ';
      echo '                               <OPTION VALUE="NOT LIKE" '.chk_select($data[$i][1],"NOT LIKE").'>has NOT</SELECT>';

      echo '<INPUT TYPE="text" NAME="data['.$i.'][2]" SIZE=45 VALUE="'.$data[$i][2].'">';

      echo '<SELECT NAME="data['.$i.'][3]"><OPTION VALUE=" " '.chk_select($data[$i][3]," ").'>__';
      echo '                               <OPTION VALUE="(" '.chk_select($data[$i][3],"(").'>(';
      echo '                               <OPTION VALUE=")" '.chk_select($data[$i][3],")").'>)</SELECT>';
      echo '<SELECT NAME="data['.$i.'][4]"><OPTION VALUE=" "   '.chk_select($data[$i][4]," ").  '>__';
      echo '                               <OPTION VALUE="OR" '.chk_select($data[$i][4],"OR").  '>OR';
      echo '                               <OPTION VALUE="AND" '.chk_select($data[$i][4],"AND").'>AND</SELECT>';

      if ( $i == $data_cnt-1 )
         echo '    <INPUT TYPE="submit" NAME="submit" VALUE="ADD Payload">';
      echo '<BR>';
   }
        echo '
</TABLE>';

?>
