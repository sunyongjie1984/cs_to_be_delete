<?php
/*  
 * Analysis Console for Incident Databases (ACID)
 *
 * Author: Roman Danyliw <rdd@cert.org>, <roman@danyliw.com>
 *
 * Copyright (C) 2000 Carnegie Mellon University
 * (see the file 'acid_main.php' for license details)
 *
 * Purpose:   
 *
 */

function SensorCnt($db)
{
   $result = mysql_query("SELECT count(*) FROM sensor;", $db);
   $myrow = mysql_fetch_row($result);
   $num = $myrow[0];
   mysql_free_result($result);

   return $num;
}

function EventCnt($db)
{
   $result = mysql_query("SELECT count(*) FROM event;", $db);
   $myrow = mysql_fetch_row($result);
   $num = $myrow[0];
   mysql_free_result($result);

   return $num;
}

/*
 * Takes: Numeric sensor ID from the Sensor table (SID), and 
 *	  database connection.
 * 
 * Returns: The number of unique alert descriptions for the 
 * 	    given sensor ID. 
 *
 */
function UniqueCntBySensor($sensorID, $db)
{

  /* Calculate the Unique Alerts */
  $query = "SELECT distinctrow signature FROM event WHERE sid = " . $sensorID . ";";

  $result = mysql_query($query, $db);

  if ( $result  ) {
        $num = mysql_num_rows($result);
  }

  else {
        $num = 0;
  }

  mysql_free_result($result);

  return $num;
}

/*
 * Takes: Numeric sensor ID from the Sensor table (SID), and 
 *        database connection.
 * 
 * Returns: The total number of alerts for the given sensor ID
 */ 
function EventCntBySensor($sensorID, $db)
{
   $query_string = "SELECT count(*) FROM event where SID = " .$sensorID. ";";

   $result = mysql_query($query_string, $db);
   $myrow = mysql_fetch_row($result);
   $num = $myrow[0];
   mysql_free_result($result);

   return $num;
}

function MinDateBySensor($sensorID, $db)
{
   $query_string = "SELECT min(timestamp) FROM event WHERE sid=" . $sensorID . ";";

   $result = mysql_query($query_string, $db);
   $myrow = mysql_fetch_row($result);
   $num = $myrow[0];
   mysql_free_result($result);

   return $num;

}


function MaxDateBySensor($sensorID, $db)
{
   $query_string = "SELECT max(timestamp) FROM event WHERE sid=" . $sensorID . ";";

   $result = mysql_query($query_string, $db);
   $myrow = mysql_fetch_row($result);
   $num = $myrow[0];
   mysql_free_result($result);

   return $num;

}

function UniqueDestAddrCntBySensor( $sensorID, $db )
{
   $query_string = "SELECT distinctrow ip_dst from iphdr WHERE sid=" . $sensorID . ";";

   $result = mysql_query($query_string, $db);
   $num = mysql_num_rows($result);
   mysql_free_result($result);

   return $num;

}

function UniqueSrcAddrCntBySensor( $sensorID, $db )
{
   $query_string = "SELECT distinctrow ip_src from iphdr WHERE sid=" . $sensorID . ";";

   $result = mysql_query($query_string, $db);
   $num = mysql_num_rows($result);
   mysql_free_result($result);

   return $num;

}

function TCPPktCnt($db)
{
   $result = mysql_query("SELECT count(*) FROM tcphdr;", $db);
   $myrow = mysql_fetch_row($result);
   $num = $myrow[0];
   mysql_free_result($result);

   return $num;
}

function UDPPktCnt($db)
{
   $result = mysql_query("SELECT count(*) FROM udphdr;", $db);
   $myrow = mysql_fetch_row($result);
   $num = $myrow[0];
   mysql_free_result($result);

   return $num;
}

function ICMPPktCnt($db)
{
   $result = mysql_query("SELECT count(*) FROM icmphdr;", $db);
   $myrow = mysql_fetch_row($result);
   $num = $myrow[0];
   mysql_free_result($result);

   return $num;
}

function UniqueSrcIPCnt($db)
{
   $result = mysql_query("SELECT distinctrow ip_src FROM iphdr;", $db);
   $num = mysql_num_rows($result);
   mysql_free_result($result);
   return $num;
}

function UniqueDstIPCnt($db)
{
   $result = mysql_query("SELECT distinctrow ip_dst FROM iphdr;", $db);
   $num = mysql_num_rows($result);
   mysql_free_result($result);
   return $num;
}

function StartStopTime(&$start_time, &$stop_time, $db)
{
   $result = mysql_query("SELECT min(timestamp), max(timestamp) FROM event;", $db);
   $myrow = mysql_fetch_row($result);
   $start_time = $myrow[0];
   $stop_time = $myrow[1];
   mysql_free_result($result);
}

function UniqueAlertCnt($db)
{
   $result = mysql_query("SELECT distinctrow signature FROM event;", $db);
   $num = mysql_num_rows($result);
   mysql_free_result($result);

   return $num;
}

?>
