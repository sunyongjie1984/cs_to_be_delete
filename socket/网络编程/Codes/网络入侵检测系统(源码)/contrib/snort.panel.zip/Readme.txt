=============================================
 Xato snort.panel utility v1.0 build 10
 Copyright (c) 2000 Xato Network Security, Inc.
=============================================

THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY WARRANTIES AS TO PERFORMANCE, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR ANY OTHER WARRANTIES WHETHER EXPRESSED OR IMPLIED. THE ENTIRE RISK AS TO THE RESULTS AND PERFORMANCE OF THE SOFTWARE IS ASSUMED BY YOU. THE AUTHOR SHALL NOT HAVE ANY LIABILITY TO YOU OR ANY OTHER PERSON OR ENTITY FOR ANY DAMAGES WHATSOEVER, INCLUDING, BUT NOT LIMITED TO, LOSS OF REVENUE OR PROFIT, LOST OR  DAMAGED DATA OR OTHER.  THE AUTHOR IS ALSO NOT RESPONSIBLE FOR CLAIMS BY A THIRD PARTY.

This software is freeware. That means that you may use it as long as you want without owing the author any money. However, this software is not in the public domain. You may not modify, translate, reverse engineer,   compile, or disassemble this software.


You may download this and other utilities from our web site at: http://www.xato.net/downloads

For support, questions, comments please contact snort-panel@xato.net