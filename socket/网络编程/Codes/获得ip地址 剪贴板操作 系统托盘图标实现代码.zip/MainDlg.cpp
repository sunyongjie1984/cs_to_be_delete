// MainDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GetIP.h"
#include "MainDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainDlg dialog


CMainDlg::CMainDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMainDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMainDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMainDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMainDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMainDlg, CDialog)
	//{{AFX_MSG_MAP(CMainDlg)
	ON_MESSAGE(WM_TRAYICONCLICK, OnTrayIconClick)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainDlg message handlers


void CMainDlg::AddIcon()
{
	HICON hIcon = LoadIcon((AfxGetApp()->m_hInstance), MAKEINTRESOURCE(IDR_MAINFRAME));
	
	char tip[255];
	wsprintf(tip, "Name Resolver");
	TaskBarAddIcon(this->m_hWnd, IDR_MAINFRAME, hIcon, tip);

}

// Add icon to the taskbar.
BOOL CMainDlg::TaskBarAddIcon(HWND hwnd, UINT uID, HICON hicon, LPSTR lpszTip)
{
    BOOL res;
    NOTIFYICONDATA nid;
    nid.cbSize = sizeof(NOTIFYICONDATA);
    nid.hWnd = hwnd;
    nid.uID = uID;
    nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
    nid.uCallbackMessage = WM_TRAYICONCLICK;
    nid.hIcon = hicon;
    if (lpszTip)
        lstrcpyn(nid.szTip, lpszTip, sizeof(nid.szTip));
    else
        nid.szTip[0] = '\0';
    res = Shell_NotifyIcon(NIM_ADD, &nid);
    if (hicon)
        DestroyIcon(hicon);
    return res;
}

// Deletes an icon from the taskbar status area.
BOOL CMainDlg::TaskBarDeleteIcon(HWND hwnd, UINT uID)
{
    BOOL res;
    NOTIFYICONDATA tnid;
    tnid.cbSize = sizeof(NOTIFYICONDATA);
    tnid.hWnd = hwnd;
    tnid.uID = uID;
    res = Shell_NotifyIcon(NIM_DELETE, &tnid);
    return res;
}


void CMainDlg::RemoveIcon()
{
	TaskBarDeleteIcon( this->m_hWnd, IDR_MAINFRAME);
}

void CMainDlg::OnTrayIconClick(WPARAM wparm, LPARAM lparm) {
	if(lparm==WM_LBUTTONDBLCLK) {
		CGetIPDlg dlg;
		dlg.DoModal();

		if( dlg.m_Shutdown ) {
			RemoveIcon();
			OnCancel();
		}	
	}
}

BOOL CMainDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	AddIcon();
	
	m_nTimer=SetTimer(1,1000,0);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMainDlg::OnTimer(UINT nIDEvent) 
{
	
	ShowWindow(SW_HIDE);

	KillTimer(m_nTimer);
	CDialog::OnTimer(nIDEvent);
}
