// GetIPDlg.h : header file
//

#if !defined(AFX_GETIPDLG_H__7190345A_01EB_42D5_9990_42392B400BF1__INCLUDED_)
#define AFX_GETIPDLG_H__7190345A_01EB_42D5_9990_42392B400BF1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



/////////////////////////////////////////////////////////////////////////////
// CGetIPDlg dialog

class CGetIPDlg : public CDialog
{
// Construction
public:
	bool m_Shutdown;
	CGetIPDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CGetIPDlg)
	enum { IDD = IDD_GETIP_DIALOG };
	CString	m_strName;
	CString	m_strIP;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGetIPDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	HICON m_hIcon;


	// Generated message map functions
	//{{AFX_MSG(CGetIPDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnButtonClipboard();
	virtual void OnCancel();
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnDestroy();
	afx_msg void OnButtonQuit();
	afx_msg void OnBtnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GETIPDLG_H__7190345A_01EB_42D5_9990_42392B400BF1__INCLUDED_)
