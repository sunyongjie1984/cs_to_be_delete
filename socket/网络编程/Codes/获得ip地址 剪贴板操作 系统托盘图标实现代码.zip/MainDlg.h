#if !defined(AFX_MAINDLG_H__F10848EB_8531_4809_931B_E6D59193C962__INCLUDED_)
#define AFX_MAINDLG_H__F10848EB_8531_4809_931B_E6D59193C962__INCLUDED_

#include "GetIPDlg.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MainDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMainDlg dialog

class CMainDlg : public CDialog
{
// Construction
public:
	bool m_ShowWindow;
	UINT m_nTimer;
	void RemoveIcon();
	void AddIcon();

	CMainDlg(CWnd* pParent = NULL);   // standard constructor

	BOOL TaskBarDeleteIcon(HWND hwnd, UINT uID);
	BOOL TaskBarAddIcon(HWND hwnd, UINT uID, HICON hicon, LPSTR lpszTip);

// Dialog Data
	//{{AFX_DATA(CMainDlg)
	enum { IDD = IDD_DIALOG_MAIN };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMainDlg)
	afx_msg void OnTrayIconClick(WPARAM wparm, LPARAM lparm);		
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINDLG_H__F10848EB_8531_4809_931B_E6D59193C962__INCLUDED_)
