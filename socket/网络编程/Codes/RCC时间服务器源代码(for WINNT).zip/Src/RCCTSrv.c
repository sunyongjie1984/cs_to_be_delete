
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <process.h>
#include <tchar.h>
#include "service.h"

#include <winsock.h>
#include <string.h>
#include <memory.h>
#include <time.h>
#include "wsock.h"

//////////////////////////////////////////////////////////////////
//
HANDLE hInst;
HANDLE HWnd;
//
SOCKET sock;
u_short portno;
//
char szBuff[ 1000 ];
//
#define MAX_PENDING_CONNECTS	50	/* The backlog allowed for listen() */
#define NO_FLAGS_SET			0	/* Used with recv()/send()			*/
#define MY_MSG_LENGTH			80	/* msg buffer sent back and forth	*/
//
BOOL LogEvent(
	LPCTSTR  lpUNCServerName,
	WORD  wType,
	DWORD  dwEventID,
	PSID  lpUserSid,
	LPCTSTR  message);
//
BOOL MyReportStatusToSCMgr(
	DWORD dwCurrentState, 
	DWORD dwWin32ExitCode,
	DWORD dwWaitHint);
//
BOOL FillAddr(PSOCKADDR_IN psin);
//
BOOL AsyncListen(HANDLE hWnd);
//
BOOL InitApplication(HANDLE hInstance);
//
//////////////////////////////////////////////////////////////////



//
//	FUNCTION: ServiceStart
//
//	PURPOSE: Actual code of the service
//			 that does the work.
//
//	PARAMETERS:
//	  dwArgc   - number of command line arguments
//	  lpszArgv - array of command line arguments
//
//	RETURN VALUE:
//	  none
//
VOID ServiceStart (DWORD dwArgc, LPTSTR *lpszArgv)
{
	MSG msg;
	BOOL res;

	///////////////////////////////////////////////////
	//
	// Service initialization
	//

	if (!MyReportStatusToSCMgr(SERVICE_START_PENDING, NO_ERROR, 3000))
		return;

	if (!InitApplication(NULL))
		return;

	if (!MyReportStatusToSCMgr(SERVICE_START_PENDING, NO_ERROR, 3000))
		return;

	LogEvent(NULL, EVENTLOG_INFORMATION_TYPE, 7700, NULL, "RCC Time Server started successfully.");

	if (!MyReportStatusToSCMgr(SERVICE_RUNNING, NO_ERROR, 0))
		return;

	//
	// End of initialization
	//
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	//
	// Service is now running, perform work until shutdown
	//

	while ( (res=GetMessage(&msg, NULL, 0, 0)) != 0) {
		TranslateMessage(&msg);    /* Translates virtual key codes			 */
		DispatchMessage(&msg);	   /* Dispatches message to window			 */
	}
	return;
}


//
//	FUNCTION: ServiceStop
//
//	PURPOSE: Stops the service
//
//	PARAMETERS:
//	  none
//
//	RETURN VALUE:
//	  none
//
//	COMMENTS:
//	  If a ServiceStop procedure is going to
//	  take longer than 3 seconds to execute,
//	  it should spawn a thread to execute the
//	  stop code, and return.  Otherwise, the
//	  ServiceControlManager will believe that
//	  the service has stopped responding.
//		
VOID ServiceStop()
{
	LogEvent(NULL, EVENTLOG_WARNING_TYPE, 7701, NULL, "Service control manager has posted a stop request. Stopping.");
	WSACleanup();
	PostMessage(HWnd, WM_QUIT, 0, 0);
}


/****************************************************************************
*
*	 FUNCTION: MyReportStatusToSCMgr(state, exitCode, waitHin)
*
*\***************************************************************************/
BOOL MyReportStatusToSCMgr(
	DWORD dwCurrentState, 
	DWORD dwWin32ExitCode,
	DWORD dwWaitHint)
{
	if (!ReportStatusToSCMgr(dwCurrentState, dwWin32ExitCode, dwWaitHint)) {
		LogEvent(NULL, EVENTLOG_ERROR_TYPE, 7711, NULL, "Problem talking with the service control manager");
		return (FALSE);
	}
	return (TRUE);
}


/****************************************************************************
*
*	 FUNCTION: LogEvent(server, type, id, userSID, message)
*
*	 VALID TYPES ARE:
*		EVENTLOG_ERROR_TYPE 		Error event
*		EVENTLOG_WARNING_TYPE		Warning event
*		EVENTLOG_INFORMATION_TYPE	Information event
*
*\***************************************************************************/

BOOL LogEvent(
	LPCTSTR  lpUNCServerName,
	WORD  wType,
	DWORD  dwEventID,
	PSID  lpUserSid,
	LPCTSTR  message)
{
	HANDLE hElog;
	BOOL res;
	LPCTSTR  messages[] = {message, NULL};

	hElog = RegisterEventSource(lpUNCServerName, "RCC Time Server");
	res = ReportEvent(hElog, wType, 0, dwEventID, lpUserSid, 1, 0, messages, NULL);
	return (DeregisterEventSource(hElog) && res);
}


/****************************************************************************\
*
*	 FUNCTION:	FillAddr(PSOCKADDR_IN)
*
*	 PURPOSE:  Retrieves the IP address and port number.
*
*\***************************************************************************/

BOOL FillAddr(
	PSOCKADDR_IN psin)
{
	PSERVENT pse;

	psin->sin_family = AF_INET;
	psin->sin_addr.s_addr = INADDR_ANY;

	pse = getservbyname("time", "tcp");
	if (pse == NULL)  {
		sprintf(szBuff, "Cannot get TCP port number for 'time'. Check etc\\services file. (%d)", WSAGetLastError());
		LogEvent(NULL, EVENTLOG_ERROR_TYPE, 7703, NULL, szBuff);
		return FALSE;
	}
	psin->sin_port = pse->s_port;

	return TRUE;
}

				 
/****************************************************************************\
*
*	 FUNCTION:	AsyncListen(HWND)
*
*	 PURPOSE:	Sets up an asynchronous listener on our port.
*
*\***************************************************************************/

BOOL AsyncListen(HANDLE hWnd)
{
	int status;
	SOCKADDR_IN local_sin;

	sock = socket( AF_INET, SOCK_STREAM, 0);
			
	if (sock == INVALID_SOCKET) {
		LogEvent(NULL, EVENTLOG_ERROR_TYPE, 7704, NULL, "Cannot create new socket.");
		return FALSE;
	}

	if (!FillAddr(&local_sin)) {
		closesocket( sock );
		return FALSE;
	}
	
	if (bind( sock, (struct sockaddr FAR *) &local_sin, sizeof(local_sin)) == SOCKET_ERROR) {
		sprintf(szBuff, "Failed to bind socket (%d)", WSAGetLastError());
		LogEvent(NULL, EVENTLOG_ERROR_TYPE, 7705, NULL, szBuff);
		closesocket(sock);
		return FALSE;
	}

	if (listen( sock, SOMAXCONN ) < 0) {
		sprintf(szBuff, "Failed to listen (%d)", WSAGetLastError());
		LogEvent(NULL, EVENTLOG_ERROR_TYPE, 7706, NULL, szBuff);
		return FALSE;
	}

	if ((status = WSAAsyncSelect( sock, hWnd, WSA_EVENT, FD_ACCEPT | FD_CLOSE)) > 0) {
		LogEvent(NULL, EVENTLOG_ERROR_TYPE, 7707, NULL, "Failed to register sockets with window messages");
		closesocket(sock);
		return FALSE;
	}

	return TRUE;
}


/****************************************************************************
*
*	 FUNCTION: InitApplication(HANDLE)
*
*	 PURPOSE: Initializes data and registers window class
*
*\***************************************************************************/

BOOL InitApplication(HANDLE hInstance)
{
	WNDCLASS  wc;

	wc.style = 0;							/* Class style(s).					  */
	wc.lpfnWndProc = (WNDPROC)MainWndProc;	/* Function to retrieve messages	  */
	wc.cbClsExtra = 0;						/* No per-class extra data. 		  */
	wc.cbWndExtra = 0;						/* No per-window extra data.		  */
	wc.hIcon = NULL;
//	  wc.hInstance = hInstance; 			/* Application that owns the class.   */
	wc.hCursor = NULL;
	wc.hbrBackground = NULL;
	wc.lpszMenuName =  NULL;
	wc.lpszClassName = "WSockWClass";		/* Name used in call to CreateWindow. */

	if (!MyReportStatusToSCMgr(SERVICE_START_PENDING, NO_ERROR, 3000))
		return (FALSE);

	RegisterClass(&wc);

	if (!MyReportStatusToSCMgr(SERVICE_START_PENDING, NO_ERROR, 3000))
		return (FALSE);

	HWnd = CreateWindow(
		"WSockWClass",					/* See RegisterClass() call.		  */
		"RCC Time Server",				/* Text for window title bar.		  */
		WS_OVERLAPPEDWINDOW,			/* Window style.					  */
		CW_USEDEFAULT,					/* Default horizontal position. 	  */
		CW_USEDEFAULT,					/* Default vertical position.		  */
		CW_USEDEFAULT,					/* width.					  */
		CW_USEDEFAULT,					/* height.					  */
		NULL,							/* Overlapped windows have no parent. */
		NULL,							/* Use the window class menu.		  */
		NULL,							/* This instance owns this window.	  */
		NULL							/* Pointer not needed.				  */
	);

	/* If window could not be created, return "failure" */

	if (!HWnd) {
		LogEvent(NULL, EVENTLOG_INFORMATION_TYPE, 7712, NULL, "Could not create window.");
		return (FALSE);
	}

	if (!MyReportStatusToSCMgr(SERVICE_START_PENDING, NO_ERROR, 3000))
		return (FALSE);

	/* Make the window visible; update its client area; and return "success" */

//	  ShowWindow(hWnd, nCmdShow);  /* Show the window						 */
//	  UpdateWindow(hWnd);		   /* Sends WM_PAINT message				 */

	if (! AsyncListen(HWnd))
		return (FALSE);

	return (TRUE);				 /* Returns the value from PostQuitMessage */
}


/****************************************************************************\
*
*	 FUNCTION: MainWndProc(HWND, unsigned, WORD, LONG)
*
*	 PURPOSE:  Processes main window messages
*
* MESSAGES:
*  WM_CREATE   - call WSAStartUp() and display description message
*  WSA_ACCEPT  - User-defined message used with WSAAsyncSelect().  Sent
*				 by the Windows Sockets DLL when a socket connection is
*				 pending.
*
*  WM_DESTROY  - destroy window and call the WSACleanUp()
*
*\***************************************************************************/

LONG APIENTRY MainWndProc(
	HWND hWnd,				  /* window handle					 */
	UINT message,			  /* type of message				 */
	UINT wParam,			  /* additional information 		 */
	LONG lParam)			  /* additional information 		 */
{
	int status; 			/* Status Code */
	SOCKADDR_IN acc_sin;	/* Accept socket address - internet style */
	int acc_sin_len;		/* Accept socket address length */
	time_t theTime;
	char theTime1, theTime2, theTime3, theTime4;
	WORD event;
	SOCKET socket;

	switch (message) {
	case WM_CREATE:
	{
		WSADATA WSAData;
		char szTemp[80];

		if ((status = WSAStartup(MAKEWORD(1,1), &WSAData)) != 0) {
			sprintf(szTemp, "Failed to initialize sockets (%d)", status);
			LogEvent(NULL, EVENTLOG_ERROR_TYPE, 7708, NULL, szBuff);
			MainWndProc(hWnd, WM_DESTROY, 0, 0);
		}
	}
	break;	 /* WM_CREATE */

	case WSA_EVENT: /* Notification if a socket connection is pending. */
	{
		if (WSAGETSELECTERROR(lParam))
		{
			LogEvent(NULL, EVENTLOG_ERROR_TYPE, 7710, NULL, "Async error occurred.");
			MainWndProc(hWnd, WM_DESTROY, 0, 0);
			return 1;
		}
		event = WSAGETSELECTEVENT(lParam);
		if (event == FD_ACCEPT)
		{
			/*
			*	Accept the incoming connection.
			*/
			acc_sin_len = sizeof( acc_sin );
			socket = accept( sock,(struct sockaddr FAR *) &acc_sin, (int FAR *) &acc_sin_len );

			if (socket < 0) {
				sprintf(szBuff, "Failed to accept connection (%d)", WSAGetLastError());
				LogEvent(NULL, EVENTLOG_WARNING_TYPE, 7709, NULL, szBuff);
				break;
			}

			time(&theTime);

			theTime += 2208988800;	// Diff between time() [1-1-1970 UCT] and time server [1-1-1900 UCT]

			theTime4 = (char) theTime & 255;
			theTime = theTime >> 8;

			theTime3 = (char) theTime & 255;
			theTime = theTime >> 8;

			theTime2 = (char) theTime & 255;
			theTime = theTime >> 8;

			theTime1 = (char) theTime & 255;
			theTime = theTime >> 8;

			sprintf(szBuff, "%c%c%c%c", theTime1, theTime2, theTime3, theTime4);
			status = send(socket, szBuff, 4, NO_FLAGS_SET );
			if (!status)
			{
				sprintf(szBuff, "Failed to send time (%d)", WSAGetLastError());
				LogEvent(NULL, EVENTLOG_WARNING_TYPE, 7714, NULL, szBuff);
			}
			else
			{
				sprintf(szBuff, "Served time to %d.%d.%d.%d", (int) acc_sin.sin_addr.S_un.S_un_b.s_b1,
					(int) acc_sin.sin_addr.S_un.S_un_b.s_b2, 
					(int) acc_sin.sin_addr.S_un.S_un_b.s_b3,
					(int) acc_sin.sin_addr.S_un.S_un_b.s_b4);
				LogEvent(NULL, EVENTLOG_INFORMATION_TYPE, 7702, NULL, szBuff);
			}
			return 0;
		}
		else if (event == FD_CLOSE)
		{
			socket = wParam;
			closesocket(socket);
		}
	}
	break;	 /* WSA_ACCEPT */

	case WM_DESTROY:
	{
		LogEvent(NULL, EVENTLOG_WARNING_TYPE, 7713, NULL, "Other close request. Stopping.");
		WSACleanup();
		PostQuitMessage(0);
	}
	break;

	default:
		return (DefWindowProc(hWnd, message, wParam, lParam));

	}
	return (0);
}
