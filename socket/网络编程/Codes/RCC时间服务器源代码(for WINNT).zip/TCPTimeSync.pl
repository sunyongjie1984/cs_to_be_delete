############################################################
#
# This Perl script syncs the clock with a TCP timeserver.
#

TCPTimeSync(@ARGV);
#------------------------------------------------------------
sub TCPTimeSync
{
    select((select(STDOUT), $| = 1)[0]);
    if ($#ARGV+1 != 1) 	{TCPTimeSyncUsage();}

    $serverHost = shift;
    $serverHost =~ s/\\//g;

    $port = 37;
    $AF_INET = 2;
    $SOCK_STREAM = 1;
    $sockaddr = 'S n a4 x8';

    ($name, $aliases, $proto) = getprotobyname('tcp');
    ($name, $aliases, $adrtype, $length, @serveraddr) = gethostbyname($serverHost);

    if ($length == 0)	{die "unable to resolve name $serverHost\n\n";}

    ($a, $b, $c, $d) = unpack('C4', $serveraddr[0]);

    while (1)
    {
	socket(S, $AF_INET, $SOCK_STREAM, $proto) || die "socket failed: $!\n";
	$serverproc = pack($sockaddr, $AF_INET, $port, $serveraddr[0]);

	$i = 1; while (1)
	{
	    last if connect(S, $serverproc);
	    sleep(1);
	    if (++$i > 3)
	    {
	    	print(STDERR "  ... cannot connect to time server $serverHost\n");
	    	return;
	    }
	}
	recv(S, $buffer, 100, 0);
	shutdown (S, 2);
	close S;

	($a, $b, $c, $d) = unpack('C4', $buffer);
	$seconds = $d + 256*($c + 256*($b + 256*$a));
#	print("Seconds: $seconds" .  ;
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($seconds-2208988800);
	$mon = $mon+1;

	last unless ($hour eq 23 && $min eq 59 && $sec >= 55);

	print(STDERR "  ... too close to midnight. Sleeping for 5 seconds.\n");
	sleep(5)
    }

    print(`time $hour:$min:$sec.2`);
    print(`date $mon-$mday-$year`);
#    print("  ... time $hour:$min:$sec on day $mon-$mday-$year\n");
}
#------------------------------------------------------------
sub TCPTimeSyncUsage
{
    die("\nUsage:\n   $0 timeServerName\n\n");
}
#------------------------------------------------------------
1;
