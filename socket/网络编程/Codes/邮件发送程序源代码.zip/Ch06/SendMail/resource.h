//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SendMail.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SENDMAIL_DIALOG             102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_SERVER_DIALOG               129
#define IDC_SEND_MAIL                   1000
#define IDC_MESSAGE_BODY                1001
#define IDC_TO_ADDRESS                  1002
#define IDC_SUBJECT                     1003
#define IDC_SERVER                      1004
#define IDC_FROM_ADDRESS                1005
#define IDC_SMTP_INFO                   1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
