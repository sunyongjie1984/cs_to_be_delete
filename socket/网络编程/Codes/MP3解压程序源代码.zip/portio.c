#include "all.h"

int stop_now = 0;

#define IN_BUF_SIZE 1024*128

unsigned long input_file_length = 0;

FILE *input_file;

unsigned char input_area [IN_BUF_SIZE];
int input_index;
int input_len;

void read_input_area ()
{
	input_file_length += input_len;
	input_index = 0;

	input_len = fread(input_area, 1, IN_BUF_SIZE, input_file);
}

int OpenInputFile (char *fn)
{
	input_file = fopen(fn, "rb");

	if (input_file == NULL)
	{
		CommonExit(-1, "Error: Cannot open input file");
		return -1;
	}

	read_input_area();

	return 0;
}


int ReadInputFile()
{
	if (input_index == input_len)
	{
		read_input_area();
		
		if (input_len == 0)
			return -1;
	}

	return input_area [input_index ++];
}

void CloseInputFile()
{
	fclose(input_file);
}

unsigned long GetInputLength()
{
	return input_file_length + input_index;
}

void initio(char *filename)
{
    /* set defaults */
    current_program = -1;
    default_config = 1;
    mc_info.profile = Main_Profile;
    mc_info.sampling_rate_idx = Fs_44;

	if (binisopen)
	{
		CloseInputFile();
		binisopen = 0;
	}

	OpenInputFile(filename);
	binisopen = 1;
}

int	istrans = 0;
int framebits;

long getshort()
{
    int c1, c2;

	if (!stop_now)
	{
		if ((c1 = ReadInputFile()) < 0)
			goto err;
		if ((c2 = ReadInputFile()) < 0)
			goto err;
	}

	framebits += 16;
    return (c1<<8) | c2;

err:
	stop_now = 1;
	return 0;
}

void restarttio()
{
    cword = 0;
    nbits = 0;
}

void startblock()
{
    /* get adif header */

    if (adif_header_present)
	{
		if (get_adif_header() < 0)
			adif_header_present = 0;
		else
			adif_header_present = 1;
    }
    
    byte_align();	/* start of block is byte aligned */
}
