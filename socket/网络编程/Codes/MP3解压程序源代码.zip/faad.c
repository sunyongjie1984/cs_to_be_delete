#ifndef PLUGIN

#ifdef WIN32
	#include <windows.h>
#else
	#include <time.h>
#endif

#include <stdlib.h>
#include <sndfile.h>
#include "faad.h"

char *get_filename(char *pPath)
{
    char *pT;

    for (pT = pPath; *pPath; pPath++) {
        if ((pPath[0] == '\\' || pPath[0] == ':') && pPath[1] && (pPath[1] != '\\'))
            pT = pPath + 1;
    }

    return pT;
}

void combine_path(char *path, char *dir, char *file)
{
	/* Should be a bit more sophisticated
	   This code assumes that the path exists */

	/* Assume dir is allocated big enough */
	if (dir[strlen(dir)-1] != '\\')
		strcat(dir, "\\");
	strcat(dir, get_filename(file));
	strcpy(path, dir);
}

void usage(void)
{
	printf("Usage:\n");
	printf("faad.exe -options file ...\n");
	printf("Options:\n");
	printf(" -h    Shows this help screen.\n");
	printf(" -tX   Set output file type, X can be \".wav\",\".aif\" or \".au\".\n");
	printf(" -oX   Set output directory.\n");
	printf(" file  Multiple aac files can be given as well as wild cards.\n");
	printf("Example:\n");
	printf("       faad.exe -oc:\\aac\\ *.aac\n");
	return;
}


int main(int argc, char *argv[])
{
	int i;
	char *argp;
	char *FileNames[200];
	int FileCount = 0;
	char out_dir[255];
	int out_dir_set = 0;
	faadAACInfo fInfo;
	short sample_buffer[2048];
	SNDFILE *sndfile;
	SF_INFO sf_info;
	long begin, end;
	char type[] = ".wav";

	printf("FAAD cl (Freeware AAC Decoder)\n");
	printf("FAAD homepage: %s\n", "http://www.slimline.net/aac/");

	/* Process the command line */
	if (argc == 1) {
		usage();
		return 1;
	}

	for (i = 1; i < argc; i++)
	{
		if ((argv[i][0] != '-')&&(argv[i][0] != '/')) {
			if (strchr("-/", argv[i][0]))
				argp = &argv[i][1];
			else  argp = argv[i];

			if (!strchr(argp, '*') && !strchr(argp, '?'))
			{
				FileNames[FileCount] = malloc((strlen(argv[i])+10)*sizeof(char));
				strcpy(FileNames[FileCount], argv[i]);
				FileCount++;
			} else {
#ifdef WIN32
				HANDLE hFindFile;
				WIN32_FIND_DATA fd;

				char path[255], *p;

				if (NULL == (p = strrchr(argp, '\\')))
					p = strrchr(argp, '/');
				if (p)
				{
					char ch = *p;

					*p = 0;
					lstrcat(strcpy(path, argp), "\\");
					*p = ch;
				}
				else
					*path = 0;

				if (INVALID_HANDLE_VALUE != (hFindFile = FindFirstFile(argp, &fd)))
				{
					do
					{
						FileNames[FileCount] = malloc(strlen(fd.cFileName)
							+ strlen(path) + 2);
						strcat(strcpy(FileNames[FileCount], path), fd.cFileName);
						FileCount++;
					} while (FindNextFile(hFindFile, &fd));
					FindClose(hFindFile);
				}
#else
				printf("Wildcards not yet supported on systems other than WIN32\n");
#endif
			}
		} else {
			switch(argv[i][1]) {
			case 'o':
			case 'O':
				out_dir_set = 1;
				strcpy(out_dir, &argv[i][2]);
				break;
			case 't':
			case 'T':
				strcpy(type, &argv[i][2]);
				break;
			case 'h':
			case 'H':
				usage();
				return 1;
			}
		}
	}

	if (FileCount == 0) {
		usage();
		return 1;
	}

	sf_info.samplerate = 44100;
	sf_info.channels = 2;
	sf_info.pcmbitwidth = 16;
	if (strcmp(type, ".wav")==0)
		sf_info.format = SF_FORMAT_WAV | SF_FORMAT_PCM;
	else if (strcmp(type, ".aif")==0)
		sf_info.format = SF_FORMAT_AIFF | SF_FORMAT_PCM;
	else if (strcmp(type, ".au")==0)
		sf_info.format = SF_FORMAT_AU | SF_FORMAT_PCM;

	for (i = 0; i < FileCount; i++) {
		char audio_fn[255];
		char *fnp;
		int bits;

		#ifdef WIN32
			begin = GetTickCount();
		#else
			begin = clock();
		#endif

		aac_decode_init(&fInfo, FileNames[i]);

		printf("Busy decoding %s\r", FileNames[i]);

		if (out_dir_set)
			combine_path(audio_fn, out_dir, FileNames[i]);
		else
			strcpy(audio_fn, FileNames[i]);
		fnp = (char *)strrchr(audio_fn,'.');

		if (fnp)
		  fnp[0] = '\0';

		strcat(audio_fn, type);
		sndfile = sf_open_write(audio_fn, &sf_info);
		if (sndfile==NULL) {
			printf("Error while decoding %s.\n", FileNames[i]);
			continue;
		}

		do
		{
			bits = aac_decode_frame(sample_buffer);
			
			if (bits > 0)
			{
				sf_write_short(sndfile, sample_buffer, 2048);
			}
		} while (bits > 0);

		aac_decode_free();
		sf_close(sndfile);

		#ifdef WIN32
			end = GetTickCount();
		#else
			end = clock();
		#endif
		printf("Decoding %s took: %d sec.\n", FileNames[i], (end-begin)/1000);
	}
return 0;
}

#endif // PLUGIN
