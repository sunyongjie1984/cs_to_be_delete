#ifndef _AACDEC_H
#define _AACDEC_H

typedef struct {
	int channels;
	int sampling_rate;
	int bit_rate;
	int length;
} faadAACInfo;

void aac_decode_init(faadAACInfo *fInfo, char *fn);
void aac_decode_free(void);
int  aac_decode_frame(short *sample_buffer);

void CommonExit(int errorcode, char *message);
void CommonWarning(char *message);

#endif
