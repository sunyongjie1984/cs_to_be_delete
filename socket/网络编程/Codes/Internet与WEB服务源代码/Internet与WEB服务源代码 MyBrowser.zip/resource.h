//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyBrowser.rc
//
#define IDD_ABOUTBOX                    100
#define IDX_BROWSER                     101
#define IDR_MAINFRAME                   128
#define IDR_MYBROWTYPE                  129
#define IDD_DIALOG1                     134
#define IDC_EDIT1                       1004
#define ID_BACK                         32771
#define IDC_FORWARD                     32772
#define ID_RELOAD                       32773
#define ID_STOP                         32775
#define ID_URL                          32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
