//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Mail.rc
//
#define IDD_MAIL_DIALOG                 102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_SEND                        1000
#define IDC_RETR                        1001
#define IDC_SMTP                        1002
#define IDC_POP3                        1003
#define IDC_FROM                        1004
#define IDC_TO                          1005
#define IDC_USER                        1006
#define IDC_PASSWORD                    1007
#define IDC_BODY                        1008
#define IDC_SUBJECT                     1009
#define IDC_STATUS                      1010
#define IDC_MSGNO                       1011
#define IDC_DELE                        1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
