// MailDlg.cpp : Implementierungsdatei
//
// A sample for the new CSMTP, CPOP3 and CMailMessage class
// just a few functions !
// Copyright (c) 1998 Michael Krebs
// The system generated comments are in German - you won't mind, will ya ?
//

#include "stdafx.h"
#include "MailMessage.h"
#include "POP3.h"
#include "SMTP.h"
#include "Mail.h"
#include "MailDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMailDlg Dialogfeld

CMailDlg::CMailDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMailDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMailDlg)
	m_Body = _T("");
	m_From = _T("");
	m_Password = _T("");
	m_POP3 = _T("");
	m_SMTP = _T("");
	m_To = _T("");
	m_User = _T("");
	m_Subject = _T("");
	m_MN = 0;
	//}}AFX_DATA_INIT
	// Beachten Sie, dass LoadIcon unter Win32 keinen nachfolgenden DestroyIcon-Aufruf ben�tigt
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMailDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMailDlg)
	DDX_Text(pDX, IDC_BODY, m_Body);
	DDX_Text(pDX, IDC_FROM, m_From);
	DDX_Text(pDX, IDC_PASSWORD, m_Password);
	DDX_Text(pDX, IDC_POP3, m_POP3);
	DDX_Text(pDX, IDC_SMTP, m_SMTP);
	DDX_Text(pDX, IDC_TO, m_To);
	DDX_Text(pDX, IDC_USER, m_User);
	DDX_Text(pDX, IDC_SUBJECT, m_Subject);
	DDX_Text(pDX, IDC_MSGNO, m_MN);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMailDlg, CDialog)
	//{{AFX_MSG_MAP(CMailDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SEND, OnSend)
	ON_BN_CLICKED(IDC_STATUS, OnStatus)
	ON_BN_CLICKED(IDC_RETR, OnRetr)
	ON_BN_CLICKED(IDC_DELE, OnDele)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMailDlg Nachrichten-Handler

BOOL CMailDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Symbol f�r dieses Dialogfeld festlegen. Wird automatisch erledigt
	//  wenn das Hauptfenster der Anwendung kein Dialogfeld ist
	SetIcon(m_hIcon, TRUE);			// Gro�es Symbol verwenden
	SetIcon(m_hIcon, FALSE);		// Kleines Symbol verwenden
	
	// ZU ERLEDIGEN: Hier zus�tzliche Initialisierung einf�gen
	
	return TRUE;  // Geben Sie TRUE zur�ck, au�er ein Steuerelement soll den Fokus erhalten
}

// Wollen Sie Ihrem Dialogfeld eine Schaltfl�che "Minimieren" hinzuf�gen, ben�tigen Sie 
//  den nachstehenden Code, um das Symbol zu zeichnen. F�r MFC-Anwendungen, die das 
//  Dokument/Ansicht-Modell verwenden, wird dies automatisch f�r Sie erledigt.

void CMailDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Ger�tekontext f�r Zeichnen

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Symbol in Client-Rechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// Die Systemaufrufe fragen den Cursorform ab, die angezeigt werden soll, w�hrend der Benutzer
//  das zum Symbol verkleinerte Fenster mit der Maus zieht.
HCURSOR CMailDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMailDlg::OnSend() 
{
	UpdateData( TRUE );
	CSMTP smtp( m_SMTP );
	CMailMessage msg;
	msg.m_sFrom = m_From;
	msg.AddMultipleRecipients( m_To );
	msg.m_sSubject = m_Subject;
	msg.m_sBody = m_Body;
	if( !smtp.Connect() )
	{
		AfxMessageBox( smtp.GetLastError() );
		return;
	}
	if( !smtp.SendMessage( &msg ) )
	{
		AfxMessageBox( smtp.GetLastError() );
		return;
	}
	if( !smtp.Disconnect() )
	{
		AfxMessageBox( smtp.GetLastError() );
		return;
	}
	AfxMessageBox( _T( "Message Sent Successfully") );
	
}

void CMailDlg::OnStatus() 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	UpdateData(TRUE);
	CPOP3 pop3( m_POP3 );
	pop3.SetUserProperties(m_User,m_Password);
	if (!pop3.Connect())
	{
		AfxMessageBox( pop3.GetLastError() );
		return;
	}
	int num=pop3.GetNumMessages();
	if (num<0)
	{
		AfxMessageBox( pop3.GetLastError() );
		return;
	}
	CString temp;
	temp.Format("Anzahl Nachrichten: %d",num);
	AfxMessageBox(temp);

	if( !pop3.Disconnect() )
	{
		AfxMessageBox( pop3.GetLastError() );
		return;
	}
	AfxMessageBox( _T( "Successfully disconnected" ) );
	
	
}

void CMailDlg::OnRetr() 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	UpdateData( TRUE );
	CPOP3 pop3( m_POP3 );
	pop3.SetUserProperties(m_User,m_Password);
	if (!pop3.Connect())
	{
		AfxMessageBox( pop3.GetLastError() );
		return;
	}
	CMailMessage msg;
	if (!pop3.GetMessage(m_MN,&msg))
	{
		AfxMessageBox( pop3.GetLastError() );
		return;
	}

	m_Body=msg.m_sBody;
	m_Subject=msg.m_sSubject;
	m_From=msg.m_sFrom;
	m_To="";
	for (int a=0; a<msg.GetNumRecipients(); a++)
	{
		CString sEmail;
		CString sFriendly;
		msg.GetRecipient(sEmail,sFriendly,a);
		m_To+=sEmail;
		m_To+=" ";
	}
	m_To.TrimRight();

	if( !pop3.Disconnect() )
	{
		AfxMessageBox( pop3.GetLastError() );
		return;
	}
	AfxMessageBox( _T( "Successfully disconnected" ) );

	UpdateData(FALSE);
	
}

void CMailDlg::OnDele() 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	UpdateData( TRUE );
	CPOP3 pop3( m_POP3 );
	pop3.SetUserProperties(m_User,m_Password);
	if (!pop3.Connect())
	{
		AfxMessageBox( pop3.GetLastError() );
		return;
	}
	if (!pop3.DeleteMessage(m_MN))
	{
		AfxMessageBox( pop3.GetLastError() );
		return;
	}

	if( !pop3.Disconnect() )
	{
		AfxMessageBox( pop3.GetLastError() );
		return;
	}
	AfxMessageBox( _T( "Successfully disconnected" ) );

}
