// RasDemoDlg.cpp : implementation file
// Copyright 1998 Qing Zhang
// 11/3/98 Create

#include "stdafx.h"
#include "RasDemo.h"
#include "RasDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRasDemoDlg dialog

CRasDemoDlg::CRasDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRasDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRasDemoDlg)
	m_strPasswd = _T("");
	m_strModemName = _T("");
	m_strStatus = _T("");
	m_strPhone = _T("");
	m_strUser = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CRasDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRasDemoDlg)
	DDX_Control(pDX, IDC_MODEM_COMBO, m_ctrlModem_Combo);
	DDX_Text(pDX, IDC_PASSWD_EDIT, m_strPasswd);
	DDX_CBString(pDX, IDC_MODEM_COMBO, m_strModemName);
	DDX_Text(pDX, IDC_CONNECT_STATIC, m_strStatus);
	DDX_Text(pDX, IDC_PHONE_EDIT, m_strPhone);
	DDX_Text(pDX, IDC_USE_EDIT, m_strUser);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRasDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CRasDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CONNECT_BTN, OnConnectBtn)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_DISCONN_BTN, OnDisconnBtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRasDemoDlg message handlers

BOOL CRasDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_pRas = new CRasClient;
	UpdateData(FALSE);
	if(!FillModemCombo())
		GetDlgItem(IDC_CONNECT_BTN)->EnableWindow(FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRasDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CRasDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CRasDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CRasDemoDlg::OnConnectBtn() 
{
	// TODO: Add your control notification handler code here
	m_bUserCancel = FALSE;
	GetDlgItem(IDC_CONNECT_BTN)->EnableWindow(FALSE);
	CString strEntry = "My Network";
	HRASCONN hrasConn;
	if(CreateDialUpEntry())
	{
		if(!m_pRas->GetRasConnection(strEntry, hrasConn))
		{
			if(!DialUpNetwork())
			{
				GetDlgItem(IDC_CONNECT_BTN)->EnableWindow(TRUE);
			}
		}
	}
}


BOOL CRasDemoDlg::CreateDialUpEntry()
{
	UpdateData(TRUE);
	CString strEntry = "My Network";
	if(m_pRas->CreateNewEntry(strEntry, "modem",
		m_strModemName, RASNP_NetBEUI, RASFP_Ppp, m_strPhone) 
		!= ERROR_ALREADY_EXISTS)
	{
		DWORD dwfOptions = RASEO_SwCompression | 
			RASEO_RequireEncryptedPw | RASEO_RequireMsEncryptedPw |
			RASEO_UseLogonCredentials;
		if(m_pRas->SetEntryOption(strEntry, dwfOptions, TRUE) != 0) 
		{
			m_strStatus = "Fail to Set My Network Entry!";
			UpdateData(FALSE);
			return FALSE;
		}
	}
	return TRUE;
}


BOOL CRasDemoDlg::DialUpNetwork()
{
	m_dwError = 0;
	CString strEntry = "My Network";
	DWORD dwError = m_pRas->RasDialAsynCallback1(strEntry, 
		rasCallback1, m_strPhone, m_strUser, m_strPasswd);

	BOOL bLoop = TRUE;
	BOOL bConnected = FALSE;
	while(bLoop)
	{
		CtrlYield();
		if(m_bUserCancel)
			return FALSE;

		bLoop = !(m_pRas->GetRasStatusString(m_strStatus, bConnected));
		GetDlgItem(IDC_CONNECT_STATIC)->SetWindowText(m_strStatus);
		::Sleep(100);	 

		if(m_dwError != 0)
		{
			m_pRas->GetRasErrorStringByErrorCode(m_dwError, m_dwExtendError,
				m_strStatus);
			GetDlgItem(IDC_CONNECT_STATIC)->SetWindowText(m_strStatus);
			AfxMessageBox("Error: " + m_strStatus);
			m_pRas->HangUpConnection(strEntry);	
			return FALSE; 
		} 
	}

	if(bConnected) 
		return TRUE;
	else
		return FALSE;
}

BOOL CRasDemoDlg::FillModemCombo()
{
	int iModemCount = m_pRas->GetModemCount();
	if(iModemCount == 0)
	{
		m_strStatus = "There is no modem installed in your computer!";
		return FALSE;
	}
	else if(iModemCount < 0)
	{
		m_strStatus = "Fail to get modem count!";
		return FALSE;
	}
	CString* strName = new CString[iModemCount];
	BOOL bResult = m_pRas->GetModemName(strName);
	if(bResult)
	{
		for(int i = 0; i < iModemCount; i++)
			m_ctrlModem_Combo.AddString(strName[i]);
		m_ctrlModem_Combo.SetCurSel(0);
		UpdateData(TRUE);
	}
	else
		m_strStatus = "Fail to get Modem name!";
	delete []strName;
	return bResult; 
}

void CRasDemoDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	delete m_pRas;
}


void CRasDemoDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	m_bUserCancel = TRUE;
	CString strEntry = "My Network";
	m_pRas->HangUpConnection(strEntry);

	CDialog::OnCancel();
}


void CALLBACK rasCallback1(HRASCONN hrasconn, UINT unMsg, RASCONNSTATE rascs, 
						 DWORD dwError, DWORD dwExtendedError)
{
	if(m_dwError == 0 && dwError != 0) 
	{
		m_dwError = dwError;
		m_dwExtendError = dwExtendedError;
	}
}

void CRasDemoDlg::OnDisconnBtn() 
{
	// TODO: Add your control notification handler code here
	if(AfxMessageBox("Are you sure that you want to disconnect?", 
		MB_YESNO) == IDYES)
	{
		m_bUserCancel = TRUE;
		CString strEntry = "My Network";
		m_pRas->HangUpConnection(strEntry);
		GetDlgItem(IDC_CONNECT_STATIC)->SetWindowText("Connection "
			"is disconnected!");
		GetDlgItem(IDC_CONNECT_BTN)->EnableWindow(TRUE);
	}
}

void CRasDemoDlg::CtrlYield()
{
	MSG Msg;
	if(::PeekMessage (&Msg, NULL, 0, 0, PM_REMOVE))
	{
		::TranslateMessage(&Msg);
		::DispatchMessage(&Msg);
	}
}
