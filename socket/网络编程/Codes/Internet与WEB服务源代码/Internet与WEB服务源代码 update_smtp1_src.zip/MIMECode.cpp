// MIMECode.cpp: implementation of the CMIMECode class.
// Author: Wes Clyburn (clyburnw@enmu.edu)
//////////////////////////////////////////////////////////////////////

#include "../stdafx.h"
#include "MIMECode.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMIMECode::CMIMECode()
{

}

CMIMECode::~CMIMECode()
{

}
