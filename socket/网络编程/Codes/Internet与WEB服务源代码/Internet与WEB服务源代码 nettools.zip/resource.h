//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by nettools.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_NETTOOLS_FORM               101
#define IDD_DIALOGBAR                   103
#define IDR_MAINFRAME                   128
#define IDR_NETTOOTYPE                  129
#define IDD_PING_DIALOG                 130
#define IDD_NETSTAT_DIALOG              131
#define IDD_NBSTAT_DIALOG               132
#define LISTBOX_WINDOW                  999
#define IDC_LIST_UTILITY_OUTPUT         1000
#define IDC_PING_HOSTNAME               1001
#define IDC_PING_OPT_T                  1002
#define IDC_PING_OPT_A                  1003
#define IDC_PING_OPT_F                  1004
#define IDC_PING_OPT_L_VAL              1008
#define IDC_PING_OPT_I_VAL              1009
#define IDC_PING_OPT_R_VAL              1011
#define IDC_PING_OPT_S_VAL              1012
#define IDC_PING_OPT_W_VAL              1015
#define IDC_PING_OPT_N_VAL              1018
#define IDC_NETSTAT_OPT_CONNS           1030
#define IDC_NETSTAT_OPT_TCPSTATS        1034
#define IDC_NETSTAT_OPT_UDPSTATS        1035
#define IDC_NETSTAT_OPT_ICMPSTATS       1036
#define IDC_NETSTAT_OPT_ROUTES          1037
#define IDC_NETSTAT_OPT_IPSTATS         1039
#define IDC_NBSTAT_HOSTNAME             1040
#define IDC_NBSTAT_HOSTADDR             1041
#define IDC_NBSTAT_OPT_C                1042
#define IDC_NBSTAT_OPT_N                1043
#define IDC_NBSTAT_OPT_UR               1044
#define IDC_NBSTAT_OPT_LR               1045
#define IDC_NETSTAT_OPT_US              1046
#define IDC_NBSTAT_OPT_LS               1047
#define IDC_PING_OPT_TOS_NONE           1059
#define IDC_PING_OPT_TOS_LOW_DELAY      1060
#define IDC_PING_OPT_TOS_HIGH_THRU      1061
#define IDC_PING_OPT_TOS_HIGH_RELIAB    1062
#define IDC_PING_OPT_RRLOOSE            1063
#define IDC_PING_OPT_RRSTRICT           1064
#define IDC_PING_OPT_RROUTE_LRSR        1068
#define IDC_PING_OPT_TRACERT            1069
#define IDC_NETSTAT_OPT_IFSTATS         1070
#define IDC_NETSTAT_OPT_ALL             1071
#define IDC_NETSTAT_OPT_RESOLVE         1072
#define ID_COMMANDS_PING                32771
#define ID_COMMANDS_NETSTAT             32773
#define ID_COMMANDS_NBSTAT              32775
#define ID_COMMANDS_STOPPING            32779
#define ID_COMMANDS                     32782
#define ID_COMMANDS_STOPSTAT            32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1073
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
