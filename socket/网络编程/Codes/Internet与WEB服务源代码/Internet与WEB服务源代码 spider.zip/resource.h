//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Spider.rc
//
#define IDD_ABOUTBOX                    100
#define IDC_LISTVIEW                    101
#define IDC_DIRNAME                     112
#define IDR_MAINFRAME                   128
#define IDR_SPIDERTYPE                  129
#define IDD_GETURL                      130
#define IDD_CHECKURL                    131
#define IDD_MESSAGE                     132
#define IDC_URLCOMBO                    1000
#define IDC_EDIT1                       1004
#define IDC_CHECK1                      1040
#define IDC_CHECKROOT                   1040
#define ID_WINDOWS_CLOSEALL             32771
#define ID_TOOLS_GETURL                 32772
#define ID_TOOLS_LIST                   32773
#define ID_TOOLS_SEPARATE               32775
#define ID_TOOLS_SHOWURLS               32777
#define ID_TOOLS_STRIPHTML              32778
#define ID_TOOLS_STRIPTEXT              32779
#define ID_TOOLS_EMAILADDRESS           32780
#define ID_TOOL_BROKENURLS              32783
#define ID_TOOLS_GETHEADER              32784
#define ID_TOOLS_KILLTHREAD             32786
#define ID_TOOLS_NOT_FOUND              32791
#define ID_TOOLS_STOP                   32792

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32793
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
