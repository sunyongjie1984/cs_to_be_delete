#ifndef G_FTPDOWNLOAD_FILES_H
#define G_FTPDOWNLOAD_FILES_H

#include "FTPDownload.h"

//CInternetSession can throw an exception catch it like so: catch (CInternetException* pEx)

class FTPDownLoadFiles
{
protected:
CInternetSession Cis;//All argument defaults are OK.
CFtpConnection* m_Ftp_Conn;//The ftp_connection

FTPDownload * pFtpI;//Pointer to FTPDownload object in other thread that also holds dialog
CFile cfo;//CFileObject used to write file

void ReadFile(CString & source, CString & dest);
BOOL ftp_file_exists(CString & source);
void file_not_found(CString & source);

void UpdateStatus(void);
char status_str[1024];

unsigned int file_size;
CString temp_ftp_name;

public:
FTPDownLoadFiles(FTPDownload * t_pFtpI);//Constructor
};

#endif
