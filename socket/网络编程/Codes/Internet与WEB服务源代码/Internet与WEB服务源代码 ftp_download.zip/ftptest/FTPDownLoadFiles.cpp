#include "stdafx.h"
#include "FTPDownLoadFiles.h"

#define DL_BUFFER_SIZE 4096

//**********************CONSTRUCTOR*********************
FTPDownLoadFiles::FTPDownLoadFiles(FTPDownload * t_pFtpI)
{//CinternetSession is contained and is created with defaults
pFtpI = t_pFtpI;
m_Ftp_Conn = 0;
//I have found that by reducing the timeout connection, the internet connection speed is faster.
if (pFtpI->connection_timeout)//Only if not 0 do we bother changing the timeout value
Cis.SetOption(INTERNET_OPTION_CONNECT_TIMEOUT, pFtpI->connection_timeout);//I like 3000

int csa_size = pFtpI->Csa->GetSize();//Get the CStringArray size
for (int i = 3;i<csa_size;i+=2)//start at index 3 past logon info
	ReadFile(pFtpI->Csa->GetAt(i), pFtpI->Csa->GetAt(i+1));//Download file name, disk file name

Cis.Close();//Close this session
return;
}

//m_pConn must be set B4 calling this function
//*********************READFILE*****************************
void FTPDownLoadFiles::ReadFile(CString &source, CString &dest)
{
if (pFtpI->abort_flag) return;//Has cancel been pressed ? If yes then split!!!

pFtpI->cpd.SetHeader(source);
//Unfortunately we have to reopen the ftp connection for each file.
wsprintf(status_str, "Connecting to %s", pFtpI->Csa->GetAt(0)); UpdateStatus();
if (pFtpI->abort_flag) return;//Make sure operation hasn't been cancelled yet b4 calling inet function
m_Ftp_Conn = Cis.GetFtpConnection(pFtpI->Csa->GetAt(0),
										pFtpI->Csa->GetAt(1), pFtpI->Csa->GetAt(2));//Connect to FTP Server

strcpy(status_str, source); UpdateStatus();//Show source file name

if (ftp_file_exists(source)==FALSE) return;//If file ain't there we can't download it so split!!
pFtpI->cpd.SetUpper(file_size);

if (cfo.Open(dest, CFile::modeCreate | CFile::modeWrite, NULL)==FALSE)//Now open our disk file
	{wsprintf(status_str, "Unable to create file %s", dest); AfxMessageBox(status_str); throw status_str; }

pFtpI->cpd.SetHeader(temp_ftp_name);
wsprintf(status_str, "Opening %s", temp_ftp_name); UpdateStatus();
if (pFtpI->abort_flag) return;//Make sure operation hasn't been cancelled yet b4 calling inet function
CInternetFile*  ifp = m_Ftp_Conn->OpenFile(temp_ftp_name);

char buffer[DL_BUFFER_SIZE];
unsigned int amount_read = DL_BUFFER_SIZE;
unsigned int total_read = 0;
while (amount_read == DL_BUFFER_SIZE && pFtpI->abort_flag == FALSE)
	{
	amount_read = ifp->Read(buffer, DL_BUFFER_SIZE);
	cfo.Write(buffer, amount_read);//Write this to our data file
	total_read += amount_read;
	wsprintf(status_str, "%d of %d  bytes read", total_read, file_size); 	UpdateStatus();
	pFtpI->cpd.SetPos(total_read);
	}

cfo.Close();//Close the file
//Unforunately we have to close the FTP session in order to be able to change to root folder.
//There is no way around it. We have reopen the ftp connection for each file. Oh well.
wsprintf(status_str, "Closing connection to %s", pFtpI->Csa->GetAt(0)); UpdateStatus();
m_Ftp_Conn->Close();
delete m_Ftp_Conn;//Delete the ftp connection just to be safe
return;
}

//*********************************UPDATESTATUS***********************************
void FTPDownLoadFiles::UpdateStatus(void)
{
pFtpI->cpd.SetStatus(status_str);
return;
}

//This function performs three important functions.
//I have learned that calling OpenFile() on an FTP server when the files isn't there makes my
//program go BOOM so we have to check to see if the file is there first. I have also learned
//that in checking for the files existence we can also get the file size.

//1. It checks to see wether file exists on ftp server. If it doesn't it returns FALSE.
//2. Using CFtpFileFind it gets the FIRST file name matching input string. This means that if
	//a string like amex*.txt is passed the FIRST and only the first file matching that string will
	//be downloaded. This suits my purposes (for now) because I have to download daily data from a folder
	//that is updated daily with the latest data file. This file name changes according to the date with
	//the first four leters being the same. Using this logic you can still pass a specific file name
	//or use wilcards, but just remember that if you use wildcards only the first file matching will
	//be downloaded.

//3. Gets file size. we cannot however depend on this being correct. I read something about headers
	//on the FTP site having to be updated, and also that CERN proxys can't get the file info or something
	//Since this is the case and if it is less than DL_BUFFER_SIZE I just make it 0. If it is 0
	//the progess dialog knows to ignore the percent stuff.

//This function sets temp_ftp_name. Use this name for the actual download.
//This function also sets file_size.
//*****************************FTP_FILE_EXISTS******************************
BOOL FTPDownLoadFiles::ftp_file_exists(CString &source)
{
wsprintf(status_str, "Getting File Information %s", source); UpdateStatus();

if (pFtpI->abort_flag) return FALSE;
CFtpFileFind finder(m_Ftp_Conn);

//Lets check for the files existince first using a standard FindFile call
if (pFtpI->abort_flag) return FALSE;
if (finder.FindFile(source) == FALSE)
	{ 	file_not_found(source);	return FALSE;		}	

//We have to use a FindNextFile to get info on first file, why ?. Becuase FindNextFile doesn't get the
//next file on its first invocation. It gets the first file! Makes sense doesn't it? Pure Genius...
if (pFtpI->abort_flag) return FALSE;
finder.FindNextFile();
temp_ftp_name = "";//Empty the CString
temp_ftp_name = finder.GetFilePath();//Get the actual file name in case wildcards were used
if (temp_ftp_name.IsEmpty()) temp_ftp_name = source;//Make sure we got something. If not use source
file_size = 0;
file_size = finder.GetLength();
if (file_size < DL_BUFFER_SIZE) file_size = 0;//This tells the progress dialog to ignore the progress.

return TRUE;//If here file definitely exists
}

//***************************FILE_NOT_FOUND*************************
void FTPDownLoadFiles::file_not_found(CString & source)
{
wsprintf(status_str, "File NOT found on Server: %s", source);
UpdateStatus();
AfxMessageBox(status_str);//Put up message box to let user Know!!
return;
}
