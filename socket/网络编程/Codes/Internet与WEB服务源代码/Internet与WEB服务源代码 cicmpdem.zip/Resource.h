//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EWDPing.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_EWDPING_DIALOG              102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_PingOptions                 130
#define IDI_CommLink1                   133
#define IDI_BlueArrow                   135
#define IDI_Blank                       136
#define IDI_CommLink2                   148
#define IDI_CommLink3                   149
#define IDI_CommLink4                   150
#define IDC_DefaultHost                 1000
#define IDC_BufferSize                  1001
#define IDC_PingButton                  1002
#define IDC_TraceButton                 1003
#define IDC_OptionsButton               1004
#define IDC_PingTimeout                 1005
#define IDC_MaxHops                     1006
#define IDC_CommLink                    1007
#define IDC_TraceList                   1008
#define IDC_ClearButton                 1009
#define IDC_LocalHost                   1010
#define IDC_NameServer                  1012
#define IDC_Stop                        1013
#define IDC_SENDTO                      1017
#define IDQUIT                          1045
#define IDC_DEST                        1047
#define IDC_OPEN                        1050
#define IDC_LOG_DLGWIN                  1067
#define IDC_DisplayTrace                1067

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
