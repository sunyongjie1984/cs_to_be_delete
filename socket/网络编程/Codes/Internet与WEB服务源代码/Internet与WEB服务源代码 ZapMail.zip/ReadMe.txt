ZapMail is a sample project demonstrating SMTP and e-mail file attachments using MIME.

You should have extracted this ZIP file with folder names intact.

The sub-folder "\SMTP" contains gallery-ready component files that can be inserted into your project. You may want to copy that entire folder to
\Program Files\DevStudio\SharedIDE\Gallery\ .

You may contact me at clyburnw@enmu.edu .