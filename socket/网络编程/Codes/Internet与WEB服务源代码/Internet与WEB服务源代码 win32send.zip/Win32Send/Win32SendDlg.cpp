// Win32SendDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Win32Send.h"
#include "Win32SendDlg.h"

#ifndef _DEBUG
  #define N_PLAT_MSW
  #define N_ARCH_32
  #include "novell/nwcalls.h"
  #include "novell/nwnet.h"
#endif	

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWin32SendDlg dialog

CWin32SendDlg::CWin32SendDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWin32SendDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWin32SendDlg)
	m_sMessage = _T("");
	m_sServer = _T("");
	m_sTo = _T("");
	m_nNumber = 1;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CWin32SendDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWin32SendDlg)
	DDX_Control(pDX, IDC_MESSAGE, m_Message);
	DDX_Control(pDX, IDC_NUMBER, m_Number);
	DDX_Control(pDX, IDC_SERVER, m_Server);
	DDX_Control(pDX, IDC_SPIN_NUMBER, m_SpinNumber);
	DDX_Text(pDX, IDC_MESSAGE, m_sMessage);
	DDV_MaxChars(pDX, m_sMessage, 255);
	DDX_CBString(pDX, IDC_SERVER, m_sServer);
	DDV_MaxChars(pDX, m_sServer, 50);
	DDX_CBString(pDX, IDC_TO, m_sTo);
	DDV_MaxChars(pDX, m_sTo, 50);
	DDX_Text(pDX, IDC_NUMBER, m_nNumber);
	DDV_MinMaxInt(pDX, m_nNumber, 1, 1000);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CWin32SendDlg, CDialog)
	//{{AFX_MSG_MAP(CWin32SendDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDB_SEND, OnSend)
	ON_CBN_SELCHANGE(IDC_SERVER, OnSelchangeServer)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWin32SendDlg message handlers

BOOL CWin32SendDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
  m_To.SubclassDlgItem(IDC_TO, this);

  if(!NovellGetServers())
    AfxMessageBox("Error - Novell Servers");

  m_SpinNumber.SetRange(1, 1000); //SetBuddy(&m_Number);//m_Number.GetWindow(GW_OWNER));

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CWin32SendDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CWin32SendDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CWin32SendDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

/////////////////////////////////////////////////////////////////////////////

bool CWin32SendDlg::NovellSendMessage(char* server, char* user, char* message)
{
#ifndef _DEBUG
	NWCCODE	ccode;
	NWCONN_HANDLE	conn;
	NWNUMBER	maxConns;
	NWOBJ_ID	userID, ID;
	NWFLAGS	flag;

	ccode = NWCallsInit (NULL,NULL);
	if (ccode)	return false;

	ccode = NWGetConnectionHandle ((unsigned char*)server, 0, &conn, NULL);
	if (ccode)
	{
		AfxMessageBox("Error - NWGetConnectionHandle");
		return false;
	}

	ccode = NWGetObjectID (conn, user, OT_USER, &userID);
	if (ccode)
	{
		AfxMessageBox("Error - NWGetObjectID");
		return false;
	}

	ccode = NWGetFileServerInformation (conn,NULL,NULL,NULL,NULL,&maxConns,NULL,NULL,NULL,NULL,NULL);

	if (ccode)
	{
		AfxMessageBox("Error - NWGetFileServerInformation");
		return false;
	}

	for (__int16 i = 0; i < maxConns; i++)
	{
		NWGetConnectionInformation (conn, i, NULL, NULL, &ID, NULL);
		if (ID == userID)	break;
	}

	if (ID == userID)
	{
		ccode = NWSendBroadcastMessage (conn, message, 1, (NWCONN_NUM_WORD NWFAR *) &i, &flag);
		if (ccode)
		{
  		AfxMessageBox("Error - NWSendBroadcastMessage");
			return false;
		}
		if (flag)
		{
  		AfxMessageBox("Error - Server return code");
			return false;
		}
	}
	else
	{
		AfxMessageBox("Error - User not found");
		return false;
	}
#endif	
  return true;
}

/////////////////////////////////////////////////////////////////////////////

bool CWin32SendDlg::NovellGetServers()
{
#ifndef _DEBUG
	NWCONN_HANDLE   *connList;
	NWNUMBER        maxConns, numConns;
	NWCCODE         ccode;
	char  server[50];
	int   i;

	ccode = NWCallsInit (NULL, NULL);
	if (ccode) return false;

	NWGetMaximumConnections (&maxConns);
	connList = (unsigned int *)malloc(maxConns * sizeof (NWCONN_HANDLE));

	ccode = NWGetConnectionList (0, connList, maxConns, &numConns);
	if (ccode)
	{
		free (connList);
		return false;
	}

//	printf ("\nYou are connected to %d servers\n", numConns);

	for (i = 0; i < numConns; i++)
	{
		NWGetFileServerName (connList[i], server);
//		printf ("ID:  %04X  Server:  %s\n", connList[i], server);
    m_Server.AddString(server);
	}
	free (connList);
#endif	
  return true;
}

/////////////////////////////////////////////////////////////////////////////

bool CWin32SendDlg::NovellGetUsers(CString sServer)
{
#ifndef _DEBUG
  CString sUser;

  NWCONN_HANDLE   connHandle;
  NWCCODE         ccode;
  NWINET_ADDR     addr;
  NWCONN_NUM      i;
  nuint16         suMaxConnects;
  nuint32         luID;
  nstr8           strName[130];
  nstr8           strCName[80], strCopy[80];
  nstr8           strRev[80], strRevDate[80];
  nstr8           strServer[NW_MAX_SERVER_NAME_LEN];

  ccode = NWCallsInit(NULL,NULL);
  if(ccode)
  {
    return false;
  }

  strcpy(strServer, sServer);

  ccode = NWGetConnectionIDFromName(
           /* length of server name */ (nuint32)strlen(strServer),
           /* server name           */ (nuint8*)strServer,
           /* handle to server      */  &connHandle);
  if(ccode)
  {
    return false;
  }

  ccode = NWGetFileServerDescription(connHandle, strCName, strRev, strRevDate, strCopy);
  if(ccode)
  {
    return false;
  }

  // Only interested in MaxConnections, pass in NULL to other fields

  ccode = NWGetFileServerInformation(
            /* handle to server */  connHandle,
            /* server name      */  NULL,
            /* major version #  */  NULL,
            /* minor version #  */  NULL,
            /* rev              */  NULL,
            /* max conns        */  &suMaxConnects,
            /* max conns used   */  NULL,
            /* conns in use     */  NULL,
            /* num volumes      */  NULL,
            /* SFT level        */  NULL,
            /* TTS level        */  NULL);
  if(ccode)
  {
    return false;
  }

  for(i = 0; i < suMaxConnects; i++)
  {
    ccode = NWGetConnectionInformation(connHandle, i, strName, NULL, &luID, NULL);

    if((ccode == 0) && (luID != 0L))
    {
      ccode = NWGetInetAddr(connHandle, i, &addr);
      m_To.AddString(strName);
    }
  }
#endif

  return true;
}

/////////////////////////////////////////////////////////////////////////////

void CWin32SendDlg::OnSend() 
{
  UpdateData();

  if(m_sServer != "" && m_sTo != "")
  {
    char* server = new char[50];
	  char*	user = new char[50];
    char*	message = new char[256];

	  strcpy(server, strupr(m_sServer.GetBuffer(50)));
	  strcpy(user, strupr(m_sTo.GetBuffer(50)));
	  strcpy(message, m_sMessage.GetBuffer(256));

    m_sMessage.ReleaseBuffer();
    m_sServer.ReleaseBuffer();
    m_sTo.ReleaseBuffer();

    #ifndef _DEBUG

    for(int i = 0; i < m_nNumber; i++)
    {
      if(NovellSendMessage(server, user, message))
        m_Message.SetWindowText("");
      else
      {
        AfxMessageBox("Error - send message");
        break;
      }
    }
    #endif	
  }
  else
    AfxMessageBox("Incomplete request");
    
}

/////////////////////////////////////////////////////////////////////////////

void CWin32SendDlg::OnOK() 
{

}

/////////////////////////////////////////////////////////////////////////////

void CWin32SendDlg::OnCancel() 
{
  int nResult = MessageBox("Really Quit???", NULL, MB_ICONQUESTION | MB_YESNO);
  if(nResult != IDNO)
  	CDialog::OnCancel();
}

/////////////////////////////////////////////////////////////////////////////

void CWin32SendDlg::OnSelchangeServer() 
{
  UpdateData();

  UINT nUser = 0;
  while(nUser != CB_ERR)
    nUser = m_To.DeleteString(0);

  if(!NovellGetUsers(m_sServer))
    AfxMessageBox("Error - Novell");
}

/////////////////////////////////////////////////////////////////////////////

BOOL CWin32SendDlg::PreTranslateMessage(MSG* pMsg) 
{
  if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN)
    NextDlgCtrl();
	
	return CDialog::PreTranslateMessage(pMsg);
}

/////////////////////////////////////////////////////////////////////////////
