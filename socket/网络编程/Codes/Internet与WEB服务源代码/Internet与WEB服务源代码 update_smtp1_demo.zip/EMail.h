// EMail.h : main header file for the EMAIL application
//

#if !defined(AFX_EMAIL_H__EAB43574_B50D_11D2_BD04_006097990766__INCLUDED_)
#define AFX_EMAIL_H__EAB43574_B50D_11D2_BD04_006097990766__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CEMailApp:
// See EMail.cpp for the implementation of this class
//

class CEMailApp : public CWinApp
{
public:
	CEMailApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEMailApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CEMailApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EMAIL_H__EAB43574_B50D_11D2_BD04_006097990766__INCLUDED_)
