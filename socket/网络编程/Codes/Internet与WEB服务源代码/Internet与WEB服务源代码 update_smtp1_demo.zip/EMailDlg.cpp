// EMailDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EMail.h"
#include "EMailDlg.h"

#include ".\emaillib\smtp.h"
#include ".\emaillib\MIMEMessage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static TCHAR _szFilter[]  = TEXT("All Files\0*.*\0Text Files (*.txt)\0*.TXT\0");

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEMailDlg dialog

CEMailDlg::CEMailDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEMailDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEMailDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CEMailDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEMailDlg)
	DDX_Control(pDX, IDC_LIST_FILES, m_ListBox);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CEMailDlg, CDialog)
	//{{AFX_MSG_MAP(CEMailDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_ADD_FILE, OnButtonAddFile)
	ON_BN_CLICKED(IDC_BUTTON_SEND, OnButtonSend)
	ON_BN_CLICKED(IDC_BUTTON_QUIT, OnButtonQuit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEMailDlg message handlers

BOOL CEMailDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CEMailDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEMailDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEMailDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CEMailDlg::OnCancel() 
{
	CDialog::OnCancel();
}

void CEMailDlg::OnOK() 
{
//  	CDialog::OnOK();
}

void CEMailDlg::OnButtonAddFile() 
{
   CString file;

   // **** I had some proble with the flags OFN_ALLOWMULTISELECT of the CFileDialog ?????
   // **** If I took multiple selection bigger then I could view on the selection, the list
   // **** returned is bad ???
   CFileDialog dialog(TRUE,_szFilter,NULL, OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_EXPLORER);

   dialog.DoModal();

   POSITION pos = dialog.GetStartPosition();

   while (pos != NULL)
   {
      file = dialog.GetNextPathName( pos );

      m_ListBox.AddString(file);
   }
}

void CEMailDlg::OnButtonSend() 
{
   CWaitCursor();

   //*** Retreive all information
   CString serverAdr;

   CString from;
   CString to;
	CString cc;
	CString bcc;
	CString subject;
	CString body;

   GetDlgItemText( IDC_EDIT_SMTP,    serverAdr );
   GetDlgItemText( IDC_EDIT_FROM,    from );
   GetDlgItemText( IDC_EDIT_TO,      to );
   GetDlgItemText( IDC_EDIT_CC,      cc );
   GetDlgItemText( IDC_EDIT_BCC,     bcc );
   GetDlgItemText( IDC_EDIT_SUBJECT, subject );
   GetDlgItemText( IDC_EDIT_BODY,    body );

   if ( to.IsEmpty() )
   {
      AfxMessageBox("Please fill -to- field");
      return;
   };

   if ( subject.IsEmpty() )
   {
      AfxMessageBox("Please fill -subject- field");
      return;
   };

   if ( body.IsEmpty() )
   {
      AfxMessageBox("Please write something..");
      return;
   };

   if ( serverAdr.IsEmpty() )
   {
      AfxMessageBox("Please fill server field..");
      return;
   };

   //*** Send
	CMIMEMessage msg;
	CSMTP smtp( serverAdr );
   
   msg.m_sFrom    = from;
	msg.m_sSubject = subject;
	msg.m_sBody    = body;
   msg.AddMultipleRecipients( to );

   if ( !cc.IsEmpty() )
   {
	   msg.AddMultipleRecipients( cc, CMailMessage::CC );
   }

   if ( !bcc.IsEmpty() )
   {
   	msg.AddMultipleRecipients( bcc, CMailMessage::BCC );
   }

   //*** Here we had every attached files..
   int count = m_ListBox.GetCount();
   CString file;

   for (int index = 0; index < count; index++)
   {
      m_ListBox.GetText(index, file);

      msg.AddMIMEPart( file ); 
   }

   //*** Set all control to disable
   EnableWindow(FALSE);

   smtp.Connect();
	
   if (!smtp.SendMessage( &msg ))
   {
      MessageBox(smtp.GetLastError());
   }
   else
   {
      MessageBox("Sent");

      SetDlgItemText( IDC_EDIT_TO, "" );
      SetDlgItemText( IDC_EDIT_CC, "" );
      SetDlgItemText( IDC_EDIT_BCC, "" );
      SetDlgItemText( IDC_EDIT_SUBJECT, "" );
      SetDlgItemText( IDC_EDIT_BODY, "" );
   }

   m_ListBox.ResetContent();

	smtp.Disconnect();

   //*** Set all control to enable
   EnableWindow(TRUE);
}

void CEMailDlg::OnButtonQuit() 
{
   EndDialog(0);
}
