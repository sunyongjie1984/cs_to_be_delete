/*----------------------------------------------------------------------------------------------- 
// PopGet.cpp : Defines the class behaviors for the application. 
---------------------------------------------------------------------------------------------------*/ 

#include "stdafx.h" 
//#include "TesToolbar.h"
#include "Popget.h" 

#ifdef _DEBUG 
#define new DEBUG_NEW 
#undef THIS_FILE 
static char THIS_FILE[] = __FILE__; 
#endif 

#define templist "templist.pop"			// <<file used for temp list command
#define temptop	 "temptop.pop"			// <<file used for temp top command

//////////////////////////////////////////////////////////////////// 
// CPop Class 
////////////////////////////////////////////////////////////////////// 

////////////////////////////////////////////////////////////////////// 
// Construction/Destruction 
////////////////////////////////////////////////////////////////////// 
CPop::CPop() 
{ 
	if (!m_PopServer.Create()) MessageBox(NULL,"Cant create socket!","Warning",MB_OK);
} 
//{4EEC1C91-6BE1-11d1-8824-00001C302581} 

CPop::~CPop() 
{ 
 m_PopServer.Close(); 
} 

BOOL CPop::Connect(CString & Host, int Port, CString & User, CString & Password) 
{ 
 char buf [512]; 

 if (!m_PopServer.Connect(Host,Port)) // 110 Pop3 Port 
 { 
  m_ErrorMessage = _T("Server cannot be connected"); 
  return FALSE; 
 } 
 else 
 { 
  if(CheckResponse(CONNECTION_CHECK)==FALSE) 
   return FALSE; 

  wsprintf (buf, "USER %s\r\n", (LPCSTR) User); 
  m_PopServer.Send(buf, strlen (buf)); 
  if(CheckResponse(USER_CHECK)==FALSE) 
   return FALSE; 

  wsprintf (buf, "PASS %s\r\n", (LPCSTR) Password); 
  m_PopServer.Send(buf, strlen (buf)); 
  if (CheckResponse(PASSWORD_CHECK)==FALSE) 
   return FALSE; 

  return TRUE; 
 } 

} 

BOOL CPop::Delete(int & MsgNumber) 
{ 
 char buf [512]; 

 wsprintf (buf, "DELE %d\r\n",MsgNumber ); 
 m_PopServer.Send(buf, strlen (buf)); 
 if (CheckResponse(DELETE_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

BOOL CPop::Disconnect() 
{ 
 char buf [512]; 

 wsprintf (buf, "QUIT \r\n"); 
 m_PopServer.Send(buf, strlen (buf)); 
 if (CheckResponse(QUIT_CHECK)==FALSE) 
  return FALSE; 
 else 
 {
	m_PopServer.Close(); 
	return TRUE; 
 }
} 

BOOL CPop::Noop() 
{ 
 char buf [512]; 

 wsprintf (buf, "NOOP  \r\n"); 
 m_PopServer.Send(buf, strlen (buf)); 
 if (CheckResponse(NOOP_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

// Return the Msg Size for given msg number 
int CPop::GetMessageSize(int MsgNumber) 
{ 
 if(m_SizeOfMsg.GetSize() < MsgNumber+1) 
  return 0; 
 else 
  return m_SizeOfMsg[MsgNumber+1]; 
} 

BOOL CPop::Reset() 
{ 
 char buf [512]; 

 wsprintf (buf, "RSET \r\n"); 
 m_PopServer.Send(buf, strlen (buf)); 
 if (CheckResponse(RSET_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

// MsgContents will hold the msg body 
BOOL CPop::Retrieve(int  MsgNumber) 
{ 
 char buf [512]; 

 m_todisk=FALSE;
 wsprintf (buf, "RETR %d\r\n",MsgNumber );
 m_PopServer.Send(buf, strlen (buf)); 
 if (CheckResponse(RETR_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

BOOL CPop::Retrieve(int  MsgNumber,CString fname) 
{ 
 char buf [512]; 

 if (SetOutputFile(fname)) m_todisk=TRUE;
 else
 {
	m_ErrorMessage = _T("Error opening output file");
	 return FALSE;
 }
 wsprintf (buf, "RETR %d\r\n",MsgNumber );
 m_PopServer.Send(buf, strlen (buf)); 
 if (CheckResponse(RETR_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

BOOL CPop::Statistics() 
{ 
 char buf [512]; 

 wsprintf (buf, "STAT \r\n"); 
 m_PopServer.Send(buf, strlen (buf)); 
 if (CheckResponse(STAT_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

CString CPop::GetMsgContents() 
{ 
 return m_MsgContents; 
} 

int CPop::GetNumberOfMails() 
{ 
 return m_NumberMail; 
} 

int CPop::GetTotalMailSize() 
{ 
 return m_TotalSize; 
} 

BOOL CPop::Connect() 
{ 
 return Connect(m_Host, m_port, m_User, m_Password); 
} 

void CPop::SetHost(CString Host) 
{ 
 m_Host = Host; 
} 

CString CPop::GetHost() 
{ 
 return m_Host; 
} 

void CPop::SetUser(CString User) 
{ 
 m_User = User; 
} 

CString CPop::GetUser() 
{ 
 return m_User; 
} 

void CPop::SetPassword(CString Password) 
{ 
 m_Password = Password; 
} 

CString CPop::GetPassword() 
{ 
 return m_Password; 
} 

BOOL CPop::CheckResponse(int ResponseType) 
{ 
 char buf[8192]; 
 int	totr,skip;
 BOOL	ready;

 for (int i=0;i<sizeof(buf);i++) 
  buf[i]='\0'; 

 Sleep(2000);
 totr=m_PopServer.Receive(buf, sizeof(buf)); 

 switch (ResponseType) 
 { 
  case CONNECTION_CHECK: 
   if (strnicmp(buf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Bad Connection"); 
    return FALSE; 
   } 
   break; 

  case USER_CHECK: 
   if (strnicmp(buf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Bad User Name"); 
    return FALSE; 
   } 
   break; 
  case PASSWORD_CHECK: 
   if (strnicmp(buf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Bad Password Name"); 
    return FALSE; 
   } 
   break; 
  case QUIT_CHECK: 
   if (strnicmp(buf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error occured during QUIT"); 
    return FALSE; 
   } 
   break; 
  case DELETE_CHECK: 
   if (strnicmp(buf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error occured during DELE"); 
    return FALSE; 
   } 
   break; 
  case RSET_CHECK: 
   if (strnicmp(buf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error occured during RSET"); 
    return FALSE; 
   } 
   break; 
  case STAT_CHECK: 
   if (strnicmp(buf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error occured during STAT"); 
    return FALSE; 
   } 
   else 
   { 
    BOOL EmailNumber = TRUE; 
    for (char *p = buf; *p != '\0'; p++) 
    { 
     if (*p == '\t' || *p == ' ') 
     { 
      if(EmailNumber == TRUE) 
      { 
       m_NumberMail = atoi(p); 
       EmailNumber = FALSE; 
      } 
      else 
      { 
       m_TotalSize = atoi(p); 
       return TRUE; 
      } 
     } 
    } 
   } 
   break; 
  case NOOP_CHECK: 
   if (strnicmp(buf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error occured during NOOP"); 
    return FALSE; 
   } 
   break; 
  case LIST_CHECK: 
	if (strnicmp(buf,"-ERR", 4) == 0) 
	{ 
	    m_ErrorMessage = _T("Error occured during LIST"); 
		return FALSE; 
	} 
	else 
	{ 
		m_outputfile.Open(templist,CFile::modeCreate|CFile::modeWrite);
		if (m_outputfile==0)
		{
					//receive all rest data and return false;

			if ((totr!=0) && (totr==sizeof(buf))) totr=m_PopServer.Receive(buf, sizeof(buf));

			m_ErrorMessage = _T("Error creating temp input file!");
			return FALSE;
		}

	   ready=FALSE;
	   if (strnicmp(buf,"+OK \r\n", 6) == 0) skip=6;
	   else  skip=4;			//skip +OK(SPACE)
	   while (!ready)
	   {
			if (totr==SOCKET_ERROR)
			{
				m_outputfile.Close();
				ready=TRUE;
				m_ErrorMessage = _T("Error reading from socket!");
				return FALSE;
			}
			else
			{
				m_outputfile.Write(buf+skip,totr-skip);
				skip=0;
				if (
					((buf[totr-3]=='.')&&(buf[totr-2]=='\r')&&(buf[totr-1]=='\n')) ||
					(totr==0) ||
					((buf[0]='O')&&(buf[1]=='K')&&(buf[totr-3]=='.')&&(buf[totr-2]=='\r')&&(buf[totr-1]=='\n'))
					)
				{
					ready=TRUE;
					m_outputfile.Close();
				}
				else
				{
					totr=m_PopServer.Receive(buf, sizeof(buf));
				}
			}
	   }
		return MakeMsgList();
   }
   break; 
  case RETR_CHECK: 
   if (strnicmp(buf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error occured during RETR"); 
	if (m_todisk) m_outputfile.Close();
    return FALSE; 
   } 
   else 
   { 
	   skip=0;
	   if (strnicmp(buf,"+OK", 3) == 0)
	   {
		   int ii=0;
		   while (buf[ii]!='R') ii++;
		   skip=ii;
	   }
	ready=FALSE;
    while (!ready)
	{
		if (totr==SOCKET_ERROR)
		{
			if (m_todisk) m_outputfile.Close();
			ready=TRUE;
			m_ErrorMessage = _T("Error reading from socket!");
			return FALSE;
		}
		else
		{
			if (m_todisk) m_outputfile.Write(buf+skip,totr-skip);
			skip=0;
			if (
				((buf[totr-3]=='.')&&(buf[totr-2]=='\r')&&(buf[totr-1]=='\n')) ||
				(totr==0)
				)
			{
				ready=TRUE;
				if (m_todisk) m_outputfile.Close();
			}
			else
			{
				totr=m_PopServer.Receive(buf, sizeof(buf)); 
			}
		}
	}	
	if (!m_todisk) m_MsgContents = buf; 
   } 
   break; 
  case TOP_CHECK: 
	m_outputfile.Open(temptop,CFile::modeCreate|CFile::modeWrite);
	if (m_outputfile==0)
	{
				//receive all rest data and return false;
		if ((totr!=0) && (totr==sizeof(buf))) totr=m_PopServer.Receive(buf, sizeof(buf));
		m_ErrorMessage = _T("Error creating temp input file!");
		return FALSE;
	}

   ready=FALSE;
   if (strnicmp(buf,"+OK \r\n", 6) == 0) skip=6;
   else  skip=4;			//skip +OK(SPACE)
   while (!ready)
   {
		if (totr==SOCKET_ERROR)
		{
				//receive all rest data and return false;
			if ((totr!=0) && (totr==sizeof(buf))) totr=m_PopServer.Receive(buf, sizeof(buf));
			m_outputfile.Close();
			ready=TRUE;
			m_ErrorMessage = _T("Error reading from socket!");
			return FALSE;
		}
		else
		{
			m_outputfile.Write(buf+skip,totr-skip);
			skip=0;
			if (
				((buf[totr-3]=='.')&&(buf[totr-2]=='\r')&&(buf[totr-1]=='\n')) ||
				(totr==0)
				)
			{
				ready=TRUE;
				m_outputfile.Close();
			}
			else
			{
				totr=m_PopServer.Receive(buf, sizeof(buf));
			}
		}
   }
   if (ExtractTop(temptop))
   {
	CFile::Remove(temptop);
	return TRUE;
   }
   else
   {
	CFile::Remove(temptop);
	return FALSE;
   }


   break; 
 } 
 return TRUE; 
} 

CString CPop::GetErrorMessage() 
{ 
 return m_ErrorMessage; 
} 

BOOL CPop::List() 
{ 
 char buf [512]; 

 wsprintf (buf, "LIST  \r\n"); 
 m_PopServer.Send(buf, strlen (buf)); 
 if (CheckResponse(LIST_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

BOOL CPop::GetTop(int MsgNumber, int Length) 
{ 
 char buf [512]; 

 m_todisk=FALSE;
 wsprintf (buf, "TOP %d %d\r\n",MsgNumber,Length );
 m_PopServer.Send(buf, strlen (buf)); 
 if (CheckResponse(TOP_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 


void CPop::SetPort(int port)
{
	m_port=port;
}


BOOL CPop::SetOutputFile(CString fname)
{
TRY
{
	m_outputfile.Open(fname,CFile::modeCreate|CFile::modeWrite);
	return TRUE;
}
CATCH( CFileException, e )
{
	MessageBox(NULL,"Error opening outputfile!","Error:",MB_OK);
	return FALSE;
}
END_CATCH
}

BOOL CPop::ExtractTop(CString fname)
{
	CString tcstring;
	int pos;

TRY{
	CStdioFile f(fname,CFile::modeRead);
	while (f.ReadString(tcstring))
	{
		tcstring.TrimLeft(); tcstring.TrimRight();
		if (tcstring.Find('\r')!=-1) tcstring=tcstring.Left(tcstring.GetLength()-1);
		if (tcstring.Find('\n')!=-1) tcstring=tcstring.Left(tcstring.GetLength()-1);
		tcstring.TrimLeft(); tcstring.TrimRight();

		if (pos=tcstring.Find("To:")==0) t_To=tcstring.Right(tcstring.GetLength()-sizeof("To:"));
		if (pos=tcstring.Find("From:")==0) t_From=tcstring.Right(tcstring.GetLength()-sizeof("From:"));
		if (pos=tcstring.Find("Subject:")==0) t_Subject=tcstring.Right(tcstring.GetLength()-sizeof("Subject:"));
		if (pos=tcstring.Find("Date:")==0) t_Date=tcstring.Right(tcstring.GetLength()-sizeof("Date:"));
	}
	f.Close();
	if ((t_To=="")||(t_From=="")||(t_Date=="")) return FALSE;
	else return TRUE;
}
CATCH( CFileException, e ){
	m_ErrorMessage="cant open message file";
	return FALSE;
}END_CATCH

}

BOOL CPop::MakeMsgList()
{
	m_SizeOfMsg.RemoveAll();
	CString tcstring;
	int ii;

TRY{
	CStdioFile f(templist,CFile::modeRead);
	while (f.ReadString(tcstring))
	{
		tcstring.TrimLeft(); tcstring.TrimRight();
		if (tcstring.Find('\r')!=-1) tcstring=tcstring.Left(tcstring.GetLength()-1);
		if (tcstring.Find('\n')!=-1) tcstring=tcstring.Left(tcstring.GetLength()-1);
		tcstring.TrimLeft(); tcstring.TrimRight();
		ii=tcstring.Find(' ');
		if (ii!=-1)
		{
			tcstring=tcstring.Mid(ii+1,tcstring.GetLength());
			m_SizeOfMsg.Add(atoi(tcstring));
		}
	}
	f.Close();
	CFile::Remove(templist);
	return TRUE;
}
CATCH( CFileException, e ){
	m_ErrorMessage="cant open templist file";
	CFile::Remove(templist);
	return FALSE;
}END_CATCH
}
