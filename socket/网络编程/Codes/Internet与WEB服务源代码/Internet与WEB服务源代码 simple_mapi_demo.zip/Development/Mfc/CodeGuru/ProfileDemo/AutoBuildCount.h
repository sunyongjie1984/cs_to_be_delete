// 2
#ifndef AUTOBUILDCOUNT_H
#define AUTOBUILDCOUNT_H
#define BUILDCOUNT_NUM 2
#define BUILDCOUNT_STR "2"
#endif
