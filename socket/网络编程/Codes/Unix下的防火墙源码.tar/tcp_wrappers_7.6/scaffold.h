 /*
  * @(#) scaffold.h 1.3 94/12/31 18:19:19
  * 
  * Author: Wietse Venema, Eindhoven University of Technology, The Netherlands.
  */

extern struct hostent *find_inet_addr();
extern int check_dns();
extern int check_path();
