// WhoisSocket.cpp : implementation file
//

#include "stdafx.h"
#include "Whois.h"
#include "WhoisSocket.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern CString m_HostName;
extern UINT m_HostPort;
/////////////////////////////////////////////////////////////////////////////
// CWhoisSocket

CWhoisSocket::CWhoisSocket()
{
	m_Waiting = FALSE; //Set Waiting BOOLEAN to FALSE
}

CWhoisSocket::~CWhoisSocket()
{
	//Delete associated SocketFile and Archives
	//So that this object may be reused
	if( m_pFile )
	{
		delete m_pArchiveIn;
		delete m_pArchiveOut;
		delete m_pFile;
	}
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CWhoisSocket, CSocket)
	//{{AFX_MSG_MAP(CWhoisSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CWhoisSocket member functions


BOOL CWhoisSocket::Query(CString& Query)
{
	//Make sure socket is created successfully
	if (!Create())
	{
		Error("Could not create socket!"); return FALSE;
	}
	//Attempt the connection to remote host
	if (!Connect(m_HostName,m_HostPort))
	{
		Error("Failure when attempting to connect!"); return FALSE;

	}
	//Initialize Waiting BOOLEAN to TRUE
	m_Waiting = TRUE;

	//Initialize new CSocketFile and Archives to represent this connection
	m_pFile = new CSocketFile(this);
	m_pArchiveIn = new CArchive(m_pFile,CArchive::load);
	m_pArchiveOut = new CArchive(m_pFile,CArchive::store);
	
	//Begin sending data to remote host
	TRY
	{
		Query += "\n";
		m_pArchiveOut->WriteString(Query);
		m_pArchiveOut->Flush();
	
	}
	CATCH(CFileException, e)
	{
		m_pArchiveOut->Abort();
		Error("Server has reset the connection."); return FALSE;
	}
	END_CATCH
	
	//Now, we wait for the response to arrive in OnReceive()---->
	return TRUE;
}

void CWhoisSocket::OnReceive(int nErrorCode) 
{	
	//Data has arrived from remote side
	CSocket::OnReceive(nErrorCode);

	//Begin reading incoming data
	TRY
	{
		do //Loop while the archive holding the incoming data is not empty
		{
			CString tmp;
			m_pArchiveIn->ReadString(tmp);
			m_strResult += "\r\n" + tmp;
		}
		while (!m_pArchiveIn->IsBufferEmpty());

		//Set Waiting BOOLEAN to FALSE
		m_Waiting = FALSE;

		//Enable Query button, select text in combo
		//and display results from Whois Query
		CDialog * theDlg = (CDialog*)AfxGetMainWnd();
		CComboBox* theCombo = (CComboBox*)theDlg->GetDlgItem(IDC_QUERY);
		CButton* theQueryBtn = (CButton*)theDlg->GetDlgItem(IDOK);
		CEdit* theResponseBox = (CEdit*)theDlg->GetDlgItem(IDC_OUTPUT);

		theResponseBox->SetWindowText(m_strResult);
		theCombo->SetEditSel(0,theCombo->GetWindowTextLength());
		theQueryBtn->EnableWindow(TRUE);
	}
	CATCH(CFileException, e)
	{
		m_pArchiveOut->Abort();
		Error("Connection reset by remote side."); return;
	}
	END_CATCH
}

void CWhoisSocket::Error(const CString& eMsg)
{
	//Displays a message box of the Winsock error that occurred
	m_Waiting = FALSE;

	CString errMsg;
	CDialog * theDlg = (CDialog*)AfxGetMainWnd();
	CButton* theQueryBtn = (CButton*)theDlg->GetDlgItem(IDOK);
	theQueryBtn->EnableWindow(TRUE);
	errMsg.Format("%s %s","Winsock Error: \n\n",eMsg);
	AfxMessageBox(errMsg,MB_OK|MB_ICONSTOP);

}
