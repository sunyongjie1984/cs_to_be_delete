// Whois.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Whois.h"
#include "WhoisDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
CString m_HostName;
UINT m_HostPort;
UINT m_MaxCachedQueries;
/////////////////////////////////////////////////////////////////////////////
// CWhoisApp

BEGIN_MESSAGE_MAP(CWhoisApp, CWinApp)
	//{{AFX_MSG_MAP(CWhoisApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWhoisApp construction

CWhoisApp::CWhoisApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CWhoisApp object

CWhoisApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CWhoisApp initialization

BOOL CWhoisApp::InitInstance()
{
	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();

	SetRegistryKey("Whois_v1.0"); //Set master registry key for App

	//Initialize global variables for MaxCachedQueries, Host Name and Port
	//Reverts to default (10,rs.internic.net,43 respectively)if no values are found
	m_MaxCachedQueries = strtol(GetProfileString("Settings","MaxCachedQueries","10"),NULL,10);
	m_HostName = GetProfileString("Settings","HostName","networksolutions.com");
	m_HostPort = strtol(GetProfileString("Settings","HostPort","43"),NULL,10);

	//Enable command line ability, and check for command line
	//if one is found, the member variable m_strQuery is initialized
	//in our WhoisDlg. This will cause the dialog to automatically
	//run a query on the data passed via command line.
	EnableShellOpen();
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);
	CWhoisDlg dlg;
	m_pMainWnd = &dlg;

	if (cmdInfo.m_strFileName.GetLength() !=0)
	{
		dlg.m_strQuery = cmdInfo.m_strFileName;

	}

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif
	
	//Show dialog
	int nResponse = dlg.DoModal();

	return FALSE;
}
