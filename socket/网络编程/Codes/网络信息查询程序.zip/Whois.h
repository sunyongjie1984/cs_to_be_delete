// Whois.h : main header file for the WHOIS application
//

#if !defined(AFX_WHOIS_H__B9DDE424_7A31_11D4_8F59_006008B13CA9__INCLUDED_)
#define AFX_WHOIS_H__B9DDE424_7A31_11D4_8F59_006008B13CA9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CWhoisApp:
// See Whois.cpp for the implementation of this class
//

class CWhoisApp : public CWinApp
{
public:
	CWhoisApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWhoisApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CWhoisApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WHOIS_H__B9DDE424_7A31_11D4_8F59_006008B13CA9__INCLUDED_)
