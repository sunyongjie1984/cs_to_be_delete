// UsageDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Whois.h"
#include "UsageDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUsageDialog dialog


CUsageDialog::CUsageDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CUsageDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUsageDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CUsageDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUsageDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUsageDialog, CDialog)
	//{{AFX_MSG_MAP(CUsageDialog)
	ON_BN_CLICKED(IDCLOSE, OnClose)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUsageDialog message handlers

void CUsageDialog::OnClose() 
{
	EndDialog(1);	
}

BOOL CUsageDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CEdit* theEdit = (CEdit*)GetDlgItem(IDC_USAGE);
	theEdit->SetWindowText(m_strUsageText);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
