#if !defined(AFX_WHOISSOCKET_H__B9DDE42E_7A31_11D4_8F59_006008B13CA9__INCLUDED_)
#define AFX_WHOISSOCKET_H__B9DDE42E_7A31_11D4_8F59_006008B13CA9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WhoisSocket.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CWhoisSocket command target

class CWhoisSocket : public CSocket
{
// Attributes
public:

// Operations
public:
	CWhoisSocket();
	virtual ~CWhoisSocket();
	BOOL CWhoisSocket::Query(CString& Query);
	void CWhoisSocket::Error(const CString& eMsg);
	BOOL m_Waiting;
// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWhoisSocket)
	public:
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CWhoisSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
	CSocketFile *m_pFile;
	CArchive *m_pArchiveIn, *m_pArchiveOut;
	CString m_strQuery,m_strResult;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WHOISSOCKET_H__B9DDE42E_7A31_11D4_8F59_006008B13CA9__INCLUDED_)
