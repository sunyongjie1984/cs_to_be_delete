// PropertiesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Whois.h"
#include "PropertiesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern CString m_HostName;
extern UINT m_HostPort;
extern UINT m_MaxCachedQueries;
/////////////////////////////////////////////////////////////////////////////
// CPropertiesDlg dialog


CPropertiesDlg::CPropertiesDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPropertiesDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPropertiesDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CPropertiesDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertiesDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertiesDlg, CDialog)
	//{{AFX_MSG_MAP(CPropertiesDlg)
	ON_BN_CLICKED(IDOK, OnSaveProperites)
	ON_BN_CLICKED(IDC_CLEARQUERIES, OnClearQueries)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertiesDlg message handlers

void CPropertiesDlg::OnSaveProperites() 
{
	CWinApp* theApp = AfxGetApp();
	CComboBox* theCombo = (CComboBox*)GetDlgItem(IDC_REMEMBER);
	CString cText;
	theCombo->GetWindowText(cText);

	//If max queries value is not numeric, exit
	if (!IsStringNumeric(cText))
	{
		AfxMessageBox("Please enter a number in the 'Amount of Queries to save' field.",MB_OK|MB_ICONEXCLAMATION);
		return;
	}

	//Save max allowed cacheable queries to registry
	//And initialize global m_MaxCachedQueries to new value
	theApp->WriteProfileString("Settings","MaxCachedQueries",cText);
	m_MaxCachedQueries = strtol(cText,NULL,10);


	//Save host name and remote port to registry
	CString hostName;
	CString hostPort;
	CEdit* txthostName = (CEdit*)GetDlgItem(IDC_HOST);
	CEdit* txthostPort = (CEdit*)GetDlgItem(IDC_PORT);
	txthostName->GetWindowText(hostName);
	txthostPort->GetWindowText(hostPort);

	//Validate that host name and port are valid
	if (hostName.GetLength() ==0) 
	{
		AfxMessageBox("Please provide an entry for the 'Host' field.",MB_OK|MB_ICONSTOP);
		txthostName->SetSel(0,txthostName->GetWindowTextLength());
		return;
	}

	if (hostPort.GetLength() == 0 || IsStringNumeric(hostPort) == FALSE)
	{
		AfxMessageBox("Please provide a valid entry for the 'Port' field.",MB_OK|MB_ICONSTOP);
		txthostPort->SetSel(0,txthostPort->GetWindowTextLength());
		return;
	}

	theApp->WriteProfileString("Settings","HostName",hostName);
	theApp->WriteProfileString("Settings","HostPort",hostPort);
	
	//Set globals m_HostName and m_HostPort to new values
	m_HostName = hostName;
	m_HostPort = strtol(hostPort,NULL,10);

	//Hide dialog
	EndDialog(1);
	
}


BOOL CPropertiesDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CWinApp* theApp = AfxGetApp();
	CString cText;
	CString HostName;
	CString HostPort;
	CComboBox* theCombo = (CComboBox*)GetDlgItem(IDC_REMEMBER);
	CEdit* txthostName = (CEdit*)GetDlgItem(IDC_HOST);
	CEdit* txthostPort = (CEdit*)GetDlgItem(IDC_PORT);

	//Read settings from registry
	cText = theApp->GetProfileString("Settings","MaxCachedQueries","10");
	HostName = theApp->GetProfileString("Settings","HostName","rs.internic.net");
	HostPort = theApp->GetProfileString("Settings","HostPort","43");

	txthostName->SetWindowText(HostName);
	txthostPort->SetWindowText(HostPort);

	//Set Global variables for host and port
	m_HostName = HostName;
	m_HostPort = strtol(HostPort,NULL,10);

	theCombo->SetWindowText(cText);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
BOOL CPropertiesDlg::IsStringNumeric(CString& strString)
{   
	//Takes a CString and determines if it is purely numeric
	//for use in transferring strings to numeric data types
	//FALSE for non-numeric, TRUE for purely numeric

	if (strString.FindOneOf("1234567890")==-1 || strString.FindOneOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ`~[]{}-_=+\\|'/?>,<") !=-1)
		{
			return FALSE;
		}

	return TRUE;

}
void CPropertiesDlg::OnClearQueries() 
{
	CDialog* theDlg = (CDialog*)AfxGetMainWnd();
	CWinApp* theApp = AfxGetApp();
	CComboBox* theCombo = (CComboBox*)theDlg->GetDlgItem(IDC_QUERY);

	//Get count of Queries currently residing in combo box on dialog
	int Count = theCombo->GetCount();

	//If the count is greater than 0, clear the combo box
	//and write NULL to registry key that contains cached queries
	if (!Count ==0)
	{
		CString report;
		report.Format("%d Cached Queries cleared.",Count);
		theCombo->ResetContent();
		theApp->WriteProfileString("Settings","Queries","");
		AfxMessageBox(report,MB_OK|MB_ICONINFORMATION);
	}
	else
	{
		AfxMessageBox("No Queries found to clear.",MB_OK|MB_ICONSTOP);
	}

	
}
