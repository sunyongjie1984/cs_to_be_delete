// WhoisDlg.h : header file
//

#if !defined(AFX_WHOISDLG_H__B9DDE426_7A31_11D4_8F59_006008B13CA9__INCLUDED_)
#define AFX_WHOISDLG_H__B9DDE426_7A31_11D4_8F59_006008B13CA9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "WhoisSocket.h"
#include "PropertiesDlg.h"
#include "UsageDialog.h"
/////////////////////////////////////////////////////////////////////////////
// CWhoisDlg dialog

class CWhoisDlg : public CDialog
{
// Construction
public:
	CWhoisDlg(CWnd* pParent = NULL);	// standard constructor
	CButton	m_btnClipboard;
// Dialog Data
	//{{AFX_DATA(CWhoisDlg)
	enum { IDD = IDD_WHOIS_DIALOG };
	
	CString	m_strResponse;
	CString	m_strQuery;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWhoisDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	CWhoisSocket *ourSocket;
	void CWhoisDlg::SaveQueries();
	void CWhoisDlg::LoadQueries();
	CPropertiesDlg m_dlgProperties;
	// Generated message map functions
	//{{AFX_MSG(CWhoisDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	afx_msg void OnProperties();
	afx_msg void OnQuery();
	afx_msg void OnUsage();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WHOISDLG_H__B9DDE426_7A31_11D4_8F59_006008B13CA9__INCLUDED_)
