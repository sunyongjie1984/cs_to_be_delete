The vbnbsvr sample and vbnbclient sample demonstrate session-based communications using NetBios calls. 

You need to run the vbnbsvr first, and click listen. The vbnbsvr will block until the client connects and sends some message to it. Then you can start the vbnbclient, and click connect. You will see the message exchanges between the vbnbsvr and the vbnbclient.
