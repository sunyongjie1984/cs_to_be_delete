// Module: nspguid.cpp
//
// Description:
//    This file simply defines the value for MY_NAMESPACE_GUID
//    which is used by several components of this sample.
//
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

GUID MY_NAMESPACE_GUID = {0x55a2bd9e,0xbb30,0x11d2,{0x91,0x66,0x00,0xa0,0xc9,0xa7,0x86,0xe8}} ;

