The filio sample demonstrate using Win32 File I/O API to directly create and write 
to a file on a remote share. 

The application doesn't have a user interface. It uses VB message box to 
indicate program status to users.
