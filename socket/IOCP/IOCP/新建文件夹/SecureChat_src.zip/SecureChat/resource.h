//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SecureChat.rc
//
#define IDD_SECURECHAT_DIALOG           102
#define IDD_RANDOM                      103
#define IDR_MAINFRAME                   128
#define IDB_HEADER                      130
#define IDC_TXTOUT                      1000
#define IDC_SIMPLELIBTEST               1001
#define IDC_RSATEST                     1002
#define IDC_GENERATEKEY                 1003
#define IDC_KEYSIZE                     1004
#define IDC_DHTEST                      1005
#define IDC_TOPTAP                      1006
#define IDC_BIGLOGG                     1007
#define IDC_CLEARLOG                    1008
#define IDC_SMALLLOGG                   1009
#define IDC_KEYSIZETXT                  1010
#define IDC_LISTPLACEHOLDER             1011
#define IDC_USERLIST                    1012
#define IDC_ADDRESS                     1014
#define IDC_STARTSTOPSERVER             1015
#define IDC_SERVERADRESSTXT             1016
#define IDC_PORTTXT                     1017
#define IDC_PORTNR                      1018
#define IDC_NROFIO                      1019
#define IDC_TXTNROFIOWORKER             1020
#define IDC_MAXCONNECT                  1021
#define IDC_TXTMAXCONNECT               1022
#define IDC_DISCONNECTALL               1023
#define IDC_TEXT                        1024
#define IDC_DISCONNECT                  1025
#define IDC_SENDTXT                     1026
#define IDC_PROGRESS                    1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
