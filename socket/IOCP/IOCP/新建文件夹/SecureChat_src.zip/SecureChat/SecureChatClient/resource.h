//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SecureChatClient.rc
//
#define IDD_SECURECHATCLIENT_DIALOG     102
#define IDD_RANDOM                      103
#define IDR_MAINFRAME                   128
#define IDR_ACCELERATOR1                129
#define IDC_LOGG                        1000
#define IDC_IP                          1001
#define IDC_CONNECT                     1002
#define IDC_NAME                        1003
#define IDC_USESAVEDPUBLICKEY           1006
#define IDC_MESSAGE                     1007
#define IDC_SEND                        1008
#define IDC_PKEYSIZE                    1011
#define IDC_PORT                        1012
#define IDC_CLEARWINDOW                 1013
#define IDC_PROGRESS                    1028
#define ID_SEND_MESSAGE                 32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
