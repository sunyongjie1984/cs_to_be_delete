#include "myLog.h"

myLog winLog;

int main()
{
	winLog<< "this is my log test" << endl;
	return 1;
}