#include <stdio.h>

#include "test_main.h"

int main(void)
{
        printf("Wellcome to C World!\n");
        printf("3 + 4 = %d\n", add_fun(3, 4));
        return 0;
}
