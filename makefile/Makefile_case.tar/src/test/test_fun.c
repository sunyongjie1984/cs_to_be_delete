#include "test_fun.h"

int add_fun(int x, int y)
{
	printf("%s\n", MSG);
	return x + y;
}
