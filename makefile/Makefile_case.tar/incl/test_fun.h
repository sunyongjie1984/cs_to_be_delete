#define MSG "You shold learn makefile first!"
