#include <iostream>
#include "TestClass1.h"


TestClass1::TestClass1()
          : m_int(0)
{
    std::cout<<"TestClass1::TestClass1()"<<std::endl;
}

TestClass1::~TestClass1()
{
    std::cout<<"TestClass1::~TestClass1()"<<std::endl;
}

int TestClass1::GetInt( void )
{
    return static_cast<const TestClass1&>(*this).GetInt();
}

int TestClass1::GetInt( void ) const
{
    return m_int;
}