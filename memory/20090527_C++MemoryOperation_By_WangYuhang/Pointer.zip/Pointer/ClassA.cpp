#include "ClassA.h"

ClassA::ClassA()
{

}

ClassA::~ClassA()
{

}
