#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <new>

#include "TestClass1.h"
#include "TestClass2.h"
#include "TestClass3.h"

#include "ClassA.h"
#include "ClassB.h"
#include "ClassC.h"
#include "ClassD.h"
#include "ClassE.h"
#include "ClassF.h"

int g_INT = 10;

// Global, static and local memory address
void Foo1( void );
// Pointer initialize and size of pointer and array
void Foo2( void );
// constant and pointer, wild pointer
void Foo3( void );
// void*, class size
void Foo4( void );
// Delete twice and delete NULL pointer
void Foo5( void );
// malloc -- delete and new -- free
void Foo6( void );
// new[0], new -- delete[], new[] -- delete
void Foo7( void );
// const array initialize
void Foo8( void );
// Smart pointer can release memory when throw an exception
void Foo9( void );
// std::auto_ptr ownership and usage
void Foo10( void );
void Foo11( std::auto_ptr<TestClass1> aptrTestClass1 );
// Placement new
void Foo12( void );
// Overload new, delete, new[], delete[], placement new and placement delete
void Foo13( void );
// Class size
void Foo14( void );

int main( int, char* )
{
    // Global, static and local memory address
//    Foo1();

    // Pointer initialize and size of pointer and array
//     Foo2();

    // constant and pointer, wild pointer
//     Foo3();

    // void*, class size
//     Foo4();

     // Delete twice and delete NULL pointer
//     Foo5();

     // malloc -- delete and new -- free
//     Foo6();

     // new[0], new -- delete[], new[] -- delete
//     Foo7();

     // const array initialize
//     Foo8();

     // Smart pointer can release memory when throw an exception
//     try
//     {
//         Foo9();
//     }
//    catch (...)
//     {
//        std::cout<<"sss";
//     }
     
    

     // std::auto_ptr ownership and usage
//     Foo10();

     // Placement new
//     Foo12();

     // Overload new, delete, new[], delete[], placement new and placement delete
//     Foo13();

     // Class size
     Foo14();

     getchar();

    return EXIT_SUCCESS;
}

// Global, static and local variable memory address
void Foo1( void )
{
    std::cout<<"----Foo1----"<<std::endl;
    
    // Global variable memory address
    std::cout<<"g_INT address: "<<&g_INT<<std::endl;

    // Static variable memory address
    static int nStaticInt = 6;
    std::cout<<"nStaticInt Address: "<<&nStaticInt<<std::endl;
    
    // Local variable memory address
    int nInt = 5;
    std::cout<<"nInt Address: "<<&nInt<<std::endl;

    // Growth on stack
    int n1 = 0;
    int n2 = 0;
    int n3 = 0;
    int n4 = 0;
    std::cout<<"n1 address: "<<&n1<<std::endl
             <<"n2 address: "<<&n2<<std::endl
             <<"n3 address: "<<&n3<<std::endl
             <<"n4 address: "<<&n4<<std::endl;

    int pn[2] = {0,1};
    int* p1 = NULL;
    p1 = new int;
    // Pointer to a reference
    // It can't be compiled
    //int &* p1;

    // Reference to a pointer
    int* px;
    int*& p2 = px;
}

// Pointer initialize and size of pointer and array
void Foo2( void )
{
    std::cout<<"----Foo2----"<<std::endl;
    
    // Pointer initialize
    int* p1 = NULL;
    std::cout<<"p1: "<<reinterpret_cast<void*>(p1)<<std::endl;
    int* p2;
    std::cout<<"p2: "<<reinterpret_cast<void*>(p2)<<std::endl;
    
    // Difference between pointer and array
    // Size of pointer
    int* pa = new int[10];
    size_t PointerSize = sizeof(pa);
    std::cout<<"PointerSize: "<<PointerSize<<std::endl;
    delete[] pa;
    pa = NULL;
    
    // Size of array
    int intarray[10];
    size_t ArraySize = sizeof(intarray);
    std::cout<<"ArraySize: "<<ArraySize<<std::endl;
}

// constant and pointer, wild pointer
void Foo3( void )
{
    std::cout<<"----Foo3----"<<std::endl;

    // Address of a constant
    char* p1 = NULL;
    std::cout<<"p1 address: "<<&p1<<std::endl;
    std::cout<<"p1: "<<reinterpret_cast<void*>(p1)<<std::endl;
    p1 = "Test1";
    std::cout<<"p1 address: "<<&p1<<std::endl;
    std::cout<<"p1: "<<reinterpret_cast<void*>(p1)<<std::endl;

    // const pointer to char
    char* const p2 = "Test2";
    std::cout<<"p2 address: "<<&p2<<std::endl;
    std::cout<<"p2: "<<reinterpret_cast<void*>(p2)<<std::endl;
    // This can not be compiled. The p2 is a const pointer to char
    //p2 = "Test2a";

    // pointer to const char
    const char* p3 = NULL;
    std::cout<<"p3 address: "<<&p3<<std::endl;
    std::cout<<"p3: "<<reinterpret_cast<const void*>(p3)<<std::endl;
    p3 = "Test3";
    std::cout<<"p3 address: "<<&p3<<std::endl;
    std::cout<<"p3: "<<reinterpret_cast<const void*>(p3)<<std::endl;
    // This can not be compiled. The p3 is a pointer to const char
    //p3[0] = 'a';

    // pointer to const char. char const*  <===>  const char*
    char const * p4 = "Memory";
    std::cout<<"p4: "<<reinterpret_cast<void const *>(p4)<<"  "<<p4<<std::endl;
    // This can not be compiled. The p3 is a pointer to const char
    //p4[1] = 'a';
    // This can be compiled in VC8?
    //delete p4;

    // const pinter to const char
    const char* const p5 = NULL;
    // This can not be compiled. The p5 is a const pointer to (const) char
    //p5 = "Test5";
    // This can not be compiled. The p5 is a (const) pointer to const char
    //p5[1] = 'a';

    int* pInt = NULL;
    delete pInt;
    pInt = new int(10);
    std::cout<<"pInt: "<<pInt<<std::endl;
    std::cout<<"*pInt: "<<*pInt<<std::endl;
    delete pInt;
    // After delete, the pointer may be used still. This is a wild pointer
    std::cout<<"pInt: "<<pInt<<std::endl;
    std::cout<<"*pInt: "<<*pInt<<std::endl;

    // Cannot be compiled in VC6, but can be compiled in VC8
//     const int* pci = new const int(1024);
//     std::cout<<"*pci: "<<*pci<<std::endl;
    // Cannot be compiled, pointer to a const int
//      *pci = 100;
//     delete pci;
//     pci = NULL;
}

// void*, class size
void Foo4( void )
{
    std::cout<<"----Foo4----"<<std::endl;

    // Size of TestClass1, a int member
    size_t sizeTestClass1 = sizeof(TestClass1);
    std::cout<<"TestClass1 size: "<<sizeTestClass1<<std::endl;
    TestClass1* pTestClass1 = NULL;
    // void*, need reinterpret_cast
    //pTestClass1 = malloc(sizeTestClass1);
    pTestClass1 = reinterpret_cast<TestClass1*>(malloc( sizeTestClass1 ));
    void* pv = pTestClass1;
    free( pTestClass1 );
    pTestClass1 = NULL;

    TestClass2 a;
    TestClass2* pTC2 = new TestClass2;

    // Size of TestClass2, no member
    size_t sizeTestClass2 = sizeof(TestClass2);
    std::cout<<"TestClass2 size: "<<sizeTestClass2<<std::endl;
    TestClass2* pTestClass2 = NULL;
    pTestClass2 = reinterpret_cast<TestClass2*>(malloc( sizeTestClass2 ));
    free( pTestClass2 );
    pTestClass2 = NULL;
}

// Delete twice and delete NULL pointer
void Foo5( void )
{
    std::cout<<"----Foo5----"<<std::endl;

    TestClass1* pTestClass1 = NULL;
    pTestClass1 = new TestClass1();
    delete pTestClass1;
    // delete again, crash on Debug mode
    // See C:\Program Files\Microsoft Visual Studio\VC98\CRT\SRC\DBGDEL.CPP
    delete pTestClass1;
    
    pTestClass1 = NULL;
    // delete NULL, that's OK
    // See C:\Program Files\Microsoft Visual Studio\VC98\CRT\SRC\DBGDEL.CPP
    delete pTestClass1;
    delete pTestClass1;
    delete pTestClass1;
}

// malloc -- delete and new -- free
void Foo6( void )
{
    std::cout<<"----Foo6----"<<std::endl;

    // malloc -- delete
    std::cout<<"malloc -- delete"<<std::endl;
    TestClass1* pTestClass1 = NULL;
    pTestClass1 = reinterpret_cast<TestClass1*>(malloc( sizeof(TestClass1)));
    delete pTestClass1;
    pTestClass1 = NULL;

    // new -- free
    std::cout<<"new -- free"<<std::endl;
    pTestClass1 = new TestClass1();
    free( pTestClass1 );
    pTestClass1 = NULL;
}

// new[0], new -- delete[], new[] -- delete
void Foo7( void )
{
    std::cout<<"----Foo7----"<<std::endl;

    // new[0]
    TestClass2* pTestClass2 = NULL;
    // Use 0, the pTestClass2 isn't NULL
    pTestClass2 = new TestClass2[0];
    std::cout<<"pTestClass2: "<<pTestClass2<<std::endl;
    delete[] pTestClass2;
    pTestClass2 = NULL;

    // new -- delete[]
//     pTestClass2 = new TestClass2;
//     std::cout<<"pTestClass2: "<<pTestClass2<<std::endl;
//     delete[] pTestClass2;// Bad
//     pTestClass2 = NULL;

    // new[] -- delete
    pTestClass2 = new TestClass2[3];// Create 3 TestClass2
    std::cout<<"pTestClass2: "<<pTestClass2<<std::endl;
    delete pTestClass2;// Only release 1 TestClass2
    pTestClass2 = NULL;
}

// const array initialize
void Foo8( void )
{
    std::cout<<"----Foo8----"<<std::endl;

    //const must be initialized. It shouldn't be compiled. But it can be compiled in VC8
//     const int* pci = new const int[100];
//     std::cout<<"pci[0]"<<pci[0]<<std::endl;
//     delete[] pci;
//     pci = NULL;

    // There is a default constructor of TestClass2, so it should be compiled.
    // But it can not be compiled in VC6
//     const TestClass2* pcTestClass2 = new const TestClass2[2];
//     delete[] pcTestClass2;
//     pcTestClass2 = NULL;
}

// Smart pointer can release memory when throw an exception
void Foo9( void )
{
    std::cout<<"----Foo9----"<<std::endl;

    // Raw pointer
//     TestClass1* pTestClass1 = NULL;
//     pTestClass1 = new TestClass1;
//     for ( int x = 0; x < 4; x++ )
//     {
//         if ( 2 == x )
//         {
//             // If pTestClass1 isn't delete, memory leak
// //             delete pTestClass1;
// //             pTestClass1 = NULL
//             throw std::exception();
//             return;
//         }
//     }
//     delete pTestClass1;
//     pTestClass1 = NULL;

    // Smart pointer
    std::auto_ptr<TestClass1> autoptrTestClass1( new TestClass1 );
    for ( int x = 0; x < 4; x++ )
    {
        if ( 2 == x )
        {
            throw std::exception();
            return;
        }
    }
}

// std::auto_ptr ownership and usage
void Foo10( void )
{
    std::cout<<"----Foo10----"<<std::endl;

    std::auto_ptr<TestClass1> ptr1( new TestClass1 );
    std::auto_ptr<TestClass1> ptr2;
    if ( NULL == ptr1.get())
    {
        std::cout<<"ptr1 is NULL"<<std::endl;
    }
    if ( NULL == ptr2.get())
    {
        std::cout<<"ptr2 is NULL"<<std::endl;
    }
    // Ownership will be changed after assign
    ptr2 = ptr1;
    if ( NULL == ptr1.get())
    {
        std::cout<<"ptr1 is NULL"<<std::endl;
    }
    if ( NULL == ptr2.get())
    {
        std::cout<<"ptr2 is NULL"<<std::endl;
    }

    std::auto_ptr<TestClass1> aptrTestClass1( new TestClass1 );
    Foo11( aptrTestClass1 );
    if ( NULL == aptrTestClass1.get())
    {
        std::cout<<"aptrTestClass1 is NULL"<<std::endl;
    }
}

void Foo11( std::auto_ptr<TestClass1> aptrTestClass1 )
{
    aptrTestClass1->GetInt();
}

// Placement new
void Foo12( void )
{
    std::cout<<"----Foo12----"<<std::endl;

    const size_t CLASSNUM = 10;
    unsigned char* buf = new unsigned char[sizeof(TestClass1) * CLASSNUM];

    // Placement new doesn't allocate memory
    TestClass1* pTC1 = new(buf) TestClass1;
    // Need call destructor explicitly
    pTC1->~TestClass1();

    // Don't delete pTC1, buf should be delete
    delete[] buf;
    buf = NULL;
}

// Overload new, delete, new[], delete[], placement new and placement delete
void Foo13( void )
{
    std::cout<<"----Foo13----"<<std::endl;

    // TestClass3 size
    size_t sizeTestClass3 = sizeof(TestClass3);
    std::cout<<"TestClass3 size: "<<sizeTestClass3<<std::endl;

    // Overload new and delete
    TestClass3* pTestClass3 = new TestClass3;
    std::cout<<"pTestClass3: "<<reinterpret_cast<TestClass3*>(pTestClass3)<<std::endl;
    delete pTestClass3;
    pTestClass3 = NULL;

    // Overload new[] and delete[]
    pTestClass3 = new TestClass3[3];
    std::cout<<"pTestClass3: "<<reinterpret_cast<TestClass3*>(pTestClass3)<<std::endl;
    delete[] pTestClass3;
    pTestClass3 = NULL;

    // Overload placement new and placement delete
    unsigned char* pBuf = new unsigned char[sizeof(TestClass3)*5];
    pTestClass3 = new(pBuf) TestClass3;
    pTestClass3->~TestClass3();
    pTestClass3 = NULL;
    delete[] pBuf;

    pTestClass3 = new(std::cout) TestClass3;
    delete pTestClass3;
}

// Class size
void Foo14( void )
{
    std::cout<<"----Foo14----"<<std::endl;

    // Size of empty class
    size_t sizeClassA = sizeof(ClassA);
    std::cout<<"ClassA size: "<<sizeClassA<<std::endl;

    // Size of class only a char
    size_t sizeClassB = sizeof(ClassB);
    std::cout<<"ClassB size: "<<sizeClassB<<std::endl;

    // Memory Align
    size_t sizeClassC = sizeof(ClassC);
    std::cout<<"ClassC size: "<<sizeClassC<<std::endl;
    size_t sizeClassD = sizeof(ClassD);
    std::cout<<"ClassD size: "<<sizeClassD<<std::endl;

    // size of a class including virtual
    size_t sizeClassE = sizeof(ClassE);
    std::cout<<"ClassE size: "<<sizeClassE<<std::endl;
    ClassE* pE = new ClassE;

    size_t sizeClassF = sizeof(ClassF);
    std::cout<<"ClassF size: "<<sizeClassF<<std::endl;

}
