#include <iostream>
#include "ClassE.h"

ClassE::ClassE()
{
    std::cout<<"ClassE::ClassE()"<<std::endl;
}

ClassE::~ClassE()
{
    std::cout<<"ClassE::ClassE()"<<std::endl;
}
