#ifndef _CLASSC_H_
#define _CLASSC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ClassC  
{
public:
	ClassC();
	~ClassC();

private:
    char m_char1;
    double m_double;
    char m_char2;

};

#endif // #ifndef _CLASSC_H_
