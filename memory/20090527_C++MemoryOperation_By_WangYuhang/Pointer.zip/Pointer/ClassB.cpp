#include "ClassB.h"

ClassB::ClassB()
      : m_char('a')
{

}

ClassB::~ClassB()
{

}
