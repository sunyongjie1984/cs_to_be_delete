#ifndef _TESTCLASS2_H_
#define _TESTCLASS2_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class TestClass2  
{
public:
	TestClass2();
	~TestClass2();

private:
    TestClass2( const TestClass2& );
    TestClass2& operator =( const TestClass2& );

};

#endif // #ifndef _TESTCLASS2_H_
