#include <iostream>
#include "TestClass2.h"

TestClass2::TestClass2()
{
    std::cout<<"TestClass2::TestClass2()"<<std::endl;
}

TestClass2::~TestClass2()
{
    std::cout<<"TestClass2::~TestClass2()"<<std::endl;
}
