#include <iostream>
#include "ClassE.h"
#include "ClassF.h"

ClassF::ClassF()
      : ClassE(),
        m_char('a')
{
    std::cout<<"ClassF::ClassF()"<<std::endl;
}

ClassF::~ClassF()
{
    std::cout<<"ClassF::~ClassF()"<<std::endl;
}
