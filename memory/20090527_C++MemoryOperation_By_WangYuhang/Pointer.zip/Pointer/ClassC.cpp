#include "ClassC.h"

ClassC::ClassC()
      : m_char1('a'),
        m_double(0.0),
        m_char2('b')
{

}

ClassC::~ClassC()
{

}
