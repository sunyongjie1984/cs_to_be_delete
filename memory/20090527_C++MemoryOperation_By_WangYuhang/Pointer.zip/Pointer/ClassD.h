#ifndef _CLASSD_H_
#define _CLASSD_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ClassD  
{
public:
	ClassD();
	~ClassD();

private:
    char m_char1;
    char m_char2;
    char m_char3;
    char m_char4;
    char m_char5;
    double m_double;

};

#endif // #ifndef _CLASSD_H_
