#include "ClassD.h"

ClassD::ClassD()
      : m_char1('a'),
        m_char2('b'),
        m_char3('c'),
        m_double(0.0)
{

}

ClassD::~ClassD()
{

}
