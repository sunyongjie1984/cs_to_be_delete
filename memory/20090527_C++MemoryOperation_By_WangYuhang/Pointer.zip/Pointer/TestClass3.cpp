#include <stdlib.h>
#include <iostream>
#include <new>
#include <stdexcept>
#include "TestClass3.h"

TestClass3::TestClass3(void)
          : m_int(10)
{
    std::cout<<"TestClass3::TestClass3()"<<std::endl;
}

TestClass3::~TestClass3(void)
{
    std::cout<<"TestClass3::~TestClass3()"<<std::endl;
}

void* TestClass3::operator new( size_t size )
{
    std::cout<<"TestClass3::operator new"<<"   size: "<<size<<std::endl;
    return malloc(size);
}

void TestClass3::operator delete( void* pMemory )
{
    std::cout<<"TestClass3::operator delete"<<"   pMemory: "<<pMemory<<std::endl;
    if ( NULL == pMemory )
    {
        return;
    }
    free( pMemory );
}

void* TestClass3::operator new[]( size_t size )
{
    std::cout<<"TestClass3::operator new[]"<<"   size: "<<size<<std::endl;
    void* p = malloc(size);
    std::cout<<"p: "<<p<<std::endl;
    return p;
}

void TestClass3::operator delete[]( void* pMemory )
{
    std::cout<<"TestClass3::operator delete[]"<<"   pMemory: "<<pMemory<<std::endl;
    if ( NULL == pMemory )
    {
        return;
    }
    free( pMemory );
}

void* TestClass3::operator new( size_t size, void* pBuf )
{
    std::cout<<"TestClass3 placement new"<<"   size: "
             <<"  pBuf: "<<pBuf<<std::endl;

    return ::operator new( size, pBuf );
}

void TestClass3::operator delete( void* pMemory, void* pBuf )
{
    std::cout<<"TestClass3 placement delete"<<"  pMemory: "<<pMemory
             <<"  pBuf: "<<pBuf<<std::endl;

    ::operator delete( pMemory, pBuf );
}

void* TestClass3::operator new( size_t size, std::ostream& stream )
{
    stream<<"TestClass3 placement new(ostream)"<<"  size: "<<size<<std::endl;
    throw std::exception();

    return malloc( size );
}

void TestClass3::operator delete( void* pMemory, std::ostream& stream )
{
    // There isn't a placement delete expression
    // The placement delete will be called, when there is an exception in corresponding placement new
    // If there isn't a corresponding placement delete, the memory leak
    stream<<"TestClass3 placement delete(ostream)"<<"  pMemory: "<<pMemory<<std::endl;

    if ( NULL == pMemory )
    {
        return;
    }

    free( pMemory );
}

// void* TestClass3::operator new[]( size_t size, void* pBuf )
// {
//     std::cout<<"TestClass3 placement new[]"<<"   size: "<<size
//         <<"  pBuf: "<<pBuf<<std::endl;
// 
//     return ::operator new[]( size, pBuf );
// }
// void TestClass3::operator delete[]( void* pMemory, void* pBuf )
// {
//     std::cout<<"TestClass3 placement delete[]"<<"  pMemory: "<<pMemory
//              <<"  pBuf: "<<pBuf<<std::endl;
// 
//     ::operator delete[]( pMemory, pBuf );
// }
