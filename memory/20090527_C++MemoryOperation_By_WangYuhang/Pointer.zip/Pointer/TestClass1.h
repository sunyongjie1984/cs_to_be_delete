#ifndef _TESTCLASS1_H_
#define _TESTCLASS1_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class TestClass1  
{
public:
	TestClass1();
	~TestClass1();
    int GetInt( void );
    int GetInt( void ) const;

private:
    TestClass1( const TestClass1& );
    TestClass1& operator =( const TestClass1& );

private:
    int m_int;

};

#endif // #ifndef _TESTCLASS1_H_
