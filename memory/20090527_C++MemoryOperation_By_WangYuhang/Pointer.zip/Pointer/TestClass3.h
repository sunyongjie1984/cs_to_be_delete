#pragma once

class TestClass3
{
public:
    TestClass3(void);
    ~TestClass3(void);

//private://Forbid use new and delete on this class except ::new and ::delete
    static void* operator new( size_t size );
    static void operator delete( void* pMemory );

    static void* operator new[]( size_t size );
    static void operator delete[]( void* pMemory );

    // placement new and delete
    static void* operator new( size_t size, void* pBuf );
    static void operator delete( void* pMemory, void* pBuf );

    static void* operator new( size_t size, std::ostream& stream );
    static void operator delete( void* pMemory, std::ostream& stream );

private:
    TestClass3( const TestClass3& );
    TestClass3& operator =( const TestClass3& );

private:
    int m_int;
};
