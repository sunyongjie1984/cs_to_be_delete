#ifndef _CLASSF_H_
#define _CLASSF_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ClassF : public ClassE
{
public:
	ClassF();
	~ClassF();

private:
    char m_char;

};

#endif // #ifndef _CLASSF_H_
