#ifndef _CLASSB_H_
#define _CLASSB_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ClassB  
{
public:
	ClassB();
	~ClassB();

private:
    char m_char;

};

#endif // #ifndef _CLASSB_H_
