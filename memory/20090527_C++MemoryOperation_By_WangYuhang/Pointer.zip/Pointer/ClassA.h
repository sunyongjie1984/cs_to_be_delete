#ifndef _CLASSA_H_
#define _CLASSA_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ClassA  
{
public:
	ClassA();
	~ClassA();

};

#endif // #ifndef _CLASSA_H_
