#ifndef _CLASSE_H_
#define _CLASSE_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ClassE  
{
public:
	ClassE();
	virtual ~ClassE();

};

#endif // #ifndef _CLASSE_H_
