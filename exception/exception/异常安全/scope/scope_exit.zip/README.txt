All the files in this archive are in the public domain. Use them as you like.

There are two header files in this archive.
scope_exit.h       : Boost independent version which depends on the standard library only. 
scope_exit_boost.h : Boost dependent version.

If you have no reason to keep away from the Boost, I recommend the Boost dependent one. 

