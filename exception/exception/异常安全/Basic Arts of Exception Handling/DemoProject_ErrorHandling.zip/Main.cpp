#include <iostream.h>
#include "Sample1.h"
#include <exception>


using namespace std;

void function2();
void function1()
{
	try
	{
		function2();
	}
	catch(char* errorDesc)
	{
		throw errorDesc;
	}

}

void function2()
{

	throw "we have got problem inside our second function";

}


void main(void)
{

	//Sample1 Obj;

	try
	{

		//Obj.DoSomeWork();
		function1();
	}
	catch(char* data)
	{
		cout<<data;
	}
	catch(...)
	{
		cout<<"unexpected Error";
	}


}



