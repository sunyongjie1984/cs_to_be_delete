// Sample2.cpp: implementation of the Sample2 class.
//
//////////////////////////////////////////////////////////////////////

#include "Sample2.h"
#include "simple.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Sample2::Sample2()
{

}

Sample2::~Sample2()
{

}

void Sample2::AddMoreData(int dt)
{
	if(dt<1)
		throw "[AddMoreData](Invalid argument given)";

	Function1(5);

}


void Sample2::Function1(int d)
{
	if(d>10)
		throw "problem in function 1";

	Function2(4);
}

void Sample2::Function2(int d)
{
	if(d<5)
		throw "problem in function 2";

	Function3(133);
}

void Sample2::Function3(int d)
{
	if(d>100)
		throw "problem in function 3";
}