// simple.h: interface for the simple class.
//
//////////////////////////////////////////////////////////////////////
#include "ErrorHandler.h"

#if !defined(AFX_SIMPLE_H__DB8D1305_5E39_49A0_B3BA_F929241074A3__INCLUDED_)
#define AFX_SIMPLE_H__DB8D1305_5E39_49A0_B3BA_F929241074A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

static ErrorHandler g_stObj("C:\\myerr.html");

#endif // !defined(AFX_SIMPLE_H__DB8D1305_5E39_49A0_B3BA_F929241074A3__INCLUDED_)
