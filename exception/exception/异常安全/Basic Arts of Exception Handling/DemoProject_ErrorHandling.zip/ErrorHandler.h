// ErrorHandler.h: interface for the ErrorHandler class.
//
//////////////////////////////////////////////////////////////////////

#pragma warning(disable:4786)

#if !defined(AFX_ERRORHANDLER_H__F9820F87_1375_4204_B156_537E8284C5EF__INCLUDED_)
#define AFX_ERRORHANDLER_H__F9820F87_1375_4204_B156_537E8284C5EF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <fstream>
#include<string>


using namespace std;
class ErrorHandler  
{

private:

	ofstream m_OutFile;
	string m_strCurrFunctionName;

public:
	ErrorHandler();
	ErrorHandler(string v_strPath);
	virtual ~ErrorHandler();

	void SetTitle(string v_str);

	void SetCurrentFunction(string v_strFunctionName);

private:
	void OpenLog(string &r_strPath);
	void CloseLog();
	void ShowRuntimeError(string str);
};

#endif // !defined(AFX_ERRORHANDLER_H__F9820F87_1375_4204_B156_537E8284C5EF__INCLUDED_)
