// Sample2.h: interface for the Sample2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SAMPLE2_H__71A1BD9C_5888_46B1_AD89_01D7A5FE4CDE__INCLUDED_)
#define AFX_SAMPLE2_H__71A1BD9C_5888_46B1_AD89_01D7A5FE4CDE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Sample2  
{
	
public:
	Sample2();
	virtual ~Sample2();

	void AddMoreData(int dt);
private:
	void Function3(int);
	void Function1(int);
	void Function2(int);

};

#endif // !defined(AFX_SAMPLE2_H__71A1BD9C_5888_46B1_AD89_01D7A5FE4CDE__INCLUDED_)
