// Sample1.h: interface for the Sample1 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SAMPLE1_H__5947F508_9A0A_4453_A0D7_1AB7DBDC278C__INCLUDED_)
#define AFX_SAMPLE1_H__5947F508_9A0A_4453_A0D7_1AB7DBDC278C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Sample2.h"

class Sample1  
{
public:
	Sample1();
	virtual ~Sample1();
	void DoSomeWork();

};

#endif // !defined(AFX_SAMPLE1_H__5947F508_9A0A_4453_A0D7_1AB7DBDC278C__INCLUDED_)
