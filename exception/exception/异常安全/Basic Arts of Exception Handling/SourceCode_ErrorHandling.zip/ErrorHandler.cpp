// ErrorHandler.cpp: implementation of the ErrorHandler class.
//
//////////////////////////////////////////////////////////////////////

#include "ErrorHandler.h"
#include<windows.h>
#include <iostream>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ErrorHandler::ErrorHandler()
{
	string filepath="C:\\ErrorHandlerReport.html" ;
	OpenLog(filepath);
	SetTitle("ErrorHandlerReport");
}


ErrorHandler::ErrorHandler(string v_strPath)
{
	 OpenLog(v_strPath);
}

ErrorHandler::~ErrorHandler()
{
	 CloseLog();
}


void ErrorHandler::OpenLog(string &r_strPath)
{
	if(!m_OutFile.is_open())
	{
		string str ="</body></html>";
		m_OutFile.write(str.c_str(),str.length());
		m_OutFile.open(r_strPath.c_str());
	}
	else
	{
		ShowRuntimeError("Opening the ErrorLog File has a problem")	;		
	}
}


void ErrorHandler::CloseLog()
{

	if(m_OutFile.is_open())
	{
		m_OutFile.close();
	}

}


void ErrorHandler::SetTitle(string v_str)
{

	string title = "<html><title>"+v_str+"</title><body>";

	if(m_OutFile.is_open())
	{
		m_OutFile.write(title.c_str(),title.length());
	}
	else
	{
		ShowRuntimeError("File is not initialize to SetTitle..");
	}
}


void ErrorHandler::SetCurrentFunction(string v_str)
{
	m_strCurrFunctionName = v_str;

}



void ErrorHandler::ShowRuntimeError(string str)
{

#ifdef _ErrorHandlerWindows

	MessageBox(NULL,str.c_str(),"Error Came inside ErrorHandlerClass",MB_OK)

#else

    cout<<"-------Error Came inside ErrorHandlerClass------"<<endl;
	cout<<str.c_str()<<endl;

#endif

}