
// TestDerived.h

#if !defined(TESTDERIVED_H)
#define TESTDERIVED_H

#include "Callback.h"
#include "Test.h"

// This is a virtually derived class!!
class cTestDerived : virtual cTest
{
public:
	int  SortByAlphabet(char* s8_Word1, char* s8_Word2);
	int  SortByLength  (char* s8_Word1, char* s8_Word2);
};

#endif // !defined(TESTDERIVED_H)
