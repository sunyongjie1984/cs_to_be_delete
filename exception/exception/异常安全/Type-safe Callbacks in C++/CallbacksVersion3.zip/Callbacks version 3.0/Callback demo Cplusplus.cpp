
// Callback demo Cplusplus.cpp:

#include "stdafx.h"
#include "test.h"


int main(int argc, char* argv[])
{
	cTest iTest;
	iTest.StartDemo();

	return 0;
}
