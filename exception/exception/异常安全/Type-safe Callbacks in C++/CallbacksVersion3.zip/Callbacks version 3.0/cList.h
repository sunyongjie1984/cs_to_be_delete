
// cList.h

#if !defined(cList_H)
#define cList_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "Callback.h"
#include <vector>

class cList  
{
public:
	void BubbleSort();
	void Print();
	void Append(char* s8_Word);
	void SetCallback(cCall<int, char*, char*> *p_Call);
	void Swap(int s32_Pos1, int s32_Pos2);

private:
	// creating an uninitialized callback which takes two char* arguments and returns int
	cCall<int, char*, char*> m_Callback;
	std::vector<char*>       m_List;
};

#endif // !defined(cList_H)
