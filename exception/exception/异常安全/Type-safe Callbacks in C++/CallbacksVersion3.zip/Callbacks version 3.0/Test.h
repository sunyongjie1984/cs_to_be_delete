
// Test.h

#if !defined(TEST_H)
#define TEST_H

#include "Callback.h"

// This is an ordinary C++ class
class cTest
{
public:
	void StartDemo();

	       int SortByAlphabet(char* s8_Word1, char* s8_Word2);
	       int SortByLength  (char* s8_Word1, char* s8_Word2);
	static int SortByLastChar(char* s8_Word1, char* s8_Word2);
};

#endif // !defined(TEST_H)
