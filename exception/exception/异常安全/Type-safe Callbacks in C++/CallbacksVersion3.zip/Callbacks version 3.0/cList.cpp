
// cList.cpp

#include "stdafx.h"
#include "cList.h"


// Insert a new String at the end of the list
void cList::Append(char* s8_Word)
{
	if (!s8_Word)
	{
		assert(0);
		return;
	}

	m_List.push_back(s8_Word);
}


// Output content of list in one line on screen
void cList::Print()
{
	for (int i=0; i<(int)m_List.size(); i++)
	{
		printf(m_List.at(i));
		printf(" ");
	}

	printf("\n");
}


/********************************

  The callback functions have to return:
  <0 if Param1 < Param2
   0 if Param1 = Param2
  >0 if Param1 > Param2

/*******************************/


// assign external callback funtion
void cList::SetCallback(cCall<int, char*, char*> *p_Call)
{
	m_Callback = *p_Call;
}


// Sorting the list using the callback function
void cList::BubbleSort()
{
	// Callback has to be set with SetCallback()
	if (!m_Callback.Valid())
	{
		assert(0);
		return;
	}

	int s32_Len = m_List.size();
	if (s32_Len < 2)
		return; // nothing to sort

	int s32_Bot = 0;
	int s32_Top = s32_Len -1;

	while (s32_Top)
	{
		int s32_LastXchange  = 0;
		bool  b_FirstXchange = true;
      
		for (int s32_Pos = s32_Bot; s32_Pos < s32_Top; s32_Pos++)
		{
			// s32_Pos > s32_Pos +1  ?
			// passing two list elements to the callback function to check if they are
			// equal or which one is bigger or smaller
			if (0 < m_Callback.Execute(m_List.at(s32_Pos), m_List.at(s32_Pos+1)))
			{
				Swap(s32_Pos, s32_Pos+1);

				s32_LastXchange = s32_Pos;

				if (b_FirstXchange)
				{
					b_FirstXchange = false;

					s32_Bot = s32_Pos -1;
					if (s32_Bot < 0) s32_Bot = 0;
				}
			}
		}

		s32_Top = s32_LastXchange;
	};
}


// Swap two elements in the list
void cList::Swap(int s32_Pos1, int s32_Pos2)
{
	char *s8_Temp = m_List.at(s32_Pos1);

	m_List.at(s32_Pos1) = m_List.at(s32_Pos2);
	m_List.at(s32_Pos2) = s8_Temp;
}


