
// Test.cpp

#include "stdafx.h"
#include "Test.h"
#include "TestDerived.h"
#include "cList.h"

#pragma warning (disable:4996)

/*************************** Main Test *************************/

void cTest::StartDemo()
{
	printf("\n--> Inserting some words into the list:\n\n");

	// filling the list with words
	cList i_WordList;
	i_WordList.Append("George");
	i_WordList.Append("W.");
	i_WordList.Append("Bush");
	i_WordList.Append("is");
	i_WordList.Append("the");
	i_WordList.Append("biggest");
	i_WordList.Append("bloody");
	i_WordList.Append("terrorist");
	i_WordList.Append("in");
	i_WordList.Append("the");
	i_WordList.Append("world");
	i_WordList.Append("!");
	
	i_WordList.Print();

	// --------------------------------------

	printf("\n\n--> Sorting words alphabetically using a class member callback:\n\n");

	// Generating a callback which takes two char* params and returns integer.
	// The callback function is "SortByAlphabet()" and resides 
	// in the class "cTest" and has the instance pointer "this"
	cCallGen<cTest, int, char*, char*> i_Call_1(this, &cTest::SortByAlphabet);

	// Setting the callback function for further calls from inside BubbleSort()
	i_WordList.SetCallback(&i_Call_1);

	i_WordList.BubbleSort();
	i_WordList.Print();

	// --------------------------------------

	printf("\n\n--> Sorting words by length using a virtual class callback:\n\n");

	// Generating a callback which takes two char* params and returns integer.
	// The callback function is "SortByLength()" and resides 
	// in the virtually derived class "cTestDerived" and has the instance pointer "i_VirtDerived"
	cTestDerived i_VirtDerived;
	cCallGen<cTestDerived, int, char*, char*> i_Call_2(&i_VirtDerived, &cTestDerived::SortByLength);

	// Setting the callback function for further calls from inside BubbleSort()
	i_WordList.SetCallback(&i_Call_2);

	i_WordList.BubbleSort();
	i_WordList.Print();

	// --------------------------------------

	printf("\n\n--> Sorting words by their last character using a static callback:\n\n");

	// Generating a callback which takes two char* params and returns integer.
	// The callback function is "SortByLastChar()" and resides 
	// in the class "cTest" and is static (no instance)
	cCallGenS<int, char*, char*> i_Call_3(&cTest::SortByLastChar);

	// Setting the callback function for further calls from inside BubbleSort()
	i_WordList.SetCallback(&i_Call_3);

	i_WordList.BubbleSort();
	i_WordList.Print();

	// --------------------------------------

	printf("\n\n\nPress any key !");

	getchar();
	exit(0);
}


/********************************

  The callback functions have to return:
  <0 if Param1 < Param2
   0 if Param1 = Param2
  >0 if Param1 > Param2

/*******************************/

// This function is a member of a C++ class
// A callback pointer to this function has 4 Bytes
int cTest::SortByAlphabet(char* s8_Word1, char* s8_Word2)
{
	return stricmp(s8_Word1, s8_Word2);
}

// The demo uses
// cTestDerived::SortByLength()
// instead of
// cTest::SortByLength()
int cTest::SortByLength(char* s8_Word1, char* s8_Word2)
{
	return 0;
}

// This function is static
// A callback pointer to this function has 4 Bytes
int cTest::SortByLastChar(char* s8_Word1, char* s8_Word2)
{
	int Last1 = strlen(s8_Word1) -1;
	int Last2 = strlen(s8_Word2) -1;

	if (s8_Word1[Last1] == s8_Word2[Last2])
		return 0;
	
	return ((unsigned char)s8_Word1[Last1] > (unsigned char)s8_Word2[Last2]) ? 1 : -1;
}

