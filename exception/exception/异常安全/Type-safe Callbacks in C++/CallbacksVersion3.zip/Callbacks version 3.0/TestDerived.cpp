
// Test.cpp

#include "stdafx.h"
#include "TestDerived.h"
#include "cList.h"

#pragma warning (disable:4996)


/********************************

  The callback functions have to return:
  <0 if Param1 < Param2
   0 if Param1 = Param2
  >0 if Param1 > Param2

/*******************************/

// The demo uses
// cTest::SortByAlphabet()
// instead of
// cTestDerived::SortByAlphabet()
int cTestDerived::SortByAlphabet(char* s8_Word1, char* s8_Word2)
{
	return 0;
}

// This function is located in a virtually derived class
// A callback pointer to this function has 12 Bytes instead of 4 Bytes
int cTestDerived::SortByLength(char* s8_Word1, char* s8_Word2)
{
	return strlen(s8_Word1) - strlen(s8_Word2);
}


