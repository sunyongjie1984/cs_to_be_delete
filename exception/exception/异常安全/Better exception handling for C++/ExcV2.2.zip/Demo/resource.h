//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Demo.rc
//
#define IDD_DEMO_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDD_SPEED_DIALOG                129
#define IDC_FRAME_STD                   1000
#define IDC_FRAME_CUST                  1001
#define IDC_THROW_STD                   1002
#define IDC_RADIO4                      1003
#define IDC_THROW_CUST                  1003
#define IDC_TST_SPEED                   1004
#define IDC_TST_DTOR                    1005
#define IDC_PROGRESS                    1005
#define IDC_TST_INLINE                  1006
#define IDC_BUTTON1                     1006
#define IDC_TST_NONCPP                  1007
#define IDC_TST_NONCPP2                 1008
#define IDC_TST_STOPEXC                 1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
