
#ifndef MY_HIERARCHY_H
#define MY_HIERARCHY_H

/**
 * This example code is a supplement to the article 
 * 'RAII, Dynamic Objects, and Factories in C++'
 * at CodeProject: http://www.codeproject.com/
 */

#include "raiifactoryimp.h"


/**
 *  A simple base class
 */
class MyBase {
public:
   MyBase() : mi(0) {}
   MyBase (int i) : mi(i) {}
   virtual ~MyBase() {}   // virtual!!

   void set (int i) { mi = i; }
   int  get () { return mi; }
private:
   int mi;
   // non-copyable
  MyBase (const MyBase&);
  MyBase& operator= (const MyBase&);
};


/**
 *  A simple class derived from MyBase
 */
class MyDerived : public MyBase {
public:
   MyDerived() : mi(0), mf(0.0)      {}
   MyDerived (int i): mi(i), mf(0.0) {}
   virtual ~MyDerived() {}

   void set (int i) { mi = i; }
   int  get () { return mi; }
private:
   int mi;
   float mf;
   // non-copyable
  MyDerived (const MyDerived&);
  MyDerived& operator= (const MyDerived&);
};



/**
 * RAII Factory that creates MyBase objects and objects
 * derived from MyBase (e.g. MyDerived) 
 */
class MyPolymorphicFactory  {
public:
   template <typename T>
	MyBase* create() { return imp.keep (new T); }

   template <typename T>
	MyBase* create (int arg) { return imp.keep (new T (arg)); }
private:
   RaiiFactoryImp<MyBase> imp;
};


#endif
