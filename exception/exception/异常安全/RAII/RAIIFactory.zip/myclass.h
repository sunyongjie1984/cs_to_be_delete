#ifndef MY_CLASS_H
#define MY_CLASS_H

/**
 * This example code is a supplement to the article 
 * 'RAII, Dynamic Objects, and Factories in C++'
 * at CodeProject: http://www.codeproject.com/
 */

#include "raiifactoryimp.h"


/**
 *  A simple test class
 */
class MyClass {
public:
   MyClass()       : mi(0), md (0.0)         {}
   MyClass (int i) : mi(i), md (0.0)         {}
   MyClass (double d)        : mi(0), md (d) {}
   MyClass (const char* s)   : mi(0), md (0.0) {}
   MyClass (int i, double d) : mi(i), md (d) {}

//#if defined (_MSC_VER) && _MSC_VER <= 1200  // MSVC++ 6.0 may require a destructor here even though it is not necessary
   ~MyClass() {}
//#endif

   void set (int i) { mi = i; }
   int  get () { return mi; }

private:
   int    mi;
   double md;
   
   // non-copyable
  MyClass (const MyClass&);
  MyClass& operator= (const MyClass&);
};


/**
 * RAII Factory for MyClass objects
 */
class MyClassFactory {
public:
   // create
   MyClass* create() { return imp.keep (new MyClass);  }
   MyClass* create (int arg)    { return imp.keep (new MyClass (arg)); }
   MyClass* create (double arg) { return imp.keep (new MyClass (arg)); }
   MyClass* create (const char* s) { return imp.keep (new MyClass (s)); }
   MyClass* create (int arg1, double arg2) { return imp.keep (new MyClass (arg1, arg2)); }

   // additional functions
   MyClass*       operator[] (size_t n) { return imp[n]; }
   const MyClass* operator[] (size_t n) const { return imp[n]; }
   size_t size() { return imp.size(); }
   void dispose (const MyClass* p) { imp.dispose (p); }
private:
   RaiiFactoryImp<MyClass> imp;
};


#endif
