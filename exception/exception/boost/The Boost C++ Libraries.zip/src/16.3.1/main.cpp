#include <iostream> 

int main() 
{ 
  int i = 0x10000; 
  short s = i; 
  std::cout << s << std::endl; 
} 