#include <boost/any.hpp> 

int main() 
{ 
  boost::any a = 1; 
  a = 3.14; 
  a = true; 
} 