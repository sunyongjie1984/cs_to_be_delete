//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NewTab.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FORMVIEW_RELATION           101
#define IDD_NEWTAB_DIALOG               102
#define IDD_FORMVIEW_ENTROPY            103
#define IDD_FORMVIEW                    104
#define IDR_MAINFRAME                   128
#define IDB_BITMAP_EMAIL                129
#define IDC_TAB_INFO                    1000
#define IDC_BUTTON_Open                 1001
#define IDC_BUTTON_Decode               1002
#define IDC_STATIC_HISTGRAM             1003
#define IDC_EDIT_INFILE                 1004
#define IDC_EDIT_OUTFILE                1005
#define IDC_RADIO_ENCODE                1007
#define IDC_RADIO_DECODE                1008
#define IDC_BUTTON_DESTFILE             1011
#define IDC_STATIC_SOURCELENGTH         1012
#define IDC_STATIC_ENTROPY              1013
#define IDC_STATIC_CODELENGTH           1014
#define IDC_STATIC_HEAD_LENGTH          1015
#define IDC_STATIC_ACTUAL_LENGTH        1016
#define IDC_STATIC_RATE                 1017
#define IDC_BUTTON_TEST                 1018
#define IDC_BUTTON_EMAIL                1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
