char *szVersionDate="5 PM Saturday, August 02, 2003 GMT Daylight Time";
