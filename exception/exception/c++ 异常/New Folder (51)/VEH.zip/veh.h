
typedef struct _VECTORED_EXCEPTION_NODE {
	LIST_ENTRY ListEntry;
	PVECTORED_EXCEPTION_HANDLER		pfnHandler;	// for security, this pointer has been encoded
} VECTORED_EXCEPTION_NODE, *PVECTORED_EXCEPTION_NODE;

// The following two global variables are initialized by Windows loader
// (In fact, it's LdrpInitializeProcess routine)

// this variable is response to protect insert and delete operation from
// linked list, Windows loader call RtlInitializeCriticalSection to init it
RTL_CRITICAL_SECTION RtlpCalloutEntryLock;

// this variable is the head of the Vectored Exception Handling linked list
// Windows loader call InitializeListHead to init it
// please refer the section "Singly- and Doubly-Linked Lists" in DDK documents
LIST_ENTRY RtlpCalloutEntryList;
