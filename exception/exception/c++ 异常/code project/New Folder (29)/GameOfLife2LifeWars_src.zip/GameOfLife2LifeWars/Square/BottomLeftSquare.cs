using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Square
{
	public class BottomLeftSquare : Square.StandardSquare
	{
		private System.ComponentModel.IContainer components = null;

		public BottomLeftSquare()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		public override string Directions
		{
			get
			{
				return "BOTTOMLEFT";
			}
		}

		public override string SquareType
		{
			get
			{
				return "BOTTOMLEFT";
			}
		}



		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// BottomLeftSquare
			// 
			this.Name = "BottomLeftSquare";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.OnPaint);

		}
		#endregion

		private void OnPaint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics grfx = e.Graphics;

			int nWidth = this.Width/2;
			int nHeight = this.Height/2;


			Rectangle bottomRect = new Rectangle( nWidth/2, this.Height - nHeight/2, nWidth, nHeight/2 );
			Rectangle leftRect = new Rectangle( 0, nHeight/2, nWidth/2, nHeight );
			Rectangle centerRect = new Rectangle( nWidth/2, nHeight/2, nWidth, nHeight );
			

			grfx.FillRectangle( PathBrush, bottomRect );

			grfx.FillRectangle( PathBrush, leftRect );

			grfx.FillRectangle( PathBrush, centerRect );


			if( CritterIsAnt == true )
			{
				if( PathPheromone > 0 )
				{
					double dHeight = this.Height;
					double dMaxPath = MaxPathPheromone;
					double dPath = PathPheromone;

					grfx.DrawLine( PathPheromonePen, 1, ( int )dHeight, 1, ( int )( dHeight - ( ( dHeight / dMaxPath ) * dPath ) ) );
				}

				if( DrawAnt == true )
				{
					Ant.DrawTheAnt( grfx, this.Width, this.Height );
				}
			}		
		}
	}
}

