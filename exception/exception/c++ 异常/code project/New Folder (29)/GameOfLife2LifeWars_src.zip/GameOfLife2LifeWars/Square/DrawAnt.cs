using System;
using System.Drawing;

namespace Square
{
	/// <summary>
	/// Summary description for DrawAnt.
	/// </summary>
	public class DrawAnt
	{
		/// <summary>
		/// the brush for drawing an ant
		/// </summary>
		private SolidBrush antBrush;
		/// <summary>
		/// the pen for drawing an ant
		/// </summary>
		private Pen antPen;
		/// <summary>
		/// the pen for drawing the mouht
		/// </summary>
		private Pen mouthPen;
		/// <summary>
		/// the brush for drawing the eye
		/// </summary>
		private SolidBrush eyeBrush;
		/// <summary>
		/// the color of the ant
		/// </summary>
		private Color cAntColor;
		/// <summary>
		/// the color of the ants eyes
		/// </summary>
		private Color cEyeColor;
		/// <summary>
		/// the color of the ants mouth
		/// </summary>
		private Color cMouthColor;
		/// <summary>
		/// The color of the ants antennae
		/// </summary>
		private Color cAntennaeColor;
		/// <summary>
		/// has the critter found some food
		/// </summary>
		private bool bHasFoundFood;
		/// <summary>
		/// pen for drawing antennae when food is found
		/// </summary>
		private Pen hasFoundFoodPen;
		/// <summary>
		/// change the color of antennae if ants got food
		/// </summary>
		private Color cHasFoundFoodColor;


		public Color AntColor
		{
			get
			{
				return cAntColor;
			}
			set
			{
				cAntColor = value;
			}
		}

	
		public Color EyeColor
		{
			get
			{
				return cEyeColor;
			}
			set
			{
				cEyeColor = value;
			}
		}

		public Color MouthColor
		{
			get
			{
				return cMouthColor;
			}
			set
			{
				cMouthColor = value;
			}
		}

		public Color AntennaeColor
		{
			get
			{
				return cAntennaeColor;
			}
			set
			{
				cAntennaeColor = value;
			}
		}

		public SolidBrush AntBrush
		{
			get
			{
				return antBrush;
			}
		}

		public Pen AntPen
		{
			get
			{
				return antPen;
			}
		}

		public Pen MouthPen
		{
			get
			{
				return mouthPen;
			}
		}

		public SolidBrush EyeBrush
		{
			get
			{
				return eyeBrush;
			}
		}

		public bool HasFoundFood
		{
			get
			{
				return bHasFoundFood;
			}
			set
			{
				bHasFoundFood = value;
			}
		}

		public Pen HasFoundFoodPen
		{
			get
			{
				return hasFoundFoodPen;
			}
		}

		public Color HasFoundFoodColor
		{
			get
			{
				return cHasFoundFoodColor;
			}
			set
			{
				cHasFoundFoodColor = value;
			}
		}

		public DrawAnt()
		{
			//
			// TODO: Add constructor logic here
			//

			EyeColor = Color.Black;
			MouthColor = Color.Black;
			AntColor = Color.DarkRed;
			AntennaeColor = Color.DarkOrange;

			antBrush = new SolidBrush( AntColor );
			antPen = new Pen( AntennaeColor );
			mouthPen = new Pen( MouthColor );
			eyeBrush = new SolidBrush( EyeColor );

			HasFoundFood = false;
			HasFoundFoodColor = Color.Green;
			hasFoundFoodPen = new Pen( HasFoundFoodColor );
		}

		public virtual void DrawTheAnt( Graphics grfx, int width, int height )
		{
			int nWidth = width;
			int nHeight = height;

			antBrush.Color = AntColor;
			antPen.Color = AntennaeColor;
			mouthPen.Color = MouthColor;
			eyeBrush.Color = EyeColor;

			
			Point point1 = new Point( ( nWidth/4 ), nHeight/3 );
			Point point2 = new Point( ( ( nWidth/2 ) + ( nWidth/4 ) ), nHeight/3 );
			Point point3 = new Point( ( ( nWidth/2 ) + ( nWidth/4 ) ), nHeight/2 );
			Point point4 = new Point( ( ( nWidth/2 ) + ( nWidth/8 ) ), ( ( nHeight/2 ) + nHeight/4 ) );
			Point point5 = new Point( ( ( nWidth/2 ) - ( nWidth/8 ) ), ( ( nHeight/2 ) + nHeight/4 ) );
			Point point6 = new Point( ( ( nWidth/2 ) - ( nWidth/4 ) ), nHeight/2 );

			Point[] antPoints = { point1, point2, point3, point4, point5, point6 };

			grfx.FillPolygon( antBrush, antPoints );
			if( HasFoundFood == false )
			{
				grfx.DrawLine( antPen, nWidth/2 - 5, nHeight/3, nWidth/4, nHeight/8 );
				grfx.DrawLine( antPen, nWidth/2 + 5, nHeight/3, nWidth - ( nWidth/4 ), nHeight/8 );
			}
			else
			{
				grfx.DrawLine( HasFoundFoodPen, nWidth/2 - 5, nHeight/3, nWidth/4, nHeight/8 );
				grfx.DrawLine( HasFoundFoodPen, nWidth/2 + 5, nHeight/3, nWidth - ( nWidth/4 ), nHeight/8 );
			}

			Point point7 = new Point( ( ( nWidth/2 ) - ( nWidth/6 ) + 3 ), ( nHeight/2 ) + ( nHeight/6 ) -3 );
			Point point8 = new Point( nWidth/2, ( nHeight/2 ) + ( nHeight/6 ) +3 );
			Point point9 = new Point( ( ( nWidth/2 ) + ( nWidth/6 ) - 3 ), ( nHeight/2 ) + ( nHeight/6 ) -3 );

			Point[] mouthPoints = { point7, point8, point9 };

			grfx.DrawCurve( mouthPen, mouthPoints );

			grfx.FillEllipse( eyeBrush, ( ( nWidth/2 ) - ( nWidth/6 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/12, nHeight/12 );
			grfx.FillEllipse( eyeBrush, ( ( nWidth/2 ) + ( nWidth/10 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/12, nHeight/12 ); 

		}

		public void DrawTheAntOnFoodSquare( Graphics grfx, int width, int height )
		{
			int nWidth = width;
			int nHeight = height;

			AntBrush.Color = AntColor;
			AntPen.Color = AntennaeColor;
			MouthPen.Color = MouthColor;
			EyeBrush.Color = EyeColor;

			
			Point point1 = new Point( ( nWidth/4 ), nHeight/3 );
			Point point2 = new Point( ( ( nWidth/2 ) + ( nWidth/4 ) ), nHeight/3 );
			Point point3 = new Point( ( ( nWidth/2 ) + ( nWidth/4 ) ), nHeight/2 );
			Point point4 = new Point( ( ( nWidth/2 ) + ( nWidth/8 ) ), ( ( nHeight/2 ) + nHeight/4 ) );
			Point point5 = new Point( ( ( nWidth/2 ) - ( nWidth/8 ) ), ( ( nHeight/2 ) + nHeight/4 ) );
			Point point6 = new Point( ( ( nWidth/2 ) - ( nWidth/4 ) ), nHeight/2 );

			Point[] antPoints = { point1, point2, point3, point4, point5, point6 };

			grfx.FillPolygon( AntBrush, antPoints );
			HasFoundFood = true;
			grfx.DrawLine( HasFoundFoodPen, nWidth/2 - 5, nHeight/3, nWidth/4, nHeight/8 );
			grfx.DrawLine( HasFoundFoodPen, nWidth/2 + 5, nHeight/3, nWidth - ( nWidth/4 ), nHeight/8 );

			Point point7 = new Point( ( ( nWidth/2 ) - ( nWidth/6 ) + 3 ), ( nHeight/2 ) + ( nHeight/6 ) -3 );
			Point point8 = new Point( nWidth/2, ( nHeight/2 ) + ( nHeight/6 ) +3 );
			Point point9 = new Point( ( ( nWidth/2 ) + ( nWidth/6 ) - 3 ), ( nHeight/2 ) + ( nHeight/6 ) -3 );

			Point[] mouthPoints = { point7, point8, point9 };

			grfx.DrawCurve( MouthPen, mouthPoints );

			grfx.FillEllipse( EyeBrush, ( ( nWidth/2 ) - ( nWidth/6 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/10, nHeight/10 );
			grfx.FillEllipse( EyeBrush, ( ( nWidth/2 ) + ( nWidth/10 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/10, nHeight/10 ); 

		}
	}
}
