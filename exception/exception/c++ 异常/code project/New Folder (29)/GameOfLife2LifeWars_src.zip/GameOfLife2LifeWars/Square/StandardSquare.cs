using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Square
{
	public enum SQUAREMODES{ NORMAL, LIFEWARS };

	/// <summary>
	/// Summary description for UserControl1.
	/// </summary>
	public class StandardSquare : System.Windows.Forms.UserControl
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// color of the square
		/// </summary>
		private Color backGroundColor;
		/// <summary>
		/// should a border be drawn
		/// </summary>
		private bool bDrawBorder;
		/// <summary>
		/// color of the borders
		/// </summary>
		private Color borderColor;
		/// <summary>
		/// color of the pheromones
		/// </summary>
		private Color cPathPheromoneColor;
		/// <summary>
		/// current amount of pheromones on the path
		/// </summary>
		private int nPathPheromone;
		/// <summary>
		/// maximum amount of ant pheromones allowed 
		/// </summary>
		private int nMaxPathPheromone;
		/// <summary>
		/// should the ant be drawn
		/// </summary>
		private bool bDrawAnt;
		/// <summary>
		/// should the ameoba be drawn
		/// </summary>
		private bool bDrawAmeoba;
		/// <summary>
		/// pen for drawing the borders
		/// </summary>
		private Pen borderPen;
		/// <summary>
		/// brush for drawing the paths
		/// </summary>
		private SolidBrush pathBrush;
		/// <summary>
		/// pen for drawing the pheromone levels
		/// </summary>
		private Pen pathPheromonePen;
		/// <summary>
		/// what color should the paths be ( need code to make sure backgrounds and paths not the same color )
		/// </summary>
		private Color cPathColor;
		/// <summary>
		/// verify that we are drawing an ant
		/// </summary>
		private bool bCritterIsAnt;
		/// <summary>
		/// only drawing one critter per square at the moment so don't constantly redraw the same thing
		/// </summary>
		private bool bCritterIsDrawn;
		/// <summary>
		/// What critter to use see CrittersSet enum in Form1
		/// </summary>
		private int nCritter;
		/// <summary>
		/// is this square a/the home square
		/// </summary>
		private bool bIsHomeSquare;
		/// <summary>
		/// is there already a critter on the square
		/// </summary>
		private bool bIsCritterOnSquare;
		/// <summary>
		/// verify that the critter is an ameoba
		/// </summary>
		private bool bCritterIsAmeoba;
		/// <summary>
		/// ameoba drawing class
		/// </summary>
		private DrawAmeoba ameoba;
		/// <summary>
		/// ant drawing class
		/// </summary>
		private DrawAnt ant;
		/// <summary>
		/// has the critter found some food
		/// </summary>
		private bool bHasFoundFood;
		/// <summary>
		/// What mode are we running in
		/// </summary>
		private SQUAREMODES mode;
		/// <summary>
		/// switch for life wars edit mode
		/// </summary>
		private bool bAllowLifeWarsEdit;


		public Color BackGroundColor
		{
			get
			{
				return backGroundColor;
			}
			set
			{
				backGroundColor = value;
			}
		}

		public bool DrawBorder
		{
			get
			{
				return bDrawBorder;
			}
			set
			{
				bDrawBorder = value;
			}
		}

		public Color BorderColor
		{
			get
			{
				return borderColor;
			}
			set
			{
				borderColor = value;
			}
		}

		public virtual int PathPheromone
		{
			get
			{
				return nPathPheromone;
			}
			set
			{
				nPathPheromone = value;
			}
		}

		public int MaxPathPheromone
		{
			get
			{
				return nMaxPathPheromone;
			}
			set
			{
				nMaxPathPheromone = value;
			}
		}

		public void IncrementPathPheromone()
		{
			if( nPathPheromone < nMaxPathPheromone )
			{
				nPathPheromone++;
			}
		}

		public void DecrementPathPheromone()
		{
			if( nPathPheromone > 0 )
			{
				nPathPheromone--;
			}
		}

		public Color PathPheromoneColor
		{
			get
			{
				return cPathPheromoneColor;
			}
			set
			{
				cPathPheromoneColor = value;
			}
		}

		public virtual string Directions
		{
			get
			{
				return "NONE";
			}
		}

		public virtual string SquareType
		{
			get
			{
				return "STANDARD";
			}
		}

		public bool DrawAnt
		{
			get
			{
				return bDrawAnt;
			}
			set
			{
				bDrawAnt = value;
			}
		}

		public bool DrawAmeoba
		{
			get
			{
				return bDrawAmeoba;
			}
			set
			{
				bDrawAmeoba = value;
			}
		}

		public Pen BorderPen
		{
			get
			{
				return borderPen;
			}
		}

		public SolidBrush PathBrush
		{
			get
			{
				return pathBrush;
			}
		}

		public Pen PathPheromonePen
		{
			get
			{
				return pathPheromonePen;
			}
		}

		public Color PathColor
		{
			get
			{
				return cPathColor;
			}
			set
			{
				cPathColor = value;
			}
		}

		public int Critter
		{
			get
			{
				return nCritter;
			}
			set
			{
				nCritter = value;
			}
		}

		public bool CritterIsAnt
		{
			get
			{
				return bCritterIsAnt;
			}
			set
			{
				bCritterIsAnt = value;
			}
		}

		public bool IsHomeSquare
		{
			get
			{
				return bIsHomeSquare;
			}
			set
			{
				bIsHomeSquare = value;
			}
		}

		public bool IsCritterOnSquare
		{
			get
			{
				return bIsCritterOnSquare;
			}
			set
			{
				bIsCritterOnSquare = value;
			}
		}

		public bool CritterIsAmeoba
		{
			get
			{
				return bCritterIsAmeoba;
			}
			set
			{
				bCritterIsAmeoba = value;
			}
		}

		public DrawAmeoba Ameoba
		{
			get
			{
				return ameoba;
			}
		}

		public DrawAnt Ant
		{
			get
			{
				return ant;
			}
		}

		public bool HasFoundFood
		{
			get
			{
				return bHasFoundFood;
			}
			set
			{
				bHasFoundFood = value;
				Ant.HasFoundFood = value;
			}
		}

		public SQUAREMODES Mode
		{
			get
			{
				return mode;
			}
			set
			{
				mode = value;
			}
		}

		public bool AllowLifeWarsEdit
		{
			get
			{
				return bAllowLifeWarsEdit;
			}
			set
			{
				bAllowLifeWarsEdit = value;
			}
		}
	

		public StandardSquare()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitComponent call
			base.ResizeRedraw = true;
			SetStyle( ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer, true );
			SetStyle( ControlStyles.SupportsTransparentBackColor, true );
			SetStyle( ControlStyles.Selectable, true );

			ameoba = new DrawAmeoba();
			ant = new DrawAnt();

			DrawBorder = true;
			BackGroundColor = Color.Sienna;
			BorderColor = Color.Black;
			borderPen = new Pen( BorderColor );
			MaxPathPheromone = 100;
			PathPheromone = 0;
			PathPheromoneColor = Color.Red;
			bDrawAnt = false; /// always false here

			PathColor = Color.DarkGray;
			pathBrush = new SolidBrush( PathColor );
			pathPheromonePen = new Pen( PathPheromoneColor );


			HasFoundFood = false;

			bCritterIsAnt = false;
			bIsHomeSquare = false;
			bIsCritterOnSquare = false;

			mode = SQUAREMODES.NORMAL;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if( components != null )
					components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// StandardSquare
			// 
			this.Name = "StandardSquare";
			this.Size = new System.Drawing.Size(80, 80);
			this.Click += new System.EventHandler(this.OnSquareClick);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.OnPaint);

		}
		#endregion

		private void OnPaint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics grfx = e.Graphics;
			borderPen.Color = BorderColor;

			this.BackColor = BackGroundColor;
			
			if( bDrawBorder == true )
			{
				grfx.DrawRectangle( borderPen, 0, 0, this.Width -1, this.Height -1 );
			}

			/// test code should never be true here
		
			if( bCritterIsAnt == true )
			{
				if( PathPheromone > 0 )
				{
					double dHeight = this.Height;
					double dMaxPath = MaxPathPheromone;
					double dPath = PathPheromone;

					grfx.DrawLine( PathPheromonePen, 1, ( int )dHeight, 1, ( int )( dHeight - ( ( dHeight / dMaxPath ) * dPath ) ) );
				}

				if( bDrawAnt == true )
				{
					Ant.DrawTheAnt( grfx, this.Width, this.Height );
				}
			}
			else if( bCritterIsAmeoba == true )
			{
				if( DrawAmeoba == true )
				{
					ameoba.DrawTheAmeoba( grfx, this.Width, this.Height );
				}
			}
			else
			{
			}
		}

		private void OnSquareClick(object sender, System.EventArgs e)
		{

			if( mode == SQUAREMODES.LIFEWARS )
			{
				if( AllowLifeWarsEdit == true )
				{
					DrawAmeoba = true;
					IsCritterOnSquare = true;
					this.Invalidate();
				}
			}
		}



	}
}
