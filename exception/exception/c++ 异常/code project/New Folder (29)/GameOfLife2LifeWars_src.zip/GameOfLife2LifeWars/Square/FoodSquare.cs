using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Square
{
	public class FoodSquare : Square.StandardSquare
	{
		private System.ComponentModel.IContainer components = null;
		private Color cFoodColor;


		public Color FoodColor
		{
			get
			{
				return cFoodColor;
			}
			set
			{
				cFoodColor = value;
			}
		}

		public override string Directions
		{
			get
			{
				return "ALL";
			}
		}

		public override string SquareType
		{
			get
			{
				return "FOOD";
			}
		}



		public FoodSquare()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
			cFoodColor = Color.Green;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// FoodSquare
			// 
			this.Name = "FoodSquare";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.OnPaint);

		}
		#endregion

		private void OnPaint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics grfx = e.Graphics;

			int nWidth = this.Width/2;
			int nHeight = this.Height/2;

			Rectangle bottomRect = new Rectangle( nWidth/2, this.Height - nHeight/2, nWidth, nHeight/2 );
			Rectangle rightRect = new Rectangle( this.Width - nWidth/2, nHeight/2, nWidth/2, nHeight );
			Rectangle centerRect = new Rectangle( nWidth/2, nHeight/2, nWidth, nHeight );
			Rectangle topRect = new Rectangle( nWidth/2, 0, nWidth, nHeight/2 );
			Rectangle leftRect = new Rectangle( 0, nHeight/2, nWidth/2, nHeight );

			SolidBrush foodBrush = new SolidBrush( FoodColor );

			grfx.FillRectangle( PathBrush, bottomRect );

			grfx.FillRectangle( PathBrush, rightRect );

			grfx.FillRectangle( PathBrush, centerRect );

			grfx.FillRectangle( PathBrush, topRect );

			grfx.FillRectangle( PathBrush, leftRect );

			grfx.FillEllipse( foodBrush, centerRect );

			if( CritterIsAnt == true )
			{
				if( PathPheromone > 0 )
				{
					double dHeight = this.Height;
					double dMaxPath = MaxPathPheromone;
					double dPath = PathPheromone;

					grfx.DrawLine( PathPheromonePen, 1, ( int )dHeight, 1, ( int )( dHeight - ( ( dHeight / dMaxPath ) * dPath ) ) );
				}

				if( DrawAnt == true )
				{
					Ant.DrawTheAntOnFoodSquare( grfx, this.Width, this.Height );
				}
			}		
		}

		

	}
}

