using System;
using System.Drawing;

namespace Square
{
	/// <summary>
	/// Summary description for DrawAmeoba.
	/// </summary>
	public class DrawAmeoba
	{
		/// <summary>
		/// brush for drawing the ameoba
		/// </summary>
		private SolidBrush ameobaBrush;
		/// <summary>
		/// pen for drawing the ameoba
		/// </summary>
		private Pen ameobaPen;
		/// <summary>
		/// pen for drawing the ameoba's mouth
		/// </summary>
		private Pen ameobaMouthPen;
		/// <summary>
		/// Brush for drawing the ameoba eye
		/// </summary>
		private SolidBrush ameobaEyeBrush;
		/// <summary>
		/// color of the ameoba
		/// </summary>
		private Color cAmeobaColor;
		/// <summary>
		/// color of the ameoba's eyes
		/// </summary>
		private Color cAmeobaEyeColor;
		/// <summary>
		/// color of the ameoba's mouth
		/// </summary>
		private Color cAmeobaMouthColor;
		/// <summary>
		/// what direction are the eyes looking in
		/// </summary>
		private int nAmeobaEyeDirection;
		/// <summary>
		/// color of the ameoba's pupils
		/// </summary>
		private Color cAmeobaPupilColor;
		/// <summary>
		/// brush for drwaing ameoba pupils
		/// </summary>
		private SolidBrush ameobaPupilBrush;


		public Color AmeobaColor
		{
			get
			{	
				return cAmeobaColor;
			}
			set
			{
				cAmeobaColor = value;
			}
		}

		public Color AmeobaEyeColor
		{
			get
			{
				return cAmeobaEyeColor;
			}
			set
			{
				cAmeobaEyeColor = value;
			}
		}

		public Color AmeobaMouthColor
		{
			get
			{
				return cAmeobaMouthColor;
			}
			set
			{
				cAmeobaMouthColor = value;
			}
		}

		public SolidBrush AmeobaBrush
		{
			get
			{
				return ameobaBrush;
			}
		}

		public Pen AmeobaMouthPen
		{
			get
			{
				return ameobaMouthPen;
			}
		}

		public SolidBrush AmeobaEyeBrush
		{
			get
			{
				return ameobaEyeBrush;
			}
		}

		public Pen AmeobaPen
		{
			get
			{
				return ameobaPen;
			}
		}


		public DrawAmeoba()
		{
			//
			// TODO: Add constructor logic here
			//

			AmeobaColor = Color.DarkOrchid;
			AmeobaMouthColor = Color.Black;
			AmeobaEyeColor = Color.Orchid;

			ameobaBrush = new SolidBrush( AmeobaColor );
			ameobaPen = new Pen( AmeobaColor );
			ameobaMouthPen = new Pen( AmeobaMouthColor );
			ameobaEyeBrush = new SolidBrush( AmeobaEyeColor );
			nAmeobaEyeDirection = 0;
			cAmeobaPupilColor = Color.Black;
			ameobaPupilBrush = new SolidBrush( cAmeobaPupilColor );
		}

		public void DrawTheAmeoba( Graphics grfx, int width, int height )
		{
			int nWidth = width;
			int nHeight = height;
			

			ameobaBrush.Color = AmeobaColor;
			ameobaPen.Color = AmeobaColor;
			ameobaMouthPen.Color = AmeobaMouthColor;
			cAmeobaEyeColor = AmeobaEyeColor;

			Point point1 = new Point( ( nWidth/5 ), ( nHeight/8 ) );
			Point point2 = new Point( ( nWidth/2 ), ( nHeight/4 ) );
			Point point3 = new Point( ( nWidth - ( nWidth/10 ) ), ( nHeight/7 ) );
			Point point4 = new Point( ( nWidth - ( nWidth/12 ) ), ( nHeight/2 ) );
			Point point5 = new Point( ( nWidth - ( nWidth/8 ) ), ( nHeight - ( nHeight/3 ) ) );
			Point point6 = new Point( ( nWidth - ( nWidth/9 ) ), ( nHeight - ( nHeight/5 ) ) );
			Point point7 = new Point( ( nWidth - ( nWidth/8 ) ), ( nHeight - ( nHeight/10 ) ) );
			Point point8 = new Point( ( nWidth - ( nWidth/6 ) ), ( nHeight - ( nHeight/9 ) ) );
			Point point9 = new Point( ( nWidth - ( nWidth/4 ) ), ( nHeight - ( nHeight/14 ) ) );
			Point point10 = new Point( ( nWidth - ( nWidth/3 ) ), ( nHeight - ( nHeight/16 ) ) );
			Point point11 = new Point( ( nWidth/2 ), ( nHeight - ( nHeight/12 ) ) );
			Point point12 = new Point( ( nWidth/4 ), ( nHeight - ( nHeight/10 ) ) );
			Point point13 = new Point( ( nWidth/7 ), ( nHeight - ( nHeight/8 ) ) );
			Point point14 = new Point( ( nWidth/10 ), ( nHeight - ( nHeight/4 ) ) );
			Point point15 = new Point( ( nWidth/18 ), ( nHeight/2 ) );
			Point point16 = new Point( ( nWidth/14 ), ( nHeight/3 ) );

			Point[] ameobaPoints = { point1, point2, point3, point4, point5, point6, point7, point8, point9, point10,
									   point11, point12, point13, point14, point15, point16 };

			grfx.FillPolygon( ameobaBrush, ameobaPoints );

			Point point17 = new Point( ( ( nWidth/2 ) - ( nWidth/6 ) + 3 ), ( nHeight/2 ) + ( nHeight/6 ) -3 );
			Point point18 = new Point( nWidth/2, ( nHeight/2 ) + ( nHeight/6 ) +3 );
			Point point19 = new Point( ( ( nWidth/2 ) + ( nWidth/6 ) - 3 ), ( nHeight/2 ) + ( nHeight/6 ) -3 );

			Point[] mouthPoints = { point17, point18, point19 };

			grfx.DrawCurve( ameobaMouthPen, mouthPoints );

			grfx.FillEllipse( ameobaEyeBrush, ( ( nWidth/2 ) - ( nWidth/6 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/8, nHeight/6 );
			grfx.FillEllipse( ameobaEyeBrush, ( ( nWidth/2 ) + ( nWidth/10 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/8, nHeight/6 ); 
			
			Random rand = new Random();
			nAmeobaEyeDirection = rand.Next( 20 );
			switch( nAmeobaEyeDirection )
			{
					/// upper left
				case 0:
				{
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) - ( nWidth/6 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/16, nHeight/16 );
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) + ( nWidth/10 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/16, nHeight/16 ); 
				}break;
				case 1: /// up
				{
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) - ( nWidth/8 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/16, nHeight/16 );
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) + ( nWidth/8 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/16, nHeight/16 );
				}break;
				case 2: /// upper right
				{
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) - ( nWidth/10 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/16, nHeight/16 );
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) + ( nWidth/6 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/16, nHeight/16 );
				}break;
				case 3: /// right
				{
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) - ( nWidth/10 ) ), ( ( nHeight/2 ) - nHeight/14 ), nWidth/16, nHeight/16 );
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) + ( nWidth/6 ) ), ( ( nHeight/2 ) - nHeight/14 ), nWidth/16, nHeight/16 );
				}break;
				case 4: /// lower right
				{
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) - ( nWidth/10 ) ), ( nHeight/2 ), nWidth/16, nHeight/16 );
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) + ( nWidth/6 ) ), ( nHeight/2 ), nWidth/16, nHeight/16 );
				}break;
				case 5: /// down
				{
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) - ( nWidth/8 ) ), ( nHeight/2 ), nWidth/16, nHeight/16 );
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) + ( nWidth/8 ) ), ( nHeight/2 ), nWidth/16, nHeight/16 );
				}break;
				case 6: /// lower left
				{
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) - ( nWidth/6 ) ), ( nHeight/2 ), nWidth/16, nHeight/16 );
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) + ( nWidth/10 ) ), ( nHeight/2 ), nWidth/16, nHeight/16 );
				}break;
				case 7: /// left
				{
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) - ( nWidth/6 ) ), ( ( nHeight/2 ) - nHeight/14 ), nWidth/16, nHeight/16 );
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) + ( nWidth/10 ) ), ( ( nHeight/2 ) - nHeight/14 ), nWidth/16, nHeight/16 );
				}break;
				case 8:
				{
					grfx.FillEllipse( ameobaBrush, ( ( nWidth/2 ) - ( nWidth/6 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/8, nHeight/6 );
					grfx.FillEllipse( ameobaBrush, ( ( nWidth/2 ) + ( nWidth/10 ) ), ( ( nHeight/2 ) - nHeight/10 ), nWidth/8, nHeight/6 ); 

					Point point20 = new Point( ( ( nWidth/2 ) - ( nWidth/6 ) ), ( nHeight/2 ) + nHeight/20 );
					Point point21 = new Point( ( ( nWidth/2 ) - ( nWidth/8 ) ), ( ( nHeight/2 ) + nHeight/16 ) );
					Point point22 = new Point( ( nWidth/2 ) - nWidth/10, ( nHeight/2 ) + nHeight/20 );

					Point[] leftEyeLashPoints = { point20, point21, point22 };

					grfx.DrawCurve( ameobaMouthPen, leftEyeLashPoints );

					Point point23 = new Point( ( ( nWidth/2 ) + ( nWidth/10 ) ), ( nHeight/2 ) + nHeight/20 );
					Point point24 = new Point( ( ( nWidth/2 ) + ( nWidth/8 ) ), ( ( nHeight/2 ) + nHeight/16 ) );
					Point point25 = new Point( ( ( nWidth/2 ) + ( nWidth/6 ) ), ( nHeight/2 ) + nHeight/20 );

					Point[] rightEyeLashPoints = { point23, point24, point25 };

					grfx.DrawCurve( ameobaMouthPen, rightEyeLashPoints );

				}break;
				default:
				{
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) - ( nWidth/8 ) ), ( ( nHeight/2 ) - nHeight/14 ), nWidth/16, nHeight/16 );
					grfx.FillEllipse( ameobaPupilBrush, ( ( nWidth/2 ) + ( nWidth/8 ) ), ( ( nHeight/2 ) - nHeight/14 ), nWidth/16, nHeight/16 );
				}break;

			}

		}

	}
}
