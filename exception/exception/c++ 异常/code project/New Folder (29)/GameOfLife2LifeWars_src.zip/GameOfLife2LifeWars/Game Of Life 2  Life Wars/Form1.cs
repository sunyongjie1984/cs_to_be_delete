using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Square;

namespace Game_Of_Life_2__Life_Wars
{
	public enum MODES{ GAME_OF_LIFE, LIFE_WARS };

	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{

		private ArrayList arraySquares;
		private const int nSquareCountH = 25;
		private const int nSquareCountV = 25;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.CheckBox bordersCheckBox;
		private System.Windows.Forms.TabPage mainOptionsPage;
		private System.Windows.Forms.GroupBox Modes;
		private System.Windows.Forms.CheckBox lifeWarsCheckBox;
		private System.Windows.Forms.CheckBox gameOfLifeCheckBox;
		private MODES mode;
		private System.Windows.Forms.Label displayLabel;
		private System.Windows.Forms.Button startButton;
		private System.Windows.Forms.TabPage gameOfLifePage;
		private System.Windows.Forms.TabPage lifeWarsPage;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.NumericUpDown golStartingNumberUpDown;
		private System.Windows.Forms.CheckBox golRandomPlacementBox;
		private System.Windows.Forms.Timer gameTimer;
		private System.Windows.Forms.Button pauseButton;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.Button clearButton;
		private System.Windows.Forms.NumericUpDown createNewUpDown;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.CheckBox createNewBox;
		private System.Windows.Forms.NumericUpDown minimumStayAliveUpDown;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.NumericUpDown maximumStayAliveUpDown;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.CheckBox maximumBox;
		private System.Windows.Forms.NumericUpDown startingLifeFormsPerSideUpDown;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.CheckBox lwRandomPlacementBox;
		private bool bPaused;
		Color computerColor;
		private System.Windows.Forms.Timer lifeWarsEditTimer;
		Color playerColor;
		private bool bLifeWarsEdited;

		private class Data
		{
			private StandardSquare square;
			private bool bIsNewSquare;
			private bool bIsDeadSquare;
			private bool bDeleteAmeoba;
			private Color cCritterColor;

			public Data()
			{
				square = new StandardSquare();
				bIsNewSquare = false;
				bIsDeadSquare = false;
				bDeleteAmeoba = false;
				cCritterColor = Color.DarkGoldenrod;
			}

			public StandardSquare Square
			{
				get
				{
					return square;
				}
				set
				{
					square = value;
				}
			}

			public bool IsNewSquare
			{
				get
				{
					return bIsNewSquare;
				}
				set
				{
					bIsNewSquare = value;
				}
			}

			public bool IsDeadSquare
			{
				get
				{
					return bIsDeadSquare;
				}
				set
				{
					bIsDeadSquare = value;
				}
			}

			public bool DeleteAmeoba
			{
				get
				{
					return bDeleteAmeoba;
				}
				set
				{
					bDeleteAmeoba = value;
				}
			}

			public Color CritterColor
			{
				get
				{
					return cCritterColor;
				}
				set
				{
					cCritterColor = value;
				}
			}
		}

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			mode = MODES.GAME_OF_LIFE;

			arraySquares = new ArrayList();

			int nStartPositionH = 20;
			int nStartPositionV = 0;
			int nSquareWidth = 20;
			int nSquareHeight = 20;
			for( int i=0; i<nSquareCountH; i++ )
			{
				for( int j=0; j<nSquareCountV; j++ )
				{
					Data tempData = new Data();
					tempData.Square.Size = new Size( nSquareWidth, nSquareHeight );
					tempData.Square.BackGroundColor = Color.Blue;
					tempData.Square.DrawAnt = false;
					tempData.Square.DrawBorder = true;
					tempData.Square.IsCritterOnSquare = false;
					tempData.Square.IsHomeSquare = false;
					tempData.Square.CritterIsAmeoba = true;
					tempData.Square.Mode = Square.SQUAREMODES.LIFEWARS;

					tempData.Square.Location = new Point( ( nStartPositionH + ( nSquareWidth * i ) ), ( nStartPositionV + ( nSquareHeight * j ) ) );
 
					arraySquares.Add( tempData ); 
					this.Controls.Add( tempData.Square );
				}
			}

			pauseButton.Enabled = true;
			bPaused = false;
			clearButton.Enabled = false;

			computerColor = Color.DarkSalmon;
			playerColor = Color.AntiqueWhite;
			bLifeWarsEdited = false;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.mainOptionsPage = new System.Windows.Forms.TabPage();
			this.clearButton = new System.Windows.Forms.Button();
			this.pauseButton = new System.Windows.Forms.Button();
			this.startButton = new System.Windows.Forms.Button();
			this.Modes = new System.Windows.Forms.GroupBox();
			this.lifeWarsCheckBox = new System.Windows.Forms.CheckBox();
			this.gameOfLifeCheckBox = new System.Windows.Forms.CheckBox();
			this.bordersCheckBox = new System.Windows.Forms.CheckBox();
			this.gameOfLifePage = new System.Windows.Forms.TabPage();
			this.maximumBox = new System.Windows.Forms.CheckBox();
			this.label5 = new System.Windows.Forms.Label();
			this.maximumStayAliveUpDown = new System.Windows.Forms.NumericUpDown();
			this.label4 = new System.Windows.Forms.Label();
			this.minimumStayAliveUpDown = new System.Windows.Forms.NumericUpDown();
			this.createNewBox = new System.Windows.Forms.CheckBox();
			this.label2 = new System.Windows.Forms.Label();
			this.createNewUpDown = new System.Windows.Forms.NumericUpDown();
			this.golRandomPlacementBox = new System.Windows.Forms.CheckBox();
			this.golStartingNumberUpDown = new System.Windows.Forms.NumericUpDown();
			this.label1 = new System.Windows.Forms.Label();
			this.lifeWarsPage = new System.Windows.Forms.TabPage();
			this.lwRandomPlacementBox = new System.Windows.Forms.CheckBox();
			this.label3 = new System.Windows.Forms.Label();
			this.startingLifeFormsPerSideUpDown = new System.Windows.Forms.NumericUpDown();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.displayLabel = new System.Windows.Forms.Label();
			this.gameTimer = new System.Windows.Forms.Timer(this.components);
			this.lifeWarsEditTimer = new System.Windows.Forms.Timer(this.components);
			this.tabControl1.SuspendLayout();
			this.mainOptionsPage.SuspendLayout();
			this.Modes.SuspendLayout();
			this.gameOfLifePage.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.maximumStayAliveUpDown)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.minimumStayAliveUpDown)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.createNewUpDown)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.golStartingNumberUpDown)).BeginInit();
			this.lifeWarsPage.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.startingLifeFormsPerSideUpDown)).BeginInit();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl1.Controls.Add(this.mainOptionsPage);
			this.tabControl1.Controls.Add(this.gameOfLifePage);
			this.tabControl1.Controls.Add(this.lifeWarsPage);
			this.tabControl1.Location = new System.Drawing.Point(0, 540);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(540, 190);
			this.tabControl1.TabIndex = 0;
			// 
			// mainOptionsPage
			// 
			this.mainOptionsPage.Controls.Add(this.clearButton);
			this.mainOptionsPage.Controls.Add(this.pauseButton);
			this.mainOptionsPage.Controls.Add(this.startButton);
			this.mainOptionsPage.Controls.Add(this.Modes);
			this.mainOptionsPage.Controls.Add(this.bordersCheckBox);
			this.mainOptionsPage.Location = new System.Drawing.Point(4, 22);
			this.mainOptionsPage.Name = "mainOptionsPage";
			this.mainOptionsPage.Size = new System.Drawing.Size(532, 164);
			this.mainOptionsPage.TabIndex = 0;
			this.mainOptionsPage.Text = "Main Options";
			// 
			// clearButton
			// 
			this.clearButton.Location = new System.Drawing.Point(424, 128);
			this.clearButton.Name = "clearButton";
			this.clearButton.TabIndex = 4;
			this.clearButton.Text = "Clear";
			this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
			// 
			// pauseButton
			// 
			this.pauseButton.Location = new System.Drawing.Point(424, 96);
			this.pauseButton.Name = "pauseButton";
			this.pauseButton.TabIndex = 3;
			this.pauseButton.Text = "Pause";
			this.pauseButton.Click += new System.EventHandler(this.pauseButton_Click);
			// 
			// startButton
			// 
			this.startButton.Location = new System.Drawing.Point(424, 56);
			this.startButton.Name = "startButton";
			this.startButton.TabIndex = 2;
			this.startButton.Text = "Start";
			this.startButton.Click += new System.EventHandler(this.OnStartButton);
			// 
			// Modes
			// 
			this.Modes.Controls.Add(this.lifeWarsCheckBox);
			this.Modes.Controls.Add(this.gameOfLifeCheckBox);
			this.Modes.Location = new System.Drawing.Point(8, 8);
			this.Modes.Name = "Modes";
			this.Modes.Size = new System.Drawing.Size(200, 152);
			this.Modes.TabIndex = 1;
			this.Modes.TabStop = false;
			this.Modes.Text = "Modes";
			// 
			// lifeWarsCheckBox
			// 
			this.lifeWarsCheckBox.AutoCheck = false;
			this.lifeWarsCheckBox.Location = new System.Drawing.Point(16, 64);
			this.lifeWarsCheckBox.Name = "lifeWarsCheckBox";
			this.lifeWarsCheckBox.Size = new System.Drawing.Size(128, 16);
			this.lifeWarsCheckBox.TabIndex = 3;
			this.lifeWarsCheckBox.Text = "Life Wars";
			this.lifeWarsCheckBox.Click += new System.EventHandler(this.OnLifeWarsClick);
			// 
			// gameOfLifeCheckBox
			// 
			this.gameOfLifeCheckBox.AutoCheck = false;
			this.gameOfLifeCheckBox.Checked = true;
			this.gameOfLifeCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.gameOfLifeCheckBox.Location = new System.Drawing.Point(16, 32);
			this.gameOfLifeCheckBox.Name = "gameOfLifeCheckBox";
			this.gameOfLifeCheckBox.Size = new System.Drawing.Size(128, 16);
			this.gameOfLifeCheckBox.TabIndex = 2;
			this.gameOfLifeCheckBox.Text = "Game Of Life ";
			this.gameOfLifeCheckBox.Click += new System.EventHandler(this.OnGameOfLifeClick);
			// 
			// bordersCheckBox
			// 
			this.bordersCheckBox.Checked = true;
			this.bordersCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.bordersCheckBox.Location = new System.Drawing.Point(424, 16);
			this.bordersCheckBox.Name = "bordersCheckBox";
			this.bordersCheckBox.TabIndex = 0;
			this.bordersCheckBox.Text = "Draw Borders";
			this.bordersCheckBox.CheckedChanged += new System.EventHandler(this.bordersCheckBox_CheckedChanged);
			// 
			// gameOfLifePage
			// 
			this.gameOfLifePage.Controls.Add(this.maximumBox);
			this.gameOfLifePage.Controls.Add(this.label5);
			this.gameOfLifePage.Controls.Add(this.maximumStayAliveUpDown);
			this.gameOfLifePage.Controls.Add(this.label4);
			this.gameOfLifePage.Controls.Add(this.minimumStayAliveUpDown);
			this.gameOfLifePage.Controls.Add(this.createNewBox);
			this.gameOfLifePage.Controls.Add(this.label2);
			this.gameOfLifePage.Controls.Add(this.createNewUpDown);
			this.gameOfLifePage.Controls.Add(this.golRandomPlacementBox);
			this.gameOfLifePage.Controls.Add(this.golStartingNumberUpDown);
			this.gameOfLifePage.Controls.Add(this.label1);
			this.gameOfLifePage.Location = new System.Drawing.Point(4, 22);
			this.gameOfLifePage.Name = "gameOfLifePage";
			this.gameOfLifePage.Size = new System.Drawing.Size(532, 164);
			this.gameOfLifePage.TabIndex = 1;
			this.gameOfLifePage.Text = "Game Of Life Options";
			// 
			// maximumBox
			// 
			this.maximumBox.Checked = true;
			this.maximumBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.maximumBox.Location = new System.Drawing.Point(368, 104);
			this.maximumBox.Name = "maximumBox";
			this.maximumBox.Size = new System.Drawing.Size(144, 24);
			this.maximumBox.TabIndex = 12;
			this.maximumBox.Text = "Use Greater Than";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(72, 104);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(288, 23);
			this.label5.TabIndex = 11;
			this.label5.Text = "Maximum Number Of Neighbours Needed Before Death";
			// 
			// maximumStayAliveUpDown
			// 
			this.maximumStayAliveUpDown.Location = new System.Drawing.Point(8, 104);
			this.maximumStayAliveUpDown.Name = "maximumStayAliveUpDown";
			this.maximumStayAliveUpDown.Size = new System.Drawing.Size(56, 20);
			this.maximumStayAliveUpDown.TabIndex = 10;
			this.maximumStayAliveUpDown.Value = new System.Decimal(new int[] {
																				 3,
																				 0,
																				 0,
																				 0});
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(72, 72);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(288, 23);
			this.label4.TabIndex = 9;
			this.label4.Text = "Minimum Number Of Neighbours Needed To Stay Alive";
			// 
			// minimumStayAliveUpDown
			// 
			this.minimumStayAliveUpDown.Location = new System.Drawing.Point(8, 72);
			this.minimumStayAliveUpDown.Name = "minimumStayAliveUpDown";
			this.minimumStayAliveUpDown.Size = new System.Drawing.Size(56, 20);
			this.minimumStayAliveUpDown.TabIndex = 8;
			this.minimumStayAliveUpDown.Value = new System.Decimal(new int[] {
																				 2,
																				 0,
																				 0,
																				 0});
			// 
			// createNewBox
			// 
			this.createNewBox.Checked = true;
			this.createNewBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.createNewBox.Location = new System.Drawing.Point(352, 40);
			this.createNewBox.Name = "createNewBox";
			this.createNewBox.Size = new System.Drawing.Size(152, 24);
			this.createNewBox.TabIndex = 5;
			this.createNewBox.Text = "Use Greater Than";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(72, 40);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(264, 23);
			this.label2.TabIndex = 4;
			this.label2.Text = "Number Of Adjoining Squares To Create New";
			// 
			// createNewUpDown
			// 
			this.createNewUpDown.Location = new System.Drawing.Point(8, 40);
			this.createNewUpDown.Name = "createNewUpDown";
			this.createNewUpDown.Size = new System.Drawing.Size(56, 20);
			this.createNewUpDown.TabIndex = 3;
			this.createNewUpDown.Value = new System.Decimal(new int[] {
																		  3,
																		  0,
																		  0,
																		  0});
			// 
			// golRandomPlacementBox
			// 
			this.golRandomPlacementBox.Checked = true;
			this.golRandomPlacementBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.golRandomPlacementBox.Enabled = false;
			this.golRandomPlacementBox.Location = new System.Drawing.Point(280, 8);
			this.golRandomPlacementBox.Name = "golRandomPlacementBox";
			this.golRandomPlacementBox.Size = new System.Drawing.Size(128, 24);
			this.golRandomPlacementBox.TabIndex = 2;
			this.golRandomPlacementBox.Text = "Random Placement";
			this.golRandomPlacementBox.CheckedChanged += new System.EventHandler(this.golRandomPlacementBox_CheckedChanged);
			// 
			// golStartingNumberUpDown
			// 
			this.golStartingNumberUpDown.Location = new System.Drawing.Point(8, 8);
			this.golStartingNumberUpDown.Maximum = new System.Decimal(new int[] {
																					200,
																					0,
																					0,
																					0});
			this.golStartingNumberUpDown.Minimum = new System.Decimal(new int[] {
																					10,
																					0,
																					0,
																					0});
			this.golStartingNumberUpDown.Name = "golStartingNumberUpDown";
			this.golStartingNumberUpDown.Size = new System.Drawing.Size(56, 20);
			this.golStartingNumberUpDown.TabIndex = 1;
			this.golStartingNumberUpDown.Value = new System.Decimal(new int[] {
																				  100,
																				  0,
																				  0,
																				  0});
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(72, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(168, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Number Of Starting Life Forms";
			// 
			// lifeWarsPage
			// 
			this.lifeWarsPage.Controls.Add(this.lwRandomPlacementBox);
			this.lifeWarsPage.Controls.Add(this.label3);
			this.lifeWarsPage.Controls.Add(this.startingLifeFormsPerSideUpDown);
			this.lifeWarsPage.Location = new System.Drawing.Point(4, 22);
			this.lifeWarsPage.Name = "lifeWarsPage";
			this.lifeWarsPage.Size = new System.Drawing.Size(532, 164);
			this.lifeWarsPage.TabIndex = 2;
			this.lifeWarsPage.Text = "Life Wars Options";
			// 
			// lwRandomPlacementBox
			// 
			this.lwRandomPlacementBox.Checked = true;
			this.lwRandomPlacementBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.lwRandomPlacementBox.Location = new System.Drawing.Point(336, 8);
			this.lwRandomPlacementBox.Name = "lwRandomPlacementBox";
			this.lwRandomPlacementBox.Size = new System.Drawing.Size(152, 24);
			this.lwRandomPlacementBox.TabIndex = 2;
			this.lwRandomPlacementBox.Text = "Random Placement";
			this.lwRandomPlacementBox.CheckedChanged += new System.EventHandler(this.lwRandomPlacementBox_CheckedChanged);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(80, 8);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(208, 23);
			this.label3.TabIndex = 1;
			this.label3.Text = "Number Of Starting Life Forms Per Side";
			// 
			// startingLifeFormsPerSideUpDown
			// 
			this.startingLifeFormsPerSideUpDown.Location = new System.Drawing.Point(8, 8);
			this.startingLifeFormsPerSideUpDown.Maximum = new System.Decimal(new int[] {
																						   200,
																						   0,
																						   0,
																						   0});
			this.startingLifeFormsPerSideUpDown.Name = "startingLifeFormsPerSideUpDown";
			this.startingLifeFormsPerSideUpDown.Size = new System.Drawing.Size(64, 20);
			this.startingLifeFormsPerSideUpDown.TabIndex = 0;
			this.startingLifeFormsPerSideUpDown.Value = new System.Decimal(new int[] {
																						 50,
																						 0,
																						 0,
																						 0});
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem2});
			this.menuItem1.Text = "File";
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 0;
			this.menuItem2.Text = "Exit";
			this.menuItem2.Click += new System.EventHandler(this.OnExit);
			// 
			// displayLabel
			// 
			this.displayLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.displayLabel.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.displayLabel.Location = new System.Drawing.Point(10, 510);
			this.displayLabel.Name = "displayLabel";
			this.displayLabel.Size = new System.Drawing.Size(530, 23);
			this.displayLabel.TabIndex = 1;
			this.displayLabel.Text = "Select A Mode Then Change The Options Or Press Start To Use Defaults";
			this.displayLabel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			// 
			// gameTimer
			// 
			this.gameTimer.Interval = 1000;
			this.gameTimer.Tick += new System.EventHandler(this.gameTimer_Tick);
			// 
			// lifeWarsEditTimer
			// 
			this.lifeWarsEditTimer.Tick += new System.EventHandler(this.OnLifeWarsEditTimer);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(542, 735);
			this.Controls.Add(this.displayLabel);
			this.Controls.Add(this.tabControl1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Game Of Life 2 Life Wars";
			this.tabControl1.ResumeLayout(false);
			this.mainOptionsPage.ResumeLayout(false);
			this.Modes.ResumeLayout(false);
			this.gameOfLifePage.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.maximumStayAliveUpDown)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.minimumStayAliveUpDown)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.createNewUpDown)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.golStartingNumberUpDown)).EndInit();
			this.lifeWarsPage.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.startingLifeFormsPerSideUpDown)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		/// <summary>
		/// event to update the borders
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void bordersCheckBox_CheckedChanged(object sender, System.EventArgs e)
		{
		
			if( bordersCheckBox.Checked == true )
			{
				DrawBorders( true );
			}
			else
			{
				DrawBorders( false );
			}
		
		}

		/// <summary>
		/// update the borders
		/// </summary>
		/// <param name="bDraw"></param>
		private void DrawBorders( bool bDraw )
		{
			if( bDraw == true )
			{
				for( int i=0; i<arraySquares.Count; i++ )
				{
					( ( Data )arraySquares[ i ] ).Square.DrawBorder = true;
					( ( Data )arraySquares[ i ] ).Square.Invalidate();
				}
			}
			else
			{
				for( int i=0; i<arraySquares.Count; i++ )
				{
					( ( Data )arraySquares[ i ] ).Square.DrawBorder = false;
					( ( Data )arraySquares[ i ] ).Square.Invalidate();
				}
			}
		}

		/// <summary>
		/// event to choose game of life mode
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void OnGameOfLifeClick(object sender, System.EventArgs e)
		{
		
			if( gameOfLifeCheckBox.Checked == false )
			{
				mode = MODES.GAME_OF_LIFE;
				lifeWarsCheckBox.Checked = false;
				gameOfLifeCheckBox.Checked = true;
			}
			else
			{
				mode = MODES.LIFE_WARS;
				lifeWarsCheckBox.Checked = false;
				gameOfLifeCheckBox.Checked = true;
			}
		}

		/// <summary>
		/// event to choose life wars mode
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void OnLifeWarsClick(object sender, System.EventArgs e)
		{

			if( lifeWarsCheckBox.Checked == false )
			{
				mode = MODES.LIFE_WARS;
				gameOfLifeCheckBox.Checked = false;
				lifeWarsCheckBox.Checked = true;
			}
			else
			{
				mode = MODES.GAME_OF_LIFE;
				gameOfLifeCheckBox.Checked = true;
				lifeWarsCheckBox.Checked = false;
			}
		}

		/// <summary>
		/// start the game of life in whatever mode is set
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void OnStartButton(object sender, System.EventArgs e)
		{
			if( mode == MODES.GAME_OF_LIFE )
			{
				StartGameOfLife();
			}
			else
			{
				StartLifeWars();
			}

			startButton.Enabled = false;

		}

		/// <summary>
		/// event to update the game of life random placement option
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void golRandomPlacementBox_CheckedChanged(object sender, System.EventArgs e)
		{
			GOLRandomPlacementUpdate();
		}


		/// <summary>
		/// function to update the ramdom placement option for game of life
		/// </summary>
		private void GOLRandomPlacementUpdate()
		{
		}


		private void StartGameOfLife()
		{
			if( bPaused == false )
			{
				Random rand = new Random();
				int nCount = ( int )this.golStartingNumberUpDown.Value;
				int nTemp = 0;
				StandardSquare tempSquare = null;

				for( int i=0; i<nCount; i++ )
				{
					nTemp = rand.Next( arraySquares.Count );
					tempSquare = ( ( Data )arraySquares[ nTemp ] ).Square;

					tempSquare.DrawAmeoba = true;
					tempSquare.IsCritterOnSquare = true;
					tempSquare.Invalidate();
					( ( Data )arraySquares[ nTemp ] ).IsNewSquare = true;
				}

				gameTimer.Enabled = true;
			}
			else
			{
				gameTimer.Enabled = true;
			}

			startButton.Enabled = false;
			pauseButton.Enabled = true;
			bPaused = false;
			clearButton.Enabled = false;
		}

		private void StartLifeWars()
		{
			if( bPaused == false )
			{
				Random rand = new Random();
				int nCount = ( int )this.startingLifeFormsPerSideUpDown.Value;
				int nTemp = 0;
				StandardSquare tempSquare = null;

				for( int i=0; i<nCount; i++ )
				{
					nTemp = rand.Next( arraySquares.Count );

					while( ( ( Data )arraySquares[ nTemp ] ).Square.IsCritterOnSquare == true )
						nTemp = rand.Next( arraySquares.Count );

					tempSquare = ( ( Data )arraySquares[ nTemp ] ).Square;

					tempSquare.Ameoba.AmeobaColor = computerColor;
					tempSquare.DrawAmeoba = true;
					tempSquare.IsCritterOnSquare = true;
					tempSquare.Invalidate();
					( ( Data )arraySquares[ nTemp ] ).IsNewSquare = true;
					( ( Data )arraySquares[ nTemp ] ).CritterColor = computerColor;
				}

				if( bLifeWarsEdited == false )
				{
					for( int i=0; i<nCount; i++ )
					{
						nTemp = rand.Next( arraySquares.Count );

						while( ( ( Data )arraySquares[ nTemp ] ).Square.IsCritterOnSquare == true )
							nTemp = rand.Next( arraySquares.Count );

						tempSquare = ( ( Data )arraySquares[ nTemp ] ).Square;

						tempSquare.Ameoba.AmeobaColor = playerColor;
						tempSquare.DrawAmeoba = true;
						tempSquare.IsCritterOnSquare = true;
						tempSquare.Invalidate();
						( ( Data )arraySquares[ nTemp ] ).IsNewSquare = true;
						( ( Data )arraySquares[ nTemp ] ).CritterColor = playerColor;
					}
				}

				gameTimer.Enabled = true;

			}
			else
			{
				gameTimer.Enabled = true;
			}

			startButton.Enabled = false;
			pauseButton.Enabled = true;
			bPaused = false;
			clearButton.Enabled = false;
			bLifeWarsEdited = false;
		}

		/// <summary>
		///  implement the rules when the timer ticks
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void gameTimer_Tick(object sender, System.EventArgs e)
		{
			StandardSquare tempSquare = null;
			StandardSquare topSquare = null;
			StandardSquare topRightSquare = null;
			StandardSquare rightSquare = null;
			StandardSquare bottomRightSquare = null;
			StandardSquare bottomSquare = null;
			StandardSquare bottomLeftSquare = null;
			StandardSquare leftSquare = null;
			StandardSquare topLeftSquare = null;

			
			int nNumberOfCritters = 0;
			int nTemp = 0;

			/// reset the square data
			for( int i=0; i<arraySquares.Count; i++ )
			{
				( ( Data )arraySquares[ i ] ).IsNewSquare = false;
				( ( Data )arraySquares[ i ] ).IsDeadSquare = false;
				( ( Data )arraySquares[ i ] ).DeleteAmeoba = false;
			}

			int nTopSquare = 0;
			int nTopRightSquare = 0;
			int nRightSquare = 0;
			int nBottomRightSquare = 0;
			int nBottomSquare = 0;
			int nBottomLeftSquare = 0;
			int nLeftSquare = 0;
			int nTopLeftSquare = 0;

			int nPlayerNumber = 0;
			int nComputerNumber = 0;
			Color tempColor;

			/// standard game of life rules
			for( int i=0; i<arraySquares.Count; i++ )
			{
				topSquare = null;
				topRightSquare = null;
				rightSquare = null;
				bottomRightSquare = null;
				bottomSquare = null;
				bottomLeftSquare = null;
				leftSquare = null;
				topLeftSquare = null;

				nTopSquare = 0;
				nTopRightSquare = 0;
				nRightSquare = 0;
				nBottomRightSquare = 0;
				nBottomSquare = 0;
				nBottomLeftSquare = 0;
				nLeftSquare = 0;
				nTopLeftSquare = 0;

				nPlayerNumber = 0;
				nComputerNumber = 0;

				nNumberOfCritters = 0;
				nTemp = 0;
				tempSquare = ( ( Data )arraySquares[ i ] ).Square;

				if( i > 24 )
				{
					nTemp = i-25;
					leftSquare = ( ( Data )arraySquares[ nTemp ] ).Square;
					nLeftSquare = nTemp;
					if(  i-25 > 0 ) 
					{
						topLeftSquare = ( ( Data )arraySquares[ nTemp -1 ] ).Square;
						nTopLeftSquare = nTemp -1;
					}
					if( i-23 > 0 )
					{
						bottomLeftSquare = ( ( Data )arraySquares[ nTemp +1 ] ).Square;
						nBottomLeftSquare = nTemp +1;
					}
				}

				nTemp = i;

				/// check its not a top square
				if( i > 0 && ( i % 25 ) != 0 )
				{
					topSquare = ( ( Data )arraySquares[ nTemp -1 ] ).Square;
					nTopSquare = nTemp -1;
				}

				/// check there's a bottom square
				if( i >= 0 && i < 23 || ( i % 24 ) >= 1 )
				{
					bottomSquare = ( ( Data )arraySquares[ nTemp +1 ] ).Square;
					nBottomSquare = nTemp +1;
				}

				/// check there's a row to the right
				if( i < arraySquares.Count - 25 )
				{
					nTemp = i + 25;
					rightSquare = ( ( Data )arraySquares[ nTemp ] ).Square;
					nRightSquare = nTemp;
					if( i != 0 && arraySquares.Count > i + 24 && arraySquares[ i + 24 ] != null  )
					{
						topRightSquare = ( ( Data )arraySquares[ nTemp -1 ] ).Square;
						nTopRightSquare = nTemp -1;
					}
					if( i == 0 || arraySquares.Count > i + 26 && arraySquares[ i + 26 ] != null )
					{
						bottomRightSquare = ( ( Data )arraySquares[ nTemp +1 ] ).Square;
						nBottomRightSquare = nTemp +1;
					}
				}

				/// check adjoining cells

				if( topSquare != null && topSquare.IsCritterOnSquare == true 
					&& ( ( Data )arraySquares[ nTopSquare ] ).IsNewSquare == false )
				{
					nNumberOfCritters++;
					
					tempColor = ( ( Data )arraySquares[ nTopSquare ] ).Square.Ameoba.AmeobaColor;
					if( tempColor == playerColor )
						nPlayerNumber++;
					if( tempColor == computerColor )
						nComputerNumber++;

				}
				if( topRightSquare != null && topRightSquare.IsCritterOnSquare == true 
					&& ( ( Data )arraySquares[ nTopRightSquare ] ).IsNewSquare == false )
				{
					nNumberOfCritters++;

					tempColor = ( ( Data )arraySquares[ nTopRightSquare ] ).Square.Ameoba.AmeobaColor;
					if( tempColor == playerColor )
						nPlayerNumber++;
					if( tempColor == computerColor )
						nComputerNumber++;
				}
				if( rightSquare != null && rightSquare.IsCritterOnSquare == true 
					&& ( ( Data )arraySquares[ nRightSquare ] ).IsNewSquare == false )
				{
					nNumberOfCritters++;

					tempColor = ( ( Data )arraySquares[ nRightSquare ] ).Square.Ameoba.AmeobaColor;
					if( tempColor == playerColor )
						nPlayerNumber++;
					if( tempColor == computerColor )
						nComputerNumber++;
				}
				if( bottomRightSquare != null && bottomRightSquare.IsCritterOnSquare == true 
					&& ( ( Data )arraySquares[ nBottomRightSquare ] ).IsNewSquare == false )
				{
					nNumberOfCritters++;

					tempColor = ( ( Data )arraySquares[ nBottomRightSquare ] ).Square.Ameoba.AmeobaColor;
					if( tempColor == playerColor )
						nPlayerNumber++;
					if( tempColor == computerColor )
						nComputerNumber++;
				}
				if( bottomSquare != null && bottomSquare.IsCritterOnSquare == true
					&& ( ( Data )arraySquares[ nBottomSquare ] ).IsNewSquare == false )
				{
					nNumberOfCritters++;

					tempColor = ( ( Data )arraySquares[ nBottomSquare ] ).Square.Ameoba.AmeobaColor;
					if( tempColor == playerColor )
						nPlayerNumber++;
					if( tempColor == computerColor )
						nComputerNumber++;
				}
				if( bottomLeftSquare != null && bottomLeftSquare.IsCritterOnSquare == true 
					&& ( ( Data )arraySquares[ nBottomLeftSquare ] ).IsNewSquare == false )
				{
					nNumberOfCritters++;

					tempColor = ( ( Data )arraySquares[ nBottomLeftSquare ] ).Square.Ameoba.AmeobaColor;
					if( tempColor == playerColor )
						nPlayerNumber++;
					if( tempColor == computerColor )
						nComputerNumber++;
				}
				if( leftSquare != null && leftSquare.IsCritterOnSquare == true 
					&& ( ( Data )arraySquares[ nLeftSquare ] ).IsNewSquare == false )
				{
					nNumberOfCritters++;

					tempColor = ( ( Data )arraySquares[ nLeftSquare ] ).Square.Ameoba.AmeobaColor;
					if( tempColor == playerColor )
						nPlayerNumber++;
					if( tempColor == computerColor )
						nComputerNumber++;
				}
				if( topLeftSquare != null && topLeftSquare.IsCritterOnSquare == true
					&& ( ( Data )arraySquares[ nTopLeftSquare ] ).IsNewSquare == false )
				{
					nNumberOfCritters++;

					tempColor = ( ( Data )arraySquares[ nTopLeftSquare ] ).Square.Ameoba.AmeobaColor;
					if( tempColor == playerColor )
						nPlayerNumber++;
					if( tempColor == computerColor )
						nComputerNumber++;
				}

				if( mode == MODES.GAME_OF_LIFE )
				{
					/// check all empty squares
					if( tempSquare.IsCritterOnSquare == false )
					{
						if( this.createNewBox.Checked == false )
						{
							if( nNumberOfCritters == ( int )this.createNewUpDown.Value )
							{
								( ( Data )arraySquares[ i ] ).IsNewSquare = true;
							}
						}
						else
						{
							if( nNumberOfCritters >= ( int )createNewUpDown.Value )
							{
								( ( Data )arraySquares[ i ] ).IsNewSquare = true;
							}
						}
					}
					else
					{
						if( nNumberOfCritters < ( int )this.minimumStayAliveUpDown.Value )
						{
							( ( Data )arraySquares[ i ] ).IsDeadSquare = true;
						}

						if( this.maximumBox.Checked == false )
						{
							if( nNumberOfCritters == ( int )this.maximumStayAliveUpDown.Value )
								( ( Data )arraySquares[ i ] ).IsDeadSquare = true;
						}
						else
						{
							if( nNumberOfCritters >= ( int )this.maximumStayAliveUpDown.Value )
								( ( Data )arraySquares[ i ] ).IsDeadSquare = true ;
						}				
					}
				}
				else
				{
					if( tempSquare.IsCritterOnSquare == false )
					{
						if( nNumberOfCritters >= 2 )
						{
							( ( Data )arraySquares[ i ] ).IsNewSquare = true;

							/// whose side is it on
							if( nPlayerNumber > nComputerNumber )
							{
								( ( Data )arraySquares[ i ] ).Square.Ameoba.AmeobaColor = playerColor;
								( ( Data )arraySquares[ i ] ).CritterColor = playerColor;
							}
							else if( nComputerNumber > nPlayerNumber )
							{
								( ( Data )arraySquares[ i ] ).Square.Ameoba.AmeobaColor = computerColor;
								( ( Data )arraySquares[ i ] ).CritterColor = computerColor;
							}
							else
							{
								Random decideRand = new Random();
								int nDecide = decideRand.Next( 2 );

								if( nDecide == 1 )
								{
									( ( Data )arraySquares[ i ] ).Square.Ameoba.AmeobaColor = playerColor;
									( ( Data )arraySquares[ i ] ).CritterColor = playerColor;
								}
								else
								{
									( ( Data )arraySquares[ i ] ).Square.Ameoba.AmeobaColor = computerColor;
									( ( Data )arraySquares[ i ] ).CritterColor = computerColor;
								}
							}
						}
					} 

					if( nNumberOfCritters < 2 || nNumberOfCritters > 3 )
					{
						( ( Data )arraySquares[ i ] ).IsDeadSquare = true;
					}
				}
			}

			for( int i=0; i<arraySquares.Count; i++ )
			{
				StandardSquare temp = ( ( Data )arraySquares[ i ] ).Square;

				if( ( ( Data )arraySquares[ i ] ).IsNewSquare == true )
				{
					temp.IsCritterOnSquare = true;
					temp.DrawAmeoba = true;
					temp.Invalidate();
				}

				if( ( ( Data )arraySquares[ i ] ).IsDeadSquare == true )
				{
					temp.IsCritterOnSquare = false;
					temp.DrawAmeoba = false;
					temp.Invalidate();
				}
			}

			/// report current results
			if( mode == MODES.LIFE_WARS )
			{
				int nPlayerCount = 0;
				int nComputerCount = 0;

				for( int i=0; i<arraySquares.Count; i++ )
				{
					if( ( ( Data )arraySquares[ i ] ).Square.IsCritterOnSquare == true )
					{
						if( ( ( Data )arraySquares[ i ] ).CritterColor == playerColor )
							nPlayerCount++;
						else
							nComputerCount++;
					}
				}

				if( nComputerCount != 0 && nPlayerCount != 0 )
				{
					displayLabel.Text = "Computer :- " + nComputerCount + " Player :- " + nPlayerCount;
				}
				else
				{
					if( nComputerCount == 0 )
					{
						displayLabel.Text = "Player Wins !!!! :)";
					}
					else
					{
						displayLabel.Text = "Computer Wins !!!! :(";
					}

					if( bordersCheckBox.Checked == true )
					{
						DrawBorders( false );
						DrawBorders( true );
						DrawBorders( false );
						DrawBorders( true );
					}
					else
					{
						DrawBorders( true );
						DrawBorders( false );
						DrawBorders( true );
						DrawBorders( false );
					}

					pauseButton_Click( this, new EventArgs() );

				}
			}
		}

		private void pauseButton_Click(object sender, System.EventArgs e)
		{
			gameTimer.Enabled = false;
			this.startButton.Enabled = true;
			this.startButton.Text = "Continue";
			bPaused = true;
			pauseButton.Enabled = false;
			clearButton.Enabled = true;
		}

		private void clearButton_Click(object sender, System.EventArgs e)
		{
			gameTimer.Enabled = false;
			startButton.Enabled = true;
			startButton.Text = "Start";
			bPaused = false;
			pauseButton.Enabled = false;

			for( int i=0; i<arraySquares.Count; i++ )
			{
				( ( Data )arraySquares[ i ] ).Square.IsCritterOnSquare = false;
				( ( Data )arraySquares[ i ] ).Square.DrawAmeoba = false;
				( ( Data )arraySquares[ i ] ).Square.Invalidate();
			}

			bLifeWarsEdited = false;
		}

		private void lwRandomPlacementBox_CheckedChanged(object sender, System.EventArgs e)
		{
			if( lwRandomPlacementBox.Checked == true )
			{
			}
			else
			{
				/// clear the squares
				for( int i=0; i<arraySquares.Count; i++ )
				{
					( ( Data )arraySquares[ i ] ).Square.IsCritterOnSquare = false;
					( ( Data )arraySquares[ i ] ).Square.DrawAmeoba = false;
					( ( Data )arraySquares[ i ] ).Square.Invalidate();
				}

				displayLabel.Text = "Click On The Squares To Place Your Life Forms";

				for( int i=0; i<arraySquares.Count; i++ )
				{
					( ( Data )arraySquares[ i ] ).Square.Ameoba.AmeobaColor = playerColor;
					( ( Data )arraySquares[ i ] ).Square.AllowLifeWarsEdit = true;
				}

				lifeWarsEditTimer.Enabled = true;
			}
		}

		private void OnLifeWarsEditTimer(object sender, System.EventArgs e)
		{
			int nPlayerCount = 0;

			for( int i=0; i<arraySquares.Count; i++ )
			{
				if( ( ( Data )arraySquares[ i ] ).Square.IsCritterOnSquare == true )
					nPlayerCount++;
			}

			displayLabel.Text = "Number Of Players Life Forms Placed :- " + nPlayerCount;

			if( nPlayerCount == ( int )startingLifeFormsPerSideUpDown.Value )
			{
				lifeWarsEditTimer.Enabled = false;

				for( int i=0; i<arraySquares.Count; i++ )
				{
					( ( Data )arraySquares[ i ] ).Square.AllowLifeWarsEdit = false;
				} 
			}
		}

		private void OnExit(object sender, System.EventArgs e)
		{
			Application.Exit();
		}
	}
}
