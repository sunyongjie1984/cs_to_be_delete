#region Summary
/******************************************************************************
// AUTHOR                   : Mark Nischalke 
// PURPOSE                  : Provides an implementation of ExceptionPolicy that
//                             uses a hierarchial configuration file structure
//                             that starts with this assembly
// SPECIAL NOTES            : 
// 
// EXTERNAL DEPENDENCIES    : Microsoft Enterprise Library 3.1
// SPECIAL CHARACTERISTICS 
// OR LIMITATIONS           : None
//
// Copyright � 2007 all rights reserved
******************************************************************************/
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.IO;
using System.Configuration;

using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

namespace HierExceptionHandler
{
    /// <summary>
    /// Provides an implementation of ExceptionPolicy that
    //  uses a hierarchial configuration file structure
    //  that starts with this assembly.
    /// </summary>
    public static class HierExceptionPolicy
    {
        private static Dictionary<string, FileConfigurationSource> m_Sources;
        private static Exception m_ExceptionToHandle;
        private static string m_PolicyName;
        private static string m_RootPath;

        /// <summary>
        /// Handle the given exception using the policy defined
        /// </summary>
        /// <param name="ex">Exception to handle</param>
        /// <param name="policyName">Name of policy to use. If null or empty, the "Default Policy" will be used</param>
        /// <returns>True if the exception needs to be rethrown, otherwise false.</returns>
        /// <exception cref="ArgumentNullException">Thrown if the ex is null</exception>
        /// <exception cref="NoPolicyException">Thrown if no policy can be found matching the name or exception</exception>
        public static bool HandleException(Exception ex, string policyName)
        {
            // Check if a valid exception is passed in
            if(ex == null)
                throw new ArgumentNullException("ex");
            else
                ExceptionToHandle = ex;

            // If no policy name were passed in, use the
            // default policy
            if(string.IsNullOrEmpty(policyName))
                PolicyName = "Default Policy";
            else
                PolicyName = policyName;

            // Get a policy to handle the exception
            ExceptionPolicyImpl policy = GetPolicy();
            if(policy == null)
                throw new NoPolicyException("No policy named \"" + policyName + "\" could be found for the exception " + ex.GetType().Name, ex);

            // Handle the exception as per the policy
            return policy.HandleException(ex);
        }

        #region Private Methods

        /// <summary>
        /// Returns a <see cref="ExceptionPolicyImpl"/> for the policy and <see cref="Exception"/>
        /// </summary>
        /// <returns><see cref="ExceptionPolicyImpl"/> if found, otherwise null</returns>
        private static ExceptionPolicyImpl GetPolicy()
        {
            ExceptionPolicyImpl policy = null;

            // Search the existing sources for the policy to handle the exception
            foreach(FileConfigurationSource source in ConfigSources.Values)
            {
                policy = FindPolicy(source);
                if(policy != null)
                    return policy;
            }

            // Nothing was found so far, so we need to walk the
            // folder chain to find a policy

            // In theory there should be one config so far,
            // so start with the siblings at this level.
            string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            policy = FindConfigFile(path);
            if(policy != null)
                return policy;

            return policy;
        }

        /// <summary>
        /// Find configuration files at the same level as
        /// the given path
        /// </summary>
        /// <param name="path"></param>
        private static ExceptionPolicyImpl FindConfigFile(string path)
        {
            ExceptionPolicyImpl policy = null;

            // Only interested in config files in the directory
            string[] files = Directory.GetFiles(path, "*.config");
            foreach(string file in files)
            {
                // Check if the config file was already added
                if(!ConfigSources.ContainsKey(Path.GetFileName(file)))
                {
                    // Create a new source and store it in the collection for later
                    FileConfigurationSource source = new FileConfigurationSource(file);
                    ConfigSources.Add(Path.GetFileName(file), source);
                    
                    // Does the source handle the exception?
                    policy = FindPolicy(source);
                    if(policy != null)
                        return policy;
                }
            }

            // Get the parent path
            string parentPath = Path.GetDirectoryName(path.Substring(0, path.LastIndexOf('\\')+1));
            
            // Make sure we have not passed the root folder for the application
            // and call this method recursively if not
            if(!IsPastRootFolder(parentPath))
                return FindConfigFile(parentPath);

            return policy;
        }

        /// <summary>
        /// Determine if the given <see cref="FileConfigurationSource"/> contains a
        /// policy for the exception to be handled.
        /// </summary>
        /// <param name="source"><see cref="FileConfigurationSource"/> to check for policy</param>
        /// <returns><see cref="ExceptionPolicyImpl"/> that handles the exception, otherwise null</returns>
        private static ExceptionPolicyImpl FindPolicy(FileConfigurationSource source)
        {
            // Create a factory from the source
            ExceptionPolicyFactory factory = new ExceptionPolicyFactory(source);
            ExceptionPolicyImpl policy = null;

            // Try to create a policy implemenatation for the policyname
            // If the policy can't be found in the source, this exception
            // will be thrown
            try
            {
                policy = factory.Create(PolicyName);
            }
            catch(ConfigurationException)
            {
                return null;
            }

            // Now that a policy has been found, see if it
            // handles the exception
            if(policy.GetPolicyEntry(ExceptionToHandle.GetType()) != null)
                return policy;
            else
                return null;
        }

        /// <summary>
        /// Test if the given path is above the root folder
        /// for the current application
        /// </summary>
        /// <param name="path">Path to test</param>
        /// <returns>True if the path is above the root fodler, otherwise false</returns>
        private static bool IsPastRootFolder(string path)
        {
            // Do a simple test of lengths to determine if
            // the path is above the root folder
            if(path.Length < RootPath.Length )
                return true;
            else
                return false;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Get collection of FileConfigurationSource to use
        /// for searching for exception policy definitions
        /// </summary>
        private static Dictionary<string, FileConfigurationSource> ConfigSources
        {
            get
            {
                if(m_Sources == null)
                {
                    m_Sources = new Dictionary<string, FileConfigurationSource>();
                    // Get the path for this assembly
                    string filePath = Assembly.GetExecutingAssembly().Location + ".config";
                    // Make sure the file exists, and add it to the collection
                    if(File.Exists(filePath))
                        m_Sources.Add(Path.GetFileName(filePath), new FileConfigurationSource(filePath));
                }
                return m_Sources; 
            }
        }

        /// <summary>
        /// Get/Set policy name to be used
        /// </summary>
        public static string PolicyName
        {
            get { return m_PolicyName; }
            set { m_PolicyName = value; }
        }

        /// <summary>
        /// Get/Set <see cref="Exception"/> that is being handled
        /// </summary>
        private static Exception ExceptionToHandle
        {
            get { return m_ExceptionToHandle; }
            set { m_ExceptionToHandle = value; }
        }

        /// <summary>
        /// Get/Set the root folder for the current application
        /// </summary>
        public static string RootPath
        {
            get
            { 
                if( m_RootPath == null )
                    m_RootPath = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                return m_RootPath; 
            }
            set { m_RootPath = value; }
        }

        #endregion
    }
}
