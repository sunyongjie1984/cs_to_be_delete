#region Summary
/******************************************************************************
// AUTHOR                   : Mark Nischalke 
// PURPOSE                  : Define exception for no policy found
// SPECIAL NOTES            : 
// 
// EXTERNAL DEPENDENCIES    : None
// SPECIAL CHARACTERISTICS 
// OR LIMITATIONS           : None
//
// Copyright � 2007 all rights reserved
******************************************************************************/
#endregion


using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace HierExceptionHandler
{
    /// <summary>
    /// Define exception for no policy found
    /// </summary>
    [Serializable]
    public class NoPolicyException : Exception
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public NoPolicyException()
            : base("No policy found.")
        {

        }

        /// <summary>
        /// Alternate constructor
        /// </summary>
        /// <param name="message"></param>
        public NoPolicyException(string message)
            : base(message)
        {

        }

        /// <summary>
        /// Alternate constructor
        /// </summary>
        /// <param name="message"></param>
        /// <param name="innerException"></param>
        public NoPolicyException(string message, Exception innerException)
            : base(message, innerException)
        {

        }

        /// <summary>
        /// Alternate constructor
        /// </summary>
        /// <param name="info"></param>
        /// <param name="context"></param>
        protected NoPolicyException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {

        }
    }
}
