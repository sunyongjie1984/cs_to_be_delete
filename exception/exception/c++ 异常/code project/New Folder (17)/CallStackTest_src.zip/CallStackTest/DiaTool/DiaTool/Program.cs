﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// C:\Program Files\Microsoft Visual Studio 9.0\DIA SDK\bin\msdia90.dll -> Library Dia2 2.0
// http://msdn.microsoft.com/en-us/library/x93ctkx8(VS.80).aspx

namespace DiaTool
{
    class Program
    {
        static void Main(string[] args)
        {
            string output = System.IO.Directory.GetCurrentDirectory() + "\\Output.txt";
            bool help = false;
            bool process = false;
            List<string> pdbFiles = new List<string>();
            List<string> filesToAnalyze = new List<string>();

            for (int i = 0; i < args.Length; ++i)
            {
                string arg = args[i].ToLower();

                if (arg.StartsWith("/p:"))
                {
                    string filename = arg.Substring(3);
                    if (System.IO.File.Exists(filename))
                    {
                        using (System.IO.StreamReader reader = new System.IO.StreamReader(filename))
                        {
                            while (!reader.EndOfStream)
                            {
                                string file = reader.ReadLine().ToLower();
                                if (file.StartsWith(";"))
                                {
                                    continue;    // comment
                                }
                                if (file.EndsWith(".pdb") && System.IO.File.Exists(file))
                                {
                                    if (pdbFiles.Contains(arg) == false)
                                    {
                                        pdbFiles.Add(file);
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Could not open file : '{0}'", file);
                                    return;
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Could not open input file : '{0}'", filename);
                        return;
                    }
                }
                else if (arg.StartsWith("/a:"))
                {
                    string filename = arg.Substring(3);
                    if (System.IO.File.Exists(filename))
                    {
                        if (filesToAnalyze.Contains(arg) == false)
                        {
                            filesToAnalyze.Add(filename);
                        }
                    }
                }
                else if (arg.StartsWith("/o:"))
                {
                    output = arg.Substring(3);
                }
                else if (arg.StartsWith("/s"))
                {
                    process = true;
                }
                else if ((arg == "/h") || (arg == "/?"))
                {
                    help = true;
                }
                else // can only be pdb file
                {
                    if (arg.EndsWith(".pdb") && System.IO.File.Exists(arg))
                    {
                        if (pdbFiles.Contains(arg) == false)
                        {
                            pdbFiles.Add(arg.ToLower());
                        }
                    }
                    else
                    {
                        Console.WriteLine("Wrong input parameter : '{0}'", args[i]);
                        return;
                    }
                }
            }

            if (help == true)
            {
                Console.WriteLine("DiaTool.exe [/i:<input file> | <pdb file1> .. <pdb file n>] [/o:<output file>] [/h | /?]");
                Console.WriteLine("  /p:<input file>  : file that contains list of pdb files to parse");
                Console.WriteLine("  /a:<input file>  : file to analyze");
                Console.WriteLine("  /o:<output file> : name of file to write all debug symbol function names to if option '/p' is set. If omitted, default is 'Output.txt'");
                Console.WriteLine("  /h | /?          : print help");
                Console.WriteLine();
                return;
            }

            Dia dia = new Dia(pdbFiles, filesToAnalyze, output);
            if (process == true)
            {
                dia.Process();
            }
            dia.Analyze();
        }
    }
}
