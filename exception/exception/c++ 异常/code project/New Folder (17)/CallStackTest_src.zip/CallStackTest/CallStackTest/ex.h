
#ifndef I_EX_H
#define I_EX_H

#include <map>
#include <list>
#include <psapi.h>
#include <tlhelp32.h>

unsigned long findDeepestFrame(const unsigned long ebp, const unsigned long esp);
std::list<unsigned long> findFrames(const unsigned long ebp, const unsigned long esp);
std::list<unsigned long> findCodeAddress(std::list<unsigned long> frames);
std::list<unsigned long> findCodeAddress(const unsigned long ebp, const unsigned long esp);

std::list<MODULEENTRY32> GetModulesList();
bool IsValidCodeMemory(unsigned long address, std::list<MODULEENTRY32> modulesList);

std::map<unsigned long, std::wstring> LoadAsm(const wchar_t* filename);
std::map<unsigned long, std::wstring> LoadPdb(const wchar_t* filename);

unsigned long GetLoadAddress(const wchar_t* filename);
unsigned long GetLoadAddressEx(const wchar_t* filename, std::list<MODULEENTRY32> listOfModules);

void Output(std::list<unsigned long> codeAddresses, std::list<MODULEENTRY32> modulesList);

void AnalyzeCallStack(const BYTE* pFrame, const BYTE* pStack);

#endif // I_EX_H