
#ifndef I_C2_H
#define I_C2_H

class SomeClass
{
public:
    SomeClass();
    ~SomeClass();
};

class C2
{
public:
	long Test2(long p2);
};

#endif // I_C2_H

