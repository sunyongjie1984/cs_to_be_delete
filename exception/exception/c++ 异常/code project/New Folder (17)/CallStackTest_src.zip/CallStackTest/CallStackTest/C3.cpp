
#include "stdafx.h"
#include <iostream>
#include "C2.h"
#include "C3.h"

long C3::Test3()
{
    long d3 = 3;

#ifdef CATCH_LOWER_LEVELS
	try
#endif
	{
		long data = 3;

		C2 c2;
		data += c2.Test2(data);

		return data;
	}
#ifdef CATCH_LOWER_LEVELS
	catch (...)
	{
		std::cout << "crash C3::Test3()" << std::endl;
		throw;
	}
#endif
}