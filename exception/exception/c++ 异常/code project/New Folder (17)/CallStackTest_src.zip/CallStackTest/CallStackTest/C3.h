
#ifndef I_C3_H
#define I_C3_H

class C3
{
public:
	long Test3();
};

#endif // I_C3_H

