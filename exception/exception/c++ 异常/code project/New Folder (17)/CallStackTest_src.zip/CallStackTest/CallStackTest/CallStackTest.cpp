
#include "stdafx.h"
#include <windows.h>
#include <commctrl.h>
#include <iostream>
#include "C4.h"
#include "ex.h"

std::map<unsigned long, std::wstring> theExceptionTable;
std::wstring theRootPath;

void Test1()
{
	long data = -1;

	std::cout << "Running CallStackTest..." << std::endl;

	C4 c4;
	data = c4.Test4(100.200);

	std::cout << data << std::endl;
	std::cout << "CallStackTest finished." << std::endl;
}

DWORD WINAPI ThreadProc(LPVOID lpParameter)
{
	Test1();

	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
    // Prepare 
    wchar_t fullPath[512];
    wchar_t rootPath[512];
    wcscpy_s(fullPath, 512, argv[0]);
    wchar_t* dot = wcsrchr(fullPath, L'.');
    wchar_t* backslash = wcsrchr(fullPath, L'\\');
    wcscpy_s(dot, 512 - (wcslen(fullPath) - wcslen(L".exe")), L".map");
    int c = backslash - fullPath;
    wcsncpy_s(rootPath, 512, fullPath, c);

    theRootPath = rootPath;
    theExceptionTable = LoadAsm(fullPath);

    // Go ahead with test
    // Either in main() thread context or a new thread
#if 0
	DWORD threadID=0;
	CreateThread(NULL, 0, ThreadProc, NULL, 0, &threadID);
#else
    ThreadProc(NULL);
#endif

	Sleep(1000);

	return 0;
}

