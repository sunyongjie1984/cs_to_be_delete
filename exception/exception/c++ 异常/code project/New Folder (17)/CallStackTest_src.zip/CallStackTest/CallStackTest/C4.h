
#ifndef I_C4_H
#define I_C4_H

class C4
{
public:
	long Test4(double f4);
};

#endif // I_C4_H

