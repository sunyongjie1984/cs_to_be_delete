
#include "stdafx.h"
#include <iostream>
#include "C1.h"
#include "C2.h"

SomeClass::SomeClass()
{
    std::cout << "Constructing SomeClass" << std::endl;
}

SomeClass::~SomeClass()
{
    std::cout << "Destructing SomeClass" << std::endl;
}

long C2::Test2(long p2)
{
    long d2 = 2;

    // aClass will need to be destructed during the catch() unwind
    SomeClass aClass;

#ifdef CATCH_LOWER_LEVELS
    try
#endif
    {
		long data = 2;

		C1 c1;
		data += c1.Test1();

		return data;
	}
#ifdef CATCH_LOWER_LEVELS
	catch (...)
	{
		std::cout << "crash C2::Test2()" << std::endl;
		throw;
	}
#endif
}