
#include "stdafx.h"
#include <iostream>
#include "C1.h"

long C1::Test1()
{
    long d1 = 1;

#ifdef CATCH_LOWER_LEVELS
    try
#endif
    {
		long data = 1;

        // let it crash
#if 0
        //throw std::logic_error("It failed");
        throw std::exception("It failed");
#else
        char* c = NULL;
        *c = 'A';
#endif

        return data * 99;
	}
#ifdef CATCH_LOWER_LEVELS
	catch (...)
	{
		std::cout << "crash C1::Test1()" << std::endl;
		throw;
	}
#endif
}