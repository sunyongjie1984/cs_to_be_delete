
#ifndef I_C1_H
#define I_C1_H

class C1
{
public:
	long Test1();
};

#endif // I_C1_H

