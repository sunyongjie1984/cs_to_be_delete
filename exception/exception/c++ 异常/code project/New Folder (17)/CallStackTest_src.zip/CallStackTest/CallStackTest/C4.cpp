
#include "stdafx.h"
#include <iostream>
#include "C3.h"
#include "C4.h"
#include "ex.h"

long C4::Test4(double f4)
{
    BYTE* pStack = NULL;
    BYTE* pFrame = NULL;
    long d4 = 4;
	try
	{
		long data = 4;

		C3 c3;
		data += c3.Test3();

		return (long)(data * f4);
	}
	catch (...)
	{
        __asm
        {
            mov pFrame, ebp;   
            mov pStack, esp;   
        }

        AnalyzeCallStack(pFrame, pStack);

#ifdef DONT_SWALLOW
		std::cout << "crash C4::Test4() throw exception" << std::endl;
        throw;
#else
   		std::cout << "crash C4::Test4() swallow exception" << std::endl;
#endif
	}
}