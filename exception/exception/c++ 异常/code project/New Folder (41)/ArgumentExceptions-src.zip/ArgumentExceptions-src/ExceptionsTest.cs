//                                  ~ J. J. ~

using NUnit.Framework;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Reflection;
using System.Reflection.Emit;


namespace Umbrae
{
    // Author:     Nils Jonsson
    // Originated: 9/14/2004
    [TestFixture]
    public class ExceptionsTest
    {
        #region private class TemporaryTypeBuilder
        private class TemporaryTypeBuilder
        {
            public static Type CreateEnumType(ValueType memberValue)
            {
                return TemporaryTypeBuilder.CreateEnumBuilder(
                 memberValue).CreateType();
            }
            
            public static Type CreateEnumTypeWithFlagsAttribute(
             ValueType memberValue)
            {
                EnumBuilder enumBuilder
                 = TemporaryTypeBuilder.CreateEnumBuilder(memberValue);
                ConstructorInfo constructorInfo
                 = typeof(FlagsAttribute).GetConstructor(new Type[0]);
                CustomAttributeBuilder customAttributeBuilder
                 = new CustomAttributeBuilder(constructorInfo, new object[0]);
                enumBuilder.SetCustomAttribute(customAttributeBuilder);
                return enumBuilder.CreateType();
            }
            
            private static EnumBuilder CreateEnumBuilder(ValueType memberValue)
            {
                AssemblyName assemblyName = new AssemblyName();
                assemblyName.Name = "MyAssembly";
                AssemblyBuilder assemblyBuilder
                 = AppDomain.CurrentDomain.DefineDynamicAssembly(assemblyName,
                 AssemblyBuilderAccess.Run);
                ModuleBuilder moduleBuilder
                 = assemblyBuilder.DefineDynamicModule("MyModule");
                EnumBuilder enumBuilder
                 = moduleBuilder.DefineEnum("MyEnum", TypeAttributes.Public,
                 memberValue.GetType());
                enumBuilder.DefineLiteral("MyValue", memberValue);
                return enumBuilder;
            }
            
            
            private TemporaryTypeBuilder()
            {
            }
        }
        #endregion
        
        
        public ExceptionsTest()
        {
        }
        
        
        #region ThrowIfDifferentRank() tests
        [Test]
        public void TestThrowIfDifferentRank_PassWithName()
        {
            Exceptions.ThrowIfDifferentRank(new object[1], ExceptionsTest.name,
             1);
        }
        
        [Test]
        public void TestThrowIfDifferentRank_PassWithoutName()
        {
            Exceptions.ThrowIfDifferentRank(new object[1], 1);
        }
        
        [Test]
        [ExpectedException(typeof(RankException),
         "Argument myArgument must be an array with 2 dimensions.")]
        public void TestThrowIfDifferentRank_FailWithName()
        {
            Exceptions.ThrowIfDifferentRank(new object[1], ExceptionsTest.name,
             2);
        }
        
        [Test]
        [ExpectedException(typeof(RankException),
         "Argument must be an array with 2 dimensions.")]
        public void TestThrowIfDifferentRank_FailWithoutName()
        {
            Exceptions.ThrowIfDifferentRank(new object[1], 2);
        }
        #endregion
        
        #region ThrowIfDifferentType() tests
        [Test]
        public void TestThrowIfDifferentType_PassWithName()
        {
            Assert.AreEqual(typeof(int), 1.GetType());
            Exceptions.ThrowIfDifferentType(1, ExceptionsTest.name,
             typeof(int));
        }
        
        [Test]
        public void TestThrowIfDifferentType_PassWithoutName()
        {
            Assert.AreEqual(typeof(int), 1.GetType());
            Exceptions.ThrowIfDifferentType(1, typeof(int));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException),
         @"Argument myArgument must be of type Char.
Parameter name: myArgument")]
        public void TestThrowIfDifferentType_FailWithName()
        {
            Assert.AreEqual(typeof(int), 1.GetType());
            Exceptions.ThrowIfDifferentType(1, ExceptionsTest.name,
             typeof(char));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException),
         "Argument must be of type Char.")]
        public void TestThrowIfDifferentType_FailWithoutName()
        {
            Assert.AreEqual(typeof(int), 1.GetType());
            Exceptions.ThrowIfDifferentType(1, typeof(char));
        }
        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfDifferentType_WithNameValueNull()
//        {
//            Exceptions.ThrowIfDifferentType(null, ExceptionsTest.name,
//             typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfDifferentType_WithoutNameValueNull()
//        {
//            Exceptions.ThrowIfDifferentType(null, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfDifferentType_WithNameTypeNull()
//        {
//            Exceptions.ThrowIfDifferentType(1, ExceptionsTest.name,
//             null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfDifferentType_WithoutNameTypeNull()
//        {
//            Exceptions.ThrowIfDifferentType(1, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfDifferentType_WithNameValueNullTypeNull()
//        {
//            Exceptions.ThrowIfDifferentType(null, ExceptionsTest.name,
//             null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfDifferentType_WithoutNameValueNullTypeNull()
//        {
//            Exceptions.ThrowIfDifferentType(null, null);
//        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException),
         @"Argument myArgument must be of type Object.
Parameter name: myArgument")]
        public void
         TestThrowIfDifferentType_FailGrandparentTypeWithName()
        {
            Assert.AreEqual(typeof(object), (new object()).GetType());
            Exceptions.ThrowIfDifferentType(1, ExceptionsTest.name,
             typeof(object));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException),
         "Argument must be of type Object.")]
        public void
         TestThrowIfDifferentType_FailGrandparentTypeWithoutName()
        {
            Assert.AreEqual(typeof(object), (new object()).GetType());
            Exceptions.ThrowIfDifferentType(1, typeof(object));
        }
        #endregion
        
        #region ThrowIfIncompatibleType() tests
        [Test]
        public void TestThrowIfIncompatibleType_PassWithName()
        {
            Assert.AreEqual(typeof(int), 1.GetType());
            Exceptions.ThrowIfIncompatibleType(1, ExceptionsTest.name,
             typeof(int));
        }
        
        [Test]
        public void TestThrowIfIncompatibleType_PassWithoutName()
        {
            Assert.AreEqual(typeof(int), 1.GetType());
            Exceptions.ThrowIfIncompatibleType(1, typeof(int));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException),
         @"Argument myArgument must be compatible with type Char.
Parameter name: myArgument")]
        public void TestThrowIfIncompatibleType_FailWithName()
        {
            Assert.AreEqual(typeof(int), 1.GetType());
            Exceptions.ThrowIfIncompatibleType(1, ExceptionsTest.name,
             typeof(char));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException),
         "Argument must be compatible with type Char.")]
        public void TestThrowIfIncompatibleType_FailWithoutName()
        {
            Assert.AreEqual(typeof(int), 1.GetType());
            Exceptions.ThrowIfIncompatibleType(1, typeof(char));
        }
        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfIncompatibleType_WithNameValueNull()
//        {
//            Exceptions.ThrowIfIncompatibleType(null,
//             ExceptionsTest.name, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfIncompatibleType_WithoutNameValueNull()
//        {
//            Exceptions.ThrowIfIncompatibleType(null, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfIncompatibleType_WithNameTypeNull()
//        {
//            Exceptions.ThrowIfIncompatibleType(1, ExceptionsTest.name,
//             null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfIncompatibleType_WithoutNameTypeNull()
//        {
//            Exceptions.ThrowIfIncompatibleType(1, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfIncompatibleType_WithNameValueNullTypeNull()
//        {
//            Exceptions.ThrowIfIncompatibleType(null,
//             ExceptionsTest.name, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfIncompatibleType_WithoutNameValueNullTypeNull()
//        {
//            Exceptions.ThrowIfIncompatibleType(null, null);
//        }
        
        [Test]
        public void
         TestThrowIfIncompatibleType_PassGrandparentTypeWithName()
        {
            Assert.AreEqual(typeof(object), (new object()).GetType());
            Exceptions.ThrowIfIncompatibleType(1, ExceptionsTest.name,
             typeof(object));
        }
        
        [Test]
        public void
         TestThrowIfIncompatibleType_PassGrandparentTypeWithoutName()
        {
            Assert.AreEqual(typeof(object), (new object()).GetType());
            Exceptions.ThrowIfIncompatibleType(1, typeof(object));
        }
        #endregion
        
        #region ThrowIfInvalidEnumValue() tests
        [Test]
        public void TestThrowIfInvalidEnumValue_Int32PassWithName()
        {
            Assert.AreEqual(typeof(int), 1.GetType());
            Exceptions.ThrowIfInvalidEnumValue(1, ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType(1));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_Int32PassWithoutName()
        {
            Assert.AreEqual(typeof(int), 1.GetType());
            Exceptions.ThrowIfInvalidEnumValue(1,
             TemporaryTypeBuilder.CreateEnumType(1));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithName)]
        public void TestThrowIfInvalidEnumValue_Int32FailWithName()
        {
            Assert.AreEqual(typeof(int), 1.GetType());
            Exceptions.ThrowIfInvalidEnumValue(2, ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType(1));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithoutName)]
        public void TestThrowIfInvalidEnumValue_Int32FailWithoutName()
        {
            Assert.AreEqual(typeof(int), 1.GetType());
            Exceptions.ThrowIfInvalidEnumValue(2,
             TemporaryTypeBuilder.CreateEnumType(1));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_StringPassWithName()
        {
            Exceptions.ThrowIfInvalidEnumValue("MyValue",
             ExceptionsTest.name, TemporaryTypeBuilder.CreateEnumType(1));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_StringPassWithoutName()
        {
            Exceptions.ThrowIfInvalidEnumValue("MyValue",
             TemporaryTypeBuilder.CreateEnumType(1));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageOverflowedWithName)]
        public void TestThrowIfInvalidEnumValue_StringFailWithName()
        {
            Exceptions.ThrowIfInvalidEnumValue("NonexistentValue",
             ExceptionsTest.name, TemporaryTypeBuilder.CreateEnumType(1));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageOverflowedWithoutName)]
        public void TestThrowIfInvalidEnumValue_StringFailWithoutName()
        {
            Exceptions.ThrowIfInvalidEnumValue("NonexistentValue",
             TemporaryTypeBuilder.CreateEnumType(1));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_BytePassWithName()
        {
            Exceptions.ThrowIfInvalidEnumValue((byte)1,
             ExceptionsTest.name, TemporaryTypeBuilder.CreateEnumType((byte)1));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_BytePassWithoutName()
        {
            Exceptions.ThrowIfInvalidEnumValue((byte)1,
             TemporaryTypeBuilder.CreateEnumType((byte)1));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithName)]
        public void TestThrowIfInvalidEnumValue_ByteFailWithName()
        {
            Exceptions.ThrowIfInvalidEnumValue((byte)2,
             ExceptionsTest.name, TemporaryTypeBuilder.CreateEnumType((byte)1));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithoutName)]
        public void TestThrowIfInvalidEnumValue_ByteFailWithoutName()
        {
            Exceptions.ThrowIfInvalidEnumValue((byte)2,
             TemporaryTypeBuilder.CreateEnumType((byte)1));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_Int16PassWithName()
        {
            Exceptions.ThrowIfInvalidEnumValue((short)1,
             ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType((short)1));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_Int16PassWithoutName()
        {
            Exceptions.ThrowIfInvalidEnumValue((short)1,
             TemporaryTypeBuilder.CreateEnumType((short)1));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithName)]
        public void TestThrowIfInvalidEnumValue_Int16FailWithName()
        {
            Exceptions.ThrowIfInvalidEnumValue((short)2,
             ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType((short)1));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithoutName)]
        public void TestThrowIfInvalidEnumValue_Int16FailWithoutName()
        {
            Exceptions.ThrowIfInvalidEnumValue((short)2,
             TemporaryTypeBuilder.CreateEnumType((short)1));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_Int64PassWithName()
        {
            Assert.AreEqual(typeof(long), 1L.GetType());
            Exceptions.ThrowIfInvalidEnumValue(1L, ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType(1L));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_Int64PassWithoutName()
        {
            Assert.AreEqual(typeof(long), 1L.GetType());
            Exceptions.ThrowIfInvalidEnumValue(1L,
             TemporaryTypeBuilder.CreateEnumType(1L));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithName)]
        public void TestThrowIfInvalidEnumValue_Int64FailWithName()
        {
            Assert.AreEqual(typeof(long), 1L.GetType());
            Exceptions.ThrowIfInvalidEnumValue(2L, ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType(1L));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithoutName)]
        public void TestThrowIfInvalidEnumValue_Int64FailWithoutName()
        {
            Assert.AreEqual(typeof(long), 1L.GetType());
            Exceptions.ThrowIfInvalidEnumValue(2L,
             TemporaryTypeBuilder.CreateEnumType(1L));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageOverflowedWithName)]
        public void TestThrowIfInvalidEnumValue_Int64LargeFailWithName()
        {
            Assert.AreEqual(typeof(long), 1L.GetType());
            Exceptions.ThrowIfInvalidEnumValue((long)int.MaxValue + 1L,
             ExceptionsTest.name, TemporaryTypeBuilder.CreateEnumType(1L));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageOverflowedWithoutName)]
        public void
         TestThrowIfInvalidEnumValue_Int64LargeFailWithoutName()
        {
            Assert.AreEqual(typeof(long), 1L.GetType());
            Exceptions.ThrowIfInvalidEnumValue((long)int.MaxValue + 1L,
             TemporaryTypeBuilder.CreateEnumType(1L));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_UInt32PassWithName()
        {
            Assert.AreEqual(typeof(uint), 1U.GetType());
            Exceptions.ThrowIfInvalidEnumValue(1U, ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType(1U));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_UInt32PassWithoutName()
        {
            Assert.AreEqual(typeof(uint), 1U.GetType());
            Exceptions.ThrowIfInvalidEnumValue(1U,
             TemporaryTypeBuilder.CreateEnumType(1U));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithName)]
        public void TestThrowIfInvalidEnumValue_UInt32FailWithName()
        {
            Assert.AreEqual(typeof(uint), 1U.GetType());
            Exceptions.ThrowIfInvalidEnumValue(2U, ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType(1U));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithoutName)]
        public void TestThrowIfInvalidEnumValue_UInt32FailWithoutName()
        {
            Assert.AreEqual(typeof(uint), 1U.GetType());
            Exceptions.ThrowIfInvalidEnumValue(2U,
             TemporaryTypeBuilder.CreateEnumType(1U));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageOverflowedWithName)]
        public void
         TestThrowIfInvalidEnumValue_UInt32LargeFailWithName()
        {
            Assert.AreEqual(typeof(uint), 1U.GetType());
            Exceptions.ThrowIfInvalidEnumValue((uint)int.MaxValue + 1U,
             ExceptionsTest.name, TemporaryTypeBuilder.CreateEnumType(1U));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageOverflowedWithoutName)]
        public void
         TestThrowIfInvalidEnumValue_UInt32LargeFailWithoutName()
        {
            Assert.AreEqual(typeof(uint), 1U.GetType());
            Exceptions.ThrowIfInvalidEnumValue((uint)int.MaxValue + 1U,
             TemporaryTypeBuilder.CreateEnumType(1U));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_SBytePassWithName()
        {
            Exceptions.ThrowIfInvalidEnumValue((sbyte)1,
             ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType((sbyte)1));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_SBytePassWithoutName()
        {
            Exceptions.ThrowIfInvalidEnumValue((sbyte)1,
             TemporaryTypeBuilder.CreateEnumType((sbyte)1));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithName)]
        public void TestThrowIfInvalidEnumValue_SByteFailWithName()
        {
            Exceptions.ThrowIfInvalidEnumValue((sbyte)2,
             ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType((sbyte)1));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithoutName)]
        public void TestThrowIfInvalidEnumValue_SByteFailWithoutName()
        {
            Exceptions.ThrowIfInvalidEnumValue((sbyte)2,
             TemporaryTypeBuilder.CreateEnumType((sbyte)1));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_UInt16PassWithName()
        {
            Exceptions.ThrowIfInvalidEnumValue((ushort)1,
             ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType((ushort)1));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_UInt16PassWithoutName()
        {
            Exceptions.ThrowIfInvalidEnumValue((ushort)1,
             TemporaryTypeBuilder.CreateEnumType((ushort)1));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithName)]
        public void TestThrowIfInvalidEnumValue_UInt16FailWithName()
        {
            Exceptions.ThrowIfInvalidEnumValue((ushort)2,
             ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType((ushort)1));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithoutName)]
        public void TestThrowIfInvalidEnumValue_UInt16FailWithoutName()
        {
            Exceptions.ThrowIfInvalidEnumValue((ushort)2,
             TemporaryTypeBuilder.CreateEnumType((ushort)1));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_UInt64PassWithName()
        {
            Assert.AreEqual(typeof(ulong), 1UL.GetType());
            Exceptions.ThrowIfInvalidEnumValue(1UL, ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType(1UL));
        }
        
        [Test]
        public void TestThrowIfInvalidEnumValue_UInt64PassWithoutName()
        {
            Assert.AreEqual(typeof(ulong), 1UL.GetType());
            Exceptions.ThrowIfInvalidEnumValue(1UL,
             TemporaryTypeBuilder.CreateEnumType(1UL));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithName)]
        public void TestThrowIfInvalidEnumValue_UInt64FailWithName()
        {
            Assert.AreEqual(typeof(ulong), 1UL.GetType());
            Exceptions.ThrowIfInvalidEnumValue(2UL, ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType(1UL));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageWithoutName)]
        public void TestThrowIfInvalidEnumValue_UInt64FailWithoutName()
        {
            Assert.AreEqual(typeof(ulong), 1UL.GetType());
            Exceptions.ThrowIfInvalidEnumValue(2UL,
             TemporaryTypeBuilder.CreateEnumType(1UL));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageOverflowedWithName)]
        public void
         TestThrowIfInvalidEnumValue_UInt64LargeFailWithName()
        {
            Assert.AreEqual(typeof(ulong), 1UL.GetType());
            Exceptions.ThrowIfInvalidEnumValue(
             (ulong)int.MaxValue + 1UL, ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType(1UL));
        }
        
        [Test]
        [ExpectedException(typeof(InvalidEnumArgumentException),
         ExceptionsTest.enumMessageOverflowedWithoutName)]
        public void
         TestThrowIfInvalidEnumValue_UInt64LargeFailWithoutName()
        {
            Assert.AreEqual(typeof(ulong), 1UL.GetType());
            Exceptions.ThrowIfInvalidEnumValue(
             (ulong)int.MaxValue + 1UL,
             TemporaryTypeBuilder.CreateEnumType(1UL));
        }
        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_Int32WithNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1, ExceptionsTest.name,
//             null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_Int32WithoutNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_StringWithNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue("MyValue",
//             ExceptionsTest.name, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_StringWithoutNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue("MyValue", null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_ByteWithNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((byte)1,
//             ExceptionsTest.name, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_ByteWithoutNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((byte)1, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_Int16WithNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((short)1,
//             ExceptionsTest.name, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_Int16WithoutNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((short)1, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_Int64WithNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1L,
//             ExceptionsTest.name, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_Int64WithoutNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1L, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_UInt32WithNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1U,
//             ExceptionsTest.name, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt32WithoutNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1U, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_SByteWithNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((sbyte)1,
//             ExceptionsTest.name, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_SByteWithoutNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((sbyte)1, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_UInt16WithNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((ushort)1,
//             ExceptionsTest.name, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt16WithoutNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((ushort)1, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_UInt64WithNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1UL,
//             ExceptionsTest.name, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt64WithoutNameTypeNull()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1UL, null);
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_Int32WithNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1, ExceptionsTest.name,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute(1));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_Int32WithoutNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute(1));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_StringWithNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue("MyValue",
//             ExceptionsTest.name,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute(1));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_StringWithoutNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue("MyValue",
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute(1));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_ByteWithNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((byte)1,
//             ExceptionsTest.name,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute((byte)1));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_ByteWithoutNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((byte)1,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute((byte)1));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_Int16WithNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((short)1,
//             ExceptionsTest.name,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute((short)1));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_Int16WithoutNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((short)1,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute((short)1));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_Int64WithNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1L,
//             ExceptionsTest.name,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute(1L));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_Int64WithoutNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1L,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute(1L));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt32WithNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1U,
//             ExceptionsTest.name,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute(1U));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt32WithoutNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1U,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute(1U));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void TestThrowIfInvalidEnumValue_SByteWithNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((sbyte)1,
//             ExceptionsTest.name,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute((sbyte)1));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_SByteWithoutNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((sbyte)1,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute((sbyte)1));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt16WithNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((ushort)1,
//             ExceptionsTest.name,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute((ushort)1));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt16WithoutNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((ushort)1,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute((ushort)1));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt64WithNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1UL,
//             ExceptionsTest.name,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute(1UL));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt64WithoutNameTypeFlags()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1UL,
//             TemporaryTypeBuilder.CreateEnumTypeWithFlagsAttribute(1UL));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_Int32WithNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1, ExceptionsTest.name,
//             typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_Int32WithoutNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_StringWithNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue("MyValue",
//             ExceptionsTest.name, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_StringWithoutNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue("MyValue", typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_ByteWithNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((byte)1,
//             ExceptionsTest.name, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_ByteWithoutNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((byte)1, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_Int16WithNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((short)1,
//             ExceptionsTest.name, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_Int16WithoutNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((short)1, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_Int64WithNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1L,
//             ExceptionsTest.name, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_Int64WithoutNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1L, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt32WithNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1U,
//             ExceptionsTest.name, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt32WithoutNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1U, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_SByteWithNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((sbyte)1,
//             ExceptionsTest.name, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_SByteWithoutNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((sbyte)1, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt16WithNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((ushort)1,
//             ExceptionsTest.name, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt16WithoutNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue((ushort)1, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt64WithNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1UL,
//             ExceptionsTest.name, typeof(char));
//        }
//        
//        [Test]
//        [Ignore("Fails assertion.")]
//        public void
//         TestThrowIfInvalidEnumValue_UInt64WithoutNameTypeNotEnum()
//        {
//            Exceptions.ThrowIfInvalidEnumValue(1UL, typeof(char));
//        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_Int32WithNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue(1, ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType((byte)1));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_Int32WithoutNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue(1,
             TemporaryTypeBuilder.CreateEnumType((byte)1));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_ByteWithNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue((byte)1,
             ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType((short)1));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_ByteWithoutNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue((byte)1,
             TemporaryTypeBuilder.CreateEnumType((short)1));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_Int16WithNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue((short)1,
             ExceptionsTest.name, TemporaryTypeBuilder.CreateEnumType(1L));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_Int16WithoutNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue((short)1,
             TemporaryTypeBuilder.CreateEnumType(1L));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_Int64WithNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue(1L,
             ExceptionsTest.name, TemporaryTypeBuilder.CreateEnumType(1U));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_Int64WithoutNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue(1L,
             TemporaryTypeBuilder.CreateEnumType(1U));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_UInt32WithNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue(1U,
             ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType((sbyte)1));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_UInt32WithoutNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue(1U,
             TemporaryTypeBuilder.CreateEnumType((sbyte)1));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_SByteWithNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue((sbyte)1,
             ExceptionsTest.name,
             TemporaryTypeBuilder.CreateEnumType((ushort)1));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_SByteWithoutNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue((sbyte)1,
             TemporaryTypeBuilder.CreateEnumType((ushort)1));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_UInt16WithNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue((ushort)1,
             ExceptionsTest.name, TemporaryTypeBuilder.CreateEnumType(1UL));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_UInt16WithoutNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue((ushort)1,
             TemporaryTypeBuilder.CreateEnumType(1UL));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_UInt64WithNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue(1UL,
             ExceptionsTest.name, TemporaryTypeBuilder.CreateEnumType(1));
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void
         TestThrowIfInvalidEnumValue_UInt64WithoutNameTypeDifferent()
        {
            Exceptions.ThrowIfInvalidEnumValue(1UL,
             TemporaryTypeBuilder.CreateEnumType(1));
        }
        #endregion
        
        #region ThrowIfNull() tests
        [Test]
        public void TestThrowIfNull_PassWithName()
        {
            Exceptions.ThrowIfNull(1, ExceptionsTest.name);
        }
        
        [Test]
        public void TestThrowIfNull_PassWithoutName()
        {
            Exceptions.ThrowIfNull(1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentNullException),
         @"Value cannot be null.
Parameter name: myArgument")]
        public void TestThrowIfNull_FailWithName()
        {
            Exceptions.ThrowIfNull(null, ExceptionsTest.name);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentNullException),
         "Value cannot be null.")]
        public void TestThrowIfNull_FailWithoutName()
        {
            Exceptions.ThrowIfNull(null);
        }
        #endregion
        
        #region ThrowIfOutOfRange() tests
        [Test]
        public void TestThrowIfOutOfRange_Int32PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRange(1, ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int32PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(1, 1, 3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int32PassMidWithName()
        {
            Exceptions.ThrowIfOutOfRange(2, ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int32PassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2, 1, 3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int32PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRange(3, ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int32PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(3, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "0.")]
        public void TestThrowIfOutOfRange_Int32FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRange(0, ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "0.")]
        public void TestThrowIfOutOfRange_Int32FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(0, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "4.")]
        public void TestThrowIfOutOfRange_Int32FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRange(4, ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "4.")]
        public void TestThrowIfOutOfRange_Int32FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(4, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithName + "2.")]
        public void TestThrowIfOutOfRange_Int32FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRange(2, ExceptionsTest.name, 3, 1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRange_Int32FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2, 3, 1);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_BytePassMinWithName()
        {
            Exceptions.ThrowIfOutOfRange((byte)1, ExceptionsTest.name,
             (byte)1, (byte)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_BytePassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((byte)1, (byte)1, (byte)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_BytePassMidWithName()
        {
            Exceptions.ThrowIfOutOfRange((byte)2, ExceptionsTest.name,
             (byte)1, (byte)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_BytePassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((byte)2, (byte)1, (byte)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_BytePassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRange((byte)3, ExceptionsTest.name,
             (byte)1, (byte)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_BytePassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((byte)3, (byte)1, (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "0.")]
        public void TestThrowIfOutOfRange_ByteFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRange((byte)0, ExceptionsTest.name,
             (byte)1, (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "0.")]
        public void TestThrowIfOutOfRange_ByteFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((byte)0, (byte)1, (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "4.")]
        public void TestThrowIfOutOfRange_ByteFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRange((byte)4, ExceptionsTest.name,
             (byte)1, (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "4.")]
        public void TestThrowIfOutOfRange_ByteFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((byte)4, (byte)1, (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithName + "2.")]
        public void TestThrowIfOutOfRange_ByteFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRange((byte)2, ExceptionsTest.name,
             (byte)3, (byte)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRange_ByteFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((byte)2, (byte)3, (byte)1);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_CharPassMinWithName()
        {
            Exceptions.ThrowIfOutOfRange((char)1, ExceptionsTest.name,
             (char)1, (char)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_CharPassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((char)1, (char)1, (char)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_CharPassMidWithName()
        {
            Exceptions.ThrowIfOutOfRange((char)2, ExceptionsTest.name,
             (char)1, (char)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_CharPassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((char)2, (char)1, (char)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_CharPassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRange((char)3, ExceptionsTest.name,
             (char)1, (char)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_CharPassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((char)3, (char)1, (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName_Char + "\u0000.")]
        public void TestThrowIfOutOfRange_CharFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRange((char)0, ExceptionsTest.name,
             (char)1, (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName_Char + "\u0000.")]
        public void TestThrowIfOutOfRange_CharFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((char)0, (char)1, (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName_Char + "\u0004.")]
        public void TestThrowIfOutOfRange_CharFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRange((char)4, ExceptionsTest.name,
             (char)1, (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName_Char + "\u0004.")]
        public void TestThrowIfOutOfRange_CharFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((char)4, (char)1, (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithName_Char + "\u0002.")]
        public void TestThrowIfOutOfRange_CharFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRange((char)2, ExceptionsTest.name,
             (char)3, (char)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithoutName_Char + "\u0002.")]
        public void
         TestThrowIfOutOfRange_CharFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((char)2, (char)3, (char)1);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_DecimalPassMinWithName()
        {
            Exceptions.ThrowIfOutOfRange(1M, ExceptionsTest.name, 1M,
             3M);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_DecimalPassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(1M, 1M, 3M);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_DecimalPassMidWithName()
        {
            Exceptions.ThrowIfOutOfRange(2M, ExceptionsTest.name, 1M,
             3M);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_DecimalPassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2M, 1M, 3M);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_DecimalPassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRange(3M, ExceptionsTest.name, 1M,
             3M);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_DecimalPassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(3M, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "0.")]
        public void TestThrowIfOutOfRange_DecimalFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRange(0M, ExceptionsTest.name, 1M,
             3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "0.")]
        public void TestThrowIfOutOfRange_DecimalFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(0M, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "4.")]
        public void TestThrowIfOutOfRange_DecimalFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRange(4M, ExceptionsTest.name, 1M,
             3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "4.")]
        public void TestThrowIfOutOfRange_DecimalFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(4M, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRange_DecimalFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRange(2M, ExceptionsTest.name, 3M,
             1M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRange_DecimalFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2M, 3M, 1M);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_DoublePassMinWithName()
        {
            Exceptions.ThrowIfOutOfRange(1D, ExceptionsTest.name, 1D,
             3D);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_DoublePassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(1D, 1D, 3D);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_DoublePassMidWithName()
        {
            Exceptions.ThrowIfOutOfRange(2D, ExceptionsTest.name, 1D,
             3D);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_DoublePassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2D, 1D, 3D);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_DoublePassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRange(3D, ExceptionsTest.name, 1D,
             3D);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_DoublePassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(3D, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "0.")]
        public void TestThrowIfOutOfRange_DoubleFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRange(0D, ExceptionsTest.name, 1D,
             3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "0.")]
        public void TestThrowIfOutOfRange_DoubleFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(0D, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "4.")]
        public void TestThrowIfOutOfRange_DoubleFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRange(4D, ExceptionsTest.name, 1D,
             3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "4.")]
        public void TestThrowIfOutOfRange_DoubleFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(4D, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRange_DoubleFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRange(2D, ExceptionsTest.name, 3D,
             1D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRange_DoubleFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2D, 3D, 1D);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_SinglePassMinWithName()
        {
            Exceptions.ThrowIfOutOfRange(1F, ExceptionsTest.name, 1F,
             3F);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_SinglePassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(1F, 1F, 3F);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_SinglePassMidWithName()
        {
            Exceptions.ThrowIfOutOfRange(2F, ExceptionsTest.name, 1F,
             3F);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_SinglePassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2F, 1F, 3F);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_SinglePassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRange(3F, ExceptionsTest.name, 1F,
             3F);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_SinglePassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(3F, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "0.")]
        public void TestThrowIfOutOfRange_SingleFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRange(0F, ExceptionsTest.name, 1F,
             3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "0.")]
        public void TestThrowIfOutOfRange_SingleFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(0F, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "4.")]
        public void TestThrowIfOutOfRange_SingleFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRange(4F, ExceptionsTest.name, 1F,
             3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "4.")]
        public void TestThrowIfOutOfRange_SingleFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(4F, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRange_SingleFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRange(2F, ExceptionsTest.name, 3F,
             1F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRange_SingleFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2F, 3F, 1F);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int16PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRange((short)1, ExceptionsTest.name,
             (short)1, (short)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int16PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((short)1, (short)1, (short)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int16PassMidWithName()
        {
            Exceptions.ThrowIfOutOfRange((short)2, ExceptionsTest.name,
             (short)1, (short)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int16PassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((short)2, (short)1, (short)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int16PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRange((short)3, ExceptionsTest.name,
             (short)1, (short)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int16PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((short)3, (short)1, (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "0.")]
        public void TestThrowIfOutOfRange_Int16FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRange((short)0, ExceptionsTest.name,
             (short)1, (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "0.")]
        public void TestThrowIfOutOfRange_Int16FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((short)0, (short)1, (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "4.")]
        public void TestThrowIfOutOfRange_Int16FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRange((short)4, ExceptionsTest.name,
             (short)1, (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "4.")]
        public void TestThrowIfOutOfRange_Int16FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((short)4, (short)1, (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithName + "2.")]
        public void TestThrowIfOutOfRange_Int16FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRange((short)2, ExceptionsTest.name,
             (short)3, (short)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRange_Int16FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((short)2, (short)3, (short)1);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int64PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRange(1L, ExceptionsTest.name, 1L,
             3L);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int64PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(1L, 1L, 3L);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int64PassMidWithName()
        {
            Exceptions.ThrowIfOutOfRange(2L, ExceptionsTest.name, 1L,
             3L);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int64PassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2L, 1L, 3L);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int64PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRange(3L, ExceptionsTest.name, 1L,
             3L);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_Int64PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(3L, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "0.")]
        public void TestThrowIfOutOfRange_Int64FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRange(0L, ExceptionsTest.name, 1L,
             3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "0.")]
        public void TestThrowIfOutOfRange_Int64FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(0L, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "4.")]
        public void TestThrowIfOutOfRange_Int64FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRange(4L, ExceptionsTest.name, 1L,
             3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "4.")]
        public void TestThrowIfOutOfRange_Int64FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(4L, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRange_Int64FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRange(2L, ExceptionsTest.name, 3L,
             1L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRange_Int64FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2L, 3L, 1L);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt32PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRange(1U, ExceptionsTest.name, 1U,
             3U);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt32PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(1U, 1U, 3U);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt32PassMidWithName()
        {
            Exceptions.ThrowIfOutOfRange(2U, ExceptionsTest.name, 1U,
             3U);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt32PassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2U, 1U, 3U);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt32PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRange(3U, ExceptionsTest.name, 1U,
             3U);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt32PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(3U, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "0.")]
        public void TestThrowIfOutOfRange_UInt32FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRange(0U, ExceptionsTest.name, 1U,
             3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "0.")]
        public void TestThrowIfOutOfRange_UInt32FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(0U, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "4.")]
        public void TestThrowIfOutOfRange_UInt32FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRange(4U, ExceptionsTest.name, 1U,
             3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "4.")]
        public void TestThrowIfOutOfRange_UInt32FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(4U, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRange_UInt32FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRange(2U, ExceptionsTest.name, 3U,
             1U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRange_UInt32FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2U, 3U, 1U);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_SBytePassMinWithName()
        {
            Exceptions.ThrowIfOutOfRange((sbyte)1, ExceptionsTest.name,
             (sbyte)1, (sbyte)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_SBytePassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((sbyte)1, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_SBytePassMidWithName()
        {
            Exceptions.ThrowIfOutOfRange((sbyte)2, ExceptionsTest.name,
             (sbyte)1, (sbyte)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_SBytePassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((sbyte)2, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_SBytePassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRange((sbyte)3, ExceptionsTest.name,
             (sbyte)1, (sbyte)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_SBytePassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((sbyte)3, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "0.")]
        public void TestThrowIfOutOfRange_SByteFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRange((sbyte)0, ExceptionsTest.name,
             (sbyte)1, (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "0.")]
        public void TestThrowIfOutOfRange_SByteFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((sbyte)0, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "4.")]
        public void TestThrowIfOutOfRange_SByteFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRange((sbyte)4, ExceptionsTest.name,
             (sbyte)1, (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "4.")]
        public void TestThrowIfOutOfRange_SByteFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((sbyte)4, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithName + "2.")]
        public void TestThrowIfOutOfRange_SByteFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRange((sbyte)2, ExceptionsTest.name,
             (sbyte)3, (sbyte)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRange_SByteFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((sbyte)2, (sbyte)3, (sbyte)1);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt16PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRange((ushort)1, ExceptionsTest.name,
             (ushort)1, (ushort)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt16PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((ushort)1, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt16PassMidWithName()
        {
            Exceptions.ThrowIfOutOfRange((ushort)2, ExceptionsTest.name,
             (ushort)1, (ushort)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt16PassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((ushort)2, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt16PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRange((ushort)3, ExceptionsTest.name,
             (ushort)1, (ushort)3);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt16PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((ushort)3, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "0.")]
        public void TestThrowIfOutOfRange_UInt16FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRange((ushort)0, ExceptionsTest.name,
             (ushort)1, (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "0.")]
        public void TestThrowIfOutOfRange_UInt16FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((ushort)0, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "4.")]
        public void TestThrowIfOutOfRange_UInt16FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRange((ushort)4, ExceptionsTest.name,
             (ushort)1, (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "4.")]
        public void TestThrowIfOutOfRange_UInt16FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((ushort)4, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithName + "2.")]
        public void TestThrowIfOutOfRange_UInt16FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRange((ushort)2, ExceptionsTest.name,
             (ushort)3, (ushort)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRange_UInt16FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRange((ushort)2, (ushort)3,
             (ushort)1);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt64PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRange(1UL, ExceptionsTest.name, 1UL,
             3UL);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt64PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(1UL, 1UL, 3UL);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt64PassMidWithName()
        {
            Exceptions.ThrowIfOutOfRange(2UL, ExceptionsTest.name, 1UL,
             3UL);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt64PassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2UL, 1UL, 3UL);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt64PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRange(3UL, ExceptionsTest.name, 1UL,
             3UL);
        }
        
        [Test]
        public void TestThrowIfOutOfRange_UInt64PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(3UL, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "0.")]
        public void TestThrowIfOutOfRange_UInt64FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRange(0UL, ExceptionsTest.name, 1UL,
             3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "0.")]
        public void TestThrowIfOutOfRange_UInt64FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(0UL, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithName + "4.")]
        public void TestThrowIfOutOfRange_UInt64FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRange(4UL, ExceptionsTest.name, 1UL,
             3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeMessageWithoutName + "4.")]
        public void TestThrowIfOutOfRange_UInt64FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(4UL, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRange_UInt64FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRange(2UL, ExceptionsTest.name, 3UL,
             1UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRange_UInt64FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRange(2UL, 3UL, 1UL);
        }
        #endregion
        
        #region ThrowIfOutOfRangeExclusive() tests
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_Int32PassMidWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2,
             ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_Int32PassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int32FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1,
             ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int32FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int32FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3,
             ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int32FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int32FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2,
             ExceptionsTest.name, 3, 1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int32FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2, 3, 1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_BytePassMidWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((byte)2,
             ExceptionsTest.name, (byte)1, (byte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_BytePassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((byte)2, (byte)1,
             (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_ByteFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((byte)1,
             ExceptionsTest.name, (byte)1, (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_ByteFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((byte)1, (byte)1,
             (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_ByteFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((byte)3,
             ExceptionsTest.name, (byte)1, (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_ByteFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((byte)3, (byte)1,
             (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_ByteFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((byte)2,
             ExceptionsTest.name, (byte)3, (byte)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_ByteFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((byte)2, (byte)3,
             (byte)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_CharPassMidWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((char)2,
             ExceptionsTest.name, (char)1, (char)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_CharPassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((char)2, (char)1,
             (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName_Char + "\u0001.")]
        public void
         TestThrowIfOutOfRangeExclusive_CharFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((char)1,
             ExceptionsTest.name, (char)1, (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName_Char + "\u0001.")]
        public void
         TestThrowIfOutOfRangeExclusive_CharFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((char)1, (char)1,
             (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName_Char + "\u0003.")]
        public void
         TestThrowIfOutOfRangeExclusive_CharFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((char)3,
             ExceptionsTest.name, (char)1, (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName_Char + "\u0003.")]
        public void
         TestThrowIfOutOfRangeExclusive_CharFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((char)3, (char)1,
             (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithName_Char + "\u0002.")]
        public void
         TestThrowIfOutOfRangeExclusive_CharFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((char)2,
             ExceptionsTest.name, (char)3, (char)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithoutName_Char
         + "\u0002.")]
        public void
         TestThrowIfOutOfRangeExclusive_CharFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((char)2, (char)3,
             (char)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_DecimalPassMidWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2M,
             ExceptionsTest.name, 1M, 3M);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_DecimalPassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2M, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_DecimalFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1M,
             ExceptionsTest.name, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_DecimalFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1M, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_DecimalFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3M,
             ExceptionsTest.name, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_DecimalFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3M, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_DecimalFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2M,
             ExceptionsTest.name, 3M, 1M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_DecimalFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2M, 3M, 1M);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_DoublePassMidWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2D,
             ExceptionsTest.name, 1D, 3D);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_DoublePassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2D, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_DoubleFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1D,
             ExceptionsTest.name, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_DoubleFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1D, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_DoubleFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3D,
             ExceptionsTest.name, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_DoubleFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3D, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_DoubleFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2D,
             ExceptionsTest.name, 3D, 1D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_DoubleFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2D, 3D, 1D);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_SinglePassMidWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2F,
             ExceptionsTest.name, 1F, 3F);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_SinglePassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2F, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_SingleFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1F,
             ExceptionsTest.name, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_SingleFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1F, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_SingleFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3F,
             ExceptionsTest.name, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_SingleFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3F, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_SingleFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2F,
             ExceptionsTest.name, 3F, 1F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_SingleFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2F, 3F, 1F);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_Int16PassMidWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((short)2,
             ExceptionsTest.name, (short)1, (short)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_Int16PassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((short)2, (short)1,
             (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int16FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((short)1,
             ExceptionsTest.name, (short)1, (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int16FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((short)1, (short)1,
             (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int16FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((short)3,
             ExceptionsTest.name, (short)1, (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int16FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((short)3, (short)1,
             (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithName + "2.")]
        public void TestThrowIfOutOfRangeExclusive_Int16FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((short)2,
             ExceptionsTest.name, (short)3, (short)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int16FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((short)2, (short)3,
             (short)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_Int64PassMidWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2L,
             ExceptionsTest.name, 1L, 3L);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_Int64PassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2L, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int64FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1L,
             ExceptionsTest.name, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int64FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1L, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int64FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3L,
             ExceptionsTest.name, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int64FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3L, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int64FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2L,
             ExceptionsTest.name, 3L, 1L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_Int64FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2L, 3L, 1L);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_UInt32PassMidWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2U,
             ExceptionsTest.name, 1U, 3U);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_UInt32PassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2U, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt32FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1U,
             ExceptionsTest.name, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt32FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1U, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt32FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3U,
             ExceptionsTest.name, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt32FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3U, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt32FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2U,
             ExceptionsTest.name, 3U, 1U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt32FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2U, 3U, 1U);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_SBytePassMidWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((sbyte)2,
             ExceptionsTest.name, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_SBytePassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((sbyte)2, (sbyte)1,
             (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_SByteFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((sbyte)1,
             ExceptionsTest.name, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_SByteFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((sbyte)1, (sbyte)1,
             (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_SByteFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((sbyte)3,
             ExceptionsTest.name, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_SByteFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((sbyte)3, (sbyte)1,
             (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_SByteFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((sbyte)2,
             ExceptionsTest.name, (sbyte)3, (sbyte)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_SByteFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((sbyte)2, (sbyte)3,
             (sbyte)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_UInt16PassMidWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((ushort)2,
             ExceptionsTest.name, (ushort)1, (ushort)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_UInt16PassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((ushort)2, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt16FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((ushort)1,
             ExceptionsTest.name, (ushort)1, (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt16FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((ushort)1, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt16FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((ushort)3,
             ExceptionsTest.name, (ushort)1, (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt16FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((ushort)3, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt16FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((ushort)2,
             ExceptionsTest.name, (ushort)3, (ushort)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt16FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive((ushort)2, (ushort)3,
             (ushort)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_UInt64PassMidWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2UL,
             ExceptionsTest.name, 1UL, 3UL);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeExclusive_UInt64PassMidWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2UL, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt64FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1UL,
             ExceptionsTest.name, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt64FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(1UL, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt64FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3UL,
             ExceptionsTest.name, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt64FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(3UL, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt64FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2UL,
             ExceptionsTest.name, 3UL, 1UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeExclusiveReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeExclusive_UInt64FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeExclusive(2UL, 3UL, 1UL);
        }
        #endregion
        
        #region ThrowIfOutOfRangeIncludeMax() tests
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int32PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2,
             ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int32PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2, 1, 3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int32PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3,
             ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int32PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int32FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1,
             ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int32FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int32FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4,
             ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int32FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int32FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2,
             ExceptionsTest.name, 3, 1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int32FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2, 3, 1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_BytePassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((byte)2,
             ExceptionsTest.name, (byte)1, (byte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_BytePassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((byte)2, (byte)1,
             (byte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_BytePassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((byte)3,
             ExceptionsTest.name, (byte)1, (byte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_BytePassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((byte)3, (byte)1,
             (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_ByteFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((byte)1,
             ExceptionsTest.name, (byte)1, (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_ByteFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((byte)1, (byte)1,
             (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_ByteFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((byte)4,
             ExceptionsTest.name, (byte)1, (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_ByteFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((byte)4, (byte)1,
             (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_ByteFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((byte)2,
             ExceptionsTest.name, (byte)3, (byte)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_ByteFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((byte)2, (byte)3,
             (byte)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_CharPassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((char)2,
             ExceptionsTest.name, (char)1, (char)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_CharPassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((char)2, (char)1,
             (char)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_CharPassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((char)3,
             ExceptionsTest.name, (char)1, (char)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_CharPassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((char)3, (char)1,
             (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName_Char + "\u0001.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_CharFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((char)1,
             ExceptionsTest.name, (char)1, (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName_Char + "\u0001.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_CharFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((char)1, (char)1,
             (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName_Char + "\u0004.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_CharFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((char)4,
             ExceptionsTest.name, (char)1, (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName_Char + "\u0004.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_CharFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((char)4, (char)1,
             (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithName_Char + "\u0002.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_CharFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((char)2,
             ExceptionsTest.name, (char)3, (char)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithoutName_Char
         + "\u0002.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_CharFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((char)2, (char)3,
             (char)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_DecimalPassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2M,
             ExceptionsTest.name, 1M, 3M);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_DecimalPassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2M, 1M, 3M);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_DecimalPassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3M,
             ExceptionsTest.name, 1M, 3M);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_DecimalPassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3M, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_DecimalFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1M,
             ExceptionsTest.name, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_DecimalFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1M, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_DecimalFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4M,
             ExceptionsTest.name, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_DecimalFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4M, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_DecimalFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2M,
             ExceptionsTest.name, 3M, 1M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_DecimalFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2M, 3M, 1M);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_DoublePassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2D,
             ExceptionsTest.name, 1D, 3D);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_DoublePassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2D, 1D, 3D);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_DoublePassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3D,
             ExceptionsTest.name, 1D, 3D);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_DoublePassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3D, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_DoubleFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1D,
             ExceptionsTest.name, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_DoubleFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1D, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_DoubleFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4D,
             ExceptionsTest.name, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_DoubleFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4D, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_DoubleFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2D,
             ExceptionsTest.name, 3D, 1D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_DoubleFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2D, 3D, 1D);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_SinglePassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2F,
             ExceptionsTest.name, 1F, 3F);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_SinglePassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2F, 1F, 3F);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_SinglePassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3F,
             ExceptionsTest.name, 1F, 3F);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_SinglePassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3F, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_SingleFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1F,
             ExceptionsTest.name, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_SingleFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1F, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_SingleFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4F,
             ExceptionsTest.name, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_SingleFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4F, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_SingleFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2F,
             ExceptionsTest.name, 3F, 1F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_SingleFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2F, 3F, 1F);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int16PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((short)2,
             ExceptionsTest.name, (short)1, (short)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int16PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((short)2, (short)1,
             (short)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int16PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((short)3,
             ExceptionsTest.name, (short)1, (short)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int16PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((short)3, (short)1,
             (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int16FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((short)1,
             ExceptionsTest.name, (short)1, (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int16FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((short)1, (short)1,
             (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int16FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((short)4,
             ExceptionsTest.name, (short)1, (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int16FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((short)4, (short)1,
             (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int16FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((short)2,
             ExceptionsTest.name, (short)3, (short)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int16FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((short)2, (short)3,
             (short)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int64PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2L,
             ExceptionsTest.name, 1L, 3L);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int64PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2L, 1L, 3L);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int64PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3L,
             ExceptionsTest.name, 1L, 3L);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int64PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3L, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int64FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1L,
             ExceptionsTest.name, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int64FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1L, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int64FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4L,
             ExceptionsTest.name, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int64FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4L, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int64FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2L,
             ExceptionsTest.name, 3L, 1L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_Int64FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2L, 3L, 1L);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt32PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2U,
             ExceptionsTest.name, 1U, 3U);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt32PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2U, 1U, 3U);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt32PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3U,
             ExceptionsTest.name, 1U, 3U);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt32PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3U, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt32FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1U,
             ExceptionsTest.name, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt32FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1U, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt32FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4U,
             ExceptionsTest.name, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt32FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4U, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt32FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2U,
             ExceptionsTest.name, 3U, 1U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt32FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2U, 3U, 1U);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_SBytePassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((sbyte)2,
             ExceptionsTest.name, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_SBytePassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((sbyte)2, (sbyte)1,
             (sbyte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_SBytePassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((sbyte)3,
             ExceptionsTest.name, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_SBytePassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((sbyte)3, (sbyte)1,
             (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_SByteFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((sbyte)1,
             ExceptionsTest.name, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_SByteFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((sbyte)1, (sbyte)1,
             (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_SByteFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((sbyte)4,
             ExceptionsTest.name, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_SByteFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((sbyte)4, (sbyte)1,
             (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_SByteFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((sbyte)2,
             ExceptionsTest.name, (sbyte)3, (sbyte)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_SByteFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((sbyte)2, (sbyte)3,
             (sbyte)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt16PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((ushort)2,
             ExceptionsTest.name, (ushort)1, (ushort)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt16PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((ushort)2, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt16PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((ushort)3,
             ExceptionsTest.name, (ushort)1, (ushort)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt16PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((ushort)3, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt16FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((ushort)1,
             ExceptionsTest.name, (ushort)1, (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt16FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((ushort)1, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt16FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((ushort)4,
             ExceptionsTest.name, (ushort)1, (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt16FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((ushort)4, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt16FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((ushort)2,
             ExceptionsTest.name, (ushort)3, (ushort)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt16FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax((ushort)2, (ushort)3,
             (ushort)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt64PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2UL,
             ExceptionsTest.name, 1UL, 3UL);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt64PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2UL, 1UL, 3UL);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt64PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3UL,
             ExceptionsTest.name, 1UL, 3UL);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt64PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(3UL, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt64FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1UL,
             ExceptionsTest.name, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "1.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt64FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(1UL, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt64FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4UL,
             ExceptionsTest.name, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxMessageWithoutName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt64FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(4UL, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt64FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2UL,
             ExceptionsTest.name, 3UL, 1UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMaxReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMax_UInt64FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMax(2UL, 3UL, 1UL);
        }
        #endregion
        
        #region ThrowIfOutOfRangeIncludeMin() tests
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int32PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1,
             ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int32PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1, 1, 3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int32PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2,
             ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int32PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int32FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0,
             ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int32FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int32FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3,
             ExceptionsTest.name, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int32FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3, 1, 3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int32FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2,
             ExceptionsTest.name, 3, 1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int32FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2, 3, 1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_BytePassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((byte)1,
             ExceptionsTest.name, (byte)1, (byte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_BytePassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((byte)1, (byte)1,
             (byte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_BytePassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((byte)2,
             ExceptionsTest.name, (byte)1, (byte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_BytePassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((byte)2, (byte)1,
             (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_ByteFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((byte)0,
             ExceptionsTest.name, (byte)1, (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_ByteFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((byte)0, (byte)1,
             (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_ByteFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((byte)4,
             ExceptionsTest.name, (byte)1, (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "4.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_ByteFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((byte)4, (byte)1,
             (byte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_ByteFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((byte)2,
             ExceptionsTest.name, (byte)3, (byte)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_ByteFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((byte)2, (byte)3,
             (byte)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_CharPassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((char)2,
             ExceptionsTest.name, (char)1, (char)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_CharPassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((char)2, (char)1,
             (char)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_CharPassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((char)2,
             ExceptionsTest.name, (char)1, (char)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_CharPassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((char)2, (char)1,
             (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName_Char + "\u0000.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_CharFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((char)0,
             ExceptionsTest.name, (char)1, (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName_Char + "\u0000.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_CharFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((char)0, (char)1,
             (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName_Char + "\u0003.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_CharFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((char)3,
             ExceptionsTest.name, (char)1, (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName_Char + "\u0003.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_CharFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((char)3, (char)1,
             (char)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithName_Char + "\u0002.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_CharFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((char)2,
             ExceptionsTest.name, (char)3, (char)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithoutName_Char
         + "\u0002.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_CharFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((char)2, (char)3,
             (char)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_DecimalPassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1M,
             ExceptionsTest.name, 1M, 3M);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_DecimalPassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1M, 1M, 3M);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_DecimalPassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2M,
             ExceptionsTest.name, 1M, 3M);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_DecimalPassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2M, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_DecimalFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0M,
             ExceptionsTest.name, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_DecimalFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0M, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_DecimalFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3M,
             ExceptionsTest.name, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_DecimalFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3M, 1M, 3M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_DecimalFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2M,
             ExceptionsTest.name, 3M, 1M);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_DecimalFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2M, 3M, 1M);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_DoublePassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1D,
             ExceptionsTest.name, 1D, 3D);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_DoublePassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1D, 1D, 3D);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_DoublePassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2D,
             ExceptionsTest.name, 1D, 3D);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_DoublePassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2D, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_DoubleFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0D,
             ExceptionsTest.name, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_DoubleFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0D, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_DoubleFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3D,
             ExceptionsTest.name, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_DoubleFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3D, 1D, 3D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_DoubleFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2D,
             ExceptionsTest.name, 3D, 1D);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_DoubleFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2D, 3D, 1D);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_SinglePassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1F,
             ExceptionsTest.name, 1F, 3F);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_SinglePassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1F, 1F, 3F);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_SinglePassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2F,
             ExceptionsTest.name, 1F, 3F);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_SinglePassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2F, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_SingleFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0F,
             ExceptionsTest.name, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_SingleFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0F, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_SingleFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3F,
             ExceptionsTest.name, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_SingleFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3F, 1F, 3F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_SingleFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2F,
             ExceptionsTest.name, 3F, 1F);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_SingleFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2F, 3F, 1F);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int16PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((short)1,
             ExceptionsTest.name, (short)1, (short)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int16PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((short)1, (short)1,
             (short)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int16PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((short)2,
             ExceptionsTest.name, (short)1, (short)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int16PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((short)2, (short)1,
             (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int16FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((short)0,
             ExceptionsTest.name, (short)1, (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int16FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((short)0, (short)1,
             (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int16FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((short)3,
             ExceptionsTest.name, (short)1, (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int16FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((short)3, (short)1,
             (short)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int16FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((short)2,
             ExceptionsTest.name, (short)3, (short)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int16FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((short)2, (short)3,
             (short)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int64PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1L,
             ExceptionsTest.name, 1L, 3L);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int64PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1L, 1L, 3L);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int64PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2L,
             ExceptionsTest.name, 1L, 3L);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int64PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2L, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int64FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0L,
             ExceptionsTest.name, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int64FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0L, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int64FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3L,
             ExceptionsTest.name, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int64FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3L, 1L, 3L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int64FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2L,
             ExceptionsTest.name, 3L, 1L);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_Int64FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2L, 3L, 1L);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt32PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1U,
             ExceptionsTest.name, 1U, 3U);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt32PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1U, 1U, 3U);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt32PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2U,
             ExceptionsTest.name, 1U, 3U);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt32PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2U, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt32FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0U,
             ExceptionsTest.name, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt32FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0U, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt32FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3U,
             ExceptionsTest.name, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt32FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3U, 1U, 3U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt32FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2U,
             ExceptionsTest.name, 3U, 1U);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt32FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2U, 3U, 1U);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_SBytePassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((sbyte)1,
             ExceptionsTest.name, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_SBytePassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((sbyte)1, (sbyte)1,
             (sbyte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_SBytePassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((sbyte)2,
             ExceptionsTest.name, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_SBytePassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((sbyte)2, (sbyte)1,
             (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_SByteFailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((sbyte)0,
             ExceptionsTest.name, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_SByteFailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((sbyte)0, (sbyte)1,
             (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_SByteFailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((sbyte)3,
             ExceptionsTest.name, (sbyte)1, (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_SByteFailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((sbyte)3, (sbyte)1,
             (sbyte)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_SByteFailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((sbyte)2,
             ExceptionsTest.name, (sbyte)3, (sbyte)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_SByteFailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((sbyte)2, (sbyte)3,
             (sbyte)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt16PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((ushort)1,
             ExceptionsTest.name, (ushort)1, (ushort)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt16PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((ushort)1, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt16PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((ushort)2,
             ExceptionsTest.name, (ushort)1, (ushort)3);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt16PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((ushort)2, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt16FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((ushort)0,
             ExceptionsTest.name, (ushort)1, (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt16FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((ushort)0, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt16FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((ushort)3,
             ExceptionsTest.name, (ushort)1, (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt16FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((ushort)3, (ushort)1,
             (ushort)3);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt16FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((ushort)2,
             ExceptionsTest.name, (ushort)3, (ushort)1);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt16FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin((ushort)2, (ushort)3,
             (ushort)1);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt64PassMinWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1UL,
             ExceptionsTest.name, 1UL, 3UL);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt64PassMinWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(1UL, 1UL, 3UL);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt64PassMaxWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2UL,
             ExceptionsTest.name, 1UL, 3UL);
        }
        
        [Test]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt64PassMaxWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2UL, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt64FailLowWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0UL,
             ExceptionsTest.name, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "0.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt64FailLowWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(0UL, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt64FailHighWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3UL,
             ExceptionsTest.name, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinMessageWithoutName + "3.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt64FailHighWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(3UL, 1UL, 3UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt64FailMidReverseWithName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2UL,
             ExceptionsTest.name, 3UL, 1UL);
        }
        
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException),
         ExceptionsTest.rangeIncludeMinReverseMessageWithoutName + "2.")]
        public void
         TestThrowIfOutOfRangeIncludeMin_UInt64FailMidReverseWithoutName()
        {
            Exceptions.ThrowIfOutOfRangeIncludeMin(2UL, 3UL, 1UL);
        }
        #endregion
        
        
        private const string name = "myArgument";
        #region ThrowIfInvalidEnumValue()-specific constants
        private const string enumMessageWithName
         = "Enum argument value 2 is not valid for myArgument. myArgument "
         + @"should be a value from MyEnum.
Parameter name: myArgument";
        private const string enumMessageWithoutName
         = "Enum argument value 2 is not valid for .  should be a value from "
         + "MyEnum.";
        private const string enumMessageOverflowedWithName
         = "Enum argument value 0 is not valid for myArgument. myArgument "
         + @"should be a value from MyEnum.
Parameter name: myArgument";
        private const string enumMessageOverflowedWithoutName
         = "Enum argument value 0 is not valid for .  should be a value from "
         + "MyEnum.";
        #endregion
        #region ThrowIfOutOfRange()-specific constants
        private const string rangeMessageWithName
         = "Argument myArgument must be greater than or equal to 1 and less "
         + @"than or equal to 3.
Parameter name: myArgument
Actual value was ";
        private const string rangeMessageWithName_Char
         = "Argument myArgument must be greater than or equal to \u0001 and "
         + "less than or equal to \u0003" + @".
Parameter name: myArgument
Actual value was ";
        private const string rangeMessageWithoutName
         = "Argument must be greater than or equal to 1 and less than or "
         + @"equal to 3.
Actual value was ";
        private const string rangeMessageWithoutName_Char
         = "Argument must be greater than or equal to \u0001 and less than or "
         + "equal to \u0003" + @".
Actual value was ";
        private const string rangeReverseMessageWithName
         = "Argument myArgument must be greater than or equal to 3 and less "
         + @"than or equal to 1.
Parameter name: myArgument
Actual value was ";
        private const string rangeReverseMessageWithName_Char
         = "Argument myArgument must be greater than or equal to \u0003 and "
         + "less than or equal to \u0001" + @".
Parameter name: myArgument
Actual value was ";
        private const string rangeReverseMessageWithoutName
         = "Argument must be greater than or equal to 3 and less than or "
         + @"equal to 1.
Actual value was ";
        private const string rangeReverseMessageWithoutName_Char
         = "Argument must be greater than or equal to \u0003 and less than or "
         + "equal to \u0001" + @".
Actual value was ";
        #endregion
        #region ThrowIfOutOfRangeExclusive()-specific constants
        private const string rangeExclusiveMessageWithName
         = @"Argument myArgument must be greater than 1 and less than 3.
Parameter name: myArgument
Actual value was ";
        private const string rangeExclusiveMessageWithName_Char
         = "Argument myArgument must be greater than \u0001 and less than "
         + "\u0003" + @".
Parameter name: myArgument
Actual value was ";
        private const string rangeExclusiveMessageWithoutName
         = @"Argument must be greater than 1 and less than 3.
Actual value was ";
        private const string rangeExclusiveMessageWithoutName_Char
         = "Argument must be greater than \u0001 and less than \u0003" + @".
Actual value was ";
        private const string rangeExclusiveReverseMessageWithName
         = @"Argument myArgument must be greater than 3 and less than 1.
Parameter name: myArgument
Actual value was ";
        private const string rangeExclusiveReverseMessageWithName_Char
         = "Argument myArgument must be greater than \u0003 and less than "
         + "\u0001" + @".
Parameter name: myArgument
Actual value was ";
        private const string rangeExclusiveReverseMessageWithoutName
         = @"Argument must be greater than 3 and less than 1.
Actual value was ";
        private const string rangeExclusiveReverseMessageWithoutName_Char
         = "Argument must be greater than \u0003 and less than \u0001" + @".
Actual value was ";
        #endregion
        #region ThrowIfOutOfRangeIncludeMax()-specific constants
        private const string rangeIncludeMaxMessageWithName
         = "Argument myArgument must be greater than 1 and less than or equal "
         + @"to 3.
Parameter name: myArgument
Actual value was ";
        private const string rangeIncludeMaxMessageWithName_Char
         = "Argument myArgument must be greater than \u0001 and less than or "
         + "equal to \u0003" + @".
Parameter name: myArgument
Actual value was ";
        private const string rangeIncludeMaxMessageWithoutName
         = @"Argument must be greater than 1 and less than or equal to 3.
Actual value was ";
        private const string rangeIncludeMaxMessageWithoutName_Char
         = "Argument must be greater than \u0001 and less than or equal to "
         + "\u0003" + @".
Actual value was ";
        private const string rangeIncludeMaxReverseMessageWithName
         = "Argument myArgument must be greater than 3 and less than or equal "
         + @"to 1.
Parameter name: myArgument
Actual value was ";
        private const string rangeIncludeMaxReverseMessageWithName_Char
         = "Argument myArgument must be greater than \u0003 and less than or "
         + "equal to \u0001" + @".
Parameter name: myArgument
Actual value was ";
        private const string rangeIncludeMaxReverseMessageWithoutName
         = @"Argument must be greater than 3 and less than or equal to 1.
Actual value was ";
        private const string rangeIncludeMaxReverseMessageWithoutName_Char
         = "Argument must be greater than \u0003 and less than or equal to "
         + "\u0001" + @".
Actual value was ";
        #endregion
        #region ThrowIfOutOfRangeIncludeMin()-specific constants
        private const string rangeIncludeMinMessageWithName
         = "Argument myArgument must be greater than or equal to 1 and less "
         + @"than 3.
Parameter name: myArgument
Actual value was ";
        private const string rangeIncludeMinMessageWithName_Char
         = "Argument myArgument must be greater than or equal to \u0001 and "
         + "less than \u0003" + @".
Parameter name: myArgument
Actual value was ";
        private const string rangeIncludeMinMessageWithoutName
         = @"Argument must be greater than or equal to 1 and less than 3.
Actual value was ";
        private const string rangeIncludeMinMessageWithoutName_Char
         = "Argument must be greater than or equal to \u0001 and less than "
         + "\u0003" + @".
Actual value was ";
        private const string rangeIncludeMinReverseMessageWithName
         = "Argument myArgument must be greater than or equal to 3 and less "
         + @"than 1.
Parameter name: myArgument
Actual value was ";
        private const string rangeIncludeMinReverseMessageWithName_Char
         = "Argument myArgument must be greater than or equal to \u0003 and "
         + "less than \u0001" + @".
Parameter name: myArgument
Actual value was ";
        private const string rangeIncludeMinReverseMessageWithoutName
         = @"Argument must be greater than or equal to 3 and less than 1.
Actual value was ";
        private const string rangeIncludeMinReverseMessageWithoutName_Char
         = "Argument must be greater than or equal to \u0003 and less than "
         + "\u0001" + @".
Actual value was ";
        #endregion
    }
}

//                                 ~ S. D. G. ~
