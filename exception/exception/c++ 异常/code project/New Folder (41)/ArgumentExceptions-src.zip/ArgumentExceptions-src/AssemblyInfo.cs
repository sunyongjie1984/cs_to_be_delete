//                                  ~ J. J. ~

using System.Reflection;
using System.Runtime.CompilerServices;


[assembly: AssemblyTitle("Exceptions Test Suite Class Library")]
[assembly: AssemblyDescription("Exceptions Test Suite Class Library by Umbrae Research")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Umbrae Research")]
[assembly: AssemblyProduct("Exceptions Test Suite Class Library by Umbrae Research")]
[assembly: AssemblyCopyright("Copyright � 2004 Umbrae Research")]
[assembly: AssemblyTrademark("Umbrae and the Umbrae Research indicia are trademarks of Umbrae Research Ltd, est. 1996. All Rights Reserved.")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("0.9.*")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile(@"")]
[assembly: AssemblyKeyName("")]

//                                 ~ S. D. G. ~
