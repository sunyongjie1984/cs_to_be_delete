// CStackVect.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include "stackx.h"



int main(int argc, char* argv[])
{
	CStackX<int> st(8);
	st.push(4);
	st.push(10);
	for(int i =0; i<6;i++)
		st.push(i);
	
	
	for(int val = 0 ; val<8; val++)
	{
		int nVal = st.pop();
		printf("%d\n",nVal);
	}
		

	
	return 0;
}
