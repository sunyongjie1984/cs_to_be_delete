Imports System
Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.IO
Imports System.Xml

''' <summary>
''' SOAP extension to transfer full exception information from
''' server to client in the event of an exception being thrown
''' from a webmethod
''' </summary>
''' <remarks>
''' In the event of an exception being thrown during the execution
''' of a webmethod on the server, this class steps in and writes detailed 
''' exception information to the output stream.
''' 
''' Client side, if an exception is detected on the response from a
''' webmethod call, this class retrieves the detailed exception 
''' information from the input stream and throws an exception
''' containing the detailed information
''' </remarks>
Public Class ExceptionHandlingSoapExtension
    Inherits SoapExtension

#Region "Initialisation methods - not used because this class has no state to maintain"
    Public Overloads Overrides Function GetInitializer(ByVal serviceType As System.Type) As Object
        Return Nothing
    End Function

    Public Overloads Overrides Function GetInitializer(ByVal methodInfo As System.Web.Services.Protocols.LogicalMethodInfo, ByVal attribute As System.Web.Services.Protocols.SoapExtensionAttribute) As Object
        Return Nothing
    End Function

    Public Overrides Sub Initialize(ByVal initializer As Object)

    End Sub
#End Region

#Region "Stream chaining code"
    Private oldStream As Stream
    Private newStream As Stream

    Public Overrides Function ChainStream(ByVal stream As Stream) As Stream
        oldStream = stream
        newStream = New MemoryStream
        Return newStream
    End Function

    ''' <summary>
    ''' Copies the contents of one stream to another
    ''' </summary>
    ''' <param name="source">Source stream</param>
    ''' <param name="dest">Destination stream</param>        
    Private Sub StreamCopy(ByVal source As Stream, ByVal dest As Stream)
        Dim Reader As New StreamReader(source)
        Dim Writer As New StreamWriter(dest)
        Writer.WriteLine(Reader.ReadToEnd())
        Writer.Flush()
    End Sub
#End Region

    Public Overrides Sub ProcessMessage(ByVal message As System.Web.Services.Protocols.SoapMessage)
        Select Case message.Stage
            Case SoapMessageStage.BeforeSerialize
                'Do nothing

            Case SoapMessageStage.AfterSerialize
                'If exception present in message, write details 
                'to the new stream
                If Not message.Exception Is Nothing Then
                    InsertExceptionDetails(message.Exception)
                End If

                'Copy new stream to old stream
                newStream.Position = 0
                StreamCopy(newStream, oldStream)

            Case SoapMessageStage.BeforeDeserialize
                'Copy old stream to new stream
                StreamCopy(oldStream, newStream)
                newStream.Position = 0

            Case SoapMessageStage.AfterDeserialize
                'If exception present in message,
                'get details from stream and throw to caller
                If Not message.Exception Is Nothing Then
                    Dim DetailString As String
                    DetailString = GetExceptionDetails()

                    Throw New Exception(DetailString)
                End If

            Case Else
                Throw New ArgumentException("Invalid message stage")
        End Select
    End Sub

    ''' <summary>
    ''' Insert details of the specified exception into the output stream
    ''' </summary>
    ''' <param name="ex">Exception to write details for</param>        
    Private Sub InsertExceptionDetails(ByVal ex As Exception)
        'Read output stream into XML document
        newStream.Position = 0
        Dim Reader As New XmlTextReader(newStream)
        Dim MessageDoc As New XmlDocument
        MessageDoc.Load(Reader)

        Dim NsMgr As New XmlNamespaceManager(MessageDoc.NameTable)
        NsMgr.AddNamespace("soap", "http://schemas.xmlsoap.org/soap/envelope/")

        'Construct string describing exception
        Dim ErrorInfo As String
        ErrorInfo = ex.ToString()

        'Find existing soap:Fault node describing exception
        Dim ExceptionNode As XmlNode
        ExceptionNode = MessageDoc.SelectSingleNode("//soap:Fault", NsMgr)

        'Add extended exception detail node to Fault node
        Dim ExceptionDetail As XmlElement
        ExceptionDetail = MessageDoc.CreateElement("ExtendedExceptionDetails")

        ExceptionDetail.InnerText = ErrorInfo

        ExceptionNode.AppendChild(ExceptionDetail)

        'Write XML document back to output stream
        newStream = New MemoryStream
        MessageDoc.Save(newStream)
    End Sub

    ''' <summary>
    ''' Reads extra exception information from stream and
    ''' returns it as a string
    ''' </summary>
    ''' <returns>Details of any exception detail found in the input stream</returns>
    Private Function GetExceptionDetails() As String
        'Read input stream into XML document
        newStream.Position = 0
        Dim Reader As New XmlTextReader(newStream)
        Dim MessageDoc As New XmlDocument
        MessageDoc.Load(Reader)

        Dim NsMgr As New XmlNamespaceManager(MessageDoc.NameTable)
        NsMgr.AddNamespace("soap", "http://schemas.xmlsoap.org/soap/envelope/")

        'Find extended exception detail node
        Dim ExceptionDetailNode As XmlNode
        ExceptionDetailNode = MessageDoc.SelectSingleNode("//soap:Fault/ExtendedExceptionDetails", NsMgr)

        'Return detail text if found, empty string otherwise
        If Not ExceptionDetailNode Is Nothing Then
            Return ExceptionDetailNode.InnerText
        Else
            Return ""
        End If

    End Function
End Class