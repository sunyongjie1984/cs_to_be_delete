// HighResElapsedTime.cpp: implementation of the HighResElapsedTime class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HighResElapsedTimer.h"

/* static */
LONGLONG HighResElapsedTimer::m_llFrequency = 0;

