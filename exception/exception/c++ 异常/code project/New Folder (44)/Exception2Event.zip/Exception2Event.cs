using System;

public delegate void ErrorEventHandler(object sender, ErrorEventArgs e);

public class Exception2Event
{
	public static event ErrorEventHandler	Error;

	public static void PublishError(int errorCode, string message, Exception e)
	{
		ErrorEventArgs errArgs = new ErrorEventArgs(errorCode,message, e);
		
		if ( Error != null )
			Error(null, errArgs);
	}
}

public class ErrorEventArgs
{
	private string		_message;
	private int			_errorCode;
	private Exception	_innerException;
	private string		_exceptionHelpLink;
	private string		_exceptionMessage;
	private string		_exceptionSource;
	private string		_exceptionStackTrace;
	private string		_exceptionMethod;

	public ErrorEventArgs()
	{
		_message = "Catched Exception.";
		_errorCode = -1;
		_innerException = null;
		_exceptionHelpLink = "";
		_exceptionMessage = "";
		_exceptionSource = "";
		_exceptionStackTrace = "";
		_exceptionMethod = "";
	}

	public ErrorEventArgs(int errorCode, string message)
	{
		_message = message;
		_errorCode = errorCode;
		_innerException = null;
		_exceptionHelpLink = "";
		_exceptionMessage = "";
		_exceptionSource = "";
		_exceptionStackTrace = "";
		_exceptionMethod = "";
	}

	public ErrorEventArgs(int errorCode, string message, Exception e)
	{
		_message = message;
		_errorCode = errorCode;
		_innerException = e.InnerException;
		_exceptionHelpLink = e.HelpLink;
		_exceptionMessage = e.Message;
		_exceptionSource = e.Source;
		_exceptionStackTrace = e.StackTrace;
		_exceptionMethod = e.TargetSite.Name;
	}

	public string Message
	{
		get
		{
			return _message;
		}
		set
		{
			_message = value;
		}
	}

	public int Code
	{
		get
		{
			return _errorCode;
		}
		set
		{
			_errorCode = value;
		}
	}

	public Exception InnerException
	{
		get
		{
			return _innerException;
		}
		set
		{
			_innerException = value;
		}
	}

	public string ErrorMessage
	{
		get
		{
			return _exceptionMessage;
		}
		set
		{
			_exceptionMessage = value;
		}
	}

	public string Source
	{
		get
		{
			return _exceptionSource;
		}
		set
		{
			_exceptionSource = value;
		}
	}

	public string StackTrace
	{
		get
		{
			return _exceptionStackTrace;
		}
		set
		{
			_exceptionStackTrace = value;
		}
	}

	public string Method
	{
		get
		{
			return _exceptionMethod;
		}
		set
		{
			_exceptionMethod = value;
		}
	}
}

public class TestThis
{
	public TestThis()
	{
		Exception2Event.Error += new ErrorEventHandler(LogEvent);
	}

	public void LogEvent(object sender, ErrorEventArgs e)
	{
		Console.WriteLine(e.ErrorMessage + " " + e.Message);
	}

	public static void Main()
	{
		try
		{
			TestThis tt;

			tt = new TestThis();

			int zero = 0;

			int i = 10 / zero;
		}
		catch(Exception e)
		{
			Exception2Event.PublishError(1, "Divide by 0 is not good :) ", e);
		}
	}
}