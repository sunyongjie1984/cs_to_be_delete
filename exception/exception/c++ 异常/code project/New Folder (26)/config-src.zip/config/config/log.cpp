#include "log.h"

LogLevel logLevel = LOG_INFO;
