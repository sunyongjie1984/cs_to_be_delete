// MFCLeakTestDoc.h : interface of the CMFCLeakTestDoc class
//


#pragma once

class CMFCLeakTestDoc : public CDocument
{
protected: // create from serialization only
	CMFCLeakTestDoc();
	DECLARE_DYNCREATE(CMFCLeakTestDoc)

// Attributes
public:

// Operations
public:

// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CMFCLeakTestDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};


