﻿namespace LostExceptionChain
{
    using System;
    using System.ComponentModel;
    using System.Runtime.InteropServices;

    /// <summary>
    /// Unmanaged blocked memory resource.
    /// It may have a problem of disposition.
    /// Set <see cref="MaliciousDisposeBug"/> property to <c>true</c>
    /// to simulate an error at the end of <see cref="Dispose(bool)"/> method.
    /// </summary>
    class BlockMemoryResource: IDisposable
    {
        public const int BLOCK_SIZE=0x1000;

        public bool IsValid
            { get { return i_bValid; } }

        public bool MaliciousDisposeBug
        {
           get { return i_bMaliciousDisposeBug; }
           set { i_bMaliciousDisposeBug=value; }
        }

        public IntPtr MemoryPtr
        {
           get {
              if (!IsValid)
                 throw new InvalidObjectStateException();
              return i_pvMemory;
           }
        }

        public int BlocksAllocated
        {
           get {
              if (!IsValid)
                 throw new InvalidObjectStateException();
              return i_nBlocks;
           }
        }

        public int BytesAllocated
        {
           get {
              if (!IsValid)
                 throw new InvalidObjectStateException();
              return i_nBlocks*BLOCK_SIZE;
           }
        }

        public BlockMemoryResource()
        {
           InitializeInstance(1);
        }

        public BlockMemoryResource(int nNumBlocks)
        {
           InitializeInstance(nNumBlocks);
        }

        public void Dispose()
        {
           GC.SuppressFinalize(this);
           Dispose(true);
        }

        /// <remarks>
        /// If <see cref="MaliciousDisposeBug" /> property is set,
        /// there will be a problem of the disposition.
        /// </remarks>
        protected virtual void Dispose(bool bExplicit)
        {
            if (!IsValid) return;

            i_bValid=false;

            IntPtr hProcessHeap=Win32_GetProcessHeap();
            if (hProcessHeap==IntPtr.Zero)
                throw new Win32Exception();

            if (!Win32_HeapFree(hProcessHeap,0,i_pvMemory))
                throw new Win32Exception();

            // Exception chain throwing bug:
            if (i_bMaliciousDisposeBug)
                throw new System.Runtime.InteropServices.SEHException( null,
                    new System.IO.FileNotFoundException() );
        }

        ~BlockMemoryResource()
        {
            Dispose(false);
        }


        void InitializeInstance(int nNumBlocks)
        {
            if (nNumBlocks<=0)
                throw new ArgumentException("Invalid number of blocks.");

            int nBytesToAllocate;

            try
               { nBytesToAllocate=checked(nNumBlocks*BLOCK_SIZE); }
            catch (OverflowException ex)
               { throw new ArgumentException(null,ex); }

            IntPtr hProcessHeap=Win32_GetProcessHeap();
            if (hProcessHeap==IntPtr.Zero)
               throw new Win32Exception();

            i_pvMemory=Win32_HeapAlloc(
               hProcessHeap,
               HEAP_GENERATE_EXCEPTIONS | HEAP_ZERO_MEMORY,
               (UIntPtr)nBytesToAllocate );

            i_nBlocks=nNumBlocks;
            i_bValid=true;
        }

        const uint HEAP_GENERATE_EXCEPTIONS= 0x00000004;
        const uint HEAP_ZERO_MEMORY        = 0x00000008;

        bool
           i_bValid, i_bMaliciousDisposeBug;
        int
           i_nBlocks;
        IntPtr
           i_pvMemory;

        [DllImport(
            "Kernel32",
            EntryPoint="GetProcessHeap",
            SetLastError=true) ]
        static extern IntPtr Win32_GetProcessHeap();

        [DllImport("Kernel32", EntryPoint="HeapAlloc", SetLastError=true)]
        static extern IntPtr Win32_HeapAlloc(
            IntPtr hHeap,uint dwFlags,UIntPtr stBytes );

        [DllImport("Kernel32", EntryPoint="HeapFree", SetLastError=true)]
        static extern bool Win32_HeapFree(
            IntPtr hHeap,uint dwFlags,IntPtr pvMemBlock );
    }

    /// <summary>
    /// This exception is thrown, if you attempt to access some object
    /// properties when it is in an invalid state.
    /// </summary>
    /// <remarks>
    /// This is an analogue of <see cref="System.InvalidOperationException"/>.
    /// </remarks>
    class InvalidObjectStateException: Exception
    {
        public InvalidObjectStateException():
            base(DefaultMessage)
        {}

        public InvalidObjectStateException(string strMessage):
            base(strMessage)
        {}

        public InvalidObjectStateException(Exception innerException):
            base(DefaultMessage,innerException)
        {}

        public InvalidObjectStateException(
            string strMessage, Exception innerException ):
            base(strMessage,innerException)
        {}

        static string DefaultMessage
            { get { return "The object is in invalid state."; } }
    }
}
