﻿ LostExceptionChain is a simple console application.
It is written in C# language (version 2.0) to run under .NET 2.0.
 You can easily translate the program by the MSBUILD-utility with help
of the corresponding CMD-batches (the preferred method of compilation
and running for this sample app.) or by the Visual Studio 2005.

 You'll find CMD-batches in the project folder along with the project
and solution files. XML-files "LostExceptionChain.settings" and
"LostExceptionChain.targets" serve as alternative MSBUILD-only project.

 You have to specify corresponding .NET directory in the "PATH"
environment variable in order to access "MSBUILD.EXE", "CS.EXE"
and other tools from the CMD-batches.
 For example (for a system wich was installed on "C:" home-drive):
".....;C:\WINDOWS\Microsoft.NET\Framework\v2.0.50727;.....".
To make the correction, go to the following applet:
"My Computer/Properties/Advanced/Environment Variables/" --
"System variables/Variable:PATH-Value".
