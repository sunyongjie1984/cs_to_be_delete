//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//
//  This is auto-generated source file. It is created by MSBUILD-utility invoked from CMD-batch
// according to content of "LostExceptionChain.settings" file. This done by
// "PrepareAssemblyInfo" target of "LostExceptionChain.targets" file.
//
//
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Lost Exception Chain sample application")]
[assembly: AssemblyDescription("Demonstration of loss of exception information, and how you can prevent it by organizing exception chain via InnerException property.")]
[assembly: AssemblyVersion("2006.7.1.1")]
[assembly: AssemblyFileVersion("2006.7.1.1")]
[assembly: AssemblyProduct("Program Demo Samples (.NET)")]
[assembly: AssemblyCompany("MUP MIVC (the city of Voronezh)")]
[assembly: AssemblyCopyright("\x00A9 Sergei Kitaev")]

[assembly: ComVisible(false)]

[assembly: Guid("a0883713-c009-49c5-9152-61fb2274025b")]

