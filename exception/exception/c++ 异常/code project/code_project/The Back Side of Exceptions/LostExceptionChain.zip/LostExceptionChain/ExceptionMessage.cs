﻿namespace LostExceptionChain
{
    using System;
    using System.Text;

    /// <summary>
    /// Dealing with exception message(s).
    /// </summary>
    static class ExceptionMessage
    {
        public static string ComposeChainMessage(Exception e)
        {
           return ComposeChainMessage(e,false);
        }

        public static string ComposeChainMessage
        (
            Exception e, bool bIncludeExceptionNames
        )
        {
           if (e.InnerException==null)
              return ComposeMessage(e,bIncludeExceptionNames);

           StringBuilder sb=new StringBuilder();
           for (Exception ex=e; ex!=null; ex=ex.InnerException)
              sb.Insert( 0,
                 "--> "+ComposeMessage(ex,bIncludeExceptionNames)+
                 (ex==e ? "" : "\r\n") );

           return sb.ToString();
        }

        public static string ComposeMessage(Exception e)
        {
           return ComposeMessage(e,true);
        }

        public static string ComposeMessage
        (
            Exception e, bool bIncludeExceptionName
        )
        {
           return bIncludeExceptionName ?
              string.Format("{0}: \"{1}\"",e.GetType(),e.Message) :
              e.Message;
        }
    }
}
