﻿//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//
// This program was written by Sergei Kitaev, a senior programmer
// at Voronezh Municipal Center of Information and Analysis --
// MUP MIVC (the city of Voronezh).
//
// Copyright: Sergei Kitaev
//
//
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
namespace LostExceptionChain
{
    using System;
    using System.Reflection;

    /// <summary>
    /// Three possible modes of demonstration.
    /// </summary>
    enum DemonstrationMode
    {
        Plain, Advanced, AdvancedPlus
    }

    /// <summary>
    /// Class, where <see cref="Main"/> entry-point routine is located.
    /// </summary>
    static class Program
    {
        /// <summary>Entrypoint routine.</summary>
        static int Main(string[] astrParams)
        {
            // Uncomment function call below to see
            // how default exception handler does behave:

            //PerformDemonstration_Plain();

            if (astrParams.Length!=1)
                Stop( "One parameter expected -- \"/Plain\", \"/Advanced\" "+
                      "or \"/Advanced+\" switch (case insensitive)." );

            string
                strModeSwitchUpr=astrParams[0].ToUpper();
            int
                nModeIdx=Array.IndexOf(
                    new string[]{"/PLAIN","/ADVANCED","/ADVANCED+"},
                    strModeSwitchUpr );

            if (nModeIdx<0)
                Failure("Incorrect mode switch: \"{0}\".",strModeSwitchUpr);

            DemonstrationMode demoMode=(DemonstrationMode)nModeIdx;

            Console.WriteLine(
                "Performing the \"LostExceptionChain\"-demonstration {0}:",
                strModeSwitchUpr );
            Console.WriteLine();

            try
            {
                switch (demoMode)
                {
                case DemonstrationMode.Plain:
                    PerformDemonstration_Plain(); break;
                case DemonstrationMode.Advanced:
                    PerformDemonstration_Advanced(); break;
                case DemonstrationMode.AdvancedPlus:
                    PerformDemonstration_AdvancedPlus(); break;
                }
            }
            catch (Exception ex)
            {
                Failure(ex);
            }

            return 0;
        }

        /// <summary>Classic using-block.</summary>
        static void PerformDemonstration_Plain()
        {
            PrintOperation("Starting \"using\"-block");

            using (BlockMemoryResource bmr=new BlockMemoryResource())
            {
                // Resource disposition will cause an exception(s):
                bmr.MaliciousDisposeBug=true;

                AccessResourceMemory(bmr);

                ThrowSeriousExceptionChain();
            }
        }

        /// <summary>Using-block alternative.</summary>
        static void PerformDemonstration_Advanced()
        {
            PrintOperation("Starting \"using\"-block alternative");

            BlockMemoryResource bmr=new BlockMemoryResource();
            try
            {
                // Resource disposition will cause an exception(s):
                bmr.MaliciousDisposeBug=true;

                AccessResourceMemory(bmr);

                ThrowSeriousExceptionChain();
            }
            catch (Exception e)
            {
                try
                    { bmr.Dispose(); }
                catch (Exception x)
                    { throw ExceptionChainCombination.Combine(x,e); }
                throw;
            }
            bmr.Dispose();
        }

        /// <summary>Using-block alternative.</summary>
        /// <remarks>
        /// <see cref="DeterministicFinalizationException"/> is inserted
        /// as a head of combined exception chain.
        /// </remarks>
        static void PerformDemonstration_AdvancedPlus()
        {
            PrintOperation("Starting \"using\"-block alternative");

            BlockMemoryResource bmr=new BlockMemoryResource();
            try
            {
                // Resource disposition will cause an exception(s):
                bmr.MaliciousDisposeBug=true;

                AccessResourceMemory(bmr);

                ThrowSeriousExceptionChain();
            }
            catch (Exception e)
            {
                try
                {
                    bmr.Dispose();
                }
                catch (Exception x)
                {
                    throw new DeterministicFinalizationException(
                        ExceptionChainCombination.Combine(x,e) );
                }
                throw;
            }
            bmr.Dispose();
        }

        /// <summary>Testing resource accessing its memory.</summary>
        static unsafe void AccessResourceMemory(BlockMemoryResource bmr)
        {
            PrintOperation("Accessing resource's memory");

            int*
                pnMemory=(int*)bmr.MemoryPtr,
                pnNums=pnMemory;

            Version appVer=Assembly.GetExecutingAssembly().GetName().Version;

            *pnNums++=appVer.Major;
            *pnNums++=appVer.Minor;
            *pnNums++=appVer.Build;
            *pnNums++=appVer.Revision;

            for (int* pn=pnMemory; pn-pnMemory<20; pn++)
                Console.WriteLine("# {0,2}: {1}",pn-pnMemory,*pn);
        }

        /// <summary>Throwing a chain of serious errors.</summary>
        /// <remarks>
        /// <see cref="System.ApplicationException"/> is thrown.
        /// </remarks>
        static void ThrowSeriousExceptionChain()
        {
            PrintOperation(
                "Throwing exception chain of serious application errors" );
            throw new ApplicationException( "Serious Error (subsequent).",
                new ApplicationException("Serious Error (original).") );
        }

        static void PrintOperation(string strMessage)
        {
            Console.WriteLine("* {0}...",strMessage);
        }

        static void PrintOperation( string strMessageFmt,
                                    params object[] aobParams )
        {
            PrintOperation(string.Format(strMessageFmt,aobParams));
        }

        static void Exit()
        {
            Environment.Exit(0);
        }

        static void Stop(string strMessage)
        {
            Console.WriteLine(strMessage);

            Exit();
        }

        static void Stop(string strMessageFmt,params object[] aobParams)
        {
            Stop(string.Format(strMessageFmt,aobParams));
        }

        internal static void Failure(string strMessage)
        {
            Console.WriteLine("## "+strMessage);

            Environment.Exit(1);
        }

        internal static void Failure( string strMessageFmt,
                                      params object[] aobParams )
        {
            Failure(string.Format(strMessageFmt,aobParams));
        }

        /// <summary>
        /// This routine is called to handle top level exception.
        /// </summary>
        internal static void Failure(Exception e)
        {
            Console.WriteLine( "\r\n"+
                "## ERROR IN THE APPLICATION HAS OCCURRED!\r\n"+
                "=== {0}: ===\r\n"+
                "{1}",
                e.InnerException==null ?
                    "Exception and its message" :
                    "Exception chain (from primary to the last one)",
                ExceptionMessage.ComposeChainMessage(e,true) );

            Environment.Exit(1);
        }
    }
}
