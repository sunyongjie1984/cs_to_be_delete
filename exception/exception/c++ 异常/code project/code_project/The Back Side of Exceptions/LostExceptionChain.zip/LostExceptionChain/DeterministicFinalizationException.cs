﻿namespace LostExceptionChain
{
    using System;

    /// <summary>
    /// This exception is used to add it as a head of exception chain,
    /// when catching and rethrowing exception in a finally block.
    /// </summary>
    class DeterministicFinalizationException: Exception
    {
        public DeterministicFinalizationException(Exception innerException):
            base( "Can not completely perform deterministic finalization.",
                  innerException )
        {}
    }
}
