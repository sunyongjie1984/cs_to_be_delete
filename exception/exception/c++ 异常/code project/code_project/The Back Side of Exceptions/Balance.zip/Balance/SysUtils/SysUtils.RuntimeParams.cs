﻿namespace SysUtils {

using System;

//***********************************************************************************************
/// <summary>
/// These class is used for &quot;SysUtils&quot; library adjustment at startup.
/// </summary>
static class RuntimeParams {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// Set some of these properties before calling to "InitializeSysUtilsClasses":

public static string ApplicationTitle
   { set { _ApplicationTitle=value; } }

public static string ResourcesName
   { set { _ResourcesName=value; } }

public static bool FatalErrorOnUnhandledException
   { set { _FatalErrorOnUnhandledException=value; } }

public static PrimaryEmergencyActionDelegate PrimaryEmergencyAction
   { set { _PrimaryEmergencyAction=value; } }

public static PosteriorEmergencyActionDelegate PosteriorEmergencyAction
   { set { _PosteriorEmergencyAction=value; } }

//-----------------------------------------------------------------------------------------------

/// <summary>
/// This static method initializes &quot;SysUtils&quot; library with prior defined parameters.
/// </summary>
/// <remarks>
/// The initialization should be invoked at the very beginning of you program.
/// </remarks>
public static void InitializeSysUtilsClasses()
{
   SysUtils.FatalError._InitializeClass();
   SysUtils.Resources ._InitializeClass();
}

//-----------------------------------------------------------------------------------------------

// All these fields are for internal purpose only.
// Use properties of corresponding classes to read the values.
// (We use such manner because "SysUtils"-classes are implemented as static library here.)

internal static volatile string _ApplicationTitle;

internal static string _ResourcesName;

internal static bool _FatalErrorOnUnhandledException;
internal static volatile PrimaryEmergencyActionDelegate _PrimaryEmergencyAction;
internal static volatile PosteriorEmergencyActionDelegate _PosteriorEmergencyAction;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // RuntimeParams
//***********************************************************************************************

} // SysUtils
