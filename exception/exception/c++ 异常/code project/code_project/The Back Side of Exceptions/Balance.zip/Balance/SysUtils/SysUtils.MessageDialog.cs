﻿namespace SysUtils {

using System;
using System.Windows.Forms;

//***********************************************************************************************
static class MessageDialog {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public static void ShowError(string strMessage)
{
   ShowError(strMessage,SysUtils.RootInfo.ApplicationTitle);
}

public static void ShowError(string strMessage,string strTitle)
{
   MessageBox.Show(strMessage,strTitle,MessageBoxButtons.OK,MessageBoxIcon.Error);
}

public static void ShowError(IWin32Window wndOwner,string strMessage)
{
   ShowError(wndOwner,strMessage,SysUtils.RootInfo.ApplicationTitle);
}

public static void ShowError(IWin32Window wndOwner,string strMessage,string strTitle)
{
   MessageBox.Show( wndOwner, strMessage, strTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Error );
}

public static void ShowError(Exception e)
{
   ShowError(e.Message);
}

public static void ShowError(Exception e,string strTitle)
{
   ShowError(e.Message,strTitle);
}

public static void ShowError(IWin32Window wndOwner,Exception e)
{
   ShowError(wndOwner,e.Message);
}

public static void ShowError(IWin32Window wndOwner,Exception e,string strTitle)
{
   ShowError(wndOwner,e.Message,strTitle);
}

//-----------------------------------------------------------------------------------------------

public static void ShowInformation(string strMessage)
{
   ShowInformation(strMessage,SysUtils.RootInfo.ApplicationTitle);
}

public static void ShowInformation(string strMessage,string strTitle)
{
   MessageBox.Show(strMessage,strTitle,MessageBoxButtons.OK,MessageBoxIcon.Information);
}

public static void ShowInformation(IWin32Window wndOwner,string strMessage)
{
   ShowInformation(wndOwner,strMessage,SysUtils.RootInfo.ApplicationTitle);
}

public static void ShowInformation( IWin32Window wndOwner,
                                            string strMessage,
                                            string strTitle )
{
   MessageBox.Show( wndOwner, strMessage, strTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information );
}

//-----------------------------------------------------------------------------------------------

public static void ShowWarning(string strMessage)
{
   ShowWarning(strMessage,SysUtils.RootInfo.ApplicationTitle);
}

public static void ShowWarning(string strMessage,string strTitle)
{
   MessageBox.Show(strMessage,strTitle,MessageBoxButtons.OK,MessageBoxIcon.Warning);
}

public static void ShowWarning(IWin32Window wndOwner,string strMessage)
{
   ShowWarning(wndOwner,strMessage,SysUtils.RootInfo.ApplicationTitle);
}

public static void ShowWarning(IWin32Window wndOwner,string strMessage,string strTitle)
{
   MessageBox.Show( wndOwner, strMessage, strTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning );
}

//-----------------------------------------------------------------------------------------------

public static void ShowExclamation(string strMessage)
{
   ShowExclamation(strMessage,SysUtils.RootInfo.ApplicationTitle);
}

public static void ShowExclamation(string strMessage,string strTitle)
{
   MessageBox.Show(strMessage,strTitle,MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
}

public static void ShowExclamation(IWin32Window wndOwner,string strMessage)
{
   ShowExclamation(wndOwner,strMessage,SysUtils.RootInfo.ApplicationTitle);
}

public static void ShowExclamation( IWin32Window wndOwner,
                                            string strMessage,
                                            string strTitle )
{
   MessageBox.Show( wndOwner, strMessage, strTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation );
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // MessageDialog
//***********************************************************************************************

} // SysUtils
