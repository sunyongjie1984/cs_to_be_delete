﻿namespace Balance {

using System;
using System.Windows.Forms;
using Balance.Properties;

//***********************************************************************************************
public partial class FormCustomize: Form {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public static void ReadSettings()
{
   if (!IsDefaultXMLNormal(Program.Settings.DefaultXML))
      throw new SystemException(
         Resources_FormCustomize.IncorrectDefaultXMLProperty_Msg );

   SysUtils.SoundPlay.Mute=Program.Settings.NoSound;
   SysUtils.Beeper.Mute=Program.Settings.NoBeep;

#if DEBUG
   SysUtils.SoundPlay.Mute=true;
#endif
}

//===============================================================================================

static bool IsDefaultXMLNormal(string strDefaultXML)
{
   return
      !SysUtils.FilePath.DoesContainInvalidPathChar  (strDefaultXML) &&
      !SysUtils.FilePath.DoesContailWildcardChar     (strDefaultXML) &&
      !SysUtils.FilePath.DoesContainPathSeparatorChar(strDefaultXML) &&
      strDefaultXML.Trim()==strDefaultXML;
}

//===============================================================================================

public FormCustomize()
{
   InitializeComponent();
}

//===============================================================================================

void EnableButtons()
{
   buttonReset.Enabled=buttonOk.Enabled=true;
}

//-----------------------------------------------------------------------------------------------

private void FormCustomize_Load(object sender,EventArgs e)
{
   textBoxDefaultXML.Text=Program.Settings.DefaultXML;
   checkBoxDontUseDefaultXML.Checked=Program.Settings.DontUseDefaultXML;

   checkBoxNoSound.Checked=Program.Settings.NoSound;
   checkBoxNoBeep.Checked=Program.Settings.NoBeep;

   checkBoxDontLoadXML_CheckedChanged(null,null);

   buttonReset.Enabled=
   !(
      textBoxDefaultXML        .Text    == Program.Settings.DefaultXML_Default        &&
      checkBoxDontUseDefaultXML.Checked == Program.Settings.DontUseDefaultXML_Default &&
      checkBoxNoSound          .Checked == Program.Settings.NoSound_Default           &&
      checkBoxNoBeep           .Checked == Program.Settings.NoBeep_Default
   );

   buttonOk.Enabled=false;
}

private void checkBoxDontLoadXML_CheckedChanged(object sender,EventArgs e)
{
   textBoxDefaultXML.Enabled=!checkBoxDontUseDefaultXML.Checked;

   checkBox_CheckedChanged(sender,e);
}

private void FormCustomize_FormClosing(object sender,FormClosingEventArgs e)
{
   if (DialogResult!=DialogResult.OK)
      return;

   try
   {
      if (!IsDefaultXMLNormal(textBoxDefaultXML.Text))
         throw new ApplicationException(
            Resources_FormCustomize.IncorrectDefaultXMLValue_Msg );
   }
   catch (ApplicationException ex)
   {
      SysUtils.MessageDialog.ShowError( ex.Message,
         Resources_FormCustomize.IncorrectInputTitle_Msg );
      DialogResult=DialogResult.None;
      e.Cancel=true;
      return;
   }

   Program.Settings.DefaultXML=textBoxDefaultXML.Text;
   Program.Settings.DontUseDefaultXML=checkBoxDontUseDefaultXML.Checked;

   Program.Settings.NoSound=checkBoxNoSound.Checked;
   Program.Settings.NoBeep=checkBoxNoBeep.Checked;

   ReadSettings();

   if (!Program.SaveAppSettings(true))
   {
      e.Cancel=true; return;
   }
}

private void buttonReset_Click(object sender,EventArgs e)
{
   textBoxDefaultXML        .Text   = Program.Settings.DefaultXML_Default;
   checkBoxDontUseDefaultXML.Checked= Program.Settings.DontUseDefaultXML_Default;
   checkBoxNoSound          .Checked= Program.Settings.NoSound_Default;
   checkBoxNoBeep           .Checked= Program.Settings.NoBeep_Default;

   buttonReset.Enabled=false;
}

private void textBox_TextChanged(object sender,EventArgs e)
{
   EnableButtons();
}

private void checkBox_CheckedChanged(object sender,EventArgs e)
{
   EnableButtons();
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // FormCustomize
//***********************************************************************************************

} // Balance
