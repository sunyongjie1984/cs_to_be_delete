﻿namespace Balance
{
   partial class FormMain
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components=null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing&&(components!=null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
         this.panelClient = new System.Windows.Forms.Panel();
         this.panelDataFile = new System.Windows.Forms.Panel();
         this.panelControls = new System.Windows.Forms.Panel();
         this.checkBoxMonolithicBalanceOperation = new System.Windows.Forms.CheckBox();
         this.checkBoxBallanceCorruptionBug = new System.Windows.Forms.CheckBox();
         this.labelEpsilonValue = new System.Windows.Forms.Label();
         this.labelEpsilon = new System.Windows.Forms.Label();
         this.labelDivergenceValue = new System.Windows.Forms.Label();
         this.labelDivergence = new System.Windows.Forms.Label();
         this.buttonReset = new System.Windows.Forms.Button();
         this.buttonStartStop = new System.Windows.Forms.Button();
         this.labelMaxDifferenceValue = new System.Windows.Forms.Label();
         this.labelIterationValue = new System.Windows.Forms.Label();
         this.labelMaxDifference = new System.Windows.Forms.Label();
         this.labelIteration = new System.Windows.Forms.Label();
         this.panelGraphics = new System.Windows.Forms.Panel();
         this.panelSummary = new System.Windows.Forms.Panel();
         this.panelContainers = new System.Windows.Forms.Panel();
         this.statusStrip = new System.Windows.Forms.StatusStrip();
         this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
         this.menuStrip = new System.Windows.Forms.MenuStrip();
         this.menuItemFile = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemLoad = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemSave = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemSaveInputOnly = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemViewContent = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemClear = new System.Windows.Forms.ToolStripMenuItem();
         this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
         this.menuItemExit = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemApproximation = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemBalanceCorruptionBug = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemMonolithicBalanceOperation = new System.Windows.Forms.ToolStripMenuItem();
         this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
         this.menuItemReset = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemStartStop = new System.Windows.Forms.ToolStripMenuItem();
         this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
         this.menuItemViewSchema = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemTools = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemCustomize = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemFatalErrorTest = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemFatalError = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemFatalErrorNoStackTrace = new System.Windows.Forms.ToolStripMenuItem();
         this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
         this.menuItemFatalException = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemFatalExceptionChain = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemLostExceptionChainDemo = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemLostExceptionChain_Plain = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemLostExceptionChain_Advanced = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemLostExceptionChain_AdvancedPlus = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemHelp = new System.Windows.Forms.ToolStripMenuItem();
         this.menuItemDescription = new System.Windows.Forms.ToolStripMenuItem();
         this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
         this.menuItemAbout = new System.Windows.Forms.ToolStripMenuItem();
         this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
         this.toolStrip = new System.Windows.Forms.ToolStrip();
         this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
         this.toolStripButtonLoad = new System.Windows.Forms.ToolStripButton();
         this.toolStripButtonSave = new System.Windows.Forms.ToolStripButton();
         this.toolStripButtonSaveInputOnly = new System.Windows.Forms.ToolStripButton();
         this.toolStripButtonViewContent = new System.Windows.Forms.ToolStripButton();
         this.toolStripButtonClear = new System.Windows.Forms.ToolStripButton();
         this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
         this.toolStripButtonViewSchema = new System.Windows.Forms.ToolStripButton();
         this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
         this.toolStripButtonCustomize = new System.Windows.Forms.ToolStripButton();
         this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
         this.toolStripButtonDescription = new System.Windows.Forms.ToolStripButton();
         this.toolStripButtonAbout = new System.Windows.Forms.ToolStripButton();
         this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
         this.panelClient.SuspendLayout();
         this.panelControls.SuspendLayout();
         this.panelGraphics.SuspendLayout();
         this.statusStrip.SuspendLayout();
         this.menuStrip.SuspendLayout();
         this.toolStrip.SuspendLayout();
         this.SuspendLayout();
         // 
         // panelClient
         // 
         this.panelClient.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
         this.panelClient.Controls.Add(this.panelDataFile);
         this.panelClient.Controls.Add(this.panelControls);
         this.panelClient.Controls.Add(this.panelGraphics);
         this.panelClient.Controls.Add(this.statusStrip);
         this.panelClient.Location = new System.Drawing.Point(0,52);
         this.panelClient.Name = "panelClient";
         this.panelClient.Size = new System.Drawing.Size(592,354);
         this.panelClient.TabIndex = 0;
         // 
         // panelDataFile
         // 
         this.panelDataFile.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.panelDataFile.Dock = System.Windows.Forms.DockStyle.Top;
         this.panelDataFile.Font = new System.Drawing.Font("Times New Roman",8.25F,System.Drawing.FontStyle.Regular,System.Drawing.GraphicsUnit.Point,((byte)(204)));
         this.panelDataFile.Location = new System.Drawing.Point(0,0);
         this.panelDataFile.Name = "panelDataFile";
         this.panelDataFile.Size = new System.Drawing.Size(592,20);
         this.panelDataFile.TabIndex = 3;
         this.panelDataFile.Paint += new System.Windows.Forms.PaintEventHandler(this.panelDataFile_Paint);
         // 
         // panelControls
         // 
         this.panelControls.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
         this.panelControls.BackColor = System.Drawing.SystemColors.Control;
         this.panelControls.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.panelControls.Controls.Add(this.checkBoxMonolithicBalanceOperation);
         this.panelControls.Controls.Add(this.checkBoxBallanceCorruptionBug);
         this.panelControls.Controls.Add(this.labelEpsilonValue);
         this.panelControls.Controls.Add(this.labelEpsilon);
         this.panelControls.Controls.Add(this.labelDivergenceValue);
         this.panelControls.Controls.Add(this.labelDivergence);
         this.panelControls.Controls.Add(this.buttonReset);
         this.panelControls.Controls.Add(this.buttonStartStop);
         this.panelControls.Controls.Add(this.labelMaxDifferenceValue);
         this.panelControls.Controls.Add(this.labelIterationValue);
         this.panelControls.Controls.Add(this.labelMaxDifference);
         this.panelControls.Controls.Add(this.labelIteration);
         this.panelControls.Location = new System.Drawing.Point(0,223);
         this.panelControls.Name = "panelControls";
         this.panelControls.Size = new System.Drawing.Size(589,106);
         this.panelControls.TabIndex = 1;
         // 
         // checkBoxMonolithicBalanceOperation
         // 
         this.checkBoxMonolithicBalanceOperation.AutoSize = true;
         this.checkBoxMonolithicBalanceOperation.Location = new System.Drawing.Point(167,29);
         this.checkBoxMonolithicBalanceOperation.Name = "checkBoxMonolithicBalanceOperation";
         this.checkBoxMonolithicBalanceOperation.Size = new System.Drawing.Size(386,17);
         this.checkBoxMonolithicBalanceOperation.TabIndex = 1;
         this.checkBoxMonolithicBalanceOperation.Text = "M&onolithic Balance Operation (prevents the misidentification of an exception)";
         this.checkBoxMonolithicBalanceOperation.CheckedChanged += new System.EventHandler(this.checkBoxMonolithicBalance_CheckedChanged);
         // 
         // checkBoxBallanceCorruptionBug
         // 
         this.checkBoxBallanceCorruptionBug.AutoSize = true;
         this.checkBoxBallanceCorruptionBug.Location = new System.Drawing.Point(167,6);
         this.checkBoxBallanceCorruptionBug.Name = "checkBoxBallanceCorruptionBug";
         this.checkBoxBallanceCorruptionBug.Size = new System.Drawing.Size(387,17);
         this.checkBoxBallanceCorruptionBug.TabIndex = 0;
         this.checkBoxBallanceCorruptionBug.Text = "Ballance Corruption &Bug (demonstrates the side effect of exception catching)";
         this.checkBoxBallanceCorruptionBug.CheckedChanged += new System.EventHandler(this.checkBoxBallanceCorruption_CheckedChanged);
         // 
         // labelEpsilonValue
         // 
         this.labelEpsilonValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
         this.labelEpsilonValue.Location = new System.Drawing.Point(86,7);
         this.labelEpsilonValue.Name = "labelEpsilonValue";
         this.labelEpsilonValue.Size = new System.Drawing.Size(60,20);
         this.labelEpsilonValue.TabIndex = 11;
         this.labelEpsilonValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // labelEpsilon
         // 
         this.labelEpsilon.AutoSize = true;
         this.labelEpsilon.Location = new System.Drawing.Point(39,7);
         this.labelEpsilon.Name = "labelEpsilon";
         this.labelEpsilon.Size = new System.Drawing.Size(41,13);
         this.labelEpsilon.TabIndex = 10;
         this.labelEpsilon.Text = "Epsilon";
         // 
         // labelDivergenceValue
         // 
         this.labelDivergenceValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
         this.labelDivergenceValue.Location = new System.Drawing.Point(86,72);
         this.labelDivergenceValue.Name = "labelDivergenceValue";
         this.labelDivergenceValue.Size = new System.Drawing.Size(60,20);
         this.labelDivergenceValue.TabIndex = 9;
         this.labelDivergenceValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // labelDivergence
         // 
         this.labelDivergence.AutoSize = true;
         this.labelDivergence.Location = new System.Drawing.Point(18,72);
         this.labelDivergence.Name = "labelDivergence";
         this.labelDivergence.Size = new System.Drawing.Size(62,13);
         this.labelDivergence.TabIndex = 8;
         this.labelDivergence.Text = "Divergence";
         // 
         // buttonReset
         // 
         this.buttonReset.Cursor = System.Windows.Forms.Cursors.Hand;
         this.buttonReset.Location = new System.Drawing.Point(163,63);
         this.buttonReset.Name = "buttonReset";
         this.buttonReset.Size = new System.Drawing.Size(127,36);
         this.buttonReset.TabIndex = 2;
         this.buttonReset.Text = "Reset to &initial state";
         this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
         // 
         // buttonStartStop
         // 
         this.buttonStartStop.Cursor = System.Windows.Forms.Cursors.Hand;
         this.buttonStartStop.Location = new System.Drawing.Point(296,63);
         this.buttonStartStop.Name = "buttonStartStop";
         this.buttonStartStop.Size = new System.Drawing.Size(150,36);
         this.buttonStartStop.TabIndex = 3;
         this.buttonStartStop.Click += new System.EventHandler(this.buttonStartStop_Click);
         // 
         // labelMaxDifferenceValue
         // 
         this.labelMaxDifferenceValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
         this.labelMaxDifferenceValue.Location = new System.Drawing.Point(86,43);
         this.labelMaxDifferenceValue.Name = "labelMaxDifferenceValue";
         this.labelMaxDifferenceValue.Size = new System.Drawing.Size(60,20);
         this.labelMaxDifferenceValue.TabIndex = 2;
         this.labelMaxDifferenceValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // labelIterationValue
         // 
         this.labelIterationValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
         this.labelIterationValue.Font = new System.Drawing.Font("Microsoft Sans Serif",8.25F,System.Drawing.FontStyle.Bold,System.Drawing.GraphicsUnit.Point,((byte)(204)));
         this.labelIterationValue.Location = new System.Drawing.Point(532,72);
         this.labelIterationValue.Name = "labelIterationValue";
         this.labelIterationValue.Size = new System.Drawing.Size(46,20);
         this.labelIterationValue.TabIndex = 4;
         this.labelIterationValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // labelMaxDifference
         // 
         this.labelMaxDifference.AutoSize = true;
         this.labelMaxDifference.Location = new System.Drawing.Point(3,43);
         this.labelMaxDifference.Name = "labelMaxDifference";
         this.labelMaxDifference.Size = new System.Drawing.Size(79,13);
         this.labelMaxDifference.TabIndex = 1;
         this.labelMaxDifference.Text = "Max Difference";
         // 
         // labelIteration
         // 
         this.labelIteration.AutoSize = true;
         this.labelIteration.Location = new System.Drawing.Point(464,72);
         this.labelIteration.Name = "labelIteration";
         this.labelIteration.Size = new System.Drawing.Size(62,13);
         this.labelIteration.TabIndex = 3;
         this.labelIteration.Text = "Iteration No";
         // 
         // panelGraphics
         // 
         this.panelGraphics.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
         this.panelGraphics.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelGraphics.BackgroundImage")));
         this.panelGraphics.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.panelGraphics.Controls.Add(this.panelSummary);
         this.panelGraphics.Controls.Add(this.panelContainers);
         this.panelGraphics.Location = new System.Drawing.Point(3,26);
         this.panelGraphics.Name = "panelGraphics";
         this.panelGraphics.Size = new System.Drawing.Size(586,191);
         this.panelGraphics.TabIndex = 0;
         // 
         // panelSummary
         // 
         this.panelSummary.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
         this.panelSummary.BackColor = System.Drawing.Color.Black;
         this.panelSummary.Location = new System.Drawing.Point(3,86);
         this.panelSummary.Name = "panelSummary";
         this.panelSummary.Size = new System.Drawing.Size(576,98);
         this.panelSummary.TabIndex = 1;
         this.panelSummary.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSummary_Paint);
         // 
         // panelContainers
         // 
         this.panelContainers.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
         this.panelContainers.BackColor = System.Drawing.Color.Black;
         this.panelContainers.Location = new System.Drawing.Point(3,4);
         this.panelContainers.Name = "panelContainers";
         this.panelContainers.Size = new System.Drawing.Size(576,76);
         this.panelContainers.TabIndex = 0;
         this.panelContainers.Paint += new System.Windows.Forms.PaintEventHandler(this.panelContainers_Paint);
         // 
         // statusStrip
         // 
         this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
         this.statusStrip.Location = new System.Drawing.Point(0,332);
         this.statusStrip.Name = "statusStrip";
         this.statusStrip.Size = new System.Drawing.Size(592,22);
         this.statusStrip.TabIndex = 2;
         this.statusStrip.Text = "statusStrip";
         // 
         // toolStripStatusLabel
         // 
         this.toolStripStatusLabel.Name = "toolStripStatusLabel";
         this.toolStripStatusLabel.Size = new System.Drawing.Size(103,17);
         this.toolStripStatusLabel.Text = "toolStripStatusLabel";
         // 
         // menuStrip
         // 
         this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemFile,
            this.menuItemApproximation,
            this.menuItemTools,
            this.menuItemFatalErrorTest,
            this.menuItemLostExceptionChainDemo,
            this.menuItemHelp});
         this.menuStrip.Location = new System.Drawing.Point(0,0);
         this.menuStrip.Name = "menuStrip";
         this.menuStrip.Size = new System.Drawing.Size(592,24);
         this.menuStrip.TabIndex = 1;
         // 
         // menuItemFile
         // 
         this.menuItemFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemLoad,
            this.menuItemSave,
            this.menuItemSaveInputOnly,
            this.menuItemViewContent,
            this.menuItemClear,
            this.toolStripSeparator4,
            this.menuItemExit});
         this.menuItemFile.Name = "menuItemFile";
         this.menuItemFile.Size = new System.Drawing.Size(35,20);
         this.menuItemFile.Text = "&File";
         // 
         // menuItemLoad
         // 
         this.menuItemLoad.Image = ((System.Drawing.Image)(resources.GetObject("menuItemLoad.Image")));
         this.menuItemLoad.ImageTransparentColor = System.Drawing.Color.Silver;
         this.menuItemLoad.Name = "menuItemLoad";
         this.menuItemLoad.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
         this.menuItemLoad.Size = new System.Drawing.Size(416,22);
         this.menuItemLoad.Text = "L&oad data from XML...";
         this.menuItemLoad.Click += new System.EventHandler(this.menuItemLoad_Click);
         // 
         // menuItemSave
         // 
         this.menuItemSave.Image = ((System.Drawing.Image)(resources.GetObject("menuItemSave.Image")));
         this.menuItemSave.ImageTransparentColor = System.Drawing.Color.Silver;
         this.menuItemSave.Name = "menuItemSave";
         this.menuItemSave.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
         this.menuItemSave.Size = new System.Drawing.Size(416,22);
         this.menuItemSave.Text = "Save &all data to the file — initial and result values";
         this.menuItemSave.Click += new System.EventHandler(this.menuItemSave_Click);
         // 
         // menuItemSaveInputOnly
         // 
         this.menuItemSaveInputOnly.Image = ((System.Drawing.Image)(resources.GetObject("menuItemSaveInputOnly.Image")));
         this.menuItemSaveInputOnly.ImageTransparentColor = System.Drawing.Color.Silver;
         this.menuItemSaveInputOnly.Name = "menuItemSaveInputOnly";
         this.menuItemSaveInputOnly.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.S)));
         this.menuItemSaveInputOnly.Size = new System.Drawing.Size(416,22);
         this.menuItemSaveInputOnly.Text = "Save &input data only — no output node (\"outputData\")";
         this.menuItemSaveInputOnly.Click += new System.EventHandler(this.menuItemSaveInputOnly_Click);
         // 
         // menuItemViewContent
         // 
         this.menuItemViewContent.Image = ((System.Drawing.Image)(resources.GetObject("menuItemViewContent.Image")));
         this.menuItemViewContent.ImageTransparentColor = System.Drawing.Color.Teal;
         this.menuItemViewContent.Name = "menuItemViewContent";
         this.menuItemViewContent.ShortcutKeys = System.Windows.Forms.Keys.F12;
         this.menuItemViewContent.Size = new System.Drawing.Size(416,22);
         this.menuItemViewContent.Text = "View &content in IE";
         this.menuItemViewContent.Click += new System.EventHandler(this.menuItemViewContent_Click);
         // 
         // menuItemClear
         // 
         this.menuItemClear.Image = ((System.Drawing.Image)(resources.GetObject("menuItemClear.Image")));
         this.menuItemClear.ImageTransparentColor = System.Drawing.Color.Teal;
         this.menuItemClear.Name = "menuItemClear";
         this.menuItemClear.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Delete)));
         this.menuItemClear.Size = new System.Drawing.Size(416,22);
         this.menuItemClear.Text = "C&lear data — visually (don\'t touch the file)";
         this.menuItemClear.Click += new System.EventHandler(this.menuItemClear_Click);
         // 
         // toolStripSeparator4
         // 
         this.toolStripSeparator4.Name = "toolStripSeparator4";
         this.toolStripSeparator4.Size = new System.Drawing.Size(413,6);
         // 
         // menuItemExit
         // 
         this.menuItemExit.Name = "menuItemExit";
         this.menuItemExit.Size = new System.Drawing.Size(416,22);
         this.menuItemExit.Text = "E&xit";
         this.menuItemExit.Click += new System.EventHandler(this.menuItemExit_Click);
         // 
         // menuItemApproximation
         // 
         this.menuItemApproximation.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemBalanceCorruptionBug,
            this.menuItemMonolithicBalanceOperation,
            this.toolStripSeparator1,
            this.menuItemReset,
            this.menuItemStartStop,
            this.toolStripSeparator9,
            this.menuItemViewSchema});
         this.menuItemApproximation.Name = "menuItemApproximation";
         this.menuItemApproximation.Size = new System.Drawing.Size(88,20);
         this.menuItemApproximation.Text = "Approxi&mation";
         // 
         // menuItemBalanceCorruptionBug
         // 
         this.menuItemBalanceCorruptionBug.Image = ((System.Drawing.Image)(resources.GetObject("menuItemBalanceCorruptionBug.Image")));
         this.menuItemBalanceCorruptionBug.ImageTransparentColor = System.Drawing.Color.White;
         this.menuItemBalanceCorruptionBug.Name = "menuItemBalanceCorruptionBug";
         this.menuItemBalanceCorruptionBug.Size = new System.Drawing.Size(221,22);
         this.menuItemBalanceCorruptionBug.Text = "Balance corruption &bug";
         this.menuItemBalanceCorruptionBug.Click += new System.EventHandler(this.menuItemBalanceCorruption_Click);
         // 
         // menuItemMonolithicBalanceOperation
         // 
         this.menuItemMonolithicBalanceOperation.Image = ((System.Drawing.Image)(resources.GetObject("menuItemMonolithicBalanceOperation.Image")));
         this.menuItemMonolithicBalanceOperation.ImageTransparentColor = System.Drawing.Color.Teal;
         this.menuItemMonolithicBalanceOperation.Name = "menuItemMonolithicBalanceOperation";
         this.menuItemMonolithicBalanceOperation.Size = new System.Drawing.Size(221,22);
         this.menuItemMonolithicBalanceOperation.Text = "&Monolithic balance operation";
         this.menuItemMonolithicBalanceOperation.Click += new System.EventHandler(this.menuItemMonolithicBalance_Click);
         // 
         // toolStripSeparator1
         // 
         this.toolStripSeparator1.Name = "toolStripSeparator1";
         this.toolStripSeparator1.Size = new System.Drawing.Size(218,6);
         // 
         // menuItemReset
         // 
         this.menuItemReset.Image = ((System.Drawing.Image)(resources.GetObject("menuItemReset.Image")));
         this.menuItemReset.ImageTransparentColor = System.Drawing.Color.White;
         this.menuItemReset.Name = "menuItemReset";
         this.menuItemReset.Size = new System.Drawing.Size(221,22);
         this.menuItemReset.Text = "Reset to &initial state";
         this.menuItemReset.Click += new System.EventHandler(this.menuItemReset_Click);
         // 
         // menuItemStartStop
         // 
         this.menuItemStartStop.Name = "menuItemStartStop";
         this.menuItemStartStop.Size = new System.Drawing.Size(221,22);
         this.menuItemStartStop.Click += new System.EventHandler(this.menuItemStartStop_Click);
         // 
         // toolStripSeparator9
         // 
         this.toolStripSeparator9.Name = "toolStripSeparator9";
         this.toolStripSeparator9.Size = new System.Drawing.Size(218,6);
         // 
         // menuItemViewSchema
         // 
         this.menuItemViewSchema.Image = ((System.Drawing.Image)(resources.GetObject("menuItemViewSchema.Image")));
         this.menuItemViewSchema.ImageTransparentColor = System.Drawing.Color.White;
         this.menuItemViewSchema.Name = "menuItemViewSchema";
         this.menuItemViewSchema.Size = new System.Drawing.Size(221,22);
         this.menuItemViewSchema.Text = "&View XML-schema in IE";
         this.menuItemViewSchema.Click += new System.EventHandler(this.menuItemViewSchema_Click);
         // 
         // menuItemTools
         // 
         this.menuItemTools.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemCustomize});
         this.menuItemTools.Name = "menuItemTools";
         this.menuItemTools.Size = new System.Drawing.Size(44,20);
         this.menuItemTools.Text = "&Tools";
         // 
         // menuItemCustomize
         // 
         this.menuItemCustomize.Image = ((System.Drawing.Image)(resources.GetObject("menuItemCustomize.Image")));
         this.menuItemCustomize.ImageTransparentColor = System.Drawing.Color.Black;
         this.menuItemCustomize.Name = "menuItemCustomize";
         this.menuItemCustomize.ShortcutKeys = System.Windows.Forms.Keys.F9;
         this.menuItemCustomize.Size = new System.Drawing.Size(165,22);
         this.menuItemCustomize.Text = "&Customize...";
         this.menuItemCustomize.Click += new System.EventHandler(this.menuItemCustomize_Click);
         // 
         // menuItemFatalErrorTest
         // 
         this.menuItemFatalErrorTest.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemFatalError,
            this.menuItemFatalErrorNoStackTrace,
            this.toolStripSeparator2,
            this.menuItemFatalException,
            this.menuItemFatalExceptionChain});
         this.menuItemFatalErrorTest.Name = "menuItemFatalErrorTest";
         this.menuItemFatalErrorTest.Size = new System.Drawing.Size(94,20);
         this.menuItemFatalErrorTest.Text = "Fatal &Error Test";
         // 
         // menuItemFatalError
         // 
         this.menuItemFatalError.Image = ((System.Drawing.Image)(resources.GetObject("menuItemFatalError.Image")));
         this.menuItemFatalError.ImageTransparentColor = System.Drawing.Color.Teal;
         this.menuItemFatalError.Name = "menuItemFatalError";
         this.menuItemFatalError.Size = new System.Drawing.Size(581,22);
         this.menuItemFatalError.Text = "Emulate fatal error with stack trace (default for \"SysUtils.FatalError.Perform\")";
         this.menuItemFatalError.Click += new System.EventHandler(this.menuItemFatalError_Click);
         // 
         // menuItemFatalErrorNoStackTrace
         // 
         this.menuItemFatalErrorNoStackTrace.Image = ((System.Drawing.Image)(resources.GetObject("menuItemFatalErrorNoStackTrace.Image")));
         this.menuItemFatalErrorNoStackTrace.ImageTransparentColor = System.Drawing.Color.Teal;
         this.menuItemFatalErrorNoStackTrace.Name = "menuItemFatalErrorNoStackTrace";
         this.menuItemFatalErrorNoStackTrace.Size = new System.Drawing.Size(581,22);
         this.menuItemFatalErrorNoStackTrace.Text = "Emulate fatal error without stack trace (null \"stackTrace\" parameter)";
         this.menuItemFatalErrorNoStackTrace.Click += new System.EventHandler(this.menuItemFatalErrorNoStackTrace_Click);
         // 
         // toolStripSeparator2
         // 
         this.toolStripSeparator2.Name = "toolStripSeparator2";
         this.toolStripSeparator2.Size = new System.Drawing.Size(578,6);
         // 
         // menuItemFatalException
         // 
         this.menuItemFatalException.Image = ((System.Drawing.Image)(resources.GetObject("menuItemFatalException.Image")));
         this.menuItemFatalException.ImageTransparentColor = System.Drawing.Color.Teal;
         this.menuItemFatalException.Name = "menuItemFatalException";
         this.menuItemFatalException.Size = new System.Drawing.Size(581,22);
         this.menuItemFatalException.Text = "Throw exception to be caught at top level (in \"Program.ThreadExceptionEventHandle" +
    "r\")";
         this.menuItemFatalException.Click += new System.EventHandler(this.menuItemFatalException_Click);
         // 
         // menuItemFatalExceptionChain
         // 
         this.menuItemFatalExceptionChain.Image = ((System.Drawing.Image)(resources.GetObject("menuItemFatalExceptionChain.Image")));
         this.menuItemFatalExceptionChain.ImageTransparentColor = System.Drawing.Color.Teal;
         this.menuItemFatalExceptionChain.Name = "menuItemFatalExceptionChain";
         this.menuItemFatalExceptionChain.Size = new System.Drawing.Size(581,22);
         this.menuItemFatalExceptionChain.Text = "Throw exception to be caught at top level — exception chain (organized via \"Inner" +
    "Exception\" property)";
         this.menuItemFatalExceptionChain.Click += new System.EventHandler(this.menuItemFatalExceptionChain_Click);
         // 
         // menuItemLostExceptionChainDemo
         // 
         this.menuItemLostExceptionChainDemo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemLostExceptionChain_Plain,
            this.menuItemLostExceptionChain_Advanced,
            this.menuItemLostExceptionChain_AdvancedPlus});
         this.menuItemLostExceptionChainDemo.Name = "menuItemLostExceptionChainDemo";
         this.menuItemLostExceptionChainDemo.Size = new System.Drawing.Size(149,20);
         this.menuItemLostExceptionChainDemo.Text = "&Lost Exception Chain Demo";
         // 
         // menuItemLostExceptionChain_Plain
         // 
         this.menuItemLostExceptionChain_Plain.Image = ((System.Drawing.Image)(resources.GetObject("menuItemLostExceptionChain_Plain.Image")));
         this.menuItemLostExceptionChain_Plain.ImageTransparentColor = System.Drawing.Color.White;
         this.menuItemLostExceptionChain_Plain.Name = "menuItemLostExceptionChain_Plain";
         this.menuItemLostExceptionChain_Plain.Size = new System.Drawing.Size(564,22);
         this.menuItemLostExceptionChain_Plain.Text = "&Plain demonstration — \"Serious Error\" exception chain is really lost";
         this.menuItemLostExceptionChain_Plain.Click += new System.EventHandler(this.menuItemLostExceptionChain_Plain_Click);
         // 
         // menuItemLostExceptionChain_Advanced
         // 
         this.menuItemLostExceptionChain_Advanced.Image = ((System.Drawing.Image)(resources.GetObject("menuItemLostExceptionChain_Advanced.Image")));
         this.menuItemLostExceptionChain_Advanced.ImageTransparentColor = System.Drawing.Color.White;
         this.menuItemLostExceptionChain_Advanced.Name = "menuItemLostExceptionChain_Advanced";
         this.menuItemLostExceptionChain_Advanced.Size = new System.Drawing.Size(564,22);
         this.menuItemLostExceptionChain_Advanced.Text = "&Advanced demonstration — do not loose exceptions";
         this.menuItemLostExceptionChain_Advanced.Click += new System.EventHandler(this.menuItemLostExceptionChain_Advanced_Click);
         // 
         // menuItemLostExceptionChain_AdvancedPlus
         // 
         this.menuItemLostExceptionChain_AdvancedPlus.Image = ((System.Drawing.Image)(resources.GetObject("menuItemLostExceptionChain_AdvancedPlus.Image")));
         this.menuItemLostExceptionChain_AdvancedPlus.ImageTransparentColor = System.Drawing.Color.White;
         this.menuItemLostExceptionChain_AdvancedPlus.Name = "menuItemLostExceptionChain_AdvancedPlus";
         this.menuItemLostExceptionChain_AdvancedPlus.Size = new System.Drawing.Size(564,22);
         this.menuItemLostExceptionChain_AdvancedPlus.Text = "A&dvanced+ demonstration — do not loose exceptions (+SysUtils.DeterministicFinali" +
    "zationException)";
         this.menuItemLostExceptionChain_AdvancedPlus.Click += new System.EventHandler(this.menuItemLostExceptionChain_AdvancedPlus_Click);
         // 
         // menuItemHelp
         // 
         this.menuItemHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemDescription,
            this.toolStripSeparator10,
            this.menuItemAbout});
         this.menuItemHelp.Name = "menuItemHelp";
         this.menuItemHelp.Size = new System.Drawing.Size(40,20);
         this.menuItemHelp.Text = "&Help";
         // 
         // menuItemDescription
         // 
         this.menuItemDescription.Image = ((System.Drawing.Image)(resources.GetObject("menuItemDescription.Image")));
         this.menuItemDescription.ImageTransparentColor = System.Drawing.Color.Black;
         this.menuItemDescription.Name = "menuItemDescription";
         this.menuItemDescription.ShortcutKeys = System.Windows.Forms.Keys.F1;
         this.menuItemDescription.Size = new System.Drawing.Size(181,22);
         this.menuItemDescription.Text = "View &description";
         this.menuItemDescription.Click += new System.EventHandler(this.menuItemDescription_Click);
         // 
         // toolStripSeparator10
         // 
         this.toolStripSeparator10.Name = "toolStripSeparator10";
         this.toolStripSeparator10.Size = new System.Drawing.Size(178,6);
         // 
         // menuItemAbout
         // 
         this.menuItemAbout.Image = ((System.Drawing.Image)(resources.GetObject("menuItemAbout.Image")));
         this.menuItemAbout.ImageTransparentColor = System.Drawing.Color.Cyan;
         this.menuItemAbout.Name = "menuItemAbout";
         this.menuItemAbout.Size = new System.Drawing.Size(181,22);
         this.menuItemAbout.Text = "&About";
         this.menuItemAbout.Click += new System.EventHandler(this.menuItemAbout_Click);
         // 
         // openFileDialog
         // 
         this.openFileDialog.DefaultExt = "xml";
         this.openFileDialog.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*";
         this.openFileDialog.RestoreDirectory = true;
         this.openFileDialog.Title = "Open approximation data file";
         // 
         // toolStrip
         // 
         this.toolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
         this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator3,
            this.toolStripButtonLoad,
            this.toolStripButtonSave,
            this.toolStripButtonSaveInputOnly,
            this.toolStripButtonViewContent,
            this.toolStripButtonClear,
            this.toolStripSeparator8,
            this.toolStripButtonViewSchema,
            this.toolStripSeparator7,
            this.toolStripButtonCustomize,
            this.toolStripSeparator6,
            this.toolStripButtonDescription,
            this.toolStripButtonAbout,
            this.toolStripSeparator5});
         this.toolStrip.Location = new System.Drawing.Point(0,24);
         this.toolStrip.Name = "toolStrip";
         this.toolStrip.Size = new System.Drawing.Size(592,25);
         this.toolStrip.TabIndex = 2;
         this.toolStrip.Text = "toolStrip";
         // 
         // toolStripSeparator3
         // 
         this.toolStripSeparator3.Name = "toolStripSeparator3";
         this.toolStripSeparator3.Size = new System.Drawing.Size(6,25);
         // 
         // toolStripButtonLoad
         // 
         this.toolStripButtonLoad.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.toolStripButtonLoad.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLoad.Image")));
         this.toolStripButtonLoad.ImageTransparentColor = System.Drawing.Color.Silver;
         this.toolStripButtonLoad.Name = "toolStripButtonLoad";
         this.toolStripButtonLoad.Size = new System.Drawing.Size(23,22);
         this.toolStripButtonLoad.Click += new System.EventHandler(this.toolStripButtonLoad_Click);
         // 
         // toolStripButtonSave
         // 
         this.toolStripButtonSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.toolStripButtonSave.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSave.Image")));
         this.toolStripButtonSave.ImageTransparentColor = System.Drawing.Color.Silver;
         this.toolStripButtonSave.Name = "toolStripButtonSave";
         this.toolStripButtonSave.Size = new System.Drawing.Size(23,22);
         this.toolStripButtonSave.Click += new System.EventHandler(this.toolStripButtonSave_Click);
         // 
         // toolStripButtonSaveInputOnly
         // 
         this.toolStripButtonSaveInputOnly.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.toolStripButtonSaveInputOnly.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSaveInputOnly.Image")));
         this.toolStripButtonSaveInputOnly.ImageTransparentColor = System.Drawing.Color.Silver;
         this.toolStripButtonSaveInputOnly.Name = "toolStripButtonSaveInputOnly";
         this.toolStripButtonSaveInputOnly.Size = new System.Drawing.Size(23,22);
         this.toolStripButtonSaveInputOnly.Click += new System.EventHandler(this.toolStripButtonSaveInputOnly_Click);
         // 
         // toolStripButtonViewContent
         // 
         this.toolStripButtonViewContent.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.toolStripButtonViewContent.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonViewContent.Image")));
         this.toolStripButtonViewContent.ImageTransparentColor = System.Drawing.Color.Teal;
         this.toolStripButtonViewContent.Name = "toolStripButtonViewContent";
         this.toolStripButtonViewContent.Size = new System.Drawing.Size(23,22);
         this.toolStripButtonViewContent.Click += new System.EventHandler(this.toolStripButtonViewContent_Click);
         // 
         // toolStripButtonClear
         // 
         this.toolStripButtonClear.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.toolStripButtonClear.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonClear.Image")));
         this.toolStripButtonClear.ImageTransparentColor = System.Drawing.Color.Teal;
         this.toolStripButtonClear.Name = "toolStripButtonClear";
         this.toolStripButtonClear.Size = new System.Drawing.Size(23,22);
         this.toolStripButtonClear.Click += new System.EventHandler(this.toolStripButtonClear_Click);
         // 
         // toolStripSeparator8
         // 
         this.toolStripSeparator8.Name = "toolStripSeparator8";
         this.toolStripSeparator8.Size = new System.Drawing.Size(6,25);
         // 
         // toolStripButtonViewSchema
         // 
         this.toolStripButtonViewSchema.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.toolStripButtonViewSchema.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonViewSchema.Image")));
         this.toolStripButtonViewSchema.ImageTransparentColor = System.Drawing.Color.White;
         this.toolStripButtonViewSchema.Name = "toolStripButtonViewSchema";
         this.toolStripButtonViewSchema.Size = new System.Drawing.Size(23,22);
         this.toolStripButtonViewSchema.Text = "toolStripButton1";
         this.toolStripButtonViewSchema.Click += new System.EventHandler(this.toolStripButtonViewSchema_Click);
         // 
         // toolStripSeparator7
         // 
         this.toolStripSeparator7.Name = "toolStripSeparator7";
         this.toolStripSeparator7.Size = new System.Drawing.Size(6,25);
         // 
         // toolStripButtonCustomize
         // 
         this.toolStripButtonCustomize.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.toolStripButtonCustomize.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonCustomize.Image")));
         this.toolStripButtonCustomize.ImageTransparentColor = System.Drawing.Color.Black;
         this.toolStripButtonCustomize.Name = "toolStripButtonCustomize";
         this.toolStripButtonCustomize.Size = new System.Drawing.Size(23,22);
         this.toolStripButtonCustomize.Click += new System.EventHandler(this.toolStripButtonCustomize_Click);
         // 
         // toolStripSeparator6
         // 
         this.toolStripSeparator6.Name = "toolStripSeparator6";
         this.toolStripSeparator6.Size = new System.Drawing.Size(6,25);
         // 
         // toolStripButtonDescription
         // 
         this.toolStripButtonDescription.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.toolStripButtonDescription.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonDescription.Image")));
         this.toolStripButtonDescription.ImageTransparentColor = System.Drawing.Color.Black;
         this.toolStripButtonDescription.Name = "toolStripButtonDescription";
         this.toolStripButtonDescription.Size = new System.Drawing.Size(23,22);
         this.toolStripButtonDescription.Click += new System.EventHandler(this.toolStripButtonDescription_Click);
         // 
         // toolStripButtonAbout
         // 
         this.toolStripButtonAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.toolStripButtonAbout.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAbout.Image")));
         this.toolStripButtonAbout.ImageTransparentColor = System.Drawing.Color.Cyan;
         this.toolStripButtonAbout.Name = "toolStripButtonAbout";
         this.toolStripButtonAbout.Size = new System.Drawing.Size(23,22);
         this.toolStripButtonAbout.Click += new System.EventHandler(this.toolStripButtonAbout_Click);
         // 
         // toolStripSeparator5
         // 
         this.toolStripSeparator5.Name = "toolStripSeparator5";
         this.toolStripSeparator5.Size = new System.Drawing.Size(6,25);
         // 
         // FormMain
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(592,406);
         this.Controls.Add(this.toolStrip);
         this.Controls.Add(this.panelClient);
         this.Controls.Add(this.menuStrip);
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.KeyPreview = true;
         this.MainMenuStrip = this.menuStrip;
         this.Name = "FormMain";
         this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
         this.Text = "Balance Demo App. (The Back Side of Exceptions)";
         this.Resize += new System.EventHandler(this.FormMain_Resize);
         this.Shown += new System.EventHandler(this.FormMain_Shown);
         this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
         this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FormMain_KeyDown);
         this.Load += new System.EventHandler(this.FormMain_Load);
         this.panelClient.ResumeLayout(false);
         this.panelClient.PerformLayout();
         this.panelControls.ResumeLayout(false);
         this.panelControls.PerformLayout();
         this.panelGraphics.ResumeLayout(false);
         this.statusStrip.ResumeLayout(false);
         this.statusStrip.PerformLayout();
         this.menuStrip.ResumeLayout(false);
         this.menuStrip.PerformLayout();
         this.toolStrip.ResumeLayout(false);
         this.toolStrip.PerformLayout();
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.Panel panelClient;
      private System.Windows.Forms.Panel panelGraphics;
      private System.Windows.Forms.Panel panelControls;
      private System.Windows.Forms.Label labelIteration;
      private System.Windows.Forms.Label labelMaxDifference;
      private System.Windows.Forms.Label labelIterationValue;
      private System.Windows.Forms.Label labelMaxDifferenceValue;
      private System.Windows.Forms.CheckBox checkBoxBallanceCorruptionBug;
      private System.Windows.Forms.Button buttonStartStop;
      private System.Windows.Forms.Panel panelContainers;
      private System.Windows.Forms.Panel panelSummary;
      private System.Windows.Forms.Button buttonReset;
      private System.Windows.Forms.StatusStrip statusStrip;
      private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
      private System.Windows.Forms.Label labelDivergence;
      private System.Windows.Forms.Label labelDivergenceValue;
      private System.Windows.Forms.MenuStrip menuStrip;
      private System.Windows.Forms.ToolStripMenuItem menuItemFile;
      private System.Windows.Forms.ToolStripMenuItem menuItemExit;
      private System.Windows.Forms.ToolStripMenuItem menuItemHelp;
      private System.Windows.Forms.ToolStripMenuItem menuItemAbout;
      private System.Windows.Forms.ToolStripMenuItem menuItemApproximation;
      private System.Windows.Forms.ToolStripMenuItem menuItemBalanceCorruptionBug;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
      private System.Windows.Forms.ToolStripMenuItem menuItemReset;
      private System.Windows.Forms.ToolStripMenuItem menuItemStartStop;
      private System.Windows.Forms.CheckBox checkBoxMonolithicBalanceOperation;
      private System.Windows.Forms.ToolStripMenuItem menuItemFatalErrorTest;
      private System.Windows.Forms.ToolStripMenuItem menuItemFatalError;
      private System.Windows.Forms.ToolStripMenuItem menuItemFatalErrorNoStackTrace;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
      private System.Windows.Forms.ToolStripMenuItem menuItemFatalException;
      private System.Windows.Forms.ToolStripMenuItem menuItemFatalExceptionChain;
      private System.Windows.Forms.ToolStripMenuItem menuItemMonolithicBalanceOperation;
      private System.Windows.Forms.ToolStripMenuItem menuItemLoad;
      private System.Windows.Forms.ToolStripMenuItem menuItemClear;
      private System.Windows.Forms.OpenFileDialog openFileDialog;
      private System.Windows.Forms.ToolStripMenuItem menuItemSave;
      private System.Windows.Forms.ToolStripMenuItem menuItemSaveInputOnly;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
      private System.Windows.Forms.Panel panelDataFile;
      private System.Windows.Forms.Label labelEpsilon;
      private System.Windows.Forms.Label labelEpsilonValue;
      private System.Windows.Forms.ToolStripMenuItem menuItemDescription;
      private System.Windows.Forms.ToolStripMenuItem menuItemViewContent;
      private System.Windows.Forms.ToolStrip toolStrip;
      private System.Windows.Forms.ToolStripButton toolStripButtonLoad;
      private System.Windows.Forms.ToolStripButton toolStripButtonSave;
      private System.Windows.Forms.ToolStripButton toolStripButtonSaveInputOnly;
      private System.Windows.Forms.ToolStripButton toolStripButtonViewContent;
      private System.Windows.Forms.ToolStripButton toolStripButtonClear;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
      private System.Windows.Forms.ToolStripButton toolStripButtonDescription;
      private System.Windows.Forms.ToolStripButton toolStripButtonAbout;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
      private System.Windows.Forms.ToolStripMenuItem menuItemTools;
      private System.Windows.Forms.ToolStripMenuItem menuItemCustomize;
      private System.Windows.Forms.ToolStripButton toolStripButtonCustomize;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
      private System.Windows.Forms.ToolStripMenuItem menuItemViewSchema;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
      private System.Windows.Forms.ToolStripButton toolStripButtonViewSchema;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
      private System.Windows.Forms.ToolStripMenuItem menuItemLostExceptionChainDemo;
      private System.Windows.Forms.ToolStripMenuItem menuItemLostExceptionChain_Plain;
      private System.Windows.Forms.ToolStripMenuItem menuItemLostExceptionChain_Advanced;
      private System.Windows.Forms.ToolStripMenuItem menuItemLostExceptionChain_AdvancedPlus;
   }
}

