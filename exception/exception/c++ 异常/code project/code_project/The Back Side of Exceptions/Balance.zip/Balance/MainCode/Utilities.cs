﻿namespace Balance {

using System;
using System.Reflection;
using System.Diagnostics;
using System.IO;

//***********************************************************************************************
static class Utilities {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public static void PlaySound(string strSoundName)
{
   PlaySoundEx(strSoundName,false);
}

public static void SyncPlaySound(string strSoundName)
{
   PlaySoundEx(strSoundName,true);
}

//-----------------------------------------------------------------------------------------------

public static void CloseProcess(ref Process process)
{
   CloseProcess(ref process,false);
}

public static void CloseProcess(ref Process process,bool bUseExitTimeout)
{
   if (process!=null)
   {
      try {
         if (!process.HasExited)
         {
            process.CloseMainWindow();
            if (bUseExitTimeout)
               process.WaitForExit(c_nProcessWaitTimeout);
         }
      }
      catch (SystemException) {}

      process.Close();
      process=null;
   }
}

public static bool WaitForInputIdleProcess(Process process)
{
   return process==null ? false :
      process.WaitForInputIdle(c_nProcessWaitTimeout);
}

//===============================================================================================

static void PlaySoundEx(string strSoundName,bool bSyncPlay)
{
   string strSoundFile=Path.Combine( Program.SoundPath,
      SysUtils.Resources.STR(string.Format("SoundFileName_{0}",strSoundName)) );
   if (File.Exists(strSoundFile))
      SysUtils.SoundPlay.PlaySoundFile(strSoundFile,bSyncPlay);
}

//-----------------------------------------------------------------------------------------------

const int
   c_nProcessWaitTimeout=5000;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // Common
//***********************************************************************************************

} // Balance
