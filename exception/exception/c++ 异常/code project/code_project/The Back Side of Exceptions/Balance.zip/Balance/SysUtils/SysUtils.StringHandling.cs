﻿namespace SysUtils {

using System;
using System.Collections.Generic;

//***********************************************************************************************
static class StringHandling {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public static string[] SplitWhitespaceSeparatedList(string strTerms)
{
   List<string>
      termList=new List<string>();
   string
      sss=strTerms+' ';
   int
      idxHead=0;

   for (int i=1;i<sss.Length;i++)
      if (!char.IsWhiteSpace(sss,i-1) && char.IsWhiteSpace(sss,i))
      {
         termList.Add(
            sss.Substring(idxHead,i-idxHead).TrimStart() );
         idxHead=i+1;
      }

   string[] rslt=new string[termList.Count];
   termList.CopyTo(rslt);

   return rslt;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // StringHandling
//***********************************************************************************************

} // SysUtils
