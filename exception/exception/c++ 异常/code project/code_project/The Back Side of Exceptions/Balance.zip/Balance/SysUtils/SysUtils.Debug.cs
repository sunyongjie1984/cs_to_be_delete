﻿namespace SysUtils {

using System;
using System.Diagnostics;
using System.Reflection;

//***********************************************************************************************
static class Debug {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[Conditional("DEBUG")]
public static void PrintMessage(string strMessage)
{
   SysUtils.Trace.PrintMessage(strMessage);
}

[Conditional("DEBUG")]
public static void PrintMessage(string strMessageFmt,params object[] aobArgs)
{
   SysUtils.Trace.PrintMessage(strMessageFmt,aobArgs);
}

//-----------------------------------------------------------------------------------------------

[Conditional("DEBUG")]
public static void PrintError(string strMessage)
{
   SysUtils.Trace.PrintError(strMessage);
}

[Conditional("DEBUG")]
public static void PrintError(string strMessageFmt,params object[] aobArgs)
{
   SysUtils.Trace.PrintError(strMessageFmt,aobArgs);
}

//-----------------------------------------------------------------------------------------------

[Conditional("DEBUG")]
public static void PrintOperation(string strOperation)
{
   SysUtils.Trace.PrintOperation(strOperation);
}

[Conditional("DEBUG")]
public static void PrintOperation(string strOperation,string strMessage)
{
   SysUtils.Trace.PrintOperation(strOperation,strMessage);
}

[Conditional("DEBUG")]
public static void PrintOperation( string strOperation,
                                   string strMessageFmt,
                                   params object[] aobArgs )

{
   SysUtils.Trace.PrintOperation(strOperation,strMessageFmt,aobArgs);
}

//-----------------------------------------------------------------------------------------------

[Conditional("DEBUG")]
public static void PrintInMethod(MethodBase method)
{
   PrintOperation(InMethodPhrase(method));
}

[Conditional("DEBUG")]
public static void PrintInMethod(MethodBase method,string strMessage)
{
   PrintOperation(InMethodPhrase(method),strMessage);
}

[Conditional("DEBUG")]
public static void PrintInMethod(MethodBase method,string strMessageFmt,params object[] aobArgs)
{
   PrintOperation(InMethodPhrase(method),strMessageFmt,aobArgs);
}

[Conditional("DEBUG")]
public static void PrintOutOfMethod(MethodBase method)
{
   PrintOperation(string.Format("\"{0}\" -- OUT",method.Name));
}

//===============================================================================================

static string InMethodPhrase(MethodBase method)
{
   return string.Format("In \"{0}\"",method.Name);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // Debug
//***********************************************************************************************

} // SysUtils
