﻿namespace Balance {

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

//***********************************************************************************************
/// <summary>
/// Container component change handler prototype.
/// It can be used for any accompaniment action such as UI update or trace.
/// </summary>
/// <param name="container">Container, whose component was changed.</param>
/// <param name="nComponentIdx">Index of component, that was changed.</param>
/// <remarks>
/// No exceptions should be generated.
/// </remarks>
delegate void ComponentChangeAccompanimentDelegate(
   CompoundContainer container,
   int nComponentIdx );
//***********************************************************************************************


//***********************************************************************************************
class ComponentEnumerator: IEnumerator {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public ComponentEnumerator(CompoundContainer container)
{
   i_Container=container; i_nIdxOfCurrent=-1;
}

public object Current
{
   get
   {
      if (i_nIdxOfCurrent<0 || i_nIdxOfCurrent>=i_Container.ComponentCount)
         throw new InvalidOperationException(
            "Attempt to access component at invalid position during enumeration.");
      return i_Container[i_nIdxOfCurrent];
   }
}

public bool MoveNext()
{
   if (i_nIdxOfCurrent==i_Container.ComponentCount-1)
      return false;
   i_nIdxOfCurrent++;
   return true;
}

public void Reset()
{
   i_nIdxOfCurrent=-1;
}

CompoundContainer i_Container;
int i_nIdxOfCurrent;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // ComponentEnumerator
//***********************************************************************************************


//***********************************************************************************************
class CompoundContainer: ICloneable,IEnumerable {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public CompoundContainer(params CalcType[] values)
   :this((ICollection<CalcType>)values)
{}

public CompoundContainer(ICollection<CalcType> collection)
{
   collection.CopyTo(i_Components=new CalcType[collection.Count],0);
}

public CompoundContainer(CompoundContainer container)
   :this(container.i_Components)
{}

public ComponentChangeAccompanimentDelegate ComponentChangeAccompaniment=null;

public int ComponentCount
   { get { return i_Components.Length; } }

public CalcType this[int nIdx]
   { get { return i_Components[nIdx]; } }

public CalcType TotalQuantity
{
   get
   {
      if (!i_bTotalQuantityUpToDate)
      {
         i_TotalQuantity=GenAlgs.Sum(i_Components);
         i_bTotalQuantityUpToDate=true;
      }
      return i_TotalQuantity;
   }
}

public CompoundContainer Duplicate
   { get { return (CompoundContainer)Clone(); } }

public object Clone()
{
   return new CompoundContainer(this);
}

public IEnumerator GetEnumerator()
{
   return new ComponentEnumerator(this);
}

public override string ToString()
{
   StringBuilder sb=new StringBuilder("(");
   for (int i=0;i<ComponentCount;i++)
   {
   #pragma warning disable 0429 // Unreachable expression code detected
      if (i>0) sb.Append(CalcType.DecimalSeparator=="." ? "," : ";");
   #pragma warning restore 0429 // Unreachable expression code detected
      sb.Append(i_Components[i].Value.ToString());
   }
   sb.Append(")");
   return sb.ToString();
}

/// <summary>
/// Performing intercomponent transfer internal for the container.
/// This method throws <see cref="ArgumentException"/> to inform, that transfer value
/// is too large and operation can not be performed.
/// In a normal case, a <see cref="bool" /> value should be returned instead of throwing the
/// exception, but this is a demo program, and such error reporting way has been choosed
/// specially to show you the side effect of exception catching at the upper level code.
/// </summary>
/// <remarks>
/// This code is in the middle level (in terms of the monolithic code block).
/// See <see cref="Approximation.PerformIteration"/> (upper level code)
/// and <see cref="ExternalSource.BarBox.RedrawBar"/> (lower level code).
/// </remarks>
/// <param name="nComponentIdx_1">Component index to decrease quantity.</param>
/// <param name="nComponentIdx_2">Component index to increase quantity.</param>
/// <param name="internalTransfer">Intercomponent transfer value.</param>
public /*monolithic*/ void Balance( int nComponentIdx_1,
                                    int nComponentIdx_2,
                                    CalcType internalTransfer )
{
   CalcType newValue_1,newValue_2;

   // This exception throwing does not designates an error:
   if ( (newValue_1=i_Components[nComponentIdx_1]-internalTransfer)<0 ||
        (newValue_2=i_Components[nComponentIdx_2]+internalTransfer)<0 )
      throw new ArgumentException(
         "Can not perform the balance operation because it causes negative component value." );

   if (MonolithicBalanceOperation)
      // === Implementing monolithic code block (protected from unexpected exceptions):
      try
      {
         // This is transactional action (the both component changes must succeed):
         ChangeComponent(nComponentIdx_1,newValue_1);
         ChangeComponent(nComponentIdx_2,newValue_2);
      }
      catch (Exception ex)
      {
/*
         // === Alternative way (against exception forwarding) to handle fatal error: ===
         SysUtils.FatalError.Perform(new SysUtils.MonolithicCodeViolationException(ex));
*/
/*
         // === Alternative way (against exception forwarding) to handle fatal error: ===
         SysUtils.FatalError.Perform(
            new SysUtils.MonolithicCodeViolationException(ex),
            new System.Diagnostics.StackTrace(true) );
*/
         // Throwing "fatal" exception -- "MonolithicCodeViolationException":
         throw new SysUtils.MonolithicCodeViolationException(ex);
      }
   else
   // === Implementing non-monolithic code block (unprotected from unexpected exceptions):
   {
      // This is transactional complex action (the both component changes must succeed):
      ChangeComponent(nComponentIdx_1,newValue_1);
      ChangeComponent(nComponentIdx_2,newValue_2);
   }
}

//===============================================================================================

/// <remarks>
/// Here the lower level code is invoked (lower level is in terms of the monolithic code block).
/// This is done by the <see cref="ComponentChangeAccompaniment"/> delegate.
/// See <see cref="ExternalSource.BarBox.RedrawBar"/>.
/// </remarks>
void ChangeComponent(int nIdx,CalcType newValue)
{
   i_Components[nIdx]=newValue;
   InvalidateQuickProperties();
   if (ComponentChangeAccompaniment!=null)
      ComponentChangeAccompaniment(this,nIdx);
}

void SetComponentPair(int nIdx_1,CalcType value_1,int nIdx_2,CalcType value_2)
{
   ChangeComponent(nIdx_1,value_1);
   ChangeComponent(nIdx_2,value_2);
}

void InvalidateQuickProperties()
{
   i_bTotalQuantityUpToDate=false;
}

CalcType[]  i_Components;
CalcType    i_TotalQuantity;
bool        i_bTotalQuantityUpToDate;

//===============================================================================================

public static bool MonolithicBalanceOperation=false;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // CompoundContainer
//***********************************************************************************************

} // Balance
