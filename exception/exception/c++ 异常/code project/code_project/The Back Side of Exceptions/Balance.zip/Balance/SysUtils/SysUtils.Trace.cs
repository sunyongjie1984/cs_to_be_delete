﻿namespace SysUtils {

using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

//***********************************************************************************************
static class Trace {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[Conditional("TRACE")]
public static void PrintMessage(string strMessage)
{
   PrintMessageEx(strMessage,false);
}

[Conditional("TRACE")]
public static void PrintMessage(string strMessageFmt,params object[] aobArgs)
{
   PrintMessageEx(strMessageFmt,aobArgs,false);
}

//-----------------------------------------------------------------------------------------------

[Conditional("TRACE")]
public static void PrintError(string strMessage)
{
   PrintMessageEx(strMessage,true);
}

[Conditional("TRACE")]
public static void PrintError(string strMessageFmt,params object[] aobArgs)
{
   PrintMessageEx(strMessageFmt,aobArgs,true);
}

//-----------------------------------------------------------------------------------------------

[Conditional("TRACE")]
public static void PrintOperation(string strOperation)
{
   PrintMessage("* {0} ...",strOperation);
}

[Conditional("TRACE")]
public static void PrintOperation(string strOperation,string strMessage)
{
   PrintMessage("* {0}: {1} ...",strOperation,strMessage);
}

[Conditional("TRACE")]
public static void PrintOperation( string strOperation,
                                   string strMessageFmt,
                                   params object[] aobArgs )
{
   PrintOperation(strOperation,string.Format(strMessageFmt,aobArgs));
}

//===============================================================================================

static void PrintMessageEx(string strMessage,bool bErrorDecoration)
{
   System.Diagnostics.Trace.WriteLine(
      DecorateMessage(strMessage,bErrorDecoration) );
}

static void PrintMessageEx(string strMessageFmt,object[] aobArgs,bool bErrorDecoration)
{
   PrintMessageEx(string.Format(strMessageFmt,aobArgs),bErrorDecoration);
}

static string DecorateMessage(string strMessage,bool bErrorDecoration)
{
   string strPrefix=
      RootInfo.ApplicationExeName+c_strDecorationSeparator+
      (bErrorDecoration ? c_strDecorationErrorPrefix : "");

   StringBuilder sb=new StringBuilder(strPrefix);

   for (int i=0;i<strMessage.Length;i++)
   {
      char ch=strMessage[i];
      if (ch=='\n' && i==strMessage.Length-1)
         break;
      sb.Append(ch);
      if (ch=='\n')
         sb.Append(strPrefix);
   }

   return sb.ToString();
}

//-----------------------------------------------------------------------------------------------

const string
   c_strDecorationErrorPrefix= "## ",
   c_strDecorationSeparator=" >> ";

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // Trace
//***********************************************************************************************

} // SysUtils
