﻿namespace SysUtils {

using System;
using System.Reflection;

//***********************************************************************************************
/// <summary>
/// This exception does not designates an error.
/// It is specially used to distinguish where new exception chain begins.
/// </summary>
class ExceptionChainSeperatorException: Exception {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
public ExceptionChainSeperatorException(Exception innerException)
   :base("Two different exception chains have been combinated.",innerException)
{}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // FinalizationException
//***********************************************************************************************


//***********************************************************************************************
/// <summary>
/// This class is used for exception chains combination.
/// </summary>
static class ExceptionChainCombination {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/// <summary>
/// This function combines of two exception chains.
/// They are separated by <see cref="ExceptionChainSeperatorException" />.
/// Exception object reproduction is used. This needed because we can not simply correct
/// <see cref="System.Exception.InnerException" /> property which is readonly.
/// </summary>
public static Exception Combine(Exception headException,Exception innerException)
{
   return CombineTwoChains( headException,
      new ExceptionChainSeperatorException(innerException) );
}

/// <remarks>
/// Recursion is used in this implementation.
/// </remarks>
static Exception CombineTwoChains( Exception headException,
                                   Exception innerException )
{
   return NewChainedException( headException,
       headException.InnerException==null ? innerException :
       CombineTwoChains( headException.InnerException,
                         innerException ) );
}

/// <summary>
/// This function reproduces by its pattern making it chained with
/// <paramfer name="innerException" /> exception.
/// </summary>
/// <remarks>
/// Readonly properties can't be reproduced, so some informaion is lost.
/// </remarks>
static Exception NewChainedException( Exception patternException,
                                      Exception innerException )
{
   Exception rslt=null;

   try
   {
      rslt=(Exception)patternException.GetType().InvokeMember(
         null, BindingFlags.CreateInstance, null, null,
         new object[]{ // arguments for exception constructor:
            patternException.Message, innerException } );
   }
   catch (Exception ex)
   {
      SysUtils.FatalError.Perform(ex);
   }

   // Saving non-readonly properties (but the others are lost):
   rslt.HelpLink= patternException.HelpLink;
   rslt.Source  = patternException.Source;

   return rslt;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // ExceptionChainCombination
//***********************************************************************************************

} // SysUtils
