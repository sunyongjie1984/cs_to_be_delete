﻿namespace Balance {

using System;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Security;
using System.Globalization;
using Balance.Properties;

//***********************************************************************************************
class XMLData {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public XMLData(string strFileName)
{
   i_strFileName=strFileName;
}

//-----------------------------------------------------------------------------------------------

public string FileName
   { get { return i_strFileName; } }

//-----------------------------------------------------------------------------------------------

public int ComponentCount
   { get { return i_nComponentCount; } }

public int ContainerCount
   { get { return i_InitialContainers.Length; } }

//-----------------------------------------------------------------------------------------------

public bool HasOutputNode
   { get { return i_bHasOutputNode; } }

public CalcType Epsilon
   { get { return i_Epsilon; } }

public CompoundContainer[] InitialContainersDuplicate
{
   get {
      CompoundContainer[] rslt=
         new CompoundContainer[ContainerCount];
      for (int i=0;i<rslt.Length;i++)
         rslt[i]=i_InitialContainers[i].Duplicate;
      return rslt;
   }
}

public CalcType[] TargetSummaries
{
   get {
      return i_TargetSummaries;
   }
}

//-----------------------------------------------------------------------------------------------

public CalcType InitialMaxDifference
   { set { i_InitialMaxDifference=value; } }

public CalcType InitialDivergence
   { set { i_InitialDivergence=value; } }

public CalcType[] InitialQuantities
   { set { i_InitialQuantities=value; } }

public CalcType[] InitialSummaries
   { set { i_InitialSummaries=value; } }

public CalcType[] InitialDifferences
   { set { i_InitialDifferences=value; } }

//-----------------------------------------------------------------------------------------------

public int IterationCount
   { set { i_nIterationCount=value; } }

public CalcType ResultMaxDifference
   { set { i_ResultMaxDifference=value; } }

public CalcType ResultDivergence
   { set { i_ResultDivergence=value; } }

public CompoundContainer[] ResultContainers
   { set { i_ResultContainers=value; } }

public CalcType[] ResultQuantities
   { set { i_ResultQuantities=value; } }

public CalcType[] ResultSummaries
   { set { i_ResultSummaries=value; } }

public CalcType[] ResultDifferences
   { set { i_ResultDifferences=value; } }

//-----------------------------------------------------------------------------------------------

public bool LoadApproximation(out string strErrorMessage)
{
   XmlSchema xmlSchema=XmlSchema.Read(
      new StringReader(Resources.Approximation_XSD),
      null );

   XmlSchemaSet xmlSchemaSet=new XmlSchemaSet();
   xmlSchemaSet.Add(xmlSchema);

   XmlReaderSettings xmlReaderSettings=new XmlReaderSettings();
   xmlReaderSettings.ValidationType=ValidationType.Schema;
   xmlReaderSettings.Schemas=xmlSchemaSet;

   XmlReader xmlReader=null;
   i_XmlDocumentTemp=new XmlDocument();
   try
   {
      i_XmlDocumentTemp.Load(xmlReader=XmlReader.Create(FileName,xmlReaderSettings));
      SysUtils.GenOps.DefaultExchange(ref xmlReader).Close();
   }
   catch (SystemException ex)
   {
      // === Following handler is fanatical error checking: ===
      //  It is very sad, but there is no another way to continue the execution
      // and to be absolutely sure, that there was no side effect of such exception cathing,
      // which can cause a harm in the future. Such side effect can appear if we catch
      // unexpected exception belongin to "System.SystemException" class (such as
      // "System.AccessViolationException", "System.OutOfMemoryException", etc.).
      //  It is not very important here, but in many cases we have some object corruptions and
      // these objects are not safe for the future. Therefore, we have to exclude all unexpected
      // exceptions interpreting their as fatal (if we really care about it).
      //  By the way, "monolithic" code blocks (if to be used in every needed place including
      // all system code) will allow to avoid such problem.

      // Implementing exception filter in C#:
      if (!( // All unexpected exceptions are interpreted as abnormal:
         ex is NotSupportedException || ex is UriFormatException ||
         ex is SecurityException || ex is UnauthorizedAccessException ||
         ex is IOException || ex is XmlException ||
         ex is XmlSchemaValidationException
      ))
         throw; // this will rethrow the exception (leaving stack trace unchanged)

      // The reader may to remain open, therefore we have to close it:
      if (xmlReader!=null)
         try { xmlReader.Close(); }
         catch (IOException) {}

      strErrorMessage=ex.Message;
      return false;
   }

   i_XmlNamespaceManager=new XmlNamespaceManager(i_XmlDocumentTemp.NameTable);
   i_XmlNamespaceManager.AddNamespace("x",xmlSchema.TargetNamespace);

   if (i_XmlDocumentTemp.DocumentElement.NamespaceURI!=xmlSchema.TargetNamespace)
   {
      strErrorMessage=string.Format(
         "Document element must use this namespace: \"{0}\".",
         xmlSchema.TargetNamespace );
      return false;
   }

   try
      { ScanInputData(); }
   catch (ApplicationException ex)
      { strErrorMessage=ex.Message; return false;  }

   i_bHasOutputNode=
      i_XmlDocumentTemp.SelectSingleNode(
         "/x:approximation/x:outputData",
         i_XmlNamespaceManager ) != null;

   i_XmlDocument=i_XmlDocumentTemp;

   strErrorMessage=null; return true;
}

public bool SaveApproximation(bool bExcludeOutputNode,out string strErrorMessage)
{
   XmlNode
      outputNode=i_XmlDocument.SelectSingleNode(
         "/x:approximation/x:outputData", i_XmlNamespaceManager );
   if (outputNode!=null)
      outputNode.ParentNode.RemoveChild(outputNode);

   if (!bExcludeOutputNode)
      GenerateOutputData();

   XmlWriterSettings xmlWriterSettings=new XmlWriterSettings();
   xmlWriterSettings.Indent=true;
   xmlWriterSettings.IndentChars="   ";

   XmlWriter xmlWriter=null;

   //  Proof method of file saving is used, -- it guarantees that target data file
   // can not be abandoned at the middle of writing. The method is based on
   // temporary/backup file.
   try
   {
      string
         strTempFileName=FileName+".temporary",
         strBackupFileName=FileName+".backup";

      if (!File.Exists(FileName))
         throw new ApplicationException(string.Format(
            "Can't create backup for original data file.\n"+
            "The file does not exist: \"{0}\".",
            FileName ));

      if ((File.GetAttributes(FileName) & FileAttributes.ReadOnly)!=0)
         throw new ApplicationException(string.Format(
            "Data file is readonly: \"{0}\".",
            FileName ));

      if (File.Exists(strBackupFileName))
         throw new ApplicationException(string.Format(
            "Backup file found: \"{0}\".",
            strBackupFileName ));

      i_XmlDocument.Save(xmlWriter=XmlWriter.Create(strTempFileName,xmlWriterSettings));
      SysUtils.GenOps.DefaultExchange(ref xmlWriter).Close();

      File.Move(FileName,strBackupFileName);
      File.Move(strTempFileName,FileName);
      File.Delete(strBackupFileName);
   }
   catch (SystemException ex)
   {
      // === Following handler is fanatical error checking: ===
      // Implementing exception filter in C#:
      if (!( // All unexpected exceptions are interpreted as abnormal:
         ex is NotSupportedException || ex is UriFormatException ||
         ex is SecurityException || ex is UnauthorizedAccessException ||
         ex is IOException || ex is XmlException
      ))
         throw; // this will rethrow the exception (leaving stack trace unchanged)

      if (xmlWriter!=null)
         try { xmlWriter.Close(); }
         catch (IOException) {}
      strErrorMessage=ex.Message;
      return false;
   }
   catch (ApplicationException ex)
   {
      strErrorMessage=ex.Message;
      return false;
   }

   i_bHasOutputNode=!bExcludeOutputNode;

   strErrorMessage=null; return true;
}

//===============================================================================================

XmlNode SelectInputNode(string strRelativeXPath)
{
   return i_XmlDocumentTemp.SelectSingleNode(
      "/x:approximation/x:inputData"+(strRelativeXPath==null ? "" : "/"+strRelativeXPath),
      i_XmlNamespaceManager );
}

CalcType[] ExtractComponentsFromList(string strValues)
{
   string[]
      astrTerms=SysUtils.StringHandling.SplitWhitespaceSeparatedList(strValues);
   CalcType[]
      rslt=new CalcType[astrTerms.Length];
   for (int i=0;i<rslt.Length;i++)
      rslt[i]=CalcType.ParseInvariant(astrTerms[i]);

   return rslt;
}

XmlElement CreateElement(string strName)
{
   return i_XmlDocument.CreateElement(
      strName, i_XmlNamespaceManager.LookupNamespace("x") );
}

XmlElement CreateValueListElement(string strName,CalcType[] values)
{
   return CreateValueListElement(strName,"sum",values);
}

XmlElement CreateValueListElement( string strElementName,
                                   string strSummaryAttributeName,
                                   CalcType[] values )
{
   XmlElement element=CreateElement(strElementName);
   element.InnerText=ComposeValueList(values);
   AddAtribute( element, strSummaryAttributeName,
      GenAlgs.Sum(values).ToStringInvariant() );
   return element;
}

XmlElement CreateContainerElement(string strName,CompoundContainer container)
{
   XmlElement element=CreateElement(strName);
   element.InnerText=ComposeComponentList(container);
   AddAtribute( element, "totalQuantity",
      container.TotalQuantity.ToStringInvariant() );
   return element;
}

void AddAtribute(XmlElement xmlElement,string strName,object obValue)
{
   AddAtribute(xmlElement,strName,obValue.ToString());
}

void AddAtribute(XmlElement xmlElement,string strName,string strValue)
{
   XmlAttribute xmlAttribute=
      i_XmlDocument.CreateAttribute(strName);
   xmlAttribute.Value=strValue;
   xmlElement.SetAttributeNode(xmlAttribute);
}

string ComposeValueList(CalcType[] values)
{
   return ComposeValueList(values.GetEnumerator());
}

string ComposeValueList(IEnumerator valEnum)
{
   StringBuilder sb=new StringBuilder();
   while (valEnum.MoveNext())
      sb.AppendFormat(
         (sb.Length>0 ? " " : "")+
         ((CalcType)valEnum.Current).ToStringInvariant() );
   return sb.ToString();
}

string ComposeComponentList(CompoundContainer container)
{
   return ComposeValueList(container.GetEnumerator());
}

void ScanInputData()
{
   XmlNode     xmlNode;
   CalcType[]  components;

   xmlNode=SelectInputNode(null);
   i_Epsilon=CalcType.ParseInvariant(xmlNode.Attributes["epsilon"].Value);

   xmlNode=SelectInputNode("x:compoundContainers/x:components");
   List<CompoundContainer> containerList=
      new List<CompoundContainer>();
   i_nComponentCount=-1;
   do
   {
      components=ExtractComponentsFromList(xmlNode.InnerText);
      if (i_nComponentCount<0)
         i_nComponentCount=components.Length;
      if (components.Length!=i_nComponentCount)
         throw new ApplicationException("Component count differs from one node to another.");
      containerList.Add(new CompoundContainer(components));
   }
   while ((xmlNode=xmlNode.NextSibling)!=null);

   i_InitialContainers=new CompoundContainer[containerList.Count];
   containerList.CopyTo(i_InitialContainers);

   xmlNode=SelectInputNode("x:targetSummaries");
   components=ExtractComponentsFromList(xmlNode.InnerText);
   if (components.Length!=i_nComponentCount)
      throw new ApplicationException(
         "Number of target summaries differs from the component count "+
         "of preceding containers." );

   i_TargetSummaries=components;
}

void GenerateOutputData()
{
   XmlElement
      outputElement, element, subElement;

   // outputData:

   i_XmlDocument.DocumentElement.AppendChild(
      outputElement=CreateElement("outputData") );

   // comments:

   outputElement.AppendChild(
      i_XmlDocument.CreateComment(string.Format(
         "\nThis node was generated by {0}.\nCreation date-time: {1}. ",
         SysUtils.RootInfo.ApplicationTitle,
         DateTime.Now.ToString(DateTimeFormatInfo.InvariantInfo) )) );

   // constantValues:

   element=CreateElement("constantValues");
   AddAtribute(element,"componentCount", ComponentCount );
   AddAtribute(element,"containerCount", ContainerCount );
   AddAtribute(element,"sumOfTargers"  , GenAlgs.Sum(i_TargetSummaries).ToStringInvariant() );

   outputElement.AppendChild(element);

   // initialValues:

   element=CreateElement("initialValues");

   element.AppendChild(CreateValueListElement(
      "perContainerQuantities", i_InitialQuantities ));

   element.AppendChild(CreateValueListElement(
      "componentSummaries", "totalQuantity", i_InitialSummaries ));

   subElement=CreateElement("componentSummaryDifferences");
   subElement.InnerText=ComposeValueList(i_InitialDifferences);
   AddAtribute(subElement,"maxAbsolute", i_InitialMaxDifference.ToStringInvariant() );
   AddAtribute(subElement,"divergence" , i_InitialDivergence   .ToStringInvariant() );
   element.AppendChild(subElement);

   outputElement.AppendChild(element);

   // resultValues:

   element=CreateElement("resultValues");
   AddAtribute(element,"iterationCount", i_nIterationCount );

   subElement=CreateElement("compoundContainers");
   foreach (CompoundContainer container in i_ResultContainers)
      subElement.AppendChild(CreateContainerElement("components",container));
   element.AppendChild(subElement);

   element.AppendChild(CreateValueListElement(
      "perContainerQuantities", i_ResultQuantities ));

   element.AppendChild(CreateValueListElement(
      "componentSummaries", "totalQuantity", i_ResultSummaries ));

   subElement=CreateElement("componentSummaryDifferences");
   subElement.InnerText=ComposeValueList(i_ResultDifferences);
   AddAtribute(subElement,"maxAbsolute", i_ResultMaxDifference.ToStringInvariant() );
   AddAtribute(subElement,"divergence" , i_ResultDivergence   .ToStringInvariant() );
   element.AppendChild(subElement);

   outputElement.AppendChild(element);
}

//-----------------------------------------------------------------------------------------------

string
   i_strFileName=null;
XmlDocument
   i_XmlDocument,
   i_XmlDocumentTemp;
XmlNamespaceManager
   i_XmlNamespaceManager;
bool
   i_bHasOutputNode;
int
   i_nComponentCount=0,
   i_nIterationCount=0;
CalcType
   i_Epsilon=0,
   i_InitialMaxDifference,
   i_InitialDivergence,
   i_ResultMaxDifference,
   i_ResultDivergence;
CompoundContainer[]
   i_InitialContainers=null,
   i_ResultContainers=null;
CalcType[]
   i_TargetSummaries=null,
   i_InitialQuantities=null,
   i_InitialSummaries=null,
   i_InitialDifferences=null,
   i_ResultQuantities=null,
   i_ResultSummaries=null,
   i_ResultDifferences=null;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // XMLData
//***********************************************************************************************

} // Balance
