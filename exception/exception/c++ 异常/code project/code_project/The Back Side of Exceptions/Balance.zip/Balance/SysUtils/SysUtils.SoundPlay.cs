﻿namespace SysUtils {

using System;
using System.Media;
using System.Resources;

//***********************************************************************************************
static class SoundPlay {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public static volatile bool Mute=false;

//-----------------------------------------------------------------------------------------------

public static void PlaySoundResource(string strSoundName)
{
   PlaySoundResource(null,strSoundName,false);
}

public static void PlaySoundResource(string strSoundName,bool bSyncPlay)
{
   PlaySoundResource(null,strSoundName,bSyncPlay);
}

//-----------------------------------------------------------------------------------------------

public static void PlaySoundResource(ResourceManager rm,string strSoundName)
{
   PlaySoundResource(rm,strSoundName,false);
}

public static void PlaySoundResource(ResourceManager rm,string strSoundName,bool bSyncPlay)
{
   if (!Mute)
      PlaySoundAux(
         new SoundPlayer(SysUtils.Resources.GetSoundStream(rm,strSoundName)),
         bSyncPlay );
}

//-----------------------------------------------------------------------------------------------

public static void PlaySoundFile(string strSoundFile)
{
   PlaySoundFile(strSoundFile,false);
}

public static void PlaySoundFile(string strSoundFile,bool bSyncPlay)
{
   if (!Mute)
      PlaySoundAux(new SoundPlayer(strSoundFile),bSyncPlay);
}

//===============================================================================================

static void PlaySoundAux(SoundPlayer soundPlayer,bool bSyncPlay)
{
   if (bSyncPlay)
      soundPlayer.PlaySync();
   else
      soundPlayer.Play();
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // SoundPlay
//***********************************************************************************************

} // SysUtils
