﻿namespace SysUtils {

using System;
using System.Drawing;
using System.Drawing.Drawing2D;

//***********************************************************************************************
static class Graphics {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public static Bitmap MakeBitmapTransparent( Bitmap bitmap,
                                            Color colorTransparent,
                                            Color colorBackgroung )
{
   for (int y=0;y<bitmap.Height;y++)
      for (int x=0;x<bitmap.Width;x++)
         if (bitmap.GetPixel(x,y)==colorTransparent)
            bitmap.SetPixel(x,y,colorBackgroung);
   return bitmap;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // Graphics
//***********************************************************************************************

} // SysUtils
