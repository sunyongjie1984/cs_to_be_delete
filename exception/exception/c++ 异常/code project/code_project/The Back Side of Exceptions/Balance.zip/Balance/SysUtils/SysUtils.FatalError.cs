﻿namespace SysUtils {

using System;
using System.Threading;
using System.ComponentModel;
using System.Diagnostics;
using System.Text;

//***********************************************************************************************
/// <summary>
/// User defined callback prototypes, to be performed when fatal error occurs
/// (before and after error reporting).
/// </summary>
delegate void PrimaryEmergencyActionDelegate();
delegate void PosteriorEmergencyActionDelegate();
//***********************************************************************************************


//***********************************************************************************************
/// <summary>
/// Support for procedural fatal error (which causes entire process termination).
/// </summary>
static class FatalError {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public static bool FatalErrorOnUnhandledException
{
   get
   {
      lock (typeof(FatalError))
         return SysUtils.RuntimeParams._FatalErrorOnUnhandledException;
   }
   set
   {
      lock (typeof(FatalError))
      {
         bool bHandlerWasAttached=
            SysUtils.RuntimeParams._FatalErrorOnUnhandledException;
         SysUtils.RuntimeParams._FatalErrorOnUnhandledException=value;
         if (!bHandlerWasAttached && value)
            AppDomain.CurrentDomain.UnhandledException+=UnhandledExceptionFilter;
         else
            if (bHandlerWasAttached && !value)
               AppDomain.CurrentDomain.UnhandledException-=UnhandledExceptionFilter;
      }
   }
}

public static PrimaryEmergencyActionDelegate PrimaryEmergencyAction
   { get { return RuntimeParams._PrimaryEmergencyAction; } }

public static PosteriorEmergencyActionDelegate PosteriorEmergencyAction
   { get { return RuntimeParams._PosteriorEmergencyAction; } }

//-----------------------------------------------------------------------------------------------

public static void Perform(string strMessage)
{
   Perform(strMessage,1);
}

public static void Perform(string strMessage,int nStackFramesToSkip)
{
   //  It is very sad, but in release version we can loose some stack frames, --
   // it may occur because of function inlining during optimization.
   Perform(strMessage,new StackTrace(nStackFramesToSkip+1,true));
}

public static void Perform(string strMessage,StackTrace stackTrace)
{
   Perform( strMessage, stackTrace!=null ? stackTrace.ToString() : null,
            null, null );
}

public static void Perform( string strMessage, string strStackTrace,
                            string strPrefixMessage, string strSuffixMessage )
{
   try
   {
      if ( sv_bOccured =
           Interlocked.Exchange(ref s_nOccurenceIndicator,1)!=0 )
         Thread.Sleep(Timeout.Infinite);

      try { new WaitCursor(); } catch (Win32Exception) {}

      try { Trace.PrintError(c_strTraceFmt,strMessage); } catch {}

      if (PrimaryEmergencyAction!=null)
         PrimaryEmergencyAction();

      StringBuilder sb=new StringBuilder();

      if (strPrefixMessage!=null)
         sb.Append(strPrefixMessage+"\n\n");

      sb.Append(strMessage);

      if (strStackTrace!=null)
         sb.Append("\n\n"+strStackTrace);

      String str=sb.ToString();
      if (str.Substring(str.Length-1)!="\n")
         sb.Append("\n");

      if (strSuffixMessage!=null)
         sb.Append("\n"+strSuffixMessage+"\n");

      sb.Append("\nSorry !  The application will be terminated.");

      try {
         SysUtils.Beeper.BeepCertainly(
            SysUtils.Beeper.ERROR_FREQUENCY,
            SysUtils.Beeper.ERROR_DURATION*2 );
      } catch (Win32Exception) {}

      MessageDialog.ShowError( sb.ToString(),
         SysUtils.RootInfo.ApplicationExeName+" \x2014 faral error" );

      if (PosteriorEmergencyAction!=null)
         PosteriorEmergencyAction();
   }
   finally
   {
      Environment.Exit(Environment.ExitCode=SysUtils.ExitCodes.EXIT_FATAL);
   }
}

public static void Perform(Exception e)
{
   Exception x=e;
   while (x.StackTrace==null)
      x=x.InnerException;
   Perform( e, true,
            x.StackTrace==null ? null : new StackTrace(x,true),
            null, null );
}

public static void Perform(Exception e,StackTrace stackTrace)
{
   Perform(e,true,stackTrace,null,null);
}

public static void Perform( Exception e,
                            bool bShowFullExceptionChain,
                            StackTrace stackTrace,
                            string strPrefixMessage,
                            string strSuffixMessage )
{
   PerformEx( e, bShowFullExceptionChain,
              stackTrace!=null ? stackTrace.ToString() : e.StackTrace,
              strPrefixMessage, strSuffixMessage );
}

public static bool HasOccured
   { get { return sv_bOccured; } }

public static void UnhandledExceptionFilter(object sender,UnhandledExceptionEventArgs args)
{
   //  It is very sad, but when unhandled exception occures in "System.Windows.Forms.Form.Shown"
   // event (or may be in some other places), and this handler receives control,
   // exception informational chain (inner exceptions implied) is lost somewhere, --
   // only the last exception is available to display its information in this situation.

   Exception e=(Exception)args.ExceptionObject;

   Perform
   (
      e, true, null,
      e.InnerException==null ?
         "=== Unhandled exception and its stack trace: ===" :
         "##  Unhandled exception chain (from primary to the last one)\n"+
         "##  and stack trace (for the last exception throwing):",
      null
   );
}

//-----------------------------------------------------------------------------------------------

public static void _InitializeClass()
{
   if (SysUtils.RuntimeParams._FatalErrorOnUnhandledException)
      AppDomain.CurrentDomain.UnhandledException+=UnhandledExceptionFilter;
}

//===============================================================================================

static void PerformEx( Exception e,
                       bool bShowFullExceptionChain,
                       String strStackTrace,
                       string strPrefixMessage,
                       string strSuffixMessage )
{
   bool bBulleted=bShowFullExceptionChain && e.InnerException!=null;

   StringBuilder sb=new StringBuilder(ExceptionToMessage(e,bBulleted));

   if (bShowFullExceptionChain)
      for (Exception ie=e.InnerException; ie!=null; ie=ie.InnerException)
         sb.Insert(0,ExceptionToMessage(ie,bBulleted)+"\n");

   Perform(sb.ToString(),strStackTrace,strPrefixMessage,strSuffixMessage);
}

static string ExceptionToMessage(Exception e,bool bBulleted)
{
   return string.Format( "{0}{1}: \"{2}\"",
      bBulleted ? "\x2022 " : "", e.GetType(), e.Message );
}

//-----------------------------------------------------------------------------------------------

const string
   c_strTraceFmt="\n*** FATAL ERROR: ***\n{0}";

//-----------------------------------------------------------------------------------------------

static volatile bool
   sv_bOccured;
static int
   s_nOccurenceIndicator;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // FatalError
//***********************************************************************************************

} // SysUtils
