﻿namespace Balance {

using System;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;

using ExternalSource; // <-- BarBox class (implemended by the third-party developer)

//***********************************************************************************************
class ContainerBox: BarBox {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public ContainerBox(Control control,int nBarCount,Color[] barColors,SummaryBox summaryBox)
   :base(control,nBarCount,false,barColors)
{
   SummaryBox=summaryBox; GetCaptionCallback=GetCaption;
}

public readonly SummaryBox SummaryBox;

public CompoundContainer Container
{
   get
   {
      return i_Container;
   }
   set
   {
      Debug.Assert( BarCount==value.ComponentCount,
         "Bar color count / component count mismatch." );
      (i_Container=value).ComponentChangeAccompaniment=CompoundContainer_ComponentChanged;
      if (SummaryBox!=null)
         SummaryBox.i_strCaption=null;
   }
}

//===============================================================================================

protected override double RelativeHeight(int nIdx)
   { return Container[nIdx]; }
protected override double LevelLineRelativeHeight(int nIdx)
   { return 0; }
protected override double MaxRelativeHeight
   { get { return Container.TotalQuantity; } }

//===============================================================================================

void CompoundContainer_ComponentChanged(CompoundContainer container,int nComponentIdx)
{
   Debug.Assert(container==Container,"Unexpected container instance.");

   if (SummaryBox!=null)
   {
      SummaryBox.RedrawBar(nComponentIdx);
      SummaryBox.i_strCaption=null;
   }

   RedrawBar(nComponentIdx);
}

string GetCaption()
{
   return Container.TotalQuantity.ToStringNormal();
}

//-----------------------------------------------------------------------------------------------

CompoundContainer i_Container;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // ContainerBox
//***********************************************************************************************


//***********************************************************************************************
class SummaryBox: BarBox {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public SummaryBox(Control control,int nBarCount,Color[] barColors)
   :base(control,nBarCount,true,barColors)
{
   GetCaptionCallback=GetCaption;
   GetSegmentCaptionCallback=GetSegmentCaption;
}

public CompoundContainer[] Containers
{
   get
   {
      return i_Containers;
   }
   set
   {
#if DEBUG
      foreach (CompoundContainer container in value)
         Debug.Assert( BarCount==container.ComponentCount,
            "Bar color count / component count mismatch." );
#endif
      i_Containers=value;
   }
}

public CalcType[] TargetSummaries
{
   get
   {
      return i_TargetSummaries;
   }
   set
   {
      Debug.Assert( BarCount==value.Length,
         "Bar color count / target summaries count mismatch." );
      i_TargetSummaries=value;
   }
}

//===============================================================================================

protected override double RelativeHeight(int nIdx)
{
   CalcType rslt=0;
   foreach (CompoundContainer container in Containers)
      rslt+=container[nIdx];
   return rslt;
}

protected override double LevelLineRelativeHeight(int nIdx)
{
   return TargetSummaries[nIdx];
}

protected override double MaxRelativeHeight
{
   get
   {
      CalcType totalQuantitySum=0;
      foreach (CompoundContainer container in Containers)
         totalQuantitySum+=container.TotalQuantity;

      return Math.Max(totalQuantitySum,GenAlgs.Max(TargetSummaries));
   }
}

//===============================================================================================

internal string i_strCaption;

//-----------------------------------------------------------------------------------------------

string GetCaption()
{
   if (i_strCaption==null)
   {
      CalcType totalSum=0;
      foreach (CompoundContainer container in Containers)
         totalSum+=container.TotalQuantity;
      i_strCaption=string.Format( "\x2211: {0} \x2248 {1}",
         totalSum.ToStringNormal(), GenAlgs.Sum(i_TargetSummaries).ToStringNormal() );
   }
   return i_strCaption;
}

string GetSegmentCaption(int nIdx)
{
   CalcType componentSum=0,targetSummary=TargetSummaries[nIdx];
   foreach (CompoundContainer container in Containers)
      componentSum+=container[nIdx];
   return string.Format( "{0} \x2500\x25BA {1}\n({2})",
      componentSum.ToStringNormal(), targetSummary.ToStringNormal(),
      ((CalcType)Math.Abs(componentSum-targetSummary)).ToStringNormal() );
}

//-----------------------------------------------------------------------------------------------

CompoundContainer[]  i_Containers;
CalcType[]           i_TargetSummaries;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // SummaryBox
//***********************************************************************************************

} // Balance
