//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//
//  This is auto-generated source file. It is created by MSBUILD-utility invoked from CMD-batch
// according to content of "Balance.settings" file. This done by "PrepareAssemblyInfo" target
// of "Balance.targets" file.
//
//
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

#if DEBUG
   [assembly: AssemblyTitle("Balance (Debug-version)")]
#else
   [assembly: AssemblyTitle("Balance")]
#endif

[assembly: AssemblyDescription("Balance Demo Application (The Back Side of Exceptions)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("MUP MIVC (the city of Voronezh)")]
[assembly: AssemblyProduct("Program Demo Samples (.NET)")]
[assembly: AssemblyCopyright("\x00A9 Sergei Kitaev")]
[assembly: AssemblyTrademark("")]

[assembly: ComVisible(false)]
[assembly: Guid("4195b739-697d-495c-b2ed-e8438b451913")]

[assembly: AssemblyVersion("2006.7.1.1")]
[assembly: AssemblyFileVersion("2006.7.1.1")]
[assembly: NeutralResourcesLanguage("en")]

