﻿namespace Balance {

using System;
using System.Globalization;

//***********************************************************************************************
/// <summary>
/// This structure is used instead of &quot;typedef&quot; C/C++ operator
/// (with a lot of additions). Imagine that you simply wrote <c>typedef float CalcType;</c>,
/// and it works in C#.
/// </summary>
struct CalcType {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

CalcType(float val) { Value=val; }

public float Value;

public static implicit operator CalcType(float val)
   { return new CalcType(val); }
public static implicit operator CalcType(double val)
   { return new CalcType((float)val); }
public static implicit operator float(CalcType calcValue)
   { return calcValue.Value; }

//-----------------------------------------------------------------------------------------------

public override string ToString()
   { return Value.ToString(); }

public string ToStringNormal()
   { return ToStringInvariant(); }

public string ToStringAccurate(int nMaxPrecision)
{
   return ToStringAccurate(2,nMaxPrecision);
}

public string ToStringAccurate(int nMinPrecision,int nMaxPrecision)
{
   string
      rslt;
   NumberFormatInfo
      numberFormat=new NumberFormatInfo();
   int
      nPrecision=nMinPrecision;
   do
   {
      numberFormat.NumberDecimalDigits=nPrecision;
      rslt=Value.ToString("F",numberFormat);
      if (nPrecision==nMinPrecision && Value==Zero)
         break;
      nPrecision++;
   }
   while (ParseInvariant(rslt)==Zero && nPrecision<=nMaxPrecision);

   return rslt;
}

public string ToStringInvariant()
   { return Value.ToString("F",NumberFormatInfo.InvariantInfo); }

//-----------------------------------------------------------------------------------------------

public const string DecimalSeparator=".";

//===============================================================================================

public static Type BaseType
   { get { return typeof(float); } }

public static CalcType Zero
   { get { return new CalcType(0f); } }

//-----------------------------------------------------------------------------------------------

public static CalcType ParseInvariant(string str)
{
   return Double.Parse(str,NumberFormatInfo.InvariantInfo);
}

public static bool ParseInvariant(string str,out CalcType value)
{
   string strErrorMessage;

   return ParseInvariant(str,out value,out strErrorMessage);
}

public static bool ParseInvariant(string str,out CalcType value,out string strErrorMessage)
{
   try
   {
      value=ParseInvariant(str);
      strErrorMessage=null;
      return true;
   }
   catch (SystemException ex)
   {
      if (!(ex is FormatException || ex is OverflowException))
         throw ex;
      value=0;
      strErrorMessage=ex.Message;
      return false;
   }
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // CalcType
//***********************************************************************************************

} // Balance
