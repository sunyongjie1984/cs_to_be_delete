﻿namespace SysUtils {

using System;
using System.ComponentModel;
using System.Runtime.InteropServices;

//***********************************************************************************************
static class Win32Error {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public static uint LastErrorCode
{
   get { return Win32_GetLastError(); }
   set { SetLastError(value); }
}

public static string LastErrorMessage
   { get { return ErrorMessage(LastErrorCode); } }

//-----------------------------------------------------------------------------------------------

public static bool IsErrorCodeUser(uint uErrorCode)
{
   return (uErrorCode & 1u<<29) != 0;
}

public static bool IsLastErrorCodeUser()
{
   return IsErrorCodeUser(LastErrorCode);
}

public static uint SetLastError(uint uErrorCode)
{
   uint uPreviousError=LastErrorCode;
   Win32_SetLastError(uErrorCode);
   return uPreviousError;
}

public static uint ResetLastError()
{
   return SetLastError(0);
}

public static string ErrorMessage(uint uErrorCode)
{
   // Following works not fast, but the method has very simple implementation:
   try { throw new Win32Exception((int)uErrorCode); }
   catch (Win32Exception ex) { return ex.Message; }
}

public static void CheckLastError()
{
   if (LastErrorCode!=0)
      throw new Win32Exception();
}

//===============================================================================================

[DllImport("Kernel32", EntryPoint="GetLastError")]
extern static uint Win32_GetLastError();

[DllImport("Kernel32", EntryPoint="SetLastError")]
extern static void Win32_SetLastError(uint dwErrorCode);

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // Win32Error
//***********************************************************************************************

} // SysUtils
