﻿namespace SysUtils {

using System;
using System.ComponentModel;

//***********************************************************************************************
static class GenOps {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public static object NullExchange(ref object original)
{
   object rslt=original; original=null; return rslt;
}

public static bool DisposeIfNotNull<T>(ref T resource) where T: IDisposable
{
   if (resource!=null)
   {
      resource.Dispose(); resource=default(T); return true;
   }
   return false;
}

public static bool CloseIfNotNull<T>(ref T resource) where T: IDisposable
{
   return DisposeIfNotNull(ref resource);
}

public static T DefaultExchange<T>(ref T original)
{
   T rslt=original; original=default(T); return rslt;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // GenOps
//***********************************************************************************************

} // SysUtils
