﻿namespace SysUtils {

using System;
using System.ComponentModel;
using System.Runtime.InteropServices;

//***********************************************************************************************
static class Beeper {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public const int STD_FREQUENCY  = 440;
public const int STD_DURATION   = 100;

public const int ERROR_FREQUENCY= STD_FREQUENCY*2;
public const int ERROR_DURATION = STD_DURATION*2;

public const int FAINT_FREQUENCY= STD_FREQUENCY/4;
public const int FAINT_DURATION = STD_DURATION/2;

//-----------------------------------------------------------------------------------------------

public static volatile bool Mute=false;

//-----------------------------------------------------------------------------------------------

public static void Beep(int nFrequency,int nDuration)
{
   if (!Mute) BeepCertainly(nFrequency,nDuration);
}

public static void BeepCertainly(int nFrequency,int nDuration)
{
   if (!Win32_Beep((uint)nFrequency,(uint)nDuration))
      throw new Win32Exception();
}

public static void StdBeep()
{
   Beep(STD_FREQUENCY,STD_DURATION);
}

public static void ErrorBeep()
{
   Beep(ERROR_FREQUENCY,ERROR_DURATION);
}

public static void ErrorBeep(int nDurationMultiplier)
{
   Beep(ERROR_FREQUENCY,ERROR_DURATION*nDurationMultiplier);
}

public static void FaintBeep()
{
   Beep(FAINT_FREQUENCY,FAINT_DURATION);
}

//===============================================================================================

[DllImport("Kernel32", EntryPoint="Beep", SetLastError=true)]
static extern bool Win32_Beep(uint dwFreq,uint dwDuration);

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // Beeper
//***********************************************************************************************

} // SysUtils
