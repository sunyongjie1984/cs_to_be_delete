﻿namespace Balance.Properties {

using System;
using System.Configuration;
using System.ComponentModel;
using System.Reflection;
using System.Globalization;

//***********************************************************************************************
// This class allows you to handle specific events on the settings class:
// -- The SettingChanging event is raised before a setting's value is changed;
// -- The PropertyChanged event is raised after a setting's value is changed;
// -- The SettingsLoaded event is raised after the setting values are loaded;
// -- The SettingsSaving event is raised before the setting values are saved.
internal sealed partial class Settings {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public Settings()
{
   SettingsLoaded += Settings_SettingsLoaded;
   SettingChanging+= Settings_SettingsChanging;
   SettingsSaving += Settings_SettingsSaving;
}

//-----------------------------------------------------------------------------------------------

public string DefaultXML_Default
   { get { return DefaultValue(MethodBase.GetCurrentMethod()); } }

public bool DontUseDefaultXML_Default
   { get { return bool.Parse(DefaultValue(MethodBase.GetCurrentMethod())); } }

public bool NoSound_Default
   { get { return bool.Parse(DefaultValue(MethodBase.GetCurrentMethod())); } }

public bool NoBeep_Default
   { get { return bool.Parse(DefaultValue(MethodBase.GetCurrentMethod())); } }

//===============================================================================================

string DefaultValue(MethodBase propertyMethod)
{
   string
      strPropertyName=SysUtils.GenInfo.GetPropertyName(propertyMethod);
   object
      obDefaultProperty=typeof(Settings).GetProperty(
         strPropertyName.Substring(0,strPropertyName.Length-8)
      ).GetCustomAttributes(typeof(DefaultSettingValueAttribute),false)[0];
   return
      ((DefaultSettingValueAttribute)obDefaultProperty).Value;
}

void Settings_SettingsLoaded(object sender,SettingsLoadedEventArgs e)
{
   SysUtils.Debug.PrintInMethod(MethodBase.GetCurrentMethod());
}

void Settings_SettingsChanging(object sender,SettingChangingEventArgs e)
{
   SysUtils.Debug.PrintInMethod( MethodBase.GetCurrentMethod(),
      "{0}=\"{1}\"", e.SettingName, e.NewValue );
}

void Settings_SettingsSaving(object sender,CancelEventArgs e)
{
   SysUtils.Debug.PrintInMethod(MethodBase.GetCurrentMethod());
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // Settings
//***********************************************************************************************

} // Balance.Properties
