﻿namespace SysUtils {

using System;
using System.Collections;

//***********************************************************************************************
/// <summary>
/// User callback prototypes. Such functions can be used as anonymous methods,
/// when you apply <see cref="AutoDispose"/> static class methods.
/// </summary>
delegate void ForEachBlockDelegate<T>(T element,int nIdx);
delegate int ForEachIntBlockDelegate<T>(T element,int nIdx);
//***********************************************************************************************


//***********************************************************************************************
/// <summary>
/// This class provides advanced using and foreach blocks based on anonymous methods.
/// The main purpose is not to loose any exception information.
/// </summary>
/// <remarks>
/// === Example of usage of the alternative using-block: ===
/// <c>
/// SysUtils.AutoDispose.PerformUsing(rc,delegate{
///    : : : : : : : : : :
///    : : : : : : : : : :
///    : : : : : : : : : :
/// });
/// </c>
/// </remarks>
static class AutoDispose {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/// <summary>Using block alternative.</summary>
public static void PerformUsing(IDisposable resource,CodeBlockDelegate dlgtBlock)
{
   ExceptionGuard.PerformTryFinally( dlgtBlock,
      delegate { if (resource!=null) resource.Dispose(); } );
}

/// <summary>Using block alternative.</summary>
public static int PerformUsing(IDisposable resource,IntCodeBlockDelegate dlgtExBlock)
{
   return ExceptionGuard.PerformTryFinally( dlgtExBlock,
      delegate { if (resource!=null) resource.Dispose(); } );
}

//-----------------------------------------------------------------------------------------------

/// <summary>Foreach block alternative.</summary>
public static void PerformForEach<T>( IEnumerable sequence,
                                      ForEachBlockDelegate<T> dlgtForEachBlock )
{
   IEnumerator enumerator=sequence.GetEnumerator();

   PerformUsing( sequence as IDisposable,
      delegate
      {
         for (int i=0; enumerator.MoveNext(); i++)
            dlgtForEachBlock((T)enumerator.Current,i);
      }
   );
}

/// <summary>Foreach block alternative.</summary>
public static int PerformForEach<T>( IEnumerable sequence,
                                     ForEachIntBlockDelegate<T> dlgtForEachIntBlock )
{
   IEnumerator enumerator=sequence.GetEnumerator();

   return PerformUsing( sequence as IDisposable,
      delegate
      {
         for (int i=0; enumerator.MoveNext(); i++)
         {
            int code=dlgtForEachIntBlock((T)enumerator.Current,i);
            if (code!=0) return code;
         }
         return 0;
      }
   );
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // AutoDispose
//***********************************************************************************************

} // SysUtils
