﻿namespace SysUtils {

using System;

//***********************************************************************************************
/// <summary>
/// This exception is used to add it as a head of exception chain,
/// when catching and rethrowing exception in a finally block.
/// </summary>
class DeterministicFinalizationException: Exception {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
public DeterministicFinalizationException(Exception innerException)
   :base("Can not completely perform deterministic finalization.",innerException)
{}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // FinalizationException
//***********************************************************************************************


//***********************************************************************************************
/// <summary>
/// User callback prototypes. Such functions can be used as anonymous methods, when you apply
/// exception guard via <see cref="ExceptionGuard"/> static class methods.
/// </summary>
delegate void CodeBlockDelegate();
delegate int IntCodeBlockDelegate();
//***********************************************************************************************


//***********************************************************************************************
/// <summary>
/// This class supplies advanced exception guard relative to deterministic finalization, -
/// this guard is based on anonymous methods. It provides alternatives for catch and finally
/// blocks. The main purpose is not to loose exception information.
/// </summary>
/// <remarks>
/// === Example of usage of the alternative try-finally-block: ===
/// <c>
/// SysUtils.ExceptionGuard.PerformTryFinally(
///    delegate
///    {
///       : : : : : : : : : :
///       : : : : : : : : : :
///       : : : : : : : : : :
///    },
///    delegate
///    {
///       : : : : : : : : : :
///       : : : : : : : : : :
///       : : : : : : : : : :
///    }
/// );
/// </c>
/// </remarks>
static class ExceptionGuard {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/// <summary>Catch block alternative.</summary>
public static void DoCatch(Exception e,CodeBlockDelegate dlgtCatchBlock)
{
   try
   {
      dlgtCatchBlock();
   }
   catch (Exception x)
   {
      if (x is SysUtils.MonolithicCodeViolationException)
         throw;
      throw SysUtils.ExceptionChainCombination.Combine(x,e);
   }
}

/// <summary>Catch block alternative.</summary>
public static int DoCatch(Exception e,IntCodeBlockDelegate dlgtCatchIntBlock)
{
   try
   {
      return dlgtCatchIntBlock();
   }
   catch (Exception x)
   {
      if (x is SysUtils.MonolithicCodeViolationException)
         throw;
      throw SysUtils.ExceptionChainCombination.Combine(x,e);
   }
}

//-----------------------------------------------------------------------------------------------

/// <summary>Try-finally block alternative.</summary>
public static void PerformTryFinally( CodeBlockDelegate dlgtTryBlock,
                                      CodeBlockDelegate dlgtFinallyBlock )
{
   try
   {
      dlgtTryBlock();
   }
   catch (Exception e)
   {
      if (e is SysUtils.MonolithicCodeViolationException)
         throw;
      try
      {
         dlgtFinallyBlock();
      }
      catch (Exception x)
      {
         if (x is SysUtils.MonolithicCodeViolationException)
            throw;
         throw new DeterministicFinalizationException(
            SysUtils.ExceptionChainCombination.Combine(x,e) );
      }
      throw;
   }
   dlgtFinallyBlock();
}

/// <summary>Try-finally block alternative.</summary>
public static int PerformTryFinally( IntCodeBlockDelegate dlgtTryIntBlock,
                                     CodeBlockDelegate dlgtFinallyBlock )
{
   int rslt;

   try
   {
      rslt=dlgtTryIntBlock();
   }
   catch (Exception e)
   {
      if (e is SysUtils.MonolithicCodeViolationException)
         throw;
      try
      {
         dlgtFinallyBlock();
      }
      catch (Exception x)
      {
         if (x is SysUtils.MonolithicCodeViolationException)
            throw;
         throw new DeterministicFinalizationException(
            SysUtils.ExceptionChainCombination.Combine(x,e) );
      }
      throw;
   }
   dlgtFinallyBlock();

   return rslt;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // ExceptionGuard
//***********************************************************************************************

} // SysUtils
