﻿namespace Balance
{
   partial class FormAbout
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components=null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing&&(components!=null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAbout));
         this.labelAuthor = new System.Windows.Forms.Label();
         this.labelAuthorValue = new System.Windows.Forms.Label();
         this.linkLabelEMail = new System.Windows.Forms.LinkLabel();
         this.buttonOk = new System.Windows.Forms.Button();
         this.panelAppVersion = new System.Windows.Forms.Panel();
         this.pictureBoxEmblem = new System.Windows.Forms.PictureBox();
         this.richTextBoxInformation = new System.Windows.Forms.RichTextBox();
         this.labelMailTo = new System.Windows.Forms.Label();
         ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEmblem)).BeginInit();
         this.SuspendLayout();
         // 
         // labelAuthor
         // 
         this.labelAuthor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.labelAuthor.AutoSize = true;
         this.labelAuthor.Font = new System.Drawing.Font("Microsoft Sans Serif",9.75F,System.Drawing.FontStyle.Regular,System.Drawing.GraphicsUnit.Point,((byte)(204)));
         this.labelAuthor.Location = new System.Drawing.Point(58,314);
         this.labelAuthor.Margin = new System.Windows.Forms.Padding(4,0,4,0);
         this.labelAuthor.Name = "labelAuthor";
         this.labelAuthor.Size = new System.Drawing.Size(49,16);
         this.labelAuthor.TabIndex = 2;
         this.labelAuthor.Text = "Author:";
         // 
         // labelAuthorValue
         // 
         this.labelAuthorValue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.labelAuthorValue.AutoSize = true;
         this.labelAuthorValue.Font = new System.Drawing.Font("Microsoft Sans Serif",9.75F,System.Drawing.FontStyle.Bold,System.Drawing.GraphicsUnit.Point,((byte)(204)));
         this.labelAuthorValue.Location = new System.Drawing.Point(115,314);
         this.labelAuthorValue.Margin = new System.Windows.Forms.Padding(4,0,4,0);
         this.labelAuthorValue.Name = "labelAuthorValue";
         this.labelAuthorValue.Size = new System.Drawing.Size(101,16);
         this.labelAuthorValue.TabIndex = 3;
         this.labelAuthorValue.Text = "Sergei Kitaev";
         // 
         // linkLabelEMail
         // 
         this.linkLabelEMail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.linkLabelEMail.AutoSize = true;
         this.linkLabelEMail.Font = new System.Drawing.Font("Microsoft Sans Serif",9.75F,System.Drawing.FontStyle.Regular,System.Drawing.GraphicsUnit.Point,((byte)(204)));
         this.linkLabelEMail.Location = new System.Drawing.Point(295,314);
         this.linkLabelEMail.Margin = new System.Windows.Forms.Padding(4,0,4,0);
         this.linkLabelEMail.Name = "linkLabelEMail";
         this.linkLabelEMail.Size = new System.Drawing.Size(108,16);
         this.linkLabelEMail.TabIndex = 4;
         this.linkLabelEMail.TabStop = true;
         this.linkLabelEMail.Text = "serg_kit@mail.ru";
         this.linkLabelEMail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelEMail_LinkClicked);
         // 
         // buttonOk
         // 
         this.buttonOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
         this.buttonOk.DialogResult = System.Windows.Forms.DialogResult.OK;
         this.buttonOk.Location = new System.Drawing.Point(438,311);
         this.buttonOk.Name = "buttonOk";
         this.buttonOk.Size = new System.Drawing.Size(91,23);
         this.buttonOk.TabIndex = 5;
         this.buttonOk.Text = "OK";
         // 
         // panelAppVersion
         // 
         this.panelAppVersion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
         this.panelAppVersion.Location = new System.Drawing.Point(11,12);
         this.panelAppVersion.Name = "panelAppVersion";
         this.panelAppVersion.Size = new System.Drawing.Size(29,293);
         this.panelAppVersion.TabIndex = 0;
         this.panelAppVersion.Paint += new System.Windows.Forms.PaintEventHandler(this.panelAppVersion_Paint);
         this.panelAppVersion.SizeChanged += new System.EventHandler(this.panelAppVersion_SizeChanged);
         // 
         // pictureBoxEmblem
         // 
         this.pictureBoxEmblem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.pictureBoxEmblem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.pictureBoxEmblem.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxEmblem.Image")));
         this.pictureBoxEmblem.Location = new System.Drawing.Point(11,310);
         this.pictureBoxEmblem.Name = "pictureBoxEmblem";
         this.pictureBoxEmblem.Size = new System.Drawing.Size(29,24);
         this.pictureBoxEmblem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
         this.pictureBoxEmblem.TabIndex = 7;
         this.pictureBoxEmblem.TabStop = false;
         // 
         // richTextBoxInformation
         // 
         this.richTextBoxInformation.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
         this.richTextBoxInformation.BackColor = System.Drawing.Color.Azure;
         this.richTextBoxInformation.Location = new System.Drawing.Point(46,12);
         this.richTextBoxInformation.Name = "richTextBoxInformation";
         this.richTextBoxInformation.ReadOnly = true;
         this.richTextBoxInformation.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
         this.richTextBoxInformation.Size = new System.Drawing.Size(483,293);
         this.richTextBoxInformation.TabIndex = 1;
         this.richTextBoxInformation.Text = "";
         // 
         // labelMailTo
         // 
         this.labelMailTo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.labelMailTo.AutoSize = true;
         this.labelMailTo.Location = new System.Drawing.Point(237,314);
         this.labelMailTo.Name = "labelMailTo";
         this.labelMailTo.Size = new System.Drawing.Size(51,16);
         this.labelMailTo.TabIndex = 8;
         this.labelMailTo.Text = "Mail-to:";
         // 
         // FormAbout
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(8F,16F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(541,339);
         this.Controls.Add(this.labelMailTo);
         this.Controls.Add(this.richTextBoxInformation);
         this.Controls.Add(this.pictureBoxEmblem);
         this.Controls.Add(this.panelAppVersion);
         this.Controls.Add(this.buttonOk);
         this.Controls.Add(this.linkLabelEMail);
         this.Controls.Add(this.labelAuthorValue);
         this.Controls.Add(this.labelAuthor);
         this.Font = new System.Drawing.Font("Microsoft Sans Serif",9.75F,System.Drawing.FontStyle.Regular,System.Drawing.GraphicsUnit.Point,((byte)(204)));
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.KeyPreview = true;
         this.Margin = new System.Windows.Forms.Padding(4);
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "FormAbout";
         this.ShowInTaskbar = false;
         this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
         this.Text = "About Balance";
         this.Shown += new System.EventHandler(this.FormAbout_Shown);
         this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FormAbout_KeyDown);
         this.Load += new System.EventHandler(this.FormAbout_Load);
         ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEmblem)).EndInit();
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.Label labelAuthor;
      private System.Windows.Forms.Label labelAuthorValue;
      private System.Windows.Forms.LinkLabel linkLabelEMail;
      private System.Windows.Forms.Button buttonOk;
      private System.Windows.Forms.Panel panelAppVersion;
      private System.Windows.Forms.PictureBox pictureBoxEmblem;
      private System.Windows.Forms.RichTextBox richTextBoxInformation;
      private System.Windows.Forms.Label labelMailTo;
   }
}