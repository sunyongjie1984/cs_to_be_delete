﻿namespace Balance {

using System;
using Balance.Properties;

//***********************************************************************************************
class ApplicationBugCheckException: ApplicationException {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public ApplicationBugCheckException()
   : base(Resources.ApplicationBugCheck_Msg)
{}

public ApplicationBugCheckException(string strMessage)
   : base(strMessage)
{}

public ApplicationBugCheckException(Exception innerException)
   : base(Resources.ApplicationBugCheck_Msg,innerException)
{}

public ApplicationBugCheckException(string strMessage,Exception innerException)
   : base(strMessage,innerException)
{}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // ApplicationBugCheckException
//***********************************************************************************************

} // Balance
