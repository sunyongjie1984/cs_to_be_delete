﻿namespace Balance {

using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;
using System.Collections;
using System.ComponentModel;
using System.Reflection;
using System.Diagnostics;
using System.IO;
using Balance.Properties;

//***********************************************************************************************
public partial class FormAbout: Form {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public FormAbout()
{
   InitializeComponent();
}

//===============================================================================================

private void FormAbout_Load(object sender,EventArgs e)
{
   Utilities.PlaySound("About");
   richTextBoxInformation.Rtf=Resources_FormAbout.Introduction_RTF;
   MinimumSize=Size;
}

private void FormAbout_Shown(object sender,EventArgs e)
{
   SysUtils.WaitCursor.ResetToNormal();
}

private void FormAbout_KeyDown(object sender,KeyEventArgs e)
{
   if (e.KeyCode==Keys.Escape && e.Modifiers==0)
      DialogResult=DialogResult.Cancel;
}

private void linkLabelEMail_LinkClicked(object sender,LinkLabelLinkClickedEventArgs e)
{
   using (new SysUtils.WaitCursor())
   {
      FormMain.SetStatusCaption(
         Resources_FormAbout.LaunchingEmailApplication_Msg );

      Process
         emailApplicationProcess=null;
      try
      {
         emailApplicationProcess=Process.Start("mailto:"+linkLabelEMail.Text);
      }
      catch (Win32Exception ex)
      {
         SysUtils.MessageDialog.ShowError( ex,
            Resources_FormAbout.CantLaunchEmailApplication_Title );
      }
      SysUtils.GenOps.CloseIfNotNull(ref emailApplicationProcess);

      FormMain.SetStatusCaption();
   }
}

private void panelAppVersion_Paint(object sender,PaintEventArgs e)
{
   Graphics grfx=e.Graphics;
   Rectangle rc=panelAppVersion.ClientRectangle;

   LinearGradientBrush lgb=new LinearGradientBrush( rc,
      Resources_FormAbout.VersionCaptionUpperBackColor,
      Resources_FormAbout.VersionCaptionLowerBackColor,
      LinearGradientMode.Vertical );
   lgb.GammaCorrection=true;

   grfx.FillRectangle(lgb,rc);

   Font font=Resources_FormAbout.VersionCaptionFont;

   StringFormat fmt=new StringFormat();
   fmt.FormatFlags=StringFormatFlags.DirectionVertical;

   SizeF fsize=grfx.MeasureString(Program.VersionCaption,font,rc.Size,fmt);

   fmt=new StringFormat();
   fmt.FormatFlags=StringFormatFlags.NoWrap;

   grfx.TranslateTransform(
      0.5f*(rc.Width-fsize.Width),
      rc.Height-0.5f*(rc.Height-fsize.Height) );
   grfx.RotateTransform(-90f);
   grfx.TextRenderingHint=TextRenderingHint.SystemDefault;
   grfx.DrawString( Program.VersionCaption, font,
      new SolidBrush(Resources_FormAbout.VersionCaptionColor),
      0f, 0f, fmt );
}

private void panelAppVersion_SizeChanged(object sender,EventArgs e)
{
   panelAppVersion.Refresh();
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // FormAbout
//***********************************************************************************************

} // Balance
