﻿namespace SysUtils {

using System;
using System.ComponentModel;
using System.Runtime.InteropServices;

//***********************************************************************************************
class WaitCursor: IDisposable {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public WaitCursor()
{
   InitializeInstance(true);
}

public WaitCursor(bool bUseWaitCursor)
{
   InitializeInstance(bUseWaitCursor);
}

public virtual void Dispose()
{
   Dispose(true); GC.SuppressFinalize(this);
}

//-----------------------------------------------------------------------------------------------

public static void SetWait()
{
   SetPredefinedCursor(IDC_WAIT);
}

public static void ResetToNormal()
{
   SetPredefinedCursor(IDC_ARROW);
}

//===============================================================================================

void InitializeInstance(bool bUseWaitCursor)
{
   if (bUseWaitCursor)
   {
      i_hSaveCursor=SetPredefinedCursor(IDC_WAIT);
      i_bValid=true;
   }
}

void Dispose(bool bExplicit)
{
   if (!i_bValid) return;

   i_bValid=false;

   if (bExplicit && i_hSaveCursor!=IntPtr.Zero)
      SetCursor(i_hSaveCursor);
}

~WaitCursor()
{
   Dispose(false);
}

//-----------------------------------------------------------------------------------------------

static IntPtr SetCursor(IntPtr hCursor)
{
   SysUtils.Win32Error.ResetLastError();

   IntPtr hPreviousCursor=Win32_SetCursor(hCursor);

   if (hPreviousCursor.Equals(IntPtr.Zero))
      SysUtils.Win32Error.CheckLastError();

   return hPreviousCursor;
}

static IntPtr SetPredefinedCursor(ushort uValue)
{
   IntPtr hCursor=Win32_LoadCursor(IntPtr.Zero,(IntPtr)uValue);

   if (hCursor.Equals(IntPtr.Zero))
      throw new Win32Exception();

   return SetCursor(hCursor);
}

//===============================================================================================

const ushort IDC_ARROW= 32512;
const ushort IDC_WAIT = 32514;

bool
   i_bValid;
IntPtr
   i_hSaveCursor;

//-----------------------------------------------------------------------------------------------

[DllImport("User32", EntryPoint="LoadCursor", SetLastError=true)]
static extern IntPtr Win32_LoadCursor(IntPtr hInstance,IntPtr pcszCursorName);

[DllImport("User32", EntryPoint="SetCursor", SetLastError=true)]
static extern IntPtr Win32_SetCursor(IntPtr hCursor);

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // Cursor
//***********************************************************************************************

} // SysUtils
