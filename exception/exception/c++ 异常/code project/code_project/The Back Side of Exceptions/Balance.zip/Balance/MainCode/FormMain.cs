﻿namespace Balance {

using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.ComponentModel;
using Balance.Properties;

//***********************************************************************************************
partial class FormMain: Form {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public static FormMain Instance;

//-----------------------------------------------------------------------------------------------

public static StatusCaptionSaving StatusCaption
   { get { return Instance._StatusCaption; } }

//-----------------------------------------------------------------------------------------------

public FormMain()
{
   InitializeComponent();

   MinimumSize=Size;

   if (Program.IsFirstClickOnceRun)
      StartPosition=FormStartPosition.CenterScreen;
}

//-----------------------------------------------------------------------------------------------

public static void SetStatusCaption()
{
   Instance._SetStatusCaption();
}

public static void SetStatusCaption(string strCaption)
{
   Instance._SetStatusCaption(strCaption);
}

public static void SetStatusCaption(string strCaption,bool bActive)
{
   Instance._SetStatusCaption(strCaption,bActive);
}

public static void RestoreStatusCaption(StatusCaptionSaving statusCaption)
{
   Instance._RestoreStatusCaption(statusCaption);
}

//===============================================================================================

const string
   c_strIEExeName="IEXPLORE.EXE",
   c_strTemporaryFileExtension=".Temporary";

//-----------------------------------------------------------------------------------------------

static readonly string
   sr_strApproximationSchemaFileName=
      Resources_FormMain.ApproximationSchemaFileName,
   sr_strTemporaryApproximationSchemaFileName=
      Path.GetFileNameWithoutExtension(sr_strApproximationSchemaFileName)+
      c_strTemporaryFileExtension+Path.GetExtension(sr_strApproximationSchemaFileName),
   sr_strTemporaryApproximationSchemaFileWithPath=
      Path.Combine(Program.TempPath,sr_strTemporaryApproximationSchemaFileName),
   sr_strDescriptionFileName=
      Resources_FormMain.DescriptionFileName,
   sr_strTemporaryDescriptionFileName=
      Path.GetFileNameWithoutExtension(sr_strDescriptionFileName)+
      c_strTemporaryFileExtension+Path.GetExtension(sr_strDescriptionFileName),
   sr_strTemporaryDescriptionFileWithPath=
      Path.Combine(Program.TempPath,sr_strTemporaryDescriptionFileName);

static readonly string[] sr_astrApproximationStatusCaptions=
{                                                               // ## ApproximationStatus:
   Resources_FormMain.ApproximationStatusCaptions_Blank,        // Blank
   Resources_FormMain.ApproximationStatusCaptions_InitialState, // InitialState
   Resources_FormMain.ApproximationStatusCaptions_InProgress,   // InProgress
   Resources_FormMain.ApproximationStatusCaptions_Suspended,    // Suspended
   Resources_FormMain.ApproximationStatusCaptions_Finished      // Finished
};
static readonly string[] sr_astrStartStopButtonCaptions=
{                                                      // ## ApproximationStatus:
   Resources_FormMain.StartStopButtonCaptions_Start,   // Blank, InitialState
   Resources_FormMain.StartStopButtonCaptions_Suspend, // InProgress
   Resources_FormMain.StartStopButtonCaptions_Resume,  // Suspended
   Resources_FormMain.StartStopButtonCaptions_Restart  // Finished
};
static readonly string[] sr_astrStartStopMenuItemCaptions=
{                                                        // ## ApproximationStatus:
   Resources_FormMain.StartStopMenuItemCaptions_Start  , // Blank, InitialState
   Resources_FormMain.StartStopMenuItemCaptions_Suspend, // InProgress
   Resources_FormMain.StartStopMenuItemCaptions_Resume , // Suspended
   Resources_FormMain.StartStopMenuItemCaptions_Restart  // Finished
};
static readonly Bitmap[] sr_aStartStopBitmaps=
{                                     // ## ApproximationStatus:
   Resources_FormMain.Bitmap_Start,   // Blank,
   Resources_FormMain.Bitmap_Start,   // InitialState
   Resources_FormMain.Bitmap_Suspend, // InProgress
   Resources_FormMain.Bitmap_Start,   // Suspended
   Resources_FormMain.Bitmap_Restart  // Finished
};
static readonly int
   sr_nMaxAccuratePrecision= Resources_FormMain.MaxAccuratePrecision,
   sr_nBoxFrameWidth       = Resources_FormMain.BoxFrameWidth,
   sr_nBoxClearance        = Resources_FormMain.BoxClearance,
   sr_nBoxSplitterWidth    = Resources_FormMain.BoxSplitterWidth,
   sr_nSummarySplitterWidth= Resources_FormMain.SummarySplitterWidth,
   sr_nLevelLineWidth      = Resources_FormMain.LevelLineWidth;
static readonly Color
   sr_BoxBackColor               = Resources_FormMain.BoxBackColor,
   sr_BoxFrameColor              = Resources_FormMain.BoxFrameColor,
   sr_LevelLineColor             = Resources_FormMain.LevelLineColor,
   sr_BoxCaptionColor            = Resources_FormMain.BoxCaptionColor,
   sr_BoxCaptionSurroundBackColor= Resources_FormMain.BoxCaptionSurroundBackColor,
   sr_BoxCaptionCenterBackColor  = Resources_FormMain.BoxCaptionCenterBackColor,
   sr_SummarySegmentCaptionColor = Resources_FormMain.SummarySegmentCaptionColor;
static readonly Color
   sr_StartStopBitmapTransparentColor=
      Resources_FormMain.StartStopBitmapTransparentColor;
static readonly Color[]
   sr_BarColors=
   {
      Resources_FormMain.BarColor_0,
      Resources_FormMain.BarColor_1,
      Resources_FormMain.BarColor_2,
      Resources_FormMain.BarColor_3,
      Resources_FormMain.BarColor_4,
   };
static readonly HatchStyle
   sr_GraphicPanelHatchStyle=Resources_FormMain.GraphicPanelHatchStyle;
static readonly HatchBrush
   sr_GraphicPanelBrush=new HatchBrush( sr_GraphicPanelHatchStyle,
      Resources_FormMain.GraphicPanelBrushForeColor,
      Resources_FormMain.GraphicPanelBrushBackColor );
static readonly Font
   sr_ContainerCaptionFont     = Resources_FormMain.ContainerCaptionFont,
   sr_SummaryCaptionFont       = Resources_FormMain.SummaryCaptionFont,
   sr_SummarySegmentCaptionFont= Resources_FormMain.SummarySegmentCaptionFont;

//-----------------------------------------------------------------------------------------------

XMLData
   i_XMLData;
CompoundContainer[]
   i_Containers;
CalcType[]
   i_TargetSummaries;
ContainerBox[]
   i_ContainerBoxes;
SummaryBox
   i_SummaryBox;
Approximation
   i_Approximation;
ApproximationStatus
   i_ApproximationStatus;
Thread
   i_ApproximationThread;
Process
   i_IEProcessXML,
   i_IEProcessXSD,
   i_DocumentProcess;
StatusCaptionSaving
   i_StatusCaption;
int
   i_nPanelContainersInitialHeight,
   i_nPanelSummaryInitialHeight;
bool
   i_bFormResized,
   i_bFormCloseRequest,
   i_bApproximationCancelled,
   i_bOutputSaved,
   i_bStarupSoudPlayed;
volatile bool
   iv_bApproximationStopFlag;

//===============================================================================================

StatusCaptionSaving _StatusCaption
   { get { return IsInProgress ? null : i_StatusCaption; } }

bool IsInProgress
   { get { return i_ApproximationStatus==ApproximationStatus.InProgress; } }

//-----------------------------------------------------------------------------------------------

void DeleteTemporaryFilesIfPossible()
{
   try
   {
      if (File.Exists(sr_strTemporaryApproximationSchemaFileWithPath))
         File.Delete(sr_strTemporaryApproximationSchemaFileWithPath);
      if (File.Exists(sr_strTemporaryDescriptionFileWithPath))
         File.Delete(sr_strTemporaryDescriptionFileWithPath);
   }
   catch (SystemException) {}
}

CalcType[] CalculateQuantities()
{
   CalcType[] rslt=new CalcType[i_Containers.Length];
   for (int i=0;i<rslt.Length;i++)
      rslt[i]+=i_Containers[i].TotalQuantity;
   return rslt;
}

CalcType[] CalculateSummaries()
{
   CalcType[] rslt=new CalcType[i_XMLData.ComponentCount];
   for (int i=0;i<rslt.Length;i++)
      foreach (CompoundContainer container in i_Containers)
         rslt[i]+=container[i];
   return rslt;
}

CalcType[] CalculateDifferences()
{
   CalcType[] rslt=new CalcType[i_XMLData.ComponentCount];
   for (int i=0;i<rslt.Length;i++)
   {
      CalcType totalQuantity=0;
      foreach (CompoundContainer container in i_Containers)
         totalQuantity+=container[i];
      rslt[i]=Math.Abs(totalQuantity-i_TargetSummaries[i]);
   }
   return rslt;
}

void CreateBoxes()
{
   i_SummaryBox=new SummaryBox(panelSummary,i_TargetSummaries.Length,sr_BarColors);
   i_SummaryBox.BackColor               = sr_BoxBackColor;
   i_SummaryBox.FrameColor              = sr_BoxFrameColor;
   i_SummaryBox.FrameWidth              = sr_nBoxFrameWidth;
   i_SummaryBox.SegmentSplitterWidth    = sr_nSummarySplitterWidth;
   i_SummaryBox.LevelLineColor          = sr_LevelLineColor;
   i_SummaryBox.LevelLineWidth          = sr_nLevelLineWidth;
   i_SummaryBox.CaptionFont             = sr_SummaryCaptionFont;
   i_SummaryBox.CaptionColor            = sr_BoxCaptionColor;
   i_SummaryBox.CaptionSurroundBackColor= sr_BoxCaptionSurroundBackColor;
   i_SummaryBox.CaptionCenterBackColor  = sr_BoxCaptionCenterBackColor;
   i_SummaryBox.SegmentCaptionFont      = sr_SummarySegmentCaptionFont;
   i_SummaryBox.SegmentCaptionColor     = sr_SummarySegmentCaptionColor;

   i_ContainerBoxes=new ContainerBox[i_Containers.Length];
   for (int i=0;i<i_ContainerBoxes.Length;i++)
   {
      ContainerBox containerBox = i_ContainerBoxes[i] =
         new ContainerBox(panelContainers,i_SummaryBox.BarCount,sr_BarColors,i_SummaryBox);
      containerBox.BackColor               = sr_BoxBackColor;
      containerBox.FrameColor              = sr_BoxFrameColor;
      containerBox.FrameWidth              = sr_nBoxFrameWidth;
      containerBox.SegmentSplitterWidth    = sr_nBoxSplitterWidth;
      containerBox.CaptionFont             = sr_ContainerCaptionFont;
      containerBox.CaptionColor            = sr_BoxCaptionColor;
      containerBox.CaptionSurroundBackColor= sr_BoxCaptionSurroundBackColor;
      containerBox.CaptionCenterBackColor  = sr_BoxCaptionCenterBackColor;
   }
}

void AdjustSizesBoxes()
{
   if (i_ApproximationStatus==ApproximationStatus.Blank)
      return;

   Rectangle
      rcClient=panelContainers.ClientRectangle;
   int
      freeSpace=rcClient.Width-sr_nBoxClearance*(i_Containers.Length+1),
      barWidth=freeSpace/i_Containers.Length,
      lostPixels=freeSpace%i_Containers.Length;

   for (int i=0;i<i_Containers.Length;i++)
      i_ContainerBoxes[i].Bounds=new Rectangle(
         rcClient.Left+sr_nBoxClearance+lostPixels/2+(barWidth+sr_nBoxClearance)*i,
         rcClient.Top+sr_nBoxClearance,
         barWidth, rcClient.Height-2*sr_nBoxClearance );

   rcClient=panelSummary.ClientRectangle;
   i_SummaryBox.Bounds=new Rectangle(
      rcClient.Left+sr_nBoxClearance, rcClient.Top+sr_nBoxClearance,
      rcClient.Width-2*sr_nBoxClearance, rcClient.Height-2*sr_nBoxClearance );
}

void InitializeApproximation()
{
   i_Approximation=new Approximation(
      i_Containers=i_XMLData.InitialContainersDuplicate,
      i_TargetSummaries=i_XMLData.TargetSummaries,
      i_XMLData.Epsilon );
}

void SynchronizeBoxes()
{
   for (int i=0;i<i_Containers.Length;i++)
      i_ContainerBoxes[i].Container=i_Containers[i];

   i_SummaryBox.Containers=i_Containers;
   i_SummaryBox.TargetSummaries=i_TargetSummaries;
}

void ClearApproximation()
{
   SetApproximationStatus(ApproximationStatus.Blank);
}

void ResetApproximation()
{
   SetApproximationStatus(ApproximationStatus.InitialState);
}

void SetApproximationStatus(ApproximationStatus status)
{
   switch (i_ApproximationStatus=status)
   {
   case ApproximationStatus.Blank:
      i_XMLData         = null;
      i_ContainerBoxes  = null;
      i_SummaryBox      = null;
      i_Approximation   = null;
      ClearBalanceCheckBoxes();
      break;
   case ApproximationStatus.InitialState:
      InitializeApproximation();
      CreateBoxes();
      SynchronizeBoxes();
      AdjustSizesBoxes();
      break;
   }

   i_bOutputSaved=false;

   int nStartStopCaptionIdx=
      status==ApproximationStatus.Blank ? 0 : (int)status-1;
   buttonStartStop  .Text = sr_astrStartStopButtonCaptions  [nStartStopCaptionIdx];
   menuItemStartStop.Text = sr_astrStartStopMenuItemCaptions[nStartStopCaptionIdx];
   menuItemStartStop.Image= sr_aStartStopBitmaps[(int)status];

   SetStatusCaption();

   UpdateLabels();

   EnableDisableControls();

   Refresh();
}

void EnableDisableControls()
{
   Control saveActiveControl=ActiveControl;
   ActiveControl=null;

   bool bPassiveOpened=
      i_ApproximationStatus!=ApproximationStatus.Blank &&
      !IsInProgress;

   menuItemLoad.Enabled=toolStripButtonLoad.Enabled=
      !IsInProgress;
   menuItemSave.Enabled=toolStripButtonSave.Enabled=
      i_ApproximationStatus==ApproximationStatus.Finished &&
      !i_bOutputSaved;
   menuItemSaveInputOnly.Enabled=toolStripButtonSaveInputOnly.Enabled=
      bPassiveOpened && i_XMLData.HasOutputNode;
   menuItemClear.Enabled=menuItemViewContent.Enabled=
   toolStripButtonClear.Enabled=toolStripButtonViewContent.Enabled=
      bPassiveOpened;

   menuItemBalanceCorruptionBug.Enabled = checkBoxBallanceCorruptionBug.Enabled =
   menuItemMonolithicBalanceOperation.Enabled = checkBoxMonolithicBalanceOperation.Enabled =
      bPassiveOpened;

   menuItemStartStop.Enabled=
      buttonStartStop.Enabled=
         i_ApproximationStatus!=ApproximationStatus.Blank;

   menuItemReset.Enabled=
      buttonReset.Enabled=
         i_ApproximationStatus!=ApproximationStatus.Blank &&
         i_ApproximationStatus!=ApproximationStatus.InitialState &&
         !IsInProgress;

   if (saveActiveControl!=null && saveActiveControl.Enabled)
      ActiveControl=saveActiveControl;
}

void _SetStatusCaption()
{
   _SetStatusCaption(
      sr_astrApproximationStatusCaptions[(int)i_ApproximationStatus],
      IsInProgress );
}

void _SetStatusCaption(string strCaption)
{
   if (!IsInProgress)
      _SetStatusCaption(strCaption,true);
}

void _SetStatusCaption(string strCaption,bool bActive)
{
   i_StatusCaption=new StatusCaptionSaving(strCaption,bActive);

   toolStripStatusLabel.Text=
      strCaption==null ? "" : strCaption+(bActive ? " ..." : "");

   toolStripStatusLabel.Font=new Font( toolStripStatusLabel.Font,
      bActive ? FontStyle.Bold : FontStyle.Regular );

   statusStrip.Refresh();
}

void _RestoreStatusCaption(StatusCaptionSaving statusCaption)
{
   if (statusCaption!=null && !IsInProgress)
      _SetStatusCaption(statusCaption.Caption,statusCaption.Active);
}

void UpdateLabels()
{
   if (i_ApproximationStatus!=ApproximationStatus.Blank)
   {
      labelEpsilonValue.Text=i_Approximation.Epsilon.ToStringAccurate(
         sr_nMaxAccuratePrecision );
      labelMaxDifferenceValue.Text=i_Approximation.MaxDifference.ToStringAccurate(
         sr_nMaxAccuratePrecision );
      labelDivergenceValue.Text=i_Approximation.Divergence.ToStringAccurate(
         sr_nMaxAccuratePrecision );
      int
         nIteration=i_Approximation.IterationCount;
      if (IsInProgress)
         nIteration++;
      labelIterationValue.Text=nIteration>0 ? nIteration.ToString() : "";
   }
   else
      labelEpsilonValue.Text=labelMaxDifferenceValue.Text=
         labelDivergenceValue.Text=labelIterationValue.Text=null;

   labelEpsilonValue      .Refresh();
   labelMaxDifferenceValue.Refresh();
   labelDivergenceValue   .Refresh();
   labelIterationValue    .Refresh();
}

void ClearBalanceCheckBoxes()
{
   menuItemBalanceCorruptionBug.Checked = checkBoxBallanceCorruptionBug.Checked =
      menuItemMonolithicBalanceOperation.Checked = checkBoxMonolithicBalanceOperation.Checked =
         false;
}

void StartApproximation()
{
   foreach (ContainerBox containerBox in i_ContainerBoxes)
      containerBox._MaliciousBug=checkBoxBallanceCorruptionBug.Checked;
   CompoundContainer.MonolithicBalanceOperation=checkBoxMonolithicBalanceOperation.Checked;

   i_ApproximationThread=new Thread(new ThreadStart(ApproximationThreadEntry));
   iv_bApproximationStopFlag=false;

   SetApproximationStatus(ApproximationStatus.InProgress);
   i_ApproximationThread.Start();
}

void RequestStopApproximation()
{
   SetStatusCaption(
      Resources_FormMain.StatusCaption_StoppingApproximation,
      true );
   iv_bApproximationStopFlag=true;
   ActiveControl=null;
   menuItemStartStop.Enabled=
      buttonStartStop.Enabled=false;
}

void EndApproximation()
{
   if (i_bFormCloseRequest)
   {
      i_bApproximationCancelled=true; Close(); return;
   }

   if (iv_bApproximationStopFlag)
   {
      SetApproximationStatus(ApproximationStatus.Suspended);
      ActiveControl=buttonStartStop;
   }
   else
   {
      SetApproximationStatus(ApproximationStatus.Finished);

      SysUtils.Beeper.Beep( SysUtils.Beeper.STD_FREQUENCY  , SysUtils.Beeper.STD_DURATION );
      SysUtils.Beeper.Beep( SysUtils.Beeper.STD_FREQUENCY*2, SysUtils.Beeper.STD_DURATION );
      SysUtils.Beeper.Beep( SysUtils.Beeper.STD_FREQUENCY*4, SysUtils.Beeper.STD_DURATION );

      if (WindowState==FormWindowState.Minimized)
         Win32Import.ShowWindow(Handle,Win32Import.SW_RESTORE);
      Win32Import.SetForegroundWindow(Win32Import.GetLastActivePopup(Handle));
   }
}

void ApproximationThreadEntry()
{
   UpdateLabelsDelegate
      dlgtUpdateLabels=new UpdateLabelsDelegate(UpdateLabels);
   bool
      bNextIterationRequired;
   do
   {
      Invoke(dlgtUpdateLabels);

      bNextIterationRequired=i_Approximation.PerformIteration();

      foreach (ContainerBox containerBox in i_ContainerBoxes)
         containerBox.RedrawCaption();
      i_SummaryBox.RedrawCaption();

      Thread.Sleep(0);
   }
   while (bNextIterationRequired && !iv_bApproximationStopFlag);

   Invoke(new EndApproximationDelegate(EndApproximation));
}

bool LoadDataFromXML(string strFileName)
{
   using (new SysUtils.WaitCursor())
   {
      SetStatusCaption(string.Format(
         Resources_FormMain.LoadingData_MsgFmt,
         Path.GetFileName(strFileName) ));

      XMLData
         xmlData=new XMLData(strFileName);
      string
         strErrorMessage;
      bool
         rslt=xmlData.LoadApproximation(out strErrorMessage);
      if (rslt)
      {
         i_XMLData=xmlData;

         ResetApproximation();

         i_XMLData.InitialMaxDifference= i_Approximation.MaxDifference;
         i_XMLData.InitialDivergence   = i_Approximation.Divergence;
         i_XMLData.InitialQuantities   = CalculateQuantities();
         i_XMLData.InitialSummaries    = CalculateSummaries();
         i_XMLData.InitialDifferences  = CalculateDifferences();

         ClearBalanceCheckBoxes();

         ActiveControl=buttonStartStop;
      }
      else
         SysUtils.MessageDialog.ShowError( strErrorMessage,
            Resources_FormMain.CantLoadData_Title );

      SetStatusCaption();

      return rslt;
   }
}

void SaveDataToXML()
{
   SaveDataToXML(false);
}

void SaveDataToXML(bool bExcludeOutputNode)
{
   using (new SysUtils.WaitCursor())
   {
      SetStatusCaption(string.Format(
         Resources_FormMain.SavingData_MsgFmt,
         Path.GetFileName(i_XMLData.FileName) ));

      if (!bExcludeOutputNode)
      {
         i_XMLData.IterationCount     = i_Approximation.IterationCount;
         i_XMLData.ResultMaxDifference= i_Approximation.MaxDifference;
         i_XMLData.ResultDivergence   = i_Approximation.Divergence;
         i_XMLData.ResultContainers   = i_Containers;
         i_XMLData.ResultQuantities   = CalculateQuantities();
         i_XMLData.ResultSummaries    = CalculateSummaries();
         i_XMLData.ResultDifferences  = CalculateDifferences();
      }

      string strErrorMessage;
      if (i_XMLData.SaveApproximation(bExcludeOutputNode,out strErrorMessage))
      {
         SetStatusCaption();

         i_bOutputSaved=!bExcludeOutputNode;
         EnableDisableControls();

         SysUtils.MessageDialog.ShowInformation
         (
            string.Format(
               Resources_FormMain.DataSaved_MsgFmt,
               Path.GetFullPath(i_XMLData.FileName) )+
            ( bExcludeOutputNode ?
                  "\n\n"+Resources_FormMain.OutputNodeExcluded_Msg : "" )
         );

         return;
      }

      SysUtils.MessageDialog.ShowError( strErrorMessage,
         Resources_FormMain.CantSaveData_Title );

      SetStatusCaption();
   }
}

void AssignTollStripButtonText(ToolStripButton button,ToolStripMenuItem item)
{
   button.ToolTipText="";
   Keys keys=item.ShortcutKeys;
   button.Text=item.Text;
   if (keys!=Keys.None)
      button.Text+=" ("+TypeDescriptor.GetConverter(typeof(Keys)).ConvertToString(keys)+")";
}

void PlayStartupSound()
{
   if (!i_bStarupSoudPlayed)
   {
      Utilities.PlaySound("Startup");
      i_bStarupSoudPlayed=true;
   }
}

//===============================================================================================

private void FormMain_Load(object sender,EventArgs e)
{
   menuItemStartStop.ImageTransparentColor=sr_StartStopBitmapTransparentColor;

   AssignTollStripButtonText(toolStripButtonLoad         ,menuItemLoad         );
   AssignTollStripButtonText(toolStripButtonSave         ,menuItemSave         );
   AssignTollStripButtonText(toolStripButtonSaveInputOnly,menuItemSaveInputOnly);
   AssignTollStripButtonText(toolStripButtonViewContent  ,menuItemViewContent  );
   AssignTollStripButtonText(toolStripButtonClear        ,menuItemClear        );
   AssignTollStripButtonText(toolStripButtonViewSchema   ,menuItemViewSchema   );
   AssignTollStripButtonText(toolStripButtonCustomize    ,menuItemCustomize    );
   AssignTollStripButtonText(toolStripButtonDescription  ,menuItemDescription  );
   AssignTollStripButtonText(toolStripButtonAbout        ,menuItemAbout        );

   panelContainers.BackColor=
      panelSummary.BackColor=
         sr_BoxBackColor;

   ActiveControl=buttonStartStop;

   ClearApproximation();
}

private void FormMain_Shown(object sender,EventArgs e)
{
   SysUtils.WaitCursor wc=new SysUtils.WaitCursor();

   Update();

   SetStatusCaption(Resources_FormMain.InitializingTheApp_Msg);

   try
   {
      FormCustomize.ReadSettings();
   }
   catch (SystemException ex)
   {
      SysUtils.MessageDialog.ShowError( ex.Message,
         Resources_FormMain.CantReadCfgProperties_Title );
      Close();
      return;
   }

   Program.SetInitialized();

   SetStatusCaption();

   DeleteTemporaryFilesIfPossible();

   if (Program.IsFirstClickOnceRun)
   {
      PlayStartupSound();
      SysUtils.MessageDialog.ShowExclamation(
         string.Format( "{0}\n\n{1}",
            Resources_FormMain.TheFirstStart_Msg,
            Program.VersionCaption ) );
   }

   string strDefaultXML=
      Program.Settings.DontUseDefaultXML ? null : Program.Settings.DefaultXML;

   if (strDefaultXML!=null && strDefaultXML!="")
   {
      if ( SysUtils.FilePath.DoesContainVolumeSeparatorChar(strDefaultXML) ||
           SysUtils.FilePath.DoesContainDirectorySeparatorChar(strDefaultXML) )
         strDefaultXML=Path.GetFullPath(strDefaultXML);
      else
         strDefaultXML=Path.Combine(Program.DataPath,strDefaultXML);

      if (File.Exists(strDefaultXML))
      {
         if (LoadDataFromXML(strDefaultXML))
            PlayStartupSound();
         SetStatusCaption();
         wc.Dispose();
         return;
      }

      SysUtils.MessageDialog.ShowError(string.Format(
         Resources_FormMain.DefaultXMLNotFound_MsgFmt+"\n"+
         Resources_FormMain.ChooseItFromDialogInstead_Msg,
         strDefaultXML ));
   }
   else
      PlayStartupSound();

   SetStatusCaption();

   wc.Dispose();

   menuItemLoad_Click(sender,e);
}

private void FormMain_FormClosing(object sender,FormClosingEventArgs e)
{
   SysUtils.WaitCursor.SetWait();

   Update();

   if (IsInProgress && !i_bApproximationCancelled)
   {
      RequestStopApproximation();
      i_bFormCloseRequest=true;
      e.Cancel=true;
      Enabled=false;
      return;
   }

   SetStatusCaption(
      Resources_FormMain.ClosingTheApp_Msg,
      true );

   if (Program.IsInitialized)
      Program.SaveAppSettings();

   Utilities.CloseProcess(ref i_IEProcessXML);
   Utilities.CloseProcess(ref i_IEProcessXSD,true);
   Utilities.CloseProcess(ref i_DocumentProcess,true);

   DeleteTemporaryFilesIfPossible();
}

private void FormMain_Resize(object sender,EventArgs e)
{
   if (!i_bFormResized)
   {
      i_nPanelContainersInitialHeight= panelContainers.Height;
      i_nPanelSummaryInitialHeight   = panelSummary   .Height;
   }

   int
      nVertClearance= panelContainers.Top,
      nVertSpace    = panelGraphics.ClientSize.Height-nVertClearance*3;

   panelContainers.Height= nVertSpace * i_nPanelContainersInitialHeight
      / (i_nPanelContainersInitialHeight+i_nPanelSummaryInitialHeight);
   panelSummary.Top   = panelContainers.Bottom+nVertClearance;
   panelSummary.Height= nVertSpace-panelContainers.Height;

   // This is needed to correct panel's widths, when the app. started with minimized window:
   panelContainers.Width= panelGraphics.ClientRectangle.Width-panelContainers.Left*2;
   panelSummary   .Width= panelGraphics.ClientRectangle.Width-panelSummary   .Left*2;

   AdjustSizesBoxes();

   Refresh();

   i_bFormResized=true;
}

private void FormMain_KeyDown(object sender,KeyEventArgs e)
{
   if (e.KeyCode==Keys.Escape && e.Modifiers==0)
      if (i_bFormCloseRequest)
         SysUtils.Beeper.FaintBeep();
      else
         if ( MessageBox.Show(
               Resources_FormMain.AppCloseConfirmation_Msg,
               string.Format( Resources_FormMain.AppCloseConfirmation_TitleFmt,
                              SysUtils.RootInfo.ApplicationTitle ),
               MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation ) == DialogResult.OK )
            Close();
}

private void checkBoxBallanceCorruption_CheckedChanged(object sender,EventArgs e)
{
   menuItemBalanceCorruptionBug.Checked=checkBoxBallanceCorruptionBug.Checked;
}

private void checkBoxMonolithicBalance_CheckedChanged(object sender,EventArgs e)
{
   menuItemMonolithicBalanceOperation.Checked=checkBoxMonolithicBalanceOperation.Checked;
}

private void panelDataFile_Paint(object sender,PaintEventArgs e)
{
   if (i_XMLData==null || i_XMLData.FileName==null)
      return;

   Graphics
      grfx=e.Graphics;
   string
      strFileName=i_XMLData.FileName;
   SizeF
      sizeF=grfx.MeasureString(strFileName,panelDataFile.Font);

   StringFormat fmt=new StringFormat();
   fmt.FormatFlags=StringFormatFlags.NoWrap;

   float
      fLeft=sizeF.Height/4,
      fRightMargin=panelDataFile.ClientSize.Width-sizeF.Width-fLeft;
   if (fRightMargin<fLeft)
      strFileName=". . .  "+Path.GetFileName(strFileName);

   grfx.TextRenderingHint=TextRenderingHint.SystemDefault;
   grfx.DrawString( strFileName,
      panelDataFile.Font, new SolidBrush(ForeColor),
      fLeft, (panelDataFile.ClientSize.Height-sizeF.Height)/2,
      fmt );
}

private void panelContainers_Paint(object sender,PaintEventArgs e)
{
   if (i_ApproximationStatus!=ApproximationStatus.Blank)
   {
      Graphics grfx=e.Graphics;

      grfx.FillRectangle(sr_GraphicPanelBrush,panelContainers.ClientRectangle);
      foreach (ContainerBox containerBox in i_ContainerBoxes)
         containerBox.DoPaint(grfx);
   }
}

private void panelSummary_Paint(object sender,PaintEventArgs e)
{
   if (i_ApproximationStatus!=ApproximationStatus.Blank)
   {
      Graphics grfx=e.Graphics;

      grfx.FillRectangle(sr_GraphicPanelBrush,panelSummary.ClientRectangle);
      i_SummaryBox.DoPaint(grfx);
   }
}

//-----------------------------------------------------------------------------------------------

private void buttonReset_Click(object sender,EventArgs e)
{
   menuItemReset_Click(sender,e);
}

private void buttonStartStop_Click(object sender,EventArgs e)
{
   menuItemStartStop_Click(sender,e);
}

//-----------------------------------------------------------------------------------------------

private void menuItemLoad_Click(object sender,EventArgs e)
{
   using (new SysUtils.WaitCursor())
   {
      Update();

      openFileDialog.InitialDirectory = i_XMLData==null ?
         Program.DataPath : Path.GetDirectoryName(i_XMLData.FileName);
      openFileDialog.FileName = i_XMLData==null ?
         null : Path.GetFileName(i_XMLData.FileName);

      if (openFileDialog.ShowDialog()==DialogResult.OK)
      {
         Update();
         LoadDataFromXML(openFileDialog.FileName);
      }
   }
}

private void menuItemSave_Click(object sender,EventArgs e)
{
   Update(); SaveDataToXML();
}

private void menuItemSaveInputOnly_Click(object sender,EventArgs e)
{
   if ( MessageBox.Show(
         Resources_FormMain.ConfirmSaveInputOnly_Msg,
         SysUtils.RootInfo.ApplicationTitle,
         MessageBoxButtons.OKCancel,
         MessageBoxIcon.Warning )==DialogResult.OK )
   {
      Update(); SaveDataToXML(true);
   }
}

private void menuItemClear_Click(object sender,EventArgs e)
{
   ClearApproximation();
}

private void menuItemExit_Click(object sender,EventArgs e)
{
   Close();
}

private void menuItemBalanceCorruption_Click(object sender,EventArgs e)
{
   checkBoxBallanceCorruptionBug.Checked=!checkBoxBallanceCorruptionBug.Checked;
}

private void menuItemMonolithicBalance_Click(object sender, EventArgs e)
{
   checkBoxMonolithicBalanceOperation.Checked=!checkBoxMonolithicBalanceOperation.Checked;
}

private void menuItemReset_Click(object sender,EventArgs e)
{
   ResetApproximation(); ActiveControl=buttonStartStop;
}

private void menuItemStartStop_Click(object sender,EventArgs e)
{
   switch (i_ApproximationStatus)
   {
   case ApproximationStatus.InitialState:
      StartApproximation();
      break;
   case ApproximationStatus.InProgress:
      RequestStopApproximation();
      break;
   case ApproximationStatus.Suspended:
      StartApproximation();
      break;
   case ApproximationStatus.Finished:
      InitializeApproximation();
      SynchronizeBoxes();
      StartApproximation();
      break;
   }
}

private void menuItemCustomize_Click(object sender,EventArgs e)
{
   Update(); new FormCustomize().ShowDialog();
}

private void menuItemViewContent_Click(object sender,EventArgs e)
{
   Update();

   using (new SysUtils.WaitCursor())
   {
      SetStatusCaption(Resources_FormMain.LaunchingIE_Msg);

      Utilities.CloseProcess(ref i_IEProcessXML,true);

      ProcessStartInfo startupInfo=
         new ProcessStartInfo(c_strIEExeName,i_XMLData.FileName);
      startupInfo.WindowStyle=ProcessWindowStyle.Maximized;
      try
      {
         i_IEProcessXML=Process.Start(startupInfo);
         Utilities.WaitForInputIdleProcess(i_IEProcessXML);
      }
      catch (Win32Exception ex)
      {
         SysUtils.MessageDialog.ShowError( ex,
            Resources_FormMain.CantLaunchIE_Title );
      }

      SetStatusCaption();
   }
}

private void menuItemViewSchema_Click(object sender,EventArgs e)
{
   Update();

   using (new SysUtils.WaitCursor())
   {
      SetStatusCaption(string.Format(
         Resources_FormMain.PreparingSchemaFile_MsgFmt,
         sr_strTemporaryApproximationSchemaFileName ));

      string
         strXMLSchemaText=Resources.Approximation_XSD;
      StreamWriter
         sw=null;
      try
      {
         sw=new StreamWriter(sr_strTemporaryApproximationSchemaFileWithPath);
         sw.Write(strXMLSchemaText);
         SysUtils.GenOps.CloseIfNotNull(ref sw);
      }
      catch (SystemException ex)
      {
         if (sw!=null)
            try { sw.Close(); }
            catch (IOException) {}
         SysUtils.MessageDialog.ShowError( ex,
            Resources_FormMain.CantPrepareSchemaFile_Title );
         goto QUIT;
      }

      SetStatusCaption(Resources_FormMain.LaunchingIE_Msg);

      Utilities.CloseProcess(ref i_IEProcessXSD,true);

      ProcessStartInfo startupInfo=
         new ProcessStartInfo(c_strIEExeName,sr_strTemporaryApproximationSchemaFileWithPath);
      startupInfo.WindowStyle=ProcessWindowStyle.Maximized;
      try
      {
         i_IEProcessXSD=Process.Start(startupInfo);
         Utilities.WaitForInputIdleProcess(i_IEProcessXSD);
      }
      catch (Win32Exception ex)
      {
         SysUtils.MessageDialog.ShowError( ex,
            Resources_FormMain.CantLaunchIE_Title );
      }

   QUIT:
      SetStatusCaption();
   }
}

//-----------------------------------------------------------------------------------------------

private void menuItemFatalError_Click(object sender, EventArgs e)
{
   SysUtils.FatalError.Perform(Resources.ApplicationBugCheck_Msg);
}

private void menuItemFatalErrorNoStackTrace_Click(object sender, EventArgs e)
{
   SysUtils.FatalError.Perform(Resources.ApplicationBugCheck_Msg,null);
}

private void menuItemFatalException_Click(object sender, EventArgs e)
{
   throw new ApplicationBugCheckException();
}

private void menuItemFatalExceptionChain_Click(object sender, EventArgs e)
{
   TroubleClass.Touch();
}

//-----------------------------------------------------------------------------------------------

private void menuItemLostExceptionChain_Plain_Click(object sender,EventArgs e)
{
   LostExceptionChainDemo.PerformDemonstration(LostExceptionChainDemo.Mode.Plain);
}

private void menuItemLostExceptionChain_Advanced_Click(object sender,EventArgs e)
{
   LostExceptionChainDemo.PerformDemonstration(LostExceptionChainDemo.Mode.Advanced);
}

private void menuItemLostExceptionChain_AdvancedPlus_Click(object sender,EventArgs e)
{
   LostExceptionChainDemo.PerformDemonstration(LostExceptionChainDemo.Mode.AdvancedPlus);
}

//-----------------------------------------------------------------------------------------------

private void menuItemDescription_Click(object sender,EventArgs e)
{
   Update();

   using (new SysUtils.WaitCursor())
   {
      SetStatusCaption(string.Format(
         Resources_FormMain.OpeningDescriptionFile_MsgFmt,
         sr_strDescriptionFileName ));

      string strDescriptionFile=
         Path.Combine(Program.AppDocPath,sr_strDescriptionFileName);

      Utilities.CloseProcess(ref i_DocumentProcess,true);

      if (!File.Exists(strDescriptionFile))
      {
         SysUtils.MessageDialog.ShowError(string.Format(
            Resources_FormMain.DescriptionFileNotFound_MsgFmt,
            strDescriptionFile ));
         goto QUIT;
      }

      try
      {
         if ((File.GetAttributes(strDescriptionFile) & FileAttributes.ReadOnly)==0)
         {
            if (File.Exists(sr_strTemporaryDescriptionFileWithPath))
               File.Delete(sr_strTemporaryDescriptionFileWithPath);
            File.Copy(strDescriptionFile,sr_strTemporaryDescriptionFileWithPath);
            strDescriptionFile=sr_strTemporaryDescriptionFileWithPath;
         }
      }
      catch (SystemException ex)
      {
         SysUtils.MessageDialog.ShowError( ex.Message,
            Resources_FormMain.PreparingDescriptionFile_Title );
         goto QUIT;
      }

      ProcessStartInfo startupInfo=
         new ProcessStartInfo(strDescriptionFile);
      startupInfo.WindowStyle=ProcessWindowStyle.Maximized;
      try
      {
         i_DocumentProcess=Process.Start(startupInfo);
         Utilities.WaitForInputIdleProcess(i_DocumentProcess);
      }
      catch (Win32Exception ex)
      {
         SysUtils.MessageDialog.ShowError( ex,
            Resources_FormMain.CantOpenDocument_Title );
      }

   QUIT:
      SetStatusCaption();
   }
}

private void menuItemAbout_Click(object sender,EventArgs e)
{
   Update();

   SysUtils.WaitCursor.SetWait();

   new FormAbout().ShowDialog();
}

//-----------------------------------------------------------------------------------------------

private void toolStripButtonLoad_Click(object sender,EventArgs e)
{
   menuItemLoad_Click(sender,e);
}

private void toolStripButtonSave_Click(object sender,EventArgs e)
{
   menuItemSave_Click(sender,e);
}

private void toolStripButtonSaveInputOnly_Click(object sender,EventArgs e)
{
   menuItemSaveInputOnly_Click(sender,e);
}

private void toolStripButtonViewContent_Click(object sender,EventArgs e)
{
   menuItemViewContent_Click(sender,e);
}

private void toolStripButtonClear_Click(object sender,EventArgs e)
{
   menuItemClear_Click(sender,e);
}

private void toolStripButtonViewSchema_Click(object sender,EventArgs e)
{
   menuItemViewSchema_Click(sender,e);
}

private void toolStripButtonCustomize_Click(object sender,EventArgs e)
{
   menuItemCustomize_Click(sender,e);
}

private void toolStripButtonDescription_Click(object sender,EventArgs e)
{
   menuItemDescription_Click(sender,e);
}

private void toolStripButtonAbout_Click(object sender,EventArgs e)
{
   menuItemAbout_Click(sender,e);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // FormMain
//***********************************************************************************************

} // Balance
