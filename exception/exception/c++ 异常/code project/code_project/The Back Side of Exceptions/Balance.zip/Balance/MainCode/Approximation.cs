﻿namespace Balance {

using System;
using System.Diagnostics;

//***********************************************************************************************
class Approximation {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public Approximation( CompoundContainer[] containers,
                      CalcType[] targetSummaries,
                      CalcType epsilon )
{
   Debug.Assert(
      containers.Length>0 &&
      containers[0].ComponentCount==targetSummaries.Length,
      "Incorrect parameters for approximation object constructor." );

   Debug.Assert(epsilon>0,"Epsilon must be strictly greater than zero.");

   Containers     = containers;
   TargetSummaries= targetSummaries;
   Epsilon        = epsilon;

   i_Summaries        = new CalcType[ComponentCount];
   i_Differences      = new CalcType[ComponentCount];
   i_Weights          = new CalcType[Containers.Length];
   i_InternalTransfers= new CalcType[Containers.Length];
}

public readonly CompoundContainer[] Containers;
public readonly CalcType[] TargetSummaries;
public readonly CalcType Epsilon;

public int ComponentCount
   { get { return Containers[0].ComponentCount; } }

public CalcType MaxDifference
   { get { СalculateValues(); return i_MaxDifference; } }

public CalcType Divergence
   { get { СalculateValues(); return Math.Abs(i_Divergence); } }

public int IterationCount
   { get { return i_nIterationCount; } }

/// <summary>
/// Upper level code (in terms of the monolithic code block).
/// It invokes transactional operation <see cref="CompoundContainer.Balance"/>
/// (which is performed at the middle level).
/// </summary>
public bool PerformIteration()
{
   СalculateValues();

   for (int j=0;j<Containers.Length;j++)
      for ( CalcType internalTransfer=i_InternalTransfers[j];
            internalTransfer>=Epsilon; internalTransfer/=2 )
         try
         {
            // Performing transactional operation at the middle level:
            Containers[j].Balance(i_nComponentIdx_1,i_nComponentIdx_2,internalTransfer);
            i_bValuesUpToDate=false;
            break;
         }
         catch (ArgumentException)
         {
            // This exception designates that intercomponent transfer is impossible
            // (normaly it is not an error).
            // But exception misidentification may occur here!
         }

   i_nIterationCount++;

   return !i_bValuesUpToDate;
}

//===============================================================================================

void СalculateValues()
{
   if (i_bValuesUpToDate)
      return;

   for (int i=0;i<ComponentCount;i++)
   {
      i_Summaries[i]=0;
      foreach (CompoundContainer container in Containers)
         i_Summaries[i]+=container[i];
   }

   i_MaxDifference=0;
   for (int i=0;i<ComponentCount;i++)
   {
      i_Differences[i]=TargetSummaries[i]-i_Summaries[i];
      i_MaxDifference=Math.Max(i_MaxDifference,Math.Abs(i_Differences[i]));
   }

   i_Divergence=0; i_nComponentIdx_1=-1; i_nComponentIdx_2=-1;

   for (int i=0;i<ComponentCount-1;i++)
      for (int j=i+1;j<ComponentCount;j++)
      {
         CalcType dvg=i_Differences[i]-i_Differences[j];
         if (i_nComponentIdx_1<0 || Math.Abs(dvg)>Math.Abs(i_Divergence))
         {
            i_nComponentIdx_1=i; i_nComponentIdx_2=j; i_Divergence=dvg;
         }
      }

   for (int j=0;j<Containers.Length;j++)
      i_Weights[j]=Containers[j].TotalQuantity;
   CalcType sumWeight=GenAlgs.Sum(i_Weights);
   for (int j=0;j<Containers.Length;j++)
      i_InternalTransfers[j]=-i_Divergence*i_Weights[j]/sumWeight/2;

   i_bValuesUpToDate=true;
}

//-----------------------------------------------------------------------------------------------

CalcType[]
   i_Summaries, i_Differences, i_Weights, i_InternalTransfers;
CalcType
   i_MaxDifference, i_Divergence;
int
   i_nIterationCount, i_nComponentIdx_1, i_nComponentIdx_2;
bool
   i_bValuesUpToDate;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // Approximation
//***********************************************************************************************

} // Balance
