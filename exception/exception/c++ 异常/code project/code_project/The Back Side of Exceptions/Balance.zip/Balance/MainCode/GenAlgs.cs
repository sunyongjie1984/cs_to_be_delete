﻿namespace Balance {

using System;
using System.Collections.Generic;

//***********************************************************************************************
static class GenAlgs {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public static CalcType Sum(ICollection<CalcType> collection)
{
   CalcType rslt=0;
   foreach (CalcType element in collection)
      rslt+=element;
   return rslt;
}

public static CalcType Max(ICollection<CalcType> collection)
{
   CalcType? maxValue=null;
   foreach (CalcType element in collection)
      if (maxValue==null || element>maxValue)
         maxValue=element;
   return (CalcType)maxValue;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // GenAlgs
//***********************************************************************************************

} // Balance
