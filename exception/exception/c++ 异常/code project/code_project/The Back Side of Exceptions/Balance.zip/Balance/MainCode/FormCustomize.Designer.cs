﻿namespace Balance
{
   partial class FormCustomize
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.groupBoxBehaviour = new System.Windows.Forms.GroupBox();
         this.checkBoxNoBeep = new System.Windows.Forms.CheckBox();
         this.checkBoxNoSound = new System.Windows.Forms.CheckBox();
         this.checkBoxDontUseDefaultXML = new System.Windows.Forms.CheckBox();
         this.textBoxDefaultXML = new System.Windows.Forms.TextBox();
         this.labelDefaultXML = new System.Windows.Forms.Label();
         this.buttonOk = new System.Windows.Forms.Button();
         this.buttonCancel = new System.Windows.Forms.Button();
         this.labelUserConfig = new System.Windows.Forms.Label();
         this.buttonReset = new System.Windows.Forms.Button();
         this.groupBoxBehaviour.SuspendLayout();
         this.SuspendLayout();
         // 
         // groupBoxBehaviour
         // 
         this.groupBoxBehaviour.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
         this.groupBoxBehaviour.Controls.Add(this.checkBoxNoBeep);
         this.groupBoxBehaviour.Controls.Add(this.checkBoxNoSound);
         this.groupBoxBehaviour.Controls.Add(this.checkBoxDontUseDefaultXML);
         this.groupBoxBehaviour.Controls.Add(this.textBoxDefaultXML);
         this.groupBoxBehaviour.Controls.Add(this.labelDefaultXML);
         this.groupBoxBehaviour.Location = new System.Drawing.Point(12,12);
         this.groupBoxBehaviour.Name = "groupBoxBehaviour";
         this.groupBoxBehaviour.Size = new System.Drawing.Size(426,154);
         this.groupBoxBehaviour.TabIndex = 0;
         this.groupBoxBehaviour.TabStop = false;
         this.groupBoxBehaviour.Text = "Program\'s behaviour";
         // 
         // checkBoxNoBeep
         // 
         this.checkBoxNoBeep.AutoSize = true;
         this.checkBoxNoBeep.Location = new System.Drawing.Point(9,123);
         this.checkBoxNoBeep.Name = "checkBoxNoBeep";
         this.checkBoxNoBeep.Size = new System.Drawing.Size(377,17);
         this.checkBoxNoBeep.TabIndex = 4;
         this.checkBoxNoBeep.Text = "Do not use &beeper (avoid special signals produced by computer\'s speaker)";
         this.checkBoxNoBeep.UseVisualStyleBackColor = true;
         this.checkBoxNoBeep.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
         // 
         // checkBoxNoSound
         // 
         this.checkBoxNoSound.AutoSize = true;
         this.checkBoxNoSound.Location = new System.Drawing.Point(9,100);
         this.checkBoxNoSound.Name = "checkBoxNoSound";
         this.checkBoxNoSound.Size = new System.Drawing.Size(360,17);
         this.checkBoxNoSound.TabIndex = 3;
         this.checkBoxNoSound.Text = "Do not use &sound effects (avoid special sounds, played via audio card)";
         this.checkBoxNoSound.UseVisualStyleBackColor = true;
         this.checkBoxNoSound.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
         // 
         // checkBoxDontUseDefaultXML
         // 
         this.checkBoxDontUseDefaultXML.AutoSize = true;
         this.checkBoxDontUseDefaultXML.Location = new System.Drawing.Point(9,67);
         this.checkBoxDontUseDefaultXML.Name = "checkBoxDontUseDefaultXML";
         this.checkBoxDontUseDefaultXML.Size = new System.Drawing.Size(265,17);
         this.checkBoxDontUseDefaultXML.TabIndex = 2;
         this.checkBoxDontUseDefaultXML.Text = "D&on\'t load the XML — show file open dialog instead";
         this.checkBoxDontUseDefaultXML.UseVisualStyleBackColor = true;
         this.checkBoxDontUseDefaultXML.CheckedChanged += new System.EventHandler(this.checkBoxDontLoadXML_CheckedChanged);
         // 
         // textBoxDefaultXML
         // 
         this.textBoxDefaultXML.Location = new System.Drawing.Point(9,41);
         this.textBoxDefaultXML.Name = "textBoxDefaultXML";
         this.textBoxDefaultXML.Size = new System.Drawing.Size(411,20);
         this.textBoxDefaultXML.TabIndex = 1;
         this.textBoxDefaultXML.TextChanged += new System.EventHandler(this.textBox_TextChanged);
         // 
         // labelDefaultXML
         // 
         this.labelDefaultXML.AutoSize = true;
         this.labelDefaultXML.Location = new System.Drawing.Point(6,25);
         this.labelDefaultXML.Name = "labelDefaultXML";
         this.labelDefaultXML.Size = new System.Drawing.Size(369,13);
         this.labelDefaultXML.TabIndex = 0;
         this.labelDefaultXML.Text = "\"&DefaultXML\" — datafile (with or without path) to be loaded at startup, if exist" +
    "s";
         // 
         // buttonOk
         // 
         this.buttonOk.DialogResult = System.Windows.Forms.DialogResult.OK;
         this.buttonOk.Location = new System.Drawing.Point(191,172);
         this.buttonOk.Name = "buttonOk";
         this.buttonOk.Size = new System.Drawing.Size(164,29);
         this.buttonOk.TabIndex = 2;
         this.buttonOk.Text = "Apply and save the settings";
         this.buttonOk.UseVisualStyleBackColor = true;
         // 
         // buttonCancel
         // 
         this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
         this.buttonCancel.Location = new System.Drawing.Point(361,172);
         this.buttonCancel.Name = "buttonCancel";
         this.buttonCancel.Size = new System.Drawing.Size(71,29);
         this.buttonCancel.TabIndex = 3;
         this.buttonCancel.Text = "Cancel";
         this.buttonCancel.UseVisualStyleBackColor = true;
         // 
         // labelUserConfig
         // 
         this.labelUserConfig.AutoSize = true;
         this.labelUserConfig.Font = new System.Drawing.Font("Microsoft Sans Serif",8.25F,System.Drawing.FontStyle.Underline,System.Drawing.GraphicsUnit.Point,((byte)(204)));
         this.labelUserConfig.Location = new System.Drawing.Point(94,180);
         this.labelUserConfig.Name = "labelUserConfig";
         this.labelUserConfig.Size = new System.Drawing.Size(91,13);
         this.labelUserConfig.TabIndex = 3;
         this.labelUserConfig.Text = "File: \"user.config\"";
         // 
         // buttonReset
         // 
         this.buttonReset.Location = new System.Drawing.Point(21,172);
         this.buttonReset.Name = "buttonReset";
         this.buttonReset.Size = new System.Drawing.Size(58,28);
         this.buttonReset.TabIndex = 1;
         this.buttonReset.Text = "&Reset";
         this.buttonReset.UseVisualStyleBackColor = true;
         this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
         // 
         // FormCustomize
         // 
         this.AcceptButton = this.buttonOk;
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.CancelButton = this.buttonCancel;
         this.ClientSize = new System.Drawing.Size(450,208);
         this.Controls.Add(this.buttonReset);
         this.Controls.Add(this.labelUserConfig);
         this.Controls.Add(this.buttonCancel);
         this.Controls.Add(this.buttonOk);
         this.Controls.Add(this.groupBoxBehaviour);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "FormCustomize";
         this.ShowInTaskbar = false;
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
         this.Text = "Customize (user scoped settings)";
         this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormCustomize_FormClosing);
         this.Load += new System.EventHandler(this.FormCustomize_Load);
         this.groupBoxBehaviour.ResumeLayout(false);
         this.groupBoxBehaviour.PerformLayout();
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.GroupBox groupBoxBehaviour;
      private System.Windows.Forms.Label labelDefaultXML;
      private System.Windows.Forms.TextBox textBoxDefaultXML;
      private System.Windows.Forms.CheckBox checkBoxDontUseDefaultXML;
      private System.Windows.Forms.CheckBox checkBoxNoBeep;
      private System.Windows.Forms.CheckBox checkBoxNoSound;
      private System.Windows.Forms.Button buttonOk;
      private System.Windows.Forms.Button buttonCancel;
      private System.Windows.Forms.Label labelUserConfig;
      private System.Windows.Forms.Button buttonReset;
   }
}