﻿namespace SysUtils {

using System;
using System.Resources;
using System.Reflection;
using System.IO;

//***********************************************************************************************
static class Resources {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public static string ResourcesName
{
   get {
      return RuntimeParams._ResourcesName;
   }
}

public static ResourceManager ResourceManager
{
   get {
      return s_ResourceManager;
   }
   set {
      RuntimeParams._ResourcesName=
         (s_ResourceManager=value).BaseName;
   }
}

//-----------------------------------------------------------------------------------------------

public static string STR(string strStringName)
{
   return STR(null,strStringName);
}

public static object OBJ(string strObjectName)
{
   return OBJ(null,strObjectName);
}

public static UnmanagedMemoryStream GetStream(string strEntityName)
{
   return GetStream(null,strEntityName);
}

public static UnmanagedMemoryStream GetImageStream(string strImageName)
{
   return GetImageStream(null,strImageName);
}

public static UnmanagedMemoryStream GetSoundStream(string strSoundName)
{
   return GetSoundStream(null,strSoundName);
}

//-----------------------------------------------------------------------------------------------

public static string STR(ResourceManager rm,string strStringName)
{
   return (string)ExtractObject( rm, strStringName,
      "Resource string not found: \"{0}\" (in \"{1}\")." );
}

public static object OBJ(ResourceManager rm,string strObjectName)
{
   return ExtractObject( rm, strObjectName,
      "Resource object not found: \"{0}\" (in \"{1}\")." );
}

public static UnmanagedMemoryStream GetStream(ResourceManager rm,string strEntityName)
{
   return GetStreamEx( rm, strEntityName,
      "Resource entiry not found: \"{0}\" (in \"{1}\")." );
}

public static UnmanagedMemoryStream GetImageStream(ResourceManager rm,string strImageName)
{
   return GetStreamEx( rm, strImageName,
      "Resource image not found: \"{0}\" (in \"{1}\")." );
}

public static UnmanagedMemoryStream GetSoundStream(ResourceManager rm,string strSoundName)
{
   return GetStreamEx( rm, strSoundName,
      "Resource sound not found: \"{0}\" (in \"{1}\")." );
}

//-----------------------------------------------------------------------------------------------

public static Stream GetManifestStream(string strResourceName)
{
   Stream stream=
      Assembly.GetExecutingAssembly().GetManifestResourceStream(
         strResourceName );
   if (stream==null)
      SysUtils.FatalError.Perform(string.Format(
         "Manifest resource not found: \"{0}\".",
         strResourceName ));
   return stream;
}

//-----------------------------------------------------------------------------------------------

public static void _InitializeClass()
{
   if (s_ResourceManager==null && ResourcesName!=null)
      s_ResourceManager=new ResourceManager(
         ResourcesName, Assembly.GetExecutingAssembly() );
}

//===============================================================================================

static object ExtractObject(ResourceManager rm,string strObjectName,string strErrorMessageFmt)
{
   ResourceManager
      rcMan=rm ?? s_ResourceManager;
   object rslt=
      rcMan.GetObject(strObjectName);
   if (rslt==null)
      SysUtils.FatalError.Perform(string.Format( strErrorMessageFmt,
         strObjectName, rcMan.BaseName ));
   return rslt;
}

static UnmanagedMemoryStream GetStreamEx( ResourceManager rm,
                                          string strEntityName,
                                          string strErrorMessageFmt )
{
   ResourceManager
      rcMan=rm ?? s_ResourceManager;
   UnmanagedMemoryStream
      umStream=rcMan.GetStream(strEntityName);
   if (umStream==null)
      SysUtils.FatalError.Perform(string.Format( strErrorMessageFmt,
         strEntityName, rcMan.BaseName ));
   return umStream;
}

//-----------------------------------------------------------------------------------------------

static ResourceManager
   s_ResourceManager;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // Resources
//***********************************************************************************************

} // SysUtils
