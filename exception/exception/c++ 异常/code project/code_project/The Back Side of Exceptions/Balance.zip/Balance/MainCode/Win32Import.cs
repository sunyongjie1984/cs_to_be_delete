﻿namespace Balance {

using System;
using System.Runtime.InteropServices;


//***********************************************************************************************
static class Win32Import {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public const int SW_SHOW         = 5;
public const int SW_SHOWNORMAL   = 1;
public const int SW_SHOWMAXIMIZED= 3;
public const int SW_RESTORE      = 9;

//===============================================================================================

[DllImport("User32")]
public static extern bool ShowWindow(IntPtr hWnd,int nCmdShow);

[DllImport("User32")]
public static extern IntPtr GetActiveWindow();

[DllImport("User32",SetLastError=true)]
public static extern IntPtr SetActiveWindow(IntPtr hWnd);

[DllImport("User32")]
public static extern bool SetForegroundWindow(IntPtr hWnd);

[DllImport("User32")]
public static extern IntPtr GetLastActivePopup(IntPtr hWnd);

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // Win32Import
//***********************************************************************************************

} // Balance
