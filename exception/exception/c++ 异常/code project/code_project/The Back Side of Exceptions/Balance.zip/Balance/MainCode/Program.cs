﻿//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//
// This program and the SysUtils-library was written by Sergei Kitaev, a senior programmer
// at Voronezh Municipal Center of Information and Analysis -- MUP MIVC (the city of Voronezh).
//
// Copyright: Sergei Kitaev
//
//
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
namespace Balance {

using System;
using System.Configuration;
using System.Threading;
using System.Windows.Forms;
using System.Reflection;
using System.Deployment.Application;
using System.IO;
using System.Text;
using Balance.Properties;

//***********************************************************************************************
static class Program {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/// <summary>
/// Invocation of primary initialization code block.
/// </summary>
/// <remarks>
/// It is placed at the very beginning of <see cref="Program"/> class containing
/// application&apos;s entry point.
/// </remarks>
static readonly int
   sr_nJunk=PrimaryInitialization();

//===============================================================================================

public static readonly Properties.Settings
   Settings=new Properties.Settings();

//===============================================================================================

public static bool IsInitialized
   { get { return s_bInitialized; } }

public static string VersionString
   { get { return Assembly.GetExecutingAssembly().GetName().Version.ToString(); } }

public static string VersionSuffix
   { get { return '_'+VersionString.Replace('.','_'); } }

public static string VersionCaption
{
   get {
      return s_strVersionCaption ??
         ( s_strVersionCaption=string.Format(
               SysUtils.RootInfo.IsDebugVersion ? 
                  Resources.AppVersion_Fmt_D :
                  Resources.AppVersion_Fmt,
               VersionString ) );
   }
}

public static string DataRoot
{
   get {
      return ApplicationDeployment.IsNetworkDeployed ?
         Application.LocalUserAppDataPath :
         SysUtils.RootInfo.ApplicationExeDir;
   }
}

public static string DataPath
{
   get {
      return Path.Combine(
         SysUtils.RootInfo.ApplicationExeDir,
         Resources.DataFolderName );
   }
}

public static string SoundPath
{
   get {
      return Path.Combine(
         SysUtils.RootInfo.ApplicationExeDir,
         Resources.SoundFolderName );
   }
}

public static string AppDocPath
{
   get {
      return Path.Combine(
         SysUtils.RootInfo.ApplicationExeDir,
         Resources.AppDocFolderName );
   }
}

public static string TempPath
{
   get {
      return SysUtils.RootInfo.ApplicationExeDir;
   }
}

public static bool IsFirstClickOnceRun
{
   get {
      return
         ApplicationDeployment.IsNetworkDeployed &&
         ApplicationDeployment.CurrentDeployment.IsFirstRun;
   }
}

//===============================================================================================

public static void SetInitialized()
{
   s_bInitialized=true;
}

public static bool SaveAppSettings()
{
   return SaveAppSettings(false);
}

public static bool SaveAppSettings(bool bWithStatus)
{
   bool rslt=false;

   using (new SysUtils.WaitCursor(bWithStatus))
   {
      StatusCaptionSaving
         saveCaption=bWithStatus ? FormMain.StatusCaption : null;
      if (saveCaption!=null)
         FormMain.SetStatusCaption( Resources.SavingAppSettings_Msg );
      try
      {
         Program.Settings.Save(); rslt=true;
      }
      catch (SystemException ex)
      {
         SysUtils.MessageDialog.ShowError( ex.Message,
            Resources.CantSaveAppSettings_Title );
      }
      FormMain.RestoreStatusCaption(saveCaption);
   }

   return rslt;
}

//===============================================================================================

/// <summary>
/// This static method works at program startup prior to any other code in the application.
/// </summary>
static int PrimaryInitialization()
{
   SysUtils.Debug.PrintMessage("");
   SysUtils.Debug.PrintInMethod(MethodBase.GetCurrentMethod());

   SysUtils.RuntimeParams.ApplicationTitle=Resources.ApplicationTitle;
   SysUtils.RuntimeParams.ResourcesName="Balance.Properties.Resources";
   SysUtils.RuntimeParams.FatalErrorOnUnhandledException=true;
   SysUtils.RuntimeParams.InitializeSysUtilsClasses();

   return 0; // <-- junk value
}

/// <summary>
/// The main entry point for the application.
/// </summary>
[STAThread]
static void Main()
{
   SysUtils.Debug.PrintMessage("=== Main routine -- BEGIN ===");

   Application.EnableVisualStyles();
   Application.ThreadException+=ThreadExceptionEventHandler;
   Application.ApplicationExit+=ApplicationExit;
   Application.Run(FormMain.Instance=new FormMain());

#if DEBUG
   FormMain.Instance=null;

   SysUtils.Debug.PrintOperation("Waiting for finalizers to complete");

   GC.Collect();
   GC.WaitForPendingFinalizers();
#endif

   SysUtils.Debug.PrintMessage("=== Main routine -- END ===");
   SysUtils.Debug.PrintMessage("");
}

static void ThreadExceptionEventHandler(object sender,ThreadExceptionEventArgs e)
{
   SysUtils.FatalError.UnhandledExceptionFilter( sender,
      new UnhandledExceptionEventArgs(e.Exception,false) );
}

static void ApplicationExit(object sender,EventArgs e)
{
   SysUtils.Debug.PrintInMethod(MethodBase.GetCurrentMethod());

   if (IsInitialized)
      Utilities.SyncPlaySound("Shutdown");
}

//===============================================================================================

static bool
   s_bInitialized;
static string
   s_strVersionCaption;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // Program
//***********************************************************************************************

} // Balance
