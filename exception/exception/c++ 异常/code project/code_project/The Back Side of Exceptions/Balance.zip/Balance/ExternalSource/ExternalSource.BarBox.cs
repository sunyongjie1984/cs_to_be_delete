﻿//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//
//  THIS IS, ACCORDING TO THE LEGEND -- THE "THIRD-PARTY" DEVELOPER'S IMPLEMENTATION
// OF ABSTRACT CLASS "BarBox". (IN FACT, THERE IS NO ACTUAL THIRD-PARTY DEVELOPER.)
//
// * THE FOLLOWING ERROR EXISTS -- MALICIOUS BUG IN "BarBox.RedrawBar" INSTANCE METHOD.
//
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
namespace ExternalSource {

using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

//***********************************************************************************************
delegate string GetCaptionDelegate();
delegate string GetSegmentCaptionDelegate(int nIdx);
//***********************************************************************************************


//***********************************************************************************************
/// <summary>
/// Base class for graphic element, looks as box of colored bars.
/// </summary>
abstract class BarBox {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public BarBox(Control control,int nBarCount,bool targetLevelsSupported,params Color[] barColors)
{
   Control=control;
   TargetLevelsSupported=targetLevelsSupported;
   Bounds=control.ClientRectangle;

   BarColors=new Color[nBarCount];
   for (int i=0,j=0; i<nBarCount; i++)
   {
      BarColors[i]=barColors[j++];
      if (j==barColors.Length) j=0;
   }

   i_dlgtRedrawCaption=new RedrawCaptionDelegate(RedrawCaption_UIThread);
   i_dlgtRedrawBar=new RedrawBarDelegate(RedrawBar_UIThread);
}

public readonly Control    Control;
public readonly bool       TargetLevelsSupported;
public readonly Color[]    BarColors;

public Color     BackColor               = Color.Black;
public Color     LevelLineColor          = Color.White;
public Color     FrameColor              = Color.Gray;
public Color     SegmentCaptionColor     = Color.White;
public Color     CaptionColor            = Color.White;
public Color     CaptionSurroundBackColor= Color.DarkGray;
public Color     CaptionCenterBackColor  = Color.Black;
public Font      CaptionFont             = new Font("Arial",8);
public Font      SegmentCaptionFont      = new Font("Arial",8);
public int       FrameWidth              = 1;
public int       LevelLineWidth          = 1;
public int       SegmentSplitterWidth    = 0;
public Rectangle Bounds;

public GetCaptionDelegate        GetCaptionCallback       = null;
public GetSegmentCaptionDelegate GetSegmentCaptionCallback= null;

public int BarCount
   { get { return BarColors.Length; } }

public bool IsCaptionSupported
   { get { return GetCaptionCallback!=null; } }

public bool AreSegmentCaptionsSupported
   { get { return GetSegmentCaptionCallback!=null; } }

public volatile bool _MaliciousBug;

public void DoPaint(Graphics grfx)
{
   Rectangle rcBars=CalculateBarsRectangle();
   Region rgnFrameAndSplitters=new Region(Bounds);
   for (int i=0;i<BarCount;i++)
      rgnFrameAndSplitters.Exclude(CalculateSegmentRectangle(rcBars,i));
   grfx.FillRegion(new SolidBrush(FrameColor),rgnFrameAndSplitters);

   i_grfxPaintTime=grfx;
   RedrawCaption();
   for (int i=0;i<BarCount;i++)
      RedrawBar(i);
   i_grfxPaintTime=null;
}

public void RedrawCaption()
{
   Control.Invoke(i_dlgtRedrawCaption);
}

/// <summary>
/// Lower level code (in terms of the monolithic code block), implicitly used
/// by <see cref="Balance.CompoundContainer.Balance" />
/// </summary>
/// <param name="nIdx">Index of bar to redraw.</param>
public void RedrawBar(int nIdx)
{
   Control.Invoke(i_dlgtRedrawBar,nIdx);

   // This exception is abnormal (it is unexpected at the middle and the upper levels)
   if (i_grfxPaintTime==null && _MaliciousBug)
      throw new ArgumentException("Malicious Bug Exception.");
}

//===============================================================================================

protected abstract double RelativeHeight(int nIdx);
protected abstract double LevelLineRelativeHeight(int nIdx);
protected abstract double MaxRelativeHeight { get; }

//===============================================================================================

delegate void RedrawCaptionDelegate();
delegate void RedrawBarDelegate(int nIdx);

//-----------------------------------------------------------------------------------------------

int CaptionHeight
   { get { return CaptionFont.Height*3/2; } }

Rectangle CalculateBarsRectangle()
{
   int
      splitterSpace=SegmentSplitterWidth*(BarCount-1),
      freeSpace=Bounds.Width-FrameWidth*2-splitterSpace,
      lostPixels=freeSpace%BarCount,
      actualWidth=freeSpace-lostPixels+splitterSpace,
      nCaptionAndFrameWidth=FrameWidth+(IsCaptionSupported ? CaptionHeight+FrameWidth : 0);

   return new Rectangle(
      Bounds.Left+FrameWidth+lostPixels/2, Bounds.Top+nCaptionAndFrameWidth,
      actualWidth, Bounds.Height-nCaptionAndFrameWidth-FrameWidth );
}

Rectangle CalculateSegmentRectangle(Rectangle rcBars,int nIdx)
{
   int barWidth=(rcBars.Width-SegmentSplitterWidth*(BarCount-1))/BarCount;

   return new Rectangle(
      rcBars.Left+(barWidth+SegmentSplitterWidth)*nIdx, rcBars.Top,
      barWidth, rcBars.Height );
}

void DrawSegmentCaption(Graphics grfx,Rectangle rcSegment,int nIdx)
{
   if (AreSegmentCaptionsSupported)
   {
      StringFormat fmt=new StringFormat();
      fmt.Alignment=StringAlignment.Center;
      grfx.TextRenderingHint=TextRenderingHint.SystemDefault;
      grfx.DrawString( GetSegmentCaptionCallback(nIdx), SegmentCaptionFont,
         new SolidBrush(SegmentCaptionColor), rcSegment, fmt );
   }
}

void RedrawCaption_UIThread()
{
   if (!IsCaptionSupported)
      return;

   string
      strCaption=GetCaptionCallback();
   if (i_grfxPaintTime==null && strCaption==i_strPreviousCaption)
      return;

   Graphics
      grfx=i_grfxPaintTime ?? Control.CreateGraphics();
   Rectangle
      rcCaptionBounds=new Rectangle(
         Bounds.Left, Bounds.Top,
         Bounds.Width, CaptionHeight+FrameWidth*2 ),
      rcCaptionClient=Rectangle.Inflate(rcCaptionBounds,-FrameWidth,-FrameWidth);
   Region
      rgnCaptionClient=new Region(rcCaptionClient),
      rgnCaptionFrame=new Region(rcCaptionBounds);
   rgnCaptionFrame.Exclude(rcCaptionClient);

   grfx.FillRegion(new SolidBrush(FrameColor),rgnCaptionFrame);

   Region rgnSaveClip=grfx.Clip;
   grfx.Clip=rgnCaptionClient;

   if (rcCaptionClient.Width>0 && rcCaptionClient.Height>0)
   {
      GraphicsPath clientPath=new GraphicsPath();
      clientPath.AddRectangle(rcCaptionClient);
      PathGradientBrush pgb=new PathGradientBrush(clientPath);
      pgb.CenterPoint=new PointF(
         (rcCaptionClient.Left+rcCaptionClient.Right)/2,
         (rcCaptionClient.Top+rcCaptionClient.Bottom)/2 );
      pgb.CenterColor=CaptionCenterBackColor;
      pgb.SurroundColors=new Color[]{ CaptionSurroundBackColor };
      grfx.FillRectangle(pgb,rcCaptionClient);
   }

   StringFormat fmt=new StringFormat();
   fmt.Alignment=StringAlignment.Center;
   fmt.LineAlignment=StringAlignment.Center;
   fmt.FormatFlags=StringFormatFlags.NoWrap;
   grfx.TextRenderingHint=TextRenderingHint.SystemDefault;
   grfx.DrawString( i_strPreviousCaption=strCaption, CaptionFont,
      new SolidBrush(CaptionColor), rcCaptionClient, fmt );

   grfx.Clip=rgnSaveClip;

   if (grfx!=i_grfxPaintTime)
      grfx.Dispose();
}

void RedrawBar_UIThread(int nIdx)
{
   Graphics
      grfx=i_grfxPaintTime ?? Control.CreateGraphics();
   Region
      rgnSaveClip=grfx.Clip;
   Rectangle
      rcBars=CalculateBarsRectangle(),
      rcSegment=CalculateSegmentRectangle(rcBars,nIdx);

   grfx.Clip=new Region(rcSegment);

   int barHeight=(int)(rcBars.Height*RelativeHeight(nIdx)/MaxRelativeHeight);

   Rectangle rc=new Rectangle(
      rcSegment.Left, rcSegment.Bottom-barHeight,
      rcSegment.Width, barHeight );

   grfx.FillRectangle(new SolidBrush(BarColors[nIdx]),rc);

   grfx.FillRectangle( new SolidBrush(BackColor),
      rcSegment.Left, rcSegment.Top,
      rcSegment.Width, rcSegment.Height-barHeight );

   if (TargetLevelsSupported)
   {
      int level=(int)(rcBars.Height*LevelLineRelativeHeight(nIdx)/MaxRelativeHeight);

      grfx.DrawLine(
         new Pen(new HatchBrush(HatchStyle.Percent50,LevelLineColor),LevelLineWidth),
         rcSegment.Left, rcSegment.Bottom-level,
         rcSegment.Right, rcSegment.Bottom-level );
   }

   DrawSegmentCaption(grfx,rcSegment,nIdx);

   grfx.Clip=rgnSaveClip;

   if (grfx!=i_grfxPaintTime)
      grfx.Dispose();
}

Graphics                i_grfxPaintTime;
RedrawCaptionDelegate   i_dlgtRedrawCaption;
RedrawBarDelegate       i_dlgtRedrawBar;
string                  i_strPreviousCaption;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // BarBox
//***********************************************************************************************

} // ExternalSource
