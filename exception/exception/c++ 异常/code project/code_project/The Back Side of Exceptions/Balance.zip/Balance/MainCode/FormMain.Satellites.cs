﻿namespace Balance {

using System;

//***********************************************************************************************
enum ApproximationStatus { Blank, InitialState, InProgress, Suspended, Finished }
//-----------------------------------------------------------------------------------------------
delegate void UpdateLabelsDelegate();
delegate void EndApproximationDelegate();
//***********************************************************************************************


//***********************************************************************************************
class StatusCaptionSaving
{
   public string Caption;

   public bool Active;

   public StatusCaptionSaving(string strCaption,bool bActive)
   {
      Caption=strCaption; Active=bActive;
   }
}
//***********************************************************************************************


//***********************************************************************************************
/// <summary>
/// This static class is used exclusively in demo purpose.
/// Calling its <see cref="Touch"/> method you will throw following exception chain:
/// <see cref="System.TypeInitializationException"/> (the original exception),
/// <see cref="Balance.ApplicationBugCheckException"/> (subsequent exception).
/// Prior exception is saved in <see cref="System.Exception.InnerException"/> property
/// of a subsequent one. So exception chain is organized.
/// </summary>
static class TroubleClass {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

static TroubleClass()
{
   throw new ApplicationBugCheckException();
}

public static void Touch() {}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // TroubleClass
//***********************************************************************************************


//***********************************************************************************************
/// <summary>
/// This is a fictitious resource. It has a problem in a time of disposition.
/// </summary>
class TroubleResource: IDisposable {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public bool IsValid
   { get { return i_bValid; } }

public TroubleResource()
   { i_bValid=true; }

public void Dispose()
{
   GC.SuppressFinalize(this);
   Dispose(true);
}

protected virtual void Dispose(bool bExplicit)
{
   if (!IsValid) return;

   i_bValid=false;

   throw new System.Runtime.InteropServices.SEHException( null,
      new System.IO.FileNotFoundException() );
}

~TroubleResource()
{
   Dispose(false);
}

bool i_bValid;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // TroubleResource
//***********************************************************************************************


//***********************************************************************************************
/// <summary>
/// This class demonstrates a problem of lost exception.
/// It also uses some tricks in order to not loose exception.
/// </summary>
static class LostExceptionChainDemo {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/// <summary>Three modes of demonstration.</summary>
public enum Mode { Plain, Advanced, AdvancedPlus }

/// <summary>Performing one of three possible ways.</summary>
static public void PerformDemonstration(Mode mode)
{
   FormMain.Instance.Update();

   using (new SysUtils.WaitCursor())
   {
      try
      {
         switch (mode)
         {
         case Mode.Plain       : PerformDemonstration_Plain();        break;
         case Mode.Advanced    : PerformDemonstration_Advanced();     break;
         case Mode.AdvancedPlus: PerformDemonstration_AdvancedPlus(); break;
         }
      }
      catch (Exception ex)
      {
         if (ex is SysUtils.MonolithicCodeViolationException)
            throw;
         SysUtils.MessageDialog.ShowError(
            ( ex.InnerException==null ? "" :
              "=== Exception chain (from primary to the last) ===\n\n" )+
            SysUtils.ExceptionMessage.ComposeChainMessage(ex,true),
            "Exception(s) caught (\"Serious Error\" exceptions are the primary)" );
      }
   }
}

/// <summary>Classic using block.</summary>
static void PerformDemonstration_Plain()
{
   using (TroubleResource tr=new TroubleResource())
   {
      ThrowSeriousExceptionChain();
   }
}

/// <summary>Using block alternative.</summary>
static void PerformDemonstration_Advanced()
{
   TroubleResource tr=new TroubleResource();
   try
   {
      ThrowSeriousExceptionChain();
   }
   catch (Exception e)
   {
      if (e is SysUtils.MonolithicCodeViolationException)
         throw;
      try
      {
         tr.Dispose();
      }
      catch (Exception x)
      {
         if (x is SysUtils.MonolithicCodeViolationException)
            throw;
         throw SysUtils.ExceptionChainCombination.Combine(x,e);
      }
      throw;
   }
   tr.Dispose();
}

/// <summary>Using block alternative implemented as anonymous function..</summary>
/// <remarks><see cref="SysUtils.AutoDispose"/> class.</remarks>
static void PerformDemonstration_AdvancedPlus()
{
   TroubleResource tr=new TroubleResource();
   SysUtils.AutoDispose.PerformUsing(tr,delegate{
      ThrowSeriousExceptionChain();
   });
}

/// <summary>
/// Throwing of some serious error as <see cref="System.ApplicationException"/>.
/// </summary>
static void ThrowSeriousExceptionChain()
{
   throw new ApplicationException( "Serious Error (subsequent).",
      new ApplicationException("Serious Error (original).") );
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // LostExceptionChainDemo
//***********************************************************************************************

} // Balance
