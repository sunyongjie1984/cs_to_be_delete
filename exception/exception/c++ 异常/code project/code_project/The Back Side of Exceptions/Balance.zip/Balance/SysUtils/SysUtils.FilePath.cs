﻿namespace SysUtils {

using System;
using System.IO;

//***********************************************************************************************
static class FilePath {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public const string WILDCARD_CHARS="*?";

//===============================================================================================

public static char[] WildcardChars
   { get { return WILDCARD_CHARS.ToCharArray(); } }

//===============================================================================================

public static bool DoesContainVolumeSeparatorChar(string strSubject)
{
   return strSubject.IndexOf(Path.VolumeSeparatorChar)>=0;
}

public static bool DoesContainDirectorySeparatorChar(string strSubject)
{
   return
      strSubject.IndexOf(Path.DirectorySeparatorChar   )>=0 ||
      strSubject.IndexOf(Path.AltDirectorySeparatorChar)>=0;
}

public static bool DoesContainPathSeparatorChar(string strSubject)
{
   return strSubject.IndexOf(Path.PathSeparator)>=0;
}

public static bool DoesContailWildcardChar(string strSubject)
{
   return strSubject.IndexOfAny(WildcardChars)>=0;
}

public static bool DoesFileContainInvalidChar(string strFileWithOfWithoutPath)
{
   return
      DoesContainInvalidFileNameChar(strFileWithOfWithoutPath) ||
      DoesContainInvalidPathChar(strFileWithOfWithoutPath);
}

public static bool DoesContainInvalidFileNameChar(string strSubject)
{
   return strSubject.IndexOfAny(Path.GetInvalidFileNameChars())>=0;
}

public static bool DoesContainInvalidPathChar(string strSubject)
{
   return strSubject.IndexOfAny(Path.GetInvalidPathChars())>=0;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // FilePath
//***********************************************************************************************

} // SysUtils
