﻿namespace SysUtils {

using System;
using System.Reflection;
using System.IO;

//***********************************************************************************************
static class RootInfo {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public static bool IsDebugVersion
{
   get
   {
   #if DEBUG
      return true;
   #else
      return false;
   #endif
   }
}

public static bool IsReleaseVersion
{
   get {
      return !IsDebugVersion;
   }
}

public static string ApplicationTitle
{
   get {
      return RuntimeParams._ApplicationTitle ?? ApplicationExeName;
   }
   set {
      RuntimeParams._ApplicationTitle=value;
   }
}

public static string ApplicationExeName
{
   get {
      return ApplicationExeModule.Name;
   }
}

public static Module ApplicationExeModule
{
   get {
      return Assembly.GetEntryAssembly().GetModules(false)[0];
   }
}

public static string ApplicationExeDir
{
   get {
      return Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
   }
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // RootInfo
//***********************************************************************************************

} // SysUtils
