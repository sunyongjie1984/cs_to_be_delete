﻿namespace SysUtils {

using System;

//***********************************************************************************************
/// <summary>
/// This exception is used to support monolichic code blocks. It is concerned as fatal.
/// </summary>
/// <remarks>
/// Every general catch block (explicit catching of <see cref="System.Exception"/>)
/// in this program rethrows exception of this type (forwarding it towards the top).
/// </remarks>
/*fatalexception*/class MonolithicCodeViolationException: Exception {
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
public MonolithicCodeViolationException(Exception innerException)
   :base( "Violation of monolithic code flow caused by unexpected exception "+
          "in a deeper level.", innerException ) {}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} // MonolithicCodeViolationException
//***********************************************************************************************

} // SysUtils
