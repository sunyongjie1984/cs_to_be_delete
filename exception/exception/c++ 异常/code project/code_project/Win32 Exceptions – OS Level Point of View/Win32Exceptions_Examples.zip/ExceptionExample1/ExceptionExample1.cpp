/***************************************************************************************************************
 *
 * Filename: ExceptionExample1.cpp
 * 
 * Author:   Miki Rozloznik
 *
 * Date:     2010/03/26
 *
 * Implementation Description:
 *//** \file 
 *   The Example 1 for the Win32 Exceptions article.
 *//*
 *
 **************************************************************************************************************/

// disable "Inline asm assigning to 'FS:0' : handler not registered as safe handler" warning
#pragma warning(disable:4733)

#include <excpt.h>
#include <windows.h>
#include <tchar.h>

BYTE Dummy = 0xFF;

extern "C" EXCEPTION_DISPOSITION __cdecl ExceptionDeclineHandler(struct _EXCEPTION_RECORD* _ExceptionRecord,
                                                                 void*                     _EstablisherFrame,
                                                                 struct _CONTEXT*          _ContextRecord,
                                                                 void*                     _DispatcherContext)
{
    OutputDebugString(_T("    ExceptionDeclineHandler is in progress...\n"));

    // tell OS that this handler declines to handle this exception
    return ExceptionContinueSearch;
}

void ExceptionMaker()
{
    OutputDebugString(_T("  Installing ExceptionDeclineHandler...\n"));
    DWORD MyHandler = reinterpret_cast<DWORD>(ExceptionDeclineHandler);
    __asm
    {
        push MyHandler      // address of Exception Callback Function to register
        push FS:[0]         // address of previous Exception Callback Function
        mov FS:[0], ESP     // register our Exception Callback Function
    }

    OutputDebugString(_T("  Trying to write something into address 0...\n"));
    __asm
    {
        mov EAX, 0          // write to EAX zero
        mov [EAX], 0xAA     // write something to zero address => access violation exception (0xC0000005)
    }

    if (Dummy == 0xAA)
        OutputDebugString(_T("  Writing address was successfully corrected.\n"));

    OutputDebugString(_T("  Uninstalling ExceptionDeclineHandler...\n"));
    __asm
    {
        mov EAX, [ESP]      // get address of previous Exception Callback Function
        mov FS:[0], EAX     // register previous Exception Callback Function
        ADD ESP, 8          // clean our record from the stack
    }
}

extern "C" EXCEPTION_DISPOSITION __cdecl ExceptionAcceptHandler(struct _EXCEPTION_RECORD* _ExceptionRecord,
                                                                void*                     _EstablisherFrame,
                                                                struct _CONTEXT*          _ContextRecord,
                                                                void*                     _DispatcherContext)
{
    OutputDebugString(_T("    ExceptionAcceptHandler is in progress...\n"));

    // correct access violation exception => change EAX to points somewhere we can successfully write
    _ContextRecord->Eax = reinterpret_cast<DWORD>(&Dummy);

    // tell OS to restart the faulting instruction
    return ExceptionContinueExecution;
}

int _tmain(int argc, _TCHAR* argv[])
{
    OutputDebugString(_T("Installing ExceptionAcceptHandler...\n"));
    DWORD MyHandler = reinterpret_cast<DWORD>(ExceptionAcceptHandler);
    __asm
    {
        push MyHandler      // address of Exception Callback Function to register
        push FS:[0]         // address of previous Exception Callback Function
        mov FS:[0], ESP     // register our Exception Callback Function
    }

    ExceptionMaker();

    OutputDebugString(_T("Uninstalling ExceptionAcceptHandler...\n"));
    __asm
    {
        mov EAX, [ESP]      // get address of previous Exception Callback Function
        mov FS:[0], EAX     // register previous Exception Callback Function
        ADD ESP, 8          // clean our record from the stack
    }

    return 0;
}
