/***************************************************************************************************************
 *
 * Filename: ExceptionExample3.cpp
 * 
 * Author:   Miki Rozloznik
 *
 * Date:     2010/03/26
 *
 * Implementation Description:
 *//** \file 
 *   The Example 3 for the Win32 Exceptions article.
 *//*
 *
 **************************************************************************************************************/

#include <windows.h>
#include <tchar.h>

class DummyClass
{
public:
    ~DummyClass()
    {
        OutputDebugString(_T("    DummyClass destructor is in progress...\n"));
    }
};

void ExceptionMaker()
{
    OutputDebugString(_T("    ExceptionMaker is in progress...\n"));

    // some class to observe destructor calling
    DummyClass Class;

    // write something to zero address => access violation exception (0xC0000005)
    *reinterpret_cast<char*>(0) = 0;
}

void ExceptionMakerCaller()
{
    OutputDebugString(_T("  ExceptionMakerCaller is in progress...\n"));

    try
    {
        ExceptionMaker();
    }
    catch (...)
    {
        OutputDebugString(_T("  catch block is in progress...\n"));
    }
}

int _tmain(int argc, _TCHAR* argv[])
{
    OutputDebugString(_T("_tmain is in progress...\n"));

    __try
    {
        ExceptionMakerCaller();
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        OutputDebugString(_T("__except block is in progress...\n"));
    }

    OutputDebugString(_T("_tmain is after __except...\n"));

    return 0;
}
