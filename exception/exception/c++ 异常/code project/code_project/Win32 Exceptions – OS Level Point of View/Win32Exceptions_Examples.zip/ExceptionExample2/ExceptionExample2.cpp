/***************************************************************************************************************
 *
 * Filename: ExceptionExample2.cpp
 * 
 * Author:   Miki Rozloznik
 *
 * Date:     2010/03/26
 *
 * Implementation Description:
 *//** \file 
 *   The Example 2 for the Win32 Exceptions article.
 *//*
 *
 **************************************************************************************************************/

#include <excpt.h>
#include <windows.h>
#include <tchar.h>

BYTE Dummy = 0xFF;

void ExceptionMaker()
{
    __try
    {
        OutputDebugString(_T("  Trying to write something into bad address...\n"));
        __asm
        {
            mov EAX, 0          // write to EAX zero
            mov [EAX], 0xAA     // write something to zero address => access violation exception (0xC0000005)
        }

        if (Dummy == 0xAA)
            OutputDebugString(_T("  Writing address was successfully corrected.\n"));
    }
    __finally
    {
        OutputDebugString(_T("  ExceptionMaker() __finally block is in progress...\n"));
    }
}

int ExceptionAcceptFilter(struct _EXCEPTION_POINTERS* _ExceptionPointers)
{
    OutputDebugString(_T("    ExceptionAcceptFilter is in progress...\n"));

    // check if we caught access voilation as expected
    if (_ExceptionPointers->ExceptionRecord->ExceptionCode == EXCEPTION_ACCESS_VIOLATION)
    {
        // if fault address iz zero, restart the faulting instruction
        if (_ExceptionPointers->ContextRecord->Eax == 0)
        {
            // correct access violation exception => change EAX to points somewhere we can successfully write
            _ExceptionPointers->ContextRecord->Eax = reinterpret_cast<DWORD>(&Dummy);

            // restart the faulting instruction
            return EXCEPTION_CONTINUE_EXECUTION;
        }
       
        // execute the exception handler otherwise
        return EXCEPTION_EXECUTE_HANDLER;
    }

    // this handler declines to handle this exception
    return EXCEPTION_CONTINUE_SEARCH;
}

int _tmain(int argc, _TCHAR* argv[])
{
    OutputDebugString(_T("_tmain is in progress...\n"));
    __try
    {
        __try
        {
            ExceptionMaker();
        }
        __finally
        {
            OutputDebugString(_T("__finally block is in progress...\n"));
        }
    }
    __except (ExceptionAcceptFilter(GetExceptionInformation()))
    {
        OutputDebugString(_T("__except block is in progress...\n"));
    }

    return 0;
}
