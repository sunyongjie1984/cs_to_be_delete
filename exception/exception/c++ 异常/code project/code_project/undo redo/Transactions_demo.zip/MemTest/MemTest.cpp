// MemTest.cpp (take two)

#include "stdafx.h"
#include "Transactions\MemManager.h"

int DoWork(int argc, char* argv[], char** envp);
int DoWork2(int argc, char* argv[], char** envp);

////////////////////////////////////////////////////////////////////////////////
// The one place you need to use ExceptionFilter is in main, WinMain or the
// main message loop of your app.  You can put the __try block anywhere so
// long as it appears above all calls to Mm::*Transaction() in the call
// stack.
//

int main(int argc, char* argv[], char** envp)
{
	int retval = 0;
	__try {
		retval += DoWork(argc, argv, envp);
		retval += DoWork2(argc, argv, envp);
	} __except(Mm::ExceptionFilter(GetExceptionInformation())) {
		printf("Oops, should never be here...\n");
	};

	return retval;
}

// Enjoy!