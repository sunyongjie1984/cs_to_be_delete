// DrawItDoc.h : interface of the CDrawItDoc class
//
#pragma once

#include <vector>
#include <deque>
#include <map>

#include "Transactions\Allocator7.h"

class CDrawItDoc : public CDocument
{
protected: // create from serialization only
	CDrawItDoc();
	DECLARE_DYNCREATE(CDrawItDoc)

// Attributes
public:	
	typedef unsigned long															ID;
	typedef unsigned long															DataItem;

	typedef unsigned int															TypeCode;
	typedef std::vector<DataItem, Mm::Allocator<DataItem> >							ObjectData;

	typedef std::pair<TypeCode, ObjectData>											ObjectRecord;

	typedef std::map<ID, POINT, std::less<ID>, Mm::Allocator<std::pair<const ID,POINT> > >				Points;
	typedef std::map<ID, ObjectRecord, std::less<ID>, Mm::Allocator<std::pair<const ID,ObjectRecord> > >	Objects;

	struct DocData {
		DocData() {}
		~DocData() {}

		Points		m_points;
		Objects		m_objects;
	};

	Mm::SPACEID sid;
	DocData* data;

// Operations
public:

// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CDrawItDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	afx_msg void OnEditUndo();
	afx_msg void OnUpdateEditUndo(CCmdUI *pCmdUI);
	afx_msg void OnEditRedo();
	afx_msg void OnUpdateEditRedo(CCmdUI *pCmdUI);
	afx_msg void OnEditOpenlongtransaction();
	afx_msg void OnUpdateEditOpenlongtransaction(CCmdUI *pCmdUI);
	afx_msg void OnEditCommittransaction();
	afx_msg void OnUpdateEditCommittransaction(CCmdUI *pCmdUI);
	afx_msg void OnEditCanceltransaction();
	afx_msg void OnUpdateEditCanceltransaction(CCmdUI *pCmdUI);

	DECLARE_MESSAGE_MAP()
};


