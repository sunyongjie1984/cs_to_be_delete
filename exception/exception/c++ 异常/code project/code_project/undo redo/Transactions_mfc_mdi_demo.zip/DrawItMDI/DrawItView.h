// DrawItView.h : interface of the CDrawItView class
//


#pragma once


class CDrawItView : public CView
{
protected: // create from serialization only
	CDrawItView();
	DECLARE_DYNCREATE(CDrawItView)

// Attributes
public:
	CDrawItDoc* GetDocument() const;

// Operations
public:

// Overrides
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CDrawItView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	unsigned int m_spec;

// Generated message map functions
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnEditAbuse();
	afx_msg void OnEditAbuse2();
	afx_msg void OnInsertCommand(UINT id);
	afx_msg void OnUpdateInsertCommand(CCmdUI* pCmdUI);
	afx_msg void OnViewDrawobjects();
	afx_msg void OnUpdateViewDrawobjects(CCmdUI *pCmdUI);
protected:
	DECLARE_MESSAGE_MAP()
private:
	bool m_bDrawItems;
	unsigned long m_openMouseTransaction;
	unsigned long m_idCreating;
};

#ifndef _DEBUG  // debug version in DrawItView.cpp
inline CDrawItDoc* CDrawItView::GetDocument() const
   { return reinterpret_cast<CDrawItDoc*>(m_pDocument); }
#endif

