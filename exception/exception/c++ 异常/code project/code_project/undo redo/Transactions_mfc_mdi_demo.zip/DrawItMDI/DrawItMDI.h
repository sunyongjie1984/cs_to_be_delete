// DrawItMDI.h : main header file for the DrawItMDI application
//
#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols


/////////////////////////////////////////////////////////////////////////////

#include "..\DrawIt\DrawItAPI.h"

typedef std::map<unsigned char, CLIENTCALLBACKS>	DrawFunctionMap;
extern DrawFunctionMap g_drawFunctions;

// CDrawItApp:
// See DrawItMDI.cpp for the implementation of this class
//

class CDrawItApp : public CWinApp
{
public:
	CDrawItApp();

// Overrides
public:
	virtual BOOL InitInstance();
	virtual BOOL DoInit();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
	virtual int Run();
	virtual int ExitInstance();
};

extern CDrawItApp theApp;