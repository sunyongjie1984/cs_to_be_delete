#ifndef COMPRESS_H_INCLUDED
#define COMPRESS_H_INCLUDED

namespace Mm {
	int Compress(void* in, void* out);
	int Decompress(void* in, void* out);

	int ApplyCompressedDelta(void* page, void* delta);
};

#endif // COMPRESS_H_INCLUDED