// DPHullGL.cpp: implementation of the CDPHullGL class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DPHullGL.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDPHullGL::CDPHullGL()
{

}

CDPHullGL::~CDPHullGL()
{

}

void CDPHullGL::PlotCurve()
{
	int i;
	glBegin(GL_LINE_STRIP);
	for (i=0;i<m_iN;i++)
	{
		glVertex2f((GLfloat)m_pV[i][DP_XX],(GLfloat)m_pV[i][DP_YY]);
	}
	glEnd();
}

void CDPHullGL::PlotDPCurve()
{
	int i;
	glBegin(GL_LINE_STRIP);
	for (i=0;i<m_iNumResult;i++)
	{
		glVertex2f((GLfloat)(*m_ppR[i])[DP_XX],(GLfloat)(*m_ppR[i])[DP_YY]);
	}
	glEnd();
}

