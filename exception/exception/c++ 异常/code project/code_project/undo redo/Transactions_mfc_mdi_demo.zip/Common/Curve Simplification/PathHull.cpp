// PathHull.cpp: implementation of the CPathHull class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PathHull.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPathHull::CPathHull()
{
	m_iHullMax=0;
	m_pOp=NULL;
	m_ppElt=NULL;
	m_ppHelt=NULL;
	
}

CPathHull::~CPathHull()
{
	if (m_pOp)
		delete[] m_pOp;
	if (m_ppElt)
		delete[] m_ppElt;
	if (m_ppHelt)
		delete[] m_ppHelt;
	
}

void CPathHull::Split(DP_POINT *e)
{
	DP_POINT *tmpe;
	int tmpo;
	
	while ((m_iHp >= 0) 
		&& ((tmpo = m_pOp[m_iHp]), 
		((tmpe = m_ppHelt[m_iHp]) != e) || (tmpo != DP_PUSH_OP)))
    {
		m_iHp--;
		switch (tmpo)
		{
		case DP_PUSH_OP:
			m_iTop--;
			m_iBot++;
			break;
		case DP_TOP_OP:
			m_ppElt[++m_iTop] = tmpe;
			break;
		case DP_BOT_OP:
			m_ppElt[--m_iBot] = tmpe;
			break;
		}
    }
}

void CPathHull::FindExtreme(DP_HOMOG line, DP_POINT **e, double *dist)
{
	int 
		sbase, sbrk, mid,
		lo, m1, brk, m2, hi;
	double d1, d2;
	
	if ((m_iTop - m_iBot) > 8) 
    {
		lo = m_iBot; hi = m_iTop - 1;
		sbase = SlopeSign(hi, lo, line);
		do
		{
			brk = (lo + hi) / 2;
			if (sbase == (sbrk = SlopeSign(brk, brk+1, line)))
				if (sbase == (SlopeSign(lo, brk+1, line)))
					lo = brk + 1;
				else
					hi = brk;
		}
		while (sbase == sbrk);
		
		m1 = brk;
		while (lo < m1)
		{
			mid = (lo + m1) / 2;
			if (sbase == (SlopeSign(mid, mid+1, line)))
				lo = mid + 1;
			else
				m1 = mid;
		}
		
		m2 = brk;
		while (m2 < hi) 
		{
			mid = (m2 + hi) / 2;
			if (sbase == (SlopeSign(mid, mid+1, line)))
				hi = mid;
			else
				m2 = mid + 1;
		}
		
		if ((d1 = DP_DOTPROD_2CH(*m_ppElt[lo], line)) < 0) d1 = - d1;
		if ((d2 = DP_DOTPROD_2CH(*m_ppElt[m2], line)) < 0) d2 = - d2;
		*dist = (d1 > d2 ? (*e = m_ppElt[lo], d1) : (*e = m_ppElt[m2], d2));
    }
	else				/* Few DP_POINTs in hull */
    {
		*dist = 0.0;
		for (mid = m_iBot; mid < m_iTop; mid++)
		{
			
			if ((d1 = DP_DOTPROD_2CH(*m_ppElt[mid], line)) < 0) d1 = - d1;
			if (d1 > *dist)
			{
				*dist = d1;
				*e = m_ppElt[mid];
			}
		}
    }
}

void CPathHull::Add(DP_POINT *p)
{
	int topflag, botflag;
	
	topflag = LeftOfTop(p);
	botflag = LeftOfBot(p);
	
	if (topflag || botflag)
    {
		while (topflag)
		{
			PopTop();
			topflag = LeftOfTop(p);
		}
		while (botflag)
		{
			PopBot();
			botflag = LeftOfBot(p);
		}
		Push(p);
    }
}

void CPathHull::SetMaxSize(int iHullMax)
{
	m_iHullMax=iHullMax;
	
	// deleting vector if existing
	if (m_pOp)
		delete[] m_pOp;
	if (m_ppElt)
		delete[] m_ppElt;
	if (m_ppHelt)
		delete[] m_ppHelt;
	
	// allocating memory	
	m_pOp=new int[3*m_iHullMax];
	m_ppElt=new DP_POINT*[2*m_iHullMax];
	m_ppHelt=new DP_POINT*[3*m_iHullMax];	
}
