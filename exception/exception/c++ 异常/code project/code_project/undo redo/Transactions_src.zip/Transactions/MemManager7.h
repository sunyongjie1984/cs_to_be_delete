#ifndef MEM_MANAGER_H_INCLUDED
#define MEM_MANAGER_H_INCLUDED

#include "Utilities\Result.h"

namespace Mm
{
	// types
	typedef unsigned long TXNID;
	typedef unsigned long SPACEID;

	// setup
	bool InstallExceptionFilter();
	bool RemoveExceptionFilter();
	int ExceptionFilter(void* e);

	// space (heap) managment
	Result	InitSpaceZero(); // read the documentation

	SPACEID CreateSpace(size_t initial_size);
	Result	Destroy(SPACEID sid);
	Result 	Clear(SPACEID sid);

	Result ClearAll();

	// transactions
	Result OpenTransaction(SPACEID sid);
	Result CancelTransaction(SPACEID sid);
	Result CommitTransaction(SPACEID sid);

	TXNID  GetLastTransactionId(SPACEID sid);
	TXNID  GetNextTransactionId(SPACEID sid);
	TXNID  GetOpenTransactionId(SPACEID sid);

	Result Undo(SPACEID sid);
	Result Redo(SPACEID sid);

	Result TruncateUndo(SPACEID sid);
	Result TruncateRedo(SPACEID sid);

	// allocation
	void* Allocate(size_t size, SPACEID sid);
	void* Allocate(void* hint, size_t size); // does space lookup, slower, used by Mm::Allocator
	
	void  Deallocate(void* p); // does space lookup, slower
	void  Deallocate(void* p, SPACEID sid);
	void  Deallocate(void* p, size_t size); // used by Mm::Allocator
	
	void* Reallocate(void* p, size_t size); // don't pass null p
	void* Reallocate(void* p, size_t size, SPACEID sid); // null p pkay

	// debug
	size_t FreeSpace(SPACEID sid);
	size_t FreeCount(SPACEID sid);

//	void DumpStats(std::ostream& o);

	class AutoTransaction {
	private:
		AutoTransaction(const AutoTransaction& );
		operator=(const AutoTransaction&);

	public:
		AutoTransaction(SPACEID s) : sid(s), txnid(NULL), cancel(false) 
		{ 
			if (Mm::GetOpenTransactionId(sid) == NULL && !Mm::OpenTransaction(sid).IsError()) 
				txnid = Mm::GetOpenTransactionId(sid); 
		}
		
		~AutoTransaction()
		{
			if (txnid == NULL) return;
			if (txnid != Mm::GetOpenTransactionId(sid)) throw;

			if (cancel) Mm::CancelTransaction(sid);
			else Mm::CommitTransaction(sid);
		}

		Mm::SPACEID sid;
		Mm::TXNID txnid;
		bool cancel;
	};
};

#endif //
