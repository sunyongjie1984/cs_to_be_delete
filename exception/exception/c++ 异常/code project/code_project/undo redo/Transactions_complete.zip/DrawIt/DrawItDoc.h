// DrawItDoc.h : interface of the CDrawItDoc class
//
/////////////////////////////////////////////////////////////////////////////

#include <vector>
#include <deque>
#include <map>

#include "Transactions\Allocator7.h"

#if !defined(AFX_DRAWITDOC_H__8880F8C5_5940_40B3_82D3_83D56185FA34__INCLUDED_)
#define AFX_DRAWITDOC_H__8880F8C5_5940_40B3_82D3_83D56185FA34__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CDrawItDoc : public CDocument
{
protected: // create from serialization only
	CDrawItDoc();
	DECLARE_DYNCREATE(CDrawItDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDrawItDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDrawItDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	typedef unsigned long															ID;
	typedef unsigned long															DataItem;

	typedef unsigned int															TypeCode;
	typedef std::vector<DataItem, Mm::Allocator<DataItem> >							ObjectData;

	typedef std::pair<TypeCode, ObjectData>											ObjectRecord;

	typedef std::map<ID, POINT, std::less<ID>, Mm::Allocator<std::pair<const ID,POINT> > >				Points;
	typedef std::map<ID, ObjectRecord, std::less<ID>, Mm::Allocator<std::pair<const ID,ObjectRecord> > >	Objects;

	struct DocData {
		DocData() {}
		~DocData() {}

		Points		m_points;
		Objects		m_objects;
	};

	Mm::SPACEID sid;
	DocData* data;

// Generated message map functions
protected:
	//{{AFX_MSG(CDrawItDoc)
	afx_msg void OnEditUndo();
	afx_msg void OnUpdateEditUndo(CCmdUI *pCmdUI);
	afx_msg void OnEditRedo();
	afx_msg void OnUpdateEditRedo(CCmdUI *pCmdUI);
	afx_msg void OnEditOpenlongtransaction();
	afx_msg void OnUpdateEditOpenlongtransaction(CCmdUI *pCmdUI);
	afx_msg void OnEditCommittransaction();
	afx_msg void OnUpdateEditCommittransaction(CCmdUI *pCmdUI);
	afx_msg void OnEditCanceltransaction();
	afx_msg void OnUpdateEditCanceltransaction(CCmdUI *pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DRAWITDOC_H__8880F8C5_5940_40B3_82D3_83D56185FA34__INCLUDED_)
