#pragma once

#include <vector>
#include <map>

// Client API: Dlls are dynamically loaded and searched for a function with 
// the name indicated in 'lpzDrawDLLInit'.  That function must be implemented
// with the signature PFNDLLINIT: 
//
// bool DrawDllInit(PFNADDDRAWCALLBACKS fnAddCB);
//
// The client dll should call fnAddCB once for each draw code it supports and pass
// pointers to the functions that implement create/draw for the code.  The returned
// draw code should be stored to later identify how to draw specific objects
//

class DrawItAPI {
public:
	virtual unsigned long AddPoint(const POINT* where) = 0;  // creates a point, returns index
	virtual void SetPoint(unsigned long id, const POINT* where) = 0;
	virtual const POINT* GetPoint(unsigned long id) = 0;
	virtual void RemovePoint(unsigned long id) = 0;
	
	virtual unsigned long AddData(unsigned long data) = 0; // adds data to object, returns index
	virtual void SetData(unsigned long id, unsigned long data) = 0;
	virtual void ResizeData(unsigned int count) = 0;
};

typedef struct DRAWDATA {
	unsigned long*	data;
	unsigned long	count_data;
} _DRAWDATA; 

typedef void (*PFNCREATE)(DrawItAPI* api, const POINT* mouse, const DRAWDATA* data);
typedef void (*PFNCOMPLETE)(DrawItAPI* api, const DRAWDATA* data);
typedef void (*PFNDRAW)(DrawItAPI* api, HDC dc, const DRAWDATA* data);

typedef struct CLIENTCALLBACKS {
	PFNCREATE	create;
	PFNCOMPLETE	complete;
	PFNDRAW		draw;
} _CLIENTCALLBACKS;

// DrawIt host API
typedef unsigned int (*PFNADDCLIENTCALLBACKS)(const CLIENTCALLBACKS* cb);

static const char* lpzDrawDLLInit = "DrawDllInit";
typedef bool (*PFNDLLINIT)(PFNADDCLIENTCALLBACKS fnAddCB);
