// DrawItView.h : interface of the CDrawItView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DRAWITVIEW_H__AEB557EF_0CD7_42C6_B6B6_71D9BD0BA517__INCLUDED_)
#define AFX_DRAWITVIEW_H__AEB557EF_0CD7_42C6_B6B6_71D9BD0BA517__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CDrawItView : public CView
{
protected: // create from serialization only
	CDrawItView();
	DECLARE_DYNCREATE(CDrawItView)

// Attributes
public:
	CDrawItDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDrawItView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDrawItView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	unsigned int m_spec;

// Generated message map functions
protected:
	//{{AFX_MSG(CDrawItView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnEditAbuse();
	afx_msg void OnEditAbuse2();
	afx_msg void OnInsertCommand(UINT id);
	afx_msg void OnUpdateInsertCommand(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnViewDrawobjects();
private:
	bool m_bDrawItems;
	unsigned long m_openMouseTransaction;
	unsigned long m_idCreating;

public:
	afx_msg void OnUpdateViewDrawobjects(CCmdUI *pCmdUI);
//	afx_msg void OnUpdateEditUndo(CCmdUI *pCmdUI);
};

#ifndef _DEBUG  // debug version in DrawItView.cpp
inline CDrawItDoc* CDrawItView::GetDocument()
   { return (CDrawItDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DRAWITVIEW_H__AEB557EF_0CD7_42C6_B6B6_71D9BD0BA517__INCLUDED_)
