// Types.h
//
// TrackMouse Demo Platform for BeOS
// Copyright 1999, Matter and Motion, Inc. All rights reserved.

#ifndef TYPES_H_INCLUDED
#define TYPES_H_INCLUDED

typedef unsigned int uint32;

#endif // TYPES_H_INCLUDED
