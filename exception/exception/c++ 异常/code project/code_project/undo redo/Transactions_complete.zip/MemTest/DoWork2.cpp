#include "stdafx.h"

int DoWork2(int argc, char* argv[], char** envp)
{
	
	return 0;
}
