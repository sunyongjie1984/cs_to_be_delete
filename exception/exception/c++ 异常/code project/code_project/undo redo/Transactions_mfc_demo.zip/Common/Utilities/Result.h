#pragma once

#define MAKE_OK_RESULT(f,c) ((Mm::Result::eOk << Mm::Result::SeverityShift) | (f << Mm::Result::FacilityShift) | (c << Mm::Result::CodeShift))
#define MAKE_ERROR_RESULT(f,c) ((Mm::Result::eError << Mm::Result::SeverityShift) | (f << Mm::Result::FacilityShift) | (c << Mm::Result::CodeShift))
#define MAKE_WARNING_RESULT(f,c) ((Mm::Result::eWarning << Mm::Result::SeverityShift) | (f << Mm::Result::FacilityShift) | (c << Mm::Result::CodeShift))
#define MAKE_STRING_TOKEN(f,c) ((Mm::Result::eMessage << Mm::Result::SeverityShift) | (f << Mm::Result::FacilityShift) | (c << Mm::Result::CodeShift))

#include "Types.h"
#include <string>

namespace Mm
{
	typedef uint32 StringToken;
	typedef uint32 FacilityToken;

	struct Result
	{
		enum { 
			SeverityWidth	= 2,
			FacilityWidth	= 10,
			CodeWidth 	= 20,

			SeverityMax	= (1 << SeverityWidth) - 1,
			FacilityMax	= (1 << FacilityWidth) - 1,
			CodeMax		= (1 << CodeWidth) - 1,

			SeverityShift	= 0,
			FacilityShift	= SeverityWidth,
			CodeShift	= SeverityWidth + FacilityWidth,
			
			SeverifyMask	= (0xffffffff & (SeverityMax << SeverityShift)),
			FacilityMask	= (0xffffffff & (FacilityMax << FacilityShift)),
			CodeMask	= (0xffffffff & (CodeMax << CodeShift))
		};

		typedef enum {
			eError		= 0,
			eOk			= 1,
			eWarning	= 2,
			eMessage	= 3
		} ESeverityFlag;

		explicit Result(uint32 r) : raw(r)
		{}

		Result(ESeverityFlag s, uint32 t) 
			:	severity(s), 
				token(t)
		{}

		Result(ESeverityFlag s, uint32 f, uint32 c) 
			:	severity(s), 
				facility(f), 
				code(c)
		{}

		Result(const Result& r)
			:	raw(r.raw)
		{}

		union {
			uint32 raw;
			struct {
				ESeverityFlag	severity	: SeverityWidth;
				uint32			facility	: FacilityWidth;
				uint32			code		: CodeWidth;
			};
			struct {
				uint32			_dummy		: SeverityWidth; // anon
				uint32			token		: FacilityWidth + CodeWidth;
			};
		};

		bool IsOk() const			{ return (severity == eOk); }
		bool IsError() const		{ return (severity == eError); }
		bool IsWarning() const		{ return (severity == eWarning); }
		bool IsMessage() const		{ return (severity == eMessage); }

		bool operator==(const Result& rhs) const	{ return (severity == rhs.severity && facility == rhs.facility && code == rhs.code); }
		bool operator!=(const Result& rhs) const	{ return !(*this == rhs); }

		bool operator<(const Result& rhs) const	{ return (raw < rhs.raw); }

		Result GetString(std::string& str); 
		Result GetFacilityName(std::string& name);
	};
};
