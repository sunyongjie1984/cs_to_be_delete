// DPHullGL.h: interface for the CDPHullGL class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DPHULLGL_H__CC98539B_1112_42CF_9E10_C31D46DA9771__INCLUDED_)
#define AFX_DPHULLGL_H__CC98539B_1112_42CF_9E10_C31D46DA9771__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DPHull.h"

class CDPHullGL : public CDPHull  
{
public:
	CDPHullGL();
	virtual ~CDPHullGL();

	void PlotCurve();
	void PlotDPCurve();
};

#endif // !defined(AFX_DPHULLGL_H__CC98539B_1112_42CF_9E10_C31D46DA9771__INCLUDED_)
