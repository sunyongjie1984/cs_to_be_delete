// DPHull1.cpp: implementation of the CDPHull class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PathHull.h"
#include "DPHull.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDPHull::CDPHull()
{
	m_ppR=NULL;
	m_pV=NULL;
	m_dEpsilonSQ=0.5;
}

CDPHull::~CDPHull()
{
	if (m_ppR)
		delete[] m_ppR;
}

void CDPHull::SetCurve(int iN,DP_POINT* pV)
{	
	m_iN=iN; m_pV=pV;

	// clearing memory
	if (m_ppR)
		delete[] m_ppR;

	// allocating memory for solution
	m_ppR = new DP_POINT *[m_iN];

	// setting up hulls
	m_phLeft.SetMaxSize(m_iN+1);
	m_phRight.SetMaxSize(m_iN+1);
}


void CDPHull::Build(DP_POINT *i, DP_POINT *j)
{
	DP_POINT *k;
	int topflag, botflag;
	
	m_pPHtag = i + (j - i) / 2;	/* Assign tag vertex */
	
	
	m_phLeft.Init(m_pPHtag, m_pPHtag - 1); /* \va{left} hull */
	for (k = m_pPHtag - 2; k >= i; k--)
    {
		topflag = m_phLeft.LeftOfTop(k);
		botflag = m_phLeft.LeftOfBot(k);
		if ((topflag || botflag) && !(topflag && botflag))
		{
			while (topflag)
			{
				m_phLeft.PopTop();
				topflag = m_phLeft.LeftOfTop(k);
			}
			while (botflag)
			{
				m_phLeft.PopBot();
				botflag = m_phLeft.LeftOfBot(k);
			}
			m_phLeft.Push(k);
		}
    }

	m_phRight.Init(m_pPHtag, m_pPHtag + 1); /* \va{right} hull */
	for (k = m_pPHtag + 2; k <= j; k++)
    {
		topflag = m_phRight.LeftOfTop(k);
		botflag = m_phRight.LeftOfBot(k);
		if ((topflag || botflag) && !(topflag && botflag))
		{
			while (topflag)
			{
				m_phRight.PopTop();
				topflag = m_phRight.LeftOfTop(k);
			}
			while (botflag)
			{
				m_phRight.PopBot();
				botflag = m_phRight.LeftOfBot(k);
			}
			m_phRight.Push(k);
		}
    }
}

DP_POINT* CDPHull::DP(DP_POINT* i, DP_POINT* j)
{
	static double ld, rd, len_sq;
	static DP_HOMOG l;
	register DP_POINT *le, *re;
	
	DP_CROSSPROD_2CCH(*i, *j, l);
	len_sq = l[DP_XX] * l[DP_XX] + l[DP_YY] * l[DP_YY];
	
	if (j - i < 8)
    {		/* chain small */
		rd  = 0.0;
		for (le = i + 1; le < j; le++)
		{
			ld = DP_DOTPROD_2CH(*le, l);
			if (ld < 0) ld = - ld;
			if (ld > rd) 
			{
				rd = ld;
				re = le;
			}
		}
		if (rd * rd > m_dEpsilonSQ * len_sq)
		{
			OutputVertex(DP(i, re)); 
			return(DP(re, j));
		}
		else
			return(j);
    }
	else
    {				/* chain large */
		int sbase, sbrk, mid, lo, m1, brk, m2, hi;
		double d1, d2;
		if ((m_phLeft.GetTop() - m_phLeft.GetBot()) > 8) 
		{
			/* left hull large */
			lo = m_phLeft.GetBot(); 
			hi = m_phLeft.GetTop() - 1;
			sbase = m_phLeft.SlopeSign(hi, lo, l);
			do
			{
				brk = (lo + hi) / 2;
				if (sbase == (sbrk = m_phLeft.SlopeSign(brk, brk+1, l)))
					if (sbase == (m_phLeft.SlopeSign(lo, brk+1, l)))
						lo = brk + 1;
					else
						hi = brk;
			}
			while (sbase == sbrk);
			
			m1 = brk;
			while (lo < m1)
			{
				mid = (lo + m1) / 2;
				if (sbase == (m_phLeft.SlopeSign(mid, mid+1, l)))
					lo = mid + 1;
				else
					m1 = mid;
			}
			
			m2 = brk;
			while (m2 < hi) 
			{
				mid = (m2 + hi) / 2;
				if (sbase == (m_phLeft.SlopeSign(mid, mid+1, l)))
					hi = mid;
				else
					m2 = mid + 1;
			};
			
			
			if ((d1 = DP_DOTPROD_2CH(*m_phLeft.GetpElt(lo), l)) < 0) d1 = - d1;
			if ((d2 = DP_DOTPROD_2CH(*m_phLeft.GetpElt(m2), l)) < 0) d2 = - d2;
			ld = (d1 > d2 ? (le = m_phLeft.GetpElt(lo), d1) : (le = m_phLeft.GetpElt(m2), d2));
		}
		else
		{			/* Few DP_POINTs in left hull */
			ld = 0.0;
			for (mid = m_phLeft.GetBot(); mid < m_phLeft.GetTop(); mid++)
			{
				if ((d1 = DP_DOTPROD_2CH(*m_phLeft.GetpElt(mid), l)) < 0) d1 = - d1;
				if (d1 > ld)
				{
					ld = d1;
					le = m_phLeft.GetpElt(mid);
				}
			}
		}
		
		if ((m_phRight.GetTop() - m_phRight.GetBot()) > 8)
		{			/* right hull large */
			lo = m_phRight.GetBot(); hi = m_phRight.GetTop() - 1;
			sbase = m_phRight.SlopeSign(hi, lo, l);
			do
			{
				brk = (lo + hi) / 2;
				if (sbase == (sbrk = m_phRight.SlopeSign(brk, brk+1, l)))
					if (sbase == (m_phRight.SlopeSign(lo, brk+1, l)))
						lo = brk + 1;
					else
						hi = brk;
			}
			while (sbase == sbrk);
			
			m1 = brk;
			while (lo < m1)
			{
				mid = (lo + m1) / 2;
				if (sbase == (m_phRight.SlopeSign(mid, mid+1, l)))
					lo = mid + 1;
				else
					m1 = mid;
			}
			
			m2 = brk;
			while (m2 < hi) 
			{
				mid = (m2 + hi) / 2;
				if (sbase == (m_phRight.SlopeSign(mid, mid+1, l)))
					hi = mid;
				else
					m2 = mid + 1;
			};
					
			if ((d1 = DP_DOTPROD_2CH(*m_phRight.GetpElt(lo), l)) < 0) d1 = - d1;
			if ((d2 = DP_DOTPROD_2CH(*m_phRight.GetpElt(m2), l)) < 0) d2 = - d2;
			rd = (d1 > d2 ? (re = m_phRight.GetpElt(lo), d1) : (re = m_phRight.GetpElt(m2), d2));
		}
		else
		{			/* Few DP_POINTs in righthull */
			rd = 0.0;
			for (mid = m_phRight.GetBot(); mid < m_phRight.GetTop(); mid++)
			{
				if ((d1 = DP_DOTPROD_2CH(*m_phRight.GetpElt(mid), l)) < 0) d1 = - d1;
				if (d1 > rd)
				{
					rd = d1;
					re = m_phRight.GetpElt(mid);
				}
			}
		}
    }
	
	
	if (ld > rd)
		if (ld * ld > m_dEpsilonSQ * len_sq)
		{				/* split left */
			register int tmpo; 
			
			while ((m_phLeft.GetHp() >= 0) 
				&& ( (tmpo = m_phLeft.GetpOp()[m_phLeft.GetHp()] ), 
				((re = m_phLeft.GetpHelt(m_phLeft.GetHp())) != le) || (tmpo != DP_PUSH_OP)))
			{
				m_phLeft.DownHp();
				switch (tmpo)
				{
				case DP_PUSH_OP:
					m_phLeft.DownTop();
					m_phLeft.UpBot();
					break;
				case DP_TOP_OP:
					m_phLeft.UpTop();
					m_phLeft.SetTopElt(re);
					break;
				case DP_BOT_OP:
					m_phLeft.DownBot();
					m_phLeft.SetBotElt(re);
					break;
				}
			}
			
			Build(i, le);
			OutputVertex(DP(i, le));
			Build(le, j);
			return DP(le, j);
		}
		else
			return(j);
		else				/* extreme on right */
			if (rd * rd > m_dEpsilonSQ * len_sq)
			{				/* split right or both */
				if (m_pPHtag == re)
					Build(i, re);
				else
				{			/* split right */
					register int tmpo;
					
					while ((m_phRight.GetHp() >= 0) 
						&& ((tmpo = m_phRight.GetpOp()[m_phRight.GetHp()]), 
						((le = m_phRight.GetpHelt(m_phRight.GetHp())) != re) || (tmpo != DP_PUSH_OP)))
					{
						m_phRight.DownHp();
						switch (tmpo)
						{
						case DP_PUSH_OP:
							m_phRight.DownTop();
							m_phRight.UpBot();
							break;
						case DP_TOP_OP:
							m_phRight.UpTop();
							m_phRight.SetTopElt(le);
							break;
						case DP_BOT_OP:
							m_phRight.DownBot();
							m_phRight.SetBotElt(le);
							break;
						}
					}
				}
				OutputVertex(DP(i, re));
				Build(re, j);
				return(DP(re, j));
			}
			else
				return(j);	
}


void CDPHull::Approximate()
{
	m_iNumResult = 0;

	Build(m_pV, m_pV + m_iN - 1);	/* Build the initial path hull */

	OutputVertex(m_pV);
	OutputVertex( DP(m_pV, m_pV + m_iN - 1) ); /* Simplify */

	// sort result
	
}

	
/// rewritte solution on base vector
void CDPHull::InjectDPInOriginal()
{
	int i;

	for (i = 0; i < m_iNumResult; i++)
	{
		m_pV[i][DP_XX]=(*(m_ppR[i]))[DP_XX];
		m_pV[i][DP_YY]=(*(m_ppR[i]))[DP_YY];	
	}
}

/// allocate new memory for solution
DP_POINT* CDPHull::GetNewDPCurve()
{
	int i;
	DP_POINT* pNewV=new DP_POINT[m_iNumResult];

	for (i = 0; i < m_iNumResult; i++)
	{
		pNewV[i][DP_XX]=(*(m_ppR[i]))[DP_XX];
		pNewV[i][DP_YY]=(*(m_ppR[i]))[DP_YY];	
	}

	return pNewV;
}

void CDPHull::PrintResult()
{
	int i;
	
	printf("DP Curve : %d points\n", m_iNumResult);
	for (i = 0; i < m_iNumResult; i++)
		printf("%d: %.4f %.4f \n", i, (*(m_ppR[i]))[DP_XX], (*(m_ppR[i]))[DP_YY]);	/**/
}
