// DrawIt.h : main header file for the DRAWIT application
//

#if !defined(AFX_DRAWIT_H__2BB93DB3_39DA_448F_A823_7CB488B9A8FF__INCLUDED_)
#define AFX_DRAWIT_H__2BB93DB3_39DA_448F_A823_7CB488B9A8FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDrawItApp:
// See DrawIt.cpp for the implementation of this class
//

class CDrawItApp : public CWinApp
{
public:
	CDrawItApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDrawItApp)
	public:
	virtual BOOL InitInstance();
	virtual int Run();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CDrawItApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
protected:
	virtual BOOL DoInit();
public:
private:
	void UpdateAllDocViews(void);
};

/////////////////////////////////////////////////////////////////////////////

#include "DrawItAPI.h"

typedef std::map<unsigned char, CLIENTCALLBACKS>	DrawFunctionMap;
extern DrawFunctionMap g_drawFunctions;

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DRAWIT_H__2BB93DB3_39DA_448F_A823_7CB488B9A8FF__INCLUDED_)
