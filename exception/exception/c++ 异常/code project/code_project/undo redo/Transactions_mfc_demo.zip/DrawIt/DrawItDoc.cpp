// DrawItDoc.cpp : implementation of the CDrawItDoc class
//

#include "stdafx.h"
#pragma warning (disable:4786)
#include "DrawIt.h"

#include "DrawItDoc.h"

/*
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
*/

/////////////////////////////////////////////////////////////////////////////
// CDrawItDoc

IMPLEMENT_DYNCREATE(CDrawItDoc, CDocument)

BEGIN_MESSAGE_MAP(CDrawItDoc, CDocument)
	//{{AFX_MSG_MAP(CDrawItDoc)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateEditUndo)
	ON_COMMAND(ID_EDIT_REDO, OnEditRedo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REDO, OnUpdateEditRedo)
	ON_COMMAND(ID_EDIT_OPENLONGTRANSACTION, OnEditOpenlongtransaction)
	ON_UPDATE_COMMAND_UI(ID_EDIT_OPENLONGTRANSACTION, OnUpdateEditOpenlongtransaction)
	ON_COMMAND(ID_EDIT_COMMITTRANSACTION, OnEditCommittransaction)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COMMITTRANSACTION, OnUpdateEditCommittransaction)
	ON_COMMAND(ID_EDIT_CANCELTRANSACTION, OnEditCanceltransaction)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CANCELTRANSACTION, OnUpdateEditCanceltransaction)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDrawItDoc construction/destruction

CDrawItDoc::CDrawItDoc()
: data(NULL), sid(0)
{
}

CDrawItDoc::~CDrawItDoc()
{
	Mm::Clear(sid);
}

BOOL CDrawItDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// dump all managed memory and reset the undo stack
	if (sid) Mm::Destroy(sid);
	sid = Mm::CreateSpace(sizeof(DocData));

	Mm::OpenTransaction(sid);
//  Destroy() released this memory already, no need to delete it
//	if (data) delete data;
	data = new(Mm::Allocate(sizeof(DocData), sid)) DocData();
	Mm::CommitTransaction(sid);
	Mm::TruncateUndo(sid);

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CDrawItDoc serialization

void CDrawItDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDrawItDoc diagnostics

#ifdef _DEBUG
void CDrawItDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDrawItDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDrawItDoc commands

void CDrawItDoc::OnEditUndo() 
{
	if (Mm::Undo(sid).IsOk()) {
		UpdateAllViews(NULL);
	}
}

void CDrawItDoc::OnEditRedo() 
{
	if (Mm::Redo(sid).IsOk()) {
		UpdateAllViews(NULL);
	}
}

void CDrawItDoc::OnUpdateEditRedo(CCmdUI *pCmdUI)
{
	BOOL enable = (sid != 0 && Mm::GetNextTransactionId(sid) != 0 && Mm::GetOpenTransactionId(sid) == 0);
	CString text;
	if (enable) {
		text.Format("Redo Txn %d\tCtrl+Y", Mm::GetNextTransactionId(sid));
	} else {
		text = "Can't Redo";
	}
	pCmdUI->Enable(enable);
	pCmdUI->SetText(text);
}

void CDrawItDoc::OnUpdateEditUndo(CCmdUI *pCmdUI)
{
	BOOL enable = (sid != 0 && Mm::GetLastTransactionId(sid) != 0 && Mm::GetOpenTransactionId(sid) == 0);
	CString text;
	if (enable) {
		text.Format("Undo Txn %d\tCtrl+Z", Mm::GetLastTransactionId(sid));
	} else {
		text = "Can't Undo";
	}
	pCmdUI->Enable(enable);
	pCmdUI->SetText(text);
}


void CDrawItDoc::OnEditOpenlongtransaction()
{
	if (sid != 0 && Mm::OpenTransaction(sid).IsOk()) {
		UpdateAllViews(NULL);
	}
}

void CDrawItDoc::OnUpdateEditOpenlongtransaction(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(sid != 0 && Mm::GetOpenTransactionId(sid) == 0 ? TRUE : FALSE);
}

void CDrawItDoc::OnEditCommittransaction()
{
	if (sid != 0 && Mm::CommitTransaction(sid).IsOk()) {
		UpdateAllViews(NULL);
	}
}

void CDrawItDoc::OnUpdateEditCommittransaction(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(sid != 0 && Mm::GetOpenTransactionId(sid) == 0 ? FALSE : TRUE);
}

void CDrawItDoc::OnEditCanceltransaction()
{
	if (sid != 0 && Mm::CancelTransaction(sid).IsOk()) {
		UpdateAllViews(NULL);
	}
}

void CDrawItDoc::OnUpdateEditCanceltransaction(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(sid != 0 && Mm::GetOpenTransactionId(sid) == 0 ? FALSE : TRUE);
}

