extern "C"
{
#include <ntddk.h>
};

#pragma warning (disable: 4731) // EBP register overwritten
#pragma warning (disable: 4733) // non-SAFESEH compliant

typedef void (__stdcall* CleanupFN)();

struct CleanupEntry
{
    long		m_nPrevIdx;
    CleanupFN	m_pfnCleanup;
};

struct UnwindFrame
{
    ULONG			m_sig;
    long			m_nCleanupCount;   //number of entries in unwindtable
    CleanupEntry*	m_pCleanupArr;
	// C++ try-catch data is omitted
};

struct ExcReg
{ 
    ExcReg*	m_pPrev;
    ULONG	m_handler;
    long	m_NextCleanup;
    ULONG	m_ebp;
};

void FrameUnwind(UnwindFrame* pUFrame, ULONG dwEbp, ExcReg* pExcFrame)
{
    const CleanupEntry* pCleanupArr = pUFrame->m_pCleanupArr;
    int count = pUFrame->m_nCleanupCount;

	ASSERT(pExcFrame->m_NextCleanup < pUFrame->m_nCleanupCount); // stack corruption test

	while (true)
	{
		long nNextID = pExcFrame->m_NextCleanup;
		if (nNextID < 0)
			break;

		const CleanupEntry& entry = pCleanupArr[nNextID];
		CleanupFN pfnCleanup = entry.m_pfnCleanup;
		pExcFrame->m_NextCleanup = entry.m_nPrevIdx;

		__try {
			_asm
			{
				mov EAX, pfnCleanup
				push EBP       //save current EBP
				mov EBP, dwEbp  //the EBP of the unwinding function
				call EAX
				pop EBP
			}
		} __finally {
			if (AbnormalTermination())
				// one of the destructor has raised an exception that resulted
				// in another unwind.
				FrameUnwind(pUFrame, dwEbp, pExcFrame); // recursively
		}
	}
}

EXCEPTION_DISPOSITION __cdecl FrameHandler(UnwindFrame* pUFrame, EXCEPTION_RECORD* pExc, ExcReg* pExcFrame)
{
	// EXCEPTION_UNWINDING = 2, EXCEPTION_EXIT_UNWIND = 4
    if (6 & pExc->ExceptionFlags)
		FrameUnwind(pUFrame, (ULONG) (ULONG_PTR) &pExcFrame->m_ebp, pExcFrame);
    return ExceptionContinueSearch;
}

extern "C" __declspec (naked)
EXCEPTION_DISPOSITION __cdecl __CxxFrameHandler3(int a, int b, int c, int d)
{
	_asm {
		//prolog
        push EBP
        mov EBP, ESP

		// We don't use the last two parameters (processor and dispatcher contexts)
		// Hence - push just the 1st two parameters, plus the UnwindFrame passed in EAX
        push b
        push a
        push EAX

        call FrameHandler

		//epilog
        mov ESP, EBP
        pop EBP
        ret
	};
}
