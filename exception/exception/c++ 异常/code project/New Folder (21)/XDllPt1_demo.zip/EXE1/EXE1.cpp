// EXE1.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "EXE1.h"
#include "EXE1Dlg.h"
#include "DLL1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEXE1App

BEGIN_MESSAGE_MAP(CEXE1App, CWinApp)
	//{{AFX_MSG_MAP(CEXE1App)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEXE1App construction

CEXE1App::CEXE1App()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CEXE1App object

CEXE1App theApp;

/////////////////////////////////////////////////////////////////////////////
// CEXE1App initialization

BOOL CEXE1App::InitInstance()
{
#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CEXE1Dlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();
	return FALSE;
}
