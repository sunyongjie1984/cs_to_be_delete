// DLL1.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#define DLL1_EXPORTS
#include "DLL1.h"

BOOL APIENTRY DllMain(HANDLE /*hModule*/, 
                      DWORD  ul_reason_for_call, 
                      LPVOID /*lpReserved*/)
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}


///////////////////////////////////////////////////////////////////////////////
// GetCycleCount - private function of DLL1.cpp.  The static keyword ensures
//                 that this function name is not visible outside DLL1.cpp.
static inline unsigned __int64 GetCycleCount()
{
	unsigned int timehi, timelo;

	// Use the assembly instruction rdtsc, which gets the current
	// cycle count (since the process started) and puts it in edx:eax.
	__asm
	{
		rdtsc
		mov timehi, edx;
		mov timelo, eax;
	}

	return ((unsigned __int64)timehi << 32) + (unsigned __int64)timelo;
}


///////////////////////////////////////////////////////////////////////////////
// Example of an exported function
///////////////////////////////////////////////////////////////////////////////
// GetCpuSpeed - returns CPU speed in MHz;  for example, ~2193 will be 
//               returned for a 2.2 GHz CPU.
DLL1_API int GetCpuSpeed()
{
	const unsigned __int64 ui64StartCycle = GetCycleCount();
	Sleep(1000);
	return static_cast<int>((GetCycleCount() - ui64StartCycle) / 1000000);
}


///////////////////////////////////////////////////////////////////////////////
// Example of an exported class
///////////////////////////////////////////////////////////////////////////////
// This is the constructor of class CDLL1 that has been exported;
// see DLL1.h for the class definition
CDLL1::CDLL1()
{ 
}

int CDLL1::GetCpuSpeed()
{
	const unsigned __int64 ui64StartCycle = GetCycleCount();
	Sleep(1000);
	return static_cast<int>((GetCycleCount() - ui64StartCycle) / 1000000);
}
