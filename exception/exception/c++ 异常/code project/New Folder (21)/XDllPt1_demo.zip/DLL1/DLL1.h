#ifndef DLL1_H
#define DLL1_H

// The following ifdef block is the standard way of creating macros which 
// make exporting from a DLL simpler.  The DLL1.cpp file is compiled with 
// the symbol DLL1_EXPORTS defined at the top of DLL1.cpp.  This symbol should 
// *not* be defined in any project that uses DLL1.  This way any other 
// project whose source files include DLL1.h will see DLL1_API defined as
// __declspec(dllimport), whereas within DLL1.cpp, DLL1_API is defined as
// __declspec(dllexport).

#ifdef DLL1_EXPORTS
	#define DLL1_API __declspec(dllexport)
#else
	#pragma message("automatic link to DLL1.LIB")
	#pragma comment(lib, "DLL1.lib")
	#define DLL1_API __declspec(dllimport)
#endif


///////////////////////////////////////////////////////////////////////////////
// This function is exported from DLL1.dll
DLL1_API int GetCpuSpeed();


///////////////////////////////////////////////////////////////////////////////
// This class is exported from the DLL1.dll
class DLL1_API CDLL1 
{
public:
	CDLL1();
	int GetCpuSpeed();
};


#endif //DLL1_H
