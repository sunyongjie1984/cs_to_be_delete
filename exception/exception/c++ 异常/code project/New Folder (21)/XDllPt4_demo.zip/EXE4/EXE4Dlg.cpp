// EXE4Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "EXE4.h"
#include "EXE4Dlg.h"
#include "DLL3.h"
#include "XLoadLibrary.h"
#include "DLL3Wrapper.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEXE4Dlg dialog

BEGIN_MESSAGE_MAP(CEXE4Dlg, CDialog)
	//{{AFX_MSG_MAP(CEXE4Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_WM_CTLCOLOR()
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelchangeCombo1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CEXE4Dlg::CEXE4Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEXE4Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEXE4Dlg)
	m_nCallType = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CEXE4Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEXE4Dlg)
	DDX_Control(pDX, IDC_CODE, m_Code);
	DDX_Control(pDX, IDC_COMBO1, m_CallType);
	DDX_Control(pDX, IDC_SPEED1, m_Speed1);
	DDX_CBIndex(pDX, IDC_COMBO1, m_nCallType);
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CEXE4Dlg message handlers

BOOL CEXE4Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	m_CallType.SetCurSel(0);

	OnSelchangeCombo1();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CEXE4Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEXE4Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEXE4Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CEXE4Dlg::OnButton1() 
{
	CWaitCursor wait;

	switch (m_nCallType)
	{
		default:
		case 0:
			{
				// call via LIB class export
				CDLL3 dll3;
				int nSpeed = dll3.GetCpuSpeed();
				CString s;
				s.Format(_T("dll3.GetCpuSpeed() returned %d"), nSpeed);
				m_Speed1.SetWindowText(s);
			}
			break;

		case 1:
			{
				// call via class wrapper objptr
				CDLL3 * objptr = (CDLL3 *) CreateDll3();
				int nSpeed = objptr->GetCpuSpeed();
				CString s;
				s.Format(_T("objptr->GetCpuSpeed() returned %d"), nSpeed);
				m_Speed1.SetWindowText(s);
				DestroyDll3(objptr);
			}
			break;

		case 2:
			{
				// call via class wrapper function
				void * objptr = CreateDll3();
				int nSpeed = GetCpuSpeedDll3(objptr);
				CString s;
				s.Format(_T("GetCpuSpeedDll3() returned %d"), nSpeed);
				m_Speed1.SetWindowText(s);
				DestroyDll3(objptr);
			}
			break;

		case 3:
			{
				// call via dynamic linking (LoadLibrary)
				CXLoadLibrary lib;
				if (!lib.LoadLibrary(_T("DLL3.dll")))
					return;

				// get addressses for functions we need
				typedef void * (__stdcall *CreateFn)();
				CreateFn pfnCreate = 
					(CreateFn) GetProcAddress((HINSTANCE) lib, _T("CreateDll3"));
				typedef int (__stdcall *GetCpuSpeedDll3Fn)(void *);
				GetCpuSpeedDll3Fn pfnGetCpuSpeedDll3 = 
					(GetCpuSpeedDll3Fn) GetProcAddress((HINSTANCE) lib, _T("GetCpuSpeedDll3"));
				typedef void (__stdcall *DestroyDll3Fn)(void *);
				DestroyDll3Fn pfnDestroyDll3 = 
					(DestroyDll3Fn) GetProcAddress((HINSTANCE) lib, _T("DestroyDll3"));
				ASSERT(pfnCreate && pfnGetCpuSpeedDll3 && pfnDestroyDll3);

				void * objptr = pfnCreate();
				int nSpeed = pfnGetCpuSpeedDll3(objptr);
				CString s;
				s.Format(_T("pfnGetCpuSpeedDll3() returned %d"), nSpeed);
				m_Speed1.SetWindowText(s);
				pfnDestroyDll3(objptr);
			}
			break;

		case 4:
			{
				// This code demonstrates use of the 
				// "LateLoad DLL Wrapper" by Jason De Arte
				CDLL3Wrapper wrapper;

				if (!wrapper.Is_CreateDll3())
				{
					AfxMessageBox(_T("can't find CreateDLL3"));
				}
				else
				{
					void * objptr = wrapper.CreateDll3();
					int nSpeed = wrapper.GetCpuSpeedDll3(objptr);
					CString s;
					s.Format(_T("wrapper.GetCpuSpeedDll3() returned %d"), nSpeed);
					m_Speed1.SetWindowText(s);
					wrapper.DestroyDll3(objptr);
				}
			}
			break;
	}
}

void CEXE4Dlg::DisplayCode()
{
	if (m_nCallType < 0 || m_nCallType > 4)
		m_nCallType = 0;

	TCHAR * pszCode0 = _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"green\">// Call via LIB class export</font><br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CDLL3 dll3;<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">int</font> nSpeed = dll3.GetCpuSpeed();<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CString s;<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;s.Format(_T(<font color=\"fuchsia\">\"dll3.GetCpuSpeed() returned %d\"</font>), nSpeed);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;m_Speed2.SetWindowText(s);<br>");


	TCHAR * pszCode1 = _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"green\">// Call via class wrapper objptr</font><br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CDLL3 * objptr = (CDLL3 *) CreateDll3();<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">int</font> nSpeed = objptr->GetCpuSpeed();<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CString s;<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;s.Format(_T(<font color=\"fuchsia\">\"objptr->GetCpuSpeed() returned %d\"</font>), nSpeed);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;m_Speed1.SetWindowText(s);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DestroyDll3(objptr);<br>");

	TCHAR * pszCode2 = _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"green\">// Call via class wrapper function</font><br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;void * objptr = CreateDll3();<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">int</font> nSpeed = GetCpuSpeedDll3(objptr);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CString s;<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;s.Format(_T(<font color=\"fuchsia\">\"GetCpuSpeedDll3() returned %d\"</font>), nSpeed);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;m_Speed1.SetWindowText(s);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DestroyDll3(objptr);<br>");

	TCHAR * pszCode3 = _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"green\">// Call via dynamic linking (LoadLibrary)</font><br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CXLoadLibrary lib;<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">if</font> (!lib.LoadLibrary(_T(<font color=\"fuchsia\">\"DLL3.dll\"</font>)))<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">return</font>;<br><br>")

					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"green\">// get addressses for functions we need</font><br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">typedef void</font> * (<font color=\"blue\">__stdcall</font> *CreateFn)();<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CreateFn pfnCreate = <br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(CreateFn) GetProcAddress((HINSTANCE) lib, _T(<font color=\"fuchsia\">\"CreateDll3\"</font>));<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">typedef int</font> (<font color=\"blue\">__stdcall</font> *GetCpuSpeedDll3Fn)(<font color=\"blue\">void</font> *);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GetCpuSpeedDll3Fn pfnGetCpuSpeedDll3 = <br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(GetCpuSpeedDll3Fn) GetProcAddress((HINSTANCE) lib, _T(<font color=\"fuchsia\">\"GetCpuSpeedDll3\"</font>));<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">typedef void</font> (<font color=\"blue\">__stdcall</font> *DestroyDll3Fn)(<font color=\"blue\">void</font> *);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DestroyDll3Fn pfnDestroyDll3 = <br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(DestroyDll3Fn) GetProcAddress((HINSTANCE) lib, _T(<font color=\"fuchsia\">\"DestroyDll3\"</font>));<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ASSERT(pfnCreate && pfnGetCpuSpeedDll3 && pfnDestroyDll3);<br><br>")

					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">void</font> * objptr = pfnCreate();<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">int</font> nSpeed = pfnGetCpuSpeedDll3(objptr);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CString s;<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;s.Format(_T(<font color=\"fuchsia\">\"pfnGetCpuSpeedDll3() returned %d\"</font>), nSpeed);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;m_Speed1.SetWindowText(s);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pfnDestroyDll3(objptr);<br>");

	TCHAR * pszCode4 = _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"green\">// Call via LateLoad DLL Wrapper</font><br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"green\">// This code demonstrates use of the </font><br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"green\">// \"LateLoad DLL Wrapper\" by Jason De Arte</font><br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CDLL3Wrapper wrapper;<br><br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">if</font> (!wrapper.Is_CreateDll3())<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AfxMessageBox(_T(<font color=\"fuchsia\">\"can't find CreateDLL3\"</font>));<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">else</font><br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">void</font> * objptr = wrapper.CreateDll3();<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"blue\">int</font> nSpeed = wrapper.GetCpuSpeedDll3(objptr);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CString s;<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;s.Format(_T(<font color=\"fuchsia\">\"wrapper.GetCpuSpeedDll3() returned %d\"</font>), nSpeed);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;m_Speed1.SetWindowText(s);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;wrapper.DestroyDll3(objptr);<br>")
					   _T("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br>");


	TCHAR * pszCode = pszCode0;
	if (m_nCallType == 1)
		pszCode = pszCode1;
	else if (m_nCallType == 2)
		pszCode = pszCode2;
	else if (m_nCallType == 3)
		pszCode = pszCode3;
	else if (m_nCallType == 4)
		pszCode = pszCode4;
	
	m_Code.SetBkColor(RGB(255,255,255));
	m_Code.SetWindowText(pszCode);
	m_Code.RedrawWindow();
}


HBRUSH CEXE4Dlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	if (pWnd->m_hWnd == GetDlgItem(IDC_CODE)->m_hWnd)
		hbr = (HBRUSH) ::GetStockObject(WHITE_BRUSH);

	return hbr;
}

void CEXE4Dlg::OnSelchangeCombo1() 
{
	m_Speed1.SetWindowText(_T(""));

	UpdateData(TRUE);		// set m_nCallType

	DisplayCode();
}
