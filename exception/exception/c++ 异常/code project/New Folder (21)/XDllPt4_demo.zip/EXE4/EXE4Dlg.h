// EXE4Dlg.h : header file
//

#ifndef EXE4DLG_H
#define EXE4DLG_H

#include "XHTMLStatic.h"

/////////////////////////////////////////////////////////////////////////////
// CEXE4Dlg dialog

class CEXE4Dlg : public CDialog
{
// Construction
public:
	CEXE4Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CEXE4Dlg)
	enum { IDD = IDD_EXE4_DIALOG };
	CXHTMLStatic	m_Code;
	CComboBox		m_CallType;
	CEdit			m_Speed1;
	int				m_nCallType;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEXE4Dlg)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	void DisplayCode();


	// Generated message map functions
	//{{AFX_MSG(CEXE4Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSelchangeCombo1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif //EXE4DLG_H
