// XLoadLibrary.cpp  Version 1.1
//
// Author: Hans Dietrich
//         hdietrich2@hotmail.com
//
// Description:
//     XLoadLibrary.cpp implements CXLoadLibrary(), a class to wrap the Win32
//     API ::LoadLibrary().
//
// History
//     Version 1.1 - 2004 March 1
//                 - Initial public release
//
// This software is released into the public domain.  You are free to use it
// in any way you like, except that you may not sell this source code.
//
// This software is provided "as is" with no expressed or implied warranty.
// I accept no liability for any damage or loss of business that this software
// may cause.
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// include the following line if compiling an MFC app
#include "stdafx.h"
///////////////////////////////////////////////////////////////////////////////

#ifndef _MFC_VER
#include <windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <tchar.h>
#define TRACE ((void) 0)
#pragma message("    compiling for Win32")
#else
#pragma message("    compiling for MFC")
#endif

// determine number of elements in an array (not bytes)
#ifndef _countof
#define _countof(array) (sizeof(array)/sizeof(array[0]))
#endif

#pragma warning(disable : 4127)		// conditional expression is constant
									// (needed for _ASSERTE)

///////////////////////////////////////////////////////////////////////////////
//
// If you do not want TRACE output you can uncomment the following lines:
//
//#undef  TRACE
//#define TRACE ((void)0)
//

#include "XLoadLibrary.h"

#pragma message("automatic link to VERSION.LIB")
#pragma comment(lib, "version.lib")

///////////////////////////////////////////////////////////////////////////////
// ctor
CXLoadLibrary::CXLoadLibrary(LPCTSTR lpszPath /*=NULL*/)
{
	ZeroMemory(m_szPath, sizeof(m_szPath));

	m_pData     = NULL;
	m_hInstance = NULL;

	Init(lpszPath);
}

///////////////////////////////////////////////////////////////////////////////
// dtor
CXLoadLibrary::~CXLoadLibrary()
{
	// unload dll if loaded
	if (m_hInstance) 
		::FreeLibrary(m_hInstance);  
	m_hInstance = NULL;

	// free memory if allocated
	if (m_pData)
		delete [] m_pData;
	m_pData = NULL;
}

///////////////////////////////////////////////////////////////////////////////
// LoadLibrary
BOOL CXLoadLibrary::LoadLibrary(LPCTSTR lpszPath)
{
	return Init(lpszPath);
}

///////////////////////////////////////////////////////////////////////////////
// GetFileVersion
BOOL CXLoadLibrary::GetFileVersion(WORD * pwVersion)
{
	for (int i = 0; i < 4; i++)
		*pwVersion++ = m_wFileVersion[i];
	return TRUE;
}					 	 

///////////////////////////////////////////////////////////////////////////////
// GetProductVersion
BOOL CXLoadLibrary::GetProductVersion(WORD * pwVersion)
{
	for (int i = 0; i < 4; i++)
		*pwVersion++ = m_wProductVersion[i];
	return TRUE;
}


///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//
// protected methods
//
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
// GetFixedInfo
BOOL CXLoadLibrary::GetFixedInfo(VS_FIXEDFILEINFO& rFixedInfo)
{
	BOOL rc;
	UINT nLength;
	VS_FIXEDFILEINFO *pFixedInfo = NULL;

	if (!m_pData)
		return FALSE;

	if (m_pData)
		rc = ::VerQueryValue(m_pData, _T("\\"), (void **) &pFixedInfo, &nLength);
	else
		rc = FALSE;
		
	if (rc)
		memcpy (&rFixedInfo, pFixedInfo, sizeof (VS_FIXEDFILEINFO));	

	return rc;
}

///////////////////////////////////////////////////////////////////////////////
// Init
BOOL CXLoadLibrary::Init(LPCTSTR lpszPath)
{
	BOOL bRet = FALSE;

	// unload dll if already loaded
	if (m_hInstance) 
		::FreeLibrary(m_hInstance);  
	m_hInstance = NULL;

	// free memory if already allocated
	if (m_pData)
		delete [] m_pData;
	m_pData = NULL;

	ZeroMemory(m_szPath, sizeof(m_szPath));
	if (lpszPath && lpszPath[0] != _T('\0'))
		_tcsncpy(m_szPath, lpszPath, _countof(m_szPath)-1);

	if (m_szPath[0] != _T('\0')) 
		m_hInstance = ::LoadLibrary(m_szPath); 

	// initialize version info
	for (int i = 0; i < 4; i++)
	{
		m_wFileVersion[i]    = 0;
		m_wProductVersion[i] = 0;
	}
	
	if (m_hInstance)
	{
		DWORD dwHandle = 0;
		DWORD dwSize = ::GetFileVersionInfoSize((LPTSTR)(LPCTSTR)m_szPath, 
							&dwHandle);

		if (dwSize > 0)
		{
			m_pData = new BYTE [dwSize + 1];	
			ZeroMemory(m_pData, dwSize + 1);

			BOOL rc = ::GetFileVersionInfo((LPTSTR)(LPCTSTR)m_szPath, dwHandle,
							dwSize, m_pData);
			if (rc)
			{
				// get fixed info

				VS_FIXEDFILEINFO FixedInfo;
				
				if (GetFixedInfo(FixedInfo))
				{
					// get file & product version info

					m_wFileVersion[0] = HIWORD(FixedInfo.dwFileVersionMS);
					m_wFileVersion[1] = LOWORD(FixedInfo.dwFileVersionMS);
					m_wFileVersion[2] = HIWORD(FixedInfo.dwFileVersionLS);
					m_wFileVersion[3] = LOWORD(FixedInfo.dwFileVersionLS);

					m_wProductVersion[0] = HIWORD(FixedInfo.dwProductVersionMS);
					m_wProductVersion[1] = LOWORD(FixedInfo.dwProductVersionMS);
					m_wProductVersion[2] = HIWORD(FixedInfo.dwProductVersionLS);
					m_wProductVersion[3] = LOWORD(FixedInfo.dwProductVersionLS);

					bRet = TRUE;
				}
			}
		}
	}

	return bRet;
}
