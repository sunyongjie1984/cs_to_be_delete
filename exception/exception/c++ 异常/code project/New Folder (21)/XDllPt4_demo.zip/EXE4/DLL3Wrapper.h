#ifndef DLL3WRAPPER_H
#define DLL3WRAPPER_H

// based on LateLoad DLL Wrapper by Jason De Arte
// http://www.codeproject.com/useritems/LateLoad.asp

#include "LateLoad.h"

LATELOAD_BEGIN_CLASS(CDLL3Wrapper,	// the name of the class
					 DLL3,			// the DLL name
					 FALSE,			// FALSE = it will ONLY be loaded when 
									// any bound function is first used
					 TRUE)			// TRUE = FreeLibrary will be called 
									// in the destructor

	// Function Declaration, Zero Parameters, returns a value 
	//
	// ErrorResult, Default return value if the function could 
	//              not be loaded & it is called anyways
	// ReturnType,  type of value that the function returns
	// CallingConv, Calling convention of the function
	// FuncName,    Name of the function
	LATELOAD_FUNC_0(NULL,void *,STDAPICALLTYPE,CreateDll3)

	// Function Declaration, One Parameter, returns a value 
	//
	// ErrorResult, Default return value if the function could 
	//              not be loaded & it is called anyways
	// ReturnType,  type of value that the function returns
	// CallingConv, Calling convention of the function
	// FuncName,    Name of the function
	// ParamN       types of the function parameters
	LATELOAD_FUNC_1(0,int,STDAPICALLTYPE,GetCpuSpeedDll3,void *)

	// Function Declaration, One Parameter, returns nothing 
	//
	// CallingConv, Calling convention of the function
	// FuncName,    Name of the function
	// ParamN       types of the function parameters
	LATELOAD_FUNC_1_VOID(STDAPICALLTYPE,DestroyDll3,void *)

LATELOAD_END_CLASS()


#endif //DLL3WRAPPER_H
