// XLoadLibrary.h  Version 1.1
//
// Author:  Hans Dietrich
//          hdietrich2@hotmail.com
//
// This software is released into the public domain.  You are free to use it
// in any way you like, except that you may not sell this source code.
//
// This software is provided "as is" with no expressed or implied warranty.
// I accept no liability for any damage or loss of business that this software
// may cause.
//
///////////////////////////////////////////////////////////////////////////////

#ifndef XLOADLIBRARY_H
#define XLOADLIBRARY_H

class CXLoadLibrary
{
// Construction / Destruction
public:
	CXLoadLibrary(LPCTSTR lpszPath = NULL);
	virtual ~CXLoadLibrary();

// Attributes
public:
	BOOL		GetFileVersion(WORD *pwVersion);
	BOOL		GetProductVersion(WORD* pwVersion);

// Operations
public:
	BOOL		LoadLibrary(LPCTSTR lpszPath);
	operator	HINSTANCE() const 	{ return m_hInstance; }

// Implementation
protected:
	BOOL		Init(LPCTSTR lpszPath);
	BOOL		GetFixedInfo(VS_FIXEDFILEINFO& rFixedInfo);

	HINSTANCE	m_hInstance; 
	BYTE *		m_pData;
	WORD		m_wFileVersion[4];
	WORD		m_wProductVersion[4];
	TCHAR		m_szPath[_MAX_PATH*2];
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif //XLOADLIBRARY_H
