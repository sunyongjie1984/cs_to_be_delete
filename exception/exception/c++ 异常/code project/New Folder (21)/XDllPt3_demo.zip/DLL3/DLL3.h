#ifndef DLL3_H
#define DLL3_H

#ifdef DLL3_EXPORTS
	#define DLL3_API __declspec(dllexport)
#else
	#pragma message("automatic link to DLL3.LIB")
	#pragma comment(lib, "DLL3.lib")
	#define DLL3_API __declspec(dllimport)
#endif


///////////////////////////////////////////////////////////////////////////////
// This class is exported from DLL3.dll
class DLL3_API CDLL3 
{
public:
	CDLL3();
	int GetCpuSpeed();
};

void * __stdcall CreateDll3();
void __stdcall DestroyDll3(void * objptr);
int __stdcall GetCpuSpeedDll3(void * objptr);

#endif //DLL3_H
