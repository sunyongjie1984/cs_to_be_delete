﻿//
// Copyright 2004 Mohammad B. Abdulfatah
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

using System;

namespace ObjectGuardLib
{
    public abstract class ObjectGuard
        : IDisposable
    {
        private bool m_disposed = false;
        private bool m_dismissed = false;

        protected abstract void CleanUp();

        public void Dismiss()
        {
            m_dismissed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (this.m_disposed == false)
            {
                if (disposing)
                {
                    if (!m_dismissed)
                    {
                        CleanUp();
                    }
                }
            }
            m_disposed = true;
        }

        ~ObjectGuard()
        {
            Dispose(false);
        }
    }

    public class ObjectGuardVoid
        : ObjectGuard
    {
        private GuardDelegate m_delegate;

        protected override void CleanUp()
        {
            m_delegate();
        }

        public delegate void GuardDelegate();

        public ObjectGuardVoid(GuardDelegate aDelegate)
        {
            m_delegate = aDelegate;
        }
    }

    public class ObjectGuard<R>
        : ObjectGuard
    {
        private GuardDelegate m_delegate;

        protected override void CleanUp()
        {
            m_delegate();
        }

        public delegate R GuardDelegate();

        public ObjectGuard(GuardDelegate aDelegate)
        {
            m_delegate = aDelegate;
        }
    }

    public class ObjectGuardVoid<T1>
        : ObjectGuard
    {
        private T1 m_t1;
        private GuardDelegate m_delegate;

        public delegate void GuardDelegate(T1 t1);

        protected override void CleanUp()
        {
            m_delegate(m_t1);
        }

        public ObjectGuardVoid(T1 t1, GuardDelegate aDelegate)
        {
            m_t1 = t1;
            m_delegate = aDelegate;
        }
    }

    public class ObjectGuard<R, T1>
        : ObjectGuard
    {
        private T1 m_t1;
        private GuardDelegate m_delegate;

        public delegate R GuardDelegate(T1 t1);

        protected override void CleanUp()
        {
            m_delegate(m_t1);
        }

        public ObjectGuard(T1 t1, GuardDelegate aDelegate)
        {
            m_t1 = t1;
            m_delegate = aDelegate;
        }
    }

    public class ObjectGuardVoid<T1, T2>
    : ObjectGuard
    {
        private T1 m_t1;
        private T2 m_t2;

        private GuardDelegate m_delegate;

        public delegate void GuardDelegate(T1 t1, T2 t2);

        protected override void CleanUp()
        {
            m_delegate(m_t1, m_t2);
        }

        public ObjectGuardVoid(T1 t1, T2 t2, GuardDelegate aDelegate)
        {
            m_t1 = t1;
            m_t2 = t2;
            m_delegate = aDelegate;
        }
    }

    public class ObjectGuard<R, T1, T2>
        : ObjectGuard
    {
        private T1 m_t1;
        private T2 m_t2;

        private GuardDelegate m_delegate;

        public delegate R GuardDelegate(T1 t1, T2 t2);

        protected override void CleanUp()
        {
            m_delegate(m_t1, m_t2);
        }

        public ObjectGuard(T1 t1, T2 t2, GuardDelegate aDelegate)
        {
            m_t1 = t1;
            m_t2 = t2;
            m_delegate = aDelegate;
        }
    }

    public class ObjectGuardVoid<T1, T2, T3>
        : ObjectGuard
    {
        private T1 m_t1;
        private T2 m_t2;
        private T3 m_t3;

        private GuardDelegate m_delegate;

        public delegate void GuardDelegate(T1 t1, T2 t2, T3 t3);

        protected override void CleanUp()
        {
            m_delegate(m_t1, m_t2, m_t3);
        }

        public ObjectGuardVoid(T1 t1, T2 t2, T3 t3, GuardDelegate aDelegate)
        {
            m_t1 = t1;
            m_t2 = t2;
            m_t3 = t3;
            m_delegate = aDelegate;
        }
    }

    public class ObjectGuard<R, T1, T2, T3>
        : ObjectGuard
    {
        private T1 m_t1;
        private T2 m_t2;
        private T3 m_t3;

        private GuardDelegate m_delegate;

        public delegate R GuardDelegate(T1 t1, T2 t2, T3 t3);

        protected override void CleanUp()
        {
            m_delegate(m_t1, m_t2, m_t3);
        }

        public ObjectGuard(T1 t1, T2 t2, T3 t3, GuardDelegate aDelegate)
        {
            m_t1 = t1;
            m_t2 = t2;
            m_t3 = t3;
            m_delegate = aDelegate;
        }
    }

    public class ObjectGuardVoid<T1, T2, T3, T4>
    : ObjectGuard
    {
        private T1 m_t1;
        private T2 m_t2;
        private T3 m_t3;
        private T4 m_t4;

        private GuardDelegate m_delegate;

        public delegate void GuardDelegate(T1 t1, T2 t2, T3 t3, T4 t4);

        protected override void CleanUp()
        {
            m_delegate(m_t1, m_t2, m_t3, m_t4);
        }

        public ObjectGuardVoid(T1 t1, T2 t2, T3 t3, T4 t4, GuardDelegate aDelegate)
        {
            m_t1 = t1;
            m_t2 = t2;
            m_t3 = t3;
            m_t4 = t4;
            m_delegate = aDelegate;
        }
    }

    public class ObjectGuard<R, T1, T2, T3, T4>
        : ObjectGuard
    {
        private T1 m_t1;
        private T2 m_t2;
        private T3 m_t3;
        private T4 m_t4;

        private GuardDelegate m_delegate;

        public delegate R GuardDelegate(T1 t1, T2 t2, T3 t3, T4 t4);

        protected override void CleanUp()
        {
            m_delegate(m_t1, m_t2, m_t3, m_t4);
        }

        public ObjectGuard(T1 t1, T2 t2, T3 t3, T4 t4, GuardDelegate aDelegate)
        {
            m_t1 = t1;
            m_t2 = t2;
            m_t3 = t3;
            m_t4 = t4;
            m_delegate = aDelegate;
        }
    }

    public static class ObjectGuardFactory
    {
        public static ObjectGuardVoid Make(ObjectGuardVoid.GuardDelegate aDelegate)
        {
            return new ObjectGuardVoid(aDelegate);
        }

        public static ObjectGuardVoid<T1> Make<T1>(ObjectGuardVoid<T1>.GuardDelegate aDelegate, T1 t1)
        {
            return new ObjectGuardVoid<T1>(t1, aDelegate);
        }

        public static ObjectGuardVoid<T1, T2> Make<T1, T2>(ObjectGuardVoid<T1, T2>.GuardDelegate aDelegate, T1 t1, T2 t2)
        {
            return new ObjectGuardVoid<T1, T2>(t1, t2, aDelegate);
        }

        public static ObjectGuardVoid<T1, T2, T3> Make<T1, T2, T3>(ObjectGuardVoid<T1, T2, T3>.GuardDelegate aDelegate, T1 t1, T2 t2, T3 t3)
        {
            return new ObjectGuardVoid<T1, T2, T3>(t1, t2, t3, aDelegate);
        }

        public static ObjectGuardVoid<T1, T2, T3, T4> Make<T1, T2, T3, T4>(ObjectGuardVoid<T1, T2, T3, T4>.GuardDelegate aDelegate, T1 t1, T2 t2, T3 t3, T4 t4)
        {
            return new ObjectGuardVoid<T1, T2, T3, T4>(t1, t2, t3, t4, aDelegate);
        }
    }

    public static class ObjectGuardFactory<R>
    {
        public static ObjectGuard<R> Make(ObjectGuard<R>.GuardDelegate aDelegate)
        {
            return new ObjectGuard<R>(aDelegate);
        }

        public static ObjectGuard<R, T1> Make<T1>(ObjectGuard<R, T1>.GuardDelegate aDelegate, T1 t1)
        {
            return new ObjectGuard<R, T1>(t1, aDelegate);
        }

        public static ObjectGuard<R, T1, T2> Make<T1, T2>(ObjectGuard<R, T1, T2>.GuardDelegate aDelegate, T1 t1, T2 t2)
        {
            return new ObjectGuard<R, T1, T2>(t1, t2, aDelegate);
        }

        public static ObjectGuard<R, T1, T2, T3> Make<T1, T2, T3>(ObjectGuard<R, T1, T2, T3>.GuardDelegate aDelegate, T1 t1, T2 t2, T3 t3)
        {
            return new ObjectGuard<R, T1, T2, T3>(t1, t2, t3, aDelegate);
        }

        public static ObjectGuard<R, T1, T2, T3, T4> Make<T1, T2, T3, T4>(ObjectGuard<R, T1, T2, T3, T4>.GuardDelegate aDelegate, T1 t1, T2 t2, T3 t3, T4 t4)
        {
            return new ObjectGuard<R, T1, T2, T3, T4>(t1, t2, t3, t4, aDelegate);
        }
    }
}
