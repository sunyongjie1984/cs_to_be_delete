﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace TestHarness
{
    class Foo
    {
        public void Bar()
        {
            Console.WriteLine("Foo:Bar() calling.");
        }

        public int Bar(int i)
        {
            Console.WriteLine("int Foo:Bar(int i) calling with i= {0}.", i);
            return 0;
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            using (ObjectGuardLib.ScopeGuard scopeGuard = new ObjectGuardLib.ScopeGuard())
            {
                Foo f = new Foo();
                ObjectGuardLib.ObjectGuard guard = ObjectGuardLib.ObjectGuardFactory<int>.Make(f.Bar, 1);
                scopeGuard.Add( guard );
                scopeGuard.Add(ObjectGuardLib.ObjectGuardFactory.Make(delegate() { Console.WriteLine("Hellow World!"); }));
                Console.WriteLine("Testing, testing, testing.");
                //guard.Dismiss();
            }
        }
    }
}
