/*
 ******************************************************************************
 This file is part of MattRaffelNetCode.

    MattRaffelNetCode is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    MattRaffelNetCode is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with MattRaffelNetCode; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


    architected and written by 
    matt raffel 
    matt.raffel@mindspring.com

       copyright (c) 2005 by matt raffel unless noted otherwise

 ******************************************************************************
*/
using System;
using MattRaffelNetCode.ApplicationSupport;

namespace Test
{
    class TestApp
    {
        private class HelpException : Exception {}

        #region static methods/app entry
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            TestApp app = new TestApp();
            app.InitializeArguments();
            app.Run(args);
        }
        #endregion

        #region Public Members
        /// <summary>
        /// generates a set of CommandLineArguments and get them added to the hashtable
        /// </summary>
        public void InitializeArguments()
        {
            // create the help argument
            _cmdProcessor.AddArg(new CommandLineArgument("?", "prints help"));
            
            _cmdProcessor.AddArg(new DataCommandLineArgument("t", "the t option takes input"));
            _cmdProcessor.AddArg(new DataCommandLineArgument("h", "the h option takes input"));
            _cmdProcessor.AddArg(new DataCommandLineArgument("i", "the i option takes input"));

            SwitchableCommandLineArgument eoption = new SwitchableCommandLineArgument("e", "the e option (default)");
            SwitchableCommandLineArgument doption = new SwitchableCommandLineArgument("d", "the d option ");
            eoption.Selected = true;
            eoption.SwitchArg = doption;
            doption.SwitchArg = eoption;

            _cmdProcessor.AddArg(doption);
            _cmdProcessor.AddArg(eoption);

            _cmdProcessor.AddArg(new CommandLineArgument("r", "the r option"));

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        public void Run(string[] args)
        {
            // always say something about us
            PrintHeader();

            try
            {
                // parse the command line 
                _cmdProcessor.ParseCmdLineToArgs(args);

                // convert the command line data to something for the program
                ArgsToProgramData();

            }
            catch(HelpException)
            {
                PrintHelp();
            }
            catch(MattRaffelNetCode.ApplicationSupport.CommandlineException cmdError)
            {
                Console.WriteLine(cmdError.Message);
                Console.WriteLine("try Test /? for help");
            }
            catch(Exception error)
            {
                Console.WriteLine("this wasnt meant to happen");
                Console.WriteLine(error.Message);
                Console.WriteLine(error.StackTrace);
            }
            finally
            {
            }

        }
        #endregion

        #region private members
        private ApplicationCommandLine      _cmdProcessor = new ApplicationCommandLine();

        /// <summary>
        /// Prints a standard header info about the Test tool
        /// </summary>
        private void PrintHeader()
        {
            Console.WriteLine("Test 1.0 - tool for testing command line parsing");
        }

        /// <summary>
        /// prints help to the console
        /// </summary>
        private void PrintHelp()
        {        
            // output some help
            foreach(CommandLineArgument argument in _cmdProcessor)
            {
                Console.WriteLine("-{0}   {1}", argument.Argument, argument.ToString());
            }
        }

        /// <summary>
        /// For each of the CommandLineArgument instances that have been selected 
        /// (including any defaults not changed from the commandline input)
        /// convert those into program data that will be used by the Run method
        /// to perform the functions requested
        /// </summary>
        private void ArgsToProgramData()
        {
            foreach(CommandLineArgument argument in _cmdProcessor)
            {
                if (true == argument.Selected)
                {
                    char ch = argument.Argument.ToString().ToCharArray()[0];
                    switch (ch)
                    {
                        case 't':
                            Console.WriteLine("The t option has data of " + (argument as DataCommandLineArgument).Data);
                            break;
                        case 'h':
                            Console.WriteLine("The h option has data of " + (argument as DataCommandLineArgument).Data);
                            break;
                        case 'i':
                            Console.WriteLine("The i option has data of " + (argument as DataCommandLineArgument).Data);
                            break;
                        case 'e':
                            Console.WriteLine("The e option chosen");
                            break;
                        case 'd':
                            Console.WriteLine("The d option chosen");
                            break;
                        case 'r':
                            Console.WriteLine("The r option chosen");
                            break;
                        case '?':
                            throw new HelpException();
                        default:
                            throw new Exception(String.Format("found an weird arugment {0}", ch));

                    }
                }
            }
        }
        #endregion
    }
}
