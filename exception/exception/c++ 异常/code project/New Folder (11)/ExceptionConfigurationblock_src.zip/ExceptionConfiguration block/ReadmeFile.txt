1)Install Enterprise Library1.0

2)Copy this folder into inetpub/wwwroot/

3)To see the output: First delete Trace .log file

For any Query:
Santosh_poojari@rediffmail.com

